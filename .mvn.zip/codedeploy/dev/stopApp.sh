#!/bin/bash

check=`ps -ef | grep -v "grep" | grep "tomcat9" | wc -l`

if [ $check -gt 0 ]
then

    echo "stopApp"

    sudo -u tomcat /data/was/tomcat9/bin/shutdown.sh
fi