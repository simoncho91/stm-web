#!/bin/bash

echo "start mybeaker-front-mweb"

sudo -u tomcat mv /data/was-app/mybeaker-0.0.1-SNAPSHOT.war /data/was-app/ROOT.war

echo "end mybeaker-front-mweb"