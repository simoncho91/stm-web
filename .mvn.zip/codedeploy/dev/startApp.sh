#!/bin/bash

echo "startApp"

rm -rf /data/was-app/ROOT

sudo -u tomcat /data/was/tomcat9/bin/startup.sh