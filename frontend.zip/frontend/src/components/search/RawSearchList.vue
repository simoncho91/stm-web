<template>
  <div>
    <section class="search-bar">
      <h2 class="for-a11y">검색</h2>
      <div class="search-bar__left">
        <div class="search-bar__row">
          <dl class="search-bar__item">
            <dt class="search-bar__key search-bar__width--90">검색</dt>
            <dd class="search-bar__val">
              <div class="search-form">
                <div class="search-form__inner">
                  <ap-input
                    :inputClass="'ui-input__width--258'"
                    :placeholder="'내용물코드 or 내용물명 or 원료코드 or 원료명'"
                    v-model:value="searchParams.vKeyword"
                    @keypressEnter="fnSearchRawList(1)"
                  />
                  <button
                    type="button"
                    class="button-search"
                    @click="fnSearchRawList(1)"
                  >
                    검색
                  </button>
                </div>
              </div>
            </dd>
          </dl>
        </div>
      </div>

      <div class="search-bar__right">
          <div class="ui-buttons">
              <button
                type="button"
                class="ui-button ui-button__bg--blue font-weight__400"
                @click="fnOpenSearchDeptAuthMngPopup()"
              >검색부서 권한관리</button>
          </div>
      </div>
    </section>

    <div class="contents-tab__body--item">
      <div class="ui-table__wrap">
        <table class="ui-table text-center ui-table__td--40">
          <colgroup>
            <col style="width:9rem;">
            <col style="width:9%;">
            <col style="width:11%;">
            <col style="width:9%;">
            <col style="width:auto;">
            <col style="width:8%;">
            <col style="width:8%;">
          </colgroup>
          <thead>
            <tr>
              <th>NO</th>
              <th>브랜드</th>
              <th>플랜트</th>
              <th>내용물코드</th>
              <th>내용물명</th>
              <th>담당자</th>
              <th>출시완료일</th>
            </tr>
          </thead>
          <tbody>
            <template v-if="list && list.length > 0">
              <tr v-for="(vo, idx) in list" :key="'tr_' + idx">
                <td>{{ page.totalCnt - ((page.pageSize * (page.nowPageNo-1)) + idx)}}</td>
                <td>{{ vo.vBrdNm }}</td>
                <td>{{ vo.vPlantNm }}</td>
                <td>{{ vo.vContCd }}</td>
                <td class="tit">
                  <div class="tit__inner">
                    <a
                      href="#"
                      class="tit-link"
                      @click.prevent="fnOpenContDetailPopup(vo)"
                    >{{ vo.vContNm }}</a>
                  </div>
                </td>
                <td>{{ vo.vUsernm }}</td>
                <td>{{ commonUtils.changeStrDatePattern(vo.vCompleteDt, '.') }}</td>
              </tr>
            </template>
            <template v-else>
              <tr>
                <td colspan="7">
                  <div class="no-result">
                    {{ t('common.msg.no_data') }}
                  </div>
                </td>
              </tr>
            </template>
          </tbody>
        </table>
      </div>
      <div class="board-bottom">
        <div class="board-bottom__inner">
          <Pagination
            :page-info="page"
            @click="fnSearchRawList"
          />
        </div>
      </div>
    </div>
  </div>
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @selectFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, inject } from 'vue'
import { useSearch } from '@/compositions/search/useSearch'

export default {
  name: 'RawSearchList',
  components: {
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    SearchDeptAuthMngPop: defineAsyncComponent(() => import('@/components/search/popup/SearchDeptAuthMngPop.vue')),
    ContDetailPop: defineAsyncComponent(() => import('@/components/search/popup/ContDetailPop.vue'))
  },
  setup() {
    const t = inject('t')
    const commonUtils = inject('commonUtils')

    const {
      searchParams,
      page,
      list,
      popupContent,
      popParams,
      popSelectFunc,
      fnSearchRawList,
      fnOpenSearchDeptAuthMngPopup,
      fnOpenContDetailPopup
    } = useSearch()

    const init = async () => {
      fnSearchRawList(1)
    }

    init()

    return {
      t,
      commonUtils,
      searchParams,
      page,
      list,
      popupContent,
      popParams,
      popSelectFunc,
      fnSearchRawList,
      fnOpenSearchDeptAuthMngPopup,
      fnOpenContDetailPopup,
    }
  }
}
</script>
