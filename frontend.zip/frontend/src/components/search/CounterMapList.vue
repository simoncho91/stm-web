<template>
  <div>
    <section class="search-bar">
      <h2 class="for-a11y">검색</h2>

      <div class="search-bar__left">
        <div class="search-bar__row">
          <dl class="search-bar__item">
            <dt class="search-bar__key search-bar__width--90">검색</dt>
            <dd class="search-bar__val">
              <div class="search-form">
                <div class="search-form__inner">
                  <ap-input
                    :inputClass="'ui-input__width--290'"
                    :placeholder="'내용물코드 or 내용물명 or 원료코드 or 원료명'"
                    v-model:value="searchParams.vKeyword"
                    @keypressEnter="fnSearchCounterMapList()"
                  />
                  <button
                    type="button"
                    class="button-search"
                    @click="fnSearchCounterMapList()"
                  >
                    검색
                  </button>
                </div>
              </div>
            </dd>
          </dl>
        </div>
      </div>
    </section>

    <div class="compare-contents">
      <div class="compare-contents__inner">
        <!-- 2023.03.22 : mod : 레이아웃 수정 -->
        <div class="compare-contents__item--wrap">
          <template v-if="compareContArr && compareContArr.length > 0">
            <div
              v-for="(vo, idx) in compareContArr"
              :key="'cmp_' + idx"
              class="compare-contents__item"
            >
              <div class="compare-contents__text">{{ vo.vText }}</div>
              <div class="compare-contents__delete">
                <button
                  class="compare-contents__delete--button"
                  @click="compareContArr.splice(idx, 1)"
                >
              </button>
              </div>
            </div>
          </template>
        </div>
        <div class="compare-contents__button">
          <button
            class="ui-button ui-button__bg--blue font-weight__300"
            @click="fnOpenContComparePopup(compareContArr)"
          >비교하기</button>
        </div>
        <!--// 2023.03.22 : mod : 레이아웃 수정 -->
      </div>
    </div>

    <div class="contents-tab__body--item">
      <div class="ui-table__wrap">
        <table class="ui-table text-center ui-table__td--40">
          <colgroup>
            <col style="width:6rem;">
            <col style="width:10.5%;">
            <col style="width:10.5%;">
            <col style="width:auto;">
          </colgroup>
          <thead>
            <tr>
              <th></th>
              <th>브랜드</th>
              <th>내용물코드</th>
              <th>내용물명</th>
            </tr>
          </thead>
          <tbody>
            <template v-if="list && list.length > 0">
              <tr v-for="(vo, idx) in list" :key="'tr_' + idx">
                <td>
                  <div class="ui-checkbox-block" :id="`div_check_${idx}_wrap`">
                    <input
                      :id="`ex_check_${idx}`"
                      type="checkbox"
                      class="ui-checkbox"
                      :model="compareContArr"
                      :value="vo"
                      :checked="compareContArr.indexOf(vo) > -1"
                      @click="onClick($event)"
                    />
                    <label :for="`ex_check_${idx}`" class="ui-label">
                      <span class="ui-checkbox-object"></span>
                    </label>
                  </div>
                </td>
                <td>{{ vo.vBrdNm }}</td>
                <td style="cursor: pointer;" @click="fnClickChkBox(idx)">{{ vo.vContCd }}</td>
                <td style="cursor: pointer;" @click="fnClickChkBox(idx)">{{ vo.vText }}</td>
              </tr>
            </template>
            <template v-else>
              <tr>
                <td colspan="4">
                  <div class="no-result">
                    {{ t('common.msg.no_data') }}
                  </div>
                </td>
              </tr>
            </template>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @selectFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useSearch } from '@/compositions/search/useSearch'

export default {
  name: 'CounterMapList',
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    ContComparePop: defineAsyncComponent(() => import('@/components/search/popup/ContComparePop.vue'))
  },
  setup() {
    const t = inject('t')
    const { openAsyncAlert } = useActions(['openAsyncAlert'])
    const commonUtils = inject('commonUtils')

    const {
      searchParams,
      list,
      popupContent,
      popParams,
      popSelectFunc,
      fnSearchCounterMapList,
      compareContArr,
      fnOpenContComparePopup
    } = useSearch()

    const onClick = (e) => {
      const isChecked = e.target.checked
      const value = e.target._value

      if (isChecked && compareContArr.value.length === 3) {
        e.preventDefault()
        openAsyncAlert({ message: '내용물 비교는 3개를 초과할 수 없습니다.' })
        return
      }

      if (isChecked) {
        compareContArr.value.push(value)
        compareContArr.value.sort((a, b) => {
          if (a.vContPkCd < b.vContPkCd) return -1
          if (a.vContPkCd > b.vContPkCd) return 1

          return 0
        })
      } else {
        compareContArr.value.splice(compareContArr.value.indexOf(value), 1)
      }
    }

    const fnClickChkBox = (idx) => {
      document.querySelector(`#ex_check_${idx}`).click()
    }

    return {
      t,
      commonUtils,
      searchParams,
      list,
      popupContent,
      popParams,
      popSelectFunc,
      fnSearchCounterMapList,
      compareContArr,
      fnOpenContComparePopup,
      onClick,
      fnClickChkBox
    }
  }
}
</script>
