<template>
  <div class="modal-content">
    <div class="modal-header">
      <div class="modal-title">내용물 비교</div>
      <button type="button" class="modal-close" @click="fnClosePopup"></button>
    </div>
    <div class="modal-body">
      <template v-if="mateRateInfoList && mateRateInfoList.length > 0">
        <div class="form-flex align-start">
          <template v-for="(mateRateInfo, idx) in mateRateInfoList" :key="`div_${idx}`">
            <div class="form-flex__cell form-flex__cell--460">
              <div class="search-depart-table">
                <div class="search-depart-table__inner">
                  <table class="ui-table__td--40">
                    <colgroup>
                      <col style="width: 9rem" />
                      <col style="width: auto" />
                    </colgroup>
                    <tbody>
                      <tr>
                        <th>내용물명</th>
                        <td>
                          <div class="font-weight__600 color-blue">
                            {{ mateRateInfo[0].vContNm }}
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <th>연구원</th>
                        <td>{{ mateRateInfo[0].vUsernm }}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
              <div class="search-detail-table mt-15">
                <div class="search-detail-table__inner">
                  <table class="ui-table__modal">
                    <colgroup>
                      <col style="width: 8.2rem" />
                      <col style="width: auto" />
                      <col style="width: 15rem" />
                    </colgroup>
                    <thead>
                      <tr>
                        <th>원료코드</th>
                        <th>원료명</th>
                        <th>{{ mateRateInfo[0].vLotNm }} 함량</th>
                      </tr>
                    </thead>
                    <tbody>
                      <template v-if="mateRateInfo && mateRateInfo.length > 0">
                        <tr
                          v-for="(vo, idx2) in mateRateInfo"
                          :key="`tr_${idx2}`"
                        >
                          <td>{{ vo.vMateCd }}</td>
                          <td class="text-left pl-10">
                            {{ vo.vMateNm }}
                          </td>
                          <td>{{ vo.nRate }}</td>
                        </tr>
                      </template>
                    </tbody>
                  </table>
                </div>
              </div>
              <div class="search-detail-total">
                <div class="search-detail-total__inner">
                  <div class="search-detail-total__text">합계</div>
                  <div
                    class="search-detail-total__num search-detail-total__num--width-150"
                  >
                    {{ mateRateInfo[0].nRateSum }}
                  </div>
                </div>
              </div>
            </div>
          </template>
        </div>
      </template>
    </div>
  </div>
</template>

<script>
import { inject } from 'vue'
import { useSearch } from '@/compositions/search/useSearch'

export default {
  name: 'ContComparePop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {}
      },
    },
  },
  setup(props) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')

    const {
      mateRateInfoList,
      fnClosePopup,
      fnSearchMateRateInfo
    } = useSearch()

    const init = () => {
      const payload = props.popParams

      if (commonUtils.isNotEmpty(payload)) {
        fnSearchMateRateInfo(payload)
      }
    }

    init()

    return {
      t,
      commonUtils,
      mateRateInfoList,
      fnClosePopup
    }
  },
}
</script>
