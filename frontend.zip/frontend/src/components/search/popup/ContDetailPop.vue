<template>
  <div class="modal-content modal-content__width--701">
    <div class="modal-header">
      <div class="modal-title">상세조회</div>
      <button type="button" class="modal-close" @click="fnClose"></button>
    </div>
    <div class="modal-body">
      <template v-if="contentDetailInfo && contentDetailInfo.length > 0">
        <div class="search-depart-table">
          <div class="search-depart-table__inner">
            <table class="ui-table__td--40">
              <colgroup>
                <col style="width: 13rem" />
                <col style="width: auto" />
              </colgroup>
              <tbody>
                <tr>
                  <th>내용물명</th>
                  <td>
                    <div class="font-weight__600 color-blue">
                      {{ contentDetailInfo[0].vContNm }}
                    </div>
                  </td>
                </tr>
                <tr>
                  <th>연구원</th>
                  <td>{{ contentDetailInfo[0].vUsernm }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div class="search-detail-table mt-15">
          <div class="search-detail-table__inner">
            <table class="ui-table__modal">
              <colgroup>
                <col style="width: 13rem" />
                <col style="width: auto" />
                <col style="width: 14rem" />
              </colgroup>
              <thead>
                <tr>
                  <th>원료코드</th>
                  <th>원료명</th>
                  <th>{{ contentDetailInfo[0].vLotNm }} 함량</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(vo, idx) in contentDetailInfo" :key="`tr_${idx}`">
                  <td>{{ vo.vMateCd }}</td>
                  <td class="text-left pl-10">
                    {{ vo.vMateNm }}
                  </td>
                  <td>{{ vo.nRate }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div class="search-detail-total">
          <div class="search-detail-total__inner">
            <div class="search-detail-total__text">합계</div>
            <div class="search-detail-total__num">{{ contentDetailInfo[0].nRateSum }}</div>
          </div>
        </div>
      </template>
      <template v-else>
        <div class="search-depart-table">
          <div class="search-depart-table__inner">
            <table class="ui-table__td--40">
              <colgroup>
                <col style="width: 13rem" />
                <col style="width: auto" />
              </colgroup>
              <tbody>
                <tr>
                  <th>내용물명</th>
                  <td>
                    <div class="font-weight__600 color-blue">
                      {{ popParams.vContNm }}
                    </div>
                  </td>
                </tr>
                <tr>
                  <th>연구원</th>
                  <td>{{ popParams.vUsernm }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div class="search-detail-table mt-15">
          <div class="search-detail-table__inner">
            <table class="ui-table__modal">
              <colgroup>
                <col style="width: 13rem" />
                <col style="width: auto" />
                <col style="width: 14rem" />
              </colgroup>
              <thead>
                <tr>
                  <th>원료코드</th>
                  <th>원료명</th>
                  <th>함량</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td colspan="3">
                    <div class="no-result">조회된 내용이 없습니다.</div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </template>
    </div>
  </div>
</template>

<script>
import { inject } from 'vue'
import { useSearch } from '@/compositions/search/useSearch'

export default {
  name: 'ContDetailPop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {}
      },
    },
  },
  emits: ['closeFunc'],
  setup(props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')

    const {
      contentDetailInfo,
      fnClosePopup,
      fnSearchContentDetailInfo
    } = useSearch()

    const fnClose = () => {
      if (props.popParams.popSub !== 'Y') {
        fnClosePopup()
      } else {
        context.emit('closeFunc')
      }
    }

    const init = () => {
      const payload = props.popParams

      if (commonUtils.isNotEmpty(payload)) {
        fnSearchContentDetailInfo(payload)
      }
    }

    init()

    return {
      t,
      commonUtils,
      contentDetailInfo,
      fnClose,
    }
  },
}
</script>
