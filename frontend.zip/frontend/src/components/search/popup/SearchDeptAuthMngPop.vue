<template>
  <div class="modal-content modal-content__width--640">
    <div class="modal-header">
      <div class="modal-title">검색부서 권한관리</div>
      <button
        type="button"
        class="modal-close"
        @click="fnClosePopup"
      ></button>
    </div>

    <div class="modal-body">

      <div class="board-top">
        <div class="board-flex">
          <div class="board-cell">
            <div class="search-bar__left">
              <div class="search-bar__row search-bar__row--modal">
                <dl class="search-bar__item search-bar__item--modal">
                  <dt class="search-bar__key">실험노트</dt>
                  <dd class="search-bar__val">
                    <div class="search-form">
                      <div class="search-form__inner">
                        <ap-selectbox
                          :input-class="'ui-select__width--110'"
                          v-model:value="selectValue"
                          :options="codeGroupMaps['LNC25']"
                          :default-blank="{ blank: false }"
                        />
                      </div>
                    </div>

                  </dd>
                </dl>
                <dl class="search-bar__item search-bar__item--modal">
                  <dt class="search-bar__key">부서</dt>
                  <dd class="search-bar__val">
                    <div class="search-form">
                      <div class="search-form__inner">
                        <div style="width: 28rem">
                          <DeptTree
                            v-model:deptcd="selectDeptInfo.vDeptCd"
                            v-model:deptnm="selectDeptInfo.vSigmaDeptnm"
                            udeptcd="10011"
                          />
                        </div>
                        <button
                          type="button"
                          class="ui-button ui-button__bg--blue ml-10"
                          @click="fnAdd"
                        >추가</button>
                      </div>
                    </div>

                  </dd>
                </dl>
              </div>
            </div>


          </div>
        </div>
      </div>


      <div class="search-depart-table">
        <div class="search-depart-table__inner">
          <template v-if="Object.keys(authDeptInfo).length > 0">
            <table
              v-for="(cvo, idx) in codeGroupMaps['LNC25']"
              :key="`auth_dept_table_${idx}`"
              class="ui-table__td--40"
            >
              <colgroup>
                <col style="width:11rem">
                <col style="width:auto">
              </colgroup>
              <tbody v-if="authDeptInfo[cvo.vSubCode] && authDeptInfo[cvo.vSubCode].length > 0">
                <tr
                  v-for="(avo, idx2) in authDeptInfo[cvo.vSubCode]"
                  :key="`auth_dept_tr_${idx2}`"
                >
                  <th
                    v-if="idx2 === 0"
                    :rowspan="authDeptInfo[cvo.vSubCode].length"
                  >{{ avo.vSubCodenm }}</th>
                  <td>
                    <div class="search-depart__item">
                      <div class="">{{ avo.vSigmaDeptnm }}</div>
                      <div class="ui-buttons">
                        <button
                          type="button"
                          class="ui-button ui-button__width--40 ui-button__height--23 ui-button__border--blue ui-button__radius--2"
                          @click="authDeptInfo[cvo.vSubCode].splice(idx2, 1)"
                        >삭제</button>
                      </div>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </template>
        </div>
      </div>

      <div class="board-bottom ">
        <div class="board-bottom__inner">
          <div class="ui-buttons ml-auto ui-buttons__right">
            <button
              type="button"
              class="ui-button ui-button__bg--skyblue font-weight__300"
              @click="fnConfirm"
            >저장</button>
            <button
              type="button"
              class="ui-button ui-button__bg--lightgray"
              @click="fnClosePopup"
            >닫기</button>
          </div>
        </div>

      </div>

    </div>
  </div>
</template>

<script>
import { inject, defineAsyncComponent, ref } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useSearch } from '@/compositions/search/useSearch'

export default {
  name: 'SearchDeptAuthMngPop',
  components: {
    DeptTree: defineAsyncComponent(() => import('@/components/comm/DeptTree.vue'))
  },
  setup() {
    const t = inject('t')
    const commonUtils = inject('commonUtils')

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const {
      authDeptInfo,
      fnClosePopup,
      fnSearchAuthDeptInfo,
      insertAuthDeptInfo
    } = useSearch()

    const selectValue = ref('SC')

    const selectDivInfo = ref({
      vNoteType: '',
      vSubCode: '',
      vSubCodenm: ''
    })
    const selectDeptInfo = ref({
      vDeptCd: '10011',
      vSigmaDeptnm: ''
    })

    const fnAdd = () => {
      const divInfo = codeGroupMaps.value['LNC25'].find(item => item.vSubCode === selectValue.value)

      selectDivInfo.value['vNoteType'] = divInfo['vSubCode']
      selectDivInfo.value['vSubCode'] = divInfo['vSubCode']
      selectDivInfo.value['vSubCodenm'] = divInfo['vSubCodenm']

      authDeptInfo.value[selectValue.value].push({
        ...selectDivInfo.value,
        ...selectDeptInfo.value
      })
    }

    const fnConfirm = async () => {
      const result = await insertAuthDeptInfo(authDeptInfo.value)

      if (result) {
        fnClosePopup()
      }
    }

    const init = async () => {
      await findCodeList(['LNC25'])

      codeGroupMaps.value['LNC25'] = codeGroupMaps.value['LNC25'].filter(vo => vo.vSubCode !== 'BF')

      fnSearchAuthDeptInfo()
    }

    init()

    return {
      t,
      commonUtils,
      codeGroupMaps,
      authDeptInfo,
      fnClosePopup,
      selectValue,
      selectDeptInfo,
      fnAdd,
      fnConfirm
    }
  }
}
</script>
