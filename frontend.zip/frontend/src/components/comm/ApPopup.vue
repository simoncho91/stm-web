<template>
  <div :class="popupInfo.isOpen ? 'modal-backdrop fade in' : ''"></div>
  <div class="modal fade in" v-if="popupInfo.isOpen">
    <div class="modal-dialog modal-popup" :class="popupInfo.isScroll ? 'modal-dialog-scrollable' : ''">
      <slot />
    </div>
  </div>
</template>

<script>
import { computed } from 'vue'
import { useStore } from 'vuex-composition-helpers'

export default {
  name: 'ApPopup',
  setup() {
    const store = useStore()
    const popupInfo = computed(() => store.getters.getPopupInfo())

    return {
      popupInfo
    }
  }
}
</script>
