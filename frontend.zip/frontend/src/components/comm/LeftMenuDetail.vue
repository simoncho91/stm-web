<template>
  <div class="left-menu" id="leftMenu">
    <div class="left-menu__inner" v-show="isShow">
      <button type="button" class="left-menu__button"><i class="left-menu__button--icon"></i></button>
      <div class="left-menu__box">
        <div class="menu-toggle" v-show="isBrdUser !== 'Y'">
          <div class="menu-toggle__inner">
            <div class="menu-toggle__text">{{ checkSubMenu === 'Y' ? subMenuInfo[noteType].menuNm : 'My Beaker' }}</div>

            <div class="toggle-switch">
              <input type="checkbox"
                class="menu-toggle__switch--input"
                id="toggleMenu"
                v-model="checkSubMenu"
                true-value="Y"
                false-value=""
                @click="changeMenu($event)"
              >
              <label for="toggleMenu" class="menu-toggle__switch--label">
                <span class="onf_btn"></span>
              </label>
            </div>
          </div>
        </div>

        <div class="left-menu__item left-menu__item--repeat left-menu__item--global" :style="isBrdUser === 'Y' ? 'display:block;' : 'display:none;'">
          <left-menu></left-menu>
        </div>

        <div class="left-menu__item left-menu__item--skin">
          <ul class="ui-list left-menu__lists left-menu__lists--height-60" :style="isBrdUser === 'Y' ? 'display:none;' : ''">
            <template v-for="(item, index) in menuList" :key="'sub_menu_' + index">
              <li class="left-menu__list" :class="currentPath === item.vPageid ? 'is-active' : ''">
                <a href="javascript:void(0)" class="left-menu__link" @click="goPage(item)">
                  <i :class="'left-menu__icon left-menu__icon--' + item.vDetailCssnm"></i>
                  <span class="left-menu__text">{{ item.vPagenm }}</span>
                  <span class="left-menu__tooltip">{{ item.vPagenm }}</span>
                </a>
              </li>
            </template>
          </ul>
        </div>
      </div>
      <div class="left-menu__copyright">© Amorepacific Corp.</div>
    </div>
  </div>
</template>

<script>
import { computed, ref, onMounted, watch, inject } from 'vue'
import { useStore } from 'vuex'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useRoute, useRouter } from 'vue-router'

import LeftMenu from '@/components/comm/LeftMenu.vue'
export default {
  name: 'LeftMenuDetail',
  components: {
    LeftMenu,
  },
  setup () {
    const commonUtils = inject('commonUtils')
    const store = useStore()
    const route = useRoute()
    const router = useRouter()
    const checkSubMenu = ref('Y')
    const isBrdUser = ref('N')
    const isShow = ref(false)
    const subMenuInfo = {
      'SC': { menuNm: 'Skin care' },
      'MU': { menuNm: 'Make up'},
      'HBO': { menuNm: 'HBD' },
      'SA': { menuNm: '의약외품' }
    }

    const noteType = store.getters.getNoteType()
    const noteInfo = computed(() => store.getters.getNoteInfo())
    const myInfo = store.getters.getMyInfo()

    const menuid = store.getters.getMstMenuid()
    const subMenuList = computed(() => store.getters.getSubMenuList().filter(item => item.vMenuid === menuid))
    const currentPath = computed(() => route.path)

    const menuList = ref([])

    const {
      selectLabNoteInfoCheckAuth,
    } = useLabCommon()

    const goPage = (item) => {
      const query = route.query
      router.push({ path: item.vPageid, query: query })
    }

    const changeMenu = (event) => {
      if (event.target.checked) {
        document.querySelector('.left-menu__item--global').style.display = 'none'
        document.querySelector('.left-menu__item--skin').style.display = 'block'
        checkSubMenu.value = 'Y'
      } else {
        document.querySelector('.left-menu__item--global').style.display = 'block'
        document.querySelector('.left-menu__item--skin').style.display = 'none'
        checkSubMenu.value = ''
      }
    }

    const setMenuList = (noteInfo) => {
      if (!noteInfo) {
        return
      }

      store.dispatch('setNoteInfo', noteInfo)

      if (noteInfo.vBrdUserid === myInfo.loginId && myInfo.groups.indexOf('S000000') === -1) {
        checkSubMenu.value = ''
        isBrdUser.value = 'Y'
      }

      menuList.value = subMenuList.value

      if (noteInfo.vUserid !== myInfo.loginId &&
          noteInfo.vFlagContUserYn !== 'Y' &&
          myInfo.groups.indexOf('S000000') === -1) {
        menuList.value = menuList.value.filter(menu => menu.vDetailCssnm !== 'test')
      }

      if (noteInfo.vUserid !== myInfo.loginId &&
          noteInfo.vCtcUserid !== myInfo.loginId &&
          noteInfo.vSlUserid !== myInfo.loginId &&
          noteInfo.vFlagContUserYn !== 'Y' &&
          myInfo.groups.indexOf('S000000') === -1) {
          menuList.value = menuList.value.filter(menu => menu.vDetailCssnm !== 'folmula')
      }

      const statusCd = noteInfo.vStatusCd

      if (statusCd) {
        const statusNum = Number(statusCd.substring(6, 8))

        if (statusNum === 1) {
          menuList.value = menuList.value.filter(menu => menu.vDetailCssnm === 'basicInfo')
        } else if (statusNum < 21) { // 실험요청 이전일 때
          menuList.value = menuList.value.filter(menu => menu.vDetailCssnm !== 'folmula' && menu.vDetailCssnm !== 'test')
        } else if (statusNum < 22) {
          menuList.value = menuList.value.filter(menu => menu.vDetailCssnm !== 'test')
        }
      }

      isShow.value = true
    }

    const init = async () => {
      if (commonUtils.isEmpty(noteInfo.value) && commonUtils.isNotEmpty(route.query.vLabNoteCd)) {
        const noteInfo= await selectLabNoteInfoCheckAuth({ vLabNoteCd: route.query.vLabNoteCd })
        setMenuList(noteInfo)
      } else {
        setMenuList(noteInfo.value)
      }
    }

    init()

    watch(() => noteInfo.value, (newVal) => {
      setMenuList(newVal)
    })

    onMounted(() => {
      const recentFilterArea = document.querySelector('#recent-filter-area')

      if (recentFilterArea) {
        recentFilterArea.classList.remove('filter-open')
      }
    })

    return {
      isShow,
      menuList,
      subMenuInfo,
      noteInfo,
      noteType,
      goPage,
      changeMenu,
      isBrdUser,
      checkSubMenu,
      currentPath,
    }
  }
}
</script>

<style scoped>
  .menu-toggle__switch--input[type=checkbox]:checked { left: 2.5rem; }
</style>