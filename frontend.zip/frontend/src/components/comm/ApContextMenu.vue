<template>
  <context-menu v-model:show="isShow" :options="contextMenu">
    <context-menu-item label="남은 향량 자동계산" @click="onContextMenuItemClick('Item1')" />
    <context-menu-item label="자동계산 삭제" @click="onContextMenuItemClick('Item1')" />
    <context-menu-item label="그룹추가" @click="onContextMenuItemClick('Item1')" />
    <context-menu-item label="위로 이동" @click="onContextMenuItemClick('Item1')" />
    <context-menu-item label="아래로 이동" @click="onContextMenuItemClick('Item1')" />

    <!-- <context-menu-item label="Item with a icon" icon="icon-reload-1" @click="alertContextMenuItemClicked('Item2')" />
      <context-menu-item label="Test item dynamic show and hide" :clickClose="false" @click="showItem = !showItem" />
      <context-menu-item v-if="showItem" label="Click the item above to show/hide me" />
      <context-menu-sperator v-if="showItem" />
      <context-menu-item :label="itemText" :clickClose="false" @click="changeLabelText" />
      <context-menu-group label="Menu with child">
        <context-menu-item label="Item1" @click="alertContextMenuItemClicked('Item1-1')" />
        <context-menu-item label="Item1" @click="alertContextMenuItemClicked('Item1-2')" />
      </context-menu-group>
      <context-menu-group label="Menu with child child child">
        <context-menu-item label="Item1" @click="alertContextMenuItemClicked('Item2-1')" />
        <context-menu-sperator />
        <context-menu-group label="Child with v-for 50">
          <context-menu-item v-for="index of 50" :key="index" :label="'Item3-' + index"
            @click="alertContextMenuItemClicked('Item2-3-' + index)" />
        </context-menu-group>
        <context-menu-group label="Childs">
          <context-menu-item label="Item1-1" @click="alertContextMenuItemClicked('Item3-1-1')" />
          <context-menu-item label="Item1-2" @click="alertContextMenuItemClicked('Item3-1-2')" />
          <context-menu-sperator />
          <context-menu-group label="Childs">
            <context-menu-item label="Item2-1" @click="alertContextMenuItemClicked('Item3-2-1')" />
            <context-menu-item label="Item2-2" @click="alertContextMenuItemClicked('Item3-2-2')" />
          </context-menu-group>
        </context-menu-group>
      </context-menu-group> -->
  </context-menu>
</template>

<script>
import { defineAsyncComponent, ref, reactive, inject, watch, onUpdated } from 'vue'

export default {
  name: 'ApContextMenu',
  props: {
    value: {
      type: Boolean,
      default: false
    },
    options: {
      type: Object,
      default: () => {
        return {
          show: false,
          zIndex: 3,
          minWidth: 230,
          x: 500,
          y: 200,
        }
      }
    }
  },
  emits: ['update:value', 'input', 'change'],
  setup(props, context) {
    const isShow = ref(props.value)
    const contextMenu = ref(props.options)

    watch(() => props.value, (o) => {
      isShow.value = o
    })

    const onContextMenuItemClick = (e) => {
      context.emit('update:value', false)
    }

    onUpdated(() => {
      const contextMenuWrap = document.querySelector('.mx-context-menu-items')
      if(contextMenuWrap) {
        const items = contextMenuWrap.querySelectorAll('.mx-item-row')
        for (let i = 0; i < items.length; i++) {
          const sapn = items[i].querySelector('.label')
          if(sapn) {
            sapn.style.padding = '5px 0px 5px 0px'
          }
        }
      }
    })

    return {
      isShow,
      contextMenu,
      onContextMenuItemClick,
    }
  }
}
</script>
