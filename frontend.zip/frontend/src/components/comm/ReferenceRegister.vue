<template>
  <div class="arrordion-item is-active">
    <div class="arrordion-header">
      <div class="arrordion-title">참조처</div>
    </div>
    <div class="arrordion-body">
      <div class="ui-table__contents--tr ui-table__contents--tr__height--auto">
        <div class="ui-table__contents--th ui-table__contents--th__width--95">
          참조 지정
        </div>
        <div class="ui-table__contents--td">
          <div>
            <div class="search-form">
              <div class="search-form__inner">
                <ap-input
                  v-model:value="searchUserKeyword"
                  class="ui-input__width--468"
                  placeholder="검색어를 검색해주세요."
                  @keypress-enter="fnSearchOrg(searchUserKeyword)"
                  @input="searchAreaReset()"
                >
                </ap-input>
                <button type="button" class="button-search" @click="fnSearchOrg(searchUserKeyword)">검색</button>
              </div>
            </div>
            <div class="cont-input-scroll-area" :class="showArea ? '' : ' hide'">
              <ul class="cont-input-scroll-list">
                <template v-if="orgAllList && orgAllList.length > 0">
                  <li class="cont-input-scroll-item" v-for="(vo, idx) in orgAllList" :key="'user_' + idx">
                    <p class="cont-input-scroll-tit">[{{ vo.vFlagRecNm }}] {{ vo.vRefNm }}</p>
                    <button type="button" class="ui-button ui-button__height--28 ui-button__bg--blue" @click="selectRefTarget(vo)">{{ t('common.label.select') }}</button>
                  </li>
                </template>
                <template v-else>
                  <li class="cont-input-scroll-item t-center">
                    {{ t('common.msg.no_data') }}
                  </li>
                </template>
              </ul>
            </div>
          </div>
        </div>
        
      </div>
      <div class="mt-15">
        <table class="ui-table__reset ui-table__ver ui-table__td--40 text-center">
          <colgroup>
            <col style="width:19rem">
            <col style="width:auto">
            <col style="width:27rem">
          </colgroup>
          <tbody>
            <tr v-for="(vo, idx) in referenceList" :key="'ref_' + idx">
              <th>{{ vo.vFlagRecNm }}</th>
              <td>
                <div class="reference-wrap">
                  <div class="referrer">{{ vo.vRefNm }}</div>
                  <div class="ui-buttons ui-buttons__order">
                    <button type="button" class="ui-button ui-button__circle ui-button__close" @click="fnRefDelete(idx)"></button>
                  </div>
                </div>
              </td>
              <td :rowspan="referenceList.length" class="text-center" v-if="idx === 0">
                <span class="color-blue font-weight__600">{{ referenceList.length }}</span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script>
import { inject, ref, watch } from 'vue'
import { useApproval } from '@/compositions/approval/useApproval'
import { useComm } from '@/compositions/useComm'

export default {
  name: 'ReferenceRegister',
  props: {
    defaultList: {
      type: Array,
      default: () => {
        return []
      }
    },
    recordId: {
      type: String,
      default: ''
    }
  },
  setup (props) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')

    const {
      referenceList,
      findReferenceList
    } = useApproval()

    const {
      findOrgAllList,
      orgAllList
    } = useComm()

    const searchUserKeyword = ref('')
    const showArea = ref(false)

    const fnSearchOrg = async (keyword) => {
      if (!keyword) {
        openAsyncAlert({ message: t('common.msg.search_msg') })
        showArea.value = false
        return
      }

      if (keyword.length < 2) {
        openAsyncAlert({ message: '두 글자 이상 입력해 주세요.'})
        showArea.value = false
        return
      }

      await findOrgAllList(keyword)
      if (orgAllList.value.length === 1) {
        selectRefTarget(orgAllList.value[0])
      } else {
        showArea.value = true
      }
    }

    const selectRefTarget = (item) => {
      referenceList.value.push(item)
      searchUserKeyword.value = ''
      showArea.value = false
    }

    const searchAreaReset = () => {
      if (commonUtils.isEmpty(searchUserKeyword.value)) {
        showArea.value = false
      }
    }

    const fnRefDelete = (idx) => {
      referenceList.value.splice(idx, 1)
    }

    const init = async () => {
      if (commonUtils.isNotEmpty(props.recordId)) {
        await findReferenceList(props.recordId)
      }
    
      if (props.defaultList && props.defaultList.length > 0) {
        referenceList.value = [ ...props.defaultList ]
      }
    }

    init()

    watch(() => props.defaultList, (newVal) => {
      if (newVal) {
        referenceList.value = [ ...newVal ]
      }
    })

    return {
      t,
      referenceList,
      orgAllList,
      searchUserKeyword,
      showArea,
      fnSearchOrg,
      selectRefTarget,
      fnRefDelete,
      searchAreaReset,
    }
  }
}
</script>