<template>
  <date-picker mode="date" v-model="calData.date" :popover="{ visibility: 'click', placement: position }" :select-attribute="fnDefaultDate">
    <template v-slot="{ inputValue, inputEvents }">
      <div style="position:relative; display: inline-block;">
        <input
          :class="['flatpickr-input ui-input ui-input__date', inputClass]"
          :value="inputValue"
          v-on="inputEvents"
          @input="input"
          :disabled="disabled"
          :readonly="readOnly"
        />
        <div class="dp__icon dp__clear_icon dp__input_icons" @click="fnClearDate()"></div>
      </div>
    </template>
  </date-picker>
</template>

<script>
import { reactive, inject, watch } from 'vue'

export default {
  name: 'ApDatePicker',
  props: {
    date: String,
    withTime: { type: Boolean, default: false },
    inputClass: { type: [String, Array], default: '' },
    disabled: { type: Boolean, default: false },
    readOnly: { type: Boolean, default: false },
    position: { type: String, default: 'bottom-start' }
  },
  emits: ['update:date'],
  setup (props, context) {
    const commonUtils = inject('commonUtils')
    const calData = reactive({
      date: null,
      dateString: ''
    })

    const fnClearDate = () => {
      calData.date = null
      calData.dateString = ''
      context.emit('update:date', '')
    }

    if (props.date) {
      calData.date = props.withTime ? 
                    commonUtils.convertStrToDateTime(commonUtils.changeStrDatePattern(props.date, '.', 'Y'))
                     : commonUtils.convertStrToDate(commonUtils.changeStrDatePattern(props.date))
    }

    watch(() => props.date, (newVal, oldVal) => {
      if (newVal && calData.dateString !== newVal) {
        calData.date = props.withTime ? commonUtils.convertStrToDateTime(newVal) : commonUtils.convertStrToDate(newVal)
        calData.dateString = newVal
      }
    })

    watch(() => calData.date, (newVal, oldVal) => {
      if (newVal) {
        const date = props.withTime ? commonUtils.convertDateTimeToStr(newVal) : commonUtils.convertDateToStr(newVal)
        if (props.date !== date) {
          context.emit('update:date', date)
        }
      }
    })

    return {
      calData,
      fnClearDate,
    }
  }
}
</script>
