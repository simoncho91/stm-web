<template>
  <footer id="footer">
  </footer>
</template>

<script>
import { inject, ref } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useStore } from 'vuex'

export default {
  name: 'FooterTemplate',
  setup() {
    const t = inject('t')
    const store = useStore()
    const langCd = store.getters.getLangCd()
    const { openAsyncPopup } = useActions(['openAsyncPopup'])
    const popupContent = ref(null)

    const fnOpenPopup = (compNm, width, popupId) => {
      popupContent.value = compNm

      openAsyncPopup({ minWidth: width ?? 600, popupId: 'privacy-policy-popup' })
        .then(res => {})
        .catch(err => {
          console.log(err)
        })
        .finally(() => {
          popupContent.value = null
        })
    }

    return {
      t,
      langCd,
      popupContent,
      fnOpenPopup
    }
  }
}
</script>

<style>
</style>