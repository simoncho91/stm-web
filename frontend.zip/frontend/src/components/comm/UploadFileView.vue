<template>
  <div class="file-upload">
    <div class="file-upload__inner">
      <ul class="ui-list file-upload__lists">
        <li v-for="(vo, idx) in fileList" :key="'down_' + idx" class="file-upload__list">
          <span class="file-upload__name" @click="downloadFile(vo)">
            <img v-if="isImgThumb" :src="vo.vS3Url" style="width: 80px; height: 80px;" />
            <template v-else>{{ vo.vAttachnm }}</template>
          </span>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import { ref, watch, inject } from 'vue'
import { useUploadFile } from '@/compositions/useUploadFile'

export default {
  name: 'UploadFileView',
  props: {
    uploadid: {
      type: String,
      required: true
    },
    recordid: {
      type: String,
      required: true
    },
    isImgThumb: {
      type: Boolean,
      default: false
    },
  },
  setup(props) {
    const fileList = ref([])
    const t = inject('t')

    const {
      findCommAttachList,
      downloadFile
    } = useUploadFile()

    const init = async () => {
      const payload = {
        vRecordid: props.recordid,
        vUploadid: props.uploadid
      }

      fileList.value = await findCommAttachList(payload)
    }

    init()

    watch(() => props.recordid, (newValue) => {
      if (newValue) {
        init()
      }
    })

    return {
      t,
      fileList,
      downloadFile
    }
  }
}
</script>

<style scoped>
.file-upload__list {
  cursor: pointer;
}
</style>