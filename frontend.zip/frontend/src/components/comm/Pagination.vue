<template>
  <div class="pagination" v-if="pageInfo.totalPageCnt && pageInfo.totalPageCnt > 0">
    <div class="pagination__inner">
      <a href="#" @click.prevent="fnPageNum((pageInfo.nowPageNo-1))" class="paging paging-prev" title="첫 페이지로" ></a>
      <template v-for="idx in pagingCnt()" :key="idx">
        <a href="#" :class="[idx === pageInfo.nowPageNo ? 'is-active' : '']" @click.prevent="fnPageNum(idx)" class="paging" :title="idx">{{ idx }}</a>
      </template>
      <a href="#" @click.prevent="fnPageNum((pageInfo.nowPageNo+1))" class="paging paging-next" title="다음 페이지로"></a>
    </div>
  </div>
</template>

<script>
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'PaginationView',
  props: {
    pageInfo: {
      type: Object,
      default: null
    }
  },
  emits: ['click'],
  setup(props, context) {
    const { openAsyncAlert } = useActions(['openAsyncAlert'])

    function pagingCnt(){
      const list = []
      const startPage = props.pageInfo.startPage
      const endPage = props.pageInfo.endPage
      for (let i = startPage; i <= endPage; i ++){
        list.push(i);
      }
      return list;
    }

    function fnPageNum (pageNum){
      const totalPageCnt = props.pageInfo.totalPageCnt
      if(pageNum < 1){
        openAsyncAlert({ message: '앞 페이지는 없습니다.' })
        return
      }

      if(pageNum > totalPageCnt){
        openAsyncAlert({ message: '뒷 페이지는 없습니다.' })
        return
      }

      context.emit('click',pageNum);
    }

    return {
      pagingCnt,
      fnPageNum
    }
  },
}
</script>