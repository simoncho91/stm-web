<template>
  <div class="right-menu__tab--body-inner">
    <div class="material-right__status">
      <div class="material-right__status--inner">
        <div class="material-right__status--title">Status ({{ vVersionTxt }})</div>
        <div class="material-status__accordion">
          <div class="material-status__accordion--inner">
            <template v-if="lotList && lotList.length > 0">
              <div
                class="material-status__accordion--item right-lot-area"
                v-for="(lot, index) in lotList" :key="'status_lot_' + index"
                :class="lot.isActive ? 'is-active' : ''"
              >
                <div class="material-status__accordion--header">
                  <div class="ui-checkbox__list">
                    <div class="ui-checkbox__inner">
                      <ap-input-check
                        v-model:model="lot.vFlagExposure"
                        value="Y"
                        false-value="N"
                        :label="lot.vLotNm"
                        :disabled="lot.vLotCd.indexOf('tmp_lot_') > -1"
                        :id="`lot_hide_${lot.vLotCd}_${index}`"
                        @click="fnSaveFlagExposure(lot)"
                      >
                      </ap-input-check>
                    </div>
                  </div>
                  <div class="lot-dots">
                    <div class="lot-dots__inner">
                      <template v-if="commonUtils.isNotEmpty(lot.nStepNo) && lot.nStepNo > 0">
                        <span :class="'lot-dot lot-dot__step' + stepNo" v-for="stepNo in lot.nStepNo" :key="lot.vLotCd + 'step_' + stepNo"></span>
                      </template>
                    </div>
                  </div>
                  <div class="material-status__buttons">
                    <button
                      type="button"
                      class="material-status__button material-status__button--marketing"
                      :class="lot.vFlagSend === 'Y' ? 'is-active' : ''"
                      @click="fnSaveFlagSend(lot)"
                    >
                      마케팅 송부
                    </button>
                    <button
                      type="button"
                      class="material-status__button material-status__button--hide"
                      :class="lot.vFlagComplete === 'Y' ? 'is-active': ''"  
                    ></button>
                    <button
                      type="button"
                      class="material-status__button"
                      :class="lot.statusList && lot.statusList.length > 0 ? 'material-status__button--slide' : 'btn-disabled'"
                      :disabled="!lot.statusList || lot.statusList.length === 0"
                      @click="fnToggleStatusDetail(lot)"
                    ></button>
                  </div>
                </div>
                <div class="material-status__accordion--body">
                  <ul class="ui-list material-status__lists" v-if="lot.statusList && lot.statusList.length > 0">
                    <li class="material-status__list" v-for="(status, idx) in lot.statusList" :key="lot.vLotCd + 'status_' + idx">
                      <span v-html="commonUtils.removeXSS(status.vMessage)"></span>
                      <span class="material-status__date">{{ commonUtils.changeStrDatePattern(status.vRegDtm) }}</span>
                      <button type="button"
                        class="material-status__button material-status__button--clear"
                        v-if="lot.decideCancelIndex === idx && showDecideCancelBtn(lot)"
                        @click="fnFormulaDecideCancel(lot)"
                      >해제</button>
                    </li>
                  </ul>
                </div>
              </div>
            </template>
            <!-- end : material-status__accordion--item -->
            
          </div>
          <!-- end : material-status__accordion--inner -->

        </div>
        <!-- end : material-status__accordion -->

      </div>
    </div>
  </div>
</template>

<script>
import { computed, ref, inject, watch } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useStore } from 'vuex'
import { useRoute } from 'vue-router'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'

export default {
  name: 'RightMenuStatus',
  setup () {
    const commonUtils = inject('commonUtils')
    const store = useStore()
    const route = useRoute()
    const { openAsyncConfirm, openAsyncAlert } = useActions(['openAsyncConfirm', 'openAsyncAlert'])
    const lotList = computed(() => store.getters.getNoteLotList().list)
    const vVersionTxt = computed(() => store.getters.getNoteLotList().vVersionTxt)
    const lotStatusList = ref(null)
    const noteInfo = computed(() => store.getters.getNoteInfo())

    const {
      selectLotStatusList,
      updateLotFlagSend,
      updateLotFlagExposure,
      updateDecideCancel,
      noteType,
    } = useLabCommon()

    const fnToggleStatusDetail = (lot) => {
      lot.isActive = !lot.isActive
    }

    const fnSaveFlagSend = (lot) => {
      const flagSend = lot.vFlagSend || ''
      lot.vFlagSend = flagSend === 'Y' ? '' : 'Y'

      updateLotFlagSend({ vLotCd: lot.vLotCd, vFlagSend: lot.vFlagSend })
      store.dispatch('setNoteLotList', { list: lotList.value })
    }

    const fnSaveFlagExposure = (lot) => {
      const lotInfo = {
        list: lotList.value,
        vLotCd: lot.vLotCd,
        vFlagExposure: lot.vFlagExposure,
      }

      updateLotFlagExposure(lotInfo)
      store.dispatch('setNoteLotList', lotInfo)
    }

    const showDecideCancelBtn = (lot) => {
      let isVisible = false
      if (noteInfo.value.vStatusCd !== 'LNC06_51' && lot.vFlagDecide === 'Y') {
        isVisible = true
      }

      return isVisible
    }

    const fnFormulaDecideCancel = async (lot) => {
      let message = '<span class="txt_blue f-weight-700">[확정해제]시 Pilot 승인 단계로 돌아가며<br>'
                  + 'Lot 추가 시-Pilot 승인/전성분 승인,<br>'
                  + '기존 Lot (Pilot 승인) 사용 시-전성분 승인을 재수행해야 합니다.</span><br>'
                  + '<span class="txt_red f-weight-700">SCM등 유관부서와 논의 후 진행하시기 바랍니다.</span><br><br>'
                  + '확정해제 하시겠습니까?'

      if (await openAsyncConfirm({ message })) {
        const payload = {
          vNoteType: noteType,
          vLabNoteCd: noteInfo.value.vLabNoteCd,
          vContPkCd: lot.vContPkCd,
          nVersion: lot.nVersion,
          vLotCd: lot.vLotCd,
        }

        const result = await updateDecideCancel(payload)
        if (result && result === 'SUCC') {
          await openAsyncAlert({ message: '확정해제 완료하였습니다.'})
          lot.vFlagDecide = 'N'
          lot.nStepNo = 2
          lot.vTumnTsntLotStCd = 'LOT_02'

          store.dispatch('setNoteLotList', { list: lotList.value, vLotCd: lot.vLotCd, vFlagDecide : 'N' })
        }
      }
    }

    const fnSetLotStatusList = () => {
      if (route.query.vLabNoteCd) {
        
        lotList.value.forEach(lot => {
          let stepNo = 0
          if (commonUtils.isNotEmpty(lot.vTumnTsntLotStCd)) {
            stepNo = noteType === 'SC' ? Number(lot.vTumnTsntLotStCd.replace('LOT_', '')) : Number(lot.vTumnTsntLotStCd.replace('LOT_', '')) - 1
          }

          lot.nStepNo = stepNo
          lot.isActive = false
          lot.decideCancelIndex = -1

          if (lotStatusList.value && lotStatusList.value.length > 0) {
            lot.statusList = lotStatusList.value.filter(status => status.vLotCd === lot.vLotCd)
            const decideLastIdx = lot.statusList.findLastIndex(type => type.vAlrTypeCd === 'AL_NOTE12_11')
            lot.decideCancelIndex = decideLastIdx
          }
        })
      }
    }

    const init = async () => {
      if (route.query.vLabNoteCd) {
        lotStatusList.value = await selectLotStatusList({ vLabNoteCd: route.query.vLabNoteCd })
      }
      fnSetLotStatusList()
    }

    init()

    watch(() => lotList.value, (newVal) => {
      if (newVal && newVal.length > 0) {
        fnSetLotStatusList()
      }
    })
    
    return {
      commonUtils,
      lotList,
      vVersionTxt,
      lotStatusList,
      fnToggleStatusDetail,
      fnSaveFlagSend,
      fnSaveFlagExposure,
      showDecideCancelBtn,
      fnFormulaDecideCancel,
    }
  }
}
</script>