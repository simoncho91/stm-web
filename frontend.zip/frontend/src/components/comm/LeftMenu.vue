<template>
  <ul class="ui-list left-menu__lists" v-if="menuList && menuList.length > 0">
    <template v-for="(item, index) in menuList" :key="'menu_' + index">
      <li v-if="item.vPageUrl && item.vPageUrl.indexOf('MyBoard') > -1"
        :class="['left-menu__list left-menu__lists--' + item.vCssnm, 
                currentMenuid === item.vMenuid ? ' is-active' : '']"
      >
        <a href="#" class="left-menu__link" @click.prevent="goPage(item)">
          <i :class="'left-menu__icon left-menu__icon--' + item.vCssnm"></i>
          <span class="left-menu__text">{{ item.vMenunm }}</span>
          <span class="left-menu__tooltip">{{ item.vMenunm }}</span>
        </a>
      </li>
    </template>

    <li
      class="left-menu__list is-filter is-filter__open border-top pt-10"
       v-if="recentLogList && recentLogList.length > 0"
    >
      <a href="#" class="left-menu__link">
        <i class="left-menu__icon left-menu__icon--myLabNotes"></i>
        <span class="left-menu__text">recent notes</span>
        <span class="left-menu__tooltip">recent notes</span>
        <button type="button" class="button-filter__show"></button>
      </a>

      <ul class="ui-list filter-lists filter-open" id="recent-filter-area">
        <li class="filter-list" v-for="(vo, idx) in recentLogList" :key="'recent_log' + idx">
          <a href="#" class='recent-link ui-tooltip__parent' @click="goRecentDetail(vo)">
            {{ vo.vContCd }}
            <span v-if="commonUtils.isNotEmpty(vo.vContNm)" class="ui-tooltip ui-tooltip__top">
              <span class="ui-tooltip__inner">{{ vo.vContNm }}</span>
            </span>
          </a>
          <button type="button" class="filter-button__close" @click="fnDeleteRecentNote(vo)"></button>
        </li>
      </ul>
    </li>
    <template v-for="(item, index) in menuList" :key="'menu_' + index">
      <li v-if="item.vPageUrl && item.vPageUrl.indexOf('MyBoard') === -1"
        :class="['left-menu__list left-menu__lists--' + item.vCssnm, 
        currentMenuid === item.vMenuid ? ' is-active' : '',
        item.vCssnm === 'labNotes' || item.vCssnm === 'discussionLab' ? 'border-top pt-10' : '']"
      >
        <a href="#" class="left-menu__link" @click.prevent="goPage(item)">
          <i :class="'left-menu__icon left-menu__icon--' + item.vCssnm"></i>
          <span class="left-menu__text">{{ item.vMenunm }}</span>
          <span class="left-menu__tooltip">{{ item.vMenunm }}</span>
        </a>
      </li>
    </template>
  </ul>
</template>

<script>
import { onMounted, computed, ref, watch, inject } from 'vue'
import { useStore } from 'vuex'
import { useRoute, useRouter } from 'vue-router'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'

import uiUtils from '@/utils/uiUtils'

export default {
  name: 'LeftMenu',
  setup () {
    const store = useStore()
    const route = useRoute()
    const router = useRouter()
    const commonUtils = inject('commonUtils')

    const menuList = computed(() => store.getters.getRouter())
    const recentLogList = computed(() => store.getters.getRecentLogList(store.getters.getNoteType()))

    const currentMenuid = ref(route.meta.menuid)

    const {
      fnSetRecentLog,
    } = useLabCommon()

    const goPage = (item) => {
      router.push({ path: item.vPageid })
    }

    const goRecentDetail = async (item) => {
      const noteTypeNm = store.getters.getNoteTypeNm()
      if (commonUtils.isNotEmpty(item.vContCd)) {
        await fnSetRecentLog(item)
      }
      window.location.href = `/${noteTypeNm}/all-lab-note-${item.vPageType}-view?vLabNoteCd=${item.vLabNoteCd}`
    }

    const fnDeleteRecentNote = (item) => {
      const noteType = store.getters.getNoteType()

      const data = {
        vNoteType: noteType,
        vLabNoteCd: item.vLabNoteCd,
      }

      store.dispatch('deleteNoteRecentLogCont', data)
    }

    watch(() => route.meta.menuid, (newVal) => {
      if (newVal) {
        currentMenuid.value = newVal
      }
    })

    onMounted(() => {
      uiUtils.leftMenuOpenEvent()
    })

    return {
      commonUtils,
      menuList,
      recentLogList,
      currentMenuid,
      goPage,
      goRecentDetail,
      fnDeleteRecentNote,
    }
  }
}
</script>

<style scoped>
  .recent-link {
    color: #848b98;
  }
</style>