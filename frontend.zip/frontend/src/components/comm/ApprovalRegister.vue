<template>
  <div>
    <div class="arrordion-item is-active">
      <div class="arrordion-header">
        <div class="arrordion-title">결재선 지정</div>
      </div>
      <div class="arrordion-body">
        <div class="ui-table__contents--tr ui-table__contents--tr__height--auto">
          <div class="ui-table__contents--th ui-table__contents--th__width--95">
            결재선 지정
          </div>
          <div class="ui-table__contents--td">
            <div>
              <div class="search-form">
                <div class="search-form__inner">
                  <ap-input
                    v-model:value="searchUserKeyword"
                    class="ui-input__width--468"
                    placeholder="검색어를 검색해주세요."
                    @keypress-enter="fnSearchUser(searchUserKeyword)"
                    @input="searchAreaReset()"
                    id="apprSearchUser"
                    :is-auto-focus="isAutoFocus"
                  >
                  </ap-input>
                  <button type="button" class="button-search" @click="fnSearchUser(searchUserKeyword)">검색</button>
                </div>
              </div>
  
              <div class="cont-input-scroll-area" :class="showArea ? '' : ' hide'">
                <ul class="cont-input-scroll-list">
                  <template v-if="userList && userList.length > 0">
                    <li class="cont-input-scroll-item" v-for="(vo, idx) in userList" :key="'user_' + idx">
                      <p class="cont-input-scroll-tit">{{ vo.vUsernm }} ({{ vo.vDeptnm }}) / {{ vo.vEmail }}</p>
                      <button type="button" class="ui-button ui-button__height--28 ui-button__bg--blue" @click="selectApprUser(vo)">{{ t('common.label.select') }}</button>
                    </li>
                  </template>
                  <template v-else>
                    <li class="cont-input-scroll-item t-center">
                      {{ t('common.msg.no_data') }}
                    </li>
                  </template>
                </ul>
              </div>
            </div>
          </div>
        </div>
  
        <div class="note-table mt-15">
          <div class="note-table__inner">
            <table class="ui-table ui-table__td--40 text-center">
              <colgroup>
                <col style="width:20%">
                <col style="width:20%">
                <col style="width:20%">
                <col style="width:20%">
                <col style="width:20%">
              </colgroup>
              <thead>
                <tr>
                  <th>결재의뢰</th>
                  <th>{{ apprInfo.vDraftUsernm }}</th>
                  <th>{{ apprInfo.vDraftDeptnm }}</th>
                  <th>{{ apprInfo.vDraftPositnm }}</th>
                  <th></th>
                </tr>
              </thead>
              <tbody v-if="apprList && apprList.length > 0">
                <tr v-for="(vo, idx) in apprList" :key="'appr_' + idx">
                  <td>
                    <div class="ui-checkbox-block">
                      <input
                        type="checkbox"
                        class="ui-checkbox"
                        :id="'chk_appr_' + idx"
                        v-model="vo.vApprUserType"
                        true-value="USR020"
                        false-value="USR010"
                        @change="changeApprType($event, idx)"
                      />
                      <label :for="'chk_appr_' + idx" class="ui-label">
                        <span class="ui-checkbox-object"></span>
                        <span class="ui-label__text">{{ vo.vApprUserType === 'USR010' ? t('common.label.approval.appr_user_type01') : t('common.label.approval.appr_user_type02')}}</span>
                      </label>
                    </div>
                  </td>
                  <td>{{ vo.vApprUserNm }}</td>
                  <td>{{ vo.vApprDeptnm }}</td>
                  <td>{{ vo.vApprPositnm }}</td>
                  <td>
                    <div class="ui-buttons ui-buttons__order ui-buttons__center">
                      <button type="button" class="ui-button ui-button__circle ui-button__arrow--top" @click="fnApprUserUp(vo, idx)"></button>
                      <button type="button" class="ui-button ui-button__circle ui-button__arrow--bottom" @click="fnApprUserDown(vo, idx)"></button>
                      <button type="button" class="ui-button ui-button__circle ui-button__close" @click="fnApprUserDelete(idx)"></button>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <teleport to="#common-modal" v-if="popupContent">
      <ap-popup>
        <component
          :is="popupContent"
          :pop-params="popParams"
          @callbackFunc="popSelectFunc"
        />
      </ap-popup>
    </teleport>
  </div>
</template>

<script>
import { defineAsyncComponent, inject, ref, watch } from 'vue'
import { useApproval } from '@/compositions/approval/useApproval'
import { useComm } from '@/compositions/useComm'
import { useActions } from 'vuex-composition-helpers'
import { useStore } from 'vuex'

export default {
  name: 'ApprovalRegister',
  props: {
    defaultList: {
      type: Array,
      default: () => {
        return []
      }
    },
    apprCd: {
      type: String,
      default: ''
    },
    apprClass: {
      type: String,
      default: ''
    },
    isAutoFocus: {
      type: Boolean,
      default: false
    },
  },
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    OpinionApprReqPop: defineAsyncComponent(() => import('@/components/approval/popup/OpinionApprReqPop.vue'))
  },
  emits: ['callbackFunc'],
  setup (props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert } = useActions(['openAsyncAlert'])
    const store = useStore()
    const myInfo = store.getters.getMyInfo()
    const {
      apprInfo,
      apprList,
      findApprovalInfo,
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      fnClosePopup,
    } = useApproval()

    const {
      selectUserList,
      userList
    } = useComm()

    const searchUserKeyword = ref('')
    const showArea = ref(false)

    const changeApprType = (e, idx) => {
      const apprLen = apprList.value.length

      if (e.target.checked && apprLen === (idx + 1)) {
        openAsyncAlert({ message: t('common.msg.appr_msg01') })
        e.target.checked = false
        apprList.value[idx].vApprUserType = 'USR010'
      }
    }

    const fnSearchUser = async (keyword) => {
      if (!keyword) {
        openAsyncAlert({ message: t('common.msg.search_msg') })
        showArea.value = false
        return
      }

      if (keyword.length < 2) {
        openAsyncAlert({ message: '두 글자 이상 입력해 주세요.'})
        showArea.value = false
        return
      }

      await selectUserList(keyword)

      if (userList.value.length === 1) {
        selectApprUser(userList.value[0])
      } else {
        showArea.value = true
      }
    }

    const selectApprUser = (item) => {
      const selectUser = apprList.value.filter(vo => vo.vApprUserid === item.userId)

      if (selectUser != undefined && selectUser.length > 0) {
        openAsyncAlert({ message: t('common.msg.already_select') })
        return
      }

      const apprUserInfo = {
        vApprDeptnm: item.vDeptnm,
        vApprDutynm: item.vDutynm,
        vApprPhoneno: item.vPhoneno,
        vApprPositnm: item.vPositnm,
        vApprUserNm: item.vUsernm,
        vApprUserType: 'USR010',
        vApprUserid: item.vUserid
      }

      apprList.value.push(apprUserInfo)

      searchUserKeyword.value = ''
      showArea.value = false
    }

    const fnApprUserUp = (item, idx) => {
      if (idx === 0) {
        return
      }

      const changeIdx = idx - 1
      const beforeInfo = apprList.value[changeIdx]
      if (idx === (apprList.value.length - 1) && beforeInfo.vApprUserType === 'USR020') {
        openAsyncAlert({ message: '최종결재자와 합의 하실 수 없습니다.' })
        return
      }

      apprList.value.splice(idx, 1)
      apprList.value.splice(changeIdx, 0, item)
    }

    const fnApprUserDown = (item, idx) => {
      if (idx === (apprList.value.length - 1)) {
        return
      }

      const changeIdx = idx + 1
      if (changeIdx === (apprList.value.length - 1) && item.vApprUserType === 'USR020') {
        openAsyncAlert({ message: '최종결재자와 합의 하실 수 없습니다.' })
        return
      }

      apprList.value.splice(idx, 1)
      apprList.value.splice(changeIdx, 0, item)
    }

    const fnApprUserDelete = (idx) => {
      apprList.value.splice(idx, 1)
    }

    const fnApprovalSaveCheck = () => {
      let isOk = true
      if (apprList.value.length === 0) {
        isOk = false
      }

      if (!isOk) {
        openAsyncAlert({ message: '결재자가 지정되지 않았습니다.' })
        return
      }

      return isOk
    }

    const fnApprovalOpinionPop = () => {
      if (!fnApprovalSaveCheck()) {
        return
      }

      popSelectFunc.value = fnApprovalResult
      fnOpenPopup('OpinionApprReqPop')
    }

    const fnApprovalResult = (item) => {
      context.emit('callbackFunc', item)
      fnClosePopup()
    }

    const searchAreaReset = () => {
      if (commonUtils.isEmpty(searchUserKeyword.value)) {
        showArea.value = false
      }
    }

    const init = async () => {
      if (commonUtils.isNotEmpty(props.apprCd)) {
        await findApprovalInfo(props.apprCd)
      } else {
        const loginInfo = {
          vDraftUsernm: myInfo.userNm,
          vDraftUserid: myInfo.loginId,
          vDraftDeptnm: myInfo.deptNm,
          vDraftPositnm: myInfo.positNm,
          vDraftPhoneno: myInfo.phoneNo,
          vDraftOpinion: '',
          vApprClass: props.apprClass
        }

        apprInfo.value = { ...loginInfo }
      }

      if (props.defaultList && props.defaultList.length > 0) {
        apprList.value = [ ...props.defaultList ]
      }
    }

    init()

    watch(() => props.defaultList, (newVal) => {
      if (newVal) {
        apprList.value = [ ...newVal ]
      }
    })

    return {
      t,
      commonUtils,
      apprInfo,
      apprList,
      userList,
      searchUserKeyword,
      showArea,
      changeApprType,
      fnSearchUser,
      selectApprUser,
      fnApprUserUp,
      fnApprUserDown,
      fnApprUserDelete,
      fnApprovalOpinionPop,
      searchAreaReset,
      popupContent,
      popParams,
      popSelectFunc,
    }
  }
}

</script>