<template>
  <div class="right-menu__tab--body-inner">
    <div class="right-menu__schedule">
      <div class="right-menu__schedule--inner">
        <div class="schedule-process">
          <div class="schedule-process__inner">
            <template v-if="scheduleList && scheduleList.length > 0">
              <div 
                  v-for="(vo, idx) in scheduleList"
                  :key="'schd_' + idx"
                  :class="'schedule-process__item ' + vo.vCurrStatMark"
              >
                <div class="schedule-status">
                  <div class="schedule-status__num">{{ idx + 1}}</div>
                </div>
                <div class="schedule-detail">
                  <div class="schedule-title">
                    <div class="schedule-title__text">{{ vo.vStatusNm }}</div>
                    <div class="schedule-title__dday" v-if="showDdayArea(vo)">
                      D{{ commonUtils.calcDday(vo.vSchdStDt, vMassProdDt) }}
                    </div>
                  </div>
                  <div class="schedule-history__item">
                    <ul class="ui-list schedule-history" v-if="vo.scheduleList && vo.scheduleList.length > 0">
                      <li class="schedule-history__list"
                        v-for="(schedule, index) in vo.scheduleList"
                        :key="'schd_' + idx + '_' + index"
                      >
                        <span class="schedule-history__date">{{ commonUtils.changeStrDatePattern(schedule.vSchdStDt)}}</span>
                        <span class="schedule-history__text">{{ schedule.vMessage }}</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </template>
          </div>
        </div>

        <div class="schedule-expect__day"
          v-if="commonUtils.isNotEmpty(vMassProdDt)"
        >
          *출시 예정일: {{ commonUtils.changeStrDateForKorean(vMassProdDt) }}
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { computed, inject, ref } from 'vue'
import { useStore } from 'vuex'
import { useRoute } from 'vue-router'

export default {
  name: 'RightMenuSchedule',
  setup () {
    const commonUtils = inject('commonUtils')
    const store = useStore()
    const noteTypeNm = store.getters.getNoteTypeNm()
    const noteInfo = store.getters.getNoteInfo()
    const vMassProdDt = ref('')
    const route = useRoute()
    const scheduleList = computed(() => store.getters.getNoteScheduleList())

    const showDdayArea = (item) => {
      let isVisible = false

      if (commonUtils.isNotEmpty(vMassProdDt.value) &&
          commonUtils.isNotEmpty(item.vSchdStDt) &&
          item.vCurrStatMark !== 'is-none') {
        isVisible = true
      }

      return isVisible
    }

    const init = async () => {
      const payload = {
        vLabNoteCd: route.query.vLabNoteCd,
        noteTypeNm
      }
      await store.dispatch('selectNoteDetailScheduleList', payload)

      if (commonUtils.isNotEmpty(noteInfo) && commonUtils.isNotEmpty(noteInfo.vMassProdDt)) {
        vMassProdDt.value = noteInfo.vMassProdDt + '01'
      }
    }

    init()

    return {
      commonUtils,
      vMassProdDt,
      scheduleList,
      showDdayArea,
    }
  }
}
</script>