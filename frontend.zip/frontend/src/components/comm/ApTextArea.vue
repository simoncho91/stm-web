<template>
  <textarea
    :id="id"
    :readonly="readOnly"
    :disabled="disabled"
    @input="onInput($event)"
    @click="onClick($event)"
    :cols="cols"
    :rows="rows"
    :class="['ui-textarea', inputClass]"
    :value="value"
    :placeholder="placeholder"
    :spellcheck="false"
  ></textarea>
  <div class="num-characters" v-if="isWithByte">
    <span :class="checkByte > maxlength ? 'txt_red num-characters__now' : 'num-characters__now'"
      :id="'input_byte_' + id"
    >{{ commonUtils.setNumberComma(checkByte) }} /</span>
    {{ commonUtils.setNumberComma(maxlength) }}
  </div>
</template>

<script>
import { inject, ref } from 'vue'
export default {
  name: 'ApTextArea',
  props: {
    id: { type: String, default: '', required: false },
    readOnly: { type: Boolean, default: false, required: false },
    value: { type: String, default: '', required: false },
    maxlength: { type: Number, default: 2000, required: false },
    disabled: { type: Boolean, default: false, required: false },
    placeholder: { type: String, default: '', required: false },
    cols: { type: Number, default: 30, required: false },
    rows: { type: Number, default: 4, required: false },
    inputClass: { type: [String, Array], default: '' },
    isWithByte: { type: Boolean, default: false, required: false }
  },
  emits: ['update:value', 'input', 'click'],
  setup (props, context) {
    const commonUtils = inject('commonUtils')
    const checkByte = ref(0)
    const onInput = (event) => {
      const inputVal = event.target.value
      if (props.isWithByte) {
        checkByte.value = commonUtils.calcByte(inputVal)
      }
      context.emit('update:value', inputVal)
      context.emit('input', inputVal)
    }

    const onClick = (e) => {
      context.emit('click', e)
    }

    const init = () => {
      if (props.isWithByte) {
        checkByte.value = commonUtils.calcByte(props.value)
      }

      if (commonUtils.isEmpty(props.value)) {
        context.emit('update:value', '')
      }
    }

    init()

    return {
      commonUtils,
      onInput,
      onClick,
      checkByte,
      init
    }
  }
}
</script>
