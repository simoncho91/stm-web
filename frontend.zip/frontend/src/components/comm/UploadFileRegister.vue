<template>
  <div class="file-upload">
    <div class="file-upload__inner">
      <div class="file-upload__button">
        <input type="file" ref="uploadFile" multiple @change="fnChangeFile($event)" v-show="false" />
        <button type="button" class="ui-button ui-button__bg--blue font-weight__300" @click="fnSelectFiles()">
          첨부파일
        </button>
      </div>
      <ul class="ui-list file-upload__lists">
        <li v-for="(item, idx) in uploadParams.items" :key="'attach_' + idx" class="file-upload__list">
          <span class="file-upload__name">{{ item.vAttachnm }}</span>
          <button type="button" class="file-upload__button--delete" @click="fnRemoveFiles(idx)"></button>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import { ref, computed, inject, watch } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useUploadFile } from '@/compositions/useUploadFile'

export default {
  name: 'UploadFileRegister',
  props: {
    uploadid: {
      type: String,
      required: true
    },
    parentInfo: {
      type: Object,
      default: null
    },
    disabled: {
      type: Boolean,
      default: false
    },
    uploadCount: {
      type: Number,
      default: 0
    },
    isOnlyImg: {
      type: Boolean,
      default: false
    },
  },
  setup(props, { emit }) {
    const t = inject('t')
    const uploadFile = ref(null)
    let uploadParams = computed(() => props.parentInfo)
    const { openAsyncAlert } = useActions(['openAsyncAlert'])

    const {
      saveCommAttachTemp,
      findCommAttachList
    } = useUploadFile()

    const fnSelectFiles = () => {
      if (props.disabled) {
        return
      }

      if (props.uploadCount !== 0 && props.uploadCount <= uploadParams.value.items.length) {
        openAsyncAlert({ message: t('common.msg.upload_count_msg', { count: props.uploadCount }) })
        return
      }

      uploadFile.value.click()
    }

    const fnChangeFile = async (evt) => {
      const files = evt.target.files
      if (props.uploadCount != 0 && props.uploadCount < files.length) {
        openAsyncAlert({ message: t('common.msg.upload_count_msg', { count: props.uploadCount }) })
        return
      }

      if (props.isOnlyImg) {
        for (let i = 0; i < files.length; i++) {
          if (!files[i].type.startsWith('image/')) {
            openAsyncAlert({ message: '이미지만 등록가능합니다.' })
            return
          }
        }
      }

      await saveCommAttachTemp(evt, props.uploadid, uploadParams.value.items)
    }

    const fnRemoveFiles = async (idx) => {
      uploadParams.value.items.splice(idx, 1)
    }

    const uploadInit = () => {
      if (uploadParams.value.vRecordid) {
        findCommAttachList({ vRecordid: uploadParams.value.vRecordid, vUploadid: props.uploadid })
          .then(items => {
            uploadParams.value.items = items
          })
      }
    }

    uploadInit()

    watch(() => uploadParams.value.vRecordid, (newValue) => {
      if (newValue === '') {
        uploadParams.value.items = []
      } else {
        findCommAttachList({ vRecordid: newValue, vUploadid: props.uploadid })
          .then(items => {
            uploadParams.value.items = items
          })
      }
    })

    return {
      fnSelectFiles,
      fnChangeFile,
      fnRemoveFiles,
      uploadFile,
      uploadParams
    }
  }
}
</script>