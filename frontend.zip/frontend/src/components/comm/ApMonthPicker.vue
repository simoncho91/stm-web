<template>
  <div style="position:relative; display: inline-block;">
    <VueDatePicker
      v-model="calData"
      month-picker
      hide-input-icon
      auto-apply
      :clearable="false"
      :position="position"
      :readonly="readonly"
      :disabled="disabled"
      locale="ko-KR"
      format="yyyy.MM"
      month-name-format="short"
      @closed="changeEvent"
    >
    </VueDatePicker>
    <div class="dp__icon dp__clear_icon dp__input_icons" @click="fnClearDate()"></div>
  </div>
</template>

<script>
import { ref, inject, watch } from 'vue'
import VueDatePicker from '@vuepic/vue-datepicker';
import '@vuepic/vue-datepicker/dist/main.css'
export default {
  name: 'ApMonthPicker',
  props: {
    date: String,
    inputClass: { type: [String, Array], default: '' },
    readonly: { type: Boolean, default: false },
    disabled: { type: Boolean, default: false },
    position: { type: String, default: 'left' },
    separator: { type: String, default: '.'},
  },
  components: {
    VueDatePicker
  },
  emits: ['update:date'],
  setup (props, context) {
    const commonUtils = inject('commonUtils')
    const calData = ref()

    if (props.date) {
      let date = props.date || ''

      if (date.length > 0) {
        if(date.length > 6){
          date = date.substring(0, 6)
        }
        date = commonUtils.parseDate(props.date + '01')
      }

      calData.value = {
        year: date.getFullYear(),
        month: date.getMonth()
      }
    }

    const changeEvent = () => {
      const year = calData.value.year
      const month = Number(calData.value.month  + 1) < 9 ? '0' + Number(calData.value.month  + 1) : Number(calData.value.month  + 1)

      const date = commonUtils.parseDateToStr(new Date(year + '-' + month + '-' + '01'))
      context.emit('update:date', date.substr(0, 6))
    }

    const fnClearDate = () => {
      calData.value = null
      context.emit('update:date', '')
    }

    watch(() => props.date, (newVal) => {
      if (newVal) {
        let date = newVal
        if (newVal.length === 6) {
          date = commonUtils.parseDate(newVal + '01')
        }else if(newVal.length > 6){
          date = commonUtils.parseDate(newVal.substring(0, 6) + '01')
        }

        calData.value = {
          year: date.getFullYear(),
          month: date.getMonth()
        }
      } else {
        calData.value = null
      }
    })

    return {
      calData,
      changeEvent,
      fnClearDate,
    }
  }
}
</script>