<template>
  <div class="modal-content modal-content__width--800">
    <div class="modal-header">
      <div class="modal-title">실험노트 리스트</div>
      <button type="button" class="modal-close" @click="fnClose()"></button>
    </div>
    <div class="modal-body">
      <div class="myboard-table">
        <div class="myboard-table__inner">
          <table class="ui-table ui-table__th--border-radius--0 ui-table__td--40 text-center">
            <colgroup>
              <col style="width:70%">
              <col style="width:15%">
              <col style="width:15%">
            </colgroup>
            <thead>
              <tr>
                <th>파일명</th>
                <th>용량</th>
                <th>등록일</th>
              </tr>
            </thead>
            <tbody>
              <template v-if="fileList && fileList.length > 0">
                <tr v-for="(vo, idx) in fileList" :key="'user_' + idx">
                  <td><span class="file-upload__name" @click="downloadFile(vo)">{{ vo.vAttachnm }}</span></td>
                  <td>{{ commonUtils.getByteSize(vo.nAttachSize) }}</td>
                  <td>{{ commonUtils.changeStrDatePattern(vo.vRegDtm) }}</td>
                </tr>
              </template>
              <template v-else>
                <tr>
                  <td colspan="3">
                    <div class="no-result">
                      {{ t('common.msg.no_data') }}
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>
      <div class="board-bottom ">
        <div class="board-bottom__inner">
          <div class="ui-buttons ml-auto ui-buttons__right">
            <button
              type="button"
              class="ui-button ui-button__bg--lightgray"
              @click="fnClose()"
            >닫기</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, watch, inject } from 'vue'
import { useUploadFile } from '@/compositions/useUploadFile'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'UploadFileListPop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          uploadid: '',
          recordid: '',
        }
      }
    }
  },
  setup (props) {
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])

    const fileList = ref([])
    const t = inject('t')
    const commonUtils = inject('commonUtils')

    const {
      findCommAttachList,
      downloadFile
    } = useUploadFile()

    const fnClose = () => {
      closeAsyncPopup({ message: '' })
    }

    const init = async () => {
      const payload = {
        vRecordid: props.popParams.recordid,
        vUploadid: props.popParams.uploadid
      }

      fileList.value = await findCommAttachList(payload)
    }

    init()

    watch(() => props.recordid, (newValue) => {
      if (newValue) {
        init()
      }
    })

    return {
      t,
      commonUtils,
      fileList,
      downloadFile,
      fnClose,
    }
  }
}
</script>

<style scoped>
  .ui-table tbody tr {
    cursor: pointer;
  }
</style>