<template>
  <div class="modal-content modal-content__width--640">
    <div class="modal-header">
      <div class="modal-title">사용자 검색</div>
      <button type="button" class="modal-close" @click="fnClose()"></button>
    </div>
    <div class="modal-body">
      <div class="board-top">
        <div class="board-flex">
          <div class="board-cell">
            <div class="search-form">
              <div class="search-form__inner">
                <ap-input
                  v-model:value="searchParams.vKeyword"
                  input-class="ui-input ui-input__width--535"
                  placeholder="이름 or 사번"
                  id="vUserSearchPopKeyword"
                  @keypress-enter="fnSearch(1)"
                >
                </ap-input>
                <button 
                  type="button"
                  class="button-search"
                  @click="fnSearch(1)"
                >
                  검색
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="myboard-table">
        <div class="myboard-table__inner">
          <table class="ui-table ui-table__th--border-radius--0 ui-table__td--40 text-center">
            <colgroup>
              <col style="width:10%">
              <col style="width:20%">
              <col style="width:25%">
              <col style="width:38%">
            </colgroup>
            <thead>
              <tr>
                <th>NO</th>
                <th>사번</th>
                <th>이름</th>
                <th>부서</th>
              </tr>
            </thead>
            <tbody>
              <template v-if="list && list.length > 0">
                <tr v-for="(vo, idx) in list" :key="'user_' + idx" @click="fnApply(vo)">
                  <td>{{ page.totalCnt - ((page.pageSize * (page.nowPageNo-1)) + idx)}}</td>
                  <td>{{ vo.vUserid }}</td>
                  <td>{{ vo.vUsernm }}</td>
                  <td class="t-left">{{ vo.vDeptnm }}</td>
                </tr>
              </template>
              <template v-else>
                <tr>
                  <td colspan="4">
                    <div class="no-result">
                      {{ t('common.msg.no_data') }}
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>

        <div class="board-bottom">
          <div class="board-bottom__inner">
            <Pagination
              v-if="list && list.length > 0"
              :page-info="page"
              @click="fnSearch"
            >
            </Pagination>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, inject, reactive, onMounted } from 'vue'
import { useComm } from '@/compositions/useComm'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'UserSearchPop',
  components: {
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue'))
  },
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          searchFlag: 'ALL',
        }
      }
    }
  },
  emits: ['selectFunc', 'closeFunc'],
  setup (props, context) {
    const t = inject('t')
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])
    const {
      page,
      list,
      selectCommUserList,
      selectCommUserDesignationList
    } = useComm()

    const searchParams = reactive({
      vKeyword: props.popParams.vKeyword || '',
      nowPageNo: 1
    })

    const fnSearch = async (pg) => {
      if (!pg) {
        pg = 1
      }

      searchParams.nowPageNo = pg

      if (props.popParams.searchFlag === 'ALL') {
        await selectCommUserList(searchParams)
      } else {
        searchParams.vDeptCd = props.vDeptCd || '10011'
        await selectCommUserDesignationList(searchParams)
      }

      if (list.value && list.value.length === 1) {
        fnApply(list.value[0])
      }
    }

    const fnApply = (item) => {
      context.emit('selectFunc', item)

      fnClose()
    }

    const fnClose = () => {
      if (props.popParams.popType !== 'SUB') {
        closeAsyncPopup({ message: '' })
      } else {
        context.emit('closeFunc')
      }
    }

    const init = () => {
      fnSearch(1)
    }

    init()

    onMounted(() => {
      const input = document.querySelector('#vUserSearchPopKeyword')
      input.focus()
    })

    return {
      t,
      searchParams,
      page,
      list,
      fnSearch,
      fnApply,
      fnClose,
    }
  }
}
</script>

<style scoped>
  .ui-table tbody tr {
    cursor: pointer;
  }
</style>