<template>
  <div class="modal-content" style="width: 80rem;">
    <div class="modal-header">
      <div class="modal-title">보안설정</div>
      <button type="button" class="modal-close" @click="fnClose()"></button>
    </div>
    <div class="modal-body">
      <div class="version-tab__top" style="text-align:left;">
        <ApTab
          mst-id="version-tab"
          :tab-list="tabList"
          @click="getSelectedTabEvent"
          :default-tab="selectedTab"
          :tab-style="['version-tab__top__inner', 'version-tab__top__lists', 'version-tab__top__list', 'version-tab__top__link']"
        >
        </ApTab>
      </div>
      <section class="search-bar p-0 mt-15">
        <h2 class="for-a11y">검색</h2>
        <div class="search-bar__left">
          <div class="search-bar__row">
            <dl class="search-bar__item search-bar__item--width-100">
              <dt class="search-bar__key">검색</dt>
              <dd class="search-bar__val search-bar__val--flex">
                <div class="search-form">
                  <div class="search-form__inner">
                    <ap-input
                      v-model:value="searchKeyword"
                      :placeholder="'부서 or 사용자 or 그룹'"
                      @keypress-enter="fnSearch(searchKeyword)"
                      @input="searchAreaReset(searchKeyword)"
                    >
                    </ap-input>
                    <button type="button" class="button-search" @click="fnSearch(searchKeyword)">검색</button>
                  </div>
                </div>
                <div class="cont-input-scroll-area" :class="showArea ? '' : ' hide'">
                  <ul class="cont-input-scroll-list">
                    <template v-if="deptUsrGrplist && deptUsrGrplist.length > 0">
                      <li class="cont-input-scroll-item" v-for="(vo, idx) in deptUsrGrplist" :key="'user_' + idx">
                        <p class="cont-input-scroll-tit">[{{ vo.vFlagRecNm }}] {{ vo.vAuthnm }}</p>
                        <button type="button" class="ui-button ui-button__height--28 ui-button__bg--blue" @click="selectAuthTarget(vo)">{{ t('common.label.select') }}</button>
                      </li>
                    </template>
                    <template v-else>
                      <li class="cont-input-scroll-item t-center">
                        {{ t('common.msg.no_data') }}
                      </li>
                    </template>
                  </ul>
                </div>
              </dd>
            </dl>
          </div>
        </div>
      </section>

      <div class="mt-15">
        <table class="ui-table__reset ui-table__ver ui-table__td--40 text-center">
          <colgroup>
            <col style="width:19rem">
            <col style="width:auto">
            <col style="width:17rem">
          </colgroup>
          <tbody>
            <template v-if="authSettingList && authSettingList.length > 0">
              <tr v-for="(vo, idx) in authSettingList" :key="'ref_' + idx">
                <th>{{ vo.vFlagRecNm }}</th>
                <td>
                  <div class="reference-wrap">
                    <div class="referrer">{{ vo.vAuthnm }}</div>
                    <div class="ui-buttons ui-buttons__order">
                      <button type="button" class="ui-button ui-button__circle ui-button__close" @click="fnAuthDelete(idx)"></button>
                    </div>
                  </div>
                </td>
                <td :rowspan="authSettingList.length" class="text-center" v-if="idx === 0">
                  <span class="color-blue font-weight__600">{{ authSettingList.length }}</span>
                </td>
              </tr>
            </template>
            <template v-else>
              <tr>
                <td colspan="3" class="text-center">
                  {{ t('common.msg.no_data') }}
                </td>
              </tr>
            </template>
          </tbody>
        </table>
      </div>

      <div class="board-bottom">
        <div class="board-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <div class="mr-20 mt-5" v-if="popParams.vFlagRec != 'AUTH030'">
              <ap-input-check
                id="vIncLowdept"
                v-model:model="vIncLowdept"
                value="Y"
                label="하위부서 포함"
              >
              </ap-input-check>
            </div>
            <button type="button" class="ui-button ui-button__bg--skyblue" @click.prevent="fnSave">보안확정</button>
            <button type="button" class="ui-button ui-button__bg--gray" @click="fnClose">닫기</button>
          </div>
        </div>
      </div>
    </div>
  </div>
 
</template>

<script>
import { ref, inject, defineAsyncComponent } from 'vue'
import { useAuth } from '@/compositions/useAuth'
import { useActions } from 'vuex-composition-helpers'
import { useStore } from 'vuex'

export default {
  name: 'AuthSecurityOrgRegPop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
  },
  emits: ['callbackFunc'],
  setup (props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert, openAsyncConfirm, closeAsyncPopup } = useActions(['openAsyncAlert', 'openAsyncConfirm', 'closeAsyncPopup'])
    const searchKeyword = ref('')
    const showArea = ref(false)
    const deptUsrGrplist = ref(null)
    const authSettingList = ref([])
    const selectedTab = ref('N')
    const vIncLowdept = ref('N')

    const {
      selectCmAuthList,
      selectDeptUsrGrpAllList,
      saveCmAuthList
    } = useAuth()

    const tabList = [
      { tabId: 'N', tabNm: '문서+파일' },
      { tabId: 'Y', tabNm: '파일' },
    ]

    const getSelectedTabEvent = (item) =>{
      selectedTab.value = item.tabId
      init()
    }

    const fnClose = () => {
      closeAsyncPopup('AuthSecurityOrgRegPop')
    }

    const fnSearch = async (keyword) => {
      if (!keyword) {
        openAsyncAlert({ message: t('common.msg.search_msg') })
        showArea.value = false
        return
      }

      if (keyword.length < 2) {
        openAsyncAlert({ message: '두 글자 이상 입력해 주세요.'})
        showArea.value = false
        return
      }

      const payload = {
        vKeyword : keyword,
        vFlagRec : props.popParams.vFlagRec
      }

      deptUsrGrplist.value =  await selectDeptUsrGrpAllList(payload)
      if(deptUsrGrplist.value.length > 0){
        showArea.value = true
      }else{
        showArea.value = false
      }
    }

    const selectAuthTarget = async (item) => {
      const haveFlag = authSettingList.value.some(vo => vo.vAuthcd === item.vAuthcd)
      if(haveFlag){
        await openAsyncAlert({message : '해당 값이 이미 선택되어 있습니다. 다른 값을 선택해주세요.'})
        return 
      }

      authSettingList.value.push(item)
      searchKeyword.value = ''
      showArea.value = false
    }

    const fnAuthDelete = (idx) => {
      authSettingList.value.splice(idx, 1)
    }

    const fnSave = async () => {
      if (authSettingList.value.length == 0) {
        if(!await openAsyncConfirm({ message: '보안설정 검색 대상이 없어 기존 데이터가 있을 경우 모두 삭제됩니다. 보안확정 하시겠습니까?'})){
          showArea.value = false
          return
        }
      }

      const regParams = {
        vFlagRec : selectedTab.value == 'N' ? props.popParams.vFlagRec : 'AUTH040',
        vRecordid : props.popParams.vRecordid,
        vFlagAttachAuth : props.popParams.vFlagAttachAuth,
        vFlagOnlyFile : selectedTab.value,
        authList : authSettingList.value, 
        vIncLowdept : vIncLowdept.value
      }

      const result = await saveCmAuthList(regParams)
      if(result == 'SUCC'){
        await openAsyncAlert({message : '등록 되었습니다.'})
        context.emit('callbackFunc')
      }
    }

    const init = async () => {
      const payload = {
        vFlagRec : props.popParams.vFlagRec,
        vRecordid : props.popParams.vRecordid,
        vFlagOnlyFile : selectedTab.value
      }

      authSettingList.value = await selectCmAuthList(payload)
    }

    init()

    const searchAreaReset = (keyword) => {
      if(commonUtils.isEmpty(keyword)){
        showArea.value = false
      }
    }

    return {
      t,
      fnSearch,
      fnClose,
      showArea,
      deptUsrGrplist,
      selectAuthTarget,
      fnAuthDelete,
      authSettingList,
      tabList,
      fnSave,
      getSelectedTabEvent,
      selectedTab,
      vIncLowdept,
      searchAreaReset,
      commonUtils,
      searchKeyword
    }
  }
}
</script>