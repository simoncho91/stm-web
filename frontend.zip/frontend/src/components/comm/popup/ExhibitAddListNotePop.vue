<template>
  <div class="modal-content modal-content__width--800">
    <div class="modal-header">
      <div class="modal-title">실험노트 리스트</div>
      <button type="button" class="modal-close" @click="fnClose()"></button>
    </div>
    <div class="modal-body">
      <div class="myboard-table">
        <div class="myboard-table__inner">
          <table class="ui-table ui-table__th--border-radius--0 ui-table__td--40 text-center">
            <colgroup>
              <col style="width:10%">
              <col style="width:45%">
              <col style="width:15%">
              <col style="width:10%">
              <col style="width:10%">
              <col style="width:10%">
            </colgroup>
            <thead>
              <tr>
                <th>내용물 코드</th>
                <th>[브랜드] 내용물명</th>
                <th>상태</th>
                <th>연구담당자</th>
                <th>파일럿시기</th>
                <th>출시시기</th>
              </tr>
            </thead>
            <tbody>
              <template v-if="resData && resData.length > 0">
                <tr v-for="(vo, idx) in resData" :key="'user_' + idx">
                  <td>{{ vo.vContCd }}</td>
                  <td>[{{ vo.vBrdNm }}]{{ vo.vContNm }}</td>
                  <td>{{ vo.vStatusNm }}</td>
                  <td>{{ vo.vUsernm }}</td>
                  <td>{{ commonUtils.changeStrDatePattern(vo.vPilotDt) }}</td>
                  <td>{{ commonUtils.changeStrDatePattern(vo.vMassProdDt) }}</td>
                </tr>
              </template>
              <template v-else>
                <tr>
                  <td colspan="6">
                    <div class="no-result">
                      {{ t('common.msg.no_data') }}
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { inject, ref } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'ExhibitAddListNotePop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vSpCode: '',
        }
      }
    }
  },
  setup (props) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])
    const {
      selectExhibitAddList
    } = useLabCommon()

    const resData = ref([])

    const fnClose = () => {
      closeAsyncPopup({ message: '' })
    }

    const init = async () => {
      const vSpCode = props.popParams.vSpCode

      if (commonUtils.isNotEmpty(vSpCode)) {
        resData.value = await selectExhibitAddList({ vSpCode: vSpCode })
      }
    }

    init()

    return {
      t,
      fnClose,
      resData,
      commonUtils,
    }
  }
}
</script>

<style scoped>
  .ui-table tbody tr {
    cursor: pointer;
  }
</style>