<template>
  <div>
    <div v-if="commonUtils.isEmpty(flagRec) || commonUtils.isEmpty(recordId)">
      [vFlagRec, vRecordid] 미지정
    </div>
    <div v-else>
      <span class="auth_secu_check"
        v-if="chkBoxHide == '' || chkBoxHide === 'N'"
      >
        <ap-input-check
          id="authDeptCheck"
          :name="flagRec+ '_' + recordId"
          :disabled="true"
          :model="rvo?.nFlag010Cnt > 0 ? 'Y' : 'N'"
          value="Y"
          false-value="N"
          label="부서"
        >
        </ap-input-check>

        <ap-input-check
          id="authUserCheck"
          :name="flagRec+ '_' + recordId"
          :disabled="true"
          :model="rvo?.nFlag020Cnt > 0 ? 'Y' : 'N'"
          value="Y"
          false-value="N"
          label="사용자"
        >
        </ap-input-check>

        <ap-input-check
          id="authGrpCheck"
          :name="flagRec+ '_' + recordId"
          :disabled="true"
          :model="rvo?.nFlag030Cnt > 0 ? 'Y' : 'N'"
          value="Y"
          false-value="N"
          label="그룹"
        >
        </ap-input-check>
      </span>
      <button type="button" 
        class="ui-button ui-button__height--23 ui-button__bg--gray ml-20"
        @click="openSecuritySettingPop"
        >
        보안설정
      </button>
    </div>
  </div>
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @callbackFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<style scoped>
  .auth_secu_check{
    vertical-align: middle;
  }
</style>
<script>
import { defineAsyncComponent, inject, ref, watch } from 'vue'
import { useAuth } from '@/compositions/useAuth'

export default {
  name: 'AuthSecurityRegister',
  props: {
    flagRec : {
      type: String, 
      default : ''
    },
    recordId : {
      type: String, 
      default : ''
    },
    chkBoxHide : {
      type: String, 
      default : ''
    },
    flagAttachAuth : {
      type: String, 
      default : ''
    },
  },
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    AuthSecurityOrgRegPop: defineAsyncComponent(() => import('@/components/comm/popup/AuthSecurityOrgRegPop.vue'))
  },
  emits: ['callbackFunc'],
  setup (props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const rvo = ref(null)

    const {
      selectCmAuthTypeRegYn,
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      fnClosePopup,
    } = useAuth()


    const init = async () => {
      if(commonUtils.isNotEmpty(props.flagRec) 
        && commonUtils.isNotEmpty(props.recordId)){
          const obj = {
            vFlagRec : props.flagRec,
            vRecordid : props.recordId,
            vChkboxHide : props.chkBoxHide,
            vFlagAttachAuth : props.flagAttachAuth,
          }
          rvo.value = await selectCmAuthTypeRegYn(obj)
      }
    }

    init()

    const openSecuritySettingPop = () => {
      popParams.value = {
        vFlagRec : props.flagRec, 
        vRecordid : props.recordId, 
        vFlagAttachAuth : props.flagAttachAuth, 
      } 

      popSelectFunc.value = chkAuthInfo
      fnOpenPopup('AuthSecurityOrgRegPop')
    }

    const chkAuthInfo = () => {
      fnClosePopup('AuthSecurityOrgRegPop')
      init()
    }

    return {
      t,
      commonUtils,
      popupContent,
      popParams,
      popSelectFunc,
      rvo,
      openSecuritySettingPop,
      chkAuthInfo
    }
  }
}

</script>