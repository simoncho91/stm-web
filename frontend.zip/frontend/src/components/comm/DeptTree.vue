<template>
  <tree-select
    v-if="deptList.length > 0"
    v-model="deptValue"
    :multiple="multiple"
    :options="deptList"
    :clearable="clearable"
    :searchable="false"
    :normalizer="normalizer"
    :default-expand-level="1"
    @open="expandNodeBySelectedItem"
    ref="tree"
  />
</template>

<script>
import { ref, watch, inject } from 'vue'
import { useComm } from '@/compositions/useComm'
import { useStore } from 'vuex'

export default {
  name: 'DeptTree',
  props: {
    deptcd: {
      type: String,
      default: ''
    },
    deptnm: {
      type: String,
      default: ''
    },
    udeptcd: {
      type: String,
      default: '10011'
    },
    multiple: {
      type: Boolean,
      default: false
    },
    clearable: {
      type: Boolean,
      default: false
    }
  },
  emits: ['update:deptcd', 'update:deptnm'],
  setup (props, context) {
    const commonUtils = inject('commonUtils')
    const tree = ref(null)
    const store = useStore()
    const deptValue = ref('')
    const deptList = ref([])
    const {
      findSigmaDeptTreeList
    } = useComm()

    deptValue.value = props.deptcd || ''

    const normalizer = (node) => {
      return {
        id: node.vSigmaDeptcd,
        label: node.vSigmaDeptnm,
        children: node.children && node.children.length ? node.children : 0
      }
    }

    const expandNodeBySelectedItem = () => {
      if (commonUtils.isNotEmpty(deptValue.value)) {
        tree.value.traverseAllNodesByIndex(node => {
          if (node.isBranch) {
            const shouldExpand = (node.children || []).some(child => child.id === deptValue.value)
            node.isExpanded = shouldExpand || node.isExpanded
          }
        })
      }
    }

    const setDeptnm = () => {
      if (commonUtils.isNotEmpty(deptValue.value)) {
        const originDeptList = store.getters.getOriginDeptList()
        const deptInfo = originDeptList.filter(item => item.vSigmaDeptcd === deptValue.value)[0]
        if (deptInfo) {
          context.emit('update:deptnm', deptInfo.vSigmaDeptnm)
        }
      }
    }

    const init = async () => {
      deptList.value = []
      const storeDeptList = store.getters.getDeptList()
      if (storeDeptList.length === 0) {
        const result = await findSigmaDeptTreeList(props.udeptcd)
  
        if (result) {
          deptList.value = result
        }
      } else {
        deptList.value = storeDeptList
      }

      setDeptnm()
    }

    init()

    watch(() => props.deptcd, async (newVal) => {
      if (deptValue.value !== newVal) {
        deptList.value = []
        deptValue.value = newVal
        setTimeout(async () => {
          await init()
        }, 200)
      }
    })

    watch(() => deptValue.value, (newVal) => {
      context.emit('update:deptcd', newVal)
      setDeptnm()
    })

    return {
      tree,
      deptValue,
      deptList,
      normalizer,
      expandNodeBySelectedItem,
    }
  }
}
</script>