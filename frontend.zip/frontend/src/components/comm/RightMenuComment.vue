<template>
  <div class="right-menu__tab--body-inner">
    <div class="right-menu__memo">
      <div class="memo-chat">
        <div class="memo-chat__inner">
          <div class="memo-chat__view">
            <template v-if="list && list.length > 0">
              <template v-for="(vo, idx) in list" :key="'message_list' + idx">
                <div class="memo-chat__date">
                  <div class="memo-chat__date--inner">{{ commonUtils.changeStrDateForKorean(vo.vUpdateDt) }}</div>
                </div>

                <div
                  v-for="(comment, index) in vo.commentList"
                  :key="'comment_' + idx + '_' + index"
                  :class="'memo-chat__talker memo-chat__talker--' + comment.classNm"
                >
                  <div class="talker-profile" v-if="comment.classNm === 'other'">
                    <span class="talker-profile__img">
                      <img src="@/assets/images/icon/icon-profile.png" alt="">
                    </span>
                    <span class="talker-profile__detail">
                      <span class="talker-profile__name">{{ comment.vUpdateUsernm }}</span>
                      <span class="talker-profile__work">{{ comment.vDeptnm }}</span>
                    </span>
                  </div>
                  <div class="talker-talk">
                    <div class="talker-talk__content" v-html="commonUtils.removeHTMLChangeBr(comment.vMessage)"></div>
                    <div class="talker-talk__time">{{ commonUtils.changeStrTmForKorean(comment.vUpdateTm) }}</div>
                  </div>

                </div>
              </template>
            </template>
            <template v-else>
              <div class="memo-chat-no-data">
                <p>등록된 내용이 없습니다.</p>
              </div>
            </template>
          </div>
          <button class="memo-chat__resize-button"></button>
          <div class="memo-chat__write">
            <div class="memo-chat__write--inner">
              <ap-text-area
                placeholder="의견을 남겨주세요. 최소 3자 이상 최대 200자 남기실 수 있습니다."
                v-model:value="commentTxt"
                :is-with-byte="true"
                :maxlength="200"
                @click="onFocusSet"
              ></ap-text-area>
            </div>
            <button type="button" class="ui-button ui-button__width--full ui-button__bg--blue memo-chat__write--button" @click="saveComment()">전송</button>
          </div>
        </div>
      </div>
    </div>

  </div>
</template>

<script>
import { ref, computed, watch, inject } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useStore } from 'vuex'
import { useActions } from 'vuex-composition-helpers'
import mixmatUtils from '@/utils/mixmatUtils'

export default {
  name: 'RightMenuComment',
  props: {
    isOpen: {
      type: Boolean,
      default: false
    }
  },
  setup (props) {
    const t = inject('t')
    const list = ref([])
    const store = useStore()
    const myInfo = store.getters.getMyInfo()
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert } = useActions(['openAsyncAlert'])
    const noteInfo = computed(() => store.getters.getNoteInfo())
    const commentTxt = ref('')
    const isLoading = ref(false)
    const {
      selectMessageList,
      insertMessage,
    } = useLabCommon()

    const fnMessageList = async () => {
      const result = await selectMessageList({ vRecordid: noteInfo.value.vLabNoteCd })
      list.value = []

      if (result) {
        result.forEach(item => {
          if (item.vUpdateUserid === myInfo.loginId) {
            item.classNm = 'my'
          } else {
            item.classNm = 'other'
          }
        })

        result.some(item => {
          if (list.value.filter(vo => vo.vUpdateDt === item.vUpdateDt).length > 0) {
            return false
          }

          const obj = {
            vUpdateDt: item.vUpdateDt,
            commentList: [...result.filter(vo => vo.vUpdateDt === item.vUpdateDt)]
          }

          list.value.push(obj)
        })
      }

      isLoading.value = true
    }

    const checkCommentByte = () => {
      let isOk = true
      let message = ''

      if (commentTxt.value.length < 3) {
        message = '최소 3자 이상 입력해 주세요.'
        isOk = false
      } else if (commentTxt.value.length > 200) {
        message = '최대 200자까지 입력 가능합니다.'
        isOk = false
      }

      if (!isOk) {
        openAsyncAlert({ message })
      }

      return isOk
    }

    const saveComment = async () => {
      if (!checkCommentByte()) {
        return
      }

      const payload = {
        vRecordid: noteInfo.value.vLabNoteCd,
        vLaborUserid: noteInfo.value.vUserid,
        vMessage: commentTxt.value,
      }

      const result = await insertMessage(payload)
      if (result) {
        commentTxt.value = ''
        await fnMessageList()
      }
    }

    const onFocusSet = () => {
      mixmatUtils.onFocusClear()
      mixmatUtils.clearMultipleSelectCell()
    }

    const init = () => {
      if (commonUtils.isNotEmpty(noteInfo.value) && commonUtils.isNotEmpty(noteInfo.value.vLabNoteCd) && props.isOpen) {
        fnMessageList()
      }
    }

    init()

    watch(() => props.isOpen, (newVal) => {
      if (newVal && !isLoading.value) {
        fnMessageList()
      }
    })

    return {
      commonUtils,
      list,
      commentTxt,
      checkCommentByte,
      saveComment,
      onFocusSet,
    }
  }
}
</script>