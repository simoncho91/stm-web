<template>
  <div class="right-menu__tab--body-inner">
    <div class="material-right__ing">
      <div class="material-right__ing--inner">
        <div class="material-search">
          <!-- <MaterialAutoComplete @change="fnSearchIssue">
          </MaterialAutoComplete> -->
          <ap-input v-model:value="serachParam.keyword" class="material-search__input"
            @keydown.enter="fnRawMaterialSearch()" @click="onFocusSet" @select="onFocusSet"></ap-input>
          <button class="button-search" @click.prevent="fnRawMaterialSearch()"></button>
        </div>

        <div class="right-content__box right-content__box--gray" v-if="issueInfo">

          <div class="problem-history">
            <div class="problem-history__box">
              <div class="problem-history__title">{{ issueInfo.vMateCd }}</div>
              <div class="problem-history__subtitle">SCM 문제 이력</div>
              <template v-if="issueInfo.scmIssueList && issueInfo.scmIssueList.length > 0">
                <div class="problem-history__item" v-for="(issue, index) in issueInfo.scmIssueList"
                  :key="'issue_' + index" v-html="commonUtils.removeHTMLChangeBr(issue)"></div>
              </template>
              <template v-else>
                <div class="problem-history__item">문제이력이 없습니다.</div>
              </template>
              <div class="problem-history__subtitle">내부 문제 이력</div>
              <template v-if="issueInfo.issueList && issueInfo.issueList.length > 0">
                <div class="problem-history__item" v-for="(issue, index) in issueInfo.issueList" :key="'issue_' + index"
                  v-html="commonUtils.removeHTMLChangeBr(issue)"></div>
              </template>
              <template v-else>
                <div class="problem-history__item">문제이력이 없습니다.</div>
              </template>
            </div>

          </div>
        </div>

        <div class="right-content__box">
          <div class="right-content__title--wrap">
            <div class="right-content__title">Recent</div>
            <button v-if="mateList && mateList.length > 0" type="button"
              class="ui-button ui-button__width--70 ui-button__height--23 ui-button__border--blue ui-button__radius--2 ml-auto"
              @click="onAllSelect('mate')">
              {{ !dragCheck.isMateAll ? '전체 선택' : '전체 해제' }}
            </button>
          </div>

          <!-- 2023.04.05 : mod : 레이아웃 수정 -->
          <!-- 전달사항 :: 활성화시 .is-active 붙습니다. -->
          <template v-if="mateList && mateList.length > 0">
            <draggable v-model="mateList" item-key="nSort"
              :group="{ name: 'materialMateList', pull: 'clone', put: false }" :sort="false" tag="div"
              class="recent-lists__wrap" :disabled="!dragCheck.isMateDrag" @start="onDragstart" @end="onDragend">
              <template #item="{ element: mate }">
                <ul class="ui-list recent-lists">
                  <li class="recent-list" :class="[mate.dragClass, (Number(mate.nFavorCnt) > 0 ? 'is-active' : '')]"
                    @click="onDragClick('mate', mate)" @mouseenter="onMouseenter('mate', mate)">
                    <a href="javascript:void(0)" class="recent-list__link">
                      <span class="recent-list__text">
                        <span class="recent-list__code">{{ mate.vMateCd }}</span>
                        <span class="recent-list__title">{{ mate.vMateNm }}</span>
                      </span>
                      <button class="recent-button" @click="fnFavorMatr(mate)"></button>
                    </a>
                  </li>
                </ul>
              </template>
            </draggable>
          </template>
        </div>

        <div class="right-content__box">
          <div class="right-content__title--wrap">
            <div class="right-content__title">Favorites</div>
            <button v-if="favorList && favorList.length > 0" type="button"
              class="ui-button ui-button__width--70 ui-button__height--23 ui-button__border--blue ui-button__radius--2 ml-auto"
              @click="onAllSelect('favor')">
              {{ !dragCheck.isFavorAll ? '전체 선택' : '전체 해제' }}
            </button>
          </div>

          <!-- 전달사항 :: 활성화시 .is-active 붙습니다. -->
          <template v-if="favorList && favorList.length > 0">
            <draggable v-model="favorList" item-key="nSort"
              :group="{ name: 'materialMateList', pull: 'clone', put: false }" :sort="false" tag="div"
              class="favorites-lists__wrap" :disabled="!dragCheck.isFavorDrag" @start="onDragstart" @end="onDragend">
              <template #item="{ element: favor }">
                <ul class="ui-list favorites-lists">
                  <li class="favorites-list is-active" :class="favor.dragClass" @click="onDragClick('favor', favor)"
                    @mouseenter="onMouseenter('favor', favor)">
                    <a href="javascript:void(0)" class="favorites-list__link">
                      <span class="favorites-list__text">
                        <span class="favorites-list__code">{{ favor.vMateCd }}</span>
                        <span class="favorites-list__title">{{ favor.vMateNm }}</span>
                      </span>
                      <button class="favorites-button" @click="fnFavorMatr(favor)"></button>
                    </a>
                  </li>
                </ul>
              </template>
            </draggable>
          </template>
        </div>
      </div>
    </div>
    <teleport to="#common-modal" v-if="popupContent">
      <ap-popup>
        <component :is="popupContent" :pop-params="popParams" @selectFunc="popSelectFunc" />
      </ap-popup>
    </teleport>
  </div>
</template>

<script>
import { reactive, ref, inject, defineAsyncComponent, computed, watch } from 'vue'
import { useStore } from 'vuex'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import mixmatUtils from '@/utils/mixmatUtils'

export default {
  name: 'RightMenuIngrd',
  components: {
    // MaterialAutoComplete: defineAsyncComponent(() => import('@/components/comm/MaterialAutoComplete.vue'))
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    MateSearchPop: defineAsyncComponent(() => import('@/components/labcommon/popup/MateSearchPop.vue')),
  },
  props: {
    isOpen: {
      type: Boolean,
      default: false
    }
  },
  setup(props) {
    const store = useStore()
    const commonUtils = inject('commonUtils')
    const noteType = store.getters.getNoteType()
    const keyList = computed(() => store.getters.getRecentMatrList(noteType))
    const noteInfo = computed(() => store.getters.getNoteInfo())
    const mateList = ref(null)
    const favorList = ref(null)
    const issueInfo = ref(undefined)
    const isLoading = ref(false)
    const dragCheck = reactive({
      isMateDrag: false,
      isFavorDrag: false,
      isMateAll: false,
      isFavorAll: false,
    })
    const serachParam = reactive({
      keyword: '',
      isAddRecent: false,
    })

    const {
      list,
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenMateSearchPop,
      selectSearchMyMateList,
      selectMaterialIssueList,
      selectRecentMateList,
      insertLabNoteMyMate,
      deleteLabNoteMyMate,
      selectSearchMateList,
    } = useLabCommon()

    const fnSearchIssue = async (returnObj) => {
      issueInfo.value = undefined
      if (!returnObj || commonUtils.isEmpty(returnObj.vMateCd)) {
        return
      }

      const issueResult = await selectMaterialIssueList({ vSapCd: returnObj.vMateCd })

      issueInfo.value = {
        vMateCd: returnObj.vMateCd,
        scmIssueList: [],
        issueList: [],
      }

      if (issueResult) {
        issueInfo.value.issueList = issueResult.issueList
        issueInfo.value.scmIssueList = issueResult.scmIssueList
      }

      store.dispatch('setRecentMatrList', { noteType, matrKey: returnObj.vKey })
    }

    const fnFavorMatr = async (matr) => {
      if (Number(matr.nFavorCnt) > 0) {
        await deleteLabNoteMyMate({ vMateCd: matr.vKey })
        matr.nFavorCnt = 0
      } else {
        await insertLabNoteMyMate({ vMateCd: matr.vKey, vType: matr.vType })
        matr.nFavorCnt = 1
      }

      fnMateList()
    }

    const fnRecentMateList = async () => {
      if (keyList.value && keyList.value.length === 0) {
        return
      }

      const response = await selectRecentMateList({ arrKey: keyList.value })

      if (response && response.length > 0) {
        mateList.value = response.map((mate, idx) => {
          return {
            ...mate,
            nSort: idx,
            vRecType: 'MATE',
            vMatePkCd: 'add_mate_pk_cd_mate_' + idx + mate.vKey
          }
        })
      } else {
        mateList.value = []
      }
    }

    const fnSearchMyMateList = async () => {
      const response = await selectSearchMyMateList({ nowPageNo: 1, pageSize: 10 })

      if (response && response.length > 0) {
        favorList.value = response.map((favor, idx) => {
          return {
            ...favor,
            nSort: idx,
            nFavorCnt: 1,
            vRecType: 'MATE',
            vMatePkCd: 'add_mate_pk_cd_favor_' + idx + favor.vKey,
          }
        })
      } else {
        favorList.value = []
      }
    }

    const fnMateList = () => {
      fnRecentMateList()
      fnSearchMyMateList()
      isLoading.value = true
    }

    const onDragstart = () => {
      const list = store.getters.getDragMateInfo().list
      store.dispatch('setDragMateInfo', {
        list,
        isClone: true,
      })
    }

    const onDragend = () => {
      const list = store.getters.getDragMateInfo().list
      store.dispatch('setDragMateInfo', {
        list,
        isClone: false,
      })
    }

    const onDragClick = (t, o) => {
      const list = store.getters.getDragMateInfo().list || []
      let dragList = []

      if (t === 'mate') {
        dragList = list.filter(mate => mate.vMatePkCd.indexOf('add_mate_pk_cd_mate') > -1)

        favorList.value = favorList.value?.map(favor => {
          return {
            ...favor,
            dragClass: '',
          }
        })
      }
      else {
        dragList = list.filter(favor => favor.vMatePkCd.indexOf('add_mate_pk_cd_favor') > -1)

        mateList.value = mateList.value?.map(mate => {
          return {
            ...mate,
            dragClass: '',
          }
        })
      }

      o.dragClass = !o.dragClass ? 'is-drag' : ''

      if (dragList.filter(mate => mate.vMatePkCd === o.vMatePkCd).length > 0) {
        dragList = dragList.filter(mate => mate.vMatePkCd !== o.vMatePkCd)
      }
      else {
        dragList = [...dragList, o,].sort(function (a, b) {
          return a.nSort - b.nSort
        })
      }
      store.dispatch('setDragMateInfo', { list: dragList })

      if (t === 'mate') {
        dragCheck.isMateDrag = dragList.length > 0 ? true : false
        dragCheck.isFavorDrag = false

        const len = mateList.value.filter(mate => mate.dragClass).length
        if (dragCheck.isMateAll) {
          if (len === 0) {
            dragCheck.isMateAll = false
          }
        }
        else {
          if (len === mateList.value.length) {
            dragCheck.isMateAll = true
          }
        }
      }
      else {
        dragCheck.isMateDrag = false
        dragCheck.isFavorDrag = dragList.length > 0 ? true : false

        const len = favorList.value.filter(favor => favor.dragClass).length
        if (dragCheck.isFavorAll) {
          if (len === 0) {
            dragCheck.isFavorAll = false
          }
        }
        else {
          if (len === favorList.value.length) {
            dragCheck.isFavorAll = true
          }
        }
      }
    }

    const onMouseenter = (t, o) => {
      const list = store.getters.getDragMateInfo().list || []
      let dragList = []

      if (t === 'mate') {
        dragList = list.filter(mate => mate.vMatePkCd === o.vMatePkCd)
        dragCheck.isMateDrag = dragList.length > 0 ? true : false
      }
      else {
        dragList = list.filter(favor => favor.vMatePkCd === o.vMatePkCd)
        dragCheck.isFavorDrag = dragList.length > 0 ? true : false
      }
    }

    const fnRawMaterialSearch = async () => {
      await selectSearchMateList({
        vPlantCd: noteInfo.value.vPlantCd,
        vLabNoteCd: noteInfo.value.vLabNoteCd,
        vNoteType: noteType,
        vSiteType: noteType,
        arrKeyword: serachParam.keyword,
        nowPageNo: 1
      })

      if (list.value && list.value.length === 1) {
        getSearchRequMateResult(list.value)
      }
      else {
        fnOpenMateSearchPop(serachParam.keyword, 'Y', getSearchRequMateResult)
      }
    }

    const getSearchRequMateResult = (o) => {
      store.dispatch('setSearchMateInfo', { isSearch: true, list: o })

      o.map((mate, idx) => {
        fnSearchIssue(mate)

        if ((idx + 1) === o.length) {
          serachParam.isAddRecent = true
        }
      })
    }

    const onAllSelect = (t) => {
      let dragList = []

      if (t === 'mate') {
        dragCheck.isMateAll = !dragCheck.isMateAll
        dragCheck.isFavorAll = false

        mateList.value = mateList.value?.map(mate => {
          return {
            ...mate,
            dragClass: dragCheck.isMateAll ? 'is-drag' : '',
          }
        })

        store.dispatch('setDragMateInfo', { list: dragCheck.isMateAll ? mateList.value : [] })

        favorList.value = favorList.value?.map(favor => {
          return {
            ...favor,
            dragClass: '',
          }
        })
      }
      else {
        dragCheck.isFavorAll = !dragCheck.isFavorAll
        dragCheck.isMateAll = false

        favorList.value = favorList.value?.map(favor => {
          return {
            ...favor,
            dragClass: dragCheck.isFavorAll ? 'is-drag' : '',
          }
        })

        store.dispatch('setDragMateInfo', { list: dragCheck.isFavorAll ? favorList.value : [] })

        mateList.value = mateList.value?.map(mate => {
          return {
            ...mate,
            dragClass: '',
          }
        })
      }

      if (t === 'mate') {
        dragCheck.isMateDrag = dragList.length > 0 ? true : false
        dragCheck.isFavorDrag = false
      }
      else {
        dragCheck.isMateDrag = false
        dragCheck.isFavorDrag = dragList.length > 0 ? true : false
      }
    }

    const onFocusSet = () => {
      mixmatUtils.onFocusClear()
      mixmatUtils.clearMultipleSelectCell()
    }

    const init = () => {
      if (props.isOpen) {
        fnMateList()
      }
    }

    init()

    watch(() => keyList.value, (newVal) => {
      if (newVal) {
        if (serachParam.isAddRecent) {
          serachParam.isAddRecent = false

          fnRecentMateList()
        }
      }
    })

    watch(() => props.isOpen, (newVal) => {
      if (newVal && !isLoading.value) {
        fnMateList()
      }
    })

    return {
      commonUtils,
      mateList,
      favorList,
      issueInfo,
      dragCheck,
      serachParam,
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenMateSearchPop,
      onDragstart,
      onDragend,
      onDragClick,
      onMouseenter,
      fnSearchIssue,
      fnFavorMatr,
      fnRawMaterialSearch,
      onAllSelect,
      onFocusSet,
    }
  }
}
</script>

<style scoped>
.problem-history__item {
  white-space: normal;
}
</style>