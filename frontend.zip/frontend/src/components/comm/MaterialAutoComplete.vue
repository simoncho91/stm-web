<template>
  <ApAutoComplete
    class="auto-input"
    v-model="text"
    :values="materialItems"
    @update="fnSearchMaterial"
    :readonly="readOnly"
    @input="fnInputEvt"
  >
  </ApAutoComplete>
</template>

<script>
import { ref, defineAsyncComponent, inject, computed } from 'vue'
import { useStore } from 'vuex'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'

export default {
  name: 'MaterialAutoComplete',
  props: {
    searchKeyword: {
      type: String,
      default: ''
    }
  },
  components: {
    ApAutoComplete: defineAsyncComponent(() => import('@/components/comm/ApAutoComplete.vue'))
  },
  setup (props, context) {
    const commonUtils = inject('commonUtils')
    const text = ref(props.searchKeyword || '')
    const originItems = ref([])
    const materialItems = ref([])
    const store = useStore()
    const noteType = store.getters.getNoteType()
    const noteInfo = computed(() => store.getters.getNoteInfo())

    const {
      selectSearchMateAutocompleteList,
    } = useLabCommon()
    const fnSearchMaterial = async (keyword) => {
      if (!isNaN(Number(keyword)) && keyword.length < 5) {
        return
      }

      if (commonUtils.isEmpty(keyword) || keyword.length < 3) {
        return
      }

      const payload = {
        vKeyword: keyword,
        vFlagAutoComplete: 'Y',
        vPlantCd: noteInfo.value.vPlantCd,
        vLabNoteCd: noteInfo.value.vLabNoteCd,
        vSiteType: noteInfo.value.vSiteType,
        vNoteType: noteType
      }
      originItems.value = await selectSearchMateAutocompleteList(payload)
      if (!originItems.value || originItems.value.length === 0) {
        materialItems.value = []
      } else {
        materialItems.value = originItems.value.map(item => '[' +  item.vKey + '] ' + item.vMateNm)
      }
    }

    const fnInputEvt = (value) => {
      if (!originItems.value || originItems.value.length === 0) {
        return
      }

      const returnObj = originItems.value.find(item => ('[' +  item.vKey + '] ' + item.vMateNm) === value)

      if (returnObj !== undefined) {
        returnObj.vMateCd = commonUtils.isNotEmpty(returnObj.vMateCd) ? returnObj.vMateCd : null
        context.emit('change', returnObj)
      } else {
        context.emit('change', null)
      }
    }

    return {
      text,
      materialItems,
      fnSearchMaterial,
      fnInputEvt,
    }
  }
}
</script>