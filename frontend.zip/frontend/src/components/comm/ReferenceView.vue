<template>
  <div class="arrordion-item is-active">
    <div class="arrordion-header">
      <div class="arrordion-title">참조처</div>
    </div>
    <div class="arrordion-body">
      <div class="mt-15">
        <table class="ui-table__reset ui-table__ver ui-table__td--40 text-center">
          <colgroup>
            <col style="width:19rem">
            <col style="width:auto">
          </colgroup>
          <tbody>
            <tr v-for="(vo, idx) in referenceList" :key="'ref_' + idx">
              <th>{{ vo.vFlagRecNm }}</th>
              <td>
                <div class="reference-wrap">
                  <div class="referrer">{{ vo.vRefNm }}</div>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script>
import { inject } from 'vue'
import { useApproval } from '@/compositions/approval/useApproval'

export default {
  name: 'ReferenceView',
  props: {
    recordId: {
      type: String,
      default: ''
    }
  },
  setup (props) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const {
      referenceList,
      findReferenceList
    } = useApproval()

    const init = async () => {
      if (commonUtils.isNotEmpty(props.recordId)) {
        await findReferenceList(props.recordId)
      }
    }

    init()

    return {
      t,
      referenceList
    }
  }
}
</script>