<template>
  <tree-select
    v-if="classList.length > 0"
    v-model="classValue"
    :multiple="multiple"
    :options="classList"
    :clearable="clearable"
    :searchable="false"
    :normalizer="normalizer"
    :default-expand-level="1"
    @open="expandNodeBySelectedItem"
    ref="tree"
  />
</template>

<script>
import { ref, watch, inject } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useStore } from 'vuex'

export default {
  name: 'TddProductClassTree',
  props: {
    classcd: {
      type: String,
      default: ''
    },
    classnm: {
      type: String,
      default: ''
    },
    uclasscd: {
      type: String,
      default: 'S000001'
    },
    multiple: {
      type: Boolean,
      default: false
    },
    clearable: {
      type: Boolean,
      default: false
    }
  },
  emits: ['update:classcd', 'update:classnm'],
  setup (props, context) {
    const commonUtils = inject('commonUtils')
    const tree = ref(null)
    const store = useStore()
    const classValue = ref('')
    const classList = ref([])
    const {
      selectTddProductClassList
    } = useLabCommon()

    classValue.value = props.classcd || ''

    const normalizer = (node) => {
      return {
        id: node.vCid,
        label: node.vTitle,
        children: node.children && node.children.length ? node.children : 0
      }  
    }

    const expandNodeBySelectedItem = () => {
      if (commonUtils.isNotEmpty(classValue.value)) {
        tree.value.traverseAllNodesByIndex(node => {
          if (node.isBranch) {
            const shouldExpand = (node.children || []).some(child => child.id === classValue.value)
            node.isExpanded = shouldExpand || node.isExpanded
          }
        })
      }
    }

    const setClassnm = () => {
      if (commonUtils.isNotEmpty(classValue.value)) {
        const originClassList = store.getters.getOriginClassList()
        const classInfo = originClassList.filter(item => item.vCid === classValue.value)[0]
        if (classInfo) {
          context.emit('update:classnm', classInfo.vTitle)
        }
      }
    }

    const init = async () => {
      classList.value = []
      const storeClassList = store.getters.getClassList()
      if (storeClassList.length === 0) {
        const result = await selectTddProductClassList(props.uclasscd)

        if (result) {
          classList.value = result
        }
      } else {
        classList.value = storeClassList
      }

      setClassnm()
    }

    init()

    watch(() => props.classcd, async (newVal) => {
      if (classValue.value !== newVal) {
        classList.value = []
        classValue.value = newVal
        setTimeout(async () => {
          await init()
        }, 200)
      }
    })

    watch(() => classValue.value, (newVal) => {
      context.emit('update:classcd', newVal)
      setClassnm()
    })

    return {
      tree,
      classValue,
      classList,
      normalizer,
      expandNodeBySelectedItem,
    }
  }
}
</script>