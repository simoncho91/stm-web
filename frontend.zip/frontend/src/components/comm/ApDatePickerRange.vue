<template>
  <date-picker v-model="calData.range" is-range :popover="{ visibility: 'click' }">
    <template v-slot="{ inputValue, inputEvents }">
      <div class="form-flex">
        <div class="form-flex-cell">
          <input
            type="text"
            :value="inputValue.start"
            v-on="inputEvents.start"
            :disabled="calData.disabledYn === 'Y'"
            :class="['flatpickr-input ui-input ui-input__date', styleClass]"
            :readonly="readOnly"
          >
        </div>
        <div class="form-flex-cell form-flex-cell--date-hyphen">~</div>
        <div class="form-flex-cell">
          <input
            type="text"
            :value="inputValue.end"
            v-on="inputEvents.end"
            :disabled="calData.disabledYn === 'Y'"
            :class="['flatpickr-input ui-input ui-input__date', styleClass]"
            :readonly="readOnly"
          >
        </div>
        <div v-if="isWeekTerm" class="form-flex-cell ml-05">
          <div class="ui-buttons">
            <button type="button" class="ui-button ui-button__bg--lightgray" @click="onWeekTerm('B')">초기</button>
            <button type="button" class="ui-button ui-button__bg--lightgray" @click="onWeekTerm('N')">익일</button>
            <button type="button" class="ui-button ui-button__bg--lightgray" @click="onWeekTerm('1')">1주</button>
            <button type="button" class="ui-button ui-button__bg--lightgray" @click="onWeekTerm('2')">2주</button>
            <button type="button" class="ui-button ui-button__bg--lightgray" @click="onWeekTerm('3')">3주</button>
            <button type="button" class="ui-button ui-button__bg--lightgray" @click="onWeekTerm('4')">4주</button>
          </div>
        </div>
      </div>
    </template>
  </date-picker>
</template>

<script>
import { reactive, inject, watch } from 'vue'

export default {
  name: 'ApDatePickerRange',
  props: {
    startDt: String,
    endDt: String,
    disabledYn: String,
    styleClass: { type: String, default: '' },
    readOnly: { type: Boolean, default: false },
    resetable: { type: Boolean, default: false },
    isWeekTerm: { type: Boolean, default: false },
  },
  emits: ['update:startDt', 'update:endDt', 'onWeekTerm', 'onChange'],
  setup (props, context) {
    const commonUtils = inject('commonUtils')
    const calData = reactive({
      range: {
        start: null,
        end: null
      },
      rangeString: {
        start: '',
        end: ''
      },
      disabledYn: ''
    })

    if (props.startDt && props.endDt) {
      calData.range = {
        start: commonUtils.convertStrToDate(props.startDt),
        end: commonUtils.convertStrToDate(props.endDt)
      }
    } else if (props.startDt) {
      calData.range = {
        start: commonUtils.convertStrToDate(props.startDt),
        end: null
      }
    } else if (props.endDt) {
      calData.range = {
        start: null,
        end: commonUtils.convertStrToDate(props.endDt)
      }
    }

    watch(() => props.disabledYn, () => {
      calData.disabledYn = props.disabledYn === 'Y' ? 'Y' : 'N'
    })

    watch(() => props.startDt, (newVal, oldVal) => {
      if (props.resetable || (newVal && calData.rangeString.start !== newVal)) {
        calData.range = {
          start: commonUtils.convertStrToDate(newVal),
          end: calData.range.end
        }
        calData.rangeString.start = newVal

        context.emit('onChange', newVal, 'S')
      }
    })

    watch(() => props.endDt, (newVal, oldVal) => {
      if (props.resetable || (newVal && calData.rangeString.end !== newVal)) {
          calData.range = {
            start: calData.range.start,
            end: commonUtils.convertStrToDate(newVal)
          }
          calData.rangeString.end = newVal

          context.emit('onChange', newVal, 'E')
        }
    })

    watch(() => calData.range, (newVal, oldVal) => {
      if (newVal) {
        const startDt = commonUtils.convertDateToStr(newVal.start)
        const endDt = commonUtils.convertDateToStr(newVal.end)

        if (startDt && props.startDt !== startDt) {
          context.emit('update:startDt', startDt)
        }

        if (endDt && props.endDt !== endDt) {
          context.emit('update:endDt', endDt)
        }
      } else {
        context.emit('update:startDt', '')
        context.emit('update:endDt', '')
      }

    })

    const onWeekTerm = (o) => {
      context.emit('onWeekTerm', o)
    }

    return {
      calData,
      onWeekTerm,
    }
  }
}
</script>
