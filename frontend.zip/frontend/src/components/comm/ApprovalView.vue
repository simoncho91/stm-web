<template>
  <div>
    <div class="arrordion-item is-active">
      <div class="arrordion-header">
        <div class="arrordion-title">결재선</div>
      </div>
      <div class="arrordion-body">
        <div class="note-table mt-15">
          <div class="note-table__inner">
            <table class="ui-table ui-table__td--40 text-center">
              <colgroup>
                <col style="width:20%">
                <col style="width:20%">
                <col style="width:20%">
                <col style="width:20%">
                <col style="width:20%">
              </colgroup>
              <thead>
                <tr>
                  <th>결재구분</th>
                  <th>결재자</th>
                  <th>직급(직책)</th>
                  <th>결재시간</th>
                  <th>결재결과</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>기안자</td>
                  <td>
                    {{ apprInfo.vDraftUsernm }}
                    <template v-if="apprInfo.vDraftDeptnm">
                      ( {{ apprInfo.vDraftDeptnm }} )
                    </template>
                  </td>
                  <td>{{ apprInfo.vDraftPositnm }}</td>
                  <td>{{ commonUtils.changeStrDatePattern(apprInfo.vDraftDtm, '.', 'Y') }}</td>
                  <td>결재의뢰</td>
                </tr>
                <tr v-for="(vo, idx) in apprList" :key="'appr_' + idx">
                  <td>
                    {{ vo.vApprUserTypenm }}
                  </td>
                  <td>
                    {{ vo.vApprUserNm }}
                    <template v-if="vo.vApprDeptnm">
                      ( {{ vo.vApprDeptnm }} )
                    </template>
                  </td>
                  <td>{{ vo.vApprPositnm }}</td>
                  <td>{{ commonUtils.changeStrDatePattern(vo.vApprDtm, '.', 'Y') }}</td>
                  <td>{{ vo.vApprStatusnm }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <teleport to="#common-modal" v-if="popupContent">
      <ap-popup>
        <component
          :is="popupContent"
          :pop-params="popParams"
          @callbackFunc="popSelectFunc"
        />
      </ap-popup>
    </teleport>
  </div>
</template>

<script>
import { defineAsyncComponent, inject, watch } from 'vue'
import { useApproval } from '@/compositions/approval/useApproval'

export default {
  name: 'ApprovalView',
  props: {
    apprCd: {
      type: String,
      default: ''
    },
    apprClass: {
      type: String,
      default: ''
    },
    apprMstInfo: {
      type: Object,
      default: () => {
        return null
      }
    },
    apprUserList: {
      type: Object,
      default: () => {
        return null
      }
    }
  },
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    OpinionApprReqPop: defineAsyncComponent(() => import('@/components/approval/popup/OpinionApprReqPop.vue'))
  },
  emits: ['update:apprMstInfo', 'update:apprUserList'],
  setup (props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const {
      apprInfo,
      apprList,
      findApprovalInfo,
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      fnClosePopup,
    } = useApproval()

    const fnApprovalOpinionPop = () => {
      popSelectFunc.value = fnApprovalResult
      fnOpenPopup('OpinionApprReqPop')
    }

    const fnApprovalResult = (item) => {
      context.emit('callbackFunc', item)
      fnClosePopup()
    }

    const init = async () => {
      if (commonUtils.isNotEmpty(props.apprCd)) {
        await findApprovalInfo(props.apprCd)
      }
    }

    init()

    watch(() => apprInfo.value, (newVal) => {
      if (newVal) {
        context.emit('update:apprMstInfo', newVal)
      }
    })

    watch(() => apprList.value, (newVal) => {
      if (newVal) {
        context.emit('update:apprUserList', newVal)
      }
    })

    return {
      apprInfo,
      apprList,
      commonUtils,
      popupContent,
      popParams,
      popSelectFunc,
      fnApprovalOpinionPop,
    }
  }
}
</script>
