<template>
  <header class="header">
    <div class="header__inner">
      <div class="header-logo">
        <a class="header-logo__link" href="#" @click.prevent="goMain()"></a>
      </div>
      <div class="header-menu">
        <div class="header-menu__inner">
          <div class="header-menu__item header-user-info">
            <a href="#" class="header-menu__link icon_none"></a>
            {{ myInfo.userNm }}님 ({{ myInfo.loginId }})
          </div>
          <!-- 전달사항 :: 클릭시 클래스 is-active 추가 됩니다. -->
          <div class="header-menu__item header-menu__inquiry">
            <a href="#" class="header-menu__link"></a>
            <div class="header-menu__dropdown">
              <div class="header-menu__dropdown--inner">
                <div class="header-menu__dropdown--body">
                  <div class="ui-buttons">
                    <a href="#" class="ui-button ui-button__link ui-button__bg--blue" @click="fnOpenSystemReg('error')">오류/일반 문의</a>
                    <a href="#" class="ui-button ui-button__link ui-button__bg--blue" @click="fnOpenSystemReg('system')">my BEAKER 개선 제안</a>
                    <a href="#" class="ui-button ui-button__link ui-button__bg--blue" @click="fnOpenItHelpDesk">데이터 수정/추출</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="header-menu__item header-menu__qr" style="z-index: 4;">
            <a href="#" :class="['header-menu__link', (checkQrFlag == 'true' ? 'is-active' : '')]" @click="fnQrOpen"></a>
            <div class="header-menu__dropdown">
              <div class="header-menu__dropdown--inner">
                <div class="header-menu__dropdown--header">
                    <div class="header-menu__dropdown--title">QR코드를 스캔해 주세요.</div>
                </div>
                <div class="header-menu__dropdown--body">
                  
                  <div v-if="webcamYn === 'N'">
                    <div>
                      <ap-input
                      v-model:value="vQrTxt"
                      :maxlength="300"
                      input-class="ui-input__width--340"
                      placeholder="인식이 안될 경우 커서를 올려주세요."
                      @keypressEnter="fnQrTxtInfo(vQrTxt)"
                      @keyup="fnQrTxtInfo(vQrTxt)"
                      >
                      </ap-input>
                    </div>
                  </div>
                  <div v-else>
                    <div class="qr-img__wrap camera">
                      <div class="qr-img">
                        <div class="stream">
                          <qr-stream @decode="onDecode" :camera="onCam == '' ? 'off' : onCam" class="mb" style="width:133px; height:110px;">
                            <div style="color: red;" class="frame"></div>
                          </qr-stream>
                        </div>
                      </div>
                      <div class="qr-text">사각 테두리안에 QR코드를 <br>인식해 주세요.</div>
                    </div>
                  </div>

                  <div class="qr-checkbox">
                    <div class="ui-checkbox__list">
                      <div class="ui-checkbox__inner">
                        
                        <div class="ui-checkbox-block">
                          <ap-input-check
                            v-model:model="webcamYn"
                            value="Y"
                            false-value="N"
                            id="webcamYn"
                            @click="clickWbCam"
                          >
                          </ap-input-check>
                          웹캠사용
                        </div>
                        <div class="ui-checkbox-block">
                          <ap-input-check
                            v-model:model="newBrYn"
                            value="Y"
                            false-value="N"
                            id="newBrYn"
                            @click="clickNwBr"
                          >
                          </ap-input-check>
                          새창으로
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- 전달사항 :: 미확인 알람 있을때 클래스 is-alarm 추가 됩니다. -->
          <div class="header-menu__item header-menu__alarm" :class="alarmCount && Number(alarmCount) > 0 ? 'is-alarm' : ''">
            <a href="#" class="header-menu__link" @click="fnAlarmList()"></a>
            <div class="header-menu__dropdown">
              <div class="header-menu__dropdown--inner header-menu__dropdown--alarm">
                <div class="alarm-scroll-area">
                  <div class="header-menu__dropdown--body header-menu__dropdown--body-alarm">
                    <div class="dropdown-alarm">
                      <div class="dropdown-alarm__inner">
                        <ul class="ui-list dropdown-alarm__lists">
                          <template v-if="userAlarmList && userAlarmList.length > 0">
                            <li class="dropdown-alarm__list"
                              v-for="(vo, idx) in userAlarmList"
                              :key="'alarm_' + idx"
                            >
                              <a class="dropdown-alarm__link"
                                href="#"
                                @click.prevent="goMoveUrl(vo)"
                                v-html="commonUtils.removeXSS(vo.vMessage)"
                              ></a>
                              <span class="dropdown-alarm__time">{{ commonUtils.changeStrDatePattern(vo.vRegDtm, '.', 'Y')}}</span>
                            </li>
                          </template>
                          <template v-else>
                            <li class="dropdown-alarm__list">
                              <div class="no-alarm"><span></span>알림이 없습니다.</div>
                            </li>
                          </template>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="header-menu__item header-menu__approval" :class="approvalCount && Number(approvalCount) > 0 ? 'is-approval' : ''">
            <a href="#" class="header-menu__link" @click.prevent="goApproval()"></a>
          </div>

          <div class="header-menu__item header-menu__setting "><!-- is-active -->
              <a href="#" class="header-menu__link" @click="fnSettingPop"></a>
              <div class="header-menu__dropdown">
                  <div class="header-menu__dropdown--inner">
                      <div class="header-menu__dropdown--header">
                          <div class="header-menu__dropdown--title">설정</div>
                      </div>
                      <div class="header-menu__dropdown--body header-menu__dropdown--body-setting">
                          <div class="dropdown-item">
                              <div class="dropdown-item__title">메인</div>
                              <div class="dropdown-item__contents">
                                  <div class="setting-myBoard">
                                      <div class="setting-myBoard__inner">

                                        <draggable v-model="mainList" item-key="nSort" :group="{ name: 'mainList', pull: 'clone', put: false}"
                                        :sort="true" tag="div" @end="onDragend">
                                          <template #item="{ element: main }">
                                              <ul class="ui-list setting-myBoard__lists">
                                                  <li :class="['setting-myBoard__list', (main.vMenuid == 'NS' ? checkNsFlag : checkEmFlag) ? 'is-active' : '']"
                                                    @click="fnSettingMain(main)">
                                                    <a href="javascript:void(0)" :class="['setting-myBoard__link', 'setting-myBoard__link--' + (main.vMenuid === 'NS' ? 'note' : 'examination')]">
                                                      <i class="setting-myBoard__icon"></i>
                                                      <span class="setting-myBoard__title">{{ main.vMenuid == 'NS' ? 'Note' : 'Examination' }}</span>
                                                    </a>
                                                    <a href="javascript:void(0)" :class="['setting-myBoard__link', 'setting-myBoard__link--' + (main.vMenuid === 'NS' ? 'schedule' : 'memo')]">
                                                      <i class="setting-myBoard__icon"></i>
                                                      <span class="setting-myBoard__title">{{ main.vMenuid == 'NS' ? 'schedule' : 'Memo' }}</span>
                                                    </a>
                                                  </li>
                                              </ul>
                                          </template>
                                        </draggable>

                                      </div>
                                  </div>
                              </div>
                          </div>
                          <div class="dropdown-item">
                            <div class="dropdown-item__title">알림수신</div>
                            <div class="dropdown-item__contents">
                              <div class="setting-myBoard__inner">
                                <ul class="alarm-set-area">
                                  <li :class="check_all === 'Y' ? 'is-active' : ''">
                                    <a href="#" @click.prevent="fnCheckAllEvent(check_all)">전체</a>
                                  </li>
                                </ul>
                                <ul class="alarm-set-area">
                                  <li
                                    v-for="(alarm, index) in alarmList" :key="'alarm_list_' + index"
                                    :class="alarm.vAlarm === 'Y' ? 'is-active' : ''"
                                  >
                                    <a href="#" @click.prevent="fnCheckEvent(alarm)">{{ alarm.vSubCodenm }}</a>
                                  </li>
                                </ul>
                              </div>
                            </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>

          <div class="header-menu__item header-menu__logout">
            <a href="#" class="header-menu__link" @click="fnLogout"></a>
          </div>
        </div>
      </div>
    </div>
  </header>
</template>

<script>
import { ref, onMounted, getCurrentInstance, inject, computed, watch } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useComm } from '@/compositions/useComm'
import { useStore } from 'vuex'
import { useRouter } from 'vue-router'
import { useActions } from 'vuex-composition-helpers'
import { QrStream } from 'vue3-qr-reader'
import uiUtils from '@/utils/uiUtils'
import ApInput from './ApInput.vue'
export default {
  components: { ApInput, QrStream},
  name: 'HeaderTemplate',
  setup() {
    const app = getCurrentInstance();
    const tiumUrl = app.appContext.config.globalProperties.tiumUrl
    const serverMode = app.appContext.config.globalProperties.serverMode

    const { openAsyncAlert } = useActions(['openAsyncAlert'])
    const store = useStore()
    const router = useRouter()
    const commonUtils = inject('commonUtils')
    const check_all = ref('')
    const t = inject('t')
    const userAlarmList = ref([])
    const alarmCount = computed(() => store.getters.getAlarmCount())
    const approvalCount = computed(() => store.getters.getApprovalCount())
    const webcamYn = ref('')
    const newBrYn = ref('')
    const vQrTxt = ref('')
    const myInfo = store.getters.getMyInfo()
    const onCam = ref('')
    const vQrVal = ref('')
    const rvo = ref('')

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const {
      selectTopList,
      insertTopBannerSettingAlarm,
      insertTopBannerSettingMain,
      mainList,
      alarmList,
      checkNsFlag,
      checkEmFlag,
      selectAlarmCheckCount,
      selectAlarmList,
      updateAlarmCheckFlag,
      selectQrReaderCheckInfo,
      updateQrReaderCheck,
    } = useComm()

    const fnLogout = () => {
      store.dispatch('signout')
        .then(res => {
          const resData = res.data
          if (resData.code === 'C0000') {
            router.push({ path: '/login' })
          } else {
            openAsyncAlert({ message: res.data.message })
          }
        })
    }

    const fnOpenItHelpDesk = () => {
      //데이터/수정 추출
      const url = "https://ithelpdesk.amorepacific.com/hc/ko/requests/new?ticket_form_id=5703199398553";
      window.open(url, "_blank");
    }

    const fnOpenSystemReg = (flag) => {
      //오류/일반문의 게시판
      const url = "/supo/rs/supo_rs_"+flag+"_enquiry_reg.do";
      const pop_title = "supo_rs_enquiry_reg" ;

      const targetUrl = tiumUrl + url;
      //새창
      window.open(targetUrl, pop_title) ;
    }

    const onDragend = () =>{
      //드래그시 저장
      fnSave('MS')
    }

    const fnSettingMain = (item) => {
      //설정
      if (item.vMenuid === 'NS') {
        checkNsFlag.value = !checkNsFlag.value
        item.vView = checkNsFlag.value ? 'Y' : 'N'
      } else {
        checkEmFlag.value = !checkEmFlag.value
        item.vView = checkEmFlag.value ? 'Y' : 'N'
      }

      //저장
      fnSave('MS')
    }

    const fnSettingPop = async () => {
      //Top Banner 정보 불러오기(메인, 알림)
      await selectTopList()
      setAlarmAll()

      //메인 가져온 데이터 셋팅
      mainList.value.forEach((item) => {
        if(item.vMenuid == 'NS'){
          if(item.vView !== "Y"){
            checkNsFlag.value = false
          }
        }else{
          if(item.vView !== "Y"){
            checkEmFlag.value = false
          }
        }
      })
    }
      
    const fnCheckAllEvent = (value) => {
      // 알림수신 체크
      // value === 'Y' 현재 체크 여부. 반대로 작동
      if (value === 'Y') {
        alarmList.value.forEach((item, idx) => {
          item.vAlarm = 'N'
        })

        check_all.value = ''
      } else {
        alarmList.value.forEach((item, idx) => {
          item.vAlarm = 'Y'
        })
        
        check_all.value = 'Y'
    }

      //저장
      fnSave('AL')
    }

    const setAlarmAll = () => {
      // 알림수신 체크
      const checkedLen = alarmList.value.filter(item => item.vAlarm == 'Y').length
      if (alarmList.value.length === checkedLen) {
        check_all.value = 'Y'
      } else {
        check_all.value = ''
      }
    }

    const fnCheckEvent = (alarmInfo) => {
      alarmInfo.vAlarm = alarmInfo.vAlarm === 'Y' ? '' : 'Y'
      // 알림수신 체크
      setAlarmAll()

      //저장
      fnSave('AL')
    }

    const fnSave = (flag) => {
      
       if(flag == 'AL'){
        //알림 저장
        insertTopBannerSettingAlarm(alarmList.value)
      }else{
        //메인설정 저장
        insertTopBannerSettingMain(mainList.value)
      } 
    }

    const fnAlarmList = async () => {
      store.dispatch('setAlarmCount', 0)
      const result = await selectAlarmList()

      if (result) {
        userAlarmList.value = [...result]

        if (userAlarmList.value && userAlarmList.value.length > 0) {
          updateAlarmCheckFlag()
        }
      }
    }

    const goMain = () => {
      router.push({ path : '/main', query : { redirect: 'N' } })
    }

    const goApproval = () => {
      router.push({ path : '/approval/list' })
    }

    const goMoveUrl = (item) => {
      if (commonUtils.isEmpty(item.vMoveUrl)) {
        return
      }

      window.location.href = item.vMoveUrl
    }

    const init = () => {
      const alarmCount = sessionStorage.getItem('alarmCount')

      if (!alarmCount) {
        selectAlarmCheckCount()
      }

      if (!approvalCount.value) {
        store.dispatch('selectMyApprovalCount')
      }

      webcamYn.value = "Y"
      checkQrFlag.value = true
    }

    const checkQrFlag = ref('')

    const onDecode = (data) => {
      //데이터 split 해서 QR_CODE_INFO 정보가 있는지 확인 후 없으면 아래 안내메시지 생성
      const arrQrData = data.split('//')
      
      let dataInfo = ''
      let mbInfo = ''
      if(arrQrData.length > 0){
        dataInfo = codeGroupMaps.value['QR_CODE_INFO'].filter(item => item.vSubCode === arrQrData[0])
      }

      if(dataInfo.length === 0){
        openAsyncAlert({ message: "QR코드가 정상적으로 입력되지 않았습니다.</br>정상적인 QR코드를 입력 부탁드립니다." })
        return
      }

      if(arrQrData[0] === 'QR_SC_NOTE' || arrQrData[0] === 'QR_MU_NOTE' || arrQrData[0] === 'QR_HBO_NOTE' || arrQrData[0] === 'QR_SA_NOTE'
      || arrQrData[0] === 'QR_BF_NOTE' || arrQrData[0] === 'QR_SP_LIB' ){
        mbInfo = 'MB'
      }else{
        mbInfo = 'NO'
      }
      
      if(arrQrData[0].length > 0){
        fnQrMovePage(mbInfo, arrQrData[0], arrQrData[1], arrQrData[2], arrQrData[3], dataInfo[0].vBuffer1, dataInfo[0].vBuffer2, arrQrData[4])
      }

    }

    const fnQrTxtInfo = (data) => {
      //QR_C_MRQ040_FUNC//TR202310018190//1//MRQ040
      //데이터 split 해서 QR_CODE_INFO 정보가 있는지 확인 후 없으면 아래 안내메시지 생성
      const arrQrData = data.split('//')
      let dataInfo = ''
      let mbInfo = ''
      if(arrQrData.length > 0){
        dataInfo = codeGroupMaps.value['QR_CODE_INFO'].filter(item => item.vSubCode === arrQrData[0])
      }

      if(dataInfo.length === 0){
        openAsyncAlert({ message: "QR코드가 정상적으로 입력되지 않았습니다.</br>정상적인 QR코드를 입력 부탁드립니다." })
        return
      }

      if(arrQrData[0] === 'QR_SC_NOTE' || arrQrData[0] === 'QR_MU_NOTE' || arrQrData[0] === 'QR_HBO_NOTE' || arrQrData[0] === 'QR_SA_NOTE'
      || arrQrData[0] === 'QR_BF_NOTE' || arrQrData[0] === 'QR_SP_LIB' ){
        mbInfo = 'MB'
      }else{
        mbInfo = 'NO'
      }

      fnQrMovePage(mbInfo, arrQrData[0], arrQrData[1], arrQrData[2], arrQrData[3], dataInfo[0].vBuffer1, dataInfo[0].vBuffer2, arrQrData[4])
    }

    const fnQrMovePage = (data1, data2, data3, data4, data5, pgUrl, qrParam, noteCd) => {
      //QR_C_MRQ040_FUNC//TR202310018190//1//MRQ040
      //QR_C_CLINICAL//DISCUSS//CT20230000008
      //QR_SC_NOTE//Y//NOTE_LOT//LLO20230321014963//LMS20230315010302
      //QR_MU_NOTE//Y//NOTE_LOT//LLO20230724016845//LMS20230724011373
      //i_sFlagQrCode//i_sDivQrCode//i_sQrCode
      const arrQrParams = qrParam.split('//')
      let query = ''
      
      if(data1 === 'MB'){
        //마이비커 페이지 이동
        let url = ''
        let qrNoteType = ''
        if(arrQrParams.length === 3){
          
          if(data2 === "QR_SC_NOTE"){
            //정보 불러오기
            url = '/skincare/all-lab-note-prd-material'
            qrNoteType = 'skincare'
          }else if(data2 === "QR_MU_NOTE"){
            //정보 불러오기
            url = '/makeup/all-lab-note-prd-material'
            qrNoteType = 'makeup'
          }else if(data2 === "QR_HBO_NOTE"){
            //정보 불러오기
            url = '/hbd/all-lab-note-prd-material'
            qrNoteType = 'hbd'
          }else if(data2 === "QR_SA_NOTE"){
            //정보 불러오기
            url = '/qdrug/all-lab-note-prd-material'
            qrNoteType = 'qdrug'
          }else{
            openAsyncAlert({ message: "정보를 불러 올 수 없습니다." })
            return
          }
          
          // router.push 방식
          // query = {
          //   vFlagQrCode : data3,
          //   vDivQrCode : data4,
          //   vQrCode : data5,
          //   vQrNoteType : qrNoteType,
          // }

        }else{
          //SP라이브러리 
          // i_sFlagQrCode//i_sSplMstCd
          let url = pgUrl + '?' + arrQrParams[0] + "=" + data3 + '&' + arrQrParams[1] + "=" + data4 
          
          const targetUrl = tiumUrl + url
          //새창
          window.open(targetUrl, '')

        }

        //이동 
        // router.push({ path : url, query})
        window.location.href = url+"?vFlagQrCode="+data3+"&vDivQrCode="+data4+"&vQrCode="+data5+"&vQrNoteType="+qrNoteType+"&vLabNoteCd="+noteCd

      }else{
        //티움넷 페이지 이동
        let url = ''
        if(arrQrParams.length === 3){
          url = pgUrl + '?' + arrQrParams[0] + "=" + data3 + '&' + arrQrParams[1] + "=" + data4 + '&' + arrQrParams[2] + "=" + data5
        }else{
          
          if(data2 === 'QR_C_CLINICAL'){
            url = '/' + pgUrl + '?' + arrQrParams[0] + "=" + data3 + '&' + arrQrParams[1] + "=" + data4 
          }else{
            url = pgUrl + '?' + arrQrParams[0] + "=" + data3 + '&' + arrQrParams[1] + "=" + data4 
          }

        }

          vQrTxt.value = ""

          const targetUrl = tiumUrl + url
          //새창
          window.open(targetUrl, '')
      }

    }

    const fnQrOpen = async () =>{

      if(checkQrFlag.value){
        //열림
        findCodeList('QR_CODE_INFO') //QR 이동 정보

        const result = await selectQrReaderCheckInfo()
        if (result) {
          rvo.value = result.rvo
          webcamYn.value = rvo.value.vQrCamYn
          newBrYn.value = rvo.value.vQrNewYn
        }
        
        if(webcamYn.value == "Y"){
            onCam.value = "on"
        }else{
          onCam.value = "off"
        }

      }else{
      //닫힘
        onCam.value = "off"
      }

      //is-active
      checkQrFlag.value = !checkQrFlag.value     
    }

    const clickWbCam = () => {
      
      if(webcamYn.value == "N"){
        checkQrFlag.value = true
        onCam.value = "off"
      }else{
        checkQrFlag.value = false 
        onCam.value = "on"
      }

      const payload = {
        vQrCamYn: webcamYn.value,
        vQrNewYn: newBrYn.value
      }
      updateQrReaderCheck(payload)
      
    }

    const clickNwBr = () => {
      //새로고침
      vQrTxt.value = ""
      //QR 재실행
    }

    init()

    watch(() => approvalCount.value, (newVal) => {
      if (!newVal) {
        store.dispatch('selectMyApprovalCount')
      }
    })
    
    onMounted(() => {
      uiUtils.headerItemClickEvent()
    })

    return {
      alarmList,
      mainList,
      userAlarmList,
      checkNsFlag,
      checkEmFlag,
      t,
      fnLogout,
      fnOpenItHelpDesk,
      fnOpenSystemReg,
      fnSettingMain,
      fnCheckAllEvent,
      fnCheckEvent,
      commonUtils,
      check_all,
      selectTopList,
      fnSettingPop,
      fnSave,
      insertTopBannerSettingAlarm,
      onDragend,
      fnAlarmList,
      goMain,
      goApproval,
      alarmCount,
      approvalCount,
      fnQrOpen,
      fnQrTxtInfo,
      fnQrMovePage,
      codeGroupMaps,
      vQrVal,
      onDecode,
      onCam,
      checkQrFlag,
      webcamYn,
      newBrYn,
      clickWbCam,
      clickNwBr,
      vQrTxt,
      serverMode,
      myInfo,
      goMoveUrl,
      selectQrReaderCheckInfo,
      rvo,
    }

  },


}
</script>

<style scoped>
  .dropdown-item:hover, .dropdown-item:focus {
    background-color: #fff;
  }

  .icon_none { background: none;}
</style>