<template>
  <div class="ui-checkbox-block" :id="'div_check_' + id + '_wrap'">
    <input
      type="checkbox"
      :class="['ui-checkbox', inputClass]"
      :id="id"
      :model="checkValue"
      :readonly="readonly"
      :disabled="disabled"
      :trueValue="value"
      :falseValue="falseValue"
      :checked="checkValue === value || checkValue.indexOf(value) > -1"
      @click="onClick($event)"
    />
    <label :for="id" class="ui-label">
      <span class="ui-checkbox-object"></span>
      <span class="ui-label__text" v-if="label !== ''">{{ label }}</span>
    </label>
  </div>
</template>

<script>
import { ref, watch } from 'vue'
export default {
  name: 'ApInputCheck',
  props: {
    id: { type: String, default: '', required: false },
    name: { type: String, default: '', required: false },
    inputClass: { type: [String, Array], default: '', required: false },
    readonly: { type: Boolean, default: false, required: false },
    disabled: { type: Boolean, default: false, required: false },
    model: { default: '' },
    value: { type: [String, Number], default: '', required: false },
    checked: { type: Boolean, default: false },
    label: { type: String, default: '', requlred: false },
    falseValue: {type: [String, Number], default: '', required: false },
  },
  emits: ['update:model', 'click'],
  setup (props, context) {
    const checkValue = ref(props.model)
    const onClick = (e) => {
      const isChecked = e.target.checked
      if (props.model instanceof Array) {
        let newValue = [ ...props.model ]

        if (isChecked) {
          newValue.push(props.value)
        } else {
          newValue.splice(newValue.indexOf(props.value), 1)
        }

        context.emit('update:model', newValue.sort())
      } else {
        context.emit('update:model', isChecked ? props.value : props.falseValue)
      }

      context.emit('click', isChecked ? props.value : props.falseValue)
    }

    watch(() => props.model, (newVal) => {
      const wrap = document.querySelector('#div_check_' + props.id + '_wrap')
      checkValue.value = newVal
      const trueValue = props.value

      if (wrap) {
        wrap.querySelector('#' + props.id).checked = newVal.indexOf(trueValue) > -1 ? true : false
      }
    }, { immediate: true })

    return {
      onClick,
      checkValue
    }
  }
}
</script>