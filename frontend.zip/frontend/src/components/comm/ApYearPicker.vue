<template>
  <div :class="inputClass">
    <VueDatePicker
      v-model="year"
      year-picker
      hide-input-icon
      auto-apply
      :position="position"
      :readonly="readonly"
      :disabled="disabled"
    >
    </VueDatePicker>
  </div>
</template>

<script>
import { ref, inject, watch } from 'vue'
import VueDatePicker from '@vuepic/vue-datepicker';
import '@vuepic/vue-datepicker/dist/main.css'
export default {
  name: 'ApYearPicker',
  props: {
    date: String,
    inputClass: { type: [String, Array], default: '' },
    readonly: { type: Boolean, default: false },
    disabled: { type: Boolean, default: false },
    position: { type: String, default: 'left' },
  },
  components: {
    VueDatePicker
  },
  emits: ['update:date'],
  setup (props, context) {
    const commonUtils = inject('commonUtils')
    const year = ref()

    if (props.date) {
      const date = commonUtils.parseDate(props.date + '0101')

      year.value = date.getFullYear()
    }

    watch(() => props.date, (newVal) => {
      if (newVal) {
        const date = commonUtils.parseDate(newVal + '0101')

        year.value = date.getFullYear()
      } else {
        year.value = ''
      }
    })

    watch(() => year.value, (newVal) => {
      if (newVal) {
        const newData = newVal
  
        const date = commonUtils.parseDateToStr(new Date(newData + '-01-01'))
  
        if (props.date !== date.substr(0, 4)) {
          context.emit('update:date', date.substr(0, 4))
        }
      } else {
        context.emit('update:date', '')
      }
    })

    return {
      year,
    }
  }
}
</script>