<template>
  <select
    :id="id"
    :name="name"
    :title="title"
    :class="['ui-select', inputClass]"
    :readonly="readonly"
    :disabled="disabled"
    :value="selectValue"
    :placeholder="placeholder"
    @input="onInput($event)"
    @change="onChange($event)"
  >
    <option v-if="defaultBlank.blank" :value="defaultBlank.value" :selected="defaultBlank.value === selectValue">{{ defaultBlank.name }}</option>
    <option v-for="(item, index) in options" :key="item[codeKey] + '_' + index" :value="item[codeKey]">{{ item[codeNmKey] }}</option>
  </select>
</template>

<script>
import { ref, watch } from 'vue'
export default {
  name: 'ApSelectbox',
  props: {
    id: { type: String, default: '', required: false },
    name: { type: String, default: '', required: false },
    title: { type: String, default: '', required: false },
    inputClass: { type: [String, Array], default: '', required: false },
    disabled: { type: Boolean, default: false, required: false },
    readonly: { type: Boolean, default: false, required: false },
    value: { type: [String, Number], default: '', required: false },
    placeholder: { type: String, default: '', required: false },
    codeKey: { type: String, default: 'vSubCode'},
    codeNmKey: { type: String, default: 'vSubCodenm'},
    defaultBlank: {
      type: Object,
      default: () => {
        return {
          blank: true,
          value: '',
          name: '선택'
        }
      }
    },
    options: {
      type: Array,
      default: () => {
        return []
      }
    },
  },
  emits: ['update:value', 'input', 'change'],
  setup (props, context) {
    const selectValue = ref(props.value)
    const onInput = (e) => {
      context.emit('update:value', e.target.value)
      context.emit('input', e.target.value)
    }

    const onChange = (e) => {
      context.emit('update:value', e.target.value)
      context.emit('change', e.target.value)
    }

    watch(() => props.value, (newVal) => {
      selectValue.value = newVal
    })

    return {
      onInput,
      onChange,
      selectValue
    }
  }
}
</script>