<template>
  <div class="right-menu" id="rightMenu">
    <div class="right-menu__inner">
      <button type="button" class="right-menu__button"><i class="right-menu__button--icon"></i></button>
      <div class="right-menu__tab ap_contents_tab" id="rightMenuTab">
        <div class="right-menu__tab--header">
          <ul class="ui-list right-menu__tab--lists">
            <template v-if="currentPath.indexOf('-material') > -1">
              <li 
                v-for="(vo, idx) in tabList"
                :key="'right_tab_' + idx"
                class="right-menu__tab--list ap_li_tab_item"
                :class="selectedTab === vo.tabId ? 'is-active' : ''"
                :for="vo.tabId"
                @click="fnTabClickEvent(vo)"
              >
                <a href="#" class="right-menu__tab--link">{{ vo.tabNm }}</a>
              </li>
            </template>
            <template v-else>
              <li
                v-for="(vo, idx) in tabList.filter(item => item.formulaYn !== 'Y')"
                :key="'right_tab_' + idx"
                class="right-menu__tab--list ap_li_tab_item"
                :class="selectedTab === vo.tabId ? 'is-active' : ''"
                :for="vo.tabId"
                @click="fnTabClickEvent(vo)"
              >
                <a href="#" class="right-menu__tab--link">{{ vo.tabNm }}</a>
              </li>
            </template>
          </ul>
        </div>
        <div class="right-menu__tab--body contents-tab__body" id="rightIngrd">
          <RightMenuIngrd
            v-if="selectedTab === 'rightIngrd'"
            v-model:isOpen="isOpen"
          >
          </RightMenuIngrd>
        </div>
        <div class="right-menu__tab--body contents-tab__body" id="rightStatus">
          <RightMenuStatus
            v-if="selectedTab === 'rightStatus'"
            v-model:isOpen="isOpen"
          >
          </RightMenuStatus>
        </div>
        <div class="right-menu__tab--body contents-tab__body" id="rightComment">
          <RightMenuComment
            v-if="selectedTab === 'rightComment'"
            v-model:isOpen="isOpen"
          >
          </RightMenuComment>
        </div>
        <div class="right-menu__tab--body contents-tab__body" id="rightSchedule">
          <RightMenuSchedule
            v-if="selectedTab === 'rightSchedule'"
            v-model:isOpen="isOpen"
          >
          </RightMenuSchedule>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, onMounted, onUnmounted, ref, watch } from 'vue'
import { useRoute } from 'vue-router'

export default {
  name: 'RightMenu',
  components: {
    RightMenuIngrd: defineAsyncComponent(() => import('@/components/comm/RightMenuIngrd.vue')),
    RightMenuStatus: defineAsyncComponent(() => import('@/components/comm/RightMenuStatus.vue')),
    RightMenuComment: defineAsyncComponent(() => import('@/components/comm/RightMenuComment.vue')),
    RightMenuSchedule: defineAsyncComponent(() => import('@/components/comm/RightMenuSchedule.vue')),
  },
  setup () {
    const route = useRoute()
    const isOpen = ref(false)
    
    const currentPath = ref(route.path)
    const selectedTab = ref('rightComment')
    const tabList = ref([
      { tabId: 'rightIngrd', tabNm: 'ing.', formulaYn: 'Y' },
      { tabId: 'rightStatus', tabNm: 'status', formulaYn: 'Y' },
      { tabId: 'rightComment', tabNm: 'comment', formulaYn: 'N' },
      { tabId: 'rightSchedule', tabNm: 'schedule', formulaYn: 'N' },
    ])

    const fnTabClickEvent = (item) => {
      selectedTab.value = item.tabId
    }

    const rightMenuOpenEvent = () => {
      const rightMenuButton = document.querySelector('.right-menu__button')
      const rightMenu = document.querySelector('.right-menu')

      if (rightMenuButton) {
        rightMenuButton.addEventListener('click', () => {
          rightMenu.classList.toggle('is-open')
          isOpen.value = !isOpen.value
        })
      }
    }

    const setSelectedTab = () => {
      if (currentPath.value.indexOf('-material') > -1) {
        selectedTab.value = 'rightIngrd'
      } else {
        selectedTab.value = 'rightComment'
      }
    }

    setSelectedTab()

    watch(() => route.path, (newVal) => {
      if (newVal) {
        currentPath.value = newVal
        setSelectedTab()
      }
    })

    onMounted(() => {
      rightMenuOpenEvent()
    })

    onUnmounted(() => {
      rightMenuOpenEvent()
    })

    return {
      isOpen,
      currentPath,
      selectedTab,
      tabList,
      fnTabClickEvent,
    }
  }
}

</script>