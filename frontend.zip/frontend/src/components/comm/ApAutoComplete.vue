<template>
  <div class="autocomplete-form"
    @keydown.down="onKeydown($event)"
    @keydown.up="onKeyup($event)"
    @keydown.enter="onEnterClicked"
    @focusin="visible=true"
    @focusout="onFocusout($event)"
  >
    <div class="autocomplete-form-input-elements">
      <input class="autocomplete-form-input material-search__input"
        autocomplete="off"
        @input="onInputHandler($event)"
        v-model="text"
        :readonly="readOnly"
        :disabled="disabled"
        type="text"
      >
    </div>
    <div :id="elemId" class="list-group list-group-flush autocomplete-form-items" :class="{hide: (disabled && visible) || !visible}">
      <button v-for="(val, index) in valuesList"
          :key="index"
          class="list-group-item list-group-item-action"
          :class="{active: selectedIndex === index}"
          @click="onClickHandler"
          @mouseover="selectedIndex = index"
          type="button"
      >
        {{ val }}
      </button>
    </div>
  </div>
</template>

<script>
import { ref, inject, watch } from 'vue'
export default {
  name: 'ApAutoComplete',
  props: {
    values: { type: Array, required: true },
    value: { type: String, default: '', required: false },
    readOnly: { type: Boolean, default: false, required: false },
    disabled: { type: Boolean, default: false, required: false },
  },
  setup (props, context) {
    const elemId = ref('')
    const text = ref('')
    const valuesList = ref([])
    const visible = ref(false)
    const selectedIndex = ref(0)

    const onKeydown = () => {
      if (valuesList.value.length === 0) {
        return
      }

      selectedIndex.value = selectedIndex.value < valuesList.value.length - 1 ? selectedIndex.value + 1 : selectedIndex.value

      const elem = document.querySelector('#' + elemId.value)
      const btn = elem.querySelectorAll('.list-group-item')[selectedIndex.value]
      const bb = btn.offsetTop + btn.offsetHeight
      const h = elem.offsetHeight

      if (selectedIndex.value === 0) {
        elem.scrollTop = 0
      } else if (h < bb) {
        elem.scrollTop = bb - h
      }
    }

    const onKeyup = () => {
      if (valuesList.value.length === 0) {
        return
      }

      selectedIndex.value = selectedIndex.value > 0 ? selectedIndex.value - 1 : selectedIndex.value

      const elem = document.querySelector('#' + elemId.value)
      const btn = elem.querySelectorAll('.list-group-item')[selectedIndex.value]
      const bt = btn.offsetTop

      if (bt < elem.scrollTop) {
        elem.scrollTop = bt
      }
    }

    const setBoxScrollTop = (y) => {
      const elem = document.querySelector('#' + elemId.value)
      elem.scrollTop = y
    }

    const onFocusout = (e) => {
      if (e.relatedTarget === null || e.relatedTarget === undefined) {
        visible.value = false
        selectedIndex.value = 0
        setBoxScrollTop(0)
        return
      }

      try {
        const cls = e.relatedTarget.getAttribute('class')
        if (cls.indexOf('list-group-item-action') === -1) {
          visible.value = false
          selectedIndex.value = 0
          setBoxScrollTop(0)
        }
      } catch (e) {
        visible.value = false
        selectedIndex.value = 0
        setBoxScrollTop(0)
      }
    }

    const onInputHandler = (e) => {
      context.emit('input', text.value)
      context.emit('update', e.target.value)
    }

    const onClickHandler = (e) => {
      text.value = e.target.innerHTML.trim()
      selectedIndex.value = e.target.dataset.id
      context.emit('input', text.value)
      e.target.blur()
    }

    const onEnterClicked = (e) => {
      if (valuesList.value.length > 0) {
        text.value = valuesList.value[selectedIndex.value].trim()
        context.emit('input', text.value)
        e.target.blur()
      }
    }

    const init = () => {
      elemId.value = 'autocomplete_' + (new Date().getTime()) + '_' + Math.floor(Math.random() * 10000)
      if (text.value !== props.value) {
        text.value = props.value
      }
    }

    init()

    watch(() => props.values, (newVal) => {
      if (newVal) {
        valuesList.value = props.values
        visible.value = true
      }
    })

    return {
      elemId,
      text,
      valuesList,
      visible,
      selectedIndex,
      onKeydown,
      onKeyup,
      onFocusout,
      onInputHandler,
      onClickHandler,
      onEnterClicked,
    }
  }
}
</script>

<style scoped>
  .autocomplete-form { width: 100%; }
  .autocomplete-form-input-elements {
    width: 100%;
    height: 100%;
  }
  .material-search__input {
    width: 100%;
    height: 100%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
</style>