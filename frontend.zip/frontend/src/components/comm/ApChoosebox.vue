<template>
  <div class="p-relative">
    <ap-input
      v-model:value="outTxt"
      :input-class="inputStyle.class"
      :readonly="true"
      @click="setChoosebox"
    >
    </ap-input>
    <ul class="ui-choosebox"
        :class="!showFlag ? 'd-none' : ''"
        :id="'choosebox_' + id"
    >
      <li class="all">
        <ap-input-check
          value="Y"
          label="전체"
          v-model:model="chkAll"
          :id="'choosebox_' + id + 'chkAll'"
          @click="fnChooseBoxAll"
        >
        </ap-input-check>
      </li>
      <li v-for="(item, index) in options" :key="item[codeKey] + '_' + index">
        <div class="ui-checkbox-block">
          <input
            type="checkbox"
            class="ui-checkbox"
            :id="'choosebox_' + id + index"
            :class="'choosebox_' + id + 'chk'"
            :value="item[codeKey]"
            :checked="checkList.indexOf(item[codeKey]) > -1"
            @click="fnChooseBox"
          />
          <label :for="'choosebox_' + id + index" class="ui-label">
            <span class="ui-checkbox-object"></span>
            <span class="ui-label__text">{{ item[codeNmKey] }}</span>
          </label>
        </div>
      </li>
    </ul>
  </div>
</template>

<script>
import { ref, watch, onMounted, onUnmounted, reactive } from 'vue'
export default {
  name: 'ApChoosebox',
  props: {
    id: { type: String, default: ''},
    codeKey: { type: String, default: 'vSubCode'},
    codeNmKey: { type: String, default: 'vSubCodenm'},
    inputClass: { type: [String, Array], default: '', required: false },
    modelChkAll: {
      type: String,
      default: ''
    },
    model: {
      type: Array,
      default: () => {
        return []
      }
    },
    options: {
      type: Array,
      default: () => {
        return []
      }
    }
  },
  emits: ['update:model', 'update:modelChkAll', 'click'],
  setup (props, context) {
    const outTxt = ref('전체')
    const chkAll = ref(props.modelChkAll)
    const showFlag = ref(false)
    const inputStyle = reactive({
      class: 'ui-select ' + (showFlag.value ? ' ui-choosebox-input ' : '') + props.inputClass
    })

    const checkList = ref(props.model || [])

    const setChoosebox = (e) => {
      showFlag.value = !showFlag.value
      if (showFlag.value) {
        const input = e.target

        if (!input) {
          return
        }

        const left = input.offsetLeft
        const top = input.offsetTop + input.offsetHeight - 2

        const chooseBox = document.querySelector('#choosebox_' + props.id)

        chooseBox.style.top = top + 'px'
        chooseBox.style.left = left + 'px'
      }
    }

    const setChooseBoxInput = () => {
      const checkCnt = checkList.value.length
      
      if (checkCnt === props.options.length) {
        document.querySelector('#choosebox_' + props.id + 'chkAll').checked = true
        outTxt.value = '전체'
      } else {
        if (checkCnt > 0) {
          const codeInfo = props.options.filter(vo => vo[props.codeKey] === checkList.value[0])[0]
          if (codeInfo) {
            outTxt.value = codeInfo[props.codeNmKey] + (checkCnt > 1 ? ' 외 ' + (checkCnt - 1) + '건' : '')
          }
        } else {
          outTxt.value = '전체'
        }
        document.querySelector('#choosebox_' + props.id + 'chkAll').checked = false
      }
    }

    const fnChooseBoxAll = (value) => {
      let newValue = []
      if (value === 'Y') {
        props.options.forEach((item, index) => {
          newValue.push(item[props.codeKey])
          document.querySelector('#choosebox_' + props.id + index).checked = true
        })
      } else {
        props.options.forEach((item, index) => {
          checkList.value.splice(item[props.codeKey], 1)
          document.querySelector('#choosebox_' + props.id + index).checked = false
        })
      }

      context.emit('update:model', newValue.sort())
      setChooseBoxInput()
    }

    const fnChooseBox = (e) => {
      let newValue = [ ...checkList.value ]
      if (e.target.checked) {
        newValue.push(e.target.value)
      } else {
        newValue.splice(newValue.indexOf(e.target.value), 1)
      }

      context.emit('update:model', newValue.sort())
      setChooseBoxInput()
    }

    const init = () => {
      if (checkList.value.length > 0) {
        setChooseBoxInput()
      }
    }

    onMounted(() => {
      init()
    })

    watch(() => chkAll.value, (newVal) => {
      context.emit('update:modelChkAll', newVal)
    })

    watch(() => props.modelChkAll, (newVal) => {
      chkAll.value = props.modelChkAll
    })

    watch(() => props.model, (newVal) => {
      checkList.value = newVal || []
      setChooseBoxInput()
    })

    watch(() => props.options, (newVal) => {
      if (newVal && newVal.length > 0) {
        setChooseBoxInput()
      }
    })

    return {
      checkList,
      outTxt,
      showFlag,
      inputStyle,
      chkAll,
      setChoosebox,
      setChooseBoxInput,
      fnChooseBox,
      fnChooseBoxAll,
    }
  }
}
</script>