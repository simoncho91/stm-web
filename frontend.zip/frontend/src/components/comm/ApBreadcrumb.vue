<template>
  <div :class="inputStyle.class">
    <div class="nav__inner">
      <div class="nav-title">{{ navTitle }}</div>
      <ul class="ui-list nav-lists">
        <li class="nav-list nav-list__home"><a href="#" class="nav-link" @click.prevent="goPage(homePath)"></a></li>
        <li v-for="(item, index) in pathList" :key="'breadcrumb_' + index"
          :class="['nav-list', 'nav-list__depth' + (pathList.length + 1), index === (pathList.length - 1) ? 'is-active': '']"
        >
          <a
            v-if="index !== (pathList.length - 1)"
            href="#" 
            class="nav-link" @click.prevent="goPage(item[pathKey])"
          >
            {{ item[pathNmKey] }}
          </a>
          <a
            v-else
            href="#" 
            class="nav-link"
          >
            {{ item[pathNmKey] }}
          </a>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import { ref, reactive } from 'vue'
import { useStore } from 'vuex'
import { useRouter } from 'vue-router'

export default {
  name: 'ApBreamdcrumb',
  props: {
    pathList: {
      type: Array,
      default: () => {
        return []
      }
    },
    navTitle: {
      type: String,
      default: ''
    },
    pathKey: {
      type: String,
      default: 'path'
    },
    pathNmKey: {
      type: String,
      default: 'pathNm'
    },
    flagInside : {
      type: Boolean,
      default: false
    }
  },
  setup (props, context) {
    const homePath = ref('')
    const store = useStore()
    const router = useRouter()
    const inputStyle = reactive({ class: ['nav', (props.flagInside ? 'nav-inside' : '')]})

    const goPage = (path) => {
      router.push({ path: path })
    }

    const init = () => {
      const noteType = store.getters.getNoteTypeNm()

      homePath.value = '/' + noteType + '/' + 'my-board'
    }
    
    init()

    return {
      homePath,
      goPage,
      inputStyle
    }
  }
}
</script>

