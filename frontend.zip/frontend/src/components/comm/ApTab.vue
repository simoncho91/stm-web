<template>
  <div :class="tabStyle[0]" :id="mstId">
    <ul :class="ulTabStyle">
      <li v-for="(item, index) in tabList" :key="mstId + '_' + index"
        :class="(defaultTab === item[tabIdKey]) || (defaultTab === '' && index === 0) ? tabLiStyle + ' is-active' : tabLiStyle"
        :for="item[tabIdKey]">
        <ap-input v-if="item.isInput" v-model:value="item[tabNmKey]" id="apTabInput" class="ui-input__width--124"
          @keypress-enter="onKeypress" />
        <a v-else href="#" :class="tabStyle[3]" @click.prevent="onClick(item)">{{ item[tabNmKey] }}</a>
      </li>
      <template v-if="isSlot">
        <li :class="tabLiStyle" class="slot">
          <!-- 추가 li 가 필요시 고유 name 으로 slot 추가해서 사용하세요.(사용처를 쉽게 찾기위해) -->
          <slot name="materialVersionPlusButton"></slot>
        </li>
      </template>
    </ul>
  </div>
</template>

<script>
import { onMounted, onUpdated, toRefs } from 'vue'
import uiUtils from '@/utils/uiUtils'
export default {
  name: 'ApTab',
  props: {
    mstId: {
      type: String,
      default: ''
    },
    tabList: {
      type: Array,
      default: () => {
        return []
      }
    },
    tabNmKey: {
      type: String,
      default: 'tabNm'
    },
    tabIdKey: {
      type: String,
      default: 'tabId'
    },
    defaultTab: {
      type: String,
      default: ''
    },
    tabStyle: {
      type: Array,
      default: () => {
        return [
          'contents-tab__header',
          'ui-list contents-tab__lists ap_ul_tab',
          'contents-tab__list ap_li_tab_item',
          'contents-tab__link',
        ]
      },
    },
    isSlot: {
      type: Boolean,
      default: false,
    }
  },
  emits: ['click', 'onKeypress'],
  setup(props, context) {
    const onClick = (item) => {
      context.emit('click', item)
    }

    const { tabStyle } = toRefs(props)
    let tabLiStyle = tabStyle.value[2]
    if (tabLiStyle.indexOf('ap_li_tab_item') < 0) {
      tabLiStyle += ' ap_li_tab_item';
    }

    let ulTabStyle = tabStyle.value[1]
    if (ulTabStyle.indexOf('ap_ul_tab') < 0) {
      ulTabStyle += ' ap_ul_tab';
    }

    onMounted(() => {
      uiUtils.tabInit(props.mstId)
      uiUtils.tabEvent(props.mstId)
    })

    // 동적 탭 추가시 작동하게 하기 위하여
    onUpdated(() => {
      uiUtils.tabInit(props.mstId)
      uiUtils.tabEvent(props.mstId)

      if (props.tabList.filter(tab => tab.isInput).length > 0) {
        setTimeout(() => {
          const element = document.getElementById('apTabInput');
          if (element) {
            element.focus();
          }
        }, 200)
      }
    })

    const onKeypress = (o) => {
      context.emit('onKeypress', o)
    }

    return {
      onClick,
      tabLiStyle,
      ulTabStyle,
      onKeypress,
    }
  }
}
</script>

