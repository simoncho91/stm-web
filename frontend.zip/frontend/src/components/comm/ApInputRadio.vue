<template>
  <div class="ui-radio-block" :id="'div_radio_' + id + '_wrap'">
    <input
      type="radio"
      :class="['ui-radio', inputClass]"
      :id="id"
      :name="name"
      :model="model"
      :readonly="readonly"
      :disabled="disabled"
      :checked="model === value"
      :value="value"
      :falseValue="falseValue"
      @click="onClick($event)"
    />
    <label :for="id" class="ui-label">
      <span class="ui-radio-object"></span>
      <span class="ui-label__text" v-if="label !== ''">{{ label }}</span>
    </label>
  </div>
</template>

<script>
import { ref, inject } from 'vue'
export default {
  name: 'ApInputRadio',
  props: {
    id: { type: String, default: '', required: true },
    name: { type: String, default: '', required: true },
    inputClass: { type: [String, Array], default: '', required: false },
    readonly: { type: Boolean, default: false, required: false },
    disabled: { type: Boolean, default: false, required: false },
    model: { type: [String, Number], default: '', required: false },
    value: { type: [String, Number], default: '', required: false },
    falseValue: {type: [String, Number], default: '', required: false },
    label: { type: String, default: '', requlred: false },
  },
  emits: ['update:model', 'click'],
  setup (props, context) {
    const commonUtils = inject('commonUtils')
    const onClick = (e) => {
      const isChecked = e.target.checked
      context.emit('update:model', isChecked ? props.value : props.falseValue)
      context.emit('click', isChecked ? props.value : props.falseValue)
    }


    return {
      onClick,
      commonUtils,
    }
  }
}
</script>