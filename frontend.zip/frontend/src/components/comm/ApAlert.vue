<template>
  <div :class="alertInfo.isOpen ? 'modal-backdrop modal-alert-backdrop fade in' : ''"></div>
  <div class="modal modal-alert fade in" v-show="alertInfo.isOpen">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-body">
          <div class="modal-cont-msg" :style="`text-align: ${alertInfo?.textAlign ?? ''}`">
            <p class="tit" v-html="commonUtils.removeXSS(alertInfo.message)"></p>
          </div>
          <div v-if="alertInfo.type === 'ALERT'" class="btn-wrap">
            <button type="button"
                @click="onOk()"
                class="ui-button ui-button__bg--blue"
            >
              {{ alertInfo.alertOk !== undefined ? alertInfo.alertOk : alertOk }}
            </button>
          </div>
          <div v-else-if="alertInfo.type === 'CONFIRM'" class="btn-wrap">
            <button type="button"
                @click="onCancel()"
                class="ui-button ui-button__bg--lightgray"
            >
              {{ alertInfo.confirmCancel !== undefined ? alertInfo.confirmCancel : confirmCancel }}
            </button>
            <button type="button"
                @click="onConfirm()"
                class="ui-button ui-button__bg--blue ml-3"
            >
              {{ alertInfo.confirmOk !== undefined ? alertInfo.confirmOk : confirmOk }}
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { computed, ref, inject } from 'vue'
import { useStore, useActions } from 'vuex-composition-helpers'

export default {
  name: 'ApAlert',
  setup() {
    const commonUtils = inject('commonUtils')
    const t = inject('t')
    const store = useStore()
    const alertInfo = computed(() => store.getters.getAlertInfo())
    const { closeAsyncConfirm, closeAsyncAlert } = useActions(['closeAsyncConfirm', 'closeAsyncAlert'])
    const alertOk = ref(t('common.label.alert_ok'))
    const confirmOk = ref(t('common.label.confirm_ok'))
    const confirmCancel = ref(t('common.label.confirm_cancel'))

    const onConfirm = () => {
      closeAsyncConfirm('OK')
    }
    const onCancel = () => {
      closeAsyncConfirm('CANCEL')
    }
    const onOk = () => {
      closeAsyncAlert()
    }

    return {
      commonUtils,
      t,
      alertInfo,
      alertOk,
      confirmOk,
      confirmCancel,
      onOk,
      onCancel,
      onConfirm
    }
  }
}
</script>
