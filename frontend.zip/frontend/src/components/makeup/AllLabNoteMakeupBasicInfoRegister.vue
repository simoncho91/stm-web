<template>
  <div class="arrordion-item is-active">
    <div class="arrordion-header">
      <div class="arrordion-title">내용물 개요</div>
      <button type="button" class="ui-button__accordion"></button>
    </div>
    <div class="arrordion-body">
      <div class="basic-info__table">
        <table class="ui-table__contents">
          <colgroup>
            <col style="width:17rem">
            <col style="width:auto">
            <col style="width:17rem">
            <col style="width:auto">
          </colgroup>
          <tbody>
            <tr class="tr_vertical">
              <th>브랜드<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td>
                <template v-if="flagAction === 'R' || (regParams.vBsmUserid === myInfo.loginId || regParams.vIsLabNoteAdmin === 'Y' )">
                  <div class="form-flex">
                    <div class="ui-select-box form-flex__cell--5" id="error_wrap_vBrdCd">
                      <ap-selectbox
                        v-model:value="regParams.vBrdCd"
                        :input-class="['ui-select__width--full', 'min-187']"
                        :options="codeGroupMaps['LAB_NOTE_BRAND']"
                        @change="fnValidate('vBrdCd');changePerfUser();"
                      >
                      </ap-selectbox>
                      <span class="error-msg" id="error_msg_vBrdCd"></span>
                    </div>
                    <div class="form-flex__cell--5">
                      <ap-input-check
                        v-model:model="regParams.vFlagOem"
                        id="flagOem"
                        value="Y"
                        label="OEM"
                      >
                      </ap-input-check>
                    </div>
                    <div class="ui-select-box form-flex__cell--5" v-if="regParams.vFlagOem === 'Y'">
                      <ap-input
                        v-model:value="regParams.vOemManufacturer"
                        :maxlength="200"
                      >
                      </ap-input>
                    </div>
                  </div>
                  <p class="p_caution">* 브랜드 지정 시 향 담당자도 자동으로 등록됩니다.</p>
                </template>
                <div class="form-flex" v-else>
                  <div class="form-flex__cell--5">{{ regParams.vBrdNm }}</div>
                  <div class="form-flex__cell--5">
                    <ap-input-check
                      v-model:model="regParams.vFlagOem"
                      id="flagOem"
                      value="Y"
                      label="OEM"
                      :disabled="true"
                    >
                    </ap-input-check>
                    <div class="form-flex__cell--5" v-if="regParams.vFlagOem === 'Y'">
                      {{ regParams.vOemManufacturer }}
                    </div>
                  </div>
                </div>
              </td>
              <th>플랜트<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td>
                <div class="form-flex" :class="flagAction === 'R' ? 'form-flex-error' : ''">
                  <div class="ui-select-box ui-form-box__width--200 form-flex__cell--5" id="error_wrap_vPlantCd" v-if="flagAction === 'R'">
                    <ap-selectbox
                      v-model:value="regParams.vPlantCd"
                      input-class="ui-select__width--full"
                      :options="codeGroupMaps['LAB_NOTE_PLANT']"
                      @change="fnValidate('vPlantCd');changePlantCd(regParams.vPlantCd);"
                    >
                    </ap-selectbox>
                    <span class="error-msg" id="error_msg_vPlantCd"></span>
                  </div>
                  <div class="form-flex__cell--5" v-else>
                    <span class="span_plant">{{ regParams.vPlantNm }} / </span>
                  </div>
                  <div class="ui-select-box ui-form-box__width--200 form-flex__cell--5" id="error_wrap_vSiteType">
                    <ap-selectbox
                      v-if="codeGroupMaps['MA_PLANT']"
                      v-model:value="regParams.vSiteType"
                      input-class="ui-select__width--full"
                      :options="codeGroupMaps['MA_PLANT'].filter(item => item.vBuffer1 === (commonUtils.isEmpty(regParams.vPlantCd) ? 'CN20' : regParams.vPlantCd))"
                      @change="fnValidate('vSiteType');changeSiteType(regParams.vSiteType);"
                    >
                    </ap-selectbox>
                    <span class="error-msg" id="error_msg_vSiteType"></span>
                  </div>
                </div>
              </td>
            </tr>
            <tr>
              <th style="vertical-align: top;">내용물 정보<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td colspan="3">
                <p class="p_caution">대표홋수 선정 기준</p>
                <p class="p_caution_sub"> - 주로 실험 진행할 홋수로 선정</p>
                <p class="p_caution">내용물명 작성 시 기준</p>
                <p class="p_caution_sub"> - 표기순서 1.(기) 2. (PF)/(검출)/(무방부) 3.(ECO)/(무향)/(이층상)</p>
                <p class="p_caution_sub"> - 약자: 단일기능성: (기), 이중기능성: (기2), 삼중기능성: (기3), 파라벤 프리: (PF), 파라벤 소구: (검출), 유기농 인증: (ECO), 무방부: 소구 상관없이 (무방부), 무향: (무향)</p>
                <p class="p_caution_sub"> - [ ] 괄호사용 금지, ECO는 대문자 표기</p>
              </td>
            </tr>
            <tr>
              <td colspan="4">
                <div class="search-result-table">
                  <table class="ui-table__reset ui-table__search-result text-center">
                    <colgroup>
                      <col width="5.5%">
                      <col width="11%">
                      <col width="6.5%">
                      <col width="9.5%">
                      <col width="*">
                      <col width="8.8%">
                      <col width="22%">
                      <col width="9%">
                      <col width="6.8%">
                    </colgroup>
                    <thead>
                      <tr>
                        <th :rowspan="rowspanCnt">대표홋수</th>
                        <th :rowspan="rowspanCnt">제품코드</th>
                        <th :rowspan="rowspanCnt">내용물코드</th>
                        <th :rowspan="rowspanCnt">별칭</th>
                        <th>내용물명<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
                        <th :rowspan="rowspanCnt">조색 내용물코드</th>
                        <th :rowspan="rowspanCnt">조색 내용물명</th>
                        <th :rowspan="rowspanCnt">조색담당자<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
                        <th :rowspan="rowspanCnt">
                          <button
                            type="button"
                            class="ui-button ui-button__width--70 ui-button__height--23 ui-button__radius--2 ui-button__border--blue"
                            @click="addContEvent()"
                          >추가</button>
                        </th>
                      </tr>
                      <tr v-if="showNoteContNmArea()">
                        <th>실험노트 제품명</th>
                      </tr>
                    </thead>
                    <tbody>
                      <template v-for="(vo, idx) in regParams.contList" :key="'cont_' + idx">
                        <tr :class="vo.vFlagCancel === 'Y' ? 'cancel_area' : ''">
                          <td :rowspan="rowspanCnt">
                            <template v-if="regParams.vStatusCd === 'LNC06_01' || flagAction === 'R'">
                              <ap-input-radio
                                v-model:model="vo.vFlagRepresent"
                                value="Y"
                                false-value="N"
                                name="vFlagRepresent"
                                :id="'vFlagRepresent_' + idx"
                                @click="fnChangeRepresentEvent()"
                              >
                              </ap-input-radio>
                            </template>
                            <template v-else-if="vo.vFlagRepresent === 'Y'">
                              √
                            </template>
                          </td>
                          <template v-if="vo.vFlagCancel === 'Y'">
                            <td :rowspan="rowspanCnt">{{ vo.vPrdCd }}</td>
                            <td :rowspan="rowspanCnt">{{ vo.vContCd }}</td>
                            <td :rowspan="rowspanCnt">{{ vo.vTctnBynmNm }}</td>
                            <td>{{ vo.vContNm }} - (개발취소)</td>
                            <td :rowspan="rowspanCnt">{{ vo.vHal4ContCd }}</td>
                            <td :rowspan="rowspanCnt">{{ vo.vHal4ContNm }}</td>
                            <td :rowspan="rowspanCnt">{{ vo.vUsernm }}</td>
                            <td :rowspan="rowspanCnt">
                              <button
                                type="button"
                                class="ui-button ui-button__width--70 ui-button__height--23 ui-button__radius--2 ui-button__bg--blue"
                                @click="fnContDevelopFlagChange(vo, 'RESTART')"
                              >개발재개</button>
                            </td>
                          </template>
                          <template v-else>
                            <td :rowspan="rowspanCnt" class="t-left">
                              <div class="search-form" :id="'error_wrap_vPrdCd' + idx">
                                <div class="search-form__inner">
                                  <ap-input
                                    v-model:value="vo.vPrdCd"
                                    input-class="w97"
                                    :readonly="true"
                                    @click="fnProdSearchPop(idx)"
                                  >
                                  </ap-input>
                                  <button type="button"
                                    class="ui-button__circle ui-button__close input-close-btn--1"
                                    @click="removePrdCd(idx)"
                                  ></button>
                                </div>
                                <span class="error-msg" :id="'error_msg_vPrdCd' + idx"></span>
                              </div>
                            </td>
                            <td :rowspan="rowspanCnt">{{ vo.vContCd }}</td>
                            <td :rowspan="rowspanCnt">
                              <ap-input
                                input-class="w97"
                                v-model:value="vo.vTctnBynmNm"
                                :maxLength="5"
                              >
                              </ap-input>
                            </td>
                            <td class="t-left">
                              <div :id="'error_wrap_vContNm' + idx">
                                <ap-input
                                  v-model:value="vo.vContNm"
                                  input-class="w97"
                                  :maxLength="200"
                                >
                                </ap-input>
                                <span class="error-msg" :id="'error_msg_vContNm' + idx"></span>
                              </div>
                            </td>
                            <td :rowspan="rowspanCnt">{{ vo.vHal4ContCd }}</td>
                            <td :rowspan="rowspanCnt" class="t-left">
                              <div class="form-flex">
                                <ap-input-check
                                  v-model:model="vo.vFlagExistsHal4"
                                  value="Y"
                                  false-value=""
                                  :id="'flag_exists_hal4' + idx"
                                  label="신규조색"
                                >
                                </ap-input-check>
                                <ap-input
                                  v-if="vo.vFlagExistsHal4 === 'Y'"
                                  v-model:value="vo.vHal4ContNm"
                                  :maxlength="200"
                                >
                                </ap-input>
                              </div>
                            </td>
                            <td :rowspan="rowspanCnt" class="t-left">
                              <div class="search-form" :id="'error_wrap_vUserid' + idx">
                                <div class="search-form__inner">
                                  <ap-input
                                    v-model:value="vo.vUsernm"
                                    input-class="w97"
                                    :readonly="true"
                                    @click="fnUserSearchPop(idx)"
                                  >
                                  </ap-input>
                                  <button type="button"
                                    class="ui-button__circle ui-button__close input-close-btn--1"
                                    @click="removeUser(vo)"
                                  ></button>
                                </div>
                                <span class="error-msg" :id="'error_msg_vUserid' + idx"></span>
                              </div>
                            </td>
                            <td :rowspan="rowspanCnt">
                              <button
                                v-if="commonUtils.isEmpty(vo.vContCd)"
                                type="button"
                                class="ui-button ui-button__width--70 ui-button__height--23 ui-button__radius--2 ui-button__border--blue"
                                @click="delContEvent(idx)"
                              >삭제</button>
                              <button
                                v-if="vo.vFlagRepresent !== 'Y' && commonUtils.isNotEmpty(vo.vContCd)"
                                type="button"
                                class="ui-button ui-button__width--70 ui-button__height--23 ui-button__radius--2 ui-button__bg--blue"
                                @click="fnContDevelopFlagChange(vo, 'CANCEL')"
                              >개발취소</button>
                            </td>
                          </template>
                        </tr>
                        <template v-if="showNoteContNmArea()">
                          <tr>
                            <td v-if="vo.vFlagCancel === 'Y'">
                              {{ vo.vNoteContNm }}
                            </td>
                            <td v-else>
                              <ap-input
                                v-model:value="vo.vNoteContNm"
                                :maxlength="200"
                              >
                              </ap-input>
                            </td>
                          </tr>
                        </template>
                      </template>
                    </tbody>
                  </table>
                </div>
              </td>
            </tr>
            <tr>
              <th>예산코드<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td>
                <div class="search-form" id="error_wrap_pjtList">
                  <div class="search-form__inner">
                    <ap-input
                      v-model:value="searchParams.ptsProjectKeyword"
                      input-class="ui-input__width--340"
                      placeholder="검색어를 입력하세요."
                    >
                    </ap-input>
                    <button type="button" class="button-search" @click="fnSearchPtsProjectPop">검색</button>
                  </div>
                  <span class="error-msg" id="error_msg_pjtList"></span>
                </div>
              </td>
            </tr>
            <tr v-if="regParams.pjtList.length > 0">
              <th></th>
              <td colspan="3">
                <div class="search-result-table">
                  <table class="ui-table__reset ui-table__search-result text-center">
                    <colgroup>
                      <col style="width:15rem"/>
                      <col style="width:15rem"/>
                      <col style="width:15rem"/>
                      <col style="width:auto"/>
                      <col style="width:5rem"/>
                    </colgroup>
                    <thead>
                      <tr>
                        <th>예산코드</th>
                        <th>과제유형</th>
                        <th>과제성격</th>
                        <th>과제명</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-for="(vo, index) in regParams.pjtList" :key="'pjt_' + index">
                        <td>{{ vo.vRpmsCd }}</td>
                        <td>{{ vo.vPjtType2Nm }}</td>
                        <td>{{ vo.vPjtTag }}</td>
                        <td>{{ vo.vPjtNm }}</td>
                        <td>
                          <div class="ui-buttons ui-buttons__order ui-buttons__center">
                            <button type="button" class="ui-button ui-button__circle ui-button__close" @click="removePtsProject(index)"></button>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </td>
            </tr>
            <tr>
              <th>제품유형<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td>
                <div class="form-flex form-flex-error">
                  <div
                    class="ui-select-box form-flex__cell--5"
                    :class="'ui-form-box__width--' + ((regParams.vProdType2Cd !== '' && Number(regParams.vProdType2Cd.replace('MTR02_', '')) > 90) ? '150' : '200')"
                    id="error_wrap_vProdType1Cd"
                  >
                    <ap-selectbox
                      v-model:value="regParams.vProdType1Cd"
                      input-class="ui-select__width--full"
                      :options="codeGroupMaps['MTR01'] ? 
                                codeGroupMaps['MTR01'].filter(item => item.vBuffer1 === 'MU') : []"
                      @change="fnValidate('vProdType1Cd');changeProdType1Cd(regParams.vProdType1Cd);"
                    >
                    </ap-selectbox>
                    <span class="error-msg" id="error_msg_vProdType1Cd"></span>
                  </div>
                  <div
                    class="ui-select-box form-flex__cell--5"
                    :class="'ui-form-box__width--' + ((regParams.vProdType2Cd !== '' && Number(regParams.vProdType2Cd.replace('MTR02_', '')) > 90) ? '150' : '200')"
                    id="error_wrap_vProdType2Cd"
                  >
                    <ap-selectbox
                      v-model:value="regParams.vProdType2Cd"
                      input-class="ui-select__width--full"
                      :options="regParams.vProdType1Cd !== '' && codeGroupMaps['MTR02'] ?  codeGroupMaps['MTR02'].filter(item => item.vBuffer1 === regParams.vProdType1Cd) : []"
                      @change="fnValidate('vProdType2Cd');changeProdType2Cd(regParams.vProdType2Cd);"
                    >
                    </ap-selectbox>
                    <span class="error-msg" id="error_msg_vProdType2Cd"></span>
                  </div>
                  <div
                    v-if="regParams.vProdType2Cd !== '' && Number(regParams.vProdType2Cd.replace('MTR02_', '')) > 90"
                    class="ui-select-box ui-form-box__width--150 form-flex__cell--5"
                  >
                    <ap-input
                      v-model:value="regParams.vProdTypeNote"
                      :maxlength="200"
                    >
                    </ap-input>
                  </div>
                </div>
              </td>
              <th>TDD 제품유형<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td>
                <div class="form-flex form-flex-error">
                  <div class="ui-select-box ui-form-box__width--200 form-flex__cell--5" id="error_wrap_vTddProdType1Cd">
                    <ap-selectbox
                      v-model:value="regParams.vTddProdType1Cd"
                      input-class="ui-select__width--full"
                      :options="tddProdType1List"
                      codeKey="vClassCd"
                      codeNmKey="vClassNm"
                      @change="fnValidate('vTddProdType1Cd');getTddProdType2List(regParams.vTddProdType1Cd);"
                    >
                    </ap-selectbox>
                    <span class="error-msg" id="error_msg_vTddProdType1Cd"></span>
                  </div>
                  <div class="ui-select-box ui-form-box__width--200 form-flex__cell--5" id="error_wrap_vTddProdType2Cd">
                    <ap-selectbox
                      v-model:value="regParams.vTddProdType2Cd"
                      input-class="ui-select__width--full"
                      :options="tddProdType2List.length > 0 ? tddProdType2List : []"
                      codeKey="vClassCd"
                      codeNmKey="vClassNm"
                      @change="fnValidate('vTddProdType2Cd');"
                    >
                    </ap-selectbox>
                    <span class="error-msg" id="error_msg_vTddProdType2Cd"></span>
                  </div>
                </div>
              </td>
            </tr>
            <tr>
              <th>신상품 여부<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td>
                <div class="ui-radio__list" id="error_wrap_vFlagNew">
                  <div class="ui-radio__inner">
                    <ap-input-radio
                      v-model:model="regParams.vFlagNew"
                      v-for="(vo, index) in [{vSubCode: 'Y', vSubCodenm: 'NEW'}, {vSubCode: 'N', vSubCodenm: 'AD'}]" :key="'flagNew_' + index"
                      :value="vo.vSubCode"
                      :label="vo.vSubCodenm"
                      :id="'flagNew_' + index"
                      name="flagNew"
                      @click="fnValidate('vFlagNew')"
                    ></ap-input-radio>
                  </div>
                  <span class="error-msg" id="error_msg_vFlagNew"></span>
                </div>
              </td>
              <th>자재그룹<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td>
                <div class="form-flex form-flex-error" v-if="commonUtils.isNotEmpty(regParams.vProdType2Cd)">
                  <div 
                    class="ui-select-box ui-form-box__width--200 form-flex__cell--5"
                    id="error_wrap_vMaterialGroupCd"
                    v-if="mgList.length > 1"
                  >
                    <ap-selectbox
                      v-model:value="regParams.vMaterialGroupCd"
                      input-class="ui-select__width--full"
                      :options="mgList"
                      @change="fnValidate('vMaterialGroupCd');"
                    >
                    </ap-selectbox>
                    <span class="error-msg" id="error_msg_vMaterialGroupCd"></span>
                  </div>
                  <div v-else-if="mgList.length === 1">
                    {{ mgList[0].vSubCodenm }}
                  </div>
                </div>
              </td>
            </tr>
            <tr>
              <th>적용 부위<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td>
                <div class="form-flex form-flex-error">
                  <div class="ui-select-box ui-form-box__width--200 form-flex__cell--5" id="error_wrap_vPartCd">
                    <ap-selectbox
                      v-model:value="regParams.vPartCd"
                      input-class="ui-select__width--full"
                      :options="codeGroupMaps['TR_INDICATIO_PART']"
                      @change="fnValidate('vPartCd');"
                    >
                    </ap-selectbox>
                    <span class="error-msg" id="error_msg_vPartCd"></span>
                  </div>
                </div>
              </td>
              <th>용기정보</th>
              <td>
                <div class="form-flex">
                  <div class="ui-select-box ui-form-box__width--200  form-flex__cell--5">
                    <ap-selectbox
                      v-model:value="regParams.vContainerCd"
                      input-class="ui-select__width--full"
                      :options="codeGroupMaps['LNC26']"
                    >
                    </ap-selectbox>
                  </div>
                  <div class="ui-select-box ui-form-box__width--200  form-flex__cell--5">
                    <ap-input
                      v-model:value="regParams.vContainerEtc"
                      :maxlength="300"
                      input-class="ui-input__width--full"
                    >
                    </ap-input>
                  </div>
                </div>
              </td>
            </tr>
            <tr>
              <th>출시국가/시기<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
            </tr>
            <tr>
              <td colspan="4" class="inside-td inside-td__nation">
                <table class="ui-table__contents">
                  <colgroup>
                    <col style="width:14rem">
                  </colgroup>
                  <tbody>
                    <tr
                      v-for="(key, index) in Object.keys(releaseMap)"
                      :key="'countryList_' + index"
                      class="ui-table__contents--item"
                    >
                      <th>{{ releaseMap[key].ariaNm }}</th>
                      <td :id="'error_wrap_releaseInfo' + key">
                        <div class="clearfix">
                          <div class="clearfix_inner" v-show="regParams['vFlagRelease' + key] !== 'U'">
                            <ap-input-check
                              v-model:model="regParams['vFlagRelease' + key]"
                              value="N"
                              label="대상아님"
                              :id="key + '_none'"
                              @click="fnValidate('releaseInfo' + key);checkReleaseDtGroup(regParams['vFlagRelease' + key], key)"
                            >
                            </ap-input-check>
                          </div>
                          <div class="clearfix_inner" v-show="regParams['vFlagRelease' + key] !== 'N'">
                            <ap-input-check
                              v-model:model="regParams['vFlagRelease' + key]"
                              value="U"
                              label="미정"
                              :id="key + '_undecided'"
                              @click="fnValidate('releaseInfo' + key);checkReleaseDtGroup(regParams['vFlagRelease' + key], key)"
                            >
                            </ap-input-check>
                          </div>
                          <div class="clearfix_wide d-flex" v-show="regParams['vFlagRelease' + key] !== 'N' && regParams['vFlagRelease' + key] !== 'U'">
                            <ap-input-check
                              v-model:model="regParams['vFlagReleaseAll' + key]"
                              value="Y"
                              label="전체선택"
                              :id="key + '_all'"
                              @click="checkReleaseAll(regParams['vFlagReleaseAll' + key], key);fnValidate('releaseInfo' + key);"
                            >
                            </ap-input-check>
                            <ap-month-picker
                              v-if="regParams['vFlagReleaseAll' + key] === 'Y'"
                              v-model:date="regParams['vReleaseAllDt' + key]"
                              @update:date="changeReleaseAllDt(regParams['vReleaseAllDt' + key], regParams['vFlagReleaseAll' + key], key);fnValidate('releaseInfo' + key);"
                            >
                            </ap-month-picker>
                          </div>
                        </div>
                        <div class="clearfix" v-if="regParams['vFlagRelease' + key] !== 'N' && regParams['vFlagRelease' + key] !== 'U'">
                          <template v-if="releaseMap[key].countryList" >
                            <div
                              v-for="(vo, idx) in releaseMap[key].countryList"
                              :key="key + '_' + idx"
                              class="clearfix_inner"
                              :class="vo.vSubCode === 'LNC02_04' ? 'clearfix_wide' : ''"
                            >
                              <ap-input-check
                                v-model:model="vo.vTag2Cd"
                                :value="vo.vSubCode"
                                :label="vo.vSubCodenm"
                                :id="key + '_' + idx"
                                @click="fnValidate('releaseInfo' + key);checkReleaseInfo(key)"
                              >
                              </ap-input-check>
                              <template v-if="vo.vSubCode !== 'LNC02_04'">
                                <ap-month-picker
                                  v-if="commonUtils.isNotEmpty(vo.vTag2Cd)"
                                  v-model:date="vo.vTagBuffer1"
                                  @update:date="fnValidate('releaseInfo' + key);"
                                >
                                </ap-month-picker>
                              </template>
                              <template v-else>
                                <div class="form-flex" v-if="commonUtils.isNotEmpty(vo.vTag2Cd)">
                                  <div class="form-flex__cell--5">
                                    <ap-month-picker
                                      v-model:date="vo.vTagBuffer1"
                                      @update:date="fnValidate('releaseInfo' + key);"
                                    >
                                    </ap-month-picker>
                                  </div>
                                  <div class="form-flex__cell--5">
                                    <ap-input
                                      v-if="vo.vSubCode === 'LNC02_04'"
                                      v-model:value="vo.vTagBuffer2"
                                    >
                                    </ap-input>
                                  </div>
                                </div>
                              </template>
                            </div>
                          </template>
                        </div>
                        <span class="error-msg" :id="'error_msg_releaseInfo' + key"></span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
            <tr>
              <th>파일럿</th>
              <td>
                <ap-month-picker
                  v-model:date="regParams.vPilotDt"
                  input-class="div_width--200"
                >
                </ap-month-picker>
              </td>
              <th>생산회의</th>
              <td>
                <ap-month-picker
                  v-model:date="regParams.vMeetingDt"
                  input-class="div_width--200"
                >
                </ap-month-picker>
              </td>
            </tr>
            <tr>
              <th>ONE POINT (기술관점)</th>
              <td colspan="3">
                <ap-input
                  v-model:value="regParams.vOnePointTech"
                  :maxlength="200"
                >
                </ap-input>
              </td>
            </tr>
            <tr>
              <th>비고</th>
              <td colspan="3">
                <div class="ui-textarea-box" id="error_wrap_vNote">
                  <ap-text-area
                    v-model:value="regParams.vNote"
                    :is-with-byte="true"
                    :maxlength="2000"
                    id="vNote"
                  ></ap-text-area>
                  <span class="error-msg" id="error_msg_vNote"></span>
                </div>
              </td>
            </tr>
            <tr>
              <th>첨부파일</th>
              <td colspan="3">
                <UploadFileRegister
                  uploadid="MAKEUP_NOTE_ATT01"
                  :parent-info="uploadParams"
                >
                </UploadFileRegister>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @selectFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, reactive, ref, inject, watch, computed } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useMakeupRequest } from '@/compositions/makeup/useMakeupRequest'
import { useActions } from 'vuex-composition-helpers'
import { useStore } from 'vuex'

export default {
  name: 'AllLabNoteMakeupBasicInfoRegister',
  props: {
    flagAction: {
      type: String,
      default: 'R'
    }
  },
  components: {
    UploadFileRegister: defineAsyncComponent(() => import('@/components/comm/UploadFileRegister.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    PtsProjectSearchPop: defineAsyncComponent(() => import('@/components/labcommon/popup/PtsProjectSearchPop.vue')),
    UserSearchPop: defineAsyncComponent(() => import('@/components/comm/popup/UserSearchPop.vue')),
    ProdSearchPop: defineAsyncComponent(() => import('@/components/labcommon/popup/ProdSearchPop.vue')),
  },
  setup (props) {
    const reqInfo = inject('reqInfo')
    const commonUtils = inject('commonUtils')
    const { openAsyncConfirm, openAsyncAlert } = useActions(['openAsyncConfirm', 'openAsyncAlert'])
    const store = useStore()
    const myInfo = store.getters.getMyInfo()
    const storedNoteInfo = computed(() => store.getters.getNoteInfo())
    const rowspanCnt = ref(1)
    const mgList = ref([])
    let plantCd = ''
    let popIdx = null

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const {
      updateMakeupContFlagDevelopment,
    } = useMakeupRequest()

    const {
      tddProdType1List,
      tddProdType2List,
      selectTddProdTypeList,
      selectLabCodeRequired,
      popupContent,
      popParams,
      popSelectFunc,
      fnChangeNoteInfo,
      fnOpenPopup,
      releaseMap,
    } = useLabCommon()

    const searchParams = reactive({
      ptsProjectKeyword: ''
    })

    const regParams = ref({
      vBrdCd: '',
      vBrdNm: '',
      vFlagOem: '',
      vOemManufacturer: '',
      vPlantCd: '',
      vSiteType: '',
      contList: [],
      pjtList: [],
      releaseList: [],
      vFlagNew: '',
      vProdType1Cd: '',
      vProdType2Cd: '',
      vProdTypeNote: '',
      vTddProdType1Cd: '',
      vTddProdType2Cd: '',
      vPartCd: '',
      vFlagReleaseASIA: '',
      vFlagReleaseASEAN: '',
      vFlagReleaseETC: '',
      vFlagReleaseAllASIA: '',
      vFlagReleaseAllASEAN: '',
      vFlagReleaseAllETC: '',
      vReleaseAllDtASIA: '',
      vReleaseAllDtASEAN: '',
      vReleaseAllDtETC: '',
      vPilotDt: '',
      vMeetingDt: '',
      vContainerCd: '',
      vContainerEtc: '',
      vIsLabNoteAdmin: '',
      vOnePointTech: '',
      vNote: '',
    })

    const uploadParams = reactive({
      vRecordid: '',
      items: []
    })

    const fnSearchPtsProjectPop = () => {
      popParams.value = {
        vKeyword: searchParams.ptsProjectKeyword
      }

      popSelectFunc.value = getPtsProject
      fnOpenPopup('PtsProjectSearchPop', false)
    }

    const getPtsProject = (selectList) => {
      selectList.forEach(item => {
        if (regParams.value.pjtList.filter(vo => vo.vPjtCd === item.vPjtCd).length === 0) {
          regParams.value.pjtList.push({ ...item })
        }
      })

      fnValidate('pjtList')
    }

    const removePtsProject = (index) => {
      regParams.value.pjtList.splice(index, 1)
      fnValidate('pjtList')
    }

    const getTddProdType2List = (tddProdType1Cd) => {
      regParams.value.vTddProdType2Cd = ''
      selectTddProdTypeList({vClassCd: tddProdType1Cd, vFlagSub: 'Y'}, 'TYPE2')
    }

    const changePlantCd = (selectCode) => {
      const noteInfo = store.getters.getNoteInfo()
      const newInfo = { ...noteInfo, ...{vPlantCd: selectCode} }
      setSiteType()
      fnChangeNoteInfo(newInfo)
    }

    const changeSiteType = (selectCode) => {
      const noteInfo = store.getters.getNoteInfo()
      const newInfo = { ...noteInfo, ...{vSiteType: selectCode} }
      fnChangeNoteInfo(newInfo)
    }

    const changeProdType1Cd = (selectCode) => {
      regParams.value.vProdType2Cd = ''
      const noteInfo = store.getters.getNoteInfo()
      const newInfo = { ...noteInfo, ...{vProdType1Cd: selectCode} }
      fnChangeNoteInfo(newInfo)
    }

    const changePerfUser = () => {
      if (commonUtils.isEmpty(regParams.value.vBrdCd)) {
        return
      }

      const tempInfo = codeGroupMaps.value['LAB_NOTE_BRAND'].filter(item => item.vSubCode === regParams.value.vBrdCd)
      if (tempInfo) {
        const brdInfo = tempInfo[0]
        store.dispatch('setPerfUserid', brdInfo.vContent2)
      }
    }

    const setMgList = (selectCode) => {
      const prodTypeInfo = codeGroupMaps.value['MTR02'].filter(vo => vo.vSubCode === selectCode)

      if (prodTypeInfo) {
        const buffer2 = prodTypeInfo[0].vBuffer2

        if (buffer2 !== 'ALL') {
          mgList.value = [ ...codeGroupMaps.value['LNC24'].filter(item => buffer2.indexOf(item.vSubCode) > -1) ]
        } else {
          mgList.value = [ ...codeGroupMaps.value['LNC24']]
        }

        if (mgList.value && mgList.value.length === 1) {
          regParams.value.vMaterialGroupCd = mgList.value[0].vSubCode
        }
      }
    }

    const changeProdType2Cd = (selectCode) => {
      regParams.value.vMaterialGroupCd = ''
      setMgList(selectCode)

      const noteInfo = store.getters.getNoteInfo()
      const newInfo = { ...noteInfo, ...{vProdType2Cd: selectCode} }
      fnChangeNoteInfo(newInfo)
    }

    const setSiteType = () => {
      const siteOption = codeGroupMaps.value['MA_PLANT'].filter(item => item.vBuffer1 === (commonUtils.isEmpty(regParams.value.vPlantCd) ? 'CN20' : regParams.value.vPlantCd))
      regParams.value.vSiteType = siteOption.length === 1 ? siteOption[0].vSubCode : ''
    }

    const checkReleaseDtGroup = (value, key) => {
      if (value === 'N' || value === 'U') {
        regParams.value['vFlagReleaseAll' + key] = ''
        regParams.value['vReleaseAllDt' + key] = ''
        releaseMap.value[key].countryList.forEach(item => {
          item.vTag2Cd = ''
          item.vTagBuffer1 = ''
          item.vTagBuffer2 = ''
        })
      }
    }

    const checkReleaseAll = (value, key) => {
      if (value === 'Y') {
        releaseMap.value[key].countryList.forEach(item => {
          item.vTag2Cd = item.vSubCode
        })
      } else {
        releaseMap.value[key].countryList.forEach(item => {
          item.vTag2Cd = ''
          item.vTagBuffer1 = ''
        })
      }
    }

    const changeReleaseAllDt = (ym, value, key) => {
      if (value === 'Y') {
        releaseMap.value[key].countryList.forEach(item => {
          item.vTagBuffer1 = ym
        })
      }
    }

    const checkReleaseInfo = (key) => {
      const countryList = releaseMap.value[key].countryList
      const allLength = countryList.length
      const checkedLength = countryList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)).length

      if (allLength === checkedLength) {
        regParams.value['vFlagReleaseAll' + key] = 'Y'
      } else {
        regParams.value['vFlagReleaseAll' + key] = 'N'
      }

      regParams.value['vReleaseAllDt' + key] = ''
    }

    const fnValidateAll = (arrChkKey) => {
      let isOk = true
      commonUtils.hideErrorMessageAll(arrChkKey)

      arrChkKey.forEach(key => {
        if (!fnValidate(key)) {
          isOk = false
        }
      })

      return isOk
    }

    const fnValidate = (key) => {
      let isOk = true
      let errorMsg = '필수 입력 사항입니다.'
      commonUtils.hideErrorMessage(key)

      if (key === 'pjtList') {
        if (regParams.value.pjtList.length === 0) {
          isOk = false
        }
      } else if (key === 'contList') {
        const contList = regParams.value.contList

        contList.forEach((item, idx) => {
          commonUtils.hideErrorMessage('vContNm' + idx)
          commonUtils.hideErrorMessage('vUserid' + idx)

          if (commonUtils.isEmpty(item.vContNm)) {
            isOk = false
            commonUtils.showErrorMessage('vContNm' + idx, errorMsg)
          }

          if (commonUtils.isEmpty(item.vUserid)) {
            isOk = false
            commonUtils.showErrorMessage('vUserid' + idx, errorMsg)
          }
        })
      } else if (key === 'releaseInfoASIA') {
        const countryLen = releaseMap.value['ASIA'].countryList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)).length
        const releaseDtLen = releaseMap.value['ASIA'].countryList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd) && commonUtils.isEmpty(item.vTagBuffer1)).length

        if (commonUtils.isEmpty(regParams.value.vFlagReleaseASIA) && countryLen === 0) {
          isOk = false
          errorMsg = '출시지역을 선택해 주세요.'
        } else if (commonUtils.isEmpty(regParams.value.vFlagReleaseASIA) && countryLen > 0 && releaseDtLen > 0) {
          isOk = false
          errorMsg = '출시시기를 입력해 주세요.'
        }
      } else if (key === 'releaseInfoASEAN') {
        const countryLen = releaseMap.value['ASEAN'].countryList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)).length
        const releaseDtLen = releaseMap.value['ASEAN'].countryList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd) && commonUtils.isEmpty(item.vTagBuffer1)).length

        if (commonUtils.isEmpty(regParams.value.vFlagReleaseASEAN) && countryLen === 0) {
          isOk = false
          errorMsg = '출시지역을 선택해 주세요.'
        } else if (commonUtils.isEmpty(regParams.value.vFlagReleaseASEAN) && countryLen > 0 && releaseDtLen > 0) {
          isOk = false
          errorMsg = '출시시기를 입력해 주세요.'
        }
      } else if (key === 'releaseInfoETC') {
        const countryLen = releaseMap.value['ETC'].countryList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)).length
        const releaseDtLen = releaseMap.value['ETC'].countryList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd) && commonUtils.isEmpty(item.vTagBuffer1)).length
        if (commonUtils.isEmpty(regParams.value.vFlagReleaseETC) && countryLen === 0) {
          isOk = false
          errorMsg = '출시지역을 선택해 주세요.'
        } else if (commonUtils.isEmpty(regParams.value.vFlagReleaseETC) && countryLen > 0 && releaseDtLen > 0) {
          isOk = false
          errorMsg = '출시시기를 입력해 주세요.'
        }
      } else if (key === 'vNote') {
        if (!commonUtils.checkByte(regParams.value.vNote, 2000)) {
          isOk = false
          errorMsg = t('common.msg.byte_msg2', { byteSize: commonUtils.setNumberComma(2000) })
        }
      } else if (commonUtils.isEmpty(regParams.value[key])) {
        isOk = false
      }

      if (!isOk) {
        commonUtils.showErrorMessage(key, errorMsg)
      }

      return isOk
    }
    
    const showNoteContNmArea = () => {
      let isVisible = false
      if (props.flagAction === 'M' && plantCd === 'CN20' && 
            'LNC06_01;LNC06_02;LNC06_03;LNC06_04;LNC06_05;LNC06_06'.indexOf(regParams.value.vStatusCd) === -1) {
        isVisible = true
        rowspanCnt.value = 2
      }

      return isVisible
    }

    const fnUserSearchPop = (index) => {
      popIdx = index

      popParams.value = {
        vKeyword: '',
        searchFlag: 'LAB'
      }

      popSelectFunc.value = getUserSearchInfo
      fnOpenPopup('UserSearchPop')
    }

    const getUserSearchInfo = (item) => {
      regParams.value.contList[popIdx].vUsernm = item.vUsernm
      regParams.value.contList[popIdx].vUserid = item.vUserid
      commonUtils.hideErrorMessage('vUserid' + popIdx)
      popIdx = null
    }

    const removeUser = (item) => {
      item.vUsernm = ''
      item.vUserid = ''
    }

    const fnProdSearchPop = (index) => {
      popIdx = index
      popParams.value = {
        vKeyword: ''
      }

      popSelectFunc.value = getProdInfo
      fnOpenPopup('ProdSearchPop')
    }

    const getProdInfo = (item) => {
      regParams.value.contList[popIdx].vPrdCd = item.vPrdCd
      popIdx = null
    }

    const removePrdCd = (index) => {
      regParams.value.contList[index].vPrdCd = ''
    }

    const addContEvent = () => {
      const obj = {
        vPrdCd: '',
        vContCd: '',
        vContNm: '',
        vNoteContNm: '',
        vUserid: '',
        vUsernm: '',
        vFlagRepresent: regParams.value.contList.length === 0 ? 'Y' : 'N',
        vFlagExistsHal4: '',
        vHal4contPkCd: '',
        vHal4ContCd: '',
        vHal4ContNm: '',
        newYn: 'Y'
      }

      regParams.value.contList.push({ ...obj })
    }

    const delContEvent = (index) => {
      regParams.value.contList.splice(index, 1)

      if (regParams.value.contList.length === 0) {
        addContEvent()
      }
    }

    const fnContDevelopFlagChange = async (item, flag) => {
      const message = '[' + item.vContCd + '] '
                    + commonUtils.checkPostPosition(item.vContNm, ['을', '를'])
                    + ' 개발' + (flag === 'CANCEL' ? '취소' : '재개')
                    + '하시겠습니까?<br>'
                    + '<span class=\'txt_red\'>(내용물 개발취소 외 수정된 부분은 저장이 되지 않습니다.)</span>'

      if (!await openAsyncConfirm({ message })) {
        return
      }

      const vFlagCancel = flag === 'CANCEL' ? 'Y' : 'N'
      const payload = {
        vContCd: item.vContCd,
        vFlagCancel
      }

      const result = await updateMakeupContFlagDevelopment(payload)

      if (result === 'SUCC') {
        await openAsyncAlert({ message: '내용물을 개발 ' + (flag === 'CANCEL' ? '취소' : '재개') + '하였습니다.' })
        item.vFlagCancel = vFlagCancel
      }
    }

    const fnChangeRepresentEvent = () => {
      document.getElementsByName("vFlagRepresent").forEach((item, idx) => {
        if (item.checked) {
          regParams.value.contList[idx].vFlagRepresent = 'Y'
        } else {
          regParams.value.contList[idx].vFlagRepresent = 'N'
        }
      })
    }

    const init = async () => {
      const arrMstCode = [
        'LAB_NOTE_BRAND', 'LAB_NOTE_PLANT', 'MA_PLANT', 'MTR01', 
        'MTR02', 'TR_INDICATIO_PART', 'LNC24', 'LNC26'
      ]
      await findCodeList(arrMstCode)
      selectTddProdTypeList({vNoteType: store.getters.getNoteType()}, 'TYPE1')

      codeGroupMaps.value['LNC24'].forEach(item => {
        item.vSubCodenm = '[' + item.vSubCode + '] ' + item.vSubCodenm
      })

      if (commonUtils.isEmpty(regParams.value.vSiteType)) {
        setSiteType()
      }
    }

    watch(() => reqInfo.value, async (newValue) => {
      await init()
      regParams.value = { ...regParams.value, ...newValue }

      if (regParams.value.releaseList && regParams.value.releaseList.length > 0) {
        regParams.value.releaseList.forEach(item => {
          releaseMap.value[item.vBuffer1].countryList.push({ ...item })
        })
      }

      if (!regParams.value.contList || regParams.value.contList.length === 0) {
        addContEvent()
      }

      if (commonUtils.isNotEmpty(regParams.value.vProdType2Cd)) {
        setMgList(regParams.value.vProdType2Cd)
      }

      if (commonUtils.isNotEmpty(reqInfo.value.vLabNoteCd)) {
        uploadParams.vRecordid = reqInfo.value.vLabNoteCd
      }

      fnChangeNoteInfo(regParams.value)
      selectTddProdTypeList({vClassCd: regParams.value.vTddProdType1Cd, vFlagSub: 'Y'}, 'TYPE2')
      if (commonUtils.isEmpty(regParams.value.vPerfUserid)) {
        changePerfUser()
      }
    })

    watch(() => storedNoteInfo.value, async (newVal) => {
      if (newVal && newVal.vDeptCd) {
        const result = await selectLabCodeRequired({ vDeptCd: newVal.vDeptCd})
        if (result && result.length === 1) {
          getPtsProject(result)
        }
      }
    })

    return {
      myInfo,
      codeGroupMaps,
      releaseMap,
      regParams,
      commonUtils,
      uploadParams,
      searchParams,
      mgList,
      rowspanCnt,
      tddProdType1List,
      tddProdType2List,
      popupContent,
      popParams,
      popSelectFunc,
      fnSearchPtsProjectPop,
      getTddProdType2List,
      changePlantCd,
      changeSiteType,
      changeProdType1Cd,
      changeProdType2Cd,
      changePerfUser,
      removePtsProject,
      checkReleaseDtGroup,
      checkReleaseAll,
      changeReleaseAllDt,
      checkReleaseInfo,
      removePrdCd,
      fnValidateAll,
      fnValidate,
      showNoteContNmArea,
      fnUserSearchPop,
      removeUser,
      fnProdSearchPop,
      addContEvent,
      delContEvent,
      fnContDevelopFlagChange,
      fnChangeRepresentEvent,
    }
  }
}

</script>

<style scoped>
  .ui-table__search-result thead th {
    padding: 1.3rem 1rem;
  }
</style>