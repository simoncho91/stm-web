<template>
  <div class="arrordion-item is-active">
    <div class="arrordion-header">
      <div class="arrordion-title">내용물 개요</div>
      <button type="button" class="ui-button__accordion"></button>
    </div>
    <div class="arrordion-body">
      <div class="basic-info__table">
        <table class="ui-table__contents">
          <colgroup>
            <col style="width:17rem">
            <col style="width:auto">
            <col style="width:17rem">
            <col style="width:auto">
          </colgroup>
          <tbody>
            <tr>
              <th>브랜드<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td>
                <div class="form-flex">
                  <div class="ui-select-box form-flex__cell--5" id="error_wrap_vBrdCd">
                    <ap-selectbox
                      v-model:value="regParams.vBrdCd"
                      :input-class="['ui-select__width--full']"
                      :options="codeGroupMaps['LAB_NOTE_BRAND']"
                      @change="fnValidate('vBrdCd')"
                    >
                    </ap-selectbox>
                    <span class="error-msg" id="error_msg_vBrdCd"></span>
                  </div>
                  <div class="form-flex__cell--5">
                    <ap-input-check
                      v-model:model="regParams.vFlagOem"
                      id="flagOem"
                      value="Y"
                      label="OEM"
                    >
                    </ap-input-check>
                  </div>
                  <div class="ui-select-box form-flex__cell--5" v-if="regParams.vFlagOem === 'Y'">
                    <ap-input
                      v-model:value="regParams.vOemManufacturer"
                      :maxlength="200"
                    >
                    </ap-input>
                  </div>
                </div>
              </td>
              <th>플랜트</th>
              <td>
                {{ regParams.vPlantNm }} / {{ regParams.vSiteTypeNm }}
              </td>
            </tr>
            <tr>
              <th style="vertical-align: top;">내용물 정보<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
            </tr>
            <tr>
              <td colspan="4">
                <div class="search-result-table">
                  <table class="ui-table__reset ui-table__search-result text-center">
                    <colgroup>
                      <col width="5.5%">
                      <col width="11%">
                      <col width="6.5%">
                      <col width="9.5%">
                      <col width="*">
                      <col width="8.8%">
                      <col width="22%">
                      <col width="9%">
                    </colgroup>
                    <thead>
                      <tr>
                        <th :rowspan="rowspanCnt">대표홋수</th>
                        <th :rowspan="rowspanCnt">제품코드</th>
                        <th :rowspan="rowspanCnt">내용물코드</th>
                        <th :rowspan="rowspanCnt">별칭</th>
                        <th>내용물명</th>
                        <th :rowspan="rowspanCnt">조색 내용물코드</th>
                        <th :rowspan="rowspanCnt">조색 내용물명</th>
                        <th :rowspan="rowspanCnt">조색담당자</th>
                      </tr>
                      <tr v-if="showNoteContNmArea()">
                        <th>실험노트 제품명</th>
                      </tr>
                    </thead>
                    <tbody>
                      <template v-for="(vo, idx) in regParams.contList" :key="'cont_' + idx">
                        <tr :class="vo.vFlagCancel === 'Y' ? 'cancel_area' : ''">
                          <td :rowspan="rowspanCnt">
                            <template v-if="vo.vFlagRepresent === 'Y'">
                              √
                            </template>
                          </td>
                          <td :rowspan="rowspanCnt" class="t-left">
                            <template v-if="vo.vFlagCancel === 'Y'">
                              {{ vo.vPrdCd }}
                            </template>
                            <template v-else>
                              <div class="search-form" :id="'error_wrap_vPrdCd' + idx">
                                <div class="search-form__inner">
                                  <ap-input
                                    v-model:value="vo.vPrdCd"
                                    input-class="w97"
                                    :readonly="true"
                                    @click="fnProdSearchPop(idx)"
                                  >
                                  </ap-input>
                                  <button type="button"
                                    class="ui-button__circle ui-button__close input-close-btn--1"
                                    @click="removePrdCd(idx)"
                                  ></button>
                                </div>
                                <span class="error-msg" :id="'error_msg_vPrdCd' + idx"></span>
                              </div>
                            </template>
                          </td>
                          <td :rowspan="rowspanCnt">{{ vo.vContCd }}</td>
                          <td :rowspan="rowspanCnt">별칭</td>
                          <td>{{ vo.vContNm }} {{ vo.vFlagCancel === 'Y' ? '(개발취소)' : '' }}<span class="txt_blue">{{ vo.vFlagLaunch === 'Y' ? '(출시완료)' : '' }}</span></td>
                          <td :rowspan="rowspanCnt">{{ vo.vHal4ContCd }}</td>
                          <td :rowspan="rowspanCnt">{{ vo.vHal4ContNm }}</td>
                          <td :rowspan="rowspanCnt">{{ vo.vUsernm }}</td>
                        </tr>
                        <template v-if="showNoteContNmArea()">
                          <tr :class="vo.vFlagCancel === 'Y' ? 'cancel_area' : ''">
                            <td>
                              {{ vo.vNoteContNm }}
                            </td>
                          </tr>
                        </template>
                      </template>
                    </tbody>
                  </table>
                </div>
              </td>
            </tr>
            <tr>
              <th>제품유형<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td>
                <div class="form-flex form-flex-error">
                  <div
                    class="ui-select-box form-flex__cell--5"
                    :class="'ui-form-box__width--' + ((regParams.vProdType2Cd !== '' && Number(regParams.vProdType2Cd.replace('MTR02_', '')) > 90) ? '150' : '200')"
                    id="error_wrap_vProdType1Cd"
                  >
                    <ap-selectbox
                      v-model:value="regParams.vProdType1Cd"
                      input-class="ui-select__width--full"
                      :options="codeGroupMaps['MTR01'] ? 
                                codeGroupMaps['MTR01'].filter(item => item.vBuffer1 === 'MU') : []"
                      @change="fnValidate('vProdType1Cd');changeProdType1Cd(regParams.vProdType1Cd);"
                    >
                    </ap-selectbox>
                    <span class="error-msg" id="error_msg_vProdType1Cd"></span>
                  </div>
                  <div
                    class="ui-select-box form-flex__cell--5"
                    :class="'ui-form-box__width--' + ((regParams.vProdType2Cd !== '' && Number(regParams.vProdType2Cd.replace('MTR02_', '')) > 90) ? '150' : '200')"
                    id="error_wrap_vProdType2Cd"
                  >
                    <ap-selectbox
                      v-model:value="regParams.vProdType2Cd"
                      input-class="ui-select__width--full"
                      :options="regParams.vProdType1Cd !== '' && codeGroupMaps['MTR02'] ?  codeGroupMaps['MTR02'].filter(item => item.vBuffer1 === regParams.vProdType1Cd) : []"
                      @change="fnValidate('vProdType2Cd');changeProdType2Cd(regParams.vProdType2Cd);"
                    >
                    </ap-selectbox>
                    <span class="error-msg" id="error_msg_vProdType2Cd"></span>
                  </div>
                  <div
                    v-if="regParams.vProdType2Cd !== '' && Number(regParams.vProdType2Cd.replace('MTR02_', '')) > 90"
                    class="ui-select-box ui-form-box__width--150 form-flex__cell--5"
                  >
                    <ap-input
                      v-model:value="regParams.vProdTypeNote"
                      :maxlength="200"
                    >
                    </ap-input>
                  </div>
                </div>
              </td>
              <th>TDD 제품유형<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td>
                <template v-if="commonUtils.isNotEmpty(regParams.vTddProdType1Nm)">
                  {{ regParams.vTddProdType1Nm }} > {{ regParams.vTddProdType2Nm }}
                </template>
              </td>
            </tr>
            <tr>
              <th>신상품 여부<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td>
                <div class="ui-radio__list" id="error_wrap_vFlagNew">
                  <div class="ui-radio__inner">
                    <ap-input-radio
                      v-model:model="regParams.vFlagNew"
                      v-for="(vo, index) in [{vSubCode: 'Y', vSubCodenm: 'NEW'}, {vSubCode: 'N', vSubCodenm: 'AD'}]" :key="'flagNew_' + index"
                      :value="vo.vSubCode"
                      :label="vo.vSubCodenm"
                      :id="'flagNew_' + index"
                      name="flagNew"
                      @click="fnValidate('vFlagNew')"
                    ></ap-input-radio>
                  </div>
                  <span class="error-msg" id="error_msg_vFlagNew"></span>
                </div>
              </td>
              <th>자재그룹<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td>
                {{ regParams.vMaterialGroupNm }}
              </td>
            </tr>
            <tr>
              <th>적용 부위</th>
              <td>
                <div class="form-flex form-flex-error">
                  <div class="ui-select-box ui-form-box__width--200 form-flex__cell--5" id="error_wrap_vPartCd">
                    <ap-selectbox
                      v-model:value="regParams.vPartCd"
                      input-class="ui-select__width--full"
                      :options="codeGroupMaps['TR_INDICATIO_PART']"
                      @change="fnValidate('vPartCd');"
                    >
                    </ap-selectbox>
                    <span class="error-msg" id="error_msg_vPartCd"></span>
                  </div>
                </div>
              </td>
              <th>용기정보</th>
              <td>
                <div class="form-flex">
                  <div class="ui-select-box ui-form-box__width--200  form-flex__cell--5">
                    <ap-selectbox
                      v-model:value="regParams.vContainerCd"
                      input-class="ui-select__width--full"
                      :options="codeGroupMaps['LNC26']"
                    >
                    </ap-selectbox>
                  </div>
                  <div class="ui-select-box ui-form-box__width--200  form-flex__cell--5">
                    <ap-input
                      v-model:value="regParams.vContainerEtc"
                      :maxlength="300"
                      input-class="ui-input__width--full"
                    >
                    </ap-input>
                  </div>
                </div>
              </td>
            </tr>
            <tr>
              <th>출시국가/시기<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
            </tr>
            <tr>
              <td colspan="4" class="inside-td inside-td__nation">
                <table class="ui-table__contents">
                  <colgroup>
                    <col style="width:14rem">
                  </colgroup>
                  <tbody>
                    <tr
                      v-for="(key, index) in Object.keys(releaseMap)"
                      :key="'countryList_' + index"
                      class="ui-table__contents--item"
                    >
                      <th>{{ releaseMap[key].ariaNm }}</th>
                      <td :id="'error_wrap_releaseInfo' + key">
                        <div class="clearfix">
                          <div class="clearfix_inner" v-show="regParams['vFlagRelease' + key] !== 'U'">
                            <ap-input-check
                              v-model:model="regParams['vFlagRelease' + key]"
                              value="N"
                              label="대상아님"
                              :id="key + '_none'"
                              @click="fnValidate('releaseInfo' + key);checkReleaseDtGroup(regParams['vFlagRelease' + key], key)"
                            >
                            </ap-input-check>
                          </div>
                          <div class="clearfix_inner" v-show="regParams['vFlagRelease' + key] !== 'N'">
                            <ap-input-check
                              v-model:model="regParams['vFlagRelease' + key]"
                              value="U"
                              label="미정"
                              :id="key + '_undecided'"
                              @click="fnValidate('releaseInfo' + key);checkReleaseDtGroup(regParams['vFlagRelease' + key], key)"
                            >
                            </ap-input-check>
                          </div>
                          <div class="clearfix_wide d-flex" v-show="regParams['vFlagRelease' + key] !== 'N' && regParams['vFlagRelease' + key] !== 'U'">
                            <ap-input-check
                              v-model:model="regParams['vFlagReleaseAll' + key]"
                              value="Y"
                              label="전체선택"
                              :id="key + '_all'"
                              @click="fnValidate('releaseInfo' + key);checkReleaseAll(regParams['vFlagReleaseAll' + key], key)"
                            >
                            </ap-input-check>
                            <ap-month-picker
                              v-if="regParams['vFlagReleaseAll' + key] === 'Y'"
                              v-model:date="regParams['vReleaseAllDt' + key]"
                              @update:date="changeReleaseAllDt(regParams['vReleaseAllDt' + key], regParams['vFlagReleaseAll' + key], key);fnValidate('releaseInfo' + key);"
                            >
                            </ap-month-picker>
                          </div>
                        </div>
                        <div class="clearfix" v-if="regParams['vFlagRelease' + key] !== 'N' && regParams['vFlagRelease' + key] !== 'U'">
                          <template v-if="releaseMap[key].countryList" >
                            <div
                              v-for="(vo, idx) in releaseMap[key].countryList"
                              :key="key + '_' + idx"
                              class="clearfix_inner"
                              :class="vo.vSubCode === 'LNC02_04' ? 'clearfix_wide' : ''"
                            >
                              <ap-input-check
                                v-model:model="vo.vTag2Cd"
                                :value="vo.vSubCode"
                                :label="vo.vSubCodenm"
                                :id="key + '_' + idx"
                                @click="fnValidate('releaseInfo' + key);checkReleaseInfo(key)"
                              >
                              </ap-input-check>
                              <template v-if="vo.vSubCode !== 'LNC02_04'">
                                <ap-month-picker
                                  v-if="commonUtils.isNotEmpty(vo.vTag2Cd)"
                                  v-model:date="vo.vTagBuffer1"
                                  @update:date="fnValidate('releaseInfo' + key);"
                                >
                                </ap-month-picker>
                              </template>
                              <template v-else>
                                <div class="form-flex" v-if="commonUtils.isNotEmpty(vo.vTag2Cd)">
                                  <div class="form-flex__cell--5">
                                    <ap-month-picker
                                      v-model:date="vo.vTagBuffer1"
                                      @update:date="fnValidate('releaseInfo' + key);"
                                    >
                                    </ap-month-picker>
                                  </div>
                                  <div class="form-flex__cell--5">
                                    <ap-input
                                      v-if="vo.vSubCode === 'LNC02_04'"
                                      v-model:value="vo.vTagBuffer2"
                                    >
                                    </ap-input>
                                  </div>
                                </div>
                              </template>
                            </div>
                          </template>
                        </div>
                        <span class="error-msg" :id="'error_msg_releaseInfo' + key"></span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
            <tr>
              <th>파일럿</th>
              <td>
                {{ commonUtils.changeStrDatePattern(regParams.vPilotDt) }}
              </td>
              <th>생산회의</th>
              <td>
                <ap-month-picker
                  v-model:date="regParams.vMeetingDt"
                  input-class="div_width--200"
                >
                </ap-month-picker>
              </td>
            </tr>
            <tr>
              <th>비고</th>
              <td colspan="3" v-html="commonUtils.removeHTMLChangeBr(regParams.vNote)"></td>
            </tr>
            <tr>
              <th>첨부파일</th>
              <td colspan="3">
                <UploadFileView
                  v-if="commonUtils.isNotEmpty(regParams.vLabNoteCd)"
                  uploadid="MAKEUP_NOTE_ATT01"
                  :recordid="regParams.vLabNoteCd"
                >
                </UploadFileView>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @callbackFunc="popSelectFunc"
        @selectFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, ref, inject, watch } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'

export default {
  name: 'AllLabNoteBrandManagerBasicInfoRegister',
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    ProdSearchPop: defineAsyncComponent(() => import('@/components/labcommon/popup/ProdSearchPop.vue')),
    UploadFileView: defineAsyncComponent(() => import('@/components/comm/UploadFileView.vue')),
  },
  setup () {
    const reqInfo = inject('reqInfo')
    const commonUtils = inject('commonUtils')
    const rowspanCnt = ref(1)
    let popIdx = null

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      releaseMap,
    } = useLabCommon()

    const regParams = ref({
      vBrdCd: '',
      vFlagOem: '',
      vOemManufacturer: '',
      vPlantNm: '',
      vSiteTypeNm: '',
      contList: [],
      releaseList: [],
      vFlagNew: '',
      vProdType1Cd: '',
      vProdType2Cd: '',
      vTddProdType1Nm: '',
      vTddProdType2Nm: '',
      vPartCd: '',
      vFlagReleaseASIA: '',
      vFlagReleaseASEAN: '',
      vFlagReleaseETC: '',
      vFlagReleaseAllASIA: '',
      vFlagReleaseAllASEAN: '',
      vFlagReleaseAllETC: '',
      vReleaseAllDtASIA: '',
      vReleaseAllDtASEAN: '',
      vReleaseAllDtETC: '',
      vPilotDt: '',
      vMeetingDt: '',
      vContainerCd: '',
      vContainerEtc: '',
      vNote: '',
      vPlantCd: '',
    })

    const checkReleaseDtGroup = (value, key) => {
      if (value === 'N' || value === 'U') {
        regParams.value['vFlagReleaseAll' + key] = ''
        regParams.value['vReleaseAllDt' + key] = ''
        releaseMap.value[key].countryList.forEach(item => {
          item.vTag2Cd = ''
          item.vTagBuffer1 = ''
          item.vTagBuffer2 = ''
        })
      }
    }

    const checkReleaseAll = (value, key) => {
      if (value === 'Y') {
        releaseMap.value[key].countryList.forEach(item => {
          item.vTag2Cd = item.vSubCode
        })
      } else {
        releaseMap.value[key].countryList.forEach(item => {
          item.vTag2Cd = ''
          item.vTagBuffer1 = ''
        })
      }
    }

    const changeReleaseAllDt = (ym, value, key) => {
      if (value === 'Y') {
        releaseMap.value[key].countryList.forEach(item => {
          item.vTagBuffer1 = ym
        })
      }
    }

    const checkReleaseInfo = (key) => {
      const countryList = releaseMap.value[key].countryList
      const allLength = countryList.length
      const checkedLength = countryList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)).length

      if (allLength === checkedLength) {
        regParams.value['vFlagReleaseAll' + key] = 'Y'
      } else {
        regParams.value['vFlagReleaseAll' + key] = 'N'
      }

      regParams.value['vReleaseAllDt' + key] = ''
    }

    const fnValidateAll = (arrChkKey) => {
      let isOk = true
      commonUtils.hideErrorMessageAll(arrChkKey)

      arrChkKey.forEach(key => {
        if (!fnValidate(key)) {
          isOk = false
        }
      })

      return isOk
    }

    const fnValidate = (key) => {
      let isOk = true
      let errorMsg = '필수 입력 사항입니다.'
      commonUtils.hideErrorMessage(key)

      if (key === 'releaseInfoASIA') {
        const countryLen = releaseMap.value['ASIA'].countryList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)).length
        const releaseDtLen = releaseMap.value['ASIA'].countryList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd) && commonUtils.isEmpty(item.vTagBuffer1)).length

        if (commonUtils.isEmpty(regParams.value.vFlagReleaseASIA) && countryLen === 0) {
          isOk = false
          errorMsg = '출시지역을 선택해 주세요.'
        } else if (commonUtils.isEmpty(regParams.value.vFlagReleaseASIA) && countryLen > 0 && releaseDtLen > 0) {
          isOk = false
          errorMsg = '출시시기를 입력해 주세요.'
        }
      } else if (key === 'releaseInfoASEAN') {
        const countryLen = releaseMap.value['ASEAN'].countryList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)).length
        const releaseDtLen = releaseMap.value['ASEAN'].countryList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd) && commonUtils.isEmpty(item.vTagBuffer1)).length

        if (commonUtils.isEmpty(regParams.value.vFlagReleaseASEAN) && countryLen === 0) {
          isOk = false
          errorMsg = '출시지역을 선택해 주세요.'
        } else if (commonUtils.isEmpty(regParams.value.vFlagReleaseASEAN) && countryLen > 0 && releaseDtLen > 0) {
          isOk = false
          errorMsg = '출시시기를 입력해 주세요.'
        }
      } else if (key === 'releaseInfoETC') {
        const countryLen = releaseMap.value['ETC'].countryList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)).length
        const releaseDtLen = releaseMap.value['ETC'].countryList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd) && commonUtils.isEmpty(item.vTagBuffer1)).length
        if (commonUtils.isEmpty(regParams.value.vFlagReleaseETC) && countryLen === 0) {
          isOk = false
          errorMsg = '출시지역을 선택해 주세요.'
        } else if (commonUtils.isEmpty(regParams.value.vFlagReleaseETC) && countryLen > 0 && releaseDtLen > 0) {
          isOk = false
          errorMsg = '출시시기를 입력해 주세요.'
        }
      } else if (commonUtils.isEmpty(regParams.value[key])) {
        isOk = false
      }

      if (!isOk) {
        commonUtils.showErrorMessage(key, errorMsg)
      }

      return isOk
    }

    const showNoteContNmArea = () => {
      let isVisible = false
      if (regParams.value.vPlantCd === 'CN20' && 
            'LNC06_01;LNC06_02;LNC06_03;LNC06_04;LNC06_05;LNC06_06'.indexOf(regParams.value.vStatusCd) === -1) {
        isVisible = true
        rowspanCnt.value = 2
      }

      return isVisible
    }

    const fnProdSearchPop = (index) => {
      popIdx = index
      popParams.value = {
        vKeyword: ''
      }

      popSelectFunc.value = getProdInfo
      fnOpenPopup('ProdSearchPop')
    }

    const getProdInfo = (item) => {
      regParams.value.contList[popIdx].vPrdCd = item.vPrdCd
      popIdx = null
    }

    const removePrdCd = (index) => {
      regParams.value.contList[index].vPrdCd = ''
    }

    const init = () => {
      const arrMstCode = [
        'LAB_NOTE_BRAND', 'MTR01', 'MTR02', 'TR_INDICATIO_PART', 'LNC26'
      ]

      findCodeList(arrMstCode)
    }

    watch(() => reqInfo.value, (newValue) => {
      init()
      regParams.value = { ...regParams.value, ...newValue }
      if (regParams.value.releaseList && regParams.value.releaseList.length > 0) {
        regParams.value.releaseList.forEach(item => {
          releaseMap.value[item.vBuffer1].countryList.push({ ...item })
        })
      }
    })

    return {
      codeGroupMaps,
      releaseMap,
      regParams,
      commonUtils,
      rowspanCnt,
      popupContent,
      popParams,
      popSelectFunc,
      checkReleaseDtGroup,
      checkReleaseAll,
      changeReleaseAllDt,
      checkReleaseInfo,
      removePrdCd,
      fnValidateAll,
      fnValidate,
      showNoteContNmArea,
      fnProdSearchPop,
    }
  }
}
</script>