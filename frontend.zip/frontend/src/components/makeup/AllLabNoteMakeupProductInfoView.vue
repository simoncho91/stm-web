<template>
  <div class="sub-contents__item mt-15">
    <dl class="sub-contents__dd">
      <dt class="sub-contents__dt">카운터</dt>
      <dd class="sub-contents__dd">
        <div class="ui-table__product--wrap">
          <table class="ui-table__product">
            <colgroup>
              <col style="width:21.5rem">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr>
                <th>구분</th>
                <td>{{ versionInfo.vCounterTypeNm ? versionInfo.vCounterTypeNm : '없음' }}</td>
              </tr>
              <tr v-if="versionInfo.vCounterTypeCd === 'LNC04_01'">
                <th>내용물 코드</th>
                <td>
                  <template v-if="commonUtils.isNotEmpty(versionInfo.vCounterInvenCd)">
                    [{{ versionInfo.vCounterSpCd }}]
                  </template>
                  {{ commonUtils.isNotEmpty(versionInfo.vCounterInvenCd) ? 
                      versionInfo.vCounterInvenNm : versionInfo.vCounterContNm }}
                </td>
              </tr>
              <template v-else-if="versionInfo.vCounterTypeCd === 'LNC04_02'">
                <tr>
                  <th>브랜드</th>
                  <td>
                    {{ versionInfo.vCounterBrdNm }}
                  </td>
                </tr>
                <tr>
                  <th>제품명</th>
                  <td>
                    {{ versionInfo.vCounterPrdNm }}
                  </td>
                </tr>
              </template>
              <template v-else-if="versionInfo.vCounterTypeCd === 'LNC04_03'">
                <tr>
                  <th>SP 정보</th>
                  <td>
                    {{ versionInfo.vCounterSpInfo }}
                  </td>
                </tr>
                <tr>
                  <th>선행파일럿</th>
                  <td>
                    {{ commonUtils.changeStrDatePattern(versionInfo.vPrePilotDt, '.') }}
                  </td>
                </tr>
              </template>
              <tr>
                <th>비고</th>
                <td v-html="commonUtils.removeHTMLChangeBr(versionInfo.vCounterNote)"></td>
              </tr>
            </tbody>
          </table>
        </div>
      </dd>
    </dl>
  </div>

  <div class="sub-contents__item">
    <dl class="sub-contents__dd">
      <dt class="sub-contents__dt">신원료</dt>
      <dd class="sub-contents__dd">
        <div class="ui-table__product--wrap">
          <table class="ui-table__product">
            <colgroup>
              <col style="width:21.5rem">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr>
                <th>신원료 정보</th>
                <td>{{ versionInfo.vFlagNewItem === 'Y' ? '유' : '무' }}</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="note-table mt-15 mb-15"
          v-if="versionInfo.vFlagNewItem === 'Y' && versionInfo.newMateList"
        >
          <MateSearchResultTableView
            :mate-list="versionInfo.newMateList"
            stock-dt-yn="Y"
            mate-chg-yn="Y"
          ></MateSearchResultTableView>
        </div>
      </dd>
    </dl>
  </div>

  <div class="sub-contents__item">
    <dl class="sub-contents__dd">
      <dt class="sub-contents__dt">향료정보</dt>
      <dd class="sub-contents__dd">
        <div class="ui-table__product--wrap">
          <table class="ui-table__product">
            <colgroup>
              <col style="width:21.5rem">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr>
                <th>구분</th>
                <td>
                  {{ versionInfo.vPerfumeNm }} 
                  <template v-if="versionInfo.vPerfumeCd === 'LNC11_03'">
                    ({{ versionInfo.vFlagPerfumeNew === 'Y' ? '신향' : '기존향' }})
                  </template>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <div class="note-table mt-15 mb-15"
          v-if="versionInfo.vPerfumeCd !== 'LNC11_99' && versionInfo.perfMateList"
        >
          <MateSearchResultTableView
            :mate-list="versionInfo.perfMateList"
            stock-dt-yn="Y"
          ></MateSearchResultTableView>
        </div>
      </dd>
    </dl>
  </div>

  <div class="sub-contents__item">
    <dl class="sub-contents__dd"
      v-if="funcList.length > 0"
    >
      <dt class="sub-contents__dt">기능성</dt>
      <dd class="sub-contents__dd">
        <div class="ui-table__product--wrap">
          <table class="ui-table__product">
            <colgroup>
              <col style="width:21.5rem">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr>
                <th>구분</th>
                <td>
                  <template v-for="(vo, idx) in funcList" :key="'func_' + idx">
                    {{ idx !== 0 ? ', ' : '' }}{{ vo.vSubCodenm }}
                  </template>
                </td>
              </tr>
              <tr>
                <th>관련근거</th>
                <td>{{ versionInfo.vRefTypeNm }}</td>
              </tr>
              <tr v-if="versionInfo.vRefTypeCd === 'LNC05_02'">
                <th>심사번호</th>
                <td>
                  {{ versionInfo.vEvaluateno }} {{ commonUtils.isNotEmpty(versionInfo.vEvaluateGosiCd) ? '/ ' + versionInfo.vEvaluateGosiNo : '' }}
                </td>
              </tr>
              <tr v-if="versionInfo.vRefTypeCd === 'LNC05_03' || versionInfo.vRefTypeCd === 'LNC05_04'">
                <th>심사항목</th>
                <td>{{ versionInfo.vRefNote }}</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div
          class="note-table mt-15 mb-15"
          v-if="versionInfo.funcMateList && versionInfo.funcMateList.length > 0"
        >
          <MateSearchResultTableView
            :mate-list="versionInfo.funcMateList"
          ></MateSearchResultTableView>
        </div>
      </dd>
    </dl>
  </div>

  <div class="sub-contents__item">
    <dl class="sub-contents__dd" v-if="versionInfo.requMateList && versionInfo.requMateList.length > 0">
      <dt class="sub-contents__dt">필수원료</dt>
      <dd class="sub-contents__dd">
        <div class="note-table mt-15 mb-15">
          <MateSearchResultTableView
            :mate-list="versionInfo.requMateList"
          ></MateSearchResultTableView>
        </div>
      </dd>
    </dl>
  </div>

  <div class="page-bottom">
    <div class="ui-buttons ui-buttons__right">
      <button type="button" class="ui-button ui-button__height--28 ui-button__bg--blue" v-if="reqInfo.vStatusCd !== 'LNC06_50'" @click="fnProductModifyPop()">버전수정</button>
      <button type="button" class="ui-button ui-button__height--28 ui-button__bg--blue" @click="fnProductHistoryPop()">변경이력</button>
    </div>
  </div>
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @callbackFunc="popSelectFunc"
        @selectFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, ref, inject, watch } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'AllLabNoteMakeupProductInfoView',
  components: {
    MateSearchResultTableView: defineAsyncComponent(() => import('@/components/labcommon/MateSearchResultTableView.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    AllLabNoteProductVersionModifyPop: defineAsyncComponent(() => import('@/components/labcommon/popup/AllLabNoteProductVersionModifyPop.vue')),
    ProductVersionHistoryPop: defineAsyncComponent(() => import('@/components/labcommon/popup/ProductVersionHistoryPop.vue')),
  },
  props: {
    versionInfo: {
      type: Object,
      default: () => {
        return {}
      }
    },
  },
  setup (props) {
    const commonUtils = inject('commonUtils')
    const funcList = ref([])
    const reqInfo = inject('reqInfo')
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
    } = useLabCommon()

    const closeModifyPop = () => {
      closeAsyncPopup({ message: '' })
      window.location.reload(true)
    }

    const fnProductModifyPop = () => {
      popParams.value = {
        vLabNoteCd: props.versionInfo.vLabNoteCd,
        vContPkCd: reqInfo.value.vContPkCd,
        vContCd: reqInfo.value.vContCd,
        vContNm: reqInfo.value.vContNm,
        nVersion: props.versionInfo.nVersion,
      }


      popSelectFunc.value = closeModifyPop

      fnOpenPopup('AllLabNoteProductVersionModifyPop', false)
    }

    const fnProductHistoryPop = () => {
      const verList = []

      reqInfo.value.verList.forEach(item => {
        verList.push({...item})
      })
      popParams.value = {
        vLabNoteCd: props.versionInfo.vLabNoteCd,
        vContPkCd: reqInfo.value.vContPkCd,
        nVersion: props.versionInfo.nVersion,
        verList: verList,
      }

      fnOpenPopup('ProductVersionHistoryPop', false)
    }

    const init = () => {
      funcList.value = [ ...props.versionInfo.funcList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)) ]
    }

    init()

    watch(() => props.versionInfo, newVal => {
      funcList.value = [ ...newVal.funcList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)) ]
    })

    return {
      reqInfo,
      funcList,
      popupContent,
      popParams,
      popSelectFunc,
      commonUtils,
      fnProductModifyPop,
      fnProductHistoryPop,
    }
  }
}
</script>