<template>
  <div class="arrordion-item is-active">
    <div class="arrordion-body">
      <div class="sub-contents__item">
        <dl class="sub-contents__dd">
          <dt class="sub-contents__dt">내용물 정보</dt>
          <dd class="sub-contents__dd">
            <div class="note-table">
              <div class="note-table__inner">
                <table class="ui-table__reset ui-table__search-result text-center cont-table">
                  <colgroup>
                    <col width="5.5%">
                    <col width="11%">
                    <col width="7%">
                    <col width="10%">
                    <col width="*">
                    <col width="8.8%">
                    <col width="22%">
                    <col width="11%">
                  </colgroup>
                  <thead>
                    <tr>
                      <th :rowspan="rowspanCnt">대표홋수</th>
                      <th :rowspan="rowspanCnt">제품코드</th>
                      <th :rowspan="rowspanCnt">내용물코드</th>
                      <th :rowspan="rowspanCnt">별칭</th>
                      <th>내용물명</th>
                      <th :rowspan="rowspanCnt">조색 내용물코드</th>
                      <th :rowspan="rowspanCnt">조색 내용물명</th>
                      <th :rowspan="rowspanCnt">조색담당자</th>
                    </tr>
                    <tr v-if="showNoteContNmArea()">
                      <th>실험노트 제품명</th>
                    </tr>
                  </thead>
                  <tbody>
                    <template v-if="contList && contList.length > 0">
                      <template v-for="(vo, idx) in contList" :key="'cont_' + idx">
                        <tr :class="vo.vFlagCancel === 'Y' ? 'cancel_area' : ''">
                          <td :rowspan="rowspanCnt">
                            {{ vo.vFlagRepresent === 'Y' ? '√' : '' }}
                          </td>
                          <td :rowspan="rowspanCnt">{{ vo.vPrdCd }}</td>
                          <td :rowspan="rowspanCnt">{{ vo.vContCd }}</td>
                          <td :rowspan="rowspanCnt">{{ vo.vTctnBynmNm }}</td>
                          <td>{{ vo.vContNm }} {{ vo.vFlagCancel === 'Y' ? '(개발취소)' : '' }}<span class="txt_blue">{{ vo.vFlagLaunch === 'Y' ? '(출시완료)' : '' }}</span></td>
                          <td :rowspan="rowspanCnt">{{ vo.vHal4ContCd }}</td>
                          <td :rowspan="rowspanCnt">{{ vo.vHal4ContNm }}</td>
                          <td :rowspan="rowspanCnt">{{ vo.vUsernm }}</td>
                        </tr>
                        <tr v-if="showNoteContNmArea()">
                          <td>{{ vo.vNoteContNm }} {{ vo.vFlagCancel === 'Y' ? '(개발취소)' : '' }}<span class="txt_blue">{{ vo.vFlagLaunch === 'Y' ? '(출시완료)' : '' }}</span></td>
                        </tr>
                      </template>
                    </template>
                    <template v-else>
                      <tr>
                        <td colspan="8">
                          <div class="no-result">
                            {{ t('common.msg.no_data') }}
                          </div>
                        </td>
                      </tr>
                    </template>
                  </tbody>
                </table>
              </div>
            </div>
          </dd>
        </dl>
      </div>
    </div>
  </div>
</template>

<script>
import { inject, watch, ref } from 'vue'

export default {
  name: 'MakeupContInfoView',
  setup () {
    const t = inject('t')
    const reqInfo = inject('reqInfo')
    const contList = ref([])
    const rowspanCnt = ref(1)
    const showNoteContNmArea = () => {
      let isVisible = false
      if (reqInfo.value && reqInfo.value.vPlantCd === 'CN20' && 
            'LNC06_01;LNC06_02;LNC06_03;LNC06_04;LNC06_05;LNC06_06'.indexOf(reqInfo.value.vStatusCd) === -1) {
        isVisible = true
        rowspanCnt.value = 2
      }

      return isVisible
    }

    watch(() => reqInfo.value, (newValue) => {
      if (newValue && newValue.contList) {
        contList.value = [ ...newValue.contList ]
      }
    })

    return {
      t,
      contList,
      rowspanCnt,
      showNoteContNmArea
    }
  }
}
</script>