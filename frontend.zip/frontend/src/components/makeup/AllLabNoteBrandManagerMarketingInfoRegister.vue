<template>
  <div class="arrordion-item is-active">
    <div class="arrordion-header">
      <div class="arrordion-title">마케팅 정보</div>
      <button type="button" class="ui-button__accordion"></button>
    </div>
    <div class="arrordion-body">
      <div class="basic-info__table">
        <table class="ui-table__contents">
          <colgroup>
            <col style="width:17rem">
            <col style="width:auto">
            <col style="width:17rem">
            <col style="width:auto">
          </colgroup>
          <tbody>
            <tr>
              <th>소비자가격/실제품용량</th>
              <td>
                <div class="form-flex">
                  <div class="ui-select-box form-flex__cell--5">
                    <ap-input
                      v-model:value="regParams.nPrice"
                      :is-comma="true"
                      :is-number="true"
                      input-class="ui-input__width--150"
                    >
                    </ap-input>
                  </div>
                  <div class="ui-select-box form-flex__cell--5">
                    원 / 
                  </div>
                  <div class="ui-select-box form-flex__cell--5">
                    <ap-input
                      v-model:value="regParams.nProductCapacity"
                      :is-comma="true"
                      :is-number="true"
                      input-class="ui-input__width--150"
                    >
                    </ap-input>
                  </div>
                  <div class="ui-select-box form-flex__cell--5">
                    <div class="ui-radio__list">
                      <div class="ui-radio__inner">
                        <ap-input-radio
                          v-for="(vo, index) in codeGroupMaps['LNC03']" :key="'unit_' + index"
                          v-model:model="regParams.vProductCapacityCd"
                          :value="vo.vSubCode"
                          :label="vo.vSubCodenm"
                          :id="'unit_' + index"
                          name="unit"
                        ></ap-input-radio>
                      </div>
                    </div>
                  </div>
                </div>
              </td>
              <th>타겟 Cost/100g</th>
              <td>
                <div class="form-flex">
                  <div class="ui-select-box form-flex__cell--5" id="error_wrap_nTargetCost">
                    <ap-input
                      v-model:value="regParams.nTargetCost"
                      :is-comma="true"
                      :is-number="true"
                      input-class="ui-input__width--150"
                    >
                    </ap-input>
                    <span class="error-msg" id="error_msg_nTargetCost"></span>
                  </div>
                  <div class="ui-select-box form-flex__cell--5">
                    원
                  </div>
                </div>
              </td>
            </tr>
            <tr>
              <th>안심감요소</th>
              <td colspan="3">
                <template v-if="regParams.reqEtcList && regParams.reqEtcList.length > 0">
                  <template v-for="(vo, idx) in regParams.reqEtcList" :key="'reqEtc_' + idx">
                    {{ idx !== 0 ? ', ' : ''}}{{ vo.vSubCodenm }} {{ vo.vTag2Cd === 'LNC13_99' ? (commonUtils.isNotEmpty(vo.vTagBuffer2) ?'(' + vo.vTagBuffer2 + ')' : '') : '' }}
                  </template>
                </template>
              </td>
            </tr>
            <tr>
              <th>효능 임상</th>
              <td colspan="3">
                <template v-if="regParams.effectList && regParams.effectList.length > 0">
                  <template v-for="(vo, idx) in regParams.effectList" :key="'effect_' + idx">
                    {{ idx !== 0 ? ', ' : ''}}{{ vo.vSubCodenm }} {{ vo.vContent2 ? '(' + vo.vContent2 + ')' : '' }} {{ vo.vTag2Cd === 'LNC15_99' ? (commonUtils.isNotEmpty(vo.vTagBuffer2) ?'(' + vo.vTagBuffer2 + ')' : '') : '' }}
                  </template>
                </template>
              </td>
            </tr>
            <tr v-if="regParams.effectList && regParams.effectList.length > 0 && regParams.effectList.filter(vo => commonUtils.isNotEmpty(vo.vTag2Cd)).length > 0">
              <td colspan="4" class="inside-td">
                <table class="ui-table__contents">
                  <colgroup>
                    <col style="width:14rem">
                  </colgroup>
                  <tbody>
                    <tr>
                      <th>시험기간</th>
                      <td>
                        {{ regParams.nEffTestDcnt }} {{ regParams.vEffTestDcntUnitTxt }}
                      </td>
                    </tr>
                    <tr>
                      <th>소구문구</th>
                      <td>
                        {{ regParams.vEffTestSogooMemo }}
                      </td>
                    </tr>
                    <tr>
                      <th>임상 진행기관</th>
                      <td>
                        {{ regParams.vEffCompTypeNm }}
                      </td>
                    </tr>
                    <tr>
                      <th>임상 시작시점</th>
                      <td>
                        {{ commonUtils.changeStrDatePattern(regParams.vEffTestItemDt) }}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
            <tr>
              <th>안전성 임상</th>
              <td colspan="3">
                <template v-if="regParams.mti01List && regParams.mti01List.length > 0">
                  <template v-for="(vo, idx) in regParams.mti01List" :key="'mti01_' + idx">
                    {{ idx !== 0 ? ', ' : ''}}{{ vo.vSubCodenm }} {{ vo.vContent2 ? '(' + vo.vContent2 + ')' : '' }} {{ vo.vTagBuffer2 ? '(' + vo.vTagBuffer2 + ')' : '' }}
                  </template>
                </template>
              </td>
            </tr>
            <tr v-if="regParams.mti01List && regParams.mti01List.length > 0">
              <td colspan="4" class="inside-td">
                <table class="ui-table__contents">
                  <colgroup>
                    <col style="width:14rem">
                  </colgroup>
                  <tbody>
                    <tr>
                      <th>임상 시작시점</th>
                      <td>
                        {{ commonUtils.changeStrDatePattern(regParams.vTestItemDt) }}
                        <!-- 논코메도제닉 (8주), 하이포알러제닉 (12주), 안과 (8주) -->
                        <template v-if="regParams.mti01List.filter(vo => vo.vTag2Cd !== '' && 'MTI01_02,MTI01_03,MTI01_04'.indexOf(vo.vTag2Cd) > -1).length > 0">
                          <p class="p_caution">
                            ※ "임상심의"를 파일럿 D-1 개월까지 완료
                          </p>
                        </template>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
            <tr>
              <th>ONE POINT (고객관점)</th>
              <td colspan="3">
                <ap-input
                  v-model:value="regParams.vOnePoint"
                  :maxlength="200"
                >
                </ap-input>
              </td>
            </tr>
            <tr>
              <th>사용 고객</th>
              <td colspan="3">
                <div class="ui-checkbox__list">
                  <div class="ui-checkbox__inner">
                    <ap-input-check
                      value="Y"
                      label="전체"
                      id="usecstm_all"
                      v-model:model="useCstmAll"
                      @click="fnUseCstmCheckAllEvent"
                    >
                    </ap-input-check>
                    <ap-input-check
                      v-for="(vo, index) in regParams.tuserList" :key="'usecstm_' + index"
                      v-model:model="vo.vTag2Cd"
                      :value="vo.vSubCode"
                      :label="vo.vSubCodenm"
                      :id="'usecstm_' + index"
                      @click="fnUseCstmCheckEvent"
                    >
                    </ap-input-check>
                  </div>
                </div>
              </td>
            </tr>
            <tr>
              <th>타겟 고객</th>
              <td colspan="3">
                <ap-input
                  v-model:value="regParams.vTargetCustomer"
                  :maxlength="200"
                >
                </ap-input>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, inject, watch } from 'vue'
import { useCode } from '@/compositions/useCode'

export default {
  name: 'AllLabNoteBrandManagerMarketingInfoRegister',
  setup () {
    const reqInfo = inject('reqInfo')
    const useCstmAll = ref('')
    const commonUtils = inject('commonUtils')
    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const regParams = ref({
      nPrice: '',
      nProductCapacity: '',
      vProductCapacityCd: '',
      nTargetCost: '',
      nCapacity: '100',
      vCapacityCd: 'LNC03_01',
      reqEtcList: [],
      effectList: [],
      nEffTestDcnt: '',
      vEffTestDcntUnit: '',
      vEffTestSogooMemo: '',
      vEffCompTypeCd: '',
      vEffTestItemDt: '',
      mti01List: [],
      vTestItemDt: '',
      vOnePoint: '',
      tuserList: [],
      vTargetCustomer: '',
    })

    const fnUseCstmCheckAllEvent = (value) => {
      if (value === 'Y') {
        regParams.value.tuserList.forEach((item, idx) => {
          item.vTag2Cd = item.vSubCode
          document.querySelector('#usecstm_' + idx).checked = true
        })
      } else {
        regParams.value.tuserList.forEach((item, idx) => {
          item.vTag2Cd = ''
          document.querySelector('#usecstm_' + idx).checked = false
        })
      }
    }

    const fnUseCstmCheckEvent = () => {
      const checkedLen = regParams.value.tuserList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)).length
      if (regParams.value.tuserList.length === checkedLen) {
        useCstmAll.value = 'Y'
        document.querySelector('#usecstm_all').checked = true
      } else {
        useCstmAll.value = ''
        document.querySelector('#usecstm_all').checked = false
      }
    }

    const fnValidateAll = (arrChkKey) => {
      let isOk = true
      commonUtils.hideErrorMessageAll(arrChkKey)

      arrChkKey.forEach(key => {
        if (!fnValidate(key)) {
          isOk = false
        }
      })

      return isOk
    }

    const fnValidate = (key) => {
      let isOk = true
      let errorMsg = '필수 입력 사항입니다.'
      commonUtils.hideErrorMessage(key)

      if (commonUtils.isEmpty(regParams.value[key])) {
        isOk = false
      }

      if (!isOk) {
        commonUtils.showErrorMessage(key, errorMsg)
      }

      return isOk
    }

    const init = () => {
      const arrMstCode = ['LNC03', 'LNC18', 'LNC16']
      findCodeList(arrMstCode)
    }

    init()

    watch(() => reqInfo.value, (newValue) => {
      regParams.value = {...regParams.value, ...{
        nPrice: newValue.nPrice,
        nProductCapacity: newValue.nProductCapacity,
        vProductCapacityCd: newValue.vProductCapacityCd,
        nTargetCost: newValue.nTargetCost,
        reqEtcList: newValue.reqEtcList,
        effectList: newValue.effectList,
        mti01List: newValue.mti01List,
        tuserList: newValue.tuserList,
        nEffTestDcnt: newValue.nEffTestDcnt,
        vEffTestDcntUnit: newValue.vEffTestDcntUnit,
        vEffTestSogooMemo: newValue.vEffTestSogooMemo,
        vEffCompTypeCd: newValue.vEffCompTypeCd,
        vEffTestItemDt: newValue.vEffTestItemDt,
        vTestItemDt: newValue.vTestItemDt,
        vOnePoint: newValue.vOnePoint,
        vTargetCustomer: newValue.vTargetCustomer,
      } }

      regParams.value.reqEtcList = [ ...regParams.value.reqEtcList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd))]
      regParams.value.effectList = [ ...regParams.value.effectList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)) ]
      regParams.value.mti01List = [ ...regParams.value.mti01List.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)) ]
    })

    return {
      codeGroupMaps,
      regParams,
      commonUtils,
      useCstmAll,
      fnUseCstmCheckAllEvent,
      fnUseCstmCheckEvent,
      fnValidateAll,
      fnValidate,
    }
  }
}
</script>