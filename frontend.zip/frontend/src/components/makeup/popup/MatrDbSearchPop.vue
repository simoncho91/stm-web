<template>
  <div class="modal-content modal-content__width--800">
    <div class="modal-header">
      <div class="modal-title">성분 등록</div>
      <button type="button" class="modal-close" @click="fnClose()"></button>
    </div>
    <div class="modal-body">
      <div class="board-top">
        <div class="board-flex">
          <div class="board-cell">
            <div class="search-form">
              <div class="search-form__inner">
                <ap-input
                  v-model:value="searchParams.vKeyword"
                  input-class="ui-input ui-input__width--535"
                  placeholder="성분코드, 성분명(영어)"
                  id="vMatrDbSearchPopKeyword"
                  @keypress-enter="fnSearch(1)"
                >
                </ap-input>
                <button 
                  type="button"
                  class="button-search"
                  @click="fnSearch(1)"
                >
                  검색
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="myboard-table">
        <div class="myboard-table__inner">
          <table class="ui-table ui-table__th--border-radius--0 ui-table__td--40 text-center">
            <colgroup>
              <col style="width:10%">
              <col style="width:37.5%">
              <col style="width:37.5%">
              <col style="width:15%">
            </colgroup>
            <thead>
              <tr>
                <th>성분코드</th>
                <th>성분명(영어)</th>
                <th>성분명</th>
                <th>Cas no</th>
              </tr>
            </thead>
            <tbody>
              <template v-if="list && list.length > 0">
                <tr v-for="(vo, idx) in list" :key="'user_' + idx" @click="fnApply(vo)">
                  <td>{{ vo.vConcd }}</td>
                  <td>{{ vo.vConnameEn }}</td>
                  <td>{{ vo.vConnameKo }}</td>
                  <td>{{ vo.vCasno }}</td>
                </tr>
              </template>
              <template v-else>
                <tr>
                  <td colspan="4">
                    <div class="no-result">
                      {{ t('common.msg.no_data') }}
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>

        <div class="board-bottom">
          <div class="board-bottom__inner">
            <Pagination
              v-if="list && list.length > 0"
              :page-info="page"
              @click="fnSearch"
            >
            </Pagination>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, inject, reactive, onMounted } from 'vue'
import { useMakeupRequest } from '@/compositions/makeup/useMakeupRequest'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'MatrDbSearchPop',
  components: {
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue'))
  },
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          searchFlag: 'ALL',
        }
      }
    }
  },
  emits: ['selectFunc'],
  setup (props, context) {
    const t = inject('t')
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])
    const {
      page,
      list,
      selectMatrDbSearchList,
    } = useMakeupRequest()

    const searchParams = reactive({
      vKeyword: props.popParams.vKeyword || '',
      nowPageNo: 1
    })

    const fnSearch = async (pg) => {
      if (!pg) {
        pg = 1
      }

      searchParams.nowPageNo = pg

      await selectMatrDbSearchList(searchParams)

      if (list.value && list.value.length === 1) {
        fnApply(list.value[0])
      }
    }

    const fnApply = (item) => {
      const returnObj = {
        vConcd: item.vConcd,
        vConnameEn: item.vConnameEn,
        vConnameKo: item.vConnameKo,
        vConnmEn: '',
        vConnmKo: '',
        vCiNumber: '',
      }

			const connmen = item.vConnameEn
			const connmko = item.vConnameKo
			
			if (connmen.indexOf('(CI') !== -1) {
				let fir = connmen.split('(')[0]
				let sec = connmen.split('(')[1]
				sec = sec.replace(/[a-z]/gi, '')
				sec = sec.replace(')', '')

        returnObj.vConnmEn = fir.trim()
        returnObj.vCiNumber = sec.trim()
			}
			
			if (connmko.indexOf('(CI') !== -1) {
				let fir = connmko.split('(')[0]
				let sec = connmko.split('(')[1]
				sec = sec.replace(/[a-z]/gi, '')
				sec = sec.replace(')', '')
				
        returnObj.vConnmKo = fir.trim()
			}


      context.emit('selectFunc', returnObj)

      fnClose()
    }

    const fnClose = () => {
      closeAsyncPopup({ message: '' })
    }

    const init = () => {
      fnSearch(1)
    }

    init()

    onMounted(() => {
      const input = document.querySelector('#vMatrDbSearchPopKeyword')
      input.focus()
    })

    return {
      t,
      searchParams,
      page,
      list,
      fnSearch,
      fnApply,
      fnClose,
    }
  }
}
</script>

<style scoped>
  .ui-table tbody tr {
    cursor: pointer;
  }
</style>