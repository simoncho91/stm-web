<template>
  <div class="modal-content modal-content__width--950">
    <div class="modal-header">
      <div class="modal-title">May Contain 찾기</div>
      <button type="button" class="modal-close" @click="fnClose"></button>
    </div>
    <div class="modal-body">
      <div class="board-top">
        <div class="board-flex">
          <div class="board-cell">
            <div class="search-form">
              <div class="search-form__inner">
                <ap-input
                  v-model:value="searchParams.vKeyword"
                  input-class="ui-input ui-input__width--535"
                  placeholder="내용물코드 or 제품"
                  id="vUserSearchPopKeyword"
                  @keypress-enter="fnSearch(1)"
                >
                </ap-input>
                <button 
                  type="button"
                  class="button-search"
                  @click="fnSearch(1)"
                >
                  검색
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="myboard-table">
        <div class="myboard-table__inner">
          <table class="ui-table ui-table__th--border-radius--0 ui-table__td--40 text-center">
            <colgroup>
              <col style="width:5%">
              <col style="width:5%">
              <col style="width:15%">
              <col style="width:30%">
              <col style="width:15%">
              <col style="width:30%">
            </colgroup>
            <thead>
              <tr>
                <th></th>
                <th>NO</th>
                <th>내용물 코드</th>
                <th>내용물 코드명</th>
                <th>[승계]내용물 코드</th>
                <th>[승계]내용물 코드명</th>
              </tr>
            </thead>
            <tbody>
              <template v-if="list && list.length > 0">
                <tr v-for="(vo, idx) in list" :key="'user_' + idx">
                  <td>
                    <ap-input-radio
                      v-model:model="payload.vSuccessionCd"
                      :value="vo.vLabNoteCd"
                      :id="'ex_radio' + idx"
                      name="exRadio"
                    >
                    </ap-input-radio>
                  </td>
                  <td>{{ page.totalCnt - ((page.pageSize * (page.nowPageNo-1)) + idx)}}</td>
                  <td>{{ vo.vContCd }}</td>
                  <td>{{ vo.vContNm }}</td>
                  <td>{{ vo.vSuccessionContCd }}</td>
                  <td>{{ vo.vSuccessionContNm }}</td>
                </tr>
              </template>
              <template v-else>
                <tr>
                  <td colspan="6">
                    <div class="no-result">
                      {{ t('common.msg.no_data') }}
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>

        <div class="board-bottom">
          <div class="board-bottom__inner">
            <Pagination
              v-if="list && list.length > 0"
              :page-info="page"
              @click="fnSearch"
            >
            </Pagination>
            <div class="ui-buttons ml-auto ui-buttons__right">
              <button
                type="button"
                class="ui-button ui-button__bg--skyblue font-weight__300"
                @click="fnApply"
              >승계</button>
              <button
                type="button"
                class="ui-button ui-button__bg--skyblue font-weight__300"
                @click="fnClose"
              >닫기</button>
          </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, inject, reactive, onMounted, ref } from 'vue'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'UserSearchPop',
  components: {
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue'))
  },
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          searchFlag: 'ALL',
        }
      }
    }
  },
  emits: ['selectFunc', 'closeFunc'],
  setup (props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')

    const { openAsyncAlert, openAsyncConfirm } = useActions(['openAsyncAlert', 'openAsyncConfirm'])
    
    const {
      list,
      page,
      selectMayContainList,
      insertMayContainCloneSucc,
    } = useProcessCommon()

    const searchParams = reactive({
      vLabNoteCd: props.popParams.vLabNoteCd || '',
      vKeyword: '',
      nowPageNo: 1
    })

    const payload = ref({
      vLabNoteCd: props.popParams.vLabNoteCd,
      vSuccessionCd: '',
    })

    const fnSearch = async (pg) => {
      if (!pg) {
        pg = 1
      }

      searchParams.nowPageNo = pg

      payload.value.vSuccessionCd = ''

      await selectMayContainList(searchParams)
    }

    const fnApply = async () => {
      if (commonUtils.isEmpty(payload.value.vSuccessionCd)) {
        openAsyncAlert({ message: '선택 된 값이 없습니다.' })
      } else {
        if (!await openAsyncConfirm({ message: '선택 한 제품을 승계 하시겠습니까?' })) {
          return
        }

        const result = await insertMayContainCloneSucc(payload.value)

        if (result === 'SUCC') {
          await openAsyncAlert({ message: '정상적으로 승계되었습니다.' })
          const returnObj = {
            vFlagCloneYn: 'N',
            vFlagTempReg: 'N',
            vTargetCd: payload.value.vSuccessionCd
          }
          context.emit('selectFunc', returnObj)
          context.emit('closeFunc')
        }
      }
    }

    const fnClose = () => {
      context.emit('closeFunc')
    }

    const init = () => {
      fnSearch(1)
    }

    init()

    onMounted(() => {
      const input = document.querySelector('#vUserSearchPopKeyword')
      input.focus()
    })

    return {
      t,
      searchParams,
      page,
      list,
      fnSearch,
      fnApply,
      fnClose,
      payload,
    }
  }
}
</script>

<style scoped>
  .ui-table tbody tr {
    cursor: pointer;
  }
</style>