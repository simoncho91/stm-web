<template>
  <div class="modal-content modal-content__width--950">
    <div class="modal-header">
      <div class="modal-title">May Contain 생성</div>
      <button type="button" class="modal-close" @click="fnClose()"></button>
    </div>
    <div class="modal-body">

      <div class="board-top mt-20">
        <div class="ui-buttons ui-buttons__right">
          <button
            type="button"
            class="ui-button ui-button__border--blue"
            @click="fnOpenMayContainSearchPop()"
          >기존  May Contain 찾기</button>
        </div>
      </div>

      <div class="version-tab__top mt-10 mb-0">
        <div class="version-tab__top__inner">
          <template v-if="resData.contList?.length > 0">
            <ul class="ui-list version-tab__top__lists">
              <li
                v-for="(vo, idx) in resData.contList"
                :key="`li_cont_${idx}`"
                :class="['version-tab__top__list', vPopParams.vContPkCd === vo.vContPkCd ? 'is-active' : '']"
              >
                <a href="#" class="version-tab__top__link" @click.prevent="fnChangeCont(vo.vContPkCd)">{{ vo.vContCd }}</a>
              </li>
            </ul>
          </template>
        </div>
      </div>

      <div class="">
        <div class="ui-table__wrap">
          <table class="ui-table text-center ui-table__td--40">
            <colgroup>
              <col style="width:10%">
              <col style="width:30%">
              <col style="width:30%">
              <col style="width:15%">
              <col style="width:15%">
            </colgroup>
            <thead>
              <tr>
                <th>성분코드</th>
                <th>표시명(한글)</th>
                <th>표시명(영문)</th>
                <th>함량</th>
                <th>기능</th>
              </tr>
            </thead>
            <tbody>
              <template v-if="resData.contentsList && resData.contentsList.length > 0">
                <tr v-for="(vo, idx) in resData.contentsList" :key="'tr_content_' + idx">
                  <td>{{ vo.vConcd }}</td>
                  <td>{{ vo.vPsnameKo }}</td>
                  <td>{{ vo.vPsnameEn }}</td>
                  <td>{{ vo.nConPer }}</td>
                  <td>{{ vo.vFcnameKo }}</td>
                </tr>
              </template>
              <template v-else>
                <tr>
                  <td colspan="5">
                    <div class="no-result">
                      {{ t('common.msg.no_data') }}
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>

      <div class="mt-20"></div>

      <div class="">
        <div class="ui-table__wrap">
          <table class="ui-table text-center ui-table__td--40">
            <colgroup>
              <col style="width:10%">
              <col style="width:15%">
              <col style="width:30%">
              <col style="width:30%">
              <col style="width:15%">
            </colgroup>
            <thead>
              <tr>
                <th>
                  <ap-input-check
                    v-model:model="chkAll"
                    :value="'Y'"
                    :false-value="'N'"
                    :id="'ex_check_all'"
                    @click="fnCheckAll"
                  >
                  </ap-input-check>
                </th>
                <th>성분코드</th>
                <th>표시명(한글)</th>
                <th>표시명(영문)</th>
                <th>기능</th>
              </tr>
            </thead>
            <tbody>
              <template v-if="resData.mcList && resData.mcList.length > 0">
                <tr v-for="(mvo, idx) in resData.mcList" :key="'tr_mc_' + idx">
                  <td>
                    <ap-input-check
                      v-model:model="mvo.vFlagUseYn"
                      :value="'Y'"
                      :false-value="'N'"
                      :id="`ex_check_${idx}`"
                      @click="fnAddMayContainTarget($event)"
                    >
                    </ap-input-check>
                  </td>
                  <td>{{ mvo.vSuccTag === 'Y' ? '[승계] ' : '' }}{{ mvo.vConcd }}</td>
                  <td>{{ mvo.vConnameEn }}</td>
                  <td>{{ mvo.vConnameKo }}</td>
                  <td>{{ mvo.vFcnameKo }}</td>
                </tr>
              </template>
              <template v-else>
                <tr>
                  <td colspan="4">
                    <div class="no-result">
                      {{ t('common.msg.no_data') }}
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>

      <div class="mt-20"></div>

      <div class="search-bar__col">
        <dl class="search-bar__item">
          <dt class="search-bar__key">May Contain 국문</dt>
          <dd class="search-bar__val">
            <div class="ui-textarea-box ui-textarea-box__height--100">
              <ap-text-area :is-with-byte="false" v-model:value="resData.mvo.vMayContainKo" :read-only="true"></ap-text-area>
            </div>
          </dd>
        </dl>
        <dl class="search-bar__item">
          <dt class="search-bar__key">May Contain 영문</dt>
          <dd class="search-bar__val">
            <div class="ui-textarea-box ui-textarea-box__height--100">
              <ap-text-area :is-with-byte="false" v-model:value="resData.mvo.vMayContainEn" :read-only="true"></ap-text-area>
            </div>
          </dd>
        </dl>
      </div>

      <div class="board-bottom">
        <div class="board-bottom__inner">
          <div class="ui-buttons ml-auto ui-buttons__right">
            <button
              type="button"
              class="ui-button ui-button__bg--skyblue font-weight__300"
              @click="fnSave"
            >저장</button>
          </div>
        </div>
      </div>

    </div>
    <teleport to="#common-modal-sub" v-if="popContent">
      <ap-popup>
        <component
          :is="popContent"
          :pop-params="popupParams"
          @selectFunc="popSelectFunc"
          @closeFunc="popCloseFunc"
        />
      </ap-popup>
    </teleport>
  </div>
  <div id="common-modal-sub"></div>
</template>

<script>
import { inject, ref, defineAsyncComponent } from 'vue'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'MayContainCreatePop',
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    MayContainSearchPop: defineAsyncComponent(() => import('@/components/makeup/popup/MayContainSearchPop.vue')),
  },
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: '',
          vContPkCd: '',
          vLeaveType: '',
          vLand: '',
          vFlagTempReg: '',
        }
      }
    }
  },
  emits: ['selectFunc'],
  setup (props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')

    const { openAsyncAlert, openAsyncConfirm, closeAsyncPopup } = useActions(['openAsyncAlert', 'openAsyncConfirm', 'closeAsyncPopup'])

    const vPopParams = ref({ ...props.popParams })

    // const mayContainTargetList = ref([])
    const chkAll = ref('N')

    const resData = ref({
      mvo: {
        vLabNoteCd: vPopParams.value.vLabNoteCd,
        vMayContainEn: '',
        vMayContainKo: '',
        vSuccessionCd: '', 
      }
    })

    const popContent = ref(null)
    const popSelectFunc = ref(null)
    const popCloseFunc = ref(null)
    const popupParams = ref({})

    const {
      selectCreateMayContainRequiredInfo,
      insertMayContain,
    } = useProcessCommon()

    const fnClose = () => {
      closeAsyncPopup({ message: '' })
    }

    const fnSave = async () => {
      if (resData.value?.mcList?.length === 0) {
        openAsyncAlert({ message: '저장 가능한 May Contain 값이 없습니다.' })
        return
      }

      const payload = {
        ...vPopParams.value,
        ...resData.value
      }

      if (!await openAsyncConfirm({ message: 'May Contain을 저장 하시겠습니까?'})) {
        return
      }

      const result = await insertMayContain(payload)

      if (result === 'SUCC') {
        context.emit('selectFunc')
      }
    }

    const init = async (vFlagUpdateYn) => {
      let payload = vPopParams.value

      if (vFlagUpdateYn && vFlagUpdateYn === 'Y') {
        payload = {
          ...payload,
          vFlagUpdateYn: 'Y',
          mcList: resData.value.mcList
        }
      }

      const result = await selectCreateMayContainRequiredInfo(payload)

      if (result) {
        if (result.contList) {
          resData.value.contList = result.contList
        }
        if (result.contentsList) {
          resData.value.contentsList = result.contentsList
        }
        if (result.mcList) {
          resData.value.mcList = result.mcList

          if (resData.value.mcList.every(mvo => mvo.vFlagUseYn === 'Y')) {
            chkAll.value = 'Y'
          } else {
            chkAll.value = 'N'
          }
        }
        if (commonUtils.isNotEmpty(result.mvo)) {
          resData.value.mvo = { ...resData.value.mvo, ...result.mvo }
        } else {
          resData.value.mvo.vMayContainKo = ''
          resData.value.mvo.vMayContainEn = ''
        }
      }
    }

    const initFirst = () => {
      openAsyncAlert({ message: 'May Contain 생성 시 각각의 내용물 코드의 성분코드 정보를 불러오기에 데이터를 불러오는데 시간이 걸릴 수 있습니다.<br><span style=\"color : red; font-weight: bold;\">*임시저장 상태로 변경 되므로 작업 종료 후 저장을 꼭 해주세요.</span>' })

      init()
    }

    const fnChangeCont = (contPkCd) => {
      vPopParams.value.vContPkCd = contPkCd
      vPopParams.value.vFlagTempReg = 'N'

      init()
    }

    const fnCheckAll = (value) => {
      // if (value === 'Y') {
      //   mayContainTargetList.value = resData.value.contList.map(cvo => cvo.vContPkCd)
      // } else {
      //   mayContainTargetList.value = []
      // }
      if (resData.value?.mcList?.length > 0) {
        resData.value.mcList.forEach(mvo => {
          mvo.vFlagUseYn = value === 'Y' ? 'Y' : 'N'
        })
      }

      vPopParams.value.vFlagTempReg = 'N'

      init('Y')
    }

    const fnAddMayContainTarget = (value) => {
      // const targetList = mayContainTargetList.value

      if (value) {
        // May Contain 대상 체크했을 때
        // if (targetList.length === resData.value.mcList.length) {
        if (resData.value.mcList.every(mvo => mvo.vFlagUseYn === 'Y')) {
          chkAll.value = 'Y'
        }
      } else {
        // May Contain 대상 체크 해제했을 때
        chkAll.value = 'N'
      }

      vPopParams.value.vFlagTempReg = 'N'

      init('Y')
    }

    const fnOpenMayContainSearchPop = () => {
      popupParams.value = {
        vLabNoteCd: vPopParams.value.vLabNoteCd,
      }

      popSelectFunc.value = settingValue
      popCloseFunc.value = closeMayContainSearchPop

      popContent.value = 'MayContainSearchPop'
    }

    const settingValue = (vo) => {
      if (vo?.vTargetCd) {
        resData.value.mvo.vSuccessionCd = vo.vTargetCd
      }
      
      vPopParams.value.vFlagTempReg = vo.vFlagTempReg

      init()
    }

    const closeMayContainSearchPop = () => {
      popContent.value = null
    }

    initFirst()

    return {
      t,
      fnClose,
      fnChangeCont,
      chkAll,
      fnCheckAll,
      // mayContainTargetList,
      fnAddMayContainTarget,
      resData,
      vPopParams,
      fnOpenMayContainSearchPop,
      fnSave,
      popContent,
      popSelectFunc,
      popCloseFunc,
      popupParams,
    }
  }
}
</script>

<style scoped>
  .ui-table tbody tr {
    cursor: pointer;
  }
</style>