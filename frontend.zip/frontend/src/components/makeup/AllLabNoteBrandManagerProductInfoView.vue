<template>
  <div class="basic-info__table">
    <table class="ui-table__contents">
      <colgroup>
        <col style="width:17rem">
        <col style="width:auto">
        <col style="width:17rem">
        <col style="width:auto">
      </colgroup>
      <tbody>
        <tr>
          <th>향료정보</th>
          <td colspan="3">
            {{ versionInfo.vPerfumeNm }} 
            <template v-if="versionInfo.vPerfumeCd === 'LNC11_03'">
              ({{ versionInfo.vFlagPerfumeNew === 'Y' ? '신향' : '기존향' }})
            </template>
          </td>
        </tr>
        <tr v-if="versionInfo.vPerfumeCd !== 'LNC11_99'">
          <td colspan="4">
            <MateSearchResultTableView
              :mate-list="versionInfo.perfMateList"
              stock-dt-yn="Y"
            ></MateSearchResultTableView>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, inject, watch } from 'vue'

export default {
  name: 'AllLabNoteMakeupProductInfoView',
  components: {
    MateSearchResultTableView: defineAsyncComponent(() => import('@/components/labcommon/MateSearchResultTableView.vue')),
  },
  props: {
    versionInfo: {
      type: Object,
      default: () => {
        return {}
      }
    },
  },
  setup () {
    return {}
  }
}
</script>