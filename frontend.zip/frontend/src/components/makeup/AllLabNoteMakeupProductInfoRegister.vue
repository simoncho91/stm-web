<template>
  <div class="basic-info__table">
    <table class="ui-table__contents">
      <colgroup>
        <col style="width:17rem">
        <col style="width:auto">
        <col style="width:17rem">
        <col style="width:auto">
      </colgroup>
      <tbody>
        <!-- 카운터 -->
        <tr>
          <th>카운터</th>
          <td colspan="3">
            <div class="ui-radio__list">
              <div class="ui-radio__inner">
                <ap-input-radio
                  v-model:model="verParams.vCounterTypeCd"
                  id="counter_none"
                  name="counterType"
                  value=""
                  label="없음"
                  @click="changeCounterTypeCd(verParams, verParams.vCounterTypeCd);"
                >
                </ap-input-radio>
                <template v-if="codeGroupMaps['LNC04']">
                  <ap-input-radio
                    v-for="(vo, index) in codeGroupMaps['LNC04'].filter(item => commonUtils.isNotEmpty(item.vBuffer1) && item.vBuffer1.indexOf('MU') > -1)"
                    :key="'counter_' + index"
                    v-model:model="verParams.vCounterTypeCd"
                    :value="vo.vSubCode"
                    :label="vo.vSubCodenm"
                    :id="'counter_' + index"
                    name="counterType"
                    @click="changeCounterTypeCd(verParams, verParams.vCounterTypeCd);"
                  >
                  </ap-input-radio>
                </template>
              </div>
            </div>
          </td>
        </tr>
        <tr v-if="verParams.vCounterTypeCd !== ''">
          <td colspan="4" class="inside-td">
            <table class="ui-table__contents">
              <colgroup>
                <col style="width:14rem">
              </colgroup>
              <tbody>
                <!-- 자사 -->
                <tr v-if="verParams.vCounterTypeCd === 'LNC04_01'">
                  <th>자사카운터</th>
                  <td>
                    <div class="search-form" id="error_wrap_vCounterNmTemp">
                      <div class="search-form__inner">
                        <ap-input
                          v-model:value="verParams.vCounterNmTemp"
                          input-class="ui-input__width--450"
                          placeholder="검색어를 입력하세요."
                          @keypress-enter="fnCounterSearchPop()"
                        >
                        </ap-input>
                        <button type="button" class="button-search" @click="fnCounterSearchPop()">검색</button>
                        <button type="button" class="button-search" @click="removeCounterInfo()">삭제</button>
                      </div>
                      <span class="error-msg" id="error_msg_vCounterNmTemp"></span>
                    </div>
                  </td>
                </tr>
                <!-- 타사 -->
                <template v-if="verParams.vCounterTypeCd === 'LNC04_02'">
                  <tr>
                    <th>브랜드</th>
                    <td id="error_wrap_vCounterBrdNm">
                      <ap-input
                        v-model:value="verParams.vCounterBrdNm"
                        :maxlength="200"
                        input-class="ui-input__width--340"
                        @input="fnValidate('vCounterBrdNm')"
                      >
                      </ap-input>
                      <span class="error-msg" id="error_msg_vCounterBrdNm"></span>
                    </td>
                  </tr>
                  <tr>
                    <th>제품명</th>
                    <td id="error_wrap_vCounterPrdNm">
                      <ap-input
                        v-model:value="verParams.vCounterPrdNm"
                        :maxlength="200"
                        input-class="ui-input__width--340"
                        @input="fnValidate('vCounterPrdNm')"
                      >
                      </ap-input>
                      <span class="error-msg" id="error_msg_vCounterPrdNm"></span>
                    </td>
                  </tr>
                </template>
                <!-- 신제형(SP) -->
                <template v-if="verParams.vCounterTypeCd === 'LNC04_03'">
                  <tr>
                    <th>SP 정보</th>
                    <td id="error_wrap_vCounterSpInfo">
                      <ap-input
                        v-model:value="verParams.vCounterSpInfo"
                        :maxlength="300"
                        input-class="ui-input__width--340"
                        @input="fnValidate('vCounterSpInfo')"
                      >
                      </ap-input>
                      <span class="error-msg" id="error_msg_vCounterSpInfo"></span>
                    </td>
                  </tr>
                  <tr>
                    <th>선행파일럿</th>
                    <td id="error_wrap_vPrePilotDt">
                      <ap-date-picker
                        v-model:date="verParams.vPrePilotDt"
                        @update:date="fnValidate('vPrePilotDt')"
                      >
                      </ap-date-picker>
                      <span class="error-msg" id="error_msg_vPrePilotDt"></span>
                    </td>
                  </tr>
                </template>
                <!-- 공통 -->
                <tr>
                  <th>비고</th>
                  <td>
                    <div class="ui-textarea-box" id="error_wrap_vCounterNote">
                      <ap-text-area
                        v-model:value="verParams.vCounterNote"
                        :is-with-byte="true"
                        :maxlength="1000"
                        id="vCounterNote"
                      ></ap-text-area>
                      <span class="error-msg" id="error_msg_vCounterNote"></span>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        
        <!-- 신원료 유무 -->
        <tr>
          <th>신원료 유무<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
          <td colspan="3">
            <div class="ui-radio__list" id="error_wrap_vFlagNewItem">
              <div class="ui-radio__inner">
                <ap-input-radio
                  v-for="(vo, index) in [{vSubCode: 'Y', vSubCodenm: '유'}, {vSubCode: 'N', vSubCodenm: '무'}]" :key="'newItem_' + index"
                  v-model:model="verParams.vFlagNewItem"
                  :value="vo.vSubCode"
                  :label="vo.vSubCodenm"
                  :id="'newItem_' + index"
                  name="newItem"
                  @click="resetMateList(verParams.vFlagNewItem, verParams, 'newMateList');fnValidate('vFlagNewItem')"
                ></ap-input-radio>
              </div>
              <span class="error-msg" id="error_msg_vFlagNewItem"></span>
            </div>
          </td>
        </tr>
        <!-- 신원료 'Y'일 경우 -->
        <tr v-if="verParams.vFlagNewItem === 'Y'">
          <td colspan="4" class="inside-td">
            <table class="ui-table__contents">
              <colgroup>
                <col style="width:14rem">
              </colgroup>
              <tbody>
                <tr>
                  <th>신원료 추가</th>
                  <td>
                    <div class="search-form">
                      <div class="search-form__inner">
                        <ap-input
                          v-model:value="searchParams.mateNewKeyword"
                          input-class="ui-input__width--340"
                          placeholder="검색어를 입력하세요."
                          @keypress-enter="fnOpenMateSearchPop(searchParams.mateNewKeyword, 'Y', getSearchNewMateResult, 'tempSearch')"
                        >
                        </ap-input>
                        <button type="button" class="button-search" @click="fnOpenMateSearchPop(searchParams.mateNewKeyword, 'Y', getSearchNewMateResult, 'tempSearch')">검색</button>
                      </div>
                    </div>
                  </td>
                </tr>
                <tr v-if="verParams.newMateList.length > 0">
                  <td colspan="2">
                    <MateSearchResultTableRegister
                      v-model:mate-list="verParams.newMateList"
                      type="new"
                      stock-dt-yn="Y"
                      mate-chg-yn="Y"
                    >
                    </MateSearchResultTableRegister>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <!-- 향료정보 -->
        <tr>
          <th>향료정보</th>
          <td colspan="3">
            <div class="ui-radio__list">
              <div class="ui-radio__inner">
                <ap-input-radio
                  v-for="(vo, index) in fragDivList" :key="'fragType_' + index"
                  v-model:model="verParams.vPerfumeCd"
                  :value="vo.vSubCode"
                  :label="vo.vSubCodenm"
                  :id="'fragType_' + index"
                  name="fragType"
                  @click="resetMateList(verParams.vPerfumeCd, verParams, 'perfMateList');"
                ></ap-input-radio>
              </div>
            </div>
          </td>
        </tr>
        <tr v-if="verParams.vPerfumeCd !== '' && verParams.vPerfumeCd !== 'LNC11_99'">
          <td colspan="4" class="inside-td">
            <table class="ui-table__contents">
              <colgroup>
                <col style="width:14rem">
              </colgroup>
              <tbody>
                <tr>
                  <th>향료 추가</th>
                  <td>
                    <div class="form-flex">
                      <!-- 향료 변경일 경우만 해당 영역 노출 -->
                      <div class="ui-select-box form-flex__cell--5 mr-20" v-if="verParams.vPerfumeCd === 'LNC11_03'">
                        <div class="ui-radio__list">
                          <div class="ui-radio__inner">
                            <ap-input-radio
                              v-for="(vo, index) in [{vSubCode: 'Y', vSubCodenm: '신향'}, {vSubCode: 'N', vSubCodenm: ' 기존향'}]" :key="'fragranceNew_' + index"
                              v-model:model="verParams.vFlagPerfumeNew"
                              :value="vo.vSubCode"
                              :label="vo.vSubCodenm"
                              :id="'fragranceNew_' + index"
                              name="fragranceNew"
                            ></ap-input-radio>
                          </div>
                        </div>
                      </div>
                      <div class="ui-select-box form-flex__cell--5">
                        <div class="search-form">
                          <div class="search-form__inner">
                            <ap-input
                              v-model:value="searchParams.perfumeKeyword"
                              input-class="ui-input__width--340"
                              placeholder="검색어를 입력하세요."
                              @keypress-enter="fnOpenMateSearchPop(searchParams.perfumeKeyword, 'Y', getSearchPerfMateResult)"
                            >
                            </ap-input>
                            <button type="button" class="button-search" @click="fnOpenMateSearchPop(searchParams.perfumeKeyword, 'Y', getSearchPerfMateResult)">검색</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </td>
                </tr>
                <tr v-if="verParams.perfMateList.length > 0">
                  <td colspan="2">
                    <MateSearchResultTableRegister
                      v-model:mate-list="verParams.perfMateList"
                      type="perf"
                      stock-dt-yn="Y"
                    >
                    </MateSearchResultTableRegister>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <!-- 기능성 -->
        <tr>
          <th>기능성</th>
          <td colspan="3">
            <div class="ui-checkbox__list">
              <div class="ui-checkbox__inner">
                <ap-input-check
                  v-for="vo in verParams.funcList"
                  v-model:model="vo.vTag2Cd"
                  :key="'func_' + vo.vSubCode"
                  :value="vo.vSubCode"
                  :label="vo.vSubCodenm"
                  :id="'func_' + vo.vSubCode"
                  :disabled="verParams.vRefTypeCd === 'LNC05_02'"
                >
                </ap-input-check>
              </div>
            </div>
          </td>
        </tr>
        <tr v-if="verParams.funcList && verParams.funcList.length > 0 && verParams.funcList.filter(vo => commonUtils.isNotEmpty(vo.vTag2Cd)).length > 0">
          <td colspan="4" class="inside-td">
            <table class="ui-table__contents">
              <colgroup>
                <col style="width:17rem">
              </colgroup>
              <tbody>
                <tr class="ui-table__contents--item">
                  <td colspan="4">
                    <div class="ui-table__contents--tr">
                      <div class="ui-table__contents--th">
                        관련근거
                      </div>
                      <div class="ui-table__contents--td">
                        <div class="ui-radio__list">
                          <div class="ui-radio__inner">
                            <ap-input-radio
                              v-for="(vo, index) in codeGroupMaps['LNC05']" :key="'refType_' + index"
                              v-model:model="verParams.vRefTypeCd"
                              :value="vo.vSubCode"
                              :label="vo.vSubCodenm"
                              :id="'refType_' + index"
                              name="refType"
                            ></ap-input-radio>
                          </div>
                        </div>
                      </div>
                    </div>
                    <!-- LNC05_03, LNC05_04 신규, 변경일 때 -->
                    <div class="ui-table__contents--tr" v-if="verParams.vRefTypeCd === 'LNC05_03' || verParams.vRefTypeCd === 'LNC05_04'">
                      <div class="ui-table__contents--th">
                        심사항목
                      </div>
                      <div class="ui-table__contents--td">
                        <ap-input
                          v-model:value="verParams.vRefNote"
                          :maxlength="200"
                          input-class="ui-input__width--340"
                        >
                        </ap-input>
                      </div>
                    </div>
                    <!-- LNC05_02 : 보고일 때 -->
                    <div class="ui-table__contents--tr" v-if="verParams.vRefTypeCd === 'LNC05_02'">
                      <div class="ui-table__contents--th">
                        심사번호
                      </div>
                      <div class="ui-table__contents--td">
                        <div class="form-flex"><!-- loop 영역 mt-10-->
                          <div class="form-flex__cell--5">
                            <div class="search-form">
                              <div class="search-form__inner">
                                <ap-input
                                  v-model:value="verParams.vEvaluateno"
                                  input-class="ui-input__width--340"
                                  :readonly="true"
                                  @click="fnOpenEvaluateSearchPop('N')"
                                >
                                </ap-input>
                                <button type="button"
                                  class="ui-button ui-button__circle ui-button__close input-close-btn--310"
                                  @click="removeEvaluateInfo('N')"
                                ></button>
                                <button type="button" class="ui-button ui-button__width-auto button-search" @click="fnOpenEvaluateSearchPop('N')">심사번호 찾기</button>
                              </div>
                            </div>
                          </div>
                          <div class="form-flex__cell--5" v-if="!showGosiFlag">
                            <button type="button"
                              class="ui-button ui-button__border--blue" @click="fnGosiFlag()">추가</button>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="ui-table__contents--tr" v-if="verParams.vRefTypeCd === 'LNC05_02' && showGosiFlag">
                      <div class="ui-table__contents--th"></div>
                      <div class="ui-table__contents--td">
                        <div class="form-flex"><!-- loop 영역 mt-10-->
                          <div class="form-flex__cell--5">
                            <div class="search-form">
                              <div class="search-form__inner">
                                <ap-input
                                  v-model:value="verParams.vEvaluateGosiNo"
                                  input-class="ui-input__width--340"
                                  :readonly="true"
                                  @click="fnOpenEvaluateSearchPop('Y')"
                                >
                                </ap-input>
                                <button type="button"
                                  class="ui-button ui-button__circle ui-button__close input-close-btn--310"
                                  @click="removeEvaluateInfo('Y')"
                                ></button>
                                <button type="button" class="button-search" @click="fnOpenEvaluateSearchPop('Y')">검색</button>
                              </div>
                            </div>
                          </div>
                          <div class="form-flex__cell--5" v-if="showGosiFlag">
                            <button type="button"
                              class="ui-button ui-button__border--blue" @click="fnGosiFlag()">삭제</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </td>
                </tr>
                <tr class="ui-table__contents--item">
                  <td colspan="4">
                    <div class="ui-table__contents--tr">
                      <div class="ui-table__contents--th">
                        기능성 원료 추가
                      </div>
                      <div class="ui-table__contents--td">
                        <div class="form-flex">
                          <div class="form-flex__cell--5">
                            <div class="search-form">
                              <div class="search-form__inner">
                                <ap-input
                                  v-model:value="searchParams.funcKeyword"
                                  input-class="ui-input__width--340"
                                  placeholder="원료를 검색해주세요."
                                  @keypress-enter="fnOpenMateSearchPop(searchParams.funcKeyword, 'Y', getSearchFuncMateResult, 'tempSearch')"
                                >
                                </ap-input>
                                <button type="button" class="button-search" @click="fnOpenMateSearchPop(searchParams.funcKeyword, 'Y', getSearchFuncMateResult, 'tempSearch')">원료추가</button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </td>
                </tr>
                <tr v-if="verParams.funcMateList.length > 0">
                  <td colspan="4" class="td-padding__y--0">
                    <MateSearchResultTableRegister
                      v-model:mate-list="verParams.funcMateList"
                      type="func"
                    >
                    </MateSearchResultTableRegister>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <!-- 필수 원료 -->
        <tr>
          <th>필수원료</th>
          <td>
            <div class="form-flex form-flex__col">
              <div class="form-flex__cell form-flex__cell--5">
                <div class="search-form">
                  <div class="search-form__inner">
                    <ap-input
                      input-class="ui-input__width--340"
                      placeholder="원료를 검색해주세요."
                      @keypress-enter="fnOpenMateSearchPop(searchParams.requKeyword, 'N', getSearchRequMateResult)"
                    >
                    </ap-input>
                    <button type="button" class="button-search" @click="fnOpenMateSearchPop(searchParams.requKeyword, 'N', getSearchRequMateResult)">원료추가</button>
                  </div>
                </div>
              </div>
            </div>
          </td>
        </tr>
        <tr v-if="verParams.requMateList.length > 0">
          <td colspan="4">
            <MateSearchResultTableRegister
              v-model:mate-list="verParams.requMateList"
              type="requ"
            >
            </MateSearchResultTableRegister>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @selectFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, ref, reactive, inject, watch } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useCode } from '@/compositions/useCode'
import { useActions } from 'vuex-composition-helpers'
import { useStore } from 'vuex'

export default {
  name: 'AllLabNoteMakeupProductInfoRegister',
  components: {
    MateSearchResultTableRegister: defineAsyncComponent(() => import('@/components/labcommon/MateSearchResultTableRegister.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    MateSearchPop: defineAsyncComponent(() => import('@/components/labcommon/popup/MateSearchPop.vue')),
    CounterSearchPop: defineAsyncComponent(() => import('@/components/labcommon/popup/CounterSearchPop.vue')),
    EvaluateSearchPop: defineAsyncComponent(() => import('@/components/labcommon/popup/EvaluateSearchPop.vue')),
  },
  props: {
    versionInfo: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  setup (props) {
    const t = inject('t')
    const reqInfo = inject('reqInfo')
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert } = useActions(['openAsyncAlert'])
    const store = useStore()
    const noteType = store.getters.getNoteType()
    const showGosiFlag = ref(false)
    const notAdd = ref(null)
    const fragDivList = ref(null)

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const arrMstCode = [
      'LNC04', 'LNC11', 'LNC05'
    ]

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenMateSearchPop,
      fnOpenPopup,
      resetMateList,
      changeCounterTypeCd,
      selectFuncMateList,
    } = useLabCommon()

    const searchParams = reactive({
      mateNewKeyword: '',
      perfumeKeyword: '',
      funcKeyword: '',
      requKeyword: ''
    })

    const verParams = ref({
      vCounterTypeCd: '',
      vCounterCd: '',
      vCounterContPkCd: '',
      vCounterInvenCd: '',
      vCounterInvenJoinCd: '',
      vCounterSpCd: '',
      vCounterInvenNm: '',
      vCounterContNm: '',
      vCounterBrdNm: '',
      vCounterPrdNm: '',
      vCounterSpInfo: '',
      vCounterNmTemp: '',
      vPrePilotDt: '',
      vCounterNote: '',
      vFlagNewItem: '',
      newMateList: [],
      vPerfumeCd: '',
      vFlagPerfumeNew: '',
      perfMateList: [],
      vFlagFuncTest: '',
      funcList: [],
      vRefTypeCd: '',
      vEvaluateno: '',
      vEvaluateCd: '',
      vEvaluateGosiNo: '',
      vEvaluateGosiCd: '',
      vFlagGosi: '',
      vRefNote: '',
      funcMateList: [],
      requMateList: [],
    })

    const mateDefaultObj = {
      vFlagTo100: '',
      nMateRate: '',
      vMatePutDt: '',
      vMateNote: '',
      vFlagMateNew: 'Y'
    }

    const getSearchPerfMateResult = (list) => {
      const perfMateDefault = {
        vMateEvalCd: '',
        vMateFuncCd: '',
        vFlagRequired: 'N',
      }
      list.forEach(item => {
        const perfMateList = verParams.value.perfMateList.filter(vo => vo.vKey === item.vKey)
        if (perfMateList.length === 0) {
          verParams.value.perfMateList.push({ ...item, ...mateDefaultObj, ...perfMateDefault })
        }
      })
    }

    const getSearchNewMateResult = (list) => {
      const newMateDefault = {
        vMateEvalCd: '',
        vMateFuncCd: '',
        vFlagRequired: 'N',
      }
      list.forEach(item => {
        const newMateList = verParams.value.newMateList.filter(vo => vo.vKey === item.vKey)
        if (newMateList.length === 0) {
          verParams.value.newMateList.push({ ...item, ...mateDefaultObj, ...newMateDefault })
        }
      })
    }

    const getSearchFuncMateResult = (list) => {
      const funcMateDefault = {
        vMateEvalCd: '',
        vMateFuncCd: '',
        vFlagRequired: 'N',
      }
      list.forEach(item => {
        const funcMateList = verParams.value.funcMateList.filter(vo => vo.vKey === item.vKey)
        if (funcMateList.length === 0) {
          verParams.value.funcMateList.push({ ...item, ...mateDefaultObj, ...funcMateDefault })
        }
      })
    }

    const getSearchRequMateResult = (list) => {
      const requMateDefault = {
        vMateEvalCd: '',
        vMateFuncCd: '',
        vFlagRequired: 'N',
      }
      list.forEach(item => {
        const requMateList = verParams.value.requMateList.filter(vo => vo.vKey === item.vKey)
        if (requMateList.length === 0) {
          verParams.value.requMateList.push({ ...item, ...mateDefaultObj, ...requMateDefault })
        }
      })
    }

    const fnCounterSearchPop = () => {
      const plantCd = store.getters.getNoteInfo().vPlantCd

      if (commonUtils.isEmpty(plantCd)) {
        openAsyncAlert({ message: '플랜트를 선택해 주세요.' })
        return
      }

      popParams.value = {
        vKeyword: verParams.value.vCounterNmTemp,
        vNoteType: noteType,
        vPlantCd: plantCd,
        vCodeType: 'HAL3',
        vDefaultTab: 'labNoteSearch',
      }

      popSelectFunc.value = getCounterInfo
      fnOpenPopup('CounterSearchPop')
    }

    const getCounterInfo = (item) => {
      if (commonUtils.isNotEmpty(item.vInvenJoinCd)) {
        verParams.value.vCounterCd = ''
        verParams.value.vCounterContPkCd = ''
        verParams.value.vCounterInvenCd = item.vInvenJoinCd
        verParams.value.vCounterInvenJoinCd = item.vInvenJoinCd
        verParams.value.vCounterNmTemp = '[' + item.vInvenJoinPjtCd + '] ' + item.vSubmitInvenNm
      } else {
        verParams.value.vCounterCd = item.vLabNoteCd
        verParams.value.vCounterContPkCd = item.vContPkCd
        verParams.value.vCounterInvenCd = ''
        verParams.value.vCounterInvenJoinCd = ''

        if (commonUtils.isNotEmpty(item.vLabNoteCd)) {
          verParams.value.vCounterNmTemp = '[' + item.vContCd + '] ' + item.vContNm
        } else {
          verParams.value.vCounterNmTemp = ''
        }
      }

      fnValidate('vCounterNmTemp')
    }

    const removeCounterInfo = () => {
      verParams.value.vCounterNmTemp = ''
      verParams.value.vCounterCd = ''
      verParams.value.vCounterContPkCd = ''
      verParams.value.vCounterInvenCd = ''
      verParams.value.vCounterInvenJoinCd = ''
      fnValidate('vCounterNmTemp')
    }

    const fnOpenEvaluateSearchPop = (flag) => {
      const selectedEff = []
      verParams.value.vFlagGosi = flag

      verParams.value.funcList.forEach(item => {
        if (commonUtils.isNotEmpty(item.vTag2Cd)) {
          selectedEff.push(item.vTag2Cd)
        }
      })
      popParams.value = {
        arrEff: selectedEff
      }
      popSelectFunc.value = getEvaludateInfo
      fnOpenPopup('EvaluateSearchPop')
    }

    const getEvaludateInfo = async (item) => {
      if (verParams.value.vFlagGosi !== 'Y') {
        verParams.value.vEvaluateno = item.vEvaluateno
        verParams.value.vEvaluateCd = item.vEvaluateCd

        verParams.value.funcList.forEach(vo => {
          if (commonUtils.isNotEmpty(item.vFunctionCd) && item.vFunctionCd.indexOf(vo.vSubCode) > -1) {
            vo.vTag2Cd = vo.vSubCode
            document.querySelector('#func_' + vo.vSubCode).checked = true
          } else {
            vo.vTag2Cd = ''
            document.querySelector('#func_' + vo.vSubCode).checked = false
          }
        })
      } else {
        verParams.value.vEvaluateGosiNo = item.vEvaluateno
        verParams.value.vEvaluateGosiCd = item.vEvaluateCd
      }

      const arrFunctionCd = []
      verParams.value.funcList.forEach(item => {
        if (commonUtils.isNotEmpty(item.vTag2Cd)) {
          arrFunctionCd.push(item.vTag2Cd)
        }
      })

      const payload = {
        vEvaluateCd: item.vEvaluateCd,
        arrFunctionCd
      }

      const result = await selectFuncMateList(payload)

      if (result && result.length > 0) {
        const funcMateDefault = {
          vMateEvalCd: '',
          vMateFuncCd: '',
          vFlagRequired: 'N',
          vFlagMateNew: 'Y',
        }
        result.forEach(mate => {
          verParams.value.funcMateList.push({...funcMateDefault, ...mate})
        })
      }
    }

    const removeEvaluateInfo = (gosiFlag) => {
      const funcMateList = verParams.value.funcMateList
      if (gosiFlag !== 'Y') {
        if (funcMateList && funcMateList.length > 0) {
          verParams.value.funcMateList = funcMateList.filter(mate => mate.vMateEvalCd !== verParams.value.vEvaluateCd)
        }

        verParams.value.vEvaluateno = ''
        verParams.value.vEvaluateCd = ''
      } else {
        if (funcMateList && funcMateList.length > 0) {
          verParams.value.funcMateList = funcMateList.filter(mate => mate.vMateEvalCd !== verParams.value.vEvaluateGosiCd)
        }

        verParams.value.vEvaluateGosiNo = ''
        verParams.value.vEvaluateGosiCd = ''
      }
    }

    const fnGosiFlag = () => {
      showGosiFlag.value = !showGosiFlag.value

      if (!showGosiFlag.value) {
        verParams.value.vEvaluateGosiNo =  ''
        verParams.value.vEvaluateGosiCd =  ''
      }
    }

    const fnValidateAll = (arrChkKey) => {
      let isOk = true
      commonUtils.hideErrorMessageAll(arrChkKey)

      arrChkKey.forEach(key => {
        if (!fnValidate(key)) {
          isOk = false
        }
      })

      return isOk
    }

    const fnValidate = (key) => {
      let isOk = true
      let errorMsg = '필수 입력 사항입니다.'
      commonUtils.hideErrorMessage(key)

      if (key === 'vCounterNmTemp') {
        if (verParams.value.vCounterTypeCd === 'LNC04_01' && 
              commonUtils.isEmpty(verParams.value.vCounterInvenCd) && 
              commonUtils.isEmpty(verParams.value.vCounterContPkCd)) { // 카운터 : 자사
          isOk = false
        }
      } else if (key === 'vCounterBrdNm' || key === 'vCounterPrdNm') { // 카운터 : 타사
        if (verParams.value.vCounterTypeCd === 'LNC04_02' && commonUtils.isEmpty(verParams.value[key])) {
          isOk = false
        }
      } else if (key === 'vCounterSpInfo' || key === 'vPrePilotDt') { // 카운터 : 신제형
        if (verParams.value.vCounterTypeCd === 'LNC04_03' && commonUtils.isEmpty(verParams.value[key])) {
          isOk = false
        }
      } else if (key === 'vCounterNote') {
        if (!commonUtils.checkByte(verParams.value.vCounterNote, 1000)) {
          isOk = false
          errorMsg = t('common.msg.byte_msg2', { byteSize: commonUtils.setNumberComma(1000) })
        }
      } else if (commonUtils.isEmpty(verParams.value[key])) {
        isOk = false
      }

      if (!isOk) {
        commonUtils.showErrorMessage(key, errorMsg)
      }

      return isOk
    }

    const init = async () => {
      if (props.versionInfo && !props.versionInfo.funcList) {
        arrMstCode.push('EV_MATERIAL_FUNC2')
      } 
      await findCodeList(arrMstCode)
      fragDivList.value = commonUtils.getCodeList(codeGroupMaps, 'LNC11', 'BKR')

      verParams.value = { ...verParams.value, ...props.versionInfo }

      if (codeGroupMaps.value['EV_MATERIAL_FUNC2']) {
        verParams.value.funcList = codeGroupMaps.value['EV_MATERIAL_FUNC2']
      }

      if (commonUtils.isNotEmpty(verParams.value.vCounterInvenCd)) {
        verParams.value.vCounterNmTemp = '[' + verParams.value.vCounterSpCd + '] ' + verParams.value.vCounterInvenNm
      } else {
        verParams.value.vCounterNmTemp = verParams.value.vCounterContNm
      }
    }

    init()

    watch(() => reqInfo.value, (newValue) => {
      verParams.value = { ...verParams.value, ...newValue.versionInfo }

      if (commonUtils.isNotEmpty(verParams.value.vCounterInvenCd)) {
        verParams.value.vCounterNmTemp = '[' + verParams.value.vCounterSpCd + '] ' + verParams.value.vCounterInvenNm
      } else {
        verParams.value.vCounterNmTemp = verParams.value.vCounterContNm
      }
    })

    watch(() => props.versionInfo, (newValue) => {
      verParams.value = { ...verParams.value, ...newValue }
    })

    return {
      codeGroupMaps,
      fragDivList,
      verParams,
      searchParams,
      commonUtils,
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenMateSearchPop,
      getSearchPerfMateResult,
      getSearchNewMateResult,
      getSearchFuncMateResult,
      getSearchRequMateResult,
      fnCounterSearchPop,
      getCounterInfo,
      removeCounterInfo,
      removeEvaluateInfo,
      fnOpenEvaluateSearchPop,
      showGosiFlag,
      fnGosiFlag,
      fnValidateAll,
      fnValidate,
      notAdd,
      resetMateList,
      changeCounterTypeCd,
    }
  }
}
</script>