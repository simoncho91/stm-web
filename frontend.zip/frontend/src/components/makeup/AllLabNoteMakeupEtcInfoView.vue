<template>
  <div class="contents-box__tab mt-15">
    <ApTab
        mst-id="etcInfoTab"
        :tab-list="etcTabList"
        :tab-style="['contents-box__tab--inner', 'contents-box__tab--list', 'contents-box__tab--item', 'contents-box__tab--link']"
        :default-tab="selectTab"
        @click="getSelectedTabEvent"
      >
      </ApTab>
      <div class="contents-box__inner min-height__unset" id="etcTab01" v-show="selectTab === 'etcTab01'">
        <div class="note-table__inner">
          <table class="ui-table ui-table__td--40 text-center">
            <colgroup>
              <col style="width:15rem;">
              <col style="width:20rem;">
              <col style="width:15rem;">
              <col style="width:50rem;">
            </colgroup>
            <thead>
              <tr>
                <th>실험노트 구분</th>
                <th>내용물 코드</th>
                <th>버전</th>
                <th>내용물명 / 과제명</th>
              </tr>
            </thead>
            <tbody>
              <template v-if="counterList && counterList.length > 0">
                <tr v-for="(vo, idx) in counterList" :key="'counter_' + idx">
                  <td>{{ vo.vLabTypeNm }}</td>
                  <td>
                    <router-link class="a-deco-none" :to="{ path: goCounterDetail(vo), query: {vLabNoteCd: vo.vLabNoteCd }}" target="_blank">
                      {{ vo.vContCd }}
                    </router-link>
                  </td>
                  <td>
                    <router-link class="a-deco-none" :to="{ path: goCounterDetail(vo), query: {vLabNoteCd: vo.vLabNoteCd }}" target="_blank">
                      {{ vo.vVersionNm }}
                    </router-link>
                  </td>
                  <td>
                    <router-link class="a-deco-none" :to="{ path: goCounterDetail(vo), query: {vLabNoteCd: vo.vLabNoteCd }}" target="_blank">
                      {{ vo.vContNm }}
                    </router-link>
                  </td>
                </tr>
              </template>
              <template v-else>
                <tr>
                  <td colspan="4">
                    <div class="no-result">
                      {{ t('common.msg.no_data') }}
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>
      <template v-if="completeInfo.vStatusCd === 'LNC06_50'">
        <div class="contents-box__inner min-height__unset" id="etcTab02" v-show="selectTab === 'etcTab02'">
          <table class="ui-table__th--bg-gray">
            <colgroup>
              <col style="width:14rem;">
              <col style="width:auto">
              <col style="width:14rem;">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr>
                <th>최종 출시 완료일</th>
                <td>
                  {{ commonUtils.changeStrDatePattern(completeInfo.vCompleteDt) }}
                </td>
                <td></td>
                <td>
                  <button
                    v-if="showReleaseModifyBtn()"
                    type="button"
                    class="ui-button ui-button__width--81 ui-button__height--23 ui-button__radius--2 ui-button__bg--blue f-right"
                    @click="fnLaunchCompletePop()"
                  >출시완료 수정</button>
                </td>
              </tr>
              <tr>
                <td
                  colspan="4"
                  class="inside-td"
                >
                  <table class="ui-table__contents"
                    :class="idx !== 0 ? 'mt-15' : ''"
                    v-for="(vo, idx) in completeInfo.compContList" :key="'compCont_' + idx"
                  >
                    <colgroup>
                      <col style="width:10rem">
                      <col style="width:auto">
                    </colgroup>
                    <tbody>
                      <tr>
                        <td colspan="2">
                          <p class="p_bold">[{{ vo.vContCd }}] [{{ vo.vPlantCd }}] {{ vo.vContNm }}</p>
                        </td>
                      </tr>
                      <tr>
                        <th>출시완료일</th>
                        <td>
                          {{ commonUtils.changeStrDatePattern(vo.vLaunchCompleteDt) }}
                        </td>
                      </tr>
                      <tr>
                        <th>카운터</th>
                        <td>
                          {{ vo.vCompleteCounterContNm }}
                        </td>
                      </tr>
                      <tr>
                        <th>비고</th>
                        <td>
                          {{ vo.vCompleteCounterNote }}
                        </td>
                      </tr>
                      <tr class="tr_vertical" v-if="vo.releaseDateList && vo.releaseDateList.length > 0">
                        <th>출시정보</th>
                        <td>
                          <template v-for="(release, idx) in vo.releaseDateList" :key="'release_' + idx">
                            <p class="p-mb5">{{ release.prdCd }} ({{ commonUtils.changeStrDatePattern(release.zzfsdat) }})</p>
                          </template>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </template>
  </div>
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { ref, reactive, defineAsyncComponent, inject, watch } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useStore } from 'vuex'

export default {
  name: 'AllLabNoteMakeupEtcInfoView',
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    LaunchCompletePop: defineAsyncComponent(() => import('@/components/labcommon/popup/LaunchCompletePop.vue')),
  },
  setup () {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const reqInfo = inject('reqInfo')
    const store = useStore()
    const myInfo = store.getters.getMyInfo()

    const {
      popupContent,
      popParams,
      fnOpenPopup,
    } = useLabCommon()

    const etcTabList = ref([])
    const counterList = ref([])
    const info = ref({})
    const completeInfo = reactive({
      vCompleteDt: '',
      vFlagNp: '',
      vFlagNpNm: '',
      compContList: [],
      vStatusCd: ''
    })
    const selectTab = ref('etcTab01')
    const getSelectedTabEvent = (item) => {
      selectTab.value = item.tabId
    }

    const goCounterDetail = (item) => {
      const labTypeCd = item.vLabTypeCd === 'LNC07_01' ? 'prd' : (item.vLabTypeCd === 'LNC07_02' ? 'half' : 'nonprd')

      return `/makeup/all-lab-note-${labTypeCd}-view`
    }

    const showReleaseModifyBtn = () => {
      let isVisible = false

      if ((info.value && info.value.vSlUserid === myInfo.loginId) || commonUtils.checkAuth('S000000')) {
        isVisible = true
      }

      return isVisible
    }

    const fnLaunchCompletePop = () => {
      popParams.value = {
        vLabNoteCd: info.value.vLabNoteCd,
        vFlagCompleteModify: 'Y'
      }

      fnOpenPopup('LaunchCompletePop')
    }

    const init = () => {
      const counterLen = reqInfo.value.counterList ? reqInfo.value.counterList.length : 0
      etcTabList.value = [
        { tabId: 'etcTab01', tabNm: '해당 내용물을 카운터로 사용한 내용물 (' + counterLen +')'}
      ]

      completeInfo.vStatusCd = reqInfo.value.vStatusCd

      if (reqInfo.value.vStatusCd === 'LNC06_50') {
        etcTabList.value.push({ tabId: 'etcTab02', tabNm: '출시 완료 정보' })

        completeInfo.vCompleteDt = reqInfo.value.vCompleteDt
        completeInfo.vFlagNp = reqInfo.value.vFlagNp
        completeInfo.vFlagNpNm = reqInfo.value.vFlagNpNm
        completeInfo.compContList = reqInfo.value.compContList

        if (reqInfo.value.releaseDateList && reqInfo.value.releaseDateList.length > 0) {
          completeInfo.compContList = completeInfo.compContList.map(comp => {
            return {
              ...comp,
              releaseDateList: reqInfo.value.releaseDateList.filter(release => comp.vContCd === release.contCd) || []
            }
          })
        }
      }

      counterList.value = [ ...reqInfo.value.counterList ]
      info.value = { ...reqInfo.value }
    }

    watch(() => reqInfo.value, (newValue) => {
      if (newValue) {
        init()
      }
    })

    return {
      t,
      commonUtils,
      etcTabList,
      selectTab,
      counterList,
      completeInfo,
      popupContent,
      popParams,
      getSelectedTabEvent,
      goCounterDetail,
      showReleaseModifyBtn,
      fnLaunchCompletePop,
    }
  }
}
</script>