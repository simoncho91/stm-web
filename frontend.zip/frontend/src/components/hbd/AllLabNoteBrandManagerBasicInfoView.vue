<template>
  <div class="basic-information">
    <div class="basic-information__inner">
      <div class="basic-information__info">
        <div class="basic-information__detail">
          <div class="basic-information__img">
            <img v-if="info.vProdType2Cd" :src="`/product/${info.vProdType2Cd}.png`" />
          </div>
          <!-- <div class="basic-information__name">{{ info.vUsernm }}</div> -->
        </div>
        <div class="basic-information__brand">{{ info.vBrdNm }}</div>
        <div class="basic-information__title">{{ info.vContNm }}</div>
        <div class="basic-information__status">
          <div>{{ info.vLabTypeNm }}</div>
          <div>{{ info.vStatusNm }}</div>
        </div>
      </div>

      <div class="basic-information__table">
        <div class="ui-table__basic-information--wrap">
          <table class="ui-table__basic-information note_contents_tb">
            <colgroup>
              <col style="width:16rem">
              <col style="width:auto">
              <col style="width:16rem">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr v-if="info.vFlagOem === 'Y'">
                <th>브랜드</th>
                <td >
                  {{ info.vBrdNm }} [OEM: {{ info.vOemManufacturer }}]
                </td>
                <th>플랜트</th>
                <td>
                  {{ info.vPlantNm }} / {{ info.vSiteTypeNm }}
                </td>
              </tr>
              <tr>
                <th>제품유형</th>
                <td colspan="3">
                  {{ info.vProdType1Nm }} {{ commonUtils.isNotEmpty(info.vProdType1Nm) ? '-' : '' }} {{ info.vProdType2Nm }}
                  <template v-if="Number(info.vProdType2Cd.replace('MTR02_', '')) > 90">
                    ({{ info.vProdTypeNote }})
                  </template>
                </td>
              </tr>
              <tr>
                <th>신상품 여부</th>
                <td>
                  {{ info.vFlagNew === 'Y' ? 'NEW' : 'AD' }}
                </td>
                <th>에어로졸 여부</th>
                <td>
                  {{ regParams.vFlagAerosol === 'Y' ? '에어로졸' : '일반' }}
                </td>
              </tr>
              <tr>
                <th>적용 부위/방식</th>
                <td>
                  {{ info.vPartNm }} / {{ info.vLeaveTypeNm }}
                </td>
                <th>용기정보</th>
                <td>
                  {{ info.vContainerNm }} {{ commonUtils.isNotEmpty(info.vContainerEtc) ? '-' : '' }} {{ info.vContainerEtc }}
                </td>
              </tr>
              <tr>
                <th>출시국가/시기</th>
                <td colspan="3" class="inside-td inside-td__nation">
                  <table class="ui-table__product">
                    <colgroup>
                      <col style="width:10rem">
                    </colgroup>
                    <tbody>
                      <tr
                        v-for="(key, index) in Object.keys(releaseMap)"
                        :key="'countryList_' + index"
                        class="ui-table__contents--item"
                      >
                        <th>{{ releaseMap[key].ariaNm }}</th>
                        <td>
                          <template v-if="info['vFlagRelease' + key] === 'N'">
                            대상아님
                          </template>
                          <template v-else-if="info['vFlagRelease' + key] === 'U'">
                            미정
                          </template>
                          <template v-else>
                            <template v-for="(vo, idx) in releaseMap[key].countryList" :key="'release_' + idx">
                              {{ idx !== 0 ? ', ' : '' }}{{ vo.vSubCodenm }} ({{commonUtils.changeStrDatePattern(vo.vTagBuffer1, '.')}})
                            </template>
                          </template>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              <tr>
                <th>파일럿</th>
                <td>
                  {{ commonUtils.changeStrDatePattern(info.vPilotDt) }}
                </td>
                <th>생산회의</th>
                <td>
                  {{ commonUtils.changeStrDatePattern(info.vMeetingDt) }}
                </td>
              </tr>
              <tr>
                <th>첨부파일</th>
                <td colspan="3">
                  <UploadFileView
                    v-if="commonUtils.isNotEmpty(info.vLabNoteCd)"
                    uploadid="HBO_NOTE_ATT01"
                    :recordid="info.vLabNoteCd"
                  >
                  </UploadFileView>
                </td>
              </tr>
              <tr>
                <th>비고</th>
                <td colspan="3" v-html="commonUtils.removeHTMLChangeBr(info.vNote)"></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, inject, watch } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'

export default {
  name: 'AllLabNoteBrandManagerBasicInfoView',
  components: {
    UploadFileView: defineAsyncComponent(() => import('@/components/comm/UploadFileView.vue')),
  },
  setup () {
    const reqInfo = inject('reqInfo')
    const commonUtils = inject('commonUtils')

    const {
      releaseMap,
    } = useLabCommon()

    const info = ref({
      vProdType2Cd: '',
      vBrdNm: '',
      vContNm: '',
      vLabTypeNm: '',
      vStatusNm: '',
      vBrdNm: '',
      vFlagOem: '',
      vOemManufacturer: '',
      vPlantNm: '',
      vSiteTypeNm: '',
      vProdType1Nm: '',
      vProdType2Nm: '',
      vProdTypeNote: '',
      vFlagNew: '',
      vFlagAerosol: '',
      vPartNm: '',
      vLeaveTypeNm: '',
      vContainerNm: '',
      vContainerEtc: '',
      releaseList: [],
      vPilotDt: '',
      vMeetingDt: '',
      vNote: '',
    })

    watch(() => reqInfo.value, (newValue) => {
      if (newValue) {
        info.value = { ...info.value, ...newValue }

        if (info.value.releaseList && info.value.releaseList.length > 0) {
          info.value.releaseList.forEach(item => {
            if (commonUtils.isNotEmpty(item.vTag2Cd)) {
              releaseMap.value[item.vBuffer1].countryList.push({ ...item })
            }
          })
        }
      }
    })

    return {
      info,
      commonUtils,
      releaseMap,
    }
  }
}
</script>