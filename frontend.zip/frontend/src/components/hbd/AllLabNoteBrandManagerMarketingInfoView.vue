<template>
  <div class="arrordion-item is-active">
    <div class="arrordion-header">
      <div class="arrordion-title">마케팅 정보</div>
      <button type="button" class="ui-button__accordion"></button>
    </div>
    <div class="arrordion-body">
      <table class="ui-table__th--bg-gray note_contents_tb">
        <colgroup>
          <col style="width:12rem">
          <col style="width:38rem">
          <col style="width:12rem">
          <col style="width:38rem">
        </colgroup>
        <tbody>
          <tr>
            <th>소비자가격/실제품용량</th>
            <td>
              <template v-if="commonUtils.isNotEmpty(info.nPrice)">
                {{ commonUtils.setNumberComma(info.nPrice) }} 원/ {{ commonUtils.setNumberComma(info.nProductCapacity) }} {{ info.vProductCapacityNm }}
              </template>
            </td>
            <th>타겟 Cost/100g</th>
            <td>
              <template v-if="commonUtils.isNotEmpty(info.nTargetCost)">
                {{ commonUtils.setNumberComma(info.nTargetCost) }} 원
              </template>
            </td>
          </tr>
          <tr>
            <th>안심감요소</th>
            <td colspan="3">
              <template v-if="info.reqEtcList && info.reqEtcList.length > 0">
                <template v-for="(vo, idx) in info.reqEtcList" :key="'reqEtc_' + idx">
                  {{ idx !== 0 ? ', ' : ''}}{{ vo.vSubCodenm }} {{ vo.vTag2Cd === 'LNC13_99' ? (commonUtils.isNotEmpty(vo.vTagBuffer2) ?'(' + vo.vTagBuffer2 + ')' : '') : '' }}
                </template>
              </template>
            </td>
          </tr>
          <tr>
            <th>효능 임상</th>
            <td colspan="3">
              <template v-if="info.effectList && info.effectList.length > 0">
                <template v-for="(vo, idx) in info.effectList" :key="'effect_' + idx">
                  {{ idx !== 0 ? ', ' : ''}}{{ vo.vSubCodenm }} {{ vo.vContent2 ? '(' + vo.vContent2 + ')' : '' }} {{ vo.vTag2Cd === 'LNC15_99' ? (commonUtils.isNotEmpty(vo.vTagBuffer2) ?'(' + vo.vTagBuffer2 + ')' : '') : '' }}
                </template>
              </template>
            </td>
          </tr>
          <tr v-if="info.effectList && info.effectList.length > 0 && info.effectList.filter(vo => commonUtils.isNotEmpty(vo.vTag2Cd)).length > 0">
            <td colspan="4" class="inside-td">
              <table class="ui-table__contents">
                <colgroup>
                  <col style="width:14rem">
                </colgroup>
                <tbody>
                  <tr>
                    <th>시험기간</th>
                    <td>
                      {{ info.nEffTestDcnt }} {{ info.vEffTestDcntUnitTxt }}
                    </td>
                  </tr>
                  <tr>
                    <th>소구문구</th>
                    <td>
                      {{ info.vEffTestSogooMemo }}
                    </td>
                  </tr>
                  <tr>
                    <th>임상 진행기관</th>
                    <td>
                      {{ info.vEffCompTypeNm }}
                    </td>
                  </tr>
                  <tr>
                    <th>임상 시작시점</th>
                    <td>
                      {{ commonUtils.changeStrDatePattern(info.vEffTestItemDt) }}
                    </td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>
          <tr>
            <th>안전성 임상</th>
            <td colspan="3">
              <template v-if="info.mti01List && info.mti01List.length > 0">
                <template v-for="(vo, idx) in info.mti01List" :key="'mti01_' + idx">
                  {{ idx !== 0 ? ', ' : ''}}{{ vo.vSubCodenm }} {{ vo.vContent2 ? '(' + vo.vContent2 + ')' : '' }} {{ vo.vTagBuffer2 ? '(' + vo.vTagBuffer2 + ')' : '' }}
                </template>
              </template>
            </td>
          </tr>
          <tr v-if="info.mti01List && info.mti01List.length > 0">
            <td colspan="4" class="inside-td">
              <table class="ui-table__contents">
                <colgroup>
                  <col style="width:14rem">
                </colgroup>
                <tbody>
                  <tr>
                    <th>임상 시작시점</th>
                    <td>
                      {{ commonUtils.changeStrDatePattern(info.vTestItemDt) }}
                      <!-- 논코메도제닉 (8주), 하이포알러제닉 (12주), 안과 (8주) -->
                      <template v-if="info.mti01List.filter(vo => vo.vTag2Cd !== '' && 'MTI01_02,MTI01_03,MTI01_04'.indexOf(vo.vTag2Cd) > -1).length > 0">
                        <p class="p_caution">
                          ※ "임상심의"를 파일럿 D-1 개월까지 완료
                        </p>
                      </template>
                    </td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>
          <tr>
            <th>ONE POINT (고객관점)</th>
            <td colspan="3">
              {{ info.vOnePoint }}
            </td>
          </tr>
          <tr>
            <th>사용 고객</th>
            <td colspan="3">
              <template v-if="info.tuserList && info.tuserList.length > 0">
                <template v-for="(vo, idx) in info.tuserList" :key="'tuser_' + idx">
                  {{ idx !== 0 ? ', ' : ''}}{{ vo.vSubCodenm }} {{vo.vContent2 ? '(' + vo.vContent2 + ')' : '' }} {{vo.vTagBuffer2 ? '(' + vo.vTagBuffer2 + ')' : '' }}
                </template>
              </template>
            </td>
          </tr>
          <tr>
            <th>타겟 고객</th>
            <td colspan="3">
              {{ info.vTargetCustomer }}
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
import { ref, inject, watch } from 'vue'

export default {
  name: 'AllLabNoteBrandManagerMarketingInfoView',
  setup () {
    const reqInfo = inject('reqInfo')
    const commonUtils = inject('commonUtils')

    const info = ref({
      nPrice: '',
      nProductCapacity: '',
      vProductCapacityNm: '',
      nTargetCost: '',
      reqEtcList: [],
      effectList: [],
      nEffTestDcnt: '',
      vEffTestDcntUnitTxt: '',
      vEffTestSogooMemo: '',
      vEffCompTypeNm: '',
      vEffTestItemDt: '',
      mti01List: [],
      vTestItemDt: '',
      vOnePoint: '',
      tuserList: [],
      vTargetCustomer: '',
    })

    watch(() => reqInfo.value, (newValue) => {
      info.value = {...info.value, ...{
        nPrice: newValue.nPrice,
        nProductCapacity: newValue.nProductCapacity,
        vProductCapacityNm: newValue.vProductCapacityNm,
        nTargetCost: newValue.nTargetCost,
        reqEtcList: newValue.reqEtcList,
        effectList: newValue.effectList,
        mti01List: newValue.mti01List,
        tuserList: newValue.tuserList,
        nEffTestDcnt: newValue.nEffTestDcnt,
        vEffTestDcntUnit: newValue.vEffTestDcntUnit,
        vEffTestSogooMemo: newValue.vEffTestSogooMemo,
        vEffCompTypeNm: newValue.vEffCompTypeNm,
        vEffTestItemDt: newValue.vEffTestItemDt,
        vTestItemDt: newValue.vTestItemDt,
        vOnePoint: newValue.vOnePoint,
        vTargetCustomer: newValue.vTargetCustomer,
      } }

      info.value.reqEtcList = [ ...info.value.reqEtcList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd))]
      info.value.effectList = [ ...info.value.effectList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)) ]
      info.value.mti01List = [ ...info.value.mti01List.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)) ]
    })

    return {
      info,
      commonUtils,
    }
  }
}
</script>