<template>
  <div class="note-table">
    <div class="note-table__inner">
      <table class="ui-table ui-table__td--40 text-center">
        <colgroup>
          <col style="width: 10.3%" />
          <col style="width: 8%" />
          <col style="width: auto" />
          <col style="width: auto" />
          <col style="width: 6.5%" />
          <col style="width: 6.5%" />
          <col style="width: 6.5%" />
          <col style="width: 7%" />
          <col style="width: 7%" />
          <col style="width: 2.5%" v-if="!commonUtils.checkAuth('S000333')"/>
          <col style="width: 2.5%" />
        </colgroup>
        <thead>
          <tr>
            <th>상태</th>
            <th>브랜드</th>
            <th>내용물명</th>
            <th>라인 내용물명</th>
            <th>라인담당자</th>
            <th>연구담당자</th>
            <th>
              생성일
              <button type="button"
                v-if="sortCol !== 'MCONT.V_REG_DTM' || (sortCol === 'MCONT.V_REG_DTM' && sortDir === 'DESC')"
                class="sort__btn sort__asc"
                @click="fnSort('MCONT.V_REG_DTM', 'ASC')">
              </button>
              <button type="button"
                v-if="sortCol !== 'MCONT.V_REG_DTM' || (sortCol === 'MCONT.V_REG_DTM' && sortDir === 'ASC')"
                class="sort__btn sort__desc"
                @click="fnSort('MCONT.V_REG_DTM', 'DESC')">
              </button>
            </th>
            <th>
              파일럿시기
              <button type="button"
                v-if="sortCol !== 'MCONT.V_PILOT_DT' || (sortCol === 'MCONT.V_PILOT_DT' && sortDir === 'DESC')"
                class="sort__btn sort__asc"
                @click="fnSort('MCONT.V_PILOT_DT', 'ASC')">
              </button>
              <button type="button"
                v-if="sortCol !== 'MCONT.V_PILOT_DT' || (sortCol === 'MCONT.V_PILOT_DT' && sortDir === 'ASC')"
                class="sort__btn sort__desc"
                @click="fnSort('MCONT.V_PILOT_DT', 'DESC')">
              </button>
            </th>
            <th>
              출시시기
              <button type="button"
                v-if="sortCol !== 'MCONT.V_RELEASE_DT' || (sortCol === 'MCONT.V_RELEASE_DT' && sortDir === 'DESC')"
                class="sort__btn sort__asc"
                @click="fnSort('MCONT.V_RELEASE_DT', 'ASC')">
              </button>
              <button type="button"
                v-if="sortCol !== 'MCONT.V_RELEASE_DT' || (sortCol === 'MCONT.V_RELEASE_DT' && sortDir === 'ASC')"
                class="sort__btn sort__desc"
                @click="fnSort('MCONT.V_RELEASE_DT', 'DESC')">
              </button>
            </th>
            <th v-if="!commonUtils.checkAuth('S000333')">복사</th>
            <th></th>
          </tr>
        </thead>
        <tbody v-if="info.list && info.list.length > 0">
          <template v-for="(vo, index) in info.list" :key="index">
            <tr class="tr-contents" :class="vo.isOpenStatusFirst ? 'is-active' : ''">
              <td v-if="vo.nSort === 1" :rowspan="vo.nRowCnt">{{ vo.vStatusNm }}</td>
              <td v-if="vo.nSort === 1" :rowspan="vo.nRowCnt">{{ vo.vBrdNm }}</td>
              <td  class="tit" v-if="vo.nSort === 1" :rowspan="vo.nRowCnt">
                <div class="tit__inner">
                  <a href="#" class="tit-link" @click.prevent="goDetailPage(vo)">
                    <span class="txt_blue">{{ vo.vMainContCd }}</span> {{ vo.vMainContNm }}
                  </a>
                </div>
              </td>
              <td class="tit">
                <template v-if="commonUtils.isNotEmpty(vo.vSubContNm)">
                  <div class="tit__inner">
                    <a href="#"
                      class="tit-link"
                      :class="vo.vSubFlagCancel === 'Y' ? 'cancel_prd' : ''"
                      @click="goDetailPage(vo)"
                    >
                      <span :class="vo.vSubFlagCancel !== 'Y' ? 'txt_blue' : ''">{{ vo.vSubContCd }}</span> {{ vo.vSubContNm }} {{ vo.vSubFlagCancel === 'Y' ? '(개발취소)' : '' }}
                    </a>
                  </div>
                </template>
              </td>
              <td :class="vo.vSubFlagCancel === 'Y' ? 'cancel_prd' : ''">{{ vo.vSubUsernm }}</td>
              <td v-if="vo.nSort === 1" :rowspan="vo.nRowCnt">{{ vo.vUsernm }}</td>
              <td v-if="vo.nSort === 1" :rowspan="vo.nRowCnt">{{ commonUtils.changeStrDatePattern(vo.vRegDtm) }}</td>
              <td v-if="vo.nSort === 1" :rowspan="vo.nRowCnt">{{ commonUtils.changeStrDatePattern(vo.vPilotDt) }}</td>
              <td v-if="vo.nSort === 1" :rowspan="vo.nRowCnt">{{ commonUtils.changeStrDatePattern(vo.vReleaseDt) }}</td>
              <td v-if="vo.nSort === 1 && !commonUtils.checkAuth('S000333')" :rowspan="vo.nRowCnt">
                  <button
                    type="button"
                    class="copy__button--icon copy__button--icon-copy"
                    @click="goCopy(vo.vLabNoteCd)"
                  >
                  </button>
              </td>
              <td v-if="vo.nSort === 1" :rowspan="vo.nRowCnt">
                <button
                  v-if="vo.vStatusCd !== 'LNC06_01'"
                  type="button"
                  class="ui-button__accordion"
                  @click="fnOpenStatus(vo)"></button>
              </td>
            </tr>
            <tr class="tr-process" :class="vo.isOpenStatus ? 'is-active' : ''" v-if="vo.nSort === vo.nRowCnt">
              <!-- 활성화시 tr-process 옆에 is-active 추가 -->
              <td :colspan="!commonUtils.checkAuth('S000333') ? 11 : 10">
                <NoteProcessBar
                  v-if="vo.progressInfo && vo.progressInfo.length > 0"
                  :progress-info="vo.progressInfo"
                  :is-big="false"
                  :is-show-date="true"
                  :is-cancel="vo.vFlagCancel == 'Y' ? true : false"
                >
                </NoteProcessBar>
              </td>
            </tr>
          </template>
        </tbody>
        <tbody v-else>
          <tr>
            <td :colspan="!commonUtils.checkAuth('S000333') ? 11 : 10">
              <div class="no-result">
                {{ t('common.msg.no_data') }}
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <div class="board-bottom">
    <div class="board-bottom__inner">
      <Pagination :page-info="info.page" @click="onPaging"> </Pagination>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, inject, watch } from 'vue'
import { useStore } from 'vuex'
import { useHbdRequest } from '@/compositions/hbd/useHbdRequest'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'

export default {
  name: 'AllLabNoteListTable',
  components: {
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
    NoteProcessBar: defineAsyncComponent(() => import('@/components/labcommon/NoteProcessBar.vue')),
  },
  props: {
    resultList: {
      type: Array,
      default: () => {
        return []
      }
    },
    resultPage: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  emits: ['onPaging', 'onSorting'],
  setup (props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const store = useStore()
    const noteType = store.getters.getNoteType()
    const info = ref({
      list: [],
      page: {}
    })

    const sortCol = ref('')
    const sortDir = ref('')

    const {
      goModify, 
      goView, 
    } = useHbdRequest()

    const {
      selectProgressBar
    } = useProcessCommon()

    const {
      fnSetRecentLog,
    } = useLabCommon()

    const onPaging = (pg) => {
      context.emit('onPaging', pg)
    }

    const goDetailPage = async (item) => {
      if (commonUtils.isNotEmpty(item.vMainContCd)) {
        const data = {
          vNoteType: noteType,
          vLabNoteCd: item.vLabNoteCd,
          vContCd: item.vMainContCd,
          vContNm: item.vMainContNm,
          vTctnBynmNm: item.vTctnBynmNm,
          vPageType: 'prd'
        }
        await fnSetRecentLog(data)
      }
      sessionStorage.removeItem('searchParamsDashboardHBO')
      goView(item.vLabNoteCd)
    }

    const fnOpenStatus = async (item) => {
      const lastIdx = item.nRowCnt
      const list = info.value.list
      const noteInfo = list.filter(v => v.vLabNoteCd === item.vLabNoteCd && v.nSort === 1)
      const lastInfo = list.filter(v => v.vLabNoteCd === item.vLabNoteCd && v.nSort === lastIdx)

      if (noteInfo && noteInfo.length > 0) {
        noteInfo[0].isOpenStatusFirst = !noteInfo[0].isOpenStatusFirst
      }

      if (lastInfo && lastInfo.length > 0) {
        lastInfo[0].isOpenStatus = !lastInfo[0].isOpenStatus

        if (lastInfo[0].progressCall !== 'Y') {
          const result = await selectProgressBar({ vLabNoteCd: item.vLabNoteCd })
          
          lastInfo[0].progressInfo = result.progressInfo
          lastInfo[0].vFlagCancel = result.vFlagCancel == undefined ? 'N' : result.vFlagCancel

          lastInfo[0].progressCall = 'Y'
        }
      }
    }

    const fnSort = (vSortCol, vSortDir) => {
      sortCol.value = vSortCol
      sortDir.value = vSortDir

      const sortInfo = {
        vSortCol,
        vSortDir
      }

      context.emit('onSorting', sortInfo)
    }

    const goCopy = (vLabNoteCd) => {
      goModify(vLabNoteCd, 'Y')
    }

    watch(() => props.resultList, (newVal) => {
      info.value.list = newVal
    })

    watch(() => props.resultPage, (newVal) => {
      info.value.page = newVal
    })

    return {
      t,
      commonUtils,
      onPaging,
      goDetailPage,
      fnOpenStatus,
      goCopy,
      fnSort,
      info,
      sortCol,
      sortDir,
    }
  }
}
</script>