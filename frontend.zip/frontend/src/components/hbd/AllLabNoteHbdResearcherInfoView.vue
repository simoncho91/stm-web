<template>
  <div class="arrordion-item is-active">
    <div class="arrordion-header">
      <div class="arrordion-title">연구원 정보</div>
      <button type="button" class="ui-button__accordion"></button>
    </div>

    <div class="arrordion-body">
      <table class="ui-table__th--bg-gray note_contents_tb">
        <colgroup>
          <col style="width:12rem">
          <col style="width:38rem">
          <col style="width:12rem">
          <col style="width:38rem">
        </colgroup>
        <tbody>
          <tr>
            <th>섹션 리더 / CTC</th>
            <td>
              {{ info.vSlUsernm }}
            </td>
            <th>브랜드 담당 PM</th>
            <td>
              {{ info.vBrdUsernm }}
            </td>
          </tr>
          <tr>
            <th>향 담당자</th>
            <td>
              {{ info.vPerfUsernm }}
            </td>
            <th>연구 담당자</th>
            <td>
              <template v-if="commonUtils.isNotEmpty(info.vUserid)">
                {{ info.vUsernm }} ( {{ info.vUserid }} / {{ info.vUsrDeptnm }} )
              </template>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
import { ref, inject, watch } from 'vue'
export default {
  name: 'AllLabNoteHbdResearcherInfoView',
  setup () {
    const reqInfo = inject('reqInfo')
    const commonUtils = inject('commonUtils')

    const info = ref({
      vSlUserid: '',
      vSlUsernm: '',
      vBrdUserid: '',
      vBrdUsernm: '',
      vPerfUserid: '',
      vPerfUsernm: '',
      vUserid: '',
      vUsernm: '',
      vUsrDeptnm: '',
    })

    watch(() => reqInfo.value, (newValue) => {
      info.value = { ...info.value, ...newValue }
    })

    return {
      commonUtils,
      info,
    }
  }
}
</script>