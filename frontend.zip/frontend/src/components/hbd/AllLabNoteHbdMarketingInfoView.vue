<template>
  <div class="arrordion-item is-active">
    <div class="arrordion-header">
      <div class="arrordion-title">마케팅 정보</div>
      <button type="button" class="ui-button__accordion"></button>
    </div>
    <div class="arrordion-body">
      <table class="ui-table__th--bg-gray note_contents_tb">
        <colgroup>
          <col style="width:12rem">
          <col style="width:38rem">
          <col style="width:12rem">
          <col style="width:38rem">
        </colgroup>
        <tbody>
          <tr>
            <th>소비자가격/실제품용량</th>
            <td>
              <template v-if="commonUtils.isNotEmpty(info.nPrice)">
                {{ commonUtils.setNumberComma(info.nPrice) }} 원/ {{ commonUtils.setNumberComma(info.nProductCapacity) }} {{ info.vProductCapacityNm }}
              </template>
            </td>
            <th>타겟 Cost/100g</th>
            <td>
              <template v-if="commonUtils.isNotEmpty(info.nTargetCost)">
                {{ commonUtils.setNumberComma(info.nTargetCost) }} 원
              </template>
            </td>
          </tr>
          <tr>
            <th>고객조사 시점</th>
            <td>
              {{ commonUtils.changeStrDatePattern(info.vCustResearchDt) }}
            </td>
            <th>안심감요소</th>
            <td>
              <template v-if="info.reqEtcList && info.reqEtcList.length > 0">
                <template v-for="(vo, idx) in info.reqEtcList" :key="'reqEtc_' + idx">
                  {{ idx !== 0 ? ', ' : ''}}{{ vo.vSubCodenm }} {{ vo.vTag2Cd === 'LNC13_99' ? (commonUtils.isNotEmpty(vo.vTagBuffer2) ?'(' + vo.vTagBuffer2 + ')' : '') : '' }}
                </template>
              </template>
            </td>
          </tr>
          <tr>
            <th>효능 임상</th>
            <td class="inside-td" colspan="3">
              <div class="pl-20 mt-15">
                <template v-if="info.effectList && info.effectList.length > 0">
                  <template v-for="(vo, idx) in info.effectList" :key="'effect_' + idx">
                    {{ idx !== 0 ? ', ' : ''}}{{ vo.vSubCodenm }} {{ vo.vContent2 ? '(' + vo.vContent2 + ')' : '' }} {{ vo.vTag2Cd === 'LNC15_99' ? (commonUtils.isNotEmpty(vo.vTagBuffer2) ?'(' + vo.vTagBuffer2 + ')' : '') : '' }}
                  </template>
                </template>
              </div>
              <table class="ui-table__product mt-1" v-if="info.effectList && info.effectList.length > 0">
                <colgroup>
                  <col style="width:14rem">
                  <col style="width:auto">
                </colgroup>
                <tbody>
                  <tr class="ui-table__contents--item">
                    <th>시험기간</th>
                    <td>
                      {{ info.nEffTestDcnt }} {{ info.vEffTestDcntUnitTxt }}
                    </td>
                  </tr>
                  <tr class="ui-table__contents--item">
                    <th>소구문구</th>
                    <td>
                      {{ info.vEffTestSogooMemo }}
                    </td>
                  </tr>
                  <tr class="ui-table__contents--item">
                    <th>임상 진행기관</th>
                    <td>
                      {{ info.vEffCompTypeNm }}
                    </td>
                  </tr>
                  <tr class="ui-table__contents--item">
                    <th>임상 시작시점</th>
                    <td>
                      {{ commonUtils.changeStrDatePattern(info.vEffTestItemDt) }}
                    </td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>
          <tr>
            <th>안전성 임상</th>
            <td class="inside-td" colspan="3">
              <table class="ui-table__product mt-15">
                <colgroup>
                  <col style="width:14rem">
                  <col style="width:auto">
                </colgroup>
                <tbody>
                  <tr class="ui-table__contents--item">
                    <th>구분</th>
                    <td>
                      <template v-if="info.mti01List && info.mti01List.length > 0">
                        <template v-for="(vo, idx) in info.mti01List" :key="'mti01_' + idx">
                          {{ idx !== 0 ? ', ' : ''}}{{ vo.vSubCodenm }} {{ vo.vContent2 ? '(' + vo.vContent2 + ')' : '' }} {{ vo.vTagBuffer2 ? '(' + vo.vTagBuffer2 + ')' : '' }}
                        </template>
                      </template>
                    </td>
                  </tr>
                  <tr class="ui-table__contents--item">
                    <th>임상 시작시점</th>
                    <td>
                      <div class="form-flex">
                        <div class="form-flex-cell form-flex__cell--5">
                          {{ commonUtils.changeStrDatePattern(info.vTestItemDt) }}
                        </div>
                        <template v-if="info.mti01List.filter(vo => vo.vTag2Cd !== '' && 'MTI01_02,MTI01_03,MTI01_04'.indexOf(vo.vTag2Cd) > -1).length > 0">
                          <div class="form-flex-cell form-flex__cell--5">
                            <p class="p_caution" style="margin-top: 1rem;">
                              ※ "임상심의"를 파일럿 D-1 개월까지 완료
                            </p>
                          </div>
                        </template>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>
          <tr>
            <th>ONE POINT (고객관점)</th>
            <td colspan="3">
              {{ info.vOnePoint }}
            </td>
          </tr>
          <tr>
            <th>사용 고객</th>
            <td colspan="3">
              <template v-if="info.tuserList && info.tuserList.length > 0">
                <template v-for="(vo, idx) in info.tuserList" :key="'tuser_' + idx">
                  {{ idx !== 0 ? ', ' : ''}}{{ vo.vSubCodenm }} {{vo.vContent2 ? '(' + vo.vContent2 + ')' : '' }} {{vo.vTagBuffer2 ? '(' + vo.vTagBuffer2 + ')' : '' }}
                </template>
              </template>
            </td>
          </tr>
          <tr>
            <th>타겟 고객</th>
            <td colspan="3">
              {{ info.vTargetCustomer }}
            </td>
          </tr>
          <tr>
            <th>
              무소구 항목
              <button
                v-if="showNotAddIngredientModifyBtn()"
                type="button"
                class="ui-button ui-button__width--40 ui-button__height--23 ml-10 ui-button__border--blue ui-button__radius--2"
                @click="fnNotAddIngredientModifyPop()"
              >수정</button>
            </th>
            <td class="inside-td" colspan="3">
              <table class="ui-table__product mt-15" v-if="info.vFlagNotAdd === 'Y'">
                <colgroup>
                  <col style="width:14rem">
                  <col style="width:auto">
                </colgroup>
                <tbody>
                  <tr>
                    <th>구분</th>
                    <td>
                      무소구 성분
                    </td>
                  </tr>
                  <tr>
                    <td colspan="2">
                      <div class="note-table__inner">
                        <table class="ui-table__reset ui-table__search-result ui-table__border table_not_add">
                          <colgroup>
                            <col style="width:23rem">
                            <col style="width:23rem">
                            <col style="width:23rem">
                            <col style="width:auto">
                          </colgroup>
                          <thead>
                            <tr>
                              <th>공통항목</th>
                              <th>특화항목</th>
                              <th>협의항목</th>
                              <th>비고</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>
                                <ul class="ul_not_add">
                                  <template v-for="(vo, idx) in info.mtr04List" :key="'mtr04_' + idx">
                                    <li>{{ vo.vSubCodenm }}</li>
                                  </template>
                                  <template v-if="info.mtr04List && maxCodeSize > info.mtr04List.length">
                                    <li v-for="(vo) in (maxCodeSize - info.mtr04List.length)" :key="'mtr04temp_' + vo"></li>
                                  </template>
                                </ul>
                              </td>
                              <td>
                                <ul class="ul_not_add">
                                  <template v-for="(vo, idx) in info.mtr05List" :key="'mtr05_' + idx">
                                    <li>{{ vo.vSubCodenm }}</li>
                                  </template>
                                  <template v-if="info.mtr05List && maxCodeSize > info.mtr05List.length">
                                    <li v-for="(vo) in (maxCodeSize - info.mtr05List.length)" :key="'mtr05temp_' + vo"></li>
                                  </template>
                                </ul>
                              </td>
                              <td>
                                <ul class="ul_not_add">
                                  <template v-for="(vo, idx) in info.mtr06List" :key="'mtr06_' + idx">
                                    <li>{{ vo.vSubCodenm }}</li>
                                  </template>
                                  <template v-if="info.mtr06List && maxCodeSize > info.mtr06List.length">
                                    <li v-for="(vo) in (maxCodeSize - info.mtr06List.length)" :key="'mtr06temp_' + vo"></li>
                                  </template>
                                </ul>
                              </td>
                              <td v-html="commonUtils.removeHTMLChangeBr(info.vNotAddNote)"></td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @callbackFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, ref, inject, watch } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useStore } from 'vuex'

export default {
  name: 'AllLabNoteHbdMarketingInfoView',
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    NotAddIngredientModifyPop: defineAsyncComponent(() => import('@/components/labcommon/popup/NotAddIngredientModifyPop.vue')),
  },
  setup () {
    const reqInfo = inject('reqInfo')
    const commonUtils = inject('commonUtils')
    const mtr04List = ref([])
    const mtr05List = ref([])
    const mtr06List = ref([])
    const maxCodeSize = ref()
    const store = useStore()
    const myInfo = store.getters.getMyInfo()

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
    } = useLabCommon()

    const info = ref({
      nPrice: '',
      nProductCapacity: '',
      vProductCapacityCd: '',
      nTargetCost: '',
      nCapacity: 100,
      vCapacityCd: 'LNC03_01',
      reqEtcList: [],
      effectList: [],
      nEffTestDcnt: '',
      vEffTestDcntUnit: '',
      vEffTestSogooMemo: '',
      vEffCompTypeCd: '',
      vEffTestItemDt: '',
      mti01List: [],
      vTestItemDt: '',
      vOnePoint: '',
      tuserList: [],
      vTargetCustomer: '',
      vDevelopPurpose: '',
      vNote: '',
      mtr04List: [],
      mtr05List: [],
      mtr06List: [],
    })

    const showNotAddIngredientModifyBtn = () => {
      let isVisible = false
      
      if (myInfo.loginId === info.value.vSlUserid || commonUtils.checkAuth('S000000')) {
        isVisible = true
      }

      return isVisible
    }

    const fnNotAddIngredientModifyPop = () => {
      popParams.value = {
        vLabNoteCd: reqInfo.value.vLabNoteCd
      }

      fnOpenPopup('NotAddIngredientModifyPop')
    }

    const init = () => {
      if (reqInfo.value) {
        mtr04List.value = [ ...reqInfo.value.mtr04List.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)) ]
        mtr05List.value = [ ...reqInfo.value.mtr05List.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)) ]
        mtr06List.value = [ ...reqInfo.value.mtr06List.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)) ]
  
        const arrCodeSize = [
                      mtr04List.value.length, 
                      mtr05List.value.length, 
                      mtr06List.value.length
                    ]
  
        maxCodeSize.value = Math.max.apply(null, arrCodeSize)
        info.value = { ...info.value, ...{
          vFlagNotAdd: reqInfo.value.vFlagNotAdd,
          mtr04List: mtr04List.value,
          mtr05List: mtr05List.value,
          mtr06List: mtr06List.value,
        } }
      }
    }

    init()

    watch(() => reqInfo.value, (newValue) => {
      if (newValue) {
        info.value = { ...info.value, ...newValue }
  
        info.value.reqEtcList = [ ...info.value.reqEtcList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)) ]
        info.value.effectList = [ ...info.value.effectList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)) ]
        info.value.mti01List = [ ...info.value.mti01List.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)) ]
        info.value.tuserList = [ ...info.value.tuserList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)) ]

        init()
      }
    })

    return {
      commonUtils,
      info,
      maxCodeSize,
      popupContent,
      popParams,
      popSelectFunc,
      showNotAddIngredientModifyBtn,
      fnNotAddIngredientModifyPop,
    }
  }
}
</script>
