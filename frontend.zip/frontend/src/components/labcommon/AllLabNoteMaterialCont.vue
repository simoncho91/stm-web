<template>
  <div v-if="info.contList && (info.contList.length > 1 || aerosol.show)" class="code-spray__wrap">
    <ul class="ui-list code-spray__list">
      <li v-for="(cont, index) in info.contList" :key="index" class="code-spray__item"
        :style="cont.vAerosol ? '' : 'width: 7.8rem'">
        <button class="code-spray__button code-spray__button--code"
          :class="cont.vContPkCd === info.contVO.vContPkCd ? 'is-click' : ''" @click="onContMove(cont)">
          <span class="code-spray__button__num" style="width: 100%;">{{ cont.vContCd?.replace('(AEROSOL)', '') }}</span>
          <span class="code-spray__button__approx">{{ cont.vTctnBynmNm?.substring(0, 6) }}</span>
        </button>
        <button v-if="cont.vAerosol" class="code-spray__button code-spray__button--spray"
          :class="cont.vAerosol.vContPkCd === info.contVO.vContPkCd ? 'is-click' : ''"
          @click="onContMove(cont.vAerosol)"></button>
      </li>
    </ul>
  </div>
</template>

<script>
import { ref, inject, watch, reactive } from 'vue'

export default {
  name: 'AllLabNoteMaterialCont',
  components: {
  },
  emits: ['onContClick'],
  setup(props, context) {
    const reqInfo = inject('reqInfo')

    const info = ref({
      contVO: {},
      contList: [],
      verVO: {},
    })

    const aerosol = reactive({
      show: false,
    })

    watch(
      () => reqInfo.value,
      (o) => {
        info.value = { ...info.value, ...o }

        const newContList = info.value.contList.filter(cont => cont.vContCd && cont.vCodeType !== 'AEROSOL')
        if (info.value.contList.filter(cont => cont.vCodeType === 'AEROSOL').length > 0) {
          newContList.map(nCont => {
            info.value.contList.filter(cont => cont.vCodeType === 'AEROSOL').map(cont => {
              if (nCont.vContCd === cont.vContCd.replace('(AEROSOL)', '')) {
                nCont.vAerosol = cont
                aerosol.show = true
              }
            })
          })
        }

        info.value.contList = newContList
      }
    )

    const onContMove = (o) => {
      context.emit('onContClick', info.value.verVO.nVersion, o.vContPkCd)
    }

    return {
      info,
      aerosol,
      onContMove,
    }
  },
}
</script>
