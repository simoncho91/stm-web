<template>

  <div class="ml-5"><!-- 반제품X, 개발취소X -->
    <ap-selectbox 
      v-model:value="selectParam.vMrqTypeCd" 
      :options="codeGroupMaps['LAB_NOTE_TEST_CD']"
      :input-class="['ui-select__width--200']"
      >
    </ap-selectbox>
    <button type="button" class="ui-button ui-button__border--blue ml-5" @click="fnSelectTestReq">
      시험의뢰
    </button>
  </div>
  
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component :is="popupContent" :pop-params="popParams" @selectFunc="popSelectFunc" />
    </ap-popup>
  </teleport>

</template>

<script>
import { defineAsyncComponent, inject } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useCode } from '@/compositions/useCode'
import { useActions } from 'vuex-composition-helpers'
import mixmatUtils from '@/utils/mixmatUtils'

export default {
  name: 'AllLabNoteTestReq',
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    AllTestReqFuncPop: defineAsyncComponent(() => import('@/components/labcommon/popup/AllTestReqFuncPop.vue')),
    AllTestReqEffiPop: defineAsyncComponent(() => import('@/components/labcommon/popup/AllTestReqEffiPop.vue')),
    AllTestReqMusoPop: defineAsyncComponent(() => import('@/components/labcommon/popup/AllTestReqMusoPop.vue')),
    AllTestReqFlavorPop: defineAsyncComponent(() => import('@/components/labcommon/popup/AllTestReqFlavorPop.vue')),
    AllTestReqSafetyPop: defineAsyncComponent(() => import('@/components/labcommon/popup/AllTestReqSafetyPop.vue')),
    AllTestReqHarmSubPop: defineAsyncComponent(() => import('@/components/labcommon/popup/AllTestReqHarmSubPop.vue')),
    AllTestReqChinaSafetyReviewPop: defineAsyncComponent(() => import('@/components/labcommon/popup/AllTestReqChinaSafetyReviewPop.vue')),
    AllTestReqPreservativePop: defineAsyncComponent(() => import('@/components/labcommon/popup/AllTestReqPreservativePop.vue')),
  },
  props: {
    noteInfo: {
      type: Object,
      default: () => {
        return {}
      }
    },
    lotList: {
      type: Array,
      default: () => {
        return []
      }
    },
    nVersion: {
      type: Number,
      default: 0
    },
    vGateCd: {
      type: String
    },
    page: {
      type: String,
      default: ''
    }
  },
  setup(props) {
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert } = useActions(['openAsyncAlert'])

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
    } = useLabCommon()

    const selectParam = {
      vLabNoteCd: ''
      , vContPkCd: ''
      , nVersion: ''
      , vLotCd: ''
      , vPlantCd: ''
      , vMrqTypeCd: ''
    }

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const fnSelectTestReq = () => {
      if (props.page && props.page === 'material') {
        mixmatUtils.clearFocusCell()
        mixmatUtils.clearMultipleSelectCell()
      }

      // LAB_NOTE_TEST_CD
      // MRQ060	      시험의뢰(부향)
      // MRQ010	      시험의뢰(안전성)
      // MRQ011	      시험의뢰(방부)
      // MRQ040_FUNC	시험의뢰(기능성)
      // MRQ040_HARM	시험의뢰(유해물질)
      // CLINICAL	    시험의뢰(효능임상)
      // MRQ050	      시험의뢰(무소구)
      // MRQ070	      시험의뢰(중국 안전성 사전검토)

      if ("" === selectParam.vMrqTypeCd) {
        openAsyncAlert({ message: '시험의뢰를 선택해 주세요.' })
        return
      }

      if (commonUtils.isEmpty(props.nVersion)) {
        openAsyncAlert({ message: '버전을 선택해 주세요.' })
        return
      }

      popParams.value = {
        vLabNoteCd: props.noteInfo.vLabNoteCd
        , vContPkCd: props.noteInfo.vContPkCd
        , nVersion: props.nVersion
        , vPlantCd: props.noteInfo.vPlantCd || ''
        , vMrqTypeCd: selectParam.vMrqTypeCd
        , vGateCd: props.vGateCd
      }

      if (props.lotList && props.lotList.length > 0) {
        const lotInfo = props.lotList.filter(o => o.vIsLotSelect)
        if (lotInfo && lotInfo.length > 0) {
          popParams.value.vLotCd = lotInfo?.[0].vLotCd
        }
      }

      if ("MRQ060" === selectParam.vMrqTypeCd) {
        //시험의뢰(부향)
        fnOpenPopup('AllTestReqFlavorPop', false)
        
      } else if ("MRQ010" === selectParam.vMrqTypeCd) {
        //시험의뢰(안전성)
        fnOpenPopup('AllTestReqSafetyPop', true)
        
      } else if ("MRQ011" === selectParam.vMrqTypeCd) {
        //시험의뢰(방부)
        fnOpenPopup('AllTestReqPreservativePop', true)
        
      } else if ("MRQ040_FUNC" === selectParam.vMrqTypeCd) {
        //시험의뢰(기능성)
        fnOpenPopup('AllTestReqFuncPop', false)

      } else if ("MRQ040_HARM" === selectParam.vMrqTypeCd) {
        //시험의뢰(유해물질)
        fnOpenPopup('AllTestReqHarmSubPop', false)
        
      } else if ("CLINICAL" === selectParam.vMrqTypeCd) {
        //시험의뢰(효능임상)
        fnOpenPopup('AllTestReqEffiPop', false)
        
      } else if ("MRQ050" === selectParam.vMrqTypeCd) {
        //시험의뢰(무소구)
        fnOpenPopup('AllTestReqMusoPop', false)
        
      } else if ("MRQ070" === selectParam.vMrqTypeCd) {
        //시험의뢰(중국 안전성 사전검토)
        fnOpenPopup('AllTestReqChinaSafetyReviewPop', false)

      } else {
        openAsyncAlert({ message: '시험의뢰를 선택해 주세요.' })
      }

    }

    const init = async () => {
      await findCodeList(['LAB_NOTE_TEST_CD'])
    }

    init()

    return {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      codeGroupMaps,
      selectParam,
      fnSelectTestReq,
    }
  },
}
</script>
