<template>
  <div class="modal-content" style="width: 100rem;">
    <div class="modal-header">
      <div class="modal-title">주성분 원료</div>
      <button type="button" class="modal-close" @click="fnClose()"></button>
    </div>

    <div class="modal-body">
      <div class="board-top">
        <section class="search-bar p-0">
          <h2 class="for-a11y">검색</h2>
          <div class="search-bar__left">
            <div class="search-bar__row">
              <dl class="search-bar__item search-bar__item--width-100">
                <dt class="search-bar__key">검색</dt>
                <dd class="search-bar__val search-bar__val--flex">
                  <div class="search-form">
                    <div class="search-form__inner">
                      <ap-input
                        v-model:value="searchParams.vKeyword"
                        placeholder="원료코드 or 원료명"
                        @keypress-enter="fnSearch(1)"
                      >
                      </ap-input>
                      <button type="button" class="button-search" @click="fnSearch(1)">검색</button>
                    </div>
                  </div>
                </dd>
              </dl>
            </div>
          </div>
        </section>
      </div>

      <div class="ui-table__wrap">
        <table class="ui-table text-center ui-table__td--40">
          <colgroup>
            <col style="width:5rem;">
            <col style="width:10rem;">
            <col style="width:20rem;">
            <col style="width:auto;">
            <col style="width:10rem;">
          </colgroup>
          <thead>
            <tr>
              <th class="chk-header">
                <ap-input-check
                  id="eval_mate_chkAll"
                  value="Y"
                  @click="fnEvalMateChkAllEvent"
                >
                </ap-input-check>
              </th>
              <th>원료코드</th>
              <th>SAP명</th>
              <th>한글허가명</th>
              <th>주성분 종류</th>
            </tr>
          </thead>
          <tbody>
            <template v-if="list && list.length > 0">
              <tr v-for="vo in list" :key="'eval_mate_' + vo.vMaterialCd + vo.vFunctionCd">
                <td>
                  <ap-input-check
                    v-model:model="vo.isChecked"
                    value="Y"
                    :id="'eval_mate_' + vo.vMaterialCd + vo.vFunctionCd"
                    @click="fnEvalMateEvent"
                  >
                  </ap-input-check>
                </td>
                <td>{{ vo.vMaterialCd }}</td>
                <td class="t-left">{{ vo.vMaterialNm }}</td>
                <td class="t-left">{{ vo.vMaterialNmK }}</td>
                <td>{{ vo.vFunctionNm }}</td>
              </tr>
            </template>
          </tbody>
        </table>
      </div>
      <div class="board-bottom board-bottom__with--button">
        <div class="board-bottom__inner">
          <Pagination
            :page-info="page"
            @click="fnSearch"
          >
          </Pagination>
          <div class="ui-buttons ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--skyblue font-weight__300" @click="fnApply()">선택적용</button>
            <button type="button" class="ui-button ui-button__bg--lightgray" @click="fnClose()">닫기</button>
          </div>
        </div>
      </div>
    </div>

  </div>

</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useCode } from '@/compositions/useCode'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'EvaluationMaterialSearchPop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  components: {
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
  },
  emits: ['selectFunc', 'closeFunc'],
  setup (props, context) {
    const page = ref({})
    const list = ref([])
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])

    const searchParams = ref({
      vKeyword: props.popParams.vKeyword,
      vSearchFunc: '',
      nowPageNo: 1
    })

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const {
      selectEvaluationMaterialList
    } = useLabCommon()

    const fnSearch = async (pg) => {
      if (!pg) {
        pg = 1
      }

      searchParams.value.nowPageNo = pg

      const result = await selectEvaluationMaterialList(searchParams.value)

      if (result) {
        page.value = result.page
        list.value = result.list
      } else {
        page.value = {}
        list.value = []
      }

      fnEvalMateEvent()
    }

    const fnApply = () => {
      const resultList = list.value
      if (resultList.length > 0 && resultList.filter(vo => vo.isChecked === 'Y').length === 0) {
        openAsyncAlert({ message: '적용 대상을 선택해 주세요.'})
        return
      }

      context.emit('selectFunc', resultList.filter(vo => vo.isChecked === 'Y'))
    }

    const fnClose = () => {
      context.emit('closeFunc')
    }

    const fnEvalMateChkAllEvent = (value) => {
      if (value === 'Y') {
        list.value.forEach(item => {
          item.isChecked = 'Y'
          document.querySelector('#eval_mate_' + item.vMaterialCd + item.vFunctionCd).checked = true
        })
      } else {
        list.value.forEach(item => {
          item.isChecked = ''
          document.querySelector('#eval_mate_' + item.vMaterialCd + item.vFunctionCd).checked = false
        })
      }
    }

    const fnEvalMateEvent = () => {
      if (list.value.filter(item => item.isChecked === 'Y').length === list.value.length) {
        document.querySelector('#eval_mate_chkAll').checked = true
      } else {
        document.querySelector('#eval_mate_chkAll').checked = false
      }
    }

    const init = () => {
      findCodeList(['EV_MATERIAL_FUNC2'])
      fnSearch(1)
    }

    init()

    return {
      page,
      list,
      searchParams,
      closeAsyncPopup,
      codeGroupMaps,
      fnSearch,
      fnApply,
      fnEvalMateChkAllEvent,
      fnEvalMateEvent,
      fnClose,
    }
  }
}
</script>