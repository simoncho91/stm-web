<template>
  <div class="modal-content modal-content__width--78">
    <div class="modal-header">
      <div class="modal-title">글로벌 {{ searchParams.vSearchType === 'BAN' ? '금지' : '제한' }}</div>
      <button type="button" class="modal-close" @click="onClose"></button>
    </div>
    <div class="modal-body">

      <div class="modal-body__item">
        <div class="modal-sub-title">[{{ searchParams.vConcd }}] {{ searchParams.vConnm }}</div>
        <table class="ui-table__reset ui-table__ver">
          <colgroup>
            <col style="width:14rem">
            <col style="width:auto">
          </colgroup>
          <tbody>
            <template v-if="searchParams.vLand1 === 'UN'">
              <tr style="height: 4rem">
                <th>글로벌 {{ searchParams.vSearchType === 'BAN' ? '금지' : '제한' }}</th>
                <th>글로벌 {{ searchParams.vSearchType === 'BAN' ? '금지' : '제한' }} 내용</th>
              </tr>
              <tr v-for="(vo, index) in list" :key="index">
                <td>{{ vo.vGlbTxt }}</td>
                <td class="text-des"><span v-html="commonUtils.removeHTMLChangeBr(vo.vGlbDescTxt)"></span></td>
              </tr>
            </template>
            <template v-else>
              <tr style="height: 4rem">
                <th>글로벌 {{ searchParams.vSearchType === 'BAN' ? '금지' : '제한' }}</th>
                <td class="tit">{{ searchParams.vSearchType === 'BAN' ? gvo.vZglobal : gvo.vZgllim }}</td>
              </tr>
              <tr>
                <th>글로벌 {{ searchParams.vSearchType === 'BAN' ? '금지' : '제한' }} 내용</th>
                <td class="text-des"><span
                    v-html="commonUtils.removeHTMLChangeBr(searchParams.vSearchType === 'BAN' ? gvo.vZglbtxt : gvo.vZgllimTxt)"></span>
                </td>
              </tr>
            </template>
          </tbody>
        </table>

        <div class="board-bottom board-bottom__with--button">
          <div class="board-bottom__inner">
            <div class="ui-buttons ui-buttons__right">
              <button type="button" class="ui-button ui-button__bg--lightgray"
                @click="onClose({ message: '닫기' })">닫기</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { reactive, ref, inject } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'

export default {
  name: 'MateGlobalViewPop',
  components: {
  },
  emits: ['selectFunc'],
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: '',
          vSearchType: '',
          vConcd: '',
          vConnm: '',
          vLand1: '',
          vGcode: '',
        }
      }
    }
  },
  emits: ['closeFunc'],
  setup(props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const list = ref(null)
    const gvo = reactive({
      vZglobal: '',
      vZglbtxt: '',
      vZgllim: '',
      vZgllimTxt: '',
    })
    const searchParams = reactive({
      vLabNoteCd: props.popParams.vLabNoteCd,
      vSearchType: props.popParams.vSearchType,
      vConcd: props.popParams.vConcd,
      vConnm: props.popParams.vConnm,
      vLand1: props.popParams.vLand1,
      vGcode: props.popParams.vGcode,
    })

    const {
      selectZplmt12List,
    } = useLabCommon()

    const init = async () => {
      const result = await selectZplmt12List(searchParams)
      list.value = result.list || []
      gvo.vZglobal = result.vo?.vZglobal || ''
      gvo.vZglbtxt = result.vo?.vZglbtxt || ''
      gvo.vZgllim = result.vo?.vZgllim || ''
      gvo.vZgllimTxt = result.vo?.vZgllimTxt || ''
    }

    const onClose = () => {
      context.emit('closeFunc')
    }

    init()

    return {
      t,
      commonUtils,
      list,
      gvo,
      searchParams,
      onClose,
    }
  }
}
</script>