<template>
  <div class="modal-content" style="width: 80rem;">
    <div class="modal-header">
      <div class="modal-title">카운터 검색</div>
      <button type="button" class="modal-close" @click="fnClose()"></button>
    </div>
    <div class="modal-body">
      <section class="search-bar p-0 mt-15">
        <h2 class="for-a11y">검색</h2>
        <div class="search-bar__left">
          <div class="search-bar__row">
            <dl class="search-bar__item search-bar__item--width-100">
              <dt class="search-bar__key">검색</dt>
              <dd class="search-bar__val search-bar__val--flex">
                <div class="search-form">
                  <div class="search-form__inner">
                    <ap-input
                      v-model:value="params.vKeyword"
                      :placeholder="popParams.vFlagNp === 'Y' ? '내용물코드 or 내용물명' : '과제명 or 담당자'"
                      @keypress-enter="fnSearch(1)"
                    >
                    </ap-input>
                    <button type="button" class="button-search" @click="fnSearch(1)">검색</button>
                  </div>
                </div>
              </dd>
            </dl>
          </div>
        </div>
      </section>

      <div class="myboard-table mt-15">
        <div class="myboard-table__inner">
          <table class="ui-table ui-table__th--border-radius--0 ui-table__td--40 text-center">
            <colgroup>
              <col style="width: 15rem">
              <col style="width: 10rem">
              <col style="width: auto">
              <col style="width: 10rem">
            </colgroup>
            <template v-if="popParams.vFlagNp === 'Y'">
              <thead>
                <tr>
                  <th>내용물코드</th>
                  <th>플랜트</th>
                  <th>내용물명</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <template v-if="list && list.length > 0">
                  <tr v-for="vo in list" :key="'counter_' + vo.vContPkCd">
                    <td>{{ vo.vContCd }}</td>
                    <td>{{ vo.vPlantCd}}</td>
                    <td class="t-left">
                      <a href="#" class="tit-link" @click="fnCounterDetail(vo)">{{ vo.vContNm }}</a>
                    </td>
                    <td>
                      <button type="button"
                        :class="['ui-button',
                                'ui-button__width--40',
                                'ui-button__height--23', 
                                'ui-button__border--blue', 
                                'ui-button__radius--2']"
                        @click="fnCounterSelect(vo)"
                      >선택</button>
                    </td>
                  </tr>
                </template>
                <template v-else>
                  <tr>
                    <td colspan="4">
                      <div class="no-result">
                        {{ t('common.msg.no_data') }}
                      </div>
                    </td>
                  </tr>
                </template>
              </tbody>
            </template>
            <template v-else-if="popParams.vFlagNp === 'N'">
              <thead>
                <tr>
                  <th>실험구분</th>
                  <th>과제명</th>
                  <th>상태</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <template v-if="list && list.length > 0">
                  <tr v-for="vo in list" :key="'counter_' + vo.vContPkCd">
                    <td>{{ vo.vLabTypeNm }}</td>
                    <td class="t-left">
                      <a href="#" class="tit-link" @click="fnCounterDetail(vo)">{{ vo.vContNm }}</a>
                    </td>
                    <td>{{ vo.vStatusNm }}</td>
                    <td>
                      <button type="button"
                        :class="['ui-button',
                                'ui-button__width--40',
                                'ui-button__height--23', 
                                'ui-button__border--blue', 
                                'ui-button__radius--2']"
                        @click="fnCounterSelect(vo)"
                      >선택</button>
                    </td>
                  </tr>
                </template>
                <template v-else>
                  <tr>
                    <td colspan="4">
                      <div class="no-result">
                        {{ t('common.msg.no_data') }}
                      </div>
                    </td>
                  </tr>
                </template>
              </tbody>
            </template>
          </table>
        </div>
      </div>

      <div class="board-bottom board-bottom__with--button">
        <div class="board-bottom__inner">
          <Pagination
            :page-info="page"
            @click="fnSearch"
          >
          </Pagination>
          <div class="ui-buttons ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--lightgray" @click="fnClose()">닫기</button>
          </div>
        </div>
      </div>
    </div>
  </div>
  <teleport to="#common-modal-sub1" v-if="popContent">
    <ap-popup>
      <component
        :is="popContent"
        :pop-params="popupParams"
        @closeFunc="closeFunc"
      />
    </ap-popup>
  </teleport>
  <div id="common-modal-sub1"></div>
</template>

<script>
import { ref, inject, defineAsyncComponent } from 'vue'
import { useSkincareCommon } from '@/compositions/skincare/useSkincareCommon'
import { useMakeupCommon } from '@/compositions/makeup/useMakeupCommon'
import { useHbdCommon } from '@/compositions/hbd/useHbdCommon'
import { useQdrugCommon } from '@/compositions/qdrug/useQdrugCommon'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useStore } from 'vuex'

export default {
  name: 'CompleteCounterSearchPop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  components: {
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    ContDetailPop: defineAsyncComponent(() => import('@/components/search/popup/ContDetailPop.vue')),
  },
  emits: ['selectFunc', 'closeFunc'],
  setup (props, context) {
    const t = inject('t')
    const store = useStore()
    const noteType = store.getters.getNoteType()
    const params = ref({
      vKeyword: '',
      nowPageNo: 1,
      vFlagNp: props.popParams.vFlagNp,
      vCodeType: props.popParams.vCodeType,
    })

    const page = ref({})
    const list = ref([])

    const popContent = ref(null)
    const popupParams = ref(null)
    const closeFunc = ref(null)

    const {
      selectCompleteCounterList,
    } = useLabCommon()

    const fnCounterSelect = (item) => {
      context.emit('selectFunc', item)
    }

    const closeCounterDetailPop = () => {
      popContent.value = null
    }

    const fnCounterDetail = (item) => {
      popupParams.value = {
        ...item,
        popSub: 'Y'
      }

      closeFunc.value = closeCounterDetailPop
      popContent.value = 'ContDetailPop'
    }

    const fnClose = () => {
      context.emit('closeFunc')
    }

    const fnSearch = async (pg) => {
      if (!pg) {
        pg = 1
      }

      params.value.nowPageNo = pg

      let result = null
      result = await selectCompleteCounterList(params.value)

      if (result) {
        page.value = result.page
        list.value = result.list
      } else {
        page.value = {}
        list.value = []
      }
    }

    const init = () => {
      fnSearch(1)
    }

    init()

    return {
      t,
      page,
      list,
      params,
      popContent,
      closeFunc,
      popupParams,
      fnSearch,
      fnCounterSelect,
      fnCounterDetail,
      fnClose,
    }
  }
}
</script>