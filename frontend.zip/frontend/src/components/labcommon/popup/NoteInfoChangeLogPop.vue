<template>
  <div class="modal-content" style="width: 95rem;">
    <div class="modal-header">
      <div class="modal-title">변경 이력</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({message: ''})"></button>
    </div>
    <div class="modal-body">
      <div class="basic-info__table">
        <table class="ui-table__contents">
          <colgroup>
            <col style="width:7.2rem">
            <col style="width:auto">
          </colgroup>
          <tbody>
            <tr>
              <th>변경필드</th>
              <td class="t-left chg-search-field">
                <ap-choosebox
                  v-if="codeGroupMaps['LNC27']"
                  v-model:modelChkAll="searchParams.vChgLogTypeAll"
                  v-model:model="searchParams.arrChgLogTypeCd"
                  id="chg_log_type"
                  :options="codeGroupMaps['LNC27']"
                >
                </ap-choosebox>
              </td>
            </tr>
            <tr>
              <th>변경자</th>
              <td class="t-left">
                <div class="search-form p-relative">
                  <ap-input
                    v-model:value="searchParams.vUsernm"
                    input-class="ui-input ui-input__width--340"
                    @keypressEnter="fnUserSearchPop()"
                  >
                  </ap-input>
                  <button type="button"
                    class="ui-button__circle ui-button__close input-close-btn--310"
                    @click="resetUserInfo()"
                  ></button>
                  <button type="button" class="ml-5 ui-button ui-button__border--blue" @click="fnUserSearchPop()">찾기</button>
                </div>
              </td>
            </tr>
            <tr>
              <th>변경기간</th>
              <td>
                <div class="search-form form-flex">
                  <ap-date-picker-range
                    v-model:startDt="searchParams.vStartDt"
                    v-model:endDt="searchParams.vEndDt"
                  >
                  </ap-date-picker-range>
                  <button type="button" class="button-search" @click="fnSearch(1)">검색</button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="myboard-table mt-15">
        <div class="myboard-table__inner">
          <table class="ui-table ui-table__th--border-radius--0 ui-table__td--40 text-center">
            <colgroup>
              <col style="width:5%">
              <col style="width:25%">
              <col style="width:35%">
              <col style="width:35%">
            </colgroup>
            <thead>
              <tr>
                <th>NO</th>
                <th>변경필드</th>
                <th>변경 전</th>
                <th>변경 후</th>
              </tr>
            </thead>
            <tbody>
              <template v-if="list && list.length > 0">
                <tr v-for="(vo, idx) in list" :key="'history_' + idx">
                  <td>{{ page.totalCnt - ((page.pageSize * (page.nowPageNo-1)) + idx) }}</td>
                  <td>
                    <template v-if="codeGroupMaps['LNC27']">
                      {{ codeGroupMaps['LNC27'].filter(item => item.vSubCode === vo.vChgFieldCd )[0]
                         ? codeGroupMaps['LNC27'].filter(item => item.vSubCode === vo.vChgFieldCd )[0].vSubCodenm 
                         : '' }}<br><br>
                    </template>
                    <p style="font-weight: 400;">{{ vo.vUsernm }} {{ commonUtils.changeStrDatePattern(vo.vRegDtm, '.', 'Y')}}</p>
                  </td>
                  <td class="t-left" v-html="commonUtils.removeHTMLChangeBr(vo.vChgBefore)"></td>
                  <td class="t-left" v-html="commonUtils.removeHTMLChangeBr(vo.vChgAfter)"></td>
                </tr>
              </template>
              <template v-else>
                <tr>
                  <td colspan="4">
                    <div class="no-result">
                      {{ t('common.msg.no_data') }}
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>

        <div class="board-bottom board-bottom__with--button">
          <div class="board-bottom__inner">
            <Pagination
              v-if="list && list.length > 0"
              :page-info="page"
              @click="fnSearch"
            >
            </Pagination>
            <div class="ui-buttons ui-buttons__right">
              <button type="button" class="ui-button ui-button__bg--lightgray" @click="closeAsyncPopup({ message: '닫기'})">닫기</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <teleport to="#common-modal-sub" v-if="popContent">
      <ap-popup>
        <component
          :is="popContent"
          :pop-params="popupParams"
          @selectFunc="popSelectFunc"
          @closeFunc="closeFunc"
        />
      </ap-popup>
    </teleport>
  </div>
  <div id="common-modal-sub"></div>
</template>

<script>
import { defineAsyncComponent, ref, reactive, inject } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useRequestCommon } from '@/compositions/labcommon/useRequestCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'NoteInfoChangeLogPop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  components: {
    UserSearchPop: defineAsyncComponent(() => import('@/components/comm/popup/UserSearchPop.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue'))
  },
  setup (props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])
    const popContent = ref(null)
    const popSelectFunc = ref(null)
    const closeFunc = ref(null)
    const popupParams = ref({})
    const list = ref([])
    const page = ref({})

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const {
      selectLabNoteChgLogList,
    } = useRequestCommon()

    const searchParams = reactive({
      vChgLogTypeAll: '',
      arrChgLogTypeCd: [],
      vUserid: '',
      vUsernm: '',
      vStartDt: '',
      vEndDt: '',
      nowPageNo: 1,
      vLabNoteCd: props.popParams.vLabNoteCd
    })

    const fnUserSearchPop = () => {
      popupParams.value = {
        vKeyword: searchParams.vUsernm,
        popType: 'SUB',
        searchFlag: 'ALL'
      }

      popSelectFunc.value = getUserSearchInfo
      closeFunc.value = closeUserSearchPop

      popContent.value = 'UserSearchPop'
    }

    const getUserSearchInfo = (item) => {
      searchParams.vUserid = item.vUserid
      searchParams.vUsernm = item.vUsernm
    }

    const closeUserSearchPop = () => {
      popContent.value = null
    }

    const resetUserInfo = () => {
      searchParams.vUserid = ''
      searchParams.vUsernm = ''
    }

    const fnSearch = async (pg = 1) => {
      searchParams.nowPageNo = pg
      const result = await selectLabNoteChgLogList(searchParams)

      if (result) {
        list.value = result.list
        page.value = result.page
      }
    } 

    const init = () => {
      findCodeList(['LAB_CHANGE_LOG', 'LNC27'])
      fnSearch(1)
    }

    init()

    return {
      t,
      popContent,
      popSelectFunc,
      closeFunc,
      popupParams,
      searchParams,
      commonUtils,
      list,
      page,
      codeGroupMaps,
      closeAsyncPopup,
      fnSearch,
      fnUserSearchPop,
      resetUserInfo,
      closeUserSearchPop,
    }
  }
}
</script>

<style scoped>
  .modal-content { overflow: visible !important; }
</style>