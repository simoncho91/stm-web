<template>
  <div class="modal-content" style="width: 120rem;">
    <div class="modal-header">
      <div class="modal-title">Product 변경 이력 정보</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({message: ''})"></button>
    </div>
    <div class="modal-body t-left">
      <div class="version-tab__top mt-30 ap_contents_tab">
        <ApTab
          mst-id="ver_history_tab"
          :tab-list="verList"
          tab-nm-key="vVersionTxt"
          tab-id-key="vVersionKey"
          :default-tab="selectedTab"
          :tab-style="['version-tab__top__inner', 'version-tab__top__lists version-tab__top__lists--s', 'version-tab__top__list', 'version-tab__top__link']"
          @click="fnTabClickEvent"
        >
        </ApTab>
      </div>
      <div class="contents-tab__body"
        v-for="(vo, idx) in verList"
        :key="'version_area_' + idx"
        :id="vo.vVersionKey"
      >
        <template v-if="selectedTab === vo.vVersionKey && vo.mstList && vo.mstList.length > 0">
          <div
            class="arrordion-item mt-30"
            :class="mst.isOpen ? 'is-active' : ''"
            v-for="(mst, index) in vo.mstList"
            :key="mst.vTumnTnpdChgHistNo"
          >
            <div class="arrordion-header">
              <div class="arrordion-title" v-if="index !== vo.mstList.length - 1">수정 #{{ Number(mst.nNum) - 1 }}</div>
              <div class="arrordion-title" v-else>최초등록</div>
              <button type="button" class="ui-button__accordion" @click="fnToggleAccordion(mst)"></button>
            </div>
            <div class="arrordion-body">
              <div class="basic-info__table">
                <table class="ui-table__reset ui-table__ver table-th-center">
                  <colgroup>
                    <col style="width: 17rem;">
                    <col style="width: auto">
                  </colgroup>
                  <tbody>
                    <tr>
                      <th>등록정보</th>
                      <td class="txt_gray">{{ mst.vRegUsernm }}&nbsp;&nbsp;&nbsp;{{ commonUtils.changeStrDatePattern(mst.vRegDtm, '.', 'Y') }}</td>
                    </tr>
                    <tr>
                      <th>신원료 유무</th>
                      <td class="t-left">{{ mst.vFlagNewItem === 'Y' ? '유' : '무'}}</td>
                    </tr>
                    <tr v-if="mst.vFlagNewItem === 'Y'">
                      <td class="inside-td-history" colspan="2">
                        <MateSearchResultTableView
                          input-class="ui-table__reset"
                          :mate-list="mst.newMateList"
                          stock-dt-yn="Y"
                          mate-chg-yn="Y"
                        ></MateSearchResultTableView>
                      </td>
                    </tr>
                    <tr>
                      <th>향료정보</th>
                      <td class="t-left">
                        {{ mst.vPerfumeNm }}
                        <template v-if="mst.vPerfumeCd === 'LNC11_03'">
                          ({{ mst.vFlagPerfumeNew === 'Y' ? '신향' : '기존향'}})
                        </template>
                      </td>
                    </tr>
                    <tr v-if="mst.vPerfumeCd !== 'LNC11_99' && mst.perfMateList && mst.perfMateList.length > 0">
                      <td class="inside-td-history" colspan="2">
                        <MateSearchResultTableView
                          input-class="ui-table__reset"
                          :mate-list="mst.perfMateList"
                          stock-dt-yn="Y"
                        ></MateSearchResultTableView>
                      </td>
                    </tr>
                    <tr v-if="mst.requMateList && mst.requMateList.length > 0">
                      <th>필수원료</th>
                      <td class="inside-td-history">
                        <MateSearchResultTableView
                          input-class="ui-table__reset"
                          :mate-list="mst.requMateList"
                        ></MateSearchResultTableView>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </template>
        <template v-else-if="selectedTab === vo.vVersionKey">
          <div class="no-result">등록된 내용이 없습니다.</div>
        </template>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'
import { useRequestCommon } from '@/compositions/labcommon/useRequestCommon'
import { useStore } from 'vuex'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'ProductVersionHistoryPop',
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    MateSearchResultTableView: defineAsyncComponent(() => import('@/components/labcommon/MateSearchResultTableView.vue')),
  },
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  setup (props, context) {
    const commonUtils = inject('commonUtils')
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])
    const verList = ref(props.popParams.verList)
    const selectedTab = ref('')

    const {
      selectProductVersionHistoryList,
    } = useRequestCommon()

    const fnTabClickEvent = (item) => {
      selectedTab.value = item.vVersionKey
    }

    const fnToggleAccordion = (item) => {
      item.isOpen = !item.isOpen
    }

    const init = async () => {
      const payload = {
        vLabNoteCd: props.popParams.vLabNoteCd,
        vContPkCd: props.popParams.vContPkCd,
      }

      const result = await selectProductVersionHistoryList(payload)

      if (result && verList.value && verList.value.length > 0) {
        result.mstList.forEach(mst => {
          mst.isOpen = true
          mst.newMateList = [ ...result.mateList.filter(v => v.vTumnTnpdChgHistNo === mst.vTumnTnpdChgHistNo && v.vAddTypeCd === 'LNC19_NEW')]
          mst.perfMateList = [ ...result.mateList.filter(v => v.vTumnTnpdChgHistNo === mst.vTumnTnpdChgHistNo && v.vAddTypeCd === 'LNC19_PREF')]
          mst.requMateList = [ ...result.mateList.filter(v => v.vTumnTnpdChgHistNo === mst.vTumnTnpdChgHistNo && v.vAddTypeCd === 'LNC19_REQU')]
        })

        verList.value.forEach(ver => {
          ver.vVersionKey = 'ver_his_' + ver.vVersionKey
          ver.mstList = [ ...result.mstList.filter(v => v.nVersion === ver.nVersion)]
        })

        const versionKeyInfo = verList.value.filter(v => v.nVersion === props.popParams.nVersion)[0]
        selectedTab.value = versionKeyInfo ? versionKeyInfo.vVersionKey : verList.value[0].vVersionKey
      }
    }

    init()

    return {
      commonUtils,
      verList,
      selectedTab,
      fnTabClickEvent,
      fnToggleAccordion,
      closeAsyncPopup,
    }
  }
}
</script>

<style scoped>
  .inside-td-history { padding: 0 !important; }
  .arrordion-header { margin-bottom: 0;}
</style>