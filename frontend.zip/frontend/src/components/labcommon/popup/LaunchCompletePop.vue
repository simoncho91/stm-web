<template>
  <div class="modal-content modal-content__width--922 launch-modal">
    <div class="modal-header">
      <div class="modal-title">출시 완료</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({message: ''})"></button>
    </div>

    <div class="modal-body">
      <div class="board-top mb-0">
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--120">출시완료일<span class="ui-require"><span class="for-a11y">(필수)</span></span></dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="search-form" id="error_wrap_vCompleteDt">
                <div class="search-form__inner search-form-with-btn">
                  <ap-month-picker
                    v-model:date="regParams.vCompleteDt"
                    @update:date="fnValidate('vCompleteDt')"
                  >
                  </ap-month-picker>
                  <button
                    type="button"
                    class="ui-button ui-button__width--146 ui-button__height--28 ui-button__radius--2 ui-button__bg--blue"
                    @click="fnAllCompleteSave()"
                  >
                    {{ popParams.vFlagCompleteModify === 'Y' ? '전체 출시완료일 변경' : '전체 출시완료' }}
                  </button>
                </div>
                <span class="error-msg" id="error_msg_vCompleteDt"></span>
              </div>
            </dd>
          </dl>
        </div>

        <table class="ui-table__th--bg-gray mt-15">
          <colgroup>
            <col style="width:14rem;">
            <col style="width:auto">
            <col style="width:14rem;">
            <col style="width:auto">
          </colgroup>
          <tbody>
            <tr>
              <td colspan="4" class="inside-td">
                <table class="ui-table__contents"
                  :class="idx !== 0 ? 'mt-15' : ''"
                  v-for="(vo, idx) in regParams.contList" :key="'compCont_' + idx"
                >
                  <colgroup>
                    <col style="width:10rem">
                    <col style="width:auto">
                    <col style="width:10rem">
                    <col style="width:auto">
                  </colgroup>
                  <tbody>
                    <tr>
                      <td colspan="4" class="t-left">
                        <p class="p_bold">[{{ vo.vContCd }}] [{{ vo.vPlantCd }}] {{ vo.vContNm }}</p>
                      </td>
                    </tr>
                    <template v-if="(vo.vFlagMassAppr === 'Y' || (vo.vPlantCd === 'CN20' && vo.vFlagDecide === 'Y')) && vo.vFlagCancel === 'N'">
                      <tr>
                        <th>출시완료일<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
                        <td>
                          <div :id="'error_wrap_vLaunchCompleteDt_' + idx">
                            <ap-month-picker
                              v-model:date="vo.vLaunchCompleteDt"
                              @update:date="fnValidate('vLaunchCompleteDt_' + idx)"
                            >
                            </ap-month-picker>
                            <span class="error-msg" :id="'error_msg_vLaunchCompleteDt_' + idx"></span>
                          </div>
                        </td>
                        <th>상태</th>
                        <td>
                          <template v-if="vo.vFlagCancel === 'Y'">
                            개발취소
                          </template>
                          <template v-else-if="vo.vFlagMassAppr === 'Y' && vo.vFlagNewReg === 'N'">
                            출시완료
                          </template>
                          <template v-else-if="vo.vFlagMassAppr === 'Y' && vo.vFlagNewReg === 'Y'">
                            양산승인 완료
                          </template>
                          <template v-else-if="vo.vFlagDecide === 'Y' && vo.vSiteType === 'CN' && noteType === 'CN_LAB'">
                            확정처방 완료
                          </template>
                          <template v-else>
                            양산승인 미완료
                          </template>
                        </td>
                      </tr>
                      <tr>
                        <th>카운터</th>
                        <td colspan="3">
                          <div class="search-form">
                            <div class="search-form__inner">
                              <ap-input
                              v-model:value="vo.vCounterNmTemp"
                              input-class="ui-input__width--450"
                              :readonly="true"
                              @click="fnCounterSearchPop(idx)"
                            >
                            </ap-input>
                            <button type="button" class="button-search" @click="fnCounterSearchPop(idx)">검색</button>
                            <button type="button" class="button-search" @click="removeCounterInfo(idx)">삭제</button>
                            </div>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <th>비고</th>
                        <td colspan="3">
                          <ap-input
                            v-model:value="vo.vCompleteCounterNote"
                            input-class="ui-input__width--full"
                          >
                          </ap-input>
                        </td>
                      </tr>
                    </template>
                    <template v-else>
                      <tr>
                        <th>출시완료일<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
                        <td>
                          -
                        </td>
                        <th>상태</th>
                        <td>{{ vo.vContStatusNm }}</td>
                      </tr>
                      <tr>
                        <th>비고</th>
                        <td colspan="3">
                          {{ vo.vFlagCancel === 'Y' ? 
                            '다시 개발을 원하신다면 개발재개 버튼을 클릭해 주세요.'
                            : '출시완료를 진행하기 위해 양산승인을 먼저 완료해 주세요.' }}
                        </td>
                      </tr>
                    </template>
                    <tr v-if="popParams.vFlagCompleteModify !== 'Y' && vo.vFlagNewReg !== 'N'">
                      <th>개발 취소 여부</th>
                      <td colspan="3">
                        <button
                          v-if="vo.vFlagCancel === 'Y'"
                          type="button"
                          class="ui-button ui-button__width--70 ui-button__height--23 ui-button__radius--2 ui-button__bg--blue"
                          @click="fnContDevelopFlagChange(vo, 'RESTART')"
                        >개발재개</button>
                        <button
                          v-else
                          type="button"
                          class="ui-button ui-button__width--70 ui-button__height--23 ui-button__radius--2 ui-button__bg--blue"
                          @click="fnContDevelopFlagChange(vo, 'CANCEL')"
                        >개발취소</button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="board-bottom">
        <div class="board-bottom__inner">
          <div class="ui-buttons ml-auto ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--skyblue font-weight__300" @click="fnLaunchCompleteSave()">{{ popParams.vFlagCompleteModify === 'Y' ? '출시완료일 변경' : '출시완료'}}</button>
            <button type="button" class="ui-button ui-button__bg--lightgray" @click="closeAsyncPopup({ message: '' })">닫기</button>
          </div>
        </div>
      </div>
    </div>
  </div>
  <teleport to="#common-modal-sub" v-if="popContent">
    <ap-popup>
      <component
        :is="popContent"
        :pop-params="popupParams"
        @selectFunc="popSelectFunc"
        @closeFunc="closeFunc"
      />
    </ap-popup>
  </teleport>
  <div id="common-modal-sub"></div>
</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'
import { useMakeupRequest } from '@/compositions/makeup/useMakeupRequest'
import { useHbdRequest } from '@/compositions/hbd/useHbdRequest'
import { useStore } from 'vuex'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'LaunchCompletePop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    CompleteCounterSearchPop: defineAsyncComponent(() => import('@/components/labcommon/popup/CompleteCounterSearchPop.vue')),
  },
  emits: ['callbackFunc'],
  setup (props) {
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert, openAsyncConfirm, closeAsyncPopup } = useActions(['openAsyncAlert', 'openAsyncConfirm', 'closeAsyncPopup'])
    const store = useStore()
    const noteType = store.getters.getNoteType()
    const popContent = ref(null)
    const popupParams = ref(null)
    const popSelectFunc = ref(null)
    const closeFunc = ref(null)
    let popIdx = null
    
    const {
      selectMakeupLabNoteVerLaunchCompleteContList,
      saveMakeupLaunchComplete,
      updateMakeupContFlagDevelopment,
    } = useMakeupRequest()

    const {
      selectHbdLabNoteVerLaunchCompleteContList,
      saveHbdLaunchComplete,
      updateHbdContFlagDevelopment,
    } = useHbdRequest()

    const regParams = ref({
      vLabNoteCd: props.popParams.vLabNoteCd,
      vCompleteDt: '',
      vFlagAllComplete: '',
      contList: []
    })

    const getCounterSearchInfo = (item) => {
      regParams.value.contList[popIdx].vCounterNmTemp = '[' + item.vContCd + '] ' + item.vContNm
      regParams.value.contList[popIdx].vCompleteCounterCd = item.vContPkCd

      popIdx = null
      closeCounterPop()
    }

    const closeCounterPop = () => {
      popContent.value = null
    }

    const fnCounterSearchPop = (idx) => {
      popIdx = idx

      popupParams.value = {
        vFlagNp: 'Y',
        vCodeType: props.popParams.vCodeType,
      }

      popSelectFunc.value = getCounterSearchInfo
      closeFunc.value = closeCounterPop
      popContent.value = 'CompleteCounterSearchPop'
    }

    const removeCounterInfo = (idx) => {
      regParams.value.contList[idx].vCounterNmTemp = ''
      regParams.value.contList[idx].vCompleteCounterCd = ''
    }

    const fnValidate = (key) => {
      let isOk = true
      let errorMsg = '필수 입력 사항입니다.'
      commonUtils.hideErrorMessage(key)

      if (key.indexOf('vLaunchCompleteDt_') > -1) {
        const idx = Number(key.split('_')[1])

        if (commonUtils.isEmpty(regParams.value.contList[idx].vLaunchCompleteDt)) {
          isOk = false
        }
      } else if (commonUtils.isEmpty(regParams.value[key])) {
        isOk = false
      }

      if (!isOk) {
        commonUtils.showErrorMessage(key, errorMsg)
      }

      return isOk
    }

    const fnValidateAll = (arrChkKey) => {
      let isOk = true
      commonUtils.hideErrorMessageAll(arrChkKey)

      arrChkKey.forEach(key => {
        if (!fnValidate(key)) {
          isOk = false
        }
      })

      return isOk
    }

    const fnContDevelopFlagChange = async (item, flag) => {
      const message = '[' + item.vContCd + '] '
                    + commonUtils.checkPostPosition(item.vContNm, ['을', '를'])
                    + ' 개발' + (flag === 'CANCEL' ? '취소' : '재개')
                    + '하시겠습니까?<br>'
                    + '<span class=\'txt_red\'>(내용물 개발취소 외 수정된 부분은 저장이 되지 않습니다.)</span>'

      if (!await openAsyncConfirm({ message })) {
        return
      }

      const vFlagCancel = flag === 'CANCEL' ? 'Y' : 'N'
      const payload = {
        vContCd: item.vContCd,
        vFlagCancel
      }

      let result = null

      if (noteType === 'MU') {
        result = await updateMakeupContFlagDevelopment(payload)
      } else if (noteType === 'HBO') {
        result = await updateHbdContFlagDevelopment(payload)
      }

      if (result === 'SUCC') {
        await openAsyncAlert({ message: '내용물을 개발 ' + (flag === 'CANCEL' ? '취소' : '재개') + '하였습니다.' })
        item.vFlagCancel = vFlagCancel
      }
    }

    const fnLaunchCompleteSave = async () => {
      const arrChkKey = []

      const contList = regParams.value.contList.filter(cont => cont.vFlagMassAppr === 'Y')

      if (!contList || contList.length === 0) {
        openAsyncAlert({ message: '출시완료 가능한 내용물이 없습니다.' })
         return
      }
      
      contList.forEach((item, idx) => {
        arrChkKey.push('vLaunchCompleteDt_' + idx)
      })

      if (!fnValidateAll(arrChkKey)) {
        openAsyncAlert({ message: '필수 입력 사항을 확인해 주세요.' })
        return
      }

      let message = ''
      if (props.popParams.vFlagCompleteModify === 'Y') {
        message = '위의 내용물의 출시완료일을 변경하시겠습니까?'
      } else {
        message = '위의 내용물을 출시완료 하시겠습니까?'
      }

      if (!await openAsyncConfirm({ message })) {
        return
      }

      regParams.value.vFlagAllComplete = 'N'
      let result = null

      if (noteType === 'MU') {
        result = await saveMakeupLaunchComplete(regParams.value)
      } else if (noteType === 'HBO') {
        result = await saveHbdLaunchComplete(regParams.value)
      }

      if (result) {
        await openAsyncAlert({ message: '저장 되었습니다.'})
        window.location.reload(true)
      }
    }

    const fnAllCompleteSave = async () => {
      const arrChkKey = ['vCompleteDt']
      if (!fnValidateAll(arrChkKey)) {
        openAsyncAlert({ message: '필수 입력 사항을 확인해 주세요.' })
        return
      }

      let message = ''
      if (props.popParams.vFlagCompleteModify === 'Y') {
        message = '모든 내용물의 출시완료일을 ' + regParams.value.vCompleteDt + '로 변경하시겠습니까?'
      } else {
        message = '출시완료가 가능한 모든 실험노트애 대해서 ' + regParams.value.vCompleteDt + '로 출시완료 하시겠습니까?'
      }

      if (!await openAsyncConfirm({ message })) {
        return
      }

      regParams.value.vFlagAllComplete = 'Y'
      let result = null

      if (noteType === 'MU') {
        result = await saveMakeupLaunchComplete(regParams.value)
      } else if (noteType === 'HBO') {
        result = await saveHbdLaunchComplete(regParams.value)
      }

      if (result) {
        await openAsyncAlert({ message: '저장 되었습니다.'})
        window.location.reload(true)
      }
    }

    const init = async () => {
      const payload = {
        vLabNoteCd: props.popParams.vLabNoteCd,
        vFlagCompleteModify: props.popParams.vFlagCompleteModify
      }

      let result = null

      if (noteType === 'MU') {
        result = await selectMakeupLabNoteVerLaunchCompleteContList(payload)
      } else if (noteType === 'HBO') {
        result = await selectHbdLabNoteVerLaunchCompleteContList(payload)
      }

      if (result) {
        result.forEach(item => {
          item.vFlagMassAppr = item.vPlantCd === 'CN20' && item.vFlagDecide === 'Y' ? 'Y' : item.vFlagMassAppr
        })
        regParams.value.contList = [ ...result ]
      }
    }

    init()

    return {
      regParams,
      closeAsyncPopup,
      popContent,
      popSelectFunc,
      closeFunc,
      popupParams,
      fnLaunchCompleteSave,
      fnAllCompleteSave,
      fnValidate,
      fnCounterSearchPop,
      removeCounterInfo,
      fnContDevelopFlagChange,
    }
  }
}
</script>

<style scoped>
  .launch-modal td { text-align: left; }
  .search-form-with-btn { justify-content: space-between; align-items: center;}
</style>
