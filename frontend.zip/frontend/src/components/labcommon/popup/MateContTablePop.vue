<template>
  <div class="modal-content modal-content__width--auto">
    <div class="modal-header modal-header__mb--10">
      <div class="modal-title">({{ popParams.vMatnr}}) {{ popParams.vMaktx }}</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({ message: '' })"></button>
    </div>
    <div class="modal-body">
      <table class="ui-table text-center ui-table__td--40 mt-15">
        <colgroup>
          <col style="width:15%">
          <col style="width:30%">
          <col style="width:auto">
          <col style="width:20%">
        </colgroup>
        <thead>
          <tr style="min-height: 2.1rem;">
            <th>원료코드</th>
            <th>원료명</th>
            <th>제목(허가명)</th>
            <th>함량</th>
          </tr>
        </thead>
        <tbody>
          <template v-if="list && list.length > 0">
            <tr v-for="(vo, idx) in list" :key="'ref_' + idx">
              <td>{{ vo.vMatCd }}</td>
              <td>{{ vo.vMatNm }}</td>
              <td></td>
              <td>{{ vo.nMatPer }}</td>
            </tr>
          </template>
          <template v-else>
            <tr>
              <td colspan="4" class="text-center">
                :: BOM이 존재하지 않습니다. ::
              </td>
            </tr>
          </template>
        </tbody>
      </table>

      <div class="board-bottom board-bottom__with--button">
        <div class="board-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button type="button" v-if="list && list.length > 0"
              class="ui-button ui-button__bg--skyblue font-weight__300"
              @click="fnExcel"
            >
              실함량표 export
            </button>
            <button type="button" class="ui-button ui-button__bg--lightgray"
              @click="closeAsyncPopup({ message: '닫기' })">닫기</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { reactive, ref, inject } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'

export default {
  name: 'MateContTablePop',
  components: {
  },
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  setup(props, context) {
    const t = inject('t')
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])
    const list = ref(null)

    const {
      selectSaNoteContentTablePop,
      selectSaNoteContentTableExcel
    } = useProcessCommon()

    const init = async () => {
      list.value = await selectSaNoteContentTablePop(props.popParams)
    }

    init()

    const fnExcel = async () => {
      await selectSaNoteContentTableExcel(props.popParams)
    }

    return {
      t,
      closeAsyncPopup,
      list,
      fnExcel
    }
  }
}
</script>