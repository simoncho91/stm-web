<template>
  <div class="modal-content" :class="popParams.vSelectType != 'SINGLE' ? 'modal-content__width--122' : ''">
    <div class="modal-header">
      <div class="modal-title">내용물 검색</div>
      <button
        type="button"
        class="modal-close"
        @click="fnClose"
      ></button>
    </div>

    <div class="modal-body">
      <div class="search-bar__left">
        <div class="search-bar__row">
          <dl class="search-bar__item search-bar__item--width-100">
            <dt class="search-bar__key">검색</dt>
            <dd class="search-bar__val search-bar__val--flex">
              <div class="search-form">
                <div class="search-form__inner">
                  <ap-input
                    :is-number="false"
                    v-model:value="searchParams.vKeyword"
                    :inputClass="'ui-input ui-input__width--58'"
                    :placeholder="'내용물코드 or 내용물명'"
                    @keypressEnter="fnSearchSafetyContentsList(1)"
                  ></ap-input>
                  <button
                    type="button"
                    class="button-search"
                    @click="fnSearchSafetyContentsList(1)"
                  >검색</button>
                </div>
              </div>
            </dd>
          </dl>
        </div>
      </div>

      <div class="contents-tab mt-1">
        <div class="contents-tab__inner">
          <ApTab
            mst-id="tab_example4"
            :tab-list="tabList"
            :default-tab="'exTab01'"
            :tab-style="['contents-tab__header mb-15', 'ui-list contents-tab__lists', 'contents-tab__list', 'contents-tab__link']"
            @click="fnChangeTab"
          >
          </ApTab>
          <div class="contents-tab__body">
            <div class="form-flex form-flex__start">
              <div class="form-flex__cell f-n width--72">
                <div class="search-detail-table">
                  <div class="search-detail-table__inner">
                    <table class="ui-table__modal">
                      <colgroup>
                        <col style="width:5rem" v-if="popParams.vSelectType != 'SINGLE'">
                        <col style="width:8rem">
                        <col style="width:auto;">
                        <template v-if="searchParams.vTypecd === 'NOTE'">
                          <col style="width:14rem">
                          <col style="width:7rem">
                          <col style="width:7rem">
                        </template>
                        <template v-if="searchParams.vTypecd === 'ODM'">
                          <col style="width:14rem">
                        </template>
                      </colgroup>
                      <thead>
                        <tr>
                          <th v-if="popParams.vSelectType != 'SINGLE'">선택</th>
                          <th>내용물코드</th>
                          <th>내용물명</th>
                          <template v-if="searchParams.vTypecd === 'NOTE'">
                            <th>PLANT</th>
                            <th>VER</th>
                            <th>LOT</th>
                          </template>
                          <template v-if="searchParams.vTypecd === 'ODM'">
                            <th>업체명</th>
                          </template>
                        </tr>
                      </thead>
                      <tbody>
                        <template v-if="list?.length > 0">
                          <tr v-for="(cvo, idx) in list" :key="`tr_${idx}`">
                            <td v-if="popParams.vSelectType != 'SINGLE'">
                              <ap-input-check
                                v-model:model="cvo.selectChk"
                                :value="'Y'"
                                :false-value="'N'"
                                :id="`prd_check_${idx}`"
                              >
                              </ap-input-check>
                            </td>
                            <td>{{ cvo.vContCd }}</td>
                            <td>
                              <div class="tit__inner">
                                <template v-if="popParams.vSelectType === 'SINGLE'">
                                  <a href="javascript:void(0)" class="tit-link" @click="setCounterContInfo(cvo)">
                                    {{ cvo.vContNm }}
                                  </a>
                                </template>
                                <template v-else>
                                  {{ cvo.vContNm }}
                                </template>
                              </div>
                            </td>
                            <template v-if="searchParams.vTypecd === 'NOTE'">
                              <td>[{{ cvo.vInnerPlant }}] {{ cvo.vMakerNm }}</td>
                              <td>Ver{{ cvo.nNoteVersion }}</td>
                              <td>{{ cvo.vLotNm }}</td>
                            </template>
                            <template v-if="searchParams.vTypecd === 'ODM'">
                              <td>{{ cvo.vCompanynm }}</td>
                            </template>
                          </tr>
                        </template>
                        <template v-else>
                          <template v-if="searchParams.vTypecd === 'NOTE'">
                            <tr>
                              <td :colspan="popParams.vSelectType != 'SINGLE' ? 6 : 5">
                                <div class="no-result">
                                  {{ t('common.msg.no_data') }}
                                </div>
                              </td>
                            </tr>
                          </template>
                          <template v-if="searchParams.vTypecd === 'SAP'">
                            <tr>
                              <td :colspan="popParams.vSelectType != 'SINGLE' ? 3 : 2">
                                <div class="no-result">
                                  {{ t('common.msg.no_data') }}
                                </div>
                              </td>
                            </tr>
                          </template>
                          <template v-if="searchParams.vTypecd === 'ODM'">
                            <tr>
                              <td colspan="4">
                                <div class="no-result">
                                  {{ t('common.msg.no_data') }}
                                </div>
                              </td>
                            </tr>
                          </template>
                        </template>
                      </tbody>
                    </table>
                  </div>
                </div>
  
                <div class="board-bottom board-bottom__with--button">
                  <div class="board-bottom__inner">
                    <Pagination
                      :page-info="page"
                      @click="fnSearchSafetyContentsList($event)"
                    />
                    <div class="ui-buttons ml-auto ui-buttons__right" v-if="popParams.vSelectType != 'SINGLE'">
                      <button
                        type="button"
                        class="ui-button ui-button__border--blue"
                        @click="fnSelect"
                      >선택</button>
                    </div>
                  </div>
                </div>
  
              </div>
  
              <div class="form-flex__cell" v-if="popParams.vSelectType != 'SINGLE'">
                <div class="search-detail-table">
                  <div class="search-detail-table__inner">
                    <table class="ui-table__modal">
                      <colgroup>
                        <col style="width:5rem">
                        <col style="width:8rem">
                        <col style="width:auto">
                      </colgroup>
                      <thead>
                        <tr>
                          <th>선택</th>
                          <th>내용물코드</th>
                          <th>내용물명</th>
                        </tr>
                      </thead>
                      <tbody>
                        <template v-if="selectList?.length > 0">
                          <tr v-for="(cvo, idx) in selectList" :key="`select_tr_${idx}`">
                            <td>
                              <ap-input-check
                                v-model:model="cvo.deleteChk"
                                :value="'Y'"
                                :false-value="'N'"
                                :id="`del_check_${idx}`"
                              >
                              </ap-input-check>
                            </td>
                            <td>
                              {{ cvo.vContCd }}
                              <template v-if="cvo?.vLotNm">
                                <br/>{{ cvo.vLotNm }}
                              </template>
                            </td>
                            <td>
                              <div class="tit__inner">
                                {{ cvo.vContNm }}
                              </div>
                            </td>
                          </tr>
                        </template>
                        <template v-else>
                          <tr>
                            <td colspan="3">
                              <div class="no-result">
                                {{ t('common.msg.no_data') }}
                              </div>
                            </td>
                          </tr>
                        </template>
                      </tbody>
                    </table>
                  </div>
                </div>
                <div class="ui-buttons ui-buttons__right mt-2">
                  <button
                    type="button"
                    class="ui-button ui-button__bg--lightgray"
                    @click="fnDelete"
                  >선택삭제</button>
                  <button
                    type="button"
                    class="ui-button ui-button__bg--skyblue font-weight__300"
                    @click="fnApply"
                  >적용</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'

export default {
  name: 'ParentProductSearchPop',
  components: {
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
  },
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vKeyword: ''
          , vTypecd: 'NOTE'
          , productList: []
          , vSelectType : ''
          , vFlagCounterPop : ''
        }
      }
    }
  },
  emits: ['selectFunc', 'closeFunc'],
  setup(props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { openAsyncConfirm, openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncConfirm', 'openAsyncAlert', 'closeAsyncPopup'])

    const tabList = [
      { tabId: 'exTab01', tabNm: 'LABNOTE', typecd: 'NOTE' }, 
      { tabId: 'exTab02', tabNm: 'SAP', typecd: 'SAP' },
      { tabId: 'exTab03', tabNm: 'ODM', typecd: 'ODM' },
    ]

    // 방부 시험의뢰 > 카운터 내용물 검색일 경우에는 ODM 없이 검색
    if(props.popParams.vFlagCounterPop == 'Y'){
      tabList.splice(2, 1)
    }

    const selectList = ref([])

    const { 
      page
      , list
      , selectSafetyContentsList
    } = useLabCommon()

    const searchParams = ref({
      vKeyword: props.popParams.vKeyword
      , vTypecd: props.popParams.vTypecd || 'NOTE'
    })

    const fnSearchSafetyContentsList = (pg, typecd) => {
      if (!pg) {
        searchParams.value.nowPageNo = 1
      }

      searchParams.value.nowPageNo = pg

      if (typecd) {
        searchParams.value.vTypecd = typecd
      }

      selectSafetyContentsList(searchParams.value)
    }

    // 선택
    const fnSelect = () => {
      const selectTargetList = list.value.filter(vo => vo.selectChk === 'Y')
      
      if (selectTargetList?.length > 0) {
        // 선택한 값이 있는 경우
        const pushList = []
        const dupList = []
        
        if (selectList.value.length > 0) {
          for (let i = 0; i < selectTargetList.length; i++) {
            const tvo = selectTargetList[i]

            if (searchParams.value.vTypecd === 'NOTE') {
              // E-LABNOTE 탭인 경우 vContCd, vLotCd 두 값 비교
              if (selectList.value.some(vo => vo.vContCd === tvo.vContCd && vo.vLotCd === tvo.vLotCd)) {
                dupList.push(tvo)
              } else {
                pushList.push(tvo)
              }
            } else {
              // SAP, ODM 탭은 vContCd 값만 비교
              if (selectList.value.some(vo => vo.vContCd === tvo.vContCd)) {
                dupList.push(tvo)
              } else {
                pushList.push(tvo)
              }
            }
          }
        } else {
          pushList.push(...selectTargetList)
        }

        if (dupList.length > 0) {
          openAsyncAlert({ message: `${dupList.map(vo => vo.vContNm).join('<br/>')}<br/><span style='font-weight: bold'>내용물 코드는 이미 존재합니다.</span>` })
        }

        selectList.value.push(...pushList)
  
        selectTargetList.forEach(vo => {
          vo.selectChk = 'N'
        })
      }
    }

    // 선택삭제
    const fnDelete = () => {
      selectList.value = selectList.value.filter(vo => vo.deleteChk !== 'Y')
    }

    // 적용
    const fnApply = () => {
      if (selectList.value.length > 0) {
        context.emit('selectFunc', selectList.value)
      }

      fnClose()
    }

    const fnClose = () => {
      context.emit('closeFunc')
    }

    const init = () => {
      if (props.popParams.productList?.length > 0) {
        selectList.value = props.popParams.productList
      }

      fnSearchSafetyContentsList(1)
    }

    const fnChangeTab = (item) => {
      fnSearchSafetyContentsList(1, item.typecd)
    }

    init()

    const setCounterContInfo = (vo) => {
      context.emit('selectFunc', vo)
    }

    return {
      t,
      tabList,
      selectList,
      page,
      list,
      searchParams,
      fnClose,
      fnSearchSafetyContentsList,
      fnChangeTab,
      fnSelect,
      fnDelete,
      fnApply,
      fnClose,
      setCounterContInfo
    }
  }
}
</script>