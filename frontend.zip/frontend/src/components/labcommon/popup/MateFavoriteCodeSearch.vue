<template>
  <div class="myboard-table">
    <div class="myboard-table__inner material-search-inner">
      <table class="ui-table ui-table__th--border-radius--0 ui-table__td--40 text-center">
        <colgroup>
          <col style="width:5rem">
          <col style="width:8rem">
          <col style="width:8rem">
          <col style="width:auto">
        </colgroup>
        <thead>
          <tr>
            <th class="chk-header">
              <ap-input-check
                id="favorite_raw_checkAll"
                value="Y"
                @click="fnRawCheckAllEvent"
              >
              </ap-input-check>
            </th>
            <th>원료코드</th>
            <th>구분</th>
            <th>원료명</th>
          </tr>
        </thead>
        <tbody>
          <template v-if="list && list.length > 0">
            <tr v-for="vo in list" :key="'favorite_code_' + vo.vKey">
              <td>
                <ap-input-check
                  v-model:model="vo.isChecked"
                  value="Y"
                  :id="'favorite_code_' + vo.vKey"
                  @click="fnRawCheckEvent"
                >
                </ap-input-check>
              </td>
              <td>{{ vo.vKey }}</td>
              <td>{{ vo.vMyMateTypeNm }}</td>
              <td class="tit">
                <MateName
                  :mate-info="vo"
                >
                </MateName>
              </td>
            </tr>
          </template>
          <template v-else>
            <tr>
              <td colspan="4">
                <div class="no-result">
                  {{ t('common.msg.no_data') }}
                </div>
              </td>
            </tr>
          </template>
        </tbody>
      </table>
    </div>
  </div>

  <div class="board-bottom board-bottom__with--button">
    <div class="board-bottom__inner">
      <Pagination
        :page-info="page"
        @click="fnSearch"
      >
      </Pagination>
      <div class="ui-buttons ui-buttons__right">
        <button type="button" class="ui-button ui-button__bg--skyblue font-weight__300" @click="fnApply()">선택적용</button>
        <button type="button" class="ui-button ui-button__bg--lightgray" @click="fnClose()">닫기</button>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, inject, defineAsyncComponent } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'MateFavoriteCodeSearch',
  components: {
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
    MateName: defineAsyncComponent(() => import('@/components/labcommon/MateName.vue')),
  },
  props: {
    searchParams: {
      type: Object,
      default: () => {
        return {
          vPlantCd: '',
          vLabNoteCd: '',
          vNoteType: '',
          vSiteType: '',
          vFlagSearchInit: 'N',
          vKeyword: '',
          nowPageNo: 1
        }
      }
    }
  },
  emits: ['applyFunc', 'closeFunc'],
  setup (props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const params = ref({})
    const { openAsyncAlert } = useActions(['openAsyncAlert'])
    const {
      page,
      list,
      selectSearchMyMateList,
      selectCheckClearList
    } = useLabCommon()

    const fnRawCheckAllEvent = (value) => {
      if(!list.value) {
        return
      }
      
      if (value === 'Y') {
        list.value.forEach(item => {
          item.isChecked = 'Y'
          document.querySelector('#favorite_code_' + item.vKey).checked = true
        })
      } else {
        list.value.forEach(item => {
          item.isChecked = ''
          document.querySelector('#favorite_code_' + item.vKey).checked = false
        })
      }
    }

    const fnRawCheckEvent = () => {
      if (list.value && list.value.filter(item => item.isChecked === 'Y').length === list.value.length) {
        document.querySelector('#favorite_raw_checkAll').checked = true
      } else {
        document.querySelector('#favorite_raw_checkAll').checked = false
      }
    }

    const fnSearch = async (pg) => {
      if (!pg) {
        pg = 1
      }

      params.value = { ...props.searchParams }
      params.value.nowPageNo = pg

      await selectSearchMyMateList(params.value)
      fnRawCheckEvent()
    }

    const fnApply = async () => {
      const resultList = list.value
      if (!resultList || resultList.filter(vo => vo.isChecked === 'Y').length === 0) {
        openAsyncAlert({ message: '적용 대상을 선택해 주세요.'})
        return
      }

      const arrMaterialCd = []

      resultList.filter(vo => vo.isChecked === 'Y').forEach(item => {
        arrMaterialCd.push(item.vMaterialCd)
      })

      const payload = {
        arrMaterialCd: arrMaterialCd,
        vType: props.searchParams.vSiteType + '_' + props.searchParams.vPlantCd
      }

      const message = await selectCheckClearList(payload)

      if (commonUtils.isNotEmpty(message)) {
        await openAsyncAlert({ message: message })
      }

      context.emit('applyFunc', resultList.filter(vo => vo.isChecked === 'Y'))
      fnClose()
    }

    const fnClose = () => {
      context.emit('closeFunc')
    }

    const init = () => {
      if (props.searchParams.vFlagSearchInit === 'Y') {
        fnSearch(1)
      }
    }

    init()

    return {
      t,
      page,
      list,
      fnRawCheckAllEvent,
      fnRawCheckEvent,
      fnSearch,
      fnApply,
      fnClose,
    }
  }
}
</script>