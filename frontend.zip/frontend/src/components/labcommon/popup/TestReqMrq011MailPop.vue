<template>
  <div class="modal-content">
    <div class="modal-header">
      <div class="modal-title">방부 알람 메일</div>
      <button
        type="button"
        class="modal-close"
        @click="fnClosePopup"
      ></button>
    </div>
    <div class="modal-body">
      <div class="search-depart-table">
        <div class="search-depart-table__inner">
          <table class="ui-table__td--40">
            <colgroup>
              <col style="width:13rem">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr>
                <th>내용물</th>
                <td>
                  [{{ noteVo?.vContCd }}] {{ noteVo?.vContNm }}
                </td>
              </tr>
              <tr>
                <th>요청내용</th>
                <td>
                  <ap-text-area
                    :is-with-byte="true"
                    :maxlength="2000"
                    id="vMailContent"
                    v-model:value="vMailContent"
                  ></ap-text-area>
                </td>
              </tr>
              <tr>
                <td colspan="2">
                  <ReferenceRegister
                    ref="refComp"
                    :default-list="rcvUsrList"
                  >
                  </ReferenceRegister>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="board-bottom">
        <div class="board-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <!-- <span class="mr-auto txt_blue">메일 발송 확인을 위해 제품 연구원에게도 동일 메일이 보내집니다.</span> -->
            <button
              type="button"
              class="ui-button ui-button__bg--skyblue font-weight__300"
              @click="fnSendMail"
            >메일 전송</button>
            <button
              type="button"
              class="ui-button ui-button__bg--lightgray"
              @click="fnCloseSubPopup"
            >닫기</button>
          </div>
        </div>
      </div>
    </div>
  </div>
  <teleport to="#common-modal-sub" v-if="popContent">
    <ap-popup>
      <component
        :is="popContent"
        :pop-params="popupParams"
        @selectFunc="popSelectFunc"
        @closeFunc="closeFunc"
      />
    </ap-popup>
  </teleport>
  <div id="common-modal-sub"></div>
</template>

<script>
import { inject, ref, reactive, defineAsyncComponent } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useTestReqCommon } from '@/compositions/labcommon/useTestReqCommon'

export default {
  name: 'TestReqMrq011MailPop',
  components:{
    UploadFileRegister: defineAsyncComponent(() => import('@/components/comm/UploadFileRegister.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    ReferenceRegister: defineAsyncComponent(() => import('@/components/comm/ReferenceRegister.vue')),
  },
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  emits: ['selectFunc', 'closeFunc'],
  setup (props, context) {
    const { openAsyncPopup, closeAsyncPopup } = useActions(['openAsyncPopup','closeAsyncPopup'])
    const noteVo = ref(null)
    const rcvUsrList = ref([])
    const closeFunc = ref(null)
    const result = ref(null)
    const refComp = ref(null)
    const vMailContent = ref('')

    const {
      selectLabNotePrdMrq011MailPop
    } = useTestReqCommon()

    const init = async () => {
      result.value = await selectLabNotePrdMrq011MailPop(props.popParams)
      
      noteVo.value = result.value.noteVo

      if(result.value.rcvUsrList){
        result.value.rcvUsrList.forEach(vo => {
          rcvUsrList.value.push({
            vRefNm: vo.vRefCdnm,
            vRefCd: vo.vUserid,
            vFlagRecNm: '참조자',
            vFlagRec: 'REF020',
          })
        })
      }
    }

    init()

    const fnSendMail = async () => {
      
      const qaUserIdList = ref([])
      rcvUsrList.value.forEach(item => {
        qaUserIdList.value.push(item.vUserid)
      })

      const payload = {
        vLabNoteCd : props.popParams.vLabNoteCd,
        vContPkCd: props.popParams.vContPkCd,
        vLotCd : props.popParams.vLotCd, 
        vPlantCd : props.popParams.vPlantCd,
        vLand1 : 'UN',
        referenceList: refComp.value.referenceList,
        vMailContent : vMailContent.value,
        vMailTitle : '[방부처방의뢰] ' + noteVo.value.vContCd + '/' + noteVo.value.vContNm,
        vContCd : noteVo.value.vContCd,
        vContNm : noteVo.value.vContNm
      }

      context.emit('selectFunc', payload)
    }

    const fnCloseSubPopup = () => {
      context.emit('closeFunc')
    }

    return {
      closeAsyncPopup,
      noteVo,
      rcvUsrList,
      fnSendMail,
      closeFunc,
      result,
      refComp,
      vMailContent,
      fnCloseSubPopup
    }
  }
}
</script>