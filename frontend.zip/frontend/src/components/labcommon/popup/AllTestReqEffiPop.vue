<template>
  <div class="modal-content modal-content__width--122">
    <div class="modal-header">
      <div class="modal-title">시험의뢰 (효능임상)</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({ message: '' })"></button>
    </div>
    <div class="modal-body">
      <div class="search-detail-table">
        <div class="search-detail-table__inner">
          <table class="ui-table__modal pd">
            <colgroup>
              <col style="width:10%">
              <col style="width:15%">
              <col style="width:15%">
              <col style="width:auto">
            </colgroup>
            <thead>
              <tr>
                <th></th>
                <th>내용물코드</th>
                <th>제품코드</th>
                <th>내용물명</th>
              </tr>
            </thead>
            <tbody>
              <template v-for="(cvo, index) in effi.contList" :key="`contPk_${index}`">
                  <tr>
                  <td><!-- cvo.vTestReqYn == 'Y' -->
                    <div class="ui-checkbox-block">
                      <ap-input-check
                        v-model:model="arrContPkCd"
                        :value="cvo.vContPkCd"
                        :id="'contPk_' + cvo.vContPkCd"
                        :disabled="cvo.vTestReqYn == 'N'"
                      >
                      </ap-input-check>
                    </div>
                  </td>
                  <td>{{ cvo.vContCd }}</td>
                  <td>{{ cvo.vPrdCd }}</td>
                  <td>
                    <div class="tit__inner">
                      {{ cvo.vContNm }}
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>
      
      <div class="board-bottom board-bottom__with--button">
        <div class="board-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--skyblue font-weight__300" @click="fnTestReqSave">시험의뢰</button>
            <button type="button" class="ui-button ui-button__bg--lightgray" @click="closeAsyncPopup({ message: '닫기' })">닫기</button>
          </div>
        </div>
      </div>

    </div>
  </div>
</template>

<script>
import { reactive, ref, inject } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useActions } from 'vuex-composition-helpers'
import { useTestReqCommon } from '@/compositions/labcommon/useTestReqCommon'

export default {
  name: 'AllTestReqEffiPop',
  components: {
  },
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: ''
        , vContPkCd: ''
        , nVersion: ''
        , vLotCd: ''
        , vPlantCd: ''
        , vMrqTypeCd: ''
        }
      }
    }
  },
  emits: ['selectFunc'],
  setup(props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { openAsyncConfirm, openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncConfirm', 'openAsyncAlert', 'closeAsyncPopup'])
    
    const result = ref('')
    const flagLotCompleYn = ref('')

    const {
      codeGroupMaps,
      // findCodeList
    } = useCode()

    const { 
      selectTestReqDetail
      , contList
      , goSkinTestReqClinicSave
      , arrContPkCd
      , params
    } = useTestReqCommon()

    const effi = reactive({
      noteVo: {},
      contList: [],
      lotList: [],
      lastTrVo: {},
      vTrMrqTypeCd:'',
    })

    const fnTestReqSave = () => {

      if(arrContPkCd.value.length === 0){
        openAsyncAlert({ message: "내용물 코드를 선택해 주세요." })
        return
      }
      
      const payload = {
        vLabNoteCd: props.popParams.vLabNoteCd
      , vContPkCd: props.popParams.vContPkCd
      , nVersion: props.popParams.nVersion
      , vPlantCd: props.popParams.vPlantCd
      , vMrqTypeCd: props.popParams.vMrqTypeCd
      , vTrMrqTypeCd: effi.vTrMrqTypeCd
      , vGateCd: props.popParams.vGateCd
      , vFlagAction: 'SAVE_CLINICAL_TEST_REQ'
      , arrContPkCd: arrContPkCd.value
      , vLotCd: props.popParams.vLotCd
      , contList: effi.contList.filter(cvo => arrContPkCd.value.indexOf(cvo.vContPkCd) > -1)
      }

      goSkinTestReqClinicSave(payload)

    }

    const searchParams = {
      vLabNoteCd: props.popParams.vLabNoteCd
        , vContPkCd: props.popParams.vContPkCd
        , nVersion: props.popParams.nVersion
        , vLotCd: ''
        , vPlantCd: props.popParams.vPlantCd
        , vMrqTypeCd: props.popParams.vMrqTypeCd
    } 

    const init = async () => {
      // findCodeList(['LAB_NOTE_PLANT'])

      //실험노트 정보 불러오기
      //실험노트 마스터 정보
      //실험노트 내용물 정보
      //실험노트 로트 정보
      result.value = await selectTestReqDetail(searchParams)

      effi.noteVo = result.value.noteVo
      effi.contList = result.value.contList
      effi.lotList = result.value.lotList
      effi.lastTrVo = result.value.lastTrVo
      effi.vTrMrqTypeCd = result.value.vTrMrqTypeCd

    }

    init()

    return {
      t,
      searchParams,
      codeGroupMaps,
      closeAsyncPopup,
      selectTestReqDetail,
      contList,
      goSkinTestReqClinicSave,
      fnTestReqSave,
      arrContPkCd,
      params,
      result,
      effi,
      flagLotCompleYn,
    }
  }
}
</script>