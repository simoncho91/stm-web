<template>
  <div class="modal-content" style="width: 80rem;">
    <div class="modal-header">
      <div class="modal-title">카운터 검색</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({message: ''})"></button>
    </div>
    <div class="modal-body">
      <div class="contents-tab">
        <div class="contents-tab__inner">
          <ApTab
            mst-id="counter-search-pop"
            :tab-list="tabList"
            @click="getSelectedTabEvent"
            :default-tab="popParams.vDefaultTab"
          >
          </ApTab>
          <div class="contents-tab__body" id="labNoteSearch">
            <CounterLabNoteSearch
              v-if="selectedTab === 'labNoteSearch'"
              :search-params="searchParams"
              @apply-func="getResultItem"
            >
            </CounterLabNoteSearch>
          </div>
          <div class="contents-tab__body" id="inventorySearch">
            <CounterInventorySearch
              v-if="selectedTab === 'inventorySearch'"
              :search-params="searchParams"
              @apply-func="getResultItem"
            >
            </CounterInventorySearch>
          </div>
          <div class="contents-tab__body" id="sapSync">
            <CounterSapSync
              v-if="selectedTab === 'sapSync'"
              :search-params="searchParams"
            >
            </CounterSapSync>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, reactive, ref } from 'vue'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'CounterSearchPop',
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    CounterLabNoteSearch: defineAsyncComponent(() => import('@/components/labcommon/popup/CounterLabNoteSearch.vue')),
    CounterInventorySearch: defineAsyncComponent(() => import('@/components/labcommon/popup/CounterInventorySearch.vue')),
    CounterSapSync: defineAsyncComponent(() => import('@/components/labcommon/popup/CounterSapSync.vue')),
  },
  emits: ['selectFunc'],
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vKeyword: '',
          vNoteType: '',
          vPlantCd: '',
          vDefaultTab: 'labNoteSearch'
        }
      }
    }
  },
  setup (props, context) {
    const sap = ref(null)
    const inven = ref(null)
    const sync = ref(null)

    const selectedTab = ref(props.popParams.vDefaultTab)
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])

    const searchParams = reactive({
      vKeyword: props.popParams.vKeyword,
      vNoteType: props.popParams.vNoteType,
      vPlantCd: props.popParams.vPlantCd,
      vCodeType: props.popParams.vCodeType,
    })

    const tabList = [
      { tabId: 'labNoteSearch', tabNm: '실험노트' },
      { tabId: 'inventorySearch', tabNm: '인벤토리' },
      { tabId: 'sapSync', tabNm: 'SAP SYNC' },
    ]

    const getSelectedTabEvent = (item) => {
      selectedTab.value = item.tabId
    }

    const getResultItem = (item) => {
      context.emit('selectFunc', item)
    }

    return {
      sap,
      inven,
      sync,
      searchParams,
      tabList,
      selectedTab,
      getSelectedTabEvent,
      getResultItem,
      closeAsyncPopup,
    }
  }
}
</script>