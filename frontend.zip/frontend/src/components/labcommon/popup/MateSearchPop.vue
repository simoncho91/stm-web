<template>
  <div class="modal-content" style="width: 90rem;">
    <div class="modal-header">
      <div class="modal-title">원료검색</div>
      <button type="button" class="modal-close" @click="fnClose"></button>
    </div>
    <div class="modal-body">
      <section class="search-bar p-0">
        <h2 class="for-a11y">검색</h2>
        <div class="search-bar__left">
          <div class="search-bar__row">
            <dl class="search-bar__item search-bar__item--width-100">
              <dt class="search-bar__key">검색</dt>
              <dd class="search-bar__val search-bar__val--flex">
                <div class="search-form">
                  <div class="search-form__inner">
                    <ap-input
                      v-model:value="searchParams.vKeyword"
                      placeholder="원료코드 or 원료명"
                      @keypress-enter="fnMateSearch"
                    >
                    </ap-input>
                    <button type="button" class="button-search" @click="fnMateSearch">검색</button>
                  </div>
                </div>
              </dd>
            </dl>
          </div>
        </div>
      </section>

      <div class="contents-tab ap_contents_tab">
        <div class="contents-tab__inner">
          <ApTab
            mst-id="mate-search-pop"
            :tab-list="tabList"
            @click="getSelectedTabEvent"
            :default-tab="popParams.vDefaultTab"
          >
          </ApTab>
          <div class="contents-tab__body" id="sapSearch">
            <MateSapCodeSearch
              v-if="selectedTab === 'sapSearch'"
              ref="sap"
              :search-params="searchParams"
              @apply-func="getResultItem"
              @close-func="fnClose"
            >
            </MateSapCodeSearch>
          </div>
          <div class="contents-tab__body" id="tempSearch">
            <MateTempCodeSearch
              v-if="selectedTab === 'tempSearch'"
              ref="temp"
              :search-params="searchParams"
              @apply-func="getResultItem"
              @close-func="fnClose"
            >
            </MateTempCodeSearch>
          </div>
          <div class="contents-tab__body" id="favoriteSearch">
            <MateFavoriteCodeSearch
              v-if="selectedTab === 'favoriteSearch'"
              ref="favorite"
              :search-params="searchParams"
              @apply-func="getResultItem"
              @close-func="fnClose"
            >
            </MateFavoriteCodeSearch>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, reactive, ref } from 'vue'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'MateSearchPop',
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    MateSapCodeSearch: defineAsyncComponent(() => import('@/components/labcommon/popup/MateSapCodeSearch.vue')),
    MateTempCodeSearch: defineAsyncComponent(() => import('@/components/labcommon/popup/MateTempCodeSearch.vue')),
    MateFavoriteCodeSearch: defineAsyncComponent(() => import('@/components/labcommon/popup/MateFavoriteCodeSearch.vue')),
  },
  emits: ['selectFunc', 'closeFunc'],
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vKeyword: '',
          vPlantCd: '',
          vLabNoteCd: '',
          vNoteType: '',
          vSiteType: '',
          vFlagSearchInit: 'N',
          vDefaultTab: 'sapSearch'
        }
      }
    }
  },
  setup (props, context) {
    const sap = ref(null)
    const temp = ref(null)
    const favorite = ref(null)

    const selectedTab = ref(props.popParams.vDefaultTab)
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])
    const searchParams = reactive({
      vKeyword: props.popParams.vKeyword,
      vPlantCd: props.popParams.vPlantCd,
      vLabNoteCd: props.popParams.vLabNoteCd,
      vSiteType: props.popParams.vSiteType,
      vFlagSearchInit: props.popParams.vFlagSearchInit,
      vNoteType: props.popParams.vNoteType
    })

    console.log(searchParams)

    const tabList = [
      { tabId: 'sapSearch', tabNm: 'SAP코드' },
      { tabId: 'tempSearch', tabNm: '임시코드 검색' },
      { tabId: 'favoriteSearch', tabNm: '나의 즐겨찾기 원료' },
    ]

    const getSelectedTabEvent = (item) => {
      selectedTab.value = item.tabId
    }

    const getResultItem = (list) => {
      context.emit('selectFunc', list)
    }

    const fnClose = () => {
      if (props.popParams.popType !== 'SUB') {
        closeAsyncPopup({ message: '' })
      } else {
        context.emit('closeFunc')
      }
    }

    const fnMateSearch = () => {
      if (selectedTab.value === 'sapSearch') {
        sap.value.fnSearch(1)
      } else if (selectedTab.value === 'tempSearch') {
        temp.value.fnSearch(1)
      } else if (selectedTab.value === 'favoriteSearch') {
        favorite.value.fnSearch(1)
      }
    }

    return {
      searchParams,
      tabList,
      selectedTab,
      sap,
      temp,
      favorite,
      getSelectedTabEvent,
      getResultItem,
      fnMateSearch,
      fnClose,
    }
  }
}
</script>