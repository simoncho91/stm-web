<template>
  <div class="modal-content">
    <div class="modal-header">
      <div class="modal-title">전성분 미리보기</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup()"></button>
    </div>

    <div class="modal-body">

      <div class="search-depart-table">
        <div class="search-depart-table__inner">
          <table class="ui-table__td--40">
            <colgroup>
              <col style="width:19rem">
              <col style="width:auto">
              <col style="width:19rem">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr>
                <th>ZPLM34E / ZPLM34</th>
                <td>
                  <div class="ui-radio__list">
                    <div class="ui-radio__inner">
                      <ap-input-radio v-model:model="searchParams.vLand1" :value="'UN'" :label="'ZPLM34E'"
                        :id="'land_radio1'" name="landRadio" />
                      <ap-input-radio v-model:model="searchParams.vLand1" :value="'KR'" :label="'ZPLM34'"
                        :id="'land_radio2'" name="landRadio" />
                    </div>
                  </div>
                </td>
                <th>LEAVE-ON / WASH-OFF</th>
                <td>
                  <div class="form-flex">
                    <div class="form-flex__cell">
                      <div class="ui-radio__list">
                        <div class="ui-radio__inner">
                          <ap-input-radio v-model:model="searchParams.vFlagLeaveType" :value="'L'" :label="'Leave-on'"
                            :id="'leave_type_radio1'" name="leaveTypeRadio" />
                          <ap-input-radio v-model:model="searchParams.vFlagLeaveType" :value="'R'" :label="'Wash-off'"
                            :id="'leave_type_radio2'" name="leaveTypeRadio" />
                        </div>
                      </div>
                    </div>
                    <div class="form-flex-cell">
                      <button type="button"
                        class="ui-button ui-button__width--60 ui-button__height--28 ui-button__radius--2 ui-button__bg--blue"
                        @click="onSearch()">변경</button>
                    </div>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>


      <div v-if="btnInfo.show" class="normal-tab mt-7">
        <div class="normal-tab__inner">
          <div class="normal-tab__header">
            <ul class="ui-list normal-tab__lists">
              <li class="normal-tab__list" :class="searchParams.vAllergenTabId !== 'NONE_ALLERGEN' ? 'is-active' : ''">
                <a href="javascript:void(0)" class="normal-tab__link" @click="onSearch('ALLERGEN')">알러젠 표기</a>
              </li>
              <li class="normal-tab__list" :class="searchParams.vAllergenTabId === 'NONE_ALLERGEN' ? 'is-active' : ''">
                <a href="javascript:void(0)" class="normal-tab__link" @click="onSearch('NONE_ALLERGEN')">알러젠 미표기</a>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div class="search-detail-table mt-15">
        <div class="search-detail-table__inner">
          <table class="ui-table__modal">
            <colgroup>
              <col style="width:6%;">
              <col style="width:13%;">
              <col style="width:15%;">
              <col style="width:11%;">
              <col style="width:7%;">
              <col style="width:7%;">
              <col style="width:auto;">
              <col style="width:8rem">
              <col style="width:9rem;">
            </colgroup>
            <thead>
              <tr>
                <th>성분코드</th>
                <th>표시명(한글)</th>
                <th>표시명(영문)</th>
                <th>표시명(중문)</th>
                <th>함량</th>
                <th>원료코드</th>
                <th>기능</th>
                <th>EWG</th>
                <th>배합규제</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(vo, idx) in info.list" :key="idx">
                <td>{{ vo.vConcd }}</td>
                <td class="text-left">{{ !vo.vPsnameKo ? vo.vConnameKo : vo.vPsnameKo }}</td>
                <td class="text-left">{{ !vo.vPsnameEn ? vo.vConnameEn : vo.vPsnameEn }}</td>
                <td class="text-left">{{ !vo.vPsnameCh ? vo.vConnameCh : vo.vPsnameCh }}</td>
                <td class="text-right">{{ vo.nSumInPer }}</td>
                <td>
                  <template v-for="(mate, mIdx) in vo.mateList" :key="mIdx">
                    <span :title="mate.vMateCd + ' : ' + mate.vMateNm" style="cursor: help;">
                      {{ mate.vMateCd }}<template v-if="vo.mateList.length !== (mIdx + 1)"><br /></template>
                    </span>
                  </template>
                </td>
                <td class="text-left">{{ vo.vFcnameEn }}</td>
                <td :class="vo.vEwgGrade === 'GREEN' ?
                  'td-grade__1' : (vo.vEwgGrade === 'YELLOW' ?
                    'td-grade__4' : (vo.vEwgGrade === 'RED' ?
                      'td-grade__2' : ''))">
                  {{ vo.vEwgGrade === 'NA' ? vo.vEwgGrade : vo.nEwgGradeNum + '등급' }}
                </td>
                <td>
                  <button v-if="vo.vMixre" type="button"
                    class="ui-button ui-button__width--81 ui-button__height--28 ui-button__radius--2 ui-button__border--blue"
                    @click="onMatrMixreInfoPop(vo.vConcd)">
                    {{ vo.vMixre }}
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div class="search-detail-total search-detail-total__center">
        <div class="search-detail-total__inner">
          <div class="search-detail-total__text">함량합계</div>
          <div class="search-detail-total__num">{{ info.nInciTotalPer }}</div>
        </div>
      </div>

      <div v-if="1 === 2" class="board-bottom ">
        <div class="board-bottom__inner">
          <div class="ui-buttons ml-auto ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--lightgray" @click="closeAsyncPopup()">닫기</button>
          </div>
        </div>
      </div>
    </div>

    <teleport to="#common-modal-sub" v-if="popContent">
      <ap-popup>
        <component :is="popContent" :pop-params="popupParams" @selectFunc="popSelectFunc" @closeFunc="closeFunc" />
      </ap-popup>
    </teleport>
    <div id="common-modal-sub"></div>
  </div>
</template>

<script>
import { defineAsyncComponent, reactive, ref } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useMaterialCommon } from '@/compositions/labcommon/useMaterialCommon'

export default {
  name: 'IngredientPop',
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    MatrMixreInfoPop: defineAsyncComponent(() => import('@/components/labcommon/popup/MatrMixreInfoPop.vue')),
  },
  emits: ['selectFunc'],
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: '',
          vPlantCd: '',
          vLotCd: '',
          vLand1: '',
          vFlagLeaveType: '',
        }
      }
    }
  },
  setup(props, context) {
    const { openAsyncPopup, closeAsyncPopup } = useActions(['openAsyncPopup', 'closeAsyncPopup'])

    const info = ref({
      list: [],
      nInciTotalPer: 0,
    })
    const searchParams = reactive({
      vLabNoteCd: props.popParams.vLabNoteCd,
      vLotCd: props.popParams.vLotCd,
      vPlantCd: props.popParams.vPlantCd,
      vLand1: props.popParams.vLand1,
      vFlagLeaveType: props.popParams.vFlagLeaveType,
      vAllergenTabId: '',
    })
    const btnInfo = reactive({
      show: false,
    })
    const popContent = ref(null)
    const popSelectFunc = ref(null)
    const popupParams = ref({})
    const closeFunc = ref({})

    const { selectLabNoteIngredientList } = useMaterialCommon()

    const init = async () => {
      info.value = await selectLabNoteIngredientList(searchParams)

      btnInfo.show = false
      if (searchParams.vLand1 === 'UN') {
        btnInfo.show = true
      }
    }

    const onSearch = (o = null) => {
      if (o) {
        searchParams.vAllergenTabId = o
      }
      else {
        searchParams.vAllergenTabId = ''
      }

      init()
    }

    const closeMatrMixreInfoPop = () => {
      popContent.value = null
    }

    const onMatrMixreInfoPop = (vConcd) => {
      popContent.value = 'MatrMixreInfoPop'
      popupParams.value = {
        vConcd,
        vIsInnerPop: true,
      }
      closeFunc.value = closeMatrMixreInfoPop

      openAsyncPopup()
        .then(res => {
        })
        .catch(err => {
          console.log(err)
        })
        .finally(() => {
          popContent.value = null
        })
    }

    init()

    return {
      info,
      searchParams,
      btnInfo,
      popContent,
      popSelectFunc,
      popupParams,
      closeFunc,
      onSearch,
      onMatrMixreInfoPop,
      closeAsyncPopup,
    }
  }
}
</script>
