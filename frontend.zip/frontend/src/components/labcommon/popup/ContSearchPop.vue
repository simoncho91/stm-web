<template>
  <div class="modal-content" style="width: 80rem;">
    <div class="modal-header">
      <div class="modal-title">내용물코드 검색</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({message: ''})"></button>
    </div>
    <div class="modal-body">
      <div class="contents-tab">
        <div class="contents-tab__inner">
          <ApTab
            mst-id="counter-search-pop"
            :tab-list="tabList"
            @click="getSelectedTabEvent"
            :default-tab="popParams.vDefaultTab"
          >
          </ApTab>
          <div class="contents-tab__body" id="labNoteSearch">
            <section class="search-bar p-0 mt-15">
              <h2 class="for-a11y">검색</h2>
              <div class="search-bar__left">
                <div class="search-bar__row">
                  <dl class="search-bar__item search-bar__item--width-100">
                    <dt class="search-bar__key">검색</dt>
                    <dd class="search-bar__val search-bar__val--flex">
                      <div class="search-form">
                        <div class="search-form__inner">
                          <ap-input
                            v-model:value="searchParams.vKeyword"
                            placeholder="내용물코드 or 내용물명 or PLANT 코드"
                            @keypress-enter="fnSearch(1)"
                          >
                          </ap-input>
                          <button type="button" class="button-search" @click="fnSearch(1)">검색</button>
                        </div>
                      </div>
                    </dd>
                  </dl>
                </div>
              </div>
            </section>

            <div class="myboard-table mt-15">
              <div class="myboard-table__inner">
                <table class="ui-table ui-table__th--border-radius--0 ui-table__td--40 text-center">
                  <colgroup>
                    <col style="width: 5rem">
                    <col style="width: 15rem">
                    <col style="width: 15rem">
                    <col style="width: auto">
                    <col style="width: 6rem">
                  </colgroup>
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>내용물코드</th>
                      <th>PLANT 코드</th>
                      <th>내용물명</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    <template v-if="list && list.length > 0">
                      <tr v-for="vo in list" :key="'counter_' + vo.vContCd">
                        <td>{{ vo.nNum }}</td>
                        <td>{{ vo.vContCd }}</td>
                        <td>{{ vo.vPlantCd}}</td>
                        <td>{{ vo.vContNm }}</td>
                        <td>
                          <button type="button"
                            :class="['ui-button',
                                    'ui-button__width--40',
                                    'ui-button__height--23', 
                                    'ui-button__border--blue', 
                                    'ui-button__radius--2']"
                            @click="fnContSelect(vo)"
                          >선택</button>
                        </td>
                      </tr>
                    </template>
                    <template v-else>
                      <tr>
                        <td colspan="5">
                          <div class="no-result">
                            {{ t('common.msg.no_data') }}
                          </div>
                        </td>
                      </tr>
                    </template>
                  </tbody>
                </table>
              </div>
            </div>

            <div class="board-bottom board-bottom__with--button">
              <div class="board-bottom__inner">
                <Pagination
                  :page-info="page"
                  @click="fnSearch"
                >
                </Pagination>
                <div class="ui-buttons ui-buttons__right">
                  <button type="button" class="ui-button ui-button__bg--lightgray" @click="closeAsyncPopup({ message: '닫기'})">닫기</button>
                </div>
              </div>
            </div>
          </div>
          
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, reactive, ref, inject } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'

export default {
  name: 'ContSearchPop',
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
  },
  emits: ['callbackFunc'],
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vKeyword: '',
          vPlantCd: '',
          vDefaultTab: 'NOTE'
        }
      }
    }
  },
  setup (props, context) {
    const t = inject('t')
    const selectedTab = ref(props.popParams.vDefaultTab)
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])

    const page = ref({})
    const list = ref([])

    const searchParams = reactive({
      vKeyword: props.popParams.vKeyword || '',
      vCodeType: selectedTab.value,
      nowPageNo: 1
    })

    const {
      selectSaNoteContSearchList
    } = useProcessCommon()

    const tabList = [
      { tabId: 'NOTE', tabNm: '실험노트' },
      { tabId: 'SAP', tabNm: 'SAP 코드' },
    ]

    const getSelectedTabEvent = (item) => {
      selectedTab.value = item.tabId
      fnSearch(1)
    }

    const fnSearch = async (pg) => {
      if (!pg) {
        pg = 1
      }

      searchParams.nowPageNo = pg

      let result = await selectSaNoteContSearchList(searchParams)

      if (result) {
        page.value = result.page
        list.value = result.list
      } else {
        page.value = {}
        list.value = []
      }
    }

    const fnContSelect = (vo) => {
      context.emit('callbackFunc', vo)
      closeAsyncPopup({ message: '닫기' })
    }

    const init = () => {
      fnSearch(1)
    }

    init()

    return {
      t,
      searchParams,
      page, 
      list,
      tabList,
      selectedTab,
      getSelectedTabEvent,
      fnSearch,
      closeAsyncPopup,
      fnContSelect
    }
  }
}
</script>