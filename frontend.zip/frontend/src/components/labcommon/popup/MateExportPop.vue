<template>
  <div class="modal-content modal-content__width--auto">
    <div class="modal-header">
      <div class="modal-title">엑셀 및 공유하기</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({ message: '' })"></button>
    </div>
    <div class="modal-body">
      <div class="material-setting">
        <div class="material-setting__inner" style="border: none; -webkit-box-shadow: none;">
          <div class="material-setting__item">
            <div class="material-setting__buttons">
              <!-- 2023.04.07 : mod : 노트 공유하기 아이콘 수정, 엑셀 양식 다운로드 버튼 추가, 이력보기 아이콘 추가 -->
              <button class="material-setting__button" @click="fnNoteAuthPop">
                <i class="material-setting__button--icon material-setting__button--icon-note__share"></i>
                <span class="material-setting__button--text">노트 공유하기</span>
              </button>

              <input type="file" ref="uploadFile" @change="onChangeUpload($event)" v-show="false" />
              <button class="material-setting__button" @click="onExcelUpload">
                <i class="material-setting__button--icon material-setting__button--icon-upload"></i>
                <span class="material-setting__button--text">엑셀 업로드</span>
              </button>

              <!-- <button class="material-setting__button"><i
                  class="material-setting__button--icon material-setting__button--icon-download"></i><span
                  class="material-setting__button--text">엑셀 다운로드</span></button> -->

              <button class="material-setting__button">
                <i class="material-setting__button--icon material-setting__button--icon-download"></i>
                <span class="material-setting__button--text">
                  <a href="/file/UploadTemplate.xlsx" style="color: #545454; text-decoration: none;"
                    download="UploadTemplate.xlsx">엑셀 양식
                    다운로드</a>
                </span>
              </button>

              <!-- <button class="material-setting__button"><i
                  class="material-setting__button--icon material-setting__button--icon-share"></i><span
                  class="material-setting__button--text">이력보기</span></button> -->


            </div>
          </div>
        </div>
      </div>

      <div class="board-bottom">
        <div class="board-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--lightgray"
              @click="closeAsyncPopup({ message: '닫기' })">닫기</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, inject } from 'vue'
import { useMaterialCommon } from '@/compositions/labcommon/useMaterialCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'MateExportPop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: '',
          vContPkCd: '',
          nVersion: '',
          vLotCd: '',
          vPlantCd: '',
          vLand1: '',
        }
      }
    }
  },
  emits: ['selectFunc'],
  setup(props, context) {
    const reqInfo = inject('reqInfo')
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert, openAsyncConfirm, closeAsyncPopup } = useActions(['openAsyncAlert', 'openAsyncConfirm', 'closeAsyncPopup'])
    const uploadFile = ref(null)

    const { updateMaterialFormulationExcel } = useMaterialCommon()

    const fnNoteAuthPop = () => {
      context.emit('selectFunc', 'auth')
      // closeAsyncPopup({ message: '닫기' })
    }

    const onChangeUpload = async (e) => {
      const files = e.target.files

      if (files === undefined || files.length === 0) {
        return
      }

      const message = await updateMaterialFormulationExcel({
        vLabNoteCd: props.popParams.vLabNoteCd,
        vContPkCd: props.popParams.vContPkCd,
        nVersion: props.popParams.nVersion,
        vLotCd: props.popParams.vLotCd,
        vPlantCd: props.popParams.vPlantCd,
        vLand1: props.popParams.vLand1,
        files,
      })

      openAsyncAlert({ message: message === 'success' ? '저장 되었습니다.' : message })
      if (message === 'success') {
        context.emit('selectFunc', 'excel')
      }
      closeAsyncPopup({ message: '닫기' })
    }

    const onExcelUpload = async () => {
      let failMessage = '';
      const lotList = reqInfo.value.lotList
      if (lotList.filter(lot => lot.vFlagExistsBom === 'Y').length > 0) {
        failMessage = '이미 BOM 전송 된 Lot이 있습니다.'
      }
      else if (lotList.filter(lot => lot.nPilotTestSeqno).length > 0) {
        failMessage = '이미 파일럿 처방 등록 된 Lot이 있습니다.'
      }
      else if (lotList.filter(lot => lot.vFlagComplete === 'Y').length > 0) {
        failMessage = '이미 시험의뢰 요청 된 Lot이 있습니다.'
      }

      if (failMessage) {
        openAsyncAlert({ message: `${failMessage}<br/>새로운 버전 생성 후 업로드 가능합니다.` })
        return
      }

      let message = '<span style="font-weight: bolder;">[주의]</span>Excel 업로드 시 현재 version 이 Excel data로 <span style="color: red; font-weight: bolder;">초기화</span> 됩니다.'
      message += '<br/>기존 data 초기화를 원하시지 않을 경우 새로운 버전 생성 후 업로드 부탁드립니다.'
      if (!await openAsyncConfirm({ message })) {
        return
      }

      uploadFile.value.click()
    }

    return {
      t,
      commonUtils,
      uploadFile,
      fnNoteAuthPop,
      onChangeUpload,
      onExcelUpload,
      closeAsyncPopup,
    }
  }
}
</script>