<template>
  <div class="modal-content modal-content__width--122">
    <div class="modal-header">
      <div class="modal-title">시험의뢰 (방부)</div>
      <button
        type="button"
        class="modal-close"
        @click="closeAsyncPopup"
      ></button>
    </div>
    <div class="modal-body">
      <div class="search-detail-table">
        <div class="search-detail-table__inner">
          <table class="ui-table__modal pd">
            <colgroup>
              <col style="width:6%">
              <col style="width:6%">
              <col style="width:15%">
              <col style="width:auto">
              <col style="width:8%">
              <col style="width:13%">
              <col style="width:13%">
              <col style="width:10%">
            </colgroup>
            <thead>
              <tr>
                <th>
                  <ap-input-check
                    v-model:model="chkAll"
                    :value="'Y'"
                    :false-value="'N'"
                    :id="'ex_check_all'"
                    @click="fnCheckAll"
                  >
                  </ap-input-check>
                </th>
                <th>대표</th>
                <th>내용물코드/제품코드</th>
                <th>내용물명</th>
                <th>플랜트</th>
                <th>버전</th>
                <th>LOT</th>
                <th>비고 </th>
              </tr>
            </thead>
            <tbody>
              <template v-if="resData?.contList && resData?.contList.length > 0">
                <tr v-for="(cvo, idx) in resData.contList" :key="'tr_' + idx">
                  <td id="error_wrap_arrContPkCd">
                    <ap-input-check
                      v-model:model="regParam.arrContPkCd"
                      :value="cvo.vContPkCd"
                      :id="'ex_check_' + idx"
                      @click="fnAddTestReqTarget($event, idx, cvo);"
                    >
                    </ap-input-check>
                    <span class="error-msg" id="error_msg_arrContPkCd"></span>
                  </td>
                  <td>
                    <div class="ui-label jc-c" id="error_wrap_vRepContPkCd">
                      <ap-input-radio
                        v-model:model="regParam.vRepContPkCd"
                        :value="cvo.vContPkCd"
                        :id="'representPkCd_' + idx"
                        name="representPkCd"
                        @click="fnValidate('vRepContPkCd')"
                      ></ap-input-radio>
                      <span class="error-msg" id="error_msg_vRepContPkCd"></span>
                    </div>
                  </td>
                  <td>{{ cvo.vContCd }} / {{ cvo.vPrdCd }}</td>
                  <td>
                    <div class="tit__inner">
                      {{ cvo.vContNm }}
                    </div>
                    </td>
                  <td>{{ cvo.vPlantCd }}</td>
                  <td>
                    <div class="ui-select-block">
                      <ap-selectbox
                        v-model:value="cvo.nVersion"
                        input-class="ui-select__width--120"
                        :options="resData.verList"
                        codeKey="nVersion"
                        codeNmKey="vVersionTxt"
                        :disabled="regParam.arrContPkCd.indexOf(cvo.vContPkCd) === -1"
                        @change="fnChangeVersion($event, cvo)"
                      >
                      </ap-selectbox>
                    </div>
                  </td>
                  <td>
                    <div class="ui-select-block" id="error_wrap_arrLotCd">
                      <ap-selectbox
                        v-model:value="cvo.vLotCd"
                        input-class="ui-select__width--120"
                        :options="cvo.subList"
                        codeKey="vLotCd"
                        codeNmKey="vLotNm"
                        :disabled="regParam.arrContPkCd.indexOf(cvo.vContPkCd) === -1"
                        @change="fnSelectOption($event, cvo, idx);"
                      >
                      </ap-selectbox>
                      <span class="error-msg" id="error_msg_arrLotCd"></span>
                    </div>
                  </td>
                  <td>
                    {{ cvo.vPrdNmEn }}
                  </td>
                </tr>
              </template>
              <template v-else>
                <tr>
                  <td colspan="8">
                    <div class="no-result">
                      {{ t('common.msg.no_data') }}
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>

      <div class="tableTitle mt-2">정보 입력</div>
      <div class="board-top">
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">완료요청일</dt>
            <dd class="search-bar__val search-bar__val--flexible" id="error_wrap_vTrCompleteReqDt">
              <ap-date-picker
                v-model:date="regParam.vTrCompleteReqDt"
                :read-only="true"
                :input-class="'ui-input__width--full'"
                @click="fnValidate('vTrCompleteReqDt')"
              />
              <span class="error-msg" id="error_msg_vTrCompleteReqDt"></span>
            </dd>
          </dl>
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">제형</dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="search-form">
                <div class="search-form__inner">
                  <ap-selectbox
                    v-model:value="regParam.vDosageFormCd"
                    :options="codeGroupMaps['DOSAGE_FORM']"
                    input-class="ui-select__width--full"
                  />
                </div>
              </div>
            </dd>
          </dl>
        </div>
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">{{ regParam.vTestTypeNm || '-' }}</dt>
            <dd class="search-bar__val search-bar__val--flexible" style="text-align: left;">
              {{ regParam.vTestValue }}
            </dd>
          </dl>
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">pH<span class="ui-require"><span class="for-a11y">(필수)</span></span></dt>
            <dd class="search-bar__val search-bar__val--flexible" id="error_wrap_vTrPh">
              <ap-input 
                :is-number="false" 
                v-model:value="regParam.vTrPh"
                @input="fnValidate('vTrPh')"
                >
              </ap-input>
              <span class="error-msg" id="error_msg_vTrPh"></span>
            </dd>
          </dl>
        </div>
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">파일럿 시기</dt>
            <dd class="search-bar__val search-bar__val--flexible" id="error_wrap_vTrPilotDt">
              <ap-month-picker
                v-model:date="regParam.vTrPilotDt"
                :read-only="true"
                input-class="ui-input__width--full"
                @update:date="fnValidate('vTrPilotDt')"
              />
              <span class="error-msg" id="error_msg_vTrPilotDt"></span>
            </dd>
          </dl>
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">용기정보<span class="ui-require"><span class="for-a11y">(필수)</span></span></dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="search-form">
                <div class="search-form__inner" id="error_wrap_vContainerCd">
                  <ap-selectbox
                    v-model:value="regParam.vContainerCd"
                    :options="codeGroupMaps['LNC26']"
                    :input-class="['ui-form-box__width--237', 'ui-select__width--full', 'form-flex__cell--5']"
                    @input="fnValidate('vContainerCd')"
                  />
                  <ap-input
                    id="vContainerEtc"
                    v-model:value="regParam.vContainerEtc"
                    :maxlength="200"
                    input-class="form-flex__cell--5"
                    >
                  </ap-input>
                  <span class="error-msg" id="error_msg_vContainerCd"></span>
                </div>
              </div>
            </dd>
          </dl>
        </div>
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">TDD 제품유형<span class="ui-require"><span class="for-a11y">(필수)</span></span></dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="search-form">
                <div class="search-form__inner">
                  <div class="ui-select-box ui-form-box__width--237 form-flex__cell--5">
                    <div id="error_wrap_vTddProdType1Cd">
                      <ap-selectbox
                        v-model:value="regParam.vTddProdType1Cd"
                        :options="tddProdType1List"
                        codeKey="vClassCd"
                        codeNmKey="vClassNm"
                        :input-class="['ui-select__width--full']"
                        @change="fnValidate('vTddProdType1Cd');getTddProdType2List($event);"
                      />
                      <span class="error-msg" id="error_msg_vTddProdType1Cd"></span>
                    </div>
                  </div>
                  
                  <div class="ui-select-box ui-form-box__width--237 form-flex__cell--5">
                    <div id="error_wrap_vTddProdType2Cd">
                      <ap-selectbox
                        v-model:value="regParam.vTddProdType2Cd"
                        :options="tddProdType2List"
                        codeKey="vClassCd"
                        codeNmKey="vClassNm"
                        :input-class="['ui-form-box__width--237', 'ui-select__width--full', 'form-flex__cell--5']"
                        @change="fnValidate('vTddProdType2Cd')"
                      />
                      <span class="error-msg" id="error_msg_vTddProdType2Cd"></span>
                    </div>
                  </div>
                </div>
              </div>

            </dd>
          </dl>
          <dl class="search-bar__item search-bar__item--flexible">
          </dl>
        </div>
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">시험종류</dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="form-flex">
                <div class="ui-select-box ui-form-box__width--237 form-flex__cell--5"
                  id="error_wrap_vTrTestTypeCd"
                >
                  <ap-selectbox
                    v-model:value="regParam.vTrTestTypeCd"
                    :options="codeGroupMaps['TR_MRQ011_TYPE']"
                    :input-class="['ui-select__width--full', 'form-flex__cell--5']"
                    @change="fnValidate('vTrTestTypeCd');fnDisabledPrsv();"
                  />
                  <span class="error-msg" id="error_msg_vTrTestTypeCd"></span>
                </div>
                <div class="text-des text-des__red ml-5 form-flex__cell--5">
                  * 방부처방 의뢰는 무방부 처방으로만 가능합니다. 법적 보존제/보존 물질이 포함되지 않은 처방으로 진행해 주세요.
                </div>    
              </div>
            </dd>
          </dl>
        </div>
        <div class="search-bar__row search-bar__row--modal"
          v-if="regParam.vTrTestTypeCd == 'TMT_2'"
          >
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">제조번호</dt>
            <dd class="search-bar__val search-bar__val--flexible" id="error_wrap_vCreateNo">
              <div class="form-flex">
                <ap-input
                  id="vCreateNo"
                  v-model:value="regParam.vCreateNo"
                  @input="fnValidate('vCreateNo')"
                >
                </ap-input>  
              </div>
              <span class="error-msg" id="error_msg_vCreateNo"></span>
            </dd>
          </dl>
        </div>

        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">생산 제조장</dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="ui-select-box form-flex__cell--5" id="error_wrap_vTrProductionCd">
                <ap-selectbox
                  v-model:value="regParam.vTrProductionCd"
                  input-class="ui-select__width--full"
                  :options="codeGroupMaps['MA_PLANT']"
                  @change="fnValidate('vTrProductionCd')"
                />
                <span class="error-msg" id="error_msg_vTrProductionCd"></span>

                <ap-input v-if="regParam.vTrProductionCd === 'ETC'"
                  id="vTrProductionTxt"
                  v-model:value="regParam.vTrProductionTxt"
                >
                </ap-input>   
              </div>
            </dd>
          </dl>
          <dl class="search-bar__item search-bar__item--flexible">
          </dl>
        </div>
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">제품표시</dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="form-flex">
                <div class="form-flex-cell form-flex__cell--5">
                  <div class="ui-checkbox__list">
                    <div class="ui-checkbox__inner">
                      <ap-input-check
                        v-model:model="vProdSignAll"
                        value="Y"
                        label="전체"
                        :id="'prodSign_All'"
                        @click="chkAllProdSignList"
                      >
                      </ap-input-check>
                      <ap-input-check
                        v-for="(vo, index) in codeGroupMaps['LNC12']" :key="'prodSign_' + index"
                        v-model:model="regParam.arrProdSignListCd"
                        :value="vo.vSubCode"
                        :label="vo.vSubCodenm"
                        :id="'prodSign_' + index"
                        @click="chkProdSignList"
                      >
                      </ap-input-check>
                    </div>
                  </div>
                </div>
              </div>
            </dd>
          </dl>
        </div>
        
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">무수여부</dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="form-flex">
                <div class="ui-radio__list" id="error_wrap_vTrFlagNoWater">
                  <div class="ui-radio__inner">
                    <ap-input-radio
                      v-model:model="regParam.vTrFlagNoWater"
                      value="Y"
                      label="Y (Water 미포함)"
                      id="vTrFlagNoWater_Y"
                      name="vTrFlagNoWater"
                      @click="fnValidate('vTrFlagNoWater')"
                    ></ap-input-radio>
                    <ap-input-radio
                      v-model:model="regParam.vTrFlagNoWater"
                      value="N"
                      label="N (Water 포함)"
                      id="vTrFlagNoWater_N"
                      name="vTrFlagNoWater"
                      @click="fnValidate('vTrFlagNoWater')"
                    ></ap-input-radio>
                  </div>
                  <span class="error-msg" id="error_msg_vTrFlagNoWater"></span>
                </div>
              </div>
            </dd>
          </dl>
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">무향여부</dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="form-flex">
                <div class="ui-radio__list" id="error_wrap_vTrFlagNoFragrance">
                  <div class="ui-radio__inner">
                    <ap-input-radio
                      v-model:model="regParam.vTrFlagNoFragrance"
                      value="Y"
                      label="Y"
                      id="vTrFlagNoFragrance_Y"
                      name="vTrFlagNoFragrance"
                      @click="fnValidate('vTrFlagNoFragrance')"
                    ></ap-input-radio>
                    <ap-input-radio
                      v-model:model="regParam.vTrFlagNoFragrance"
                      value="N"
                      label="N"
                      id="vTrFlagNoFragrance_N"
                      name="vTrFlagNoFragrance"
                      @click="fnValidate('vTrFlagNoFragrance')"
                    ></ap-input-radio>
                  </div>
                  <span class="error-msg" id="error_msg_vTrFlagNoFragrance"></span>
                </div>
              </div>
            </dd>
          </dl>
        </div>

        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">미용법<span class="ui-require"><span class="for-a11y">(필수)</span></span></dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="ui-select-block" id="error_wrap_vKosmetikCd">
                <ap-selectbox
                  v-model:value="regParam.vKosmetikCd"
                  :options="codeGroupMaps['LNC14']"
                  input-class="ui-select__width--full"
                >
                </ap-selectbox>
                <span class="error-msg" id="error_msg_vKosmetikCd"></span>
              </div>
            </dd>
          </dl>
          <dl class="search-bar__item search-bar__item--flexible">
            <ap-input
              v-if="regParam.vKosmetikCd === 'LNC14_99'"
              v-model:value="regParam.vKosmetikTxt"
              :inputClass="'ui-input form-flex__cell--5'"
            ></ap-input>
          </dl>
        </div>

        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">카운터</dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="search-form">
                <div class="search-result-table mt-15 verticalTable">
                  <table class="ui-table__reset ui-table__search-result text-center pop-padding">
                    <colgroup>
                      <col style="width:15%">
                      <col style="width:auto">
                    </colgroup>
                    <tbody>
                      <tr>
                        <th>내용물코드</th>
                        <td>
                          <div class="search-form__inner" :class="regParam.counterList && regParam.counterList.length > 0 ? 'mb-10' : ''">
                            <ap-input
                              :is-number="false"
                              v-model:value="counterSearchKeyword"
                              :inputClass="'ui-input ui-input__width--340'"
                            ></ap-input>
                            <button
                              type="button"
                              class="button-search"
                              @click="fnOpenCounterSearchPop"
                            >추가</button>
                          </div>
                          <div class="file-upload" v-if="regParam.counterList && regParam.counterList.length > 0">
                            <div class="file-upload__inner" style="display:block;">
                              <ul class="ui-list file-upload__lists display-block">
                                <li class="file-upload__list"
                                  v-for="(vo, idx) in regParam.counterList" :key="'counterVo_'+ idx"
                                >
                                  <span class="file-upload__name">[{{vo.vCounterCd}}] {{ vo.vCounterNm }}</span>
                                  <button type="button" class="file-upload__button--delete" @click="deleteCounterList(idx)"></button>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <th>비고</th>
                        <td>
                          <ap-text-area
                            :is-with-byte="true"
                            v-model:value="regParam.vCounterNote"
                            :maxlength="1000"
                          ></ap-text-area>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>

              </div>
            </dd>
          </dl>
        </div>
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">방부처방</dt>
            <dd class="search-bar__val search-bar__val display-block">
              <div class="ui-buttons ml-auto px-20 ui-buttons__right">
                <button type="button" class="ui-button ui-button__bg--lightgray"
                  @click="addPrsvRateRow"
                >
                  함량추가
                </button>
              </div>
              <div class="form-flex prsv-list-row">
                <div class="ui-select-box ui-form-box__width--150 form-flex__cell--5 request-status" 
                  v-for="(prsvInfo, n) in regParam.setPrsvList" :key="'Presevative_' + n"
                >
                  <ap-input 
                    :value="prsvInfo.vCode"
                    :is-number="false"
                    :input-class="['ui-input','ui-input__width--150','mb-08']"
                    :placeholder="'보존제 선택'"
                    :alt="'보존제/보존물질'"
                    :readonly="true"
                    :id="'preservText_'+ n"
                    class="prsvCodeList"
                    @click="showHidePreserveSelect(n)"
                  ></ap-input>
                  <div class="input-select preservative_pop" :class="n > 4 ? 'position_right' : ''" style="display:none;">
                    <div class="search-result-table mt-1">
                      <table class="ui-table__reset ui-table__search-result text-center pop-padding">
                        <colgroup>
                          <col style="width:50%">
                          <col style="width:50%">
                        </colgroup>
                        <thead>
                          <tr>
                            <th>법적 보존제</th>
                            <th>보존 물질</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>
                              <ul class="ul_not_add">
                                <li v-for="(vo, idx) in preserve1List" :key="'preservative1_' +idx">
                                  <ap-input-radio
                                    v-model:model="prsvInfo.vCode"
                                    :value="vo.vSubCode"
                                    :label="vo.vSubCodenm"
                                    :id="'preserv1_'+ n + '_' + idx"
                                    :name="'vPreservative'+n"
                                    @click="setPreservativeCont(n, vo.vSubCode, 'Y')"
                                  ></ap-input-radio>
                                </li>
                                <template v-if="preserve1List && maxCodeSize > preserve1List.length">
                                  <li v-for="(vo) in (maxCodeSize - preserve1List.length)" :key="'preservative1temp_' + vo">
                                    <div class="ui-radio-block">
                                      <div class="nbspArea">&nbsp;&nbsp;</div>
                                    </div>
                                  </li>
                                </template>
                              </ul>
                            </td>
                            <td>
                              <ul class="ul_not_add">
                                <li v-for="(vo, idx) in preserve2List" :key="'preservative2_' +idx">
                                  <ap-input-radio
                                    v-model:model="prsvInfo.vCode"
                                    :value="vo.vSubCode"
                                    :label="vo.vSubCodenm"
                                    :id="'preserv2_'+ n + '_' + idx"
                                    :name="'vPreservative'+n"
                                    @click="setPreservativeCont(n, vo.vSubCode, 'N')"
                                  ></ap-input-radio>
                                </li>
                                <template v-if="preserve2List && maxCodeSize > preserve2List.length">
                                  <li v-for="(vo) in (maxCodeSize - preserve2List.length)" :key="'preservative2temp_' + vo">
                                    <div class="ui-radio-block">
                                      <div class="nbspArea">&nbsp;&nbsp;</div>
                                    </div>
                                  </li>
                                </template>
                              </ul>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div class="form-flex" v-for="(rate, i) in prsvInfo.nRate" :key="'rate_' + i">
                    <div class="ui-select-box ui-form-box__width--150 form-flex__cell--5">
                      <ap-input 
                        v-model:value="prsvInfo.nRate[i]"
                        :is-number="true"
                        :point="9"
                        :input-class="'ui-input ui-input__width--150'"
                        :placeholder="'함량입력'"
                      ></ap-input>
                    </div>
                  </div>
                </div>
              </div>
            </dd>
          </dl>
        </div>
        <div class="search-bar__row search-bar__row--modal"
          v-if="showHideChangeReason()"
        >
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">처방 변경사유<span class="ui-require"><span class="for-a11y">(필수)</span></span></dt>
            <dd class="search-bar__val search-bar__val--flexible" id="error_wrap_vFeature">
              <ap-input 
                :is-number="false"
                v-model:value="regParam.vFeature"
                :inputClass="'ui-input ui-input__width--full'"
                @input="fnValidate('vFeature')"
              ></ap-input>
              <span class="error-msg" id="error_msg_vFeature"></span>
            </dd>
          </dl>
        </div>
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100 mt-m3">메시지</dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="ui-textarea-box ui-textarea-box__height--100">
                <ap-text-area
                  :is-with-byte="true"
                  v-model:value="regParam.vTrComment"
                  :maxlength="2000"
                ></ap-text-area>
              </div>
            </dd>
          </dl>
        </div>
        <div class="search-bar__row search-bar__row--modal pt-40">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100 mt-m3">처방 메시지</dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="ui-textarea-box ui-textarea-box__height--140">
                <ap-text-area
                  :is-with-byte="true"
                  v-model:value="regParam.vTrComment2"
                  :maxlength="2000"
                ></ap-text-area>
              </div>
            </dd>
          </dl>
        </div>
      </div>
      <div class="board-bottom pt-20">
        <div class="board-bottom__inner">
          <div class="ui-buttons ml-auto ui-buttons__right">
            <button
              v-if="regParam.vTrTestTypeCd === 'TMT_1'"
              type="button"
              class="ui-button ui-button__bg--skyblue font-weight__300"
              @click="fnPrsvSave"
            >방부시험의뢰</button>
            <button
              v-else
              type="button"
              class="ui-button ui-button__bg--skyblue font-weight__300"
              @click="fnSave"
            >시험의뢰</button>
            <button
              type="button"
              class="ui-button ui-button__bg--lightgray"
              @click="closeAsyncPopup"
            >닫기</button>
          </div>
        </div>
      </div>
    </div>
    <teleport to="#common-modal-sub" v-if="popContent">
      <ap-popup>
        <component
          :is="popContent"
          :pop-params="popupParams"
          @selectFunc="popSelectFunc"
          @closeFunc="closeFunc"
        />
      </ap-popup>
    </teleport>
  </div>
  <div id="common-modal-sub"></div>
</template>

<script>
import { ref, inject, defineAsyncComponent, reactive, getCurrentInstance, onUpdated } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useActions } from 'vuex-composition-helpers'
import { useTestReqCommon } from '@/compositions/labcommon/useTestReqCommon'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useStore } from 'vuex'
import { useRoute } from 'vue-router'

export default {
  name: 'AllTestReqPreservativePop',
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    ParentProductSearchPop: defineAsyncComponent(() => import('@/components/labcommon/popup/ParentProductSearchPop.vue')),
    TestReqMrq011MailPop: defineAsyncComponent(() => import('@/components/labcommon/popup/TestReqMrq011MailPop.vue')),
  },
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: ''
        , vContPkCd: ''
        , nVersion: ''
        , vLotCd: ''
        , vPlantCd: ''
        , vMrqTypeCd: ''
        }
      }
    }
  },
  emits: ['selectFunc'],
  setup(props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { openAsyncConfirm, openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncConfirm', 'openAsyncAlert', 'closeAsyncPopup'])
    const store = useStore()
    const route = useRoute()
    const maxCodeSize = ref()
    const preserve1List = ref(null)
    const preserve2List = ref(null)
    const app = getCurrentInstance();
    const tiumUrl = app.appContext.config.globalProperties.tiumUrl
    const flagLotCompleYn = ref('')

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const { 
      selectPrdTestReqPreservativeInfo,
      selectTestReqLotList,
      noteType,
      selectLabNotePrsvList,
      insertPrdTestPreservativeInfo,
      sendLabNotePrdMrq011Mail
    } = useTestReqCommon()

    const {
      tddProdType1List,
      tddProdType2List,
      selectTddProdTypeList,
    } = useLabCommon()

    const searchParams = ref({
      vLabNoteCd: props.popParams.vLabNoteCd,
      vOtherContPkCd: props.popParams.vContPkCd,
      nVersion: props.popParams.nVersion,
      vLotCd: props.popParams.vLotCd,
      vPlantCd: props.popParams.vPlantCd,
      vMrqTypeCd: props.popParams.vMrqTypeCd,
      vGateCd: props.popParams.vGateCd,
    })

    const resData = ref(null)
    const chkAll = ref('N')

    const counterSearchKeyword = ref('')
    const popContent = ref(null)
    const popSelectFunc = ref(null)
    const closeFunc = ref(null)
    const popupParams = ref({})
    let colSize = 7
    let rowSize = 5
    let maxRowSize = 0
    const vProdSignAll = ref('')
    const loadComment2 = ref('')

    const regParam = ref({
      vLabNoteCd : route.query.vLabNoteCd || '',
      nVersion : props.popParams.nVersion,
      vMrqTypeCd: props.popParams.vMrqTypeCd,
      vContPkCd : props.popParams.vContPkCd,
      vGateCd: props.popParams.vGateCd,
      vRepContPkCd: '',
      vTrCompleteReqDt: '', // 완료 요청일
      vDosageFormCd: '',  // 제형
      vTestType: '',  // 점도
      vTestTypeNm: '',
      vTestValue: '',
      vTrPh: '',  // pH
      vTrFlagNoFragrance: '', // 무향
      vTrComment: '', // 메시지
      vTrPrdCd: '',
      vTddProdType1Cd: '',
      vTddProdType2Cd: '',
      vContainerCd : '',
      vContainerEtc : '',
      vTrPilotDt : '',
      vTrTestTypeCd : '',
      vCreateNo : '',
      vTrProductionCd : '',
      vTrProductionTxt : '',
      arrProdSignListCd : [],
      vTrFlagNoWater : '',
      vKosmetikCd : '',
      vKosmetikTxt : '',
      vFeature : '',
      vCounterNote: '',
      vTrComment2 : '',
      arrContPkCd : [],
      contList : [],
      setPrsvList : [],    //방부 처방
      dataPrsvList : [],    //방부 처방 - 공백 제거
      vLand1 : 'UN',
      counterList : [],
      vFlagModifyComment2 : ''
    })

    const init = async () => {
      await findCodeList(['TR_MRQ011_TYPE','TR_MRQ011_PRESERVATIVE'
        ,'MA_PLANT', 'LNC12', 'LNC14', 'LNC26', 'DOSAGE_FORM'])

      resData.value = await selectPrdTestReqPreservativeInfo(searchParams.value)
      
      selectTddProdTypeList({vNoteType: store.getters.getNoteType()}, 'TYPE1')

      const vTddProdType1Cd = resData.value.noteVo.vTddProdType1Cd
      if(commonUtils.isNotEmpty(vTddProdType1Cd)){
        selectTddProdTypeList({vClassCd: vTddProdType1Cd, vFlagSub: 'Y'}, 'TYPE2')
      }else{
        selectTddProdTypeList({vClassCd: '', vFlagSub: 'Y'}, 'TYPE2')
      }

      const prev1List = commonUtils.getCodeList(codeGroupMaps, 'TR_MRQ011_PRESERVATIVE', 'TYPE1', null, null)
      preserve1List.value = prev1List.map(item => {
          return {
            ...item,
            vSubCode: item.vSubCode + '(PRSV)'  //법적 보존제는 (PRSV) 붙여서 표기
          }
      })

      preserve2List.value = commonUtils.getCodeList(codeGroupMaps, 'TR_MRQ011_PRESERVATIVE', 'TYPE2', null, null)

      const arrCodeSize = [
        preserve1List.value ? preserve1List.value.length : 0,
        preserve2List.value ? preserve2List.value.length : 0
      ];

      maxCodeSize.value = Math.max(...arrCodeSize)  

      setInitValue(resData.value)
    }

    const setInitValue = (result) => {

      result.contList.forEach(item => {
        if(item.subList && item.subList.length > 0){
          item.isChecked = 'Y'
          regParam.value.arrContPkCd.push(item.vContPkCd)
        }else{
          item.isChecked = 'N'
        }
        item.nVersion = props.popParams.nVersion
        item.vLotCd = ''
      })

      const chkLen = result.contList.filter(vo => vo.isChecked == 'Y').length
      chkAll.value = result.contList.length == chkLen ? 'Y' : 'N'

      if(chkLen > 0){
        regParam.value.vRepContPkCd = result.contList.filter(vo => vo.vFlagRepresent === 'Y')[0].vContPkCd
      }

      regParam.value.contList = result.contList
      regParam.value.vDosageFormCd = result.lastTrVo.vDosageFormCd
      regParam.value.vContainerCd = result.lastTrVo.vContainerCd
      regParam.value.vTrPilotDt = result.noteVo.vPilotDt
      regParam.value.vContainerEtc = result.lastTrVo.vContainerEtc
      regParam.value.vTddProdType1Cd = result.lastTrVo.vTddProdType1Cd
      regParam.value.vTddProdType2Cd = result.lastTrVo.vTddProdType2Cd
      regParam.value.vTrTestTypeCd = result.lastTrVo.vM011TestTypeCd
      regParam.value.vCreateNo = result.lastTrVo.vCreateNo
      regParam.value.vTrProductionCd = result.lastTrVo.vM011ProductionCd
      regParam.value.vTrProductionTxt = result.lastTrVo.vM011ProductionTxt
      regParam.value.arrProdSignListCd = result.lastTrVo.arrProdSignListCd
      regParam.value.vTrFlagNoWater = result.lastTrVo.vM011FlagNoWater
      regParam.value.vTrFlagNoFragrance = result.lastTrVo.vM011FlagNoFragrance
      regParam.value.vKosmetikCd = result.lastTrVo.vKosmetikCd
      regParam.value.vCounterNote = result.lastTrVo.vCounterNote
      regParam.value.vTrComment2 = result.vTrComment2
      loadComment2.value = result.vTrComment2
      
      regParam.value.counterList = result.counterList

      if(!regParam.value.counterList){
        regParam.value.counterList = {
          vProductCd : '',
          nVersion : '',
          nSeq : '',
          vCounterCd : result.counterVo.vCounterContCd,
          vCounterNm : result.counterVo.vCounterContNm,
          vWerks : result.counterVo.vWerks,
          vType : 'NOTE'
        }
      }

      setPrsvInitList()
    }

    const setPrsvInitList = () => {
      for(let i = 0; i < colSize; i++){
        const copyNRate = ref([])
        for(let j = 0; j < rowSize; j++){
          copyNRate.value.push('')
        }
        regParam.value.setPrsvList.push({vCode: '', nRate: copyNRate.value})
      }
    }

    init()

    onUpdated(() => {
      const prsvCodeList = document.querySelectorAll(".prsvCodeList")
      if(regParam.value.vTrTestTypeCd == 'TMT_1'){  //시험종류 : 방부처방 일 경우, vCode disabled
        prsvCodeList.forEach(item => {
          item.disabled = true
        })
      }
    })

    const showHidePreserveSelect = (idx) => {
      const inputSelectAll = document.querySelectorAll(".input-select")
      const currInputSelect = inputSelectAll[idx]

      if(currInputSelect.style.display === 'none'){
        inputSelectAll.forEach(item => {
          item.style.display = 'none'
        })
        currInputSelect.style.display = 'block'
      }else{
        currInputSelect.style.display = 'none'
      }
    }

    const setPreservativeCont = (idx, subCode) => {
      const target = document.querySelector("#preservText_" + idx)

      if(subCode.indexOf('ETC') > -1){
        target.readOnly = false
        target.focus()
        regParam.value.setPrsvList[idx].vCode = ''
      }else{
        target.readOnly = true
        regParam.value.setPrsvList[idx].vCode = subCode
      }

      const inputSelectAll = document.querySelectorAll(".input-select")
      const currInputSelect = inputSelectAll[idx]
      currInputSelect.style.display = 'none'
    }

    const fnCheckAll = (value) => {
      
      if (value === 'Y') {
        regParam.value.arrContPkCd = resData.value.contList.map(cvo => cvo.vContPkCd)
        resData.value.contList.forEach((item, idx) => {
          item.isChecked = 'Y'
        })
        regParam.value.vRepContPkCd = resData.value.contList.filter(vo => vo.vFlagRepresent === 'Y')[0].vContPkCd
      } else {
        regParam.value.arrContPkCd = []
        resData.value.contList.forEach(item => {
          item.isChecked = 'N'
        })
        regParam.value.vRepContPkCd = ''
      }
    }

    const fnAddTestReqTarget = (vContPkCd, idx, cvo) => {
      if (vContPkCd) {  // 시험 의뢰 대상 체크했을 때
        if(regParam.value.arrContPkCd.filter(vo => vo === vContPkCd).length == 0){
          regParam.value.arrContPkCd.push(vContPkCd)
        }
        cvo.isChecked = 'Y'

        if (regParam.value.arrContPkCd.length === resData.value.contList.length) {
          chkAll.value = 'Y'
          regParam.value.vRepContPkCd = resData.value.contList.filter(vo => vo.vFlagRepresent === 'Y')[0].vContPkCd
        }

      } else { // 시험 의뢰 대상 체크 해제했을 때
        cvo.isChecked = 'N'

        if (regParam.value.arrContPkCd.length !== resData.value.contList.length) {
          chkAll.value = 'N'
          regParam.value.vRepContPkCd = ''
        }
      }
    }

    const fnChangeVersion = async (value, vo) => {
      vo.vLotCd = ''

      if (commonUtils.isEmpty(value)) {
        vo.subList = []
      } else {
        const payload = {
          vContPkCd: vo.vContPkCd,
          nVersion: value,
        }
  
        const result = await selectTestReqLotList(payload)
  
        if (result) {
          vo.subList = result

          vo.subList.forEach((item, idx) => {
            if(idx == 0){
              regParam.value.vTrFlagNoFragrance = item.vFlagNoFragrance
            }
          })
        }
      }
    }

    const fnSelectOption = async (value, vo, idx) => {
      const lvo = vo.subList.find(svo => svo.vLotCd === value)
      regParam.value.setPrsvList = []    //초기화

      const vTrTestTypeCd = regParam.value.vTrTestTypeCd
      //시험종류가 방부처방이 아닌 경우에만 방부처방 목록 가져오기
      if(value && vTrTestTypeCd != 'TMT_1'){
        const payload = {
          vContPkCd: vo.vContPkCd,
          nVersion: lvo.nVersion,
          vLotCd : value, 
          vPlantCd : vo.vPlantCd,
          vTestTypecd : resData.value.lastTrVo.vM011TestTypeCd, //TMT_1, TMT_2 
          vLand1 : 'UN',
        }

        const prsvList = await selectLabNotePrsvList(payload)
        if(prsvList){
          const arrPrsvSize = ref([rowSize])
          prsvList.some(item => {
            if(regParam.value.setPrsvList.filter(vo => vo.vCode === item.vCode).length > 0){
              return false
            }
            const obj = {
              vCode : '', 
              nRate : []
            }
            
            obj.vCode = item.vCode
            
            const makeList = ref([])
            const filterList = prsvList.filter(vo => vo.vCode === item.vCode)
            filterList.forEach(item => {
              makeList.value.push(item.nRate)
            })
            
            obj.nRate = [ ...makeList.value]
            arrPrsvSize.value.push(makeList.value.length)
            
            regParam.value.setPrsvList.push(obj)
          })
          
          maxRowSize = Math.max(...arrPrsvSize.value)
        }

        if(colSize > regParam.value.setPrsvList.length){
          
          if(regParam.value.setPrsvList){
            //기존 방부 list 에서 nRate를 maxRowSize 까지 값 추가
            regParam.value.setPrsvList.forEach(item => {
              const chargeLen = maxRowSize - item.nRate.length
              for(let c = 0; c < chargeLen; c++){
                item.nRate.push('')
              }
            })
          }
          
          for(let i = 0; i < colSize; i++){
            //colSize 까지 나머지 값 빈값으로 추가하기
            if(i >= regParam.value.setPrsvList.length){
              const copyNRate = ref([])
              for(let j = 0; j < maxRowSize; j++){
                copyNRate.value.push('')
              }
              regParam.value.setPrsvList.push({vCode: '', nRate: copyNRate.value})
            }
          }
        }
      }
      else{ //lot 선택 값이 없을 경우
        setPrsvInitList()
      }

      if(lvo){
        regParam.value.vTestType = lvo.vTestType
        regParam.value.vTestTypeNm = lvo.vTestTypeNm
        regParam.value.vTestValue = lvo.vTestValue
        regParam.value.vTrPh = lvo.vPh
        flagLotCompleYn.value = lvo.vFlagComplete
        vo.vLotNm = lvo.vLotNm
      }else{
        regParam.value.vTestType = ''
        regParam.value.vTestTypeNm = ''
        regParam.value.vTestValue = ''
        regParam.value.vTrPh = ''
        flagLotCompleYn.value = ''
        vo.vLotNm = ''
      }
    }
    
    const deleteCounterList = (idx) => {
      regParam.value.counterList.splice(idx, 1)
    }

    const fnOpenCounterSearchPop = () => {
      popupParams.value = {
        vKeyword: counterSearchKeyword.value,
        vTypecd: 'NOTE',
        vSelectType : 'SINGLE',
        vFlagCounterPop : 'Y'
      }

      closeFunc.value = closeCounterPop
      popSelectFunc.value = settingCounterList
      popContent.value = 'ParentProductSearchPop'
    }

    const closeCounterPop = () => {
      popContent.value = null
    }

    const settingCounterList = (vo) => {
      
      closeCounterPop()

      const haveCnt = regParam.value.counterList.filter(cvo => cvo.vCounterCd === vo.vContCd).length
      if(haveCnt > 0){
        openAsyncAlert({ message: '이미 추가된 내용물 입니다.'})
        return
      }

      const obj = {
        vProductCd : '',
        nVersion : vo.nNoteVersion,
        nSeq : '',
        vCounterCd : vo.vContCd,
        vCounterNm : vo.vContNm,
        vWerks : vo.vInnerPlant,
        vType : vo.vType
      }
      regParam.value.counterList.push(obj)
    }

    //함량 추가
    const addPrsvRateRow = () => {
      regParam.value.setPrsvList.forEach(item => {
        item.nRate.push('')
      })
    }

    const showHideChangeReason = () =>{
      const prdLen = resData.value?.contList.length
      if(commonUtils.isEmpty(resData.value?.mrq011CheckSapCd) || prdLen > 1){
        return false
      }
      else{
        const contCd = resData.value.contList.filter(vo => vo.vContPkCd === regParam.value.vRepContPkCd)[0].vContCd
        if(resData.value?.mrq011CheckSapCd.indexOf(contCd) > -1){
          return true
        }else{
          return false
        }
      }
    }

    const chkProdSignList = () => {

      const prodSignList = regParam.value.arrProdSignListCd
      if(prodSignList.length == codeGroupMaps.value['LNC12'].length){
        vProdSignAll.value = 'Y'
      }else{
        vProdSignAll.value = 'N'
      }

    }

    const chkAllProdSignList = (value) => {
      if(value === 'Y'){
        codeGroupMaps.value['LNC12'].forEach(item => {
          regParam.value.arrProdSignListCd.push(item.vSubCode)
        })
      }else{
        regParam.value.arrProdSignListCd = []
      }
    }

    const isValidateMrq011 = () => {
      let isOk = true
      const arrChkKey = ['vTrPh', 'vContainerCd', 'vKosmetikCd']

      commonUtils.hideErrorMessageAll(arrChkKey)

      for(const chkKey of arrChkKey){
        if(!fnValidate(chkKey)){
          isOk = false
        }
      }

      return isOk
    }

    const fnValidate = (key) => {
      let isOk = true
      let errorMsg = '필수 입력 사항입니다.'
      commonUtils.hideErrorMessage(key)

      const chkContList = resData.value.contList.filter(vo => vo.isChecked === 'Y')
      if(key === 'vRepContPkCd'){
        if(commonUtils.isEmpty(regParam.value.vRepContPkCd)){
          errorMsg = '대표 내용물을 선택해 주세요.'
          isOk = false
        }
      }
      else if(key === 'vCreateNo'){
        if(regParam.value.vTrTestTypeCd === 'TMT_2'){
          if(commonUtils.isEmpty(regParam.value.vCreateNo)){
            errorMsg = '필수 입력 사항입니다.'
            isOk = false
          }
        }
      }
      else if(key === 'vFeature'){
        if(showHideChangeReason()){
          if(commonUtils.isEmpty(regParam.value.vFeature)){
            errorMsg = '필수 입력 사항입니다.'
            isOk = false
          }
        }
      }
      else if(commonUtils.isEmpty(regParam.value[key])){
        errorMsg = '필수 입력 사항입니다.'
        isOk = false
      }
      
      if(!isOk){
        commonUtils.showErrorMessage(key, errorMsg)
      }

      return isOk
    }

    const fnValidateAll = () => {
      let isOk = true
      const arrChkKey = ['vRepContPkCd', 'vTrCompleteReqDt', 'vTrPilotDt', 'vContainerCd',
          'vTddProdType1Cd', 'vTddProdType2Cd', 'vTrTestTypeCd',
          'vCreateNo', 'vTrProductionCd', 'vTrFlagNoWater', 'vTrFlagNoFragrance', 'vFeature'  
        ]

      commonUtils.hideErrorMessageAll(arrChkKey)

      for (const chkKey of arrChkKey) {
        if (!fnValidate(chkKey)) {
          isOk = false
        }
      }

      return isOk
    }

    const fnSave = async () => {

      if(!fnValidateAll()){
        await openAsyncAlert({ message: '필수 입력사항을 확인해 주세요.' })
        window.scrollTo(0, 0)
        return
      }

      const chkContList = resData.value.contList.filter(vo => vo.isChecked === 'Y')
      if(!chkContList || chkContList.length == 0){
        await openAsyncAlert({ message: '시험의뢰할 대상을 선택해 주세요.' })
        return
      }

      if(chkContList && chkContList.length > 0){
        const chkLotCd = chkContList.filter(vo => vo.vLotCd === '')
        if(chkLotCd.length > 0){
          await openAsyncAlert({ message: 'Lot를 선택해 주세요.' })
          return
        }
      }

      //처방 메시지 : 처음 로딩 값과 다르면 수정이 일어난 것으로 봄
      if(commonUtils.isNotEmpty(regParam.value.vTrComment2)
          && regParam.value.vTrComment2 != loadComment2.value
      ){
        regParam.value.vFlagModifyComment2 = 'Y'
      }

      regParam.value.dataPrsvList = regParam.value.setPrsvList.map(item => {
        if(commonUtils.isNotEmpty(item.vCode)){
          return {
            ...item
          }
        }
      })

      if(flagLotCompleYn.value !== "Y"){
        const confirmMessage = '<span style="font-weight:bold; color:red;">시험의뢰시 해당 Lot은 더이상 수정 할 수 없습니다.</span><br/>저장 하시겠습니까?'
        if (!await openAsyncConfirm({ message: confirmMessage })) {
          return
        }
      }

      regParam.value.dataPrsvList = regParam.value.dataPrsvList.filter(vo => vo != undefined)
      regParam.value.contList = chkContList

      const result = await insertPrdTestPreservativeInfo(regParam.value)

      if(result){
        let msg = "";
				if (result.vProductCd != undefined) {
					msg = `대표 내용물 코드 : ${result.vSapCd || ''}<br/>
            Lot : ${result.vLot}<br/>
            의뢰번호 : <span style='color:blue;text-weight:bold;'>${result.vDocNo}</span><br/><br/>
					  위 내용으로 정상적으로 의뢰 되었습니다.`
				}
				else {
					msg = "정상적으로 의뢰 되었습니다.";
				}

        const answer = await openAsyncAlert({ message:msg })
        if(!answer){
          return 
        }

        let urlInfo = tiumUrl + "/zm/bb/tr/zm_bb_tr_product_view.do"
        const targetUrl = urlInfo + "?i_sProductCd=" + result.vProductCd + "&i_iVersion=" + result.nVersion
       
        //새창
        window.open(targetUrl, "_blank")

        window.location.reload(true)
      }
    }
    
    const fnDisabledPrsv = async () => {

      regParam.value.setPrsvList = []
      const prsvCodeList = document.querySelectorAll(".prsvCodeList")

      if(regParam.value.vTrTestTypeCd == 'TMT_1'){  //시험종류 : 방부처방 일 경우, setPrsvList 초기화, disabled
        setPrsvInitList()
        prsvCodeList.forEach(item => {
          item.disabled = true
        })
      }else{
        prsvCodeList.forEach(item => {
          item.disabled = false
        })

        const repContVo = resData.value.contList.filter(vo => vo.vContPkCd == regParam.value.vRepContPkCd)[0]
        const payload = {
          vContPkCd: repContVo.vContPkCd,
          nVersion: repContVo.nVersion,
          vLotCd : repContVo.vLotCd, 
          vPlantCd : repContVo.vPlantCd,
          vTestTypecd : regParam.value.vTrTestTypeCd, //TMT_1, TMT_2 
          vLand1 : 'UN',
        }

        const prsvList = await selectLabNotePrsvList(payload)

        if(prsvList){
          const arrPrsvSize = ref([rowSize])
          prsvList.some(item => {
            if(regParam.value.setPrsvList.filter(vo => vo.vCode === item.vCode).length > 0){
              return false
            }
            const obj = {
              vCode : '', 
              nRate : []
            }
            
            obj.vCode = item.vCode
            
            const makeList = ref([])
            const filterList = prsvList.filter(vo => vo.vCode === item.vCode)
            filterList.forEach(item => {
              makeList.value.push(item.nRate)
            })
            
            obj.nRate = [ ...makeList.value]
            arrPrsvSize.value.push(makeList.value.length)
            
            regParam.value.setPrsvList.push(obj)
          })
          
          maxRowSize = Math.max(...arrPrsvSize.value)
        }
        else{
          setPrsvInitList()
        }

        if(colSize > regParam.value.setPrsvList.length){
          
          if(regParam.value.setPrsvList){
            //기존 방부 list 에서 nRate를 maxRowSize 까지 값 추가
            regParam.value.setPrsvList.forEach(item => {
              const chargeLen = maxRowSize - item.nRate.length
              for(let c = 0; c < chargeLen; c++){
                item.nRate.push('')
              }
            })
          }
          
          for(let i = 0; i < colSize; i++){
            //colSize 까지 나머지 값 빈값으로 추가하기
            if(i >= regParam.value.setPrsvList.length){
              const copyNRate = ref([])
              for(let j = 0; j < maxRowSize; j++){
                copyNRate.value.push('')
              }
              regParam.value.setPrsvList.push({vCode: '', nRate: copyNRate.value})
            }
          }
        }
      }
    }

    const fnPrsvSave = async () => {
      if(!fnValidateAll()){
        await openAsyncAlert({ message: '필수 입력사항을 확인해 주세요.' })
        window.scrollTo(0, 0)
        return
      }
      
      const chkContList = resData.value.contList.filter(vo => vo.isChecked === 'Y')
      if(!chkContList || chkContList.length == 0){
        await openAsyncAlert({ message: '시험의뢰할 대상을 선택해 주세요.' })
        return
      }

      if(chkContList && chkContList.length > 0){
        const chkLotCd = chkContList.filter(vo => vo.vLotCd === '')
        if(chkLotCd.length > 0){
          await openAsyncAlert({ message: 'Lot를 선택해 주세요.' })
          return
        }
      }

      //처방 메시지 : 처음 로딩 값과 다르면 수정이 일어난 것으로 봄
      if(commonUtils.isNotEmpty(regParam.value.vTrComment2)
      && regParam.value.vTrComment2 != loadComment2.value
      ){
        regParam.value.vFlagModifyComment2 = 'Y'
      }
      
      const prsvCodeList = document.querySelectorAll(".prsvCodeList")
      const codeList = ref([])
      prsvCodeList.forEach(item => {
        codeList.value.push(item.value)
      })

      const codeLen = codeList.value.filter(vo => commonUtils.isNotEmpty(vo)).length
      if(codeLen > 0){
        const message = "방부 처방의뢰는 무방부 처방으로만 가능합니다.<br/>법적 보존제/보존 물질이 포함되지 않은 처방으로 진행해주세요."
        if (!await openAsyncConfirm({ message })) {
          return
        }
      }

      const counterList = regParam.value.counterList
      if(!counterList || counterList.length == 0){
        await openAsyncAlert({ message: '카운터 처방을 등록하지 않으셨습니다. 확인부탁드립니다.' })
      }

      regParam.value.contList = chkContList

      fnMailSendPop()
    }

    const fnMailSendPop = async () => {
      if(!isValidateMrq011()){
        await openAsyncAlert({ message: '필수 입력사항을 확인해 주세요.' })
        window.scrollTo(0, 0)
        return
      }

      if(flagLotCompleYn.value !== "Y"){
        const confirmMessage = '<span style="font-weight:bold; color:red;">시험의뢰시 해당 Lot은 더이상 수정 할 수 없습니다.</span><br/>저장 하시겠습니까?'
        if (!await openAsyncConfirm({ message: confirmMessage })) {
          return
        }
      }

      const repContVo = resData.value.contList.filter(vo => vo.vContPkCd == regParam.value.vRepContPkCd)[0]
      
      popupParams.value = {
        vLabNoteCd : props.popParams.vLabNoteCd,
        vContPkCd: repContVo.vContPkCd,
        nVersion: repContVo.nVersion,
        vLotCd : repContVo.vLotCd, 
        vPlantCd : repContVo.vPlantCd,
        vLand1 : 'UN'
      }

      closeFunc.value = closeCounterPop
      popSelectFunc.value = fnMrq011MailSend
      popContent.value = 'TestReqMrq011MailPop'
    }

    const fnMrq011MailSend = async (vo) => {
      
      closeCounterPop()

      const result = await insertPrdTestPreservativeInfo(regParam.value)
      
      if(result){
        const mailParam = {
          ...vo, ...{
            vProductCd: result.vProductCd,
            nVersion: result.nVersion,
            vTrComment2: regParam.value.vTrComment2,
            vFlagModifyComment2: regParam.value.vFlagModifyComment2,
          }
        }

        await sendLabNotePrdMrq011Mail(mailParam)

        let msg = "";
				if (result.vProductCd != undefined) {
					msg = `대표 내용물 코드 : ${result.vSapCd || ''}<br/>
            Lot : ${result.vLot}<br/>
            의뢰번호 : <span style='color:blue;text-weight:bold;'>${result.vDocNo}</span><br/><br/>
					  위 내용으로 정상적으로 의뢰 되었습니다.`
				}
				else {
					msg = "정상적으로 의뢰 되었습니다.";
				}

        const answer = await openAsyncAlert({ message:msg })
        if(!answer){
          return 
        }

        let urlInfo = tiumUrl + "/zm/bb/tr/zm_bb_tr_product_view.do"
        const targetUrl = urlInfo + "?i_sProductCd=" + result.vProductCd + "&i_iVersion=" + result.nVersion
       
        //새창
        window.open(targetUrl, "_blank")
        
        window.location.reload(true)
      }
    }

    const getTddProdType2List = (tddProdType1Cd) => {
      regParam.value.vTddProdType2Cd = ''
      selectTddProdTypeList({vClassCd: tddProdType1Cd, vFlagSub: 'Y'}, 'TYPE2')
    }
    
    return {
      t,
      codeGroupMaps,
      closeAsyncPopup,
      selectPrdTestReqPreservativeInfo,
      resData,
      regParam,
      counterSearchKeyword,
      popContent,
      popSelectFunc,
      closeFunc,
      popupParams,
      noteType,
      tddProdType1List,
      tddProdType2List,
      selectTddProdTypeList,
      maxCodeSize,
      preserve1List,
      preserve2List,
      showHidePreserveSelect,
      setPreservativeCont,
      chkAll,
      fnCheckAll,
      fnAddTestReqTarget,
      fnSelectOption,
      fnChangeVersion,
      commonUtils,
      setInitValue,
      deleteCounterList,
      fnOpenCounterSearchPop,
      settingCounterList,
      colSize,
      maxRowSize,
      addPrsvRateRow,
      showHideChangeReason,
      setPrsvInitList,
      flagLotCompleYn,
      fnValidate,
      fnValidateAll,
      fnSave,
      fnPrsvSave,
      isValidateMrq011,
      chkProdSignList,
      chkAllProdSignList,
      vProdSignAll,
      loadComment2,
      fnDisabledPrsv,
      fnMailSendPop,
      fnMrq011MailSend,
      sendLabNotePrdMrq011Mail,
      getTddProdType2List,
    }
  }
}
</script>