<template>
  <div class="modal-content modal-content__width--122">
    <div class="modal-header modal-header__mb--10">
      <div class="modal-title">BOM 임시전송</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({ message: '' })"></button>
    </div>
    <div class="modal-body">
      <div class="contents-tab ap_contents_tab">
        <div class="contents-tab__inner">
          <ApTab mst-id="bookmark-search-pop" :tab-list="info.tabList" @click="getSelectedTabEvent"
            :default-tab="info.defaultTab">
          </ApTab>
          <div class="contents-tab__body" :id="info.defaultTab">
            <div class="myboard-table">
              <div class="myboard-table__inner">
                <table class="ui-table ui-table__th--border-radius--0 ui-table__td--40 text-center">
                  <colgroup>
                    <col style="width:5%">
                    <col style="width:10%">
                    <col style="width:auto">
                    <col style="width:15%">
                    <col style="width:17%">
                  </colgroup>
                  <thead>
                    <tr>
                      <th>
                        <ap-input-check id="allChk" name="allChk" v-model:model="allChk.val" value="Y" false-value="N"
                          @click="onAllChk" />
                      </th>
                      <th>내용물코드</th>
                      <th>내용물명</th>
                      <th>Plant</th>
                      <th>LOT</th>
                    </tr>
                  </thead>
                  <tbody>
                    <template v-for="(cont, index) in info.contList" :key="index">
                      <tr v-if="cont.vCodeType !== 'AEROSOL'">
                        <td>
                          <ap-input-check :id="'chk' + index" name="chk" v-model:model="cont.chk"
                            :disabled="!cont.lotList || cont.lotList.length === 0" value="Y" false-value="N" />
                        </td>
                        <td>{{ cont.vContCd }}</td>
                        <td class="tit">{{ cont.vContNm }}</td>
                        <td>[{{ cont.vPlantCd }}] {{ cont.vPlantNm }}</td>
                        <td>
                          <ap-selectbox v-model:value="cont.vLotCd" codeKey="vLotCd" codeNmKey="vLotNm" :disabled="true"
                            :options="cont.lotList" />
                        </td>
                      </tr>
                    </template>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="board-bottom">
        <div class="board-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--skyblue" @click="onView">선택</button>
            <button type="button" class="ui-button ui-button__bg--lightgray"
              @click="closeAsyncPopup({ message: '닫기' })">닫기</button>
          </div>
        </div>
      </div>

      <template v-if="shelfInfo.isShow">
        <div class="modal-sub-title">SHELF LIFE 등록</div>
        <div class="modal-sub-title__right" style="text-align: left;">
          <template v-if="shelfInfo.vFlagMsg === 'Y'">
            <span style="color: blue; font-weight: bold;">*BOM 전송을 누르시면 SAP(ZQM20050)에 사용기한이 전송됩니다.</span><br />
            <span style="color: blue; font-weight: bold;">*이는 QMS, TDD와 연동되며 이후 수정 시 결재가 필요합니다.</span>
          </template>
          <template v-else>
            <span style="color: blue; font-weight: bold;">*이미 사용기한이 등록되어 있는 내용물코드입니다.</span><br />
            <span style="color: blue; font-weight: bold;">*변경을 원하시면 사용기한 관리 게시판을 이용해주세요.</span>
          </template>
        </div>
        <div class="myboard-table">
          <div class="myboard-table__inner">
            <table class="ui-table__reset ui-table__ver">
              <colgroup>
                <col style="width:10%">
                <col style="width:auto">
              </colgroup>
              <tbody>
                <tr>
                  <th>SHELF LIFE</th>
                  <td class="tit">
                    <template v-for="(shelf, sIdx) in shelfInfo.shelfLifeList" :key="sIdx">
                      {{ shelf.vContCd }} :
                      <span v-if="shelf.vFlagLife === 'Y'">{{ shelf.vShelfLife }}M</span>
                      <ap-selectbox v-else v-model:value="shelf.vShelfLife" :options="useBydateList"
                        @change="onShelfChange(shelf)" />
                      <ap-input v-if="shelf.vIsEtc" v-model:value="shelf.vEtcDate" :isNumber="true"
                        class="ui-input__width--124" />
                      <br />
                    </template>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <br />

        <div class="modal-sub-title">BOM 정보</div>
        <ApTab mst-id="bookmark-search-pop" :tab-list="chkContList" @click="getSelectedTabEvent">
        </ApTab>
        <div class="myboard-table" :id="searchParams.vContPkCd">
          <div class="myboard-table__inner">
            <table class="ui-table__reset ui-table__ver">
              <colgroup>
                <col style="width:10%">
                <col style="width:auto">
              </colgroup>
              <tbody>
                <tr>
                  <th>내용물명</th>
                  <td class="tit">{{ mateRateList?.[0]?.vContNm }}</td>
                </tr>
                <tr>
                  <th>연구원</th>
                  <td class="tit">{{ mateRateList?.[0]?.vUsernm }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <br />

        <div class="myboard-table">
          <div class="myboard-table__inner">
            <table class="ui-table ui-table__th--border-radius--0 ui-table__td--40 text-center">
              <colgroup>
                <col style="width:10%">
                <col style="width:auto">
                <col style="width:15%">
              </colgroup>
              <thead>
                <tr>
                  <th rowspan="2">원료코드</th>
                  <th rowspan="2">원료명</th>
                  <th>{{ mateRateList?.[0]?.vLotNm }}</th>
                </tr>
                <tr>
                  <th>함량</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(mr, mrIds) in mateRateList" :key="mrIds">
                  <td>{{ mr.vMateCd }}</td>
                  <td class="tit">{{ mr.vMateNm }}</td>
                  <td>{{ mr.nRate }}</td>
                </tr>
                <tr>
                  <td>합계</td>
                  <td></td>
                  <td>{{ mateRateList?.[0]?.nRateSum }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div class="board-bottom">
          <div class="board-bottom__inner">
            <div class="ui-buttons ui-buttons__right">
              <button type="button" class="ui-button ui-button__bg--skyblue" @click="onSendBom">BOM 전송</button>
              <button type="button" class="ui-button ui-button__bg--lightgray"
                @click="closeAsyncPopup({ message: '닫기' })">닫기</button>
            </div>
          </div>
        </div>
      </template>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, reactive, ref, inject } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useMaterialCommon } from '@/compositions/labcommon/useMaterialCommon'
import { useCode } from '@/compositions/useCode'
import { useStore } from 'vuex'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'BomSendPop',
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
  },
  emits: ['onTabClick'],
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: '',
          vContPkCd: '',
          nVersion: '',
          vLotCd: '',
          vPlantCd: '',
          vCodeType: '',
          vFlagTestRes: '',
          vMoveUrl,
        }
      }
    }
  },
  setup(props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const store = useStore()
    const noteType = store.getters.getNoteType()
    const {
      openAsyncAlert, closeAsyncPopup
    } = useActions(['openAsyncAlert', 'closeAsyncPopup'])
    const searchParams = reactive({
      vLabNoteCd: props.popParams.vLabNoteCd,
      vContPkCd: props.popParams.vContPkCd,
      nVersion: props.popParams.nVersion,
      vLotCd: props.popParams.vLotCd,
      vPlantCd: props.popParams.vPlantCd,
      vCodeType: props.popParams.vCodeType,
      vFlagTestRes: props.popParams.vFlagTestRes,
      vMoveUrl: props.popParams.vMoveUrl,
    })
    const info = ref({
      contList: [],
      verList: [],
      tabList: [],
      defaultTab: '',
    })
    const allChk = reactive({
      val: 'Y',
    })

    const shelfInfo = ref({
      isShow: false,
      shelfLifeList: [],
      vFlagMsg: '',
    })
    const useBydateList = ref(null)
    const mateRateList = ref(null)
    const chkContList = ref(null)

    const {
      codeGroupMaps,
      findCodeList,
    } = useCode()

    const {
      selectOneShelfLifeContList,
    } = useLabCommon()

    const {
      selectLabNoteBomLotList,
      selectLabNoteMateRateInfo,
      updateLabNoteLotSendBom,
    } = useMaterialCommon()

    const init = async () => {
      if (!useBydateList.value) {
        await findCodeList(['SHELF_LIFE_CODE'])
        useBydateList.value = commonUtils.getCodeList(codeGroupMaps, 'SHELF_LIFE_CODE')
      }

      const response = await selectLabNoteBomLotList(searchParams)
      info.value.contList = response.contList
      info.value.verList = response.verList

      info.value.contList = info.value.contList.map(cont => {
        return {
          ...cont,
          chk: 'Y',
          vLotCd: cont.lotList?.filter(lot => lot.vLotCd === searchParams.vLotCd).length > 0 ? searchParams.vLotCd : null,
        }
      })

      const verList = [...info.value.verList]
      const tabList = []
      verList.filter(ver => ver.nVersion === searchParams.nVersion).map(ver => {
        tabList.push({
          tabId: 'VER_' + String(ver.nVersion),
          tabNm: ver.vVersionTxt,
        })
      })

      info.value.tabList = tabList
      info.value.defaultTab = 'VER_' + String(searchParams.nVersion)
    }

    const getSelectedTabEvent = (item) => {
      searchParams.nVersion = item.tabId.substring(4)
      init()
    }

    const onAllChk = () => {
      info.value.contList = info.value.contList.map(cont => {
        return {
          ...cont,
          chk: cont.lotList && cont.lotList.length > 0 ? allChk.val : 'N'
        }
      })
    }

    const onView = async () => {
      if (info.value.contList.filter(cont => cont.chk === 'Y').length === 0) {
        return
      }

      let message = ''

      info.value.contList.filter(cont => cont.chk === 'Y').map(cont => {
        if (!cont.vLotCd) {
          message = 'LOT이 선택되지 않았습니다.'
        }
        // else if (cont.lotList.find(lot => lot.vLotCd === cont.vLotCd)?.vFlagExistsBom === 'Y') {
        //   message = '이미 BOM 등록된 LOT 입니다.'
        // }
      })

      if (message) {
        openAsyncAlert({ message })
        return
      }

      const shelfRes = await selectOneShelfLifeContList({
        contCdList: info.value.contList.filter(cont => cont.chk === 'Y').map(cont => cont.vContCd),
        vPlantCd: searchParams.vPlantCd,
      })

      shelfInfo.value.shelfLifeList = shelfRes.list
      shelfInfo.value.vFlagMsg = shelfRes.vFlagMsg
      shelfInfo.value.isShow = true

      mateRateList.value = await selectLabNoteMateRateInfo({
        vLabNoteCd: searchParams.vLabNoteCd,
        vContPkCd: searchParams.vContPkCd,
        nVersion: searchParams.nVersion,
        vLotCd: searchParams.vLotCd,
      })

      chkContList.value = info.value.contList.filter(cont => cont.chk === 'Y').map(cont => {
        return {
          tabId: cont.vContPkCd,
          tabNm: cont.vContCd,
          vContPkCd: cont.vContPkCd,
          nVersion: searchParams.nVersion,
          vLotCd: cont.vLotCd,
        }
      })
    }

    const onShelfChange = (o) => {
      if (o.vShelfLife === 'ETC') {
        o.vIsEtc = true
      }
      else {
        o.vIsEtc = false
      }
    }

    const onSendBom = async () => {
      if (shelfInfo.value.vFlagMsg === 'Y') {
        if (shelfInfo.value.shelfLifeList.filter(shelf => !shelf.vShelfLife || shelf.vShelfLife === '').length > 0) {
          openAsyncAlert({ message: 'SHELF LIFE를 입력해 주세요.' })
          return
        }
      }

      let message = ''

      info.value.contList.filter(cont => cont.chk === 'Y').map(cont => {
        if (!cont.vLotCd) {
          message = 'LOT이 선택되지 않았습니다.'
        }
      })

      if (message) {
        openAsyncAlert({ message })
        return
      }

      const sendBomList = [...info.value.contList].map(cont => {
        return {
          vContPkCd: cont.vContPkCd,
          vContCd: cont.vContCd,
          vContNm: cont.vContNm,
          nVersion: searchParams.nVersion,
          vLotCd: cont.vLotCd,
          vLotNm: cont.lotList.find(lot => lot.vLotCd === cont.vLotCd)?.vLotNm || '',
        }
      })
      const vFlagSaveContCd = shelfInfo.value.shelfLifeList.length > 0 && shelfInfo.value.vFlagMsg === 'Y' ? 'Y' : null
      const shelfLifeList = !vFlagSaveContCd
        ? []
        : [...shelfInfo.value.shelfLifeList].map(shelf => {
          return {
            vContCd: shelf.vContCd,
            vNoteType: noteType,
            vShelfLife: shelf.vShelfLife,
            vPlantCd: searchParams.vPlantCd,
          }
        })

      await updateLabNoteLotSendBom({
        vLabNoteCd: searchParams.vLabNoteCd,
        sendBomList,
        vFlagSaveContCd,
        shelfLifeList,
        vMoveUrl: searchParams.vMoveUrl,
      })

      openAsyncAlert({ message: '저장 되었습니다.' })
      context.emit('onTabClick', searchParams.nVersion)
      closeAsyncPopup({ message: '닫기' })
    }

    init()

    return {
      t,
      searchParams,
      info,
      allChk,
      shelfInfo,
      useBydateList,
      mateRateList,
      chkContList,
      getSelectedTabEvent,
      onAllChk,
      onView,
      onShelfChange,
      onSendBom,
      closeAsyncPopup
    }
  }
}
</script>