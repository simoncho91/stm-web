<template>
  <div class="modal-content modal-content__width--640">
    <div class="modal-header">
      <div class="modal-title">3자코드 채번</div>
      <button type="button" class="modal-close" @click="fnClose"></button>
    </div>

    <div class="modal-body">
      <div class="basic-info__table">
        <table class="ui-table__contents">
          <colgroup>
            <col style="width:7.2rem">
            <col style="width:auto">
            <col style="width:7.2rem">
            <col style="width:auto">
            <!-- <col style="width:7.2rem"> -->
          </colgroup>
          <tbody>
            <tr>
              <th>브랜드</th>
              <td class="t-left chg-search-field">
                <ap-selectbox
                  v-model:value="regParams.vBrdCd"
                  input-class="ui-select__width--176"
                  :options="codeGroupMaps['LAB_NOTE_BRAND']"
                >
                </ap-selectbox>
              </td>
              <th class="t-right">플랜트</th>
              <td class="t-right chg-search-field">
                <ap-selectbox
                  v-model:value="regParams.vPlantCd"
                  input-class="ui-select__width--194"
                  :options="plantList"
                >
                </ap-selectbox>
              </td>
              <!-- <td>
                <button type="button" class="ui-button ui-button__bg--blue ml-10">추가</button>
              </td> -->
            </tr>
            <tr>
              <th>내용물명</th>
              <td colspan="3">
                <ap-input
                  v-model:value="regParams.vContNm"
                  input-class="ui-input__width--full"
                  placeholder="내용물 명을 입력해주세요."
                >
                </ap-input>
              </td>
            </tr>
          </tbody>
        </table>

        <div class="board-bottom ">
          <div class="board-bottom__inner">
            <div class="ui-buttons ml-auto ui-buttons__right">
              <button
                type="button"
                class="ui-button ui-button__bg--skyblue"
                @click="fnApply"
              >코드채번</button>
              <!-- 2023.04.06 : add : 닫기 버튼 추가 -->
              <button
                type="button"
                class="ui-button ui-button__bg--lightgray"
                @click="fnClose"
              >닫기</button>
            </div>
          </div>
        </div>

      </div>
    </div>

  </div><!-- /.modal-content -->
</template>

<script>
import { inject, reactive, ref } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useNonPrdCommon } from '@/compositions/labcommon/useNonPrdCommon'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'CodeGenerationPop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: '',
        }
      }
    }
  },
  emits: ['closeFunc'],
  setup (props, context) {
    const commonUtils = inject('commonUtils')
    const t = inject('t')

    const { closeAsyncPopup, openAsyncAlert } = useActions(['closeAsyncPopup', 'openAsyncAlert'])

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const {
      saveLabNoteNonprdRequest,
    } = useNonPrdCommon()

    const {
      selectLabNoteMstBaseInfo,
    } = useLabCommon()

    const resData = ref({})
    const plantList = ref([])

    const searchParams = reactive({
      vLabNoteCd: props.popParams.vLabNoteCd || '',
    })

    const regParams = ref({
      vFlagAction: 'SAVE_GENERATE_CODE',
      vLabNoteCd: props.popParams.vLabNoteCd,
      vBrdCd: '',
      vPlantCd: '',
      vContNm: '',
      vContPkCd: '',
    })

    const fnApply = async () => {

      if (commonUtils.isEmpty(regParams.value.vBrdCd)) {
        openAsyncAlert({ message: '브랜드를 선택해 주세요.' })
        return
      }
      if (commonUtils.isEmpty(regParams.value.vPlantCd)) {
        openAsyncAlert({ message: 'Plant를(을) 선택해 주세요.' })
        return
      }

      const vLabNoteCd = await saveLabNoteNonprdRequest(regParams.value)

      if (vLabNoteCd) {
        await openAsyncAlert({ message: '3자코드 채번 요청이 진행되었습니다.'})
        context.emit('closeFunc')
        fnClose()
      }
    }

    const fnClose = () => {
      closeAsyncPopup()
    }

    const init = async () => {
      await findCodeList(['LAB_NOTE_PLANT', 'LAB_NOTE_BRAND'])
      plantList.value = commonUtils.getCodeList(codeGroupMaps, 'LAB_NOTE_PLANT', 'U', null, null)

      resData.value = await selectLabNoteMstBaseInfo(searchParams);

      if (resData.value) {
        regParams.value.vContNm = resData.value.vContNm
        regParams.value.vContPkCd = resData.value.vContPkCd
      }
    }

    init()

    return {
      t,
      searchParams,
      resData,
      plantList,
      fnApply,
      fnClose,
      codeGroupMaps,
      regParams,
    }
  }
}
</script>

<style scoped>
  .ui-table tbody tr {
    cursor: pointer;
  }
</style>