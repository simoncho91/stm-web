<template>
  <div class="modal-content" style="width: 110rem;">
    <div class="modal-header">
      <div class="modal-title">무소구 수정</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({message: ''})"></button>
    </div>
    <div class="modal-body">
      <NotAddIngredientRegister
        ref="notAdd"
        v-model:vFlagNotAdd="regParams.vFlagNotAdd"
        v-model:vNotAddNote="regParams.vNotAddNote"
      >
      </NotAddIngredientRegister>

      <div class="ui-buttons ui-buttons__right mt-2">
        <button type="button" class="ui-button ui-button__bg--skyblue font-weight__300" @click="fnSave()">수정</button>
        <button type="button" class="ui-button ui-button__bg--lightgray" @click="closeAsyncPopup({ message: ''})">닫기</button>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useStore } from 'vuex'
import { useRequestCommon } from '@/compositions/labcommon/useRequestCommon'

export default {
  name: 'NotAddIngredientModifyPop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  emits: ['callbackFunc'],
  components: {
    NotAddIngredientRegister: defineAsyncComponent(() => import('@/components/labcommon/NotAddIngredientRegister.vue')),
  },
  setup (props) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const store = useStore()
    const noteInfo = store.getters.getNoteInfo()
    const { openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncAlert', 'closeAsyncPopup'])
    const notAdd = ref(null)

    const {
      updateNotAddIngredientInfo,
    } = useRequestCommon()

    const regParams = ref({
      vLabNoteCd: props.popParams.vLabNoteCd,
      vFlagNotAdd: '',
      vNotAddNote: '',
    })

    const fnSave = async () => {
      const mstTagList = []
      const mtr04List = notAdd.value.mtr04List
      const mtr05List = notAdd.value.mtr05List
      const mtr06List = notAdd.value.mtr06List
      const arrList = []

      if (regParams.value.vFlagNotAdd === 'Y') {
        arrList.push(mtr04List)
        arrList.push(mtr05List)
        arrList.push(mtr06List)

        for (const list of arrList) {
          if (list && list.length > 0) {
            for (const item of list) {
              if (commonUtils.isNotEmpty(item.vTag2Cd)) {
                mstTagList.push({ ...item })
              }
            }
          }
        }
      } else {
        regParams.value.vNotAddNote = ''
      }

      regParams.value = {
        ...regParams.value,
        mstTagList: mstTagList
      }

      const result = await updateNotAddIngredientInfo(regParams.value)

      if (result && result === 'SUCC') {
        await openAsyncAlert({ message : '수정 되었습니다.'})
        window.location.reload(true)
      }
    }

    const init = () => {
      if (noteInfo) {
        regParams.value.vFlagNotAdd = noteInfo.vFlagNotAdd
        regParams.value.vNotAddNote = noteInfo.vNotAddNote
      }
    }

    init()

    return {
      regParams,
      notAdd,
      fnSave,
      closeAsyncPopup,
    }
  }
}
</script>