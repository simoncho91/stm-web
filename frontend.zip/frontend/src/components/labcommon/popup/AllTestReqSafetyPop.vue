<template>
  <div class="modal-content modal-content__width--122">
    <div class="modal-header">
      <div class="modal-title">시험의뢰 (안전성)</div>
      <button
        type="button"
        class="modal-close"
        @click="closeAsyncPopup"
      ></button>
    </div>
    <div class="modal-body">
      <div class="search-detail-table">
        <div class="search-detail-table__inner">
          <table class="ui-table__modal pd">
            <colgroup>
              <col style="width:6%">
              <col style="width:6%">
              <col style="width:15%">
              <col style="width:auto">
              <col style="width:8%">
              <col style="width:13%">
              <col style="width:13%">
              <col style="width:10%">
            </colgroup>
            <thead>
              <tr>
                <th>
                  <ap-input-check
                    v-model:model="chkAll"
                    :value="'Y'"
                    :false-value="'N'"
                    :id="'ex_check_all'"
                    @click="fnCheckAll"
                  >
                  </ap-input-check>
                </th>
                <th>대표</th>
                <th>내용물코드/제품코드</th>
                <th>내용물명</th>
                <th>플랜트</th>
                <th>버전</th>
                <th>LOT</th>
                <th>비고 </th>
              </tr>
            </thead>
            <tbody>
              <template v-if="resData.contList?.length > 0">
                <tr v-for="(cvo, idx1) in resData.contList" :key="`tr_${idx1}`">
                  <td>
                    <ap-input-check
                      v-model:model="testReqTergetList"
                      :value="cvo.vContPkCd"
                      :id="`ex_check_${idx1}`"
                      @click="fnAddTestReqTarget($event, idx1)"
                    >
                    </ap-input-check>
                  </td>
                  <td>
                    <div class="ui-label jc-c">
                      <ap-input-radio
                        v-model:model="payload.vRepContPkCd"
                        :value="cvo.vContPkCd"
                        :id="`flagNew_${idx1}`"
                        name="flagNew"
                        @click="fnClickRep(cvo)"
                      ></ap-input-radio>
                    </div>
                  </td>
                  <td>{{ cvo.vContCd }} / {{ cvo.vPrdCd }}</td>
                  <td>
                    <div class="tit__inner">
                      {{ cvo.vContNm }}
                    </div>
                    </td>
                  <td>{{ cvo.vPlantCd }}</td>
                  <td>
                    <div class="ui-select-block">
                      <ap-selectbox
                        v-model:value="cvo.nVersion"
                        input-class="ui-select__width--120"
                        :options="resData.verList"
                        :disabled="testReqTergetList.indexOf(cvo.vContPkCd) === -1"
                        codeKey="nVersion"
                        codeNmKey="vVersionTxt"
                        @change="fnChangeVersion($event, cvo)"
                      >
                      </ap-selectbox>
                    </div>
                  </td>
                  <td>
                    <div class="ui-select-block">
                      <ap-selectbox
                        v-model:value="cvo.vLotCd"
                        input-class="ui-select__width--120"
                        :options="cvo.subList"
                        :disabled="testReqTergetList.indexOf(cvo.vContPkCd) === -1"
                        codeKey="vLotCd"
                        codeNmKey="vLotNm"
                        @change="fnSelectOption($event, cvo)"
                      >
                      </ap-selectbox>
                    </div>
                  </td>
                  <td></td>
                </tr>
              </template>
              <template v-else>
                <tr>
                  <td colspan="8">
                    <div class="no-result">
                      {{ t('common.msg.no_data') }}
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>

      <div class="tableTitle mt-2">정보 입력</div>
      <div class="board-top mb-0">
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">완료요청일<span class="ui-require"><span class="for-a11y">(필수)</span></span></dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="search-form">
                <div class="search-form__inner">
                  <ap-date-picker
                    v-model:date="payload.vTrCompleteReqDt"
                    :read-only="true"
                  />
                </div>
              </div>

            </dd>
          </dl>
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">제형<span class="ui-require"><span class="for-a11y">(필수)</span></span></dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="search-form">
                <div class="search-form__inner">
                  <ap-selectbox
                    v-model:value="payload.vDosageFormCd"
                    :options="codeGroupMaps['DOSAGE_FORM']"
                  />
                </div>
              </div>
            </dd>
          </dl>

        </div>
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">{{ payload.vTestTypeNm || '-' }}</dt>
            <dd class="search-bar__val search-bar__val--flexible" style="text-align: left;">
              {{ payload.vTestValue }}
            </dd>
          </dl>
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">pH</dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <ap-input :is-number="false" v-model:value="payload.vTrPh"></ap-input>
            </dd>
          </dl>

        </div>
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">영문명<span class="ui-require"><span class="for-a11y">(필수)</span></span></dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <ap-input :is-number="false" v-model:value="payload.vTrContNmEn" :inputClass="'ui-input__width--full'"></ap-input>
            </dd>
          </dl>
        </div>
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">시험법<span class="ui-require"><span class="for-a11y">(필수)</span></span></dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <template v-if="resData.mtr01List?.length > 0">
                <div class="form-flex">
                  <div class="form-flex-cell form-flex__cell--5">
                    <div class="ui-checkbox__list">
                      <div class="ui-checkbox__inner">
                        <template v-for="(vo, idx) in resData.mtr01List" :key="`test_item_${idx}`">
                          <ap-input-check
                            v-model:model="testItemCdList"
                            :value="vo.vSubCode"
                            :label="`${vo.vSubCodenm}${vo.vContent2 ? ' ('+vo.vContent2+')' : ''}`"
                            :id="'testItem_' + vo.vSubCode"
                          >
                          </ap-input-check>
                          <template v-if="vo.vSubCode === 'MTI01_07'">
                            <ap-input v-if="testItemCdList.indexOf('MTI01_07') > -1" :is-number="false" v-model:value="payload.vMethodEtc" :inputClass="'ui-input__width--150'"></ap-input>
                          </template>
                        </template>
                      </div>
                    </div>
                  </div>
                </div>
              </template>
              <template v-else>
                시험법이 존재하지 않습니다.
              </template>
            </dd>
          </dl>
        </div>
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">무방부/무향</dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="form-flex">
                <div class="form-flex-cell form-flex__cell--5">
                  <div class="ui-checkbox__list">
                    <div class="ui-checkbox__inner">
                      <ap-input-check
                        v-model:model="payload.vTrFlagNoAntiseptic"
                        :value="'Y'"
                        :id="'ex_check_no_antiseptic'"
                        :label="'무방부'"
                      >
                      </ap-input-check>
                      <ap-input-check
                        v-model:model="payload.vTrFlagNoFragrance"
                        :value="'Y'"
                        :id="'ex_check_no_fragrance'"
                        :label="'무향'"
                      >
                      </ap-input-check>
                    </div>
                  </div>
                </div>
                
              </div>
            </dd>
          </dl>
        </div>

        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">중국 출시 대상<span class="ui-require"><span class="for-a11y">(필수)</span></span></dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="form-flex">
                <div class="form-flex-cell form-flex__cell--5">
                  <div class="ui-checkbox__list">
                    <div class="ui-checkbox__inner">
                      <ap-input-radio
                        v-model:model="payload.vChinaGoYn"
                        :value="'Y'"
                        :id="`china_go_y`"
                        :label="'Y'"
                        name="chinaGo"
                      ></ap-input-radio>
                      <ap-input-radio
                        v-model:model="payload.vChinaGoYn"
                        :value="'N'"
                        :id="`china_go_n`"
                        :label="'N'"
                        name="chinaGo"
                      ></ap-input-radio>
                      <template v-if="payload.vChinaGoYn === 'Y'">
                        ( 중국 사전안전성 여부 
                        <ap-input-radio
                          v-model:model="payload.vChinaSafeYn"
                          :value="'Y'"
                          :id="`china_safe_y`"
                          :label="'Y'"
                          name="chinaSafe"
                        ></ap-input-radio>
                        <ap-input-radio
                          v-model:model="payload.vChinaSafeYn"
                          :value="'N'"
                          :id="`china_safe_n`"
                          :label="'N'"
                          name="chinaSafe"
                        ></ap-input-radio>
                        )
                      </template>
                    </div>
                  </div>
                </div>
                
              </div>
            </dd>
          </dl>
        </div>

        <template v-if="noteType === 'MU'">
          <div class="search-bar__row search-bar__row--modal">
            <dl class="search-bar__item search-bar__item--flexible">
              <dt class="search-bar__key search-bar__width--100">무색 베이스<br/>의뢰 여부</dt>
              <dd class="search-bar__val search-bar__val--flexible">
                <div class="form-flex">
                  <div class="form-flex-cell form-flex__cell--5">
                    <div class="ui-checkbox__list">
                      <span style="color: red;">↓ 원료배합에서 조색 라벨이 붙은 원료를 제외한 처방이 함께 의뢰됩니다.</span>
                      <div class="ui-checkbox__inner">
                        <ap-input-check
                          v-model:model="payload.vFlagNoColorBase"
                          :value="'Y'"
                          :id="'ex_check_no_color_base'"
                          :label="'무색 베이스 의뢰'"
                        >
                        </ap-input-check>
                      </div>
                    </div>
                  </div>
                  
                </div>
              </dd>
            </dl>
          </div>
        </template>

        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">모제품 코드</dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="search-form">
                <div class="search-form__inner">
                  <ap-input
                    :is-number="false"
                    v-model:value="productSearchKeyword"
                    :inputClass="'ui-input ui-input__width--340'"
                  ></ap-input>
                  <button
                    type="button"
                    class="button-search"
                    @click="fnOpenParentProductSearchPop()"
                  >추가</button>
                </div>

                <template v-if="productList?.length > 0">
                  <div class="search-result-table mt-15">
                    <table class="ui-table__reset ui-table__search-result text-center pop-padding">
                      <colgroup>
                        <col style="width:15%">
                        <col style="width:auto">
                        <col style="width:10%">
                        <col style="width:10%">
                      </colgroup>
                      <thead>
                        <tr>
                          <th>내용물코드</th>
                          <th>내용물명</th>
                          <th>LOT</th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr v-for="(pvo, idx) in productList" :key="`prod_tr_${idx}`">
                          <td>{{ pvo.vContCd }}</td>
                          <td>{{ pvo.vContNm }}</td>
                          <td>{{ pvo.vLotNm }}</td>
                          <td>
                            <button
                              type="button"
                              class="ui-button ui-button__width--40 ui-button__height--23 ui-button__border--blue ui-button__radius--2"
                              @click="fnDeleteProduct(idx)"
                            >삭제</button>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </template>

              </div>
            </dd>
          </dl>
        </div>
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100 mt-m3">메시지</dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <ap-text-area
                :is-with-byte="true"
                v-model:value="payload.vTrComment"
                :maxlength="2000"
              ></ap-text-area>
            </dd>
          </dl>
        </div>
      </div>
      <div class="board-bottom ">
        <div class="board-bottom__inner">
          <div class="ui-buttons ml-auto ui-buttons__right">
            <button
              type="button"
              class="ui-button ui-button__bg--skyblue font-weight__300"
              @click="fnTestReqSave"
            >시험의뢰</button>
            <button
              type="button"
              class="ui-button ui-button__bg--lightgray"
              @click="closeAsyncPopup"
            >닫기</button>
          </div>
        </div>
      </div>
    </div>
    <teleport to="#common-modal-sub" v-if="popContent">
      <ap-popup>
        <component
          :is="popContent"
          :pop-params="popupParams"
          @selectFunc="popSelectFunc"
          @closeFunc="closeFunc"
        />
      </ap-popup>
    </teleport>
  </div>
  <div id="common-modal-sub"></div>
</template>

<script>
import { ref, inject, defineAsyncComponent, watch } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useActions } from 'vuex-composition-helpers'
import { useTestReqCommon } from '@/compositions/labcommon/useTestReqCommon'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'

export default {
  name: 'AllTestReqSafetyPop',
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    ParentProductSearchPop: defineAsyncComponent(() => import('@/components/labcommon/popup/ParentProductSearchPop.vue')),
  },
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: ''
        , vContPkCd: ''
        , nVersion: ''
        , vLotCd: ''
        , vPlantCd: ''
        , vMrqTypeCd: ''
        }
      }
    }
  },
  emits: ['selectFunc'],
  setup(props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { openAsyncConfirm, openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncConfirm', 'openAsyncAlert', 'closeAsyncPopup'])

    const flagLotCompleYn = ref('')

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const { 
      selectPrdTestReqSafetyInfo,
      goSkinTestReqSave,
      selectTestReqLotList,
      noteType,
      isProcessing,
    } = useTestReqCommon()

    const { 
      selectSafetySapChk,
    } = useLabCommon()

    const searchParams = ref({
      vLabNoteCd: props.popParams.vLabNoteCd,
      // vContPkCd: props.popParams.vContPkCd,
      vOtherContPkCd: props.popParams.vContPkCd,
      nVersion: props.popParams.nVersion,
      vLotCd: props.popParams.vLotCd,
      vPlantCd: props.popParams.vPlantCd,
      vMrqTypeCd: props.popParams.vMrqTypeCd,
      vTrMrqTypeCd: props.popParams.vMrqTypeCd,
      vGateCd: props.popParams.vGateCd,
    })

    // 테스트용
    // const searchParams = ref({
    //   vLabNoteCd: 'LMS20230313010281',
    //   vOtherContPkCd: 'LCO20230313011941',
    //   nVersion: 4,
    //   vLotCd: props.popParams.vLotCd,
    //   vPlantCd: '1110',
    //   vMrqTypeCd: props.popParams.vMrqTypeCd,
    //   vTrMrqTypeCd: props.popParams.vMrqTypeCd,
    //   vGateCd: 'GATE_1',
    // })

    const resData = ref({})
    const mstList = ref([])

    const testReqTergetList = ref([])
    const chkAll = ref('N')

    // 시험법 리스트
    const testItemCdList = ref([])

    // 모제품 코드 리스트
    const productList = ref([])

    // 모제품 검색
    const productSearchKeyword = ref('')

    const popContent = ref(null)
    const popSelectFunc = ref(null)
    const closeFunc = ref(null)
    const popupParams = ref({})

    const payload = ref({
      vRepContPkCd: '',
      vRepContCd: '',
      vRepLotCd: '',
      vRepPlantCd: '',
      nRepVersion: '',

      vFlagAction: 'SAVE_TEST_REQ',

      // 완료 요청일
      vTrCompleteReqDt: '',
      // 제형
      vDosageFormCd: '',
      // 점도
      vTestType: '',
      vTestTypeNm: '',
      vTestValue: '',
      // pH
      vTrPh: '',
      // 영문명
      vTrContNmEn: '',

      // 무방부
      vTrFlagNoAntiseptic: '',
      // 무향
      vTrFlagNoFragrance: '',

      // 중국 출시 대상
      vChinaGoYn: '',

      // 중국 사전안전성 여부(중국 출시 대상 'Y'인 경우 영역 활성화)
      vChinaSafeYn: '',

      // 무색 베이스 의뢰 여부(메이크업만)
      vFlagNoColorBase: '',

      // 메시지
      vTrComment: '',

      vTrPrdCd: '',
      vTddProdType1Cd: '',
      vTddProdType2Cd: '',
      vMethodEtc: '',
    })

    const fnSelectOption = (value, vo) => {
      const lvo = vo.subList.find(svo => svo.vLotCd === value)
      
      if (payload.value.vRepContPkCd && payload.value.vRepContPkCd === vo.vContPkCd) {
          payload.value.vTestType = lvo ? lvo.vTestType : ''
          payload.value.vTestTypeNm = lvo ? lvo.vTestTypeNm : ''
          payload.value.vTestValue = lvo ? lvo.vTestValue : ''
          payload.value.vTrPh = lvo ? lvo.vPh :''
          flagLotCompleYn.value = lvo ? lvo.vFlagComplete : ''
      }

      // vo.nVersion = lvo ? lvo.nVersion : ''
      vo.vLotNm = lvo ? lvo.vLotNm : ''
    }

    const fnClickRep = (vo) => {
      const lotCd = vo?.vLotCd

      if (lotCd) {
        const lvo = vo.subList.find(svo => svo.vLotCd === lotCd)

        if (lvo) {
          payload.value.vTestType = lvo.vTestType
          payload.value.vTestTypeNm = lvo.vTestTypeNm
          payload.value.vTestValue = lvo.vTestValue
          payload.value.vTrPh = lvo.vPh
          flagLotCompleYn.value = lvo.vFlagComplete
        } else {
          payload.value.vTestType = ''
          payload.value.vTestTypeNm = ''
          payload.value.vTestValue = ''
          payload.value.vTrPh = ''
          flagLotCompleYn.value = ''
        }
      } else {
        payload.value.vTestType = ''
        payload.value.vTestTypeNm = ''
        payload.value.vTestValue = ''
        payload.value.vTrPh = ''
        flagLotCompleYn.value = ''
      }
    }

    const fnTestReqSave = async () => {
      if (testReqTergetList.value.length === 0) {
        await openAsyncAlert({ message: '시험의뢰할 대상을 선택해 주세요.' })
        return
      }

      const vRepContPkCd = payload.value.vRepContPkCd

      if (commonUtils.isEmpty(vRepContPkCd)) {
        await openAsyncAlert({ message: '대표 내용물을 선택해 주세요.' })
        return
      }

      const repCvo = resData.value.contList.find(cvo => cvo.vContPkCd === vRepContPkCd)

      if (repCvo) {
        const vRepLotCd = repCvo.vLotCd

        // if (commonUtils.isEmpty(vRepLotCd)) {
        //   await openAsyncAlert({ message: 'Lot를 선택해 주세요.' })
        //   return
        // }
        const targetList = resData.value.contList.filter(cvo => testReqTergetList.value.indexOf(cvo.vContPkCd) > -1)

        if (targetList.some(vo => commonUtils.isEmpty(vo.vLotCd))) {
          await openAsyncAlert({ message: 'Lot를 선택해 주세요.' })
          return
        }
        
        if (commonUtils.isEmpty(payload.value.vTrCompleteReqDt)) {
          await openAsyncAlert({ message: '완료 요청일을 입력해 주세요.' })
          return
        }

        if (commonUtils.isEmpty(payload.value.vDosageFormCd)) {
          await openAsyncAlert({ message: '제형을 선택해 주세요.' })
          return
        }

        if (commonUtils.isEmpty(payload.value.vTrContNmEn)) {
          await openAsyncAlert({ message: '영문명을 입력해 주세요.' })
          return
        }

        if (testItemCdList.value.length === 0) {
          await openAsyncAlert({ message: '시험법을 선택해 주세요.' })
          return
        }

        if (commonUtils.isEmpty(payload.value.vChinaGoYn)) {
          await openAsyncAlert({ message: '중국 출시여부를 선택해 주세요.' })
          return
        } else {
          if (payload.value.vChinaGoYn === 'Y') {
            if (commonUtils.isEmpty(payload.value.vChinaSafeYn)) {
              await openAsyncAlert({ message: '중국 사전안전성 여부를 체크해주시기 바랍니다.' })
              return
            } else {
              if (payload.value.vChinaSafeYn === 'N') {
                const message = 
                '중국 사전안전성 시스템에 미리 등록하고 진행해 주시기 바랍니다.<br/><br/>신원료(2*****/1*****), Blank (6999999)포함시, 중국사전안전검토시스템 의뢰 불가합니다.<br/>BOM엑셀다운로드에서 해당 엑셀폼을 다운받아 따로 등록 요청드립니다.'

                await openAsyncAlert({ message: message })
                return
              }
            }
          }
        }
        
        if (!commonUtils.checkByte(payload.value.vTrComment, 2000)) {
          await openAsyncAlert({ message: '메시지는 2000byte (한글 : 666자, 영문 : 2000자) 이내로 입력해 주세요.' })
          return
        }
        
        payload.value.vRepContCd = repCvo.vContCd || ''
        payload.value.vRepLotCd = vRepLotCd
        payload.value.vRepPlantCd = repCvo.vPlantCd || ''
        payload.value.nRepVersion = repCvo.nVersion || ''

        // payload.value.vTrPrdCd = repCvo.vTrPrdCd || ''

        if (!isProcessing.value) {
          mstList.value = await selectSafetySapChk({
            vSapCd: repCvo.vContCd,
            vLabNoteCd: searchParams.value.vLabNoteCd,
            vLotCd: repCvo.vLotCd,
          })   
          
          if (mstList.value?.length > 0) {
            let message = `
            <span style='font-weight:bold;'>동일한 Lot에 대해 이미 안전성 시험의뢰를 하였습니다.</span><br/>
            <span style='font-weight:bold;'>다른 Lot로 시험의뢰 해주세요.</span><br/>
            <span style=''>[가장 최근에 입력된 의뢰서]</span><br/>
            `
  
            mstList.value.forEach((vo, idx) => {
              message += `
              <span class='span_link'>
                <a href='#' class='btn_link' style='color:blue;font-weight:bold;'>
                  [제품명 : ${vo.vProductNm}, 의뢰번호 : ${vo.vDocNo}]
                </a>
              </span><br/>
              `
            })
  
            await openAsyncAlert({ message: message })
            return
          }
        }
      }

      if(flagLotCompleYn.value !== "Y"){
        const confirmMessage = '<span style="font-weight:bold; color:red;">시험의뢰시 해당 Lot은 더이상 수정 할 수 없습니다.</span><br/>저장 하시겠습니까?'
        if (!await openAsyncConfirm({ message: confirmMessage })) {
          return
        }
      }

      const params = {
        ...searchParams.value,
        ...payload.value,
        ...{
          contList: resData.value.contList.filter(cvo => testReqTergetList.value.indexOf(cvo.vContPkCd) > -1) || [],
          testItemCdList: testItemCdList.value,
          sameList: productList.value,
        }
      }

      goSkinTestReqSave(params)
    }

    const fnCheckAll = (value) => {
      if (value === 'Y') {
        testReqTergetList.value = resData.value.contList.map(cvo => cvo.vContPkCd)

        if (commonUtils.isEmpty(payload.value.vRepContPkCd)) {
          payload.value.vRepContPkCd = resData.value.contList.find(cvo => cvo.subList.length > 0).vContPkCd
        }
      } else {
        testReqTergetList.value = []
        payload.value.vRepContPkCd = ''
      }

    }

    const fnAddTestReqTarget = (value, idx) => {
      const targetList = testReqTergetList.value

      if (value) {
        // 시험 의뢰 대상 체크했을 때
        if (targetList.length === resData.value.contList.length) {
          chkAll.value = 'Y'
        }

        if (!payload.value.vRepContPkCd) {
          payload.value.vRepContPkCd = value
        }
      } else {
        // 시험 의뢰 대상 체크 해제했을 때
        if (targetList.length > 0) {
          const contList = resData.value.contList
          const existContPkCd = contList[idx].vContPkCd
          const repContPkCd = payload.value.vRepContPkCd

          if (existContPkCd && repContPkCd && existContPkCd === repContPkCd) {
            // 해제한 대상이 대표로 체크되어 있었는 지 확인
            payload.value.vRepContPkCd = contList.find(cvo => targetList.some(contPkCd => contPkCd === cvo.vContPkCd)).vContPkCd
          }
        } else {
          payload.value.vRepContPkCd = ''
        }
        chkAll.value = 'N'
      }
    }

    const fnOpenParentProductSearchPop = () => {
      popupParams.value = {
        vKeyword: productSearchKeyword.value,
        vTypecd: 'NOTE',
        productList: productList.value
      }

      popSelectFunc.value = settingProductList
      closeFunc.value = closeParentProductSearchPop

      popContent.value = 'ParentProductSearchPop'
    }

    const settingProductList = (list) => {
      if (list?.length === 0) {
        return
      }

      // productList.value.push(list)
      productList.value = list
    }

    const closeParentProductSearchPop = () => {
      popContent.value = null
    }

    const fnChangeVersion = async (value, vo) => {
      vo.vLotCd = ''

      if (commonUtils.isEmpty(value)) {
        vo.subList = []
      } else {
        const payload = {
          vContPkCd: vo.vContPkCd,
          nVersion: value
        }
  
        const result = await selectTestReqLotList(payload)
  
        if (result) {
          vo.subList = result
        }
      }
    }

    const fnDeleteProduct = async (idx) => {
      if (!await openAsyncConfirm({ message: '삭제 하시겠습니까?' })) {
        return
      }

      productList.value.splice(idx, 1)
    }

    watch(() => payload.value.vRepContPkCd, (newVal, oldVal) => {
      if (commonUtils.isNotEmpty(newVal)) {
        const cvo = resData.value.contList.find(vo => vo.vContPkCd === newVal)
  
        if (cvo.vLotCd) {
          const lvo = cvo.subList.find(svo => svo.vLotCd === cvo.vLotCd)
  
          if (lvo) {
            payload.value.vTestType = lvo.vTestType
            payload.value.vTestTypeNm = lvo.vTestTypeNm
            payload.value.vTestValue = lvo.vTestValue
            payload.value.vTrPh = lvo.vPh
            flagLotCompleYn.value = lvo.lvo.vFlagComplete
          } else {
            payload.value.vTestType = ''
            payload.value.vTestTypeNm = ''
            payload.value.vTestValue = ''
            payload.value.vTrPh = ''
            flagLotCompleYn.value = ''
          }
        } else {
          payload.value.vTestType = ''
          payload.value.vTestTypeNm = ''
          payload.value.vTestValue = ''
          payload.value.vTrPh = ''
          flagLotCompleYn.value = ''
        }
      } else {
        payload.value.vTestType = ''
        payload.value.vTestTypeNm = ''
        payload.value.vTestValue = ''
        payload.value.vTrPh = ''
        flagLotCompleYn.value = ''
      }
    })

    const init = async () => {
      await findCodeList(['DOSAGE_FORM'])

      resData.value = await selectPrdTestReqSafetyInfo(searchParams.value)

      if (resData.value) {
        if (resData.value.noteVo) {
          payload.value.vTddProdType1Cd = resData.value.noteVo.vTddProdType1Cd
          payload.value.vTddProdType2Cd = resData.value.noteVo.vTddProdType2Cd
        }
        if (resData.value.contList) {
          const contList = resData.value.contList

          const repCvo = contList.find(cvo => cvo.vContPkCd === searchParams.value.vOtherContPkCd)
  
          if (repCvo) {
            payload.value.vRepContPkCd = repCvo.vContPkCd
            // testReqTergetList.value.push(repCvo.vContPkCd)
          }

          if (testReqTergetList.value.length === contList.length) {
            chkAll.value = 'Y'
          }

          contList.forEach(cvo => {
            if(cvo.subList && cvo.subList.length > 0) {
              testReqTergetList.value.push(cvo.vContPkCd)
            }
            cvo.nVersion = props.popParams.nVersion
          });
        }
        if (resData.value.lastTrVo) {
          payload.value.vDosageFormCd = resData.value.lastTrVo.vDosageFormCd
          
          if (resData.value.lastTrVo?.vFlagNoAntiseptic === 'Y') {
            payload.value.vTrFlagNoAntiseptic = 'Y'
          }
          if (resData.value.lastTrVo?.vFlagNoFragrance === 'Y') {
            payload.value.vTrFlagNoFragrance = 'Y'
          }
        }
      } else {
        closeAsyncPopup()
      }
    }

    init()

    return {
      t,
      codeGroupMaps,
      closeAsyncPopup,
      selectPrdTestReqSafetyInfo,
      resData,
      payload,
      fnSelectOption,
      fnClickRep,
      fnTestReqSave,
      testReqTergetList,
      chkAll,
      fnCheckAll,
      fnAddTestReqTarget,
      testItemCdList,
      productList,
      productSearchKeyword,
      fnOpenParentProductSearchPop,
      popContent,
      popSelectFunc,
      closeFunc,
      popupParams,
      fnChangeVersion,
      fnDeleteProduct,
      flagLotCompleYn,
      noteType,
    }
  }
}
</script>