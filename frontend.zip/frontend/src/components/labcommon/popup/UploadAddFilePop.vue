<template>
  <div class="modal-content modal-content__width--auto" style="width:550px">
    <div class="modal-header">
      <div class="modal-title">파일 추가</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({ message: '' })"></button>
    </div>
    <div class="modal-body">
      <div class="ui-table__wrap">
        <table class="ui-table__reset ui-table__ver">
          <colgroup>
            <col style="width:10rem">
            <col style="width:auto">
          </colgroup>
          <tbody>
            <tr>
              <th>업로드</th>
              <td>
                <UploadFileRegister :uploadid="uploadParams.vUploadCd" :parent-info="uploadParams"
                  :is-only-img="uploadParams.vFlagDownload === 'Y'">
                </UploadFileRegister>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="board-bottom">
        <div class="board-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnSave">저장</button>
            <button type="button" class="ui-button ui-button__bg--lightgray"
              @click="closeAsyncPopup({ message: '닫기' })">닫기</button>
          </div>
        </div>
      </div>

      <template v-if="uploadParams.vFlagDownload === 'Y'">
        <br />

        <div class="ui-table__wrap">
          <table class="ui-table__reset ui-table__ver">
            <colgroup>
              <col style="width:10rem">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr>
                <th>다운로드</th>
                <td>
                  <UploadFileView :uploadid="uploadParams.vUploadCd" :recordid="uploadParams.vRecordid"
                    :is-img-thumb="uploadParams.vFlagDownload === 'Y'">
                  </UploadFileView>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </template>
    </div>
  </div>
</template>

<script>
import { reactive, inject, defineAsyncComponent } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'UploadAddFilePop',
  components: {
    UploadFileRegister: defineAsyncComponent(() => import('@/components/comm/UploadFileRegister.vue')),
    UploadFileView: defineAsyncComponent(() => import('@/components/comm/UploadFileView.vue')),
  },
  emits: ['callbackFunc', 'selectFunc'],
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vRecordid: '',
          vUploadCd: '',
          vFlagDownload: 'N',
        }
      }
    }
  },
  setup(props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncAlert', 'closeAsyncPopup'])
    const uploadParams = reactive({
      vRecordid: props.popParams.vRecordid,
      vUploadCd: props.popParams.vUploadCd,
      vFlagDownload: props.popParams.vFlagDownload,
      items: [],
    })

    const {
      insertAttachFile
    } = useLabCommon()


    const fnSave = async () => {
      const payload = {
        vRecordid: uploadParams.vRecordid,
        vUploadCd: uploadParams.vUploadCd,
        fileList: uploadParams.items,
      }

      const result = await insertAttachFile(payload)
      if (result === 'success') {
        await openAsyncAlert({ message: '저장되었습니다.' })
        context.emit('callbackFunc')
        context.emit('selectFunc', uploadParams)
        closeAsyncPopup({ message: '닫기' })
      }
    }

    return {
      t,
      commonUtils,
      closeAsyncPopup,
      uploadParams,
      fnSave
    }
  }
}
</script>