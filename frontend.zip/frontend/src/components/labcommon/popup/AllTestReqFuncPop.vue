<template>
  <div class="modal-content modal-content__width--122">
    <div class="modal-header">
      <div class="modal-title">시험의뢰 (기능성)</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({ message: '' })"></button>
    </div>
    <div class="modal-body">
      <div class="search-detail-table">
        <div class="search-detail-table__inner">
          <table class="ui-table__modal pd">
            <colgroup>
              <col style="width:10%">
              <col style="width:17%">
              <col style="width:auto">
              <col style="width:12%">
              <col style="width:17%">
              <col style="width:17%">
            </colgroup>
            <thead>
              <tr>
                <th>대표</th>
                <th>내용물코드/제품코드</th>
                <th>내용물명</th>
                <th>플랜트</th>
                <th>LOT</th>
                <th>비고 </th>
              </tr>
            </thead>
            <tbody>
            <template v-if="resData.contList?.length > 0">
                <tr v-for="(cvo, index) in resData.contList" :key="`tr_${index}`">
                  <td>
                    <div class="ui-label jc-c">
                     <ap-input-radio
                      v-model:model="payload.vRepContPkCd"
                      :value="cvo.vContPkCd"
                      :id="`flagNew_${index}`"
                      name="flagNew"
                      @click="fnClickRep(cvo)"
                    ></ap-input-radio>
                  </div>
                  </td>
                  <td>{{ cvo.vContCd }} / {{ cvo.vPrdCd }}</td>
                  <td>
                    <div class="tit__inner">
                      {{ cvo.vContNm }}
                    </div>
                    </td>
                  <td>{{ cvo.vPlantCd}}</td>
                  <td>
                    <div class="ui-select-block">
                      <ap-selectbox
                        v-model:value="cvo.vLotCd"
                        :options="cvo.subList"
                        :disabled="payload.vRepContPkCd !== cvo.vContPkCd"
                        codeKey="vLotCd"
                        codeNmKey="vLotNm"
                        @change="fnSelectOption($event, cvo)"
                    >
                    </ap-selectbox>
                  </div>
                  </td>
                  <td></td>
                </tr>
            </template>
            <template v-else>
                <tr>
                  <td colspan="6">
                    <div class="no-result">
                      {{ t('common.msg.no_data') }}
                    </div>
                  </td>
                </tr>
              </template>

            </tbody>
          </table>
        </div>
      </div>

      <div class="tableTitle mt-2">정보 입력</div>
      <div class="board-top mb-0">
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--120">완료요청일<span class="ui-require"><span class="for-a11y">(필수)</span></span></dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="search-form">
                <div class="search-form__inner">
                  <ap-date-picker
                    v-model:date="payload.vTrCompleteReqDt"
                    :read-only="true"
                  />
                </div>
              </div>

            </dd>
          </dl>
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">제형</dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="search-form">
                <div class="search-form__inner">
                  <ap-selectbox
                    v-model:value="payload.vDosageFormCd"
                    :options="codeGroupMaps['DOSAGE_FORM']"
                  />
                </div>
              </div>
            </dd>
          </dl>
        </div>

        <div class="search-bar__row search-bar__row--modal">
          
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">{{ payload.vTestTypeNm || '-'}}</dt>
            <dd class="search-bar__val search-bar__val--flexible" style="text-align: left;">
              {{ payload.vTestValue }}
            </dd>
          </dl>

          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">pH</dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <ap-input :is-number="false" v-model:value="payload.vTrPh"></ap-input>
            </dd>
          </dl>
        </div>

        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--120 mt-m3">시험목적<span class="ui-require"><span class="for-a11y">(필수)</span></span></dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="ui-textarea-box ui-textarea-box__height--100">
                <ap-text-area 
                  v-model:value="payload.vTrTestGoal"
                 :is-with-byte="true" 
                 :maxlength="2000"
                />
              </div>
            </dd>
          </dl>
        </div>

        <div class="search-bar__row search-bar__row--modal" style="margin-top: 35px;">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--120">시료보관조건<span class="ui-require"><span class="for-a11y">(필수)</span></span></dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="search-form">
                <div class="search-form__inner">
                  <ap-selectbox
                    v-model:value="payload.vTrSampleKeepCd"
                    :options="codeGroupMaps['TR_MRQ040_KEEP']"
                  />
                  <!-- <select class="ui-select ui-select__width--full">
                    <option>선택</option>
                  </select> -->
                </div>
              </div>
            </dd>
          </dl>
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">시료량<span class="ui-require"><span class="for-a11y">(필수)</span></span></dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <ap-input v-model:value="payload.vTrSampleAmt"/>
            </dd>
          </dl>
        </div>

        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--120">시험후 시료처리<span class="ui-require"><span class="for-a11y">(필수)</span></span></dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="search-form">
                <div class="search-form__inner">
                  <ap-selectbox
                    v-model:value="payload.vTrTestEndCd"
                    :options="codeGroupMaps['TR_MRQ040_END']"
                  />
                </div>
              </div>
            </dd>
          </dl>
          <dl class="search-bar__item search-bar__item--flexible">
          </dl>
        </div>

        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--120 mt-m3">메시지</dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="ui-textarea-box ui-textarea-box__height--100">
                <ap-text-area 
                  v-model:value="payload.vTrComment"
                  :is-with-byte="true" 
                  :maxlength="2000"
                />
              </div>
            </dd>
          </dl>
        </div>
      </div>

      <div class="board-bottom board-bottom__with--button" style="margin-top: 35px;">
        <div class="board-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--skyblue font-weight__300" @click="fnTestReqSave">시험의뢰</button>
            <button type="button" class="ui-button ui-button__bg--lightgray" @click="closeAsyncPopup({ message: '닫기' })">닫기</button>
          </div>
        </div>
      </div>

    </div>
  </div>
</template>

<script>
import { reactive, ref, inject } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useActions } from 'vuex-composition-helpers'
import { useTestReqCommon } from '@/compositions/labcommon/useTestReqCommon'

export default {
  name: 'AllTestReqFuncPop',
  components: {
  },
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: ''
        , vContPkCd: ''
        , nVersion: ''
        , vLotCd: ''
        , vPlantCd: ''
        , vMrqTypeCd: ''
        }
      }
    }
  },
  emits: ['selectFunc'],
  setup(props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { openAsyncConfirm, openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncConfirm', 'openAsyncAlert', 'closeAsyncPopup'])
    
    const flagLotCompleYn = ref('')

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const { 
      selectTestReqDetail
      , goSkinTestReqSave
    } = useTestReqCommon()

    const searchParams = {
      vLabNoteCd: props.popParams.vLabNoteCd
        // , vContPkCd: props.popParams.vContPkCd
        , vOtherContPkCd: props.popParams.vContPkCd
        , nVersion: props.popParams.nVersion
        , vLotCd: props.popParams.vLotCd
        , vPlantCd: props.popParams.vPlantCd
        , vMrqTypeCd: props.popParams.vMrqTypeCd
        , vGateCd: props.popParams.vGateCd
    } 

    const resData = ref({})

    const payload = ref({
      vTrCompleteReqDt: ''
      , vDosageFormCd: ''
      , vTrPh: ''
      , vTrTestGoal: ''
      , vTrSampleKeepCd: ''
      , vTrSampleAmt: ''
      , vTrTestEndCd: ''
      , vTrComment: ''
      , vLabNoteCd: searchParams.vLabNoteCd
      , vContPkCd: searchParams.vContPkCd
      , nVersion: searchParams.nVersion
      , vPlantCd: searchParams.vPlantCd
      , vMrqTypeCd: searchParams.vMrqTypeCd
      , vLotCd: ''
      , vContcd: ''
      , vRepContPkCd: ''
      , vFlagAction: 'SAVE_TEST_REQ'
      , vTrMrqTypeCd: ''
      , vTrGoalCd: ''
      , vGateCd:props.popParams.vGateCd
      , vTestType : ''
      , vTestTypeNm : ''
      , vTestValue : ''
    })

    const fnSelectOption = (value, vo) => {
      const lvo = vo.subList.find(svo => svo.vLotCd === value)

      if (lvo) {
        payload.value.vTestTypeNm = lvo.vTestTypeNm
        payload.value.vTestValue = lvo.vTestValue
        payload.value.vTrPh = lvo.vPh
        flagLotCompleYn.value = lvo.vFlagComplete

        vo.nVersion = lvo.nVersion
        vo.vLotNm = lvo.vLotNm
      } else {
        payload.value.vTestTypeNm = ''
        payload.value.vTestValue = ''
        payload.value.vTrPh = ''
        flagLotCompleYn.value = ''

        vo.nVersion = ''
        vo.vLotNm = ''
      }

    }

    const fnClickRep = (vo) => {
      const lotCd = vo?.vLotCd

      if (lotCd) {
        const lvo = vo.subList.find(svo => svo.vLotCd === lotCd)

        if (lvo) {
          payload.value.vTestType = lvo.vTestType
          payload.value.vTestTypeNm = lvo.vTestTypeNm
          payload.value.vTestValue = lvo.vTestValue
          payload.value.vTrPh = lvo.vPh
          flagLotCompleYn.value = lvo.vFlagComplete
        } else {
          payload.value.vTestType = ''
          payload.value.vTestTypeNm = ''
          payload.value.vTestValue = ''
          payload.value.vTrPh = ''
          flagLotCompleYn.value = ''
        }
      } else {
        payload.value.vTestType = ''
        payload.value.vTestTypeNm = ''
        payload.value.vTestValue = ''
        payload.value.vTrPh = ''
        flagLotCompleYn.value = ''
      }
    }

    const fnTestReqSave = async() => {
      const vRepContPkCd = payload.value.vRepContPkCd
      
      if (commonUtils.isEmpty(vRepContPkCd)) {
        await openAsyncAlert({ message: '대표 내용물을 선택해 주세요.' })
        return
      }
      
      const repCvo = resData.value.contList.find(cvo => cvo.vContPkCd === vRepContPkCd)

      if (repCvo) {
        const vRepLotCd = repCvo.vLotCd
      
        if (commonUtils.isEmpty(vRepLotCd)) {
          await openAsyncAlert({ message: 'Lot를 선택해 주세요.' })
          return
        }

        if (commonUtils.isEmpty(payload.value.vTrCompleteReqDt)) {
          await openAsyncAlert({ message: "완료요청일을 선택해 주세요." })
          return
        }

        if (commonUtils.isEmpty(payload.value.vTrTestGoal)) {
          await openAsyncAlert({ message: "시험목적을 입력해 주세요." })
          return
        }

        if (commonUtils.isEmpty(payload.value.vTrSampleKeepCd)) {
          await openAsyncAlert({ message: "시료보관조건을 선택해 주세요." })
          return
        }

        if (commonUtils.isEmpty(payload.value.vTrSampleAmt)) {
          await openAsyncAlert({ message: "시료량을 입력해 주세요." })
          return
        }

        if (commonUtils.isEmpty(payload.value.vTrTestEndCd)) {
          await openAsyncAlert({ message: "시험후 시료처리를 선택해 주세요." })
          return
        }

      }
      
      payload.value.vContcd = repCvo.vContCd || ''
      payload.value.vPlantCd = repCvo.vPlantCd || ''
      payload.value.nVersion = repCvo.nVersion || ''
      payload.value.vLotCd = repCvo.vLotCd || ''
      payload.value.vContPkCd = repCvo.vContPkCd || ''

      if(flagLotCompleYn.value !== "Y"){
        const confirmMessage = '<span style="font-weight:bold; color:red;">시험의뢰시 해당 Lot은 더이상 수정 할 수 없습니다.</span><br/>저장 하시겠습니까?'
        if (!await openAsyncConfirm({ message: confirmMessage })) {
          return
        }
      }

      const params = {
        ...payload.value,
        ...{
          contList: resData.value.contList.filter(cvo => cvo.vContPkCd === payload.value.vRepContPkCd) || []
        }
      }

      goSkinTestReqSave(params)
    }

    const init = async () => {
      findCodeList(['LAB_NOTE_PLANT, DOSAGE_FORM, TR_MRQ040_KEEP, TR_MRQ040_END'])
      //LAB_NOTE_PLANT:플랜트
      //DOSAGE_FORM:제형
      //TR_MRQ040_KEEP:시료보관조건
      //TR_MRQ040_END:시험후 시료처리

      //실험노트 정보 불러오기
      //실험노트 마스터 정보
      //실험노트 내용물 정보
      //실험노트 로트 정보
      resData.value = await selectTestReqDetail(searchParams)

      if (resData.value) {
        payload.value.vTrGoalCd = resData.value.vTrGoalCd
        payload.value.vTrMrqTypeCd = resData.value.vTrMrqTypeCd

        if (resData.value.contList) {
          const repCvo = resData.value.contList.find(cvo => cvo.vContPkCd === searchParams.vOtherContPkCd)
  
          if (repCvo) {
            payload.value.vRepContPkCd = repCvo.vContPkCd
          }
        }
        if (resData.value.lastTrVo) {
          payload.value.vDosageFormCd = resData.value.lastTrVo.vDosageFormCd
          payload.value.vTrTestGoal = resData.value.lastTrVo.vM040TestGoal
          payload.value.vTrSampleKeepCd = resData.value.lastTrVo.vM040SampleKeepCd
          payload.value.vTrSampleAmt = resData.value.lastTrVo.vM040SampleAmt
          payload.value.vTrTestEndCd = resData.value.lastTrVo.vM040TestEndCd
        }
      } else {
        closeAsyncPopup()
      }
      
    }

    init()

    return {
      t,
      searchParams,
      codeGroupMaps,
      closeAsyncPopup,
      selectTestReqDetail,
      resData,
      payload,
      fnSelectOption,
      fnClickRep,
      fnTestReqSave,
      goSkinTestReqSave,
      flagLotCompleYn,
    }
  }
}
</script>