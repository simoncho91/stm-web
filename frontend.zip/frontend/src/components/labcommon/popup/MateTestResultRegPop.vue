<template>
  <div class="modal-content modal-content__width--950" style="width: 150rem;">
    <div class="modal-header">
      <div class="modal-title">실험결과</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({ message: '' })"></button>
    </div>
    <div class="modal-body">
      <div class="modal-body__item">
        <div class="modal-des modal-des__red">
          *LOT에 대한 규격설정 값입니다.
        </div>
        <section class="search-bar p-0">
          <h2 class="for-a11y">검색</h2>

          <div class="search-bar__left">

            <div class="search-bar__row">
              <dl class="search-bar__item">
                <dd class="search-bar__val">
                  <div class="form-flex">
                    <div class=" form-flex-cell form-flex__cell--5">
                      <div class="ui-select-block">
                        <ap-selectbox v-model:value="info.lotVO.vTestType"
                          inputClass="ui-select ui-select__width--110 ui-select__color--deepgray"
                          :defaultBlank="{ blank: false }" :options="searchParams.testCdList" />
                      </div>
                    </div>
                    <div class="form-flex-cell form-flex__cell--5">
                      <div class="search-form">
                        <div class="search-form__inner">
                          <ap-input v-model:value="info.lotVO.vTestValue" class="ui-input ui-input__width--318"
                            placeholder="제목을 입력하세요." @click="onPlusMinusCopy(1)" />
                          <button type="button" class="button-search" @click="onPlusMinusCopy()">±입력</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </dd>
              </dl>
              <dl class="search-bar__item search-bar__item--flexible ml-20">
                <dt class="search-bar__key">pH</dt>
                <dd class="search-bar__val search-bar__val--flexible">
                  <ap-input v-model:value="info.lotVO.vPh" class="ui-input ui-input__width--full"
                    @click="onPlusMinusCopy(2)" />
                </dd>
              </dl>
            </div>

            <div class="search-bar__col">

              <dl class="search-bar__item">
                <dt class="search-bar__key">실험결과 LOT 메모</dt>
                <dd class="search-bar__val">
                  <div class="ui-textarea-box ui-textarea-box__height--100">
                    <textarea v-model="info.lotVO.vLotTestMemo" class="ui-textarea"></textarea>
                  </div>
                </dd>
              </dl>
            </div>
          </div>

        </section>

        <div class="board-bottom ">
          <div class="board-bottom__inner">
            <div class="ui-buttons ml-auto ui-buttons__right">
              <button type="button" class="ui-button ui-button__bg--skyblue font-weight__300"
                @click="onTestSave">저장</button>
            </div>
          </div>
        </div>

      </div>

      <div class="modal-body__item">
        <div class="modal-des modal-des__red">
          *실제 측정날짜를 입력해야만 저장이 됩니다.
        </div>

        <section class="search-bar p-0">
          <h2 class="for-a11y">검색</h2>

          <div class="search-bar__left">

            <div class="search-bar__row">
              <dl class="search-bar__item">
                <dt class="search-bar__key search-bar__key--width-107">그램</dt>
                <dd class="search-bar__val">
                  <div class="ui-radio__list">
                    <div class="ui-radio__inner">
                      <div v-for="(gram, gIdx) in info.gramList" :key="gIdx" class="ui-radio-block">
                        <ap-input-radio v-model:model="info.vGramCd" :value="gram.vGramCd" :id="'vGramCd_' + gIdx"
                          name="vGramCd" :label="gram.nGram" />
                      </div>
                    </div>
                  </div>
                </dd>
              </dl>
            </div>
            <div class="search-bar__row">
              <dl class="search-bar__item">
                <dt class="search-bar__key search-bar__key--width-107">실험기간</dt>
                <dd class="search-bar__val">
                  <ap-date-picker-range v-model:startDt="dateParams.vTestStDt" v-model:endDt="dateParams.vTestEnDt"
                    :read-only="true" :resetable="false" :is-week-term="true"
                    styleClass="ui-input ui-input__date ui-input__width--130" @onWeekTerm="onWeekTerm"
                    @onChange="onDateChange" />
                </dd>
              </dl>
              <dl class="" style="width: 100%; padding-right: 0; margin: 0; padding: 0;">
                <dd class="search-bar__val" style="width: auto;">
                  <div class="board-bottom ">
                    <div class="ui-buttons ml-auto ui-buttons__right">
                      <button type="button" class="ui-button ui-button__bg--blue font-weight__300"
                        @click="onStabilitySettingPop">안정도설정</button>
                    </div>
                  </div>
                </dd>
              </dl>

            </div>

          </div>

        </section>

        <div class="mt-15">
          <div class="ui-table__wrap ui-table__scroll-x" style="min-height: 41rem;">
            <table
              class="ui-table ui-table__material-pop  text-center ui-table__th--border-radius--0 ui-table__border-all"
              :style="info.titleList?.length > 0 ? 'width: 150rem;' : ''">
              <colgroup>
                <col style="width:6%;">
                <col style="width:10%;">
                <col style="width:10%;">
                <col style="width:10%;">
                <col v-for="(title, tIdx) in info.titleList" :key="tIdx" style="width:auto;">
                <col style="width:5%;">

              </colgroup>
              <thead>
                <tr>
                  <th rowspan="2" class="border-left">날짜</th>
                  <th rowspan="2">실제 측정날짜</th>
                  <th rowspan="2">
                    {{ searchParams.testCdList.find(test => test.vSubCode === info.lotVO.vTestType)?.vSubCodenm }}
                  </th>
                  <th rowspan="2">ph</th>
                  <th v-if="info.titleList?.length > 0" :colspan="info.titleList?.length"
                    class="th-height__32 border-bottom">안정도</th>
                  <th rowspan="2">저장</th>
                </tr>
                <tr>
                  <th v-for="(title, tIdx) in info.titleList" :key="tIdx" class="th-height__28"
                    :class="tIdx > 0 ? 'border-left__none' : ''">{{ title.vSubCodeNm }} </th>
                </tr>
              </thead>
              <tbody v-if="info.gramVO.vTestStDt && info.gramVO.vTestEnDt">
                <template v-for="(gramTr, gtIdx) in info.gramTrList" :key="gtIdx">
                  <tr>
                    <td v-if="gramTr.vIsShow"
                      :rowspan="info?.titleList?.length > 0 ? (2 * gramTr.nCntNum) : gramTr.nCntNum">
                      <div class="material-pop__date">
                        {{ gramTr.nSeqno === 1 ? '초기' : gramTr.nSeqno === 2 ? '익일' : gramTr.nSeqno === 3 ? '3일' :
                          (gramTr.nSeqno - 3) + '주' }}
                        <br><span class="material-pop__date--gray">{{ gramTr.vPlanDt }}</span>
                      </div>
                    </td>
                    <td :rowspan="info?.titleList?.length > 0 ? 2 : 1"
                      @contextmenu.prevent="onContextMenu($event, gramTr)">
                      <div class="form-flex form-flex__col">
                        <div class="form-flex-cell">
                          <ap-date-picker v-if="gramTr.vFlagTestPass !== 'Y'" v-model:date="gramTr.vResTestDt"
                            :disabled="gramTr.vFlagSave === 'Y' || searchParams.vFlagDisabled === 'Y'"
                            inputClass="ui-input ui-input__date ui-input__width--130" />
                        </div>
                        <div class="form-flex-cell mt-10">
                          <div class="ui-checkbox__list">
                            <div class="ui-checkbox__inner">
                              <ap-input-check v-model:model="gramTr.vFlagTestPass" :id="'gramTrChk_' + gtIdx" :value="'Y'"
                                :falseValue="'N'"
                                :disabled="gramTr.vFlagSave === 'Y' || searchParams.vFlagDisabled === 'Y'" label="측정불가" />
                            </div>
                          </div>
                        </div>
                      </div>
                    </td>
                    <td :rowspan="info?.titleList?.length > 0 ? 2 : 1" style="text-align: left;">
                      <template v-if="gramTr.vFlagSave === 'Y' || searchParams.vFlagDisabled === 'Y'">
                        {{ gramTr.nResCol01 }}
                      </template>
                      <ap-input v-else v-model:value="gramTr.nResCol01" :isNumber="true" :point="6"
                        inputClass="ui-input ui-input__width--130" />
                    </td>
                    <td :rowspan="info?.titleList?.length > 0 ? 2 : 1" style="text-align: left;">
                      <template v-if="gramTr.vFlagSave === 'Y' || searchParams.vFlagDisabled === 'Y'">
                        {{ gramTr.nResCol02 }}
                      </template>
                      <ap-input v-else v-model:value="gramTr.nResCol02" :isNumber="true" :point="6"
                        inputClass="ui-input ui-input__width--130" />
                    </td>
                    <td v-for="(title, tIdx) in info.titleList" :key="tIdx">
                      <div class="ui-buttons__material-result">
                        <!-- 전달사항 :: 활성화 시 is-active 붙습니다. -->
                        <button class="ui-button__material-result ui-button__material-result--o" :class="info.valueList.find(val =>
                          val.vGramTrCd === gramTr.vGramTrCd &&
                          val.vLotCd === searchParams.vLotCd &&
                          val.vStabilityCd === title.vSubCode)?.vFlagStability === 'Y' ? 'is-active' : ''"
                          :disabled="gramTr.vFlagSave === 'Y' || searchParams.vFlagDisabled === 'Y'"
                          @click="onStabilityChange(gramTr.vGramTrCd, title.vSubCode, 'Y')"></button>
                        <button class="ui-button__material-result ui-button__material-result--triangle" :class="info.valueList.find(val =>
                          val.vGramTrCd === gramTr.vGramTrCd &&
                          val.vLotCd === searchParams.vLotCd &&
                          val.vStabilityCd === title.vSubCode)?.vFlagStability === 'C' ? 'is-active' : ''"
                          :disabled="gramTr.vFlagSave === 'Y' || searchParams.vFlagDisabled === 'Y'"
                          @click="onStabilityChange(gramTr.vGramTrCd, title.vSubCode, 'C')"></button>
                        <button class="ui-button__material-result ui-button__material-result--x" :class="info.valueList.find(val =>
                          val.vGramTrCd === gramTr.vGramTrCd &&
                          val.vLotCd === searchParams.vLotCd &&
                          val.vStabilityCd === title.vSubCode)?.vFlagStability === 'N' ? 'is-active' : ''"
                          :disabled="gramTr.vFlagSave === 'Y' || searchParams.vFlagDisabled === 'Y'"
                          @click="onStabilityChange(gramTr.vGramTrCd, title.vSubCode, 'N')"></button>
                      </div>
                    </td>
                    <td :rowspan="info?.titleList?.length > 0 ? 2 : 1">
                      <div class="ui-buttons ml-auto ui-buttons__right">
                        <button type="button" class="ui-button font-weight__300"
                          :class="gramTr.vFlagSave === 'Y' ? 'ui-button__bg--gray' : 'ui-button__bg--skyblue'"
                          :disabled="searchParams.vFlagDisabled === 'Y'" @click="onStabilitySave(gramTr)">
                          {{ gramTr.vFlagSave === 'Y' ? '변경' : '저장' }}
                        </button>
                      </div>
                    </td>
                  </tr>
                  <tr v-if="info?.titleList?.length > 0">
                    <td :colspan="info?.titleList?.length" style="text-align: left;">
                      <template v-if="gramTr.vFlagSave === 'Y' || searchParams.vFlagDisabled === 'Y'">
                        {{ gramTr.vStabilityNote }}
                      </template>
                      <ap-input v-else v-model:value="gramTr.vStabilityNote"
                        inputClass="ui-input ui-input__width--full" />
                    </td>
                  </tr>
                </template>
              </tbody>
              <tbody v-else>
                <tr>
                  <td colspan="13">
                    <div class="no-result">실험기간을 입력해 주세요.</div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

    </div>

    <context-menu v-model:show="contextMenu.isShow" :options="contextMenu">
      <context-menu-item label="실험결과 추가" @click="onContextMenuItemClick('ADD_TEST_TR')">
        <template #icon><img src="/src/assets/images/icon/icon-insert.png" style="width: 16px;"></template>
      </context-menu-item>
      <context-menu-item label="실험결과 삭제" @click="onContextMenuItemClick('DELETE_TEST_TR')">
        <template #icon><img src="/src/assets/images/icon/icon-delete.png" style="width: 16px;"></template>
      </context-menu-item>
    </context-menu>
    <teleport to="#common-modal-sub" v-if="popContent">
      <ap-popup>
        <component :is="popContent" :pop-params="popupParams" @selectFunc="popSelectFunc" @closeFunc="closeFunc" />
      </ap-popup>
    </teleport>
    <div id="common-modal-sub"></div>
  </div>
</template>

<script>
import { defineAsyncComponent, reactive, ref, inject, onUpdated } from 'vue'
import { useMaterialCommon } from '@/compositions/labcommon/useMaterialCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'MateTestResultRegPop',
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    StabilitySettingPop: defineAsyncComponent(() => import('@/components/labcommon/popup/StabilitySettingPop.vue')),
  },
  emits: ['selectFuncMateAndGrp'],
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: '',
          vContPkCd: '',
          nVersion: '',
          vLotCd: '',
          testCdList: [],
          vFlagDisabled: '',
          sum: -1,
        }
      }
    }
  },
  setup(props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const {
      openAsyncConfirm, openAsyncAlert, openAsyncPopup, closeAsyncPopup
    } = useActions(['openAsyncConfirm', 'openAsyncAlert', 'openAsyncPopup', 'closeAsyncPopup'])
    const searchParams = reactive({
      vLabNoteCd: props.popParams.vLabNoteCd,
      vContPkCd: props.popParams.vContPkCd,
      nVersion: props.popParams.nVersion,
      vLotCd: props.popParams.vLotCd,
      testCdList: props.popParams.testCdList,
      vFlagDisabled: props.popParams.vFlagDisabled,
      vGramCd: '',
      vTestStDt: '',
      vTestEnDt: '',
      sum: props.popParams.sum,
    })
    const dateParams = reactive({
      vTestStDt: '',
      vTestEnDt: '',
      vTerm: '',
    })
    const compareParams = reactive({
      vTestStDt: '',
      vTestEnDt: '',
      vIsChange: false,
    })
    const plusMinus = reactive({
      inputId: '',
    })
    const info = ref({
      contVO: {},
      gramList: [],
      gramTrList: [],
      gramVO: {},
      lotVO: {},
      titleList: [],
      vGramCd: '',
    })
    const popContent = ref(null)
    const popSelectFunc = ref(null)
    const popupParams = ref({})
    const closeFunc = ref({})

    const selectedRow = reactive({
      gramTr: {},
      delGramTrCdList: [],
    })
    const contextMenu = reactive({
      isShow: false,
      zIndex: 1100,
      minWidth: 230,
      x: 500,
      y: 200,
    })

    const {
      selectLabNoteGramList,
      insertElabLotMemo,
      insertLabNoteTestResult,
    } = useMaterialCommon()

    const init = async () => {
      info.value = await selectLabNoteGramList(searchParams)

      if (info.value.constructor !== Object) {
        return
      }

      if (!info.value.lotVO.vTestType) {
        info.value.lotVO.vTestType = 'MTI00_01'
      }

      if (!info.value.lotVO.vTestValue || info.value.lotVO.vTestValue === '') {
        info.value.lotVO.vTestValue = '예시) 0000±0000, Spindle: 64번, 12rpm, 2min'
      }

      if (info.value.gramVO.vTestStDt) {
        dateParams.vTestStDt = commonUtils.changeStrDatePattern(info.value.gramVO.vTestStDt)
        compareParams.vTestStDt = dateParams.vTestStDt
      }
      if (info.value.gramVO.vTestEnDt) {
        dateParams.vTestEnDt = commonUtils.changeStrDatePattern(info.value.gramVO.vTestEnDt)
        compareParams.vTestEnDt = dateParams.vTestEnDt
      }

      let preKey = ''
      info.value.gramTrList = info.value.gramTrList.map(gramTr => {
        const valueLen = info.value.valueList.filter(val => val.vGramTrCd === gramTr.vGramTrCd).length
        const newValueList = []

        if (valueLen === 0) {
          info.value.titleList.map(title => {
            newValueList.push({
              vGramTrCd: gramTr.vGramTrCd,
              vKey: gramTr.vGramTrCd + '_' + title.vLotCd + '_' + title.vSubCode,
              vLotCd: title.vLotCd,
              vStabilityCd: title.vSubCode,
            })
          })

          info.value.valueList = [
            ...info.value.valueList,
            ...newValueList,
          ]
        }

        let vIsShow = false
        if (gramTr.vKey !== preKey) {
          vIsShow = true
        }
        preKey = gramTr.vKey

        return {
          ...gramTr,
          vIsShow,
        }
      })

      searchParams.vGramCd = info.value.gramVO.vGramCd
    }

    init()

    const onWeekTerm = async (o) => {
      if (!dateParams.vTestStDt || dateParams.vTestStDt === '') {
        openAsyncAlert({ message: '시작일자를 입력해 주세요.' })
        return
      }

      let addDay = o === 'N' ? 1 : o === '1' ? 7 : o === '2' ? 14 : o === '3' ? 21 : o === '4' ? 28 : 0
      const vTestStDt = commonUtils.getOnlyNumber(dateParams.vTestStDt)
      dateParams.vTestStDt = commonUtils.changeStrDatePattern(vTestStDt)
      dateParams.vTestEnDt = commonUtils.getAddDay(vTestStDt, addDay)
      compareParams.vTestStDt = commonUtils.getOnlyNumber(dateParams.vTestStDt)
      compareParams.vTestEnDt = commonUtils.getOnlyNumber(dateParams.vTestEnDt)

      if (dateParams.vTerm !== o) {
        dateParams.vTerm = o

        await onTestResultSave(info.value.gramTrList.filter(gramTr => gramTr.vResTestDt || gramTr.vFlagTestPass === 'Y'))
      }

      init()
    }

    const onDateChange = async (o, t) => {
      if (o) {
        if (t === 'S') {
          if (commonUtils.getOnlyNumber(o) !== commonUtils.getOnlyNumber(compareParams.vTestStDt)) {
            compareParams.vTestStDt = commonUtils.getOnlyNumber(o)
            compareParams.vIsChange = true
          }
        }
        else {
          if (commonUtils.getOnlyNumber(o) !== commonUtils.getOnlyNumber(compareParams.vTestEnDt)) {
            compareParams.vTestEnDt = commonUtils.getOnlyNumber(o)
            compareParams.vIsChange = true
          }
        }

        if (compareParams.vIsChange) {
          compareParams.vIsChange = false

          await onTestResultSave(info.value.gramTrList.filter(gramTr => gramTr.vResTestDt || gramTr.vFlagTestPass === 'Y'))

          init()
        }
      }
    }

    const onPlusMinusCopy = (num = 0) => {
      if (num > 0) {
        plusMinus.inputId = num
      }
      else {
        if (plusMinus.inputId === 1) {
          info.value.lotVO.vTestValue = (info.value.lotVO.vTestValue || '') + ' ±'
        }
        else {
          info.value.lotVO.vPh = (info.value.lotVO.vPh || '') + ' ±'
        }
      }
    }

    const onTestSave = async () => {
      const message = await insertElabLotMemo({
        vLotCd: info.value.lotVO.vLotCd,
        nSeqno: 1,
        vTitle: '안정도',
        vContent: info.value.lotVO.vLotTestMemo,
        vFlagStability: info.value.lotVO.vFlagStability,
        vFlagDel: 'N',
        vTestType: info.value.lotVO.vTestType,
        vTestValue: info.value.lotVO.vTestValue,
        vPh: info.value.lotVO.vPh,
      })

      if (message) {
        openAsyncAlert({ message: '저장 되었습니다.' })
      }
    }

    const onStabilityChange = (vGramTrCd, vSubCode, vFlagStability) => {
      info.value.valueList.map(val => {
        if (val.vGramTrCd === vGramTrCd &&
          val.vLotCd === searchParams.vLotCd &&
          val.vStabilityCd === vSubCode) {
          val.vFlagStability = vFlagStability
        }
      })
    }

    const onStabilitySave = async (o) => {
      if (o.vFlagSave === 'Y') {
        o.vFlagSave = 'N'
      }
      else {
        if (searchParams.sum !== 100) {
          openAsyncAlert({ message: '원료 배합 합이 100이 아닙니다.' })
          return
        }
        else if (!o.vFlagTestPass && !o.vResTestDt) {
          openAsyncAlert({ message: '실제 측정날짜를 입력하여 주십시오.' })
          return
        }

        // let vFlagFristSave = 'N'
        // if (info.value.lotVO.vFlagComplete !== 'Y') {
        //   const confirmMessage = '<span style="font-weight:bold; color:red;">저장시 해당 Lot은 더이상 수정 할 수 없습니다.</span><br/>저장 하시겠습니까?'
        //   if (!await openAsyncConfirm({ message: confirmMessage })) {
        //     return
        //   }
        //   else {
        //     vFlagFristSave = 'Y'
        //   }
        // }

        o.vFlagSave = 'Y'

        await onTestResultSave(info.value.gramTrList.filter(gramTr => gramTr.vGramTrCd === o.vGramTrCd))

        searchParams.vGramCd = ''
        init()
      }
    }

    const onTestResultSave = async (gramTrList = []) => {
      const testResultGramTrList = gramTrList.map(gramTr => {
        return {
          ...gramTr,
          flagStabilityList: info.value.valueList
            .filter(val => val.vGramTrCd === gramTr.vGramTrCd)
            .map(val => {
              return {
                vStabilityCd: val.vStabilityCd,
                vFlagStability: val.vFlagStability || null,
              }
            }),
        }
      })

      await insertLabNoteTestResult({
        vLabNoteCd: info.value.contVO.vLabNoteCd,
        vContPkCd: info.value.contVO.vContPkCd,
        vLotCd: info.value.lotVO.vLotCd,
        nVersion: info.value.verVO.nVersion,
        vTestType: info.value.lotVO.vTestType,
        vTestValue: info.value.lotVO.vTestValue,
        vPh: info.value.lotVO.vPh,
        vLotTestMemo: info.value.lotVO.vLotTestMemo,
        vFlagStability: info.value.lotVO.vFlagStability,
        vGramCd: info.value.gramVO.vGramCd,
        vTestStDt: commonUtils.getOnlyNumber(dateParams.vTestStDt),
        vTestEnDt: commonUtils.getOnlyNumber(dateParams.vTestEnDt),
        stabilityCdList: info.value.titleList.map(title => title.vSubCode),
        delGramTrCdList: selectedRow.delGramTrCdList,
        testResultGramTrList,
        vContCd: info.value.contVO.vContCd || '',
        vContNm: info.value.contVO.vContNm,
        vLotNm: info.value.lotVO.vLotNm,
      })

      selectedRow.delGramTrCdList = []
    }

    const closeStabilitySettingPop = () => {
      popContent.value = null

      init()
    }

    const onStabilitySettingPop = () => {
      popContent.value = 'StabilitySettingPop'
      popupParams.value = {
        vLabNoteCd: info.value.contVO.vLabNoteCd,
        vLotCd: info.value.lotVO.vLotCd,
      }
      closeFunc.value = closeStabilitySettingPop

      // openAsyncPopup()
      //   .then(res => {
      //   })
      //   .catch(err => {
      //     console.log(err)
      //   })
      //   .finally(() => {
      //     popContent.value = null
      //   })
    }

    const onContextMenu = (e, o) => {
      contextMenu.x = e.x
      contextMenu.y = e.y
      contextMenu.isShow = true

      selectedRow.gramTr = o
    }

    const onContextMenuItemClick = (e) => {
      if (e === 'ADD_TEST_TR') {
        const newGramTrList = []
        let vOriKey = ''

        info.value.gramTrList.map(gramTr => {
          newGramTrList.push(gramTr)

          if (gramTr.vGramTrCd === selectedRow.gramTr.vGramTrCd) {
            const gramTrLen = info.value.gramTrList.length + 1
            vOriKey = selectedRow.gramTr.vOriKey || selectedRow.gramTr.vKey

            newGramTrList.push({
              vGramTrCd: 'tmp_gram_tr_' + gramTrLen,
              vKey: selectedRow.gramTr.vGramCd + '_' + gramTrLen,
              vOriKey,
              nSeqno: selectedRow.gramTr.nSeqno,
              vGramCd: selectedRow.gramTr.vGramCd,
              vPlanDt: selectedRow.gramTr.vPlanDt,
              vResTestDt: null,
            })
          }
        })

        info.value.gramTrList = newGramTrList.map(gramTr => {
          return {
            ...gramTr,
            nCntNum: gramTr.vKey === vOriKey ? gramTr.nCntNum + 1 : gramTr.nCntNum,
          }
        })
      }
      else if (e === 'DELETE_TEST_TR') {
        let keyDupl = 0
        for (let i = 0; i < info.value.gramTrList.length; i++) {
          if (info.value.gramTrList[i].vKey === selectedRow.gramTr.vKey) {
            if (info.value.gramTrList[i].vGramTrCd === selectedRow.gramTr.vGramTrCd) {
              break
            }

            keyDupl++
          }
        }

        if (keyDupl === 0 && selectedRow.gramTr.nCntNum) {
          openAsyncAlert({ message: '각 계획날짜의 처음 열은 삭제 하실수 없습니다.' })
          return
        }

        info.value.gramTrList = info.value.gramTrList
          .filter(gramTr => gramTr.vGramTrCd !== selectedRow.gramTr.vGramTrCd)
          .map(gramTr => {
            const vOriKey = selectedRow.gramTr.vOriKey || selectedRow.gramTr.vKey
            return {
              ...gramTr,
              nCntNum: gramTr.vKey === vOriKey ? gramTr.nCntNum - 1 : gramTr.nCntNum,
            }
          })

        selectedRow.delGramTrCdList.push(selectedRow.gramTr.vGramTrCd)
      }

      selectedRow.gramTr = {}
    }

    onUpdated(() => {
      const contextMenuWrap = document.querySelector('.mx-context-menu-items')
      if (contextMenuWrap) {
        const items = contextMenuWrap.querySelectorAll('.mx-item-row')
        for (let i = 0; i < items.length; i++) {
          const sapn = items[i].querySelector('.label')
          if (sapn) {
            sapn.style.padding = '5px 0px 5px 0px'
          }
        }
      }
    })

    return {
      t,
      searchParams,
      dateParams,
      info,
      popContent,
      popSelectFunc,
      popupParams,
      contextMenu,
      closeFunc,
      onWeekTerm,
      onDateChange,
      onPlusMinusCopy,
      onTestSave,
      onStabilityChange,
      onStabilitySave,
      onStabilitySettingPop,
      onContextMenu,
      onContextMenuItemClick,
      closeAsyncPopup,
    }
  }
}
</script>