<template>
  <div class="modal-content" style="width: 110rem;">
    <div class="modal-header">
      <div class="modal-title">플랜트별 원료 단가 & 가격비</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({ message: '' })"></button>
    </div>
    <div class="modal-body">
      <div class="myboard-top d-flex">
        <div style="text-align: left;">
          *해당 원료 단가 기준은 1g입니다.<br />
          *플랜트를 원료배합에 적용 하시려면 해당 플랜트 코드를 클릭하시면 됩니다.<br />
          *용량 변경 후 Enter 키를 누르시면 변경된 용량으로 가격비가 계산됩니다.
        </div>
      </div>
      <div class="modal-body__scroll">
        <div class="search-depart-table">
          <div class="search-depart-table__inner">
            <table class="ui-table__td--40">
              <colgroup>
                <col style="width:13rem">
                <col style="width:auto">
                <col style="width:13rem">
                <col style="width:auto">
              </colgroup>
              <tbody>
                <tr>
                  <th>LOT</th>
                  <td>
                    <ap-selectbox v-model:value="searchParams.vLotCd" :defaultBlank="{ blank: false }" :options="lotList"
                      codeKey="vLotCd" codeNmKey="vLotNm"></ap-selectbox>
                  </td>
                  <th>제품 용량</th>
                  <td>
                    <ap-input v-model:value="searchParams.nCapacity" style="width:18rem"
                      @keypress-enter="onCapacity"></ap-input> g
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div class="contents-tab__body--item mt-25">
          <div class="ui-table__wrap">
            <table class="ui-table text-center ui-table__td--40">
              <colgroup>
                <col style="width:8rem">
                <col style="width:10rem">
                <col style="width:10rem">
                <col v-for="(code, cdIdx) in codeList" :key="cdIdx" style="width:auto">
              </colgroup>
              <thead>
                <tr>
                  <th>No</th>
                  <th>원료코드</th>
                  <th>함량</th>
                  <th v-for="(code, cdIdx) in codeList" :key="cdIdx">
                    <img v-if="searchParams.vPlantCd !== '' && searchParams.vPlantCd === code.vSubCode"
                      src="/src/assets/images/icon/icon-select.png">
                    <a href="javascript:void(0)" class="tit-link" @click="onClick(code)">[{{ code.vSubCode
                    }}]</a><br />{{ code.vSubCodenm }}
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(mate, index) in mateList" :key="index">
                  <td>{{ index + 1 }}</td>
                  <td>{{ mate.vMateCd }}</td>
                  <td>{{ mate.rateList?.[0].nRate }}</td>
                  <td v-for="(code, cdIdx) in codeList" :key="cdIdx">
                    {{ code.vSubCode === 'CN20' ? mate.rateList?.[0].vPlantCn20 :
                      code.vSubCode === '1110' ? mate.rateList?.[0].vPlant1110 :
                        code.vSubCode === '1111' ? mate.rateList?.[0].vPlant1111 :
                          code.vSubCode === '1113' ? mate.rateList?.[0].vPlant1113 :
                            code.vSubCode === '1510' ? mate.rateList?.[0].vPlant1510 : '' }}
                  </td>
                </tr>
              </tbody>
              <tfoot>
                <tr style="height:4rem">
                  <th colspan="2">가격비 합계</th>
                  <th>{{ rateList?.[0].nRate }}</th>
                  <th v-for="(code, cdIdx) in codeList" :key="cdIdx">
                    {{ code.vSubCode === 'CN20' ? rateList?.[0].vPlantRateCn20 :
                      code.vSubCode === '1110' ? rateList?.[0].vPlantRate1110 :
                        code.vSubCode === '1111' ? rateList?.[0].vPlantRate1111 :
                          code.vSubCode === '1113' ? rateList?.[0].vPlantRate1113 :
                            code.vSubCode === '1510' ? rateList?.[0].vPlantRate1510 : '' }}
                  </th>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

        <div class="board-bottom board-bottom__with--button">
          <div class="board-bottom__inner">
            <div class="ui-buttons ui-buttons__right">
              <button type="button" class="ui-button ui-button__bg--lightgray"
                @click="closeAsyncPopup({ message: '닫기' })">닫기</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { reactive, ref, inject } from 'vue'
import { useMaterialCommon } from '@/compositions/labcommon/useMaterialCommon'
import { useCode } from '@/compositions/useCode'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'AllPlantPricePop',
  components: {
  },
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: '',
          vContPkCd: '',
          nVersion: '',
          vLotCd: '',
          nCapacity: '',
          vPlantCd: '',
        }
      }
    }
  },
  emits: ['selectFunc'],
  setup(props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { openAsyncConfirm, openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncConfirm', 'openAsyncAlert', 'closeAsyncPopup'])
    const lotList = ref(null)
    const mateList = ref(null)
    const rateList = ref(null)
    const codeList = ref(null)
    const searchParams = reactive({
      vLabNoteCd: props.popParams.vLabNoteCd,
      vContPkCd: props.popParams.vContPkCd,
      nVersion: props.popParams.nVersion,
      vLotCd: props.popParams.vLotCd,
      nCapacity: props.popParams.nCapacity,
      vPlantCd: props.popParams.vPlantCd,
    })

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const {
      selectLabNoteAllPlantRateAndPrice,
      updateLabNoteApplyPlant,
    } = useMaterialCommon()

    const init = async () => {
      findCodeList(['LAB_NOTE_PLANT'])

      const response = await selectLabNoteAllPlantRateAndPrice(searchParams)
      lotList.value = response.lotList
      mateList.value = response.mateList
      rateList.value = response.rateList

      mateList.value = mateList.value.map(mate => {
        return {
          ...mate,
          rateList: rateList.value.filter(rate => mate.vMatePkCd === rate.vMatePkCd),
        }
      })

      rateList.value = rateList.value.filter(rate => rate.vKey === 'SUM')
      codeList.value = commonUtils.getCodeList(codeGroupMaps, 'LAB_NOTE_PLANT', 'U', null, null)
    }

    const onCapacity = (o) => {
      searchParams.nCapacity = o
      init()
    }

    const onClick = async (o) => {
      const message = 'Plant : ' + [o.vSubCode] + o.vSubCodenm + '<br/>' + '제품용량 : ' + searchParams.nCapacity + '<br/>적용하시겠습니까?'
      const answer = await openAsyncConfirm({ message })
      if (!answer) {
        return
      }

      const response = await updateLabNoteApplyPlant({
        vLabNoteCd: searchParams.vLabNoteCd,
        vContPkCd: searchParams.vContPkCd,
        vPlantCd: o.vSubCode,
        nCapacity: searchParams.nCapacity,
      })

      await openAsyncAlert({ message: response })
      context.emit('selectFunc')
      closeAsyncPopup({ message: '' })
    }

    init()

    return {
      t,
      searchParams,
      codeGroupMaps,
      lotList,
      mateList,
      rateList,
      codeList,
      onCapacity,
      onClick,
      closeAsyncPopup,
    }
  }
}
</script>