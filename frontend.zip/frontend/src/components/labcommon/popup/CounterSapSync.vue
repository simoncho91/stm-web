<template>
  <div class="basic-info__table mt-15">
    <table class="ui-table__contents">
      <colgroup>
        <col style="width: 15rem">
        <col style="width: auto">
      </colgroup>
      <tbody>
        <tr>
          <th>내용물코드</th>
          <td>
            <div class="form-flex">
              <div class="form-flex__cell--5">
                <ap-selectbox
                  v-model:value="params.vPlantCd"
                  input-class="ui-input__width--200"
                  :options="codeGroupMaps['LAB_NOTE_PLANT']"
                >
                </ap-selectbox>
              </div>
              <div class="form-flex__cell--5">
                <div class="search-form">
                  <div class="search-form__inner">
                    <ap-input
                      v-model:value="params.vContCd"
                      input-class="ui-input__width--200"
                      @keypress-enter="fnSapSync()"
                    >
                    </ap-input>
                    <button type="button" class="button-search" @click="fnSapSync()">SAP SYNC</button>
                  </div>
                </div>
              </div>
            </div>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
import { ref } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useSkincareCommon } from '@/compositions/skincare/useSkincareCommon'
import { useMakeupCommon } from '@/compositions/makeup/useMakeupCommon'
import { useHbdCommon } from '@/compositions/hbd/useHbdCommon'
import { useQdrugCommon } from '@/compositions/qdrug/useQdrugCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'CounterSapSync',
  props: {
    searchParams: {
      type: Object,
      default: () => {
        return {
          vNoteType: '',
          vPlantCd: ''
        }
      }
    }
  },
  setup (props) {
    const { openAsyncAlert } = useActions(['openAsyncAlert'])
    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const params = ref({
      vPlantCd: props.searchParams.vPlantCd,
      vContCd: ''
    })

    const {
      insertSkinCounterSapSync
    } = useSkincareCommon()

    const {
      insertMakeupCounterSapSync
    } = useMakeupCommon()

    const {
      insertHbdCounterSapSync
    } = useHbdCommon()

    const {
      insertQdrugCounterSapSync
    } = useQdrugCommon()

    const fnSapSync = () => {
      const contCd = params.value.vContCd

      if (!(contCd.indexOf('3') === 0 || contCd.indexOf('4') === 0 || contCd.indexOf('J') === 0) || contCd.length < 7) {
        openAsyncAlert({ message: '올바른 내용물 코드가 아닙니다.' })
        return
      }

      if (props.searchParams.vNoteType === 'SC') {
        insertSkinCounterSapSync(params.value)
      } else if (props.searchParams.vNoteType === 'MU') {
        insertMakeupCounterSapSync(params.value)
      } else if (props.searchParams.vNoteType === 'HBO') {
        insertHbdCounterSapSync(params.value)
      } else if (props.searchParams.vNoteType === 'SA') {
        insertQdrugCounterSapSync(params.value)
      }
    }

    const init = () => {
      findCodeList(['LAB_NOTE_PLANT'])
    }

    init()

    return {
      codeGroupMaps,
      params,
      fnSapSync,
    }
  }
}
</script>