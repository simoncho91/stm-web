<template>
  <div class="modal-content modal-content__width--101">
    <div class="modal-header">
      <div class="modal-title">문제이력</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({ message: '' })"></button>
    </div>
    <div class="modal-body">
      <div class="myboard-top d-flex">
        <div>* 글로벌 공지/제한은 상세내용 팝업에서 확인 시 CHECK BOX가 변경됩니다.</div>
        <ap-selectbox v-model:value="searchParams.vLand1" inputClass="ui-select ui-select__width--200"
          :defaultBlank="{ blank: false }" :options="land1List" @change="onChange"></ap-selectbox>
      </div>
      <div class="contents-tab__body--item mt-25">
        <div class="ui-table__wrap">
          <table class="ui-table text-center ui-table__td--40">
            <colgroup>
              <col style="width:10%;">
              <col style="width:11%;">
              <col style="width:35%;">
              <col v-if="searchParams.vLand1 === 'UN'" style="width:12%;">
              <col style="width:auto;">
              <col style="width:auto;">
              <col style="width:13%;">
            </colgroup>
            <thead>
              <tr>
                <th>성분코드</th>
                <th>CAS NO</th>
                <th>성분명</th>
                <template v-if="searchParams.vLand1 === 'UN'">
                  <th>국가</th>
                  <th>금지 여부</th>
                  <th>제한 여부</th>
                </template>
                <template v-else>
                  <th>글로벌 금지</th>
                  <th>글로벌 제한</th>
                </template>
                <th>제한 함량</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(vo, index) in problemHis.list" :key="index">
                <td>{{ vo.vConcd }}</td>
                <td class="tit">{{ vo.vCasno }}</td>
                <td class="tit">{{ vo.vConnm }}</td>
                <template v-if="searchParams.vLand1 === 'UN'">
                  <td>{{ vo.vGctxt }}</td>
                  <td>
                    <button v-if="vo.vGban === 'Y'" type="button" class="ui-button ui-button__border--blue width-70"
                      @click="onMateGlobalViewPop(vo, 'BAN')">{{
                        vo.vGban }}</button>
                  </td>
                  <td>
                    <button v-if="vo.vGlmt === 'Y'" type="button" class="ui-button ui-button__border--blue width-70"
                      @click="onMateGlobalViewPop(vo, 'LIMIT')">{{
                        vo.vGlmt }}</button>
                  </td>
                  <td>{{ vo.vGlper }}</td>
                </template>
                <template v-else>
                  <td>
                    <button v-if="vo.vZglobal" type="button" class="ui-button ui-button__border--blue width-70"
                      @click="onMateGlobalViewPop(vo, 'BAN')">{{
                        vo.vZglobal }}</button>
                  </td>
                  <td>
                    <button v-if="vo.vZgllim" type="button" class="ui-button ui-button__border--blue width-70"
                      @click="onMateGlobalViewPop(vo, 'LIMIT')">{{
                        vo.vZgllim }}</button>
                  </td>
                  <td>{{ vo.vZinper }}</td>
                </template>
              </tr>
              <template v-if="problemHis?.list?.length === 0">
                <tr>
                  <td :colspan="searchParams.vLand1 === 'UN' ? 7 : 6">
                    <div class="no-result">
                      {{ t('common.msg.no_data') }}
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>

        <br />

        <div class="ui-table__wrap">
          <table class="ui-table text-center ui-table__td--40">
            <colgroup>
              <col style="width:10%;">
              <col style="width:13%;">
              <col style="width:13%;">
              <col style="width:13%;">
              <col style="width:13%;">
              <col style="width:auto;">
            </colgroup>
            <thead>
              <tr>
                <th rowspan="2">내용물 코드</th>
                <th rowspan="2">원료 코드</th>
                <th rowspan="2">내용물 내<br />원료함량</th>
                <th rowspan="2">부서</th>
                <th rowspan="2">등록일</th>
                <th>문제 상세 이력</th>
              </tr>
              <tr>
                <th>비고</th>
              </tr>
            </thead>
            <tbody>
              <template v-for="(vo, index) in problemHis.tcodeList" :key="index">
                <tr>
                  <td rowspan="2">{{ vo.vContCd }}</td>
                  <td rowspan="2">{{ vo.vMateCd }}</td>
                  <td rowspan="2">{{ vo.vConInPer }}</td>
                  <td rowspan="2" class="tit">{{ vo.vDeptNm }}</td>
                  <td rowspan="2" class="tit">{{ commonUtils.changeStrDatePattern(vo.vRegDtm) }}</td>
                  <td class="tit">{{ vo.vTcodeDesc }}</td>
                </tr>
                <tr>
                  <td class="tit">{{ vo.vEtc }}</td>
                </tr>
              </template>
              <template v-if="problemHis?.tcodeList?.length === 0">
                <tr>
                  <td colspan="6">
                    <div class="no-result">
                      {{ t('common.msg.no_data') }}
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>

          <div class="board-bottom board-bottom__with--button">
            <div class="board-bottom__inner">
              <div class="ui-buttons ui-buttons__right">
                <button type="button" class="ui-button ui-button__bg--skyblue font-weight__300"
                  @click="onMateCheck">확인</button>
                <button type="button" class="ui-button ui-button__bg--lightgray"
                  @click="closeAsyncPopup({ message: '닫기' })">닫기</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <teleport to="#common-modal-sub" v-if="popContent">
      <ap-popup>
        <component :is="popContent" :pop-params="popupParams" @selectFunc="popSelectFunc" @closeFunc="closeFunc" />
      </ap-popup>
    </teleport>
    <div id="common-modal-sub"></div>
  </div>
</template>

<script>
import { defineAsyncComponent, reactive, ref, inject } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useMaterialCommon } from '@/compositions/labcommon/useMaterialCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'MateProblemHisPop',
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    MateGlobalViewPop: defineAsyncComponent(() => import('@/components/labcommon/popup/MateGlobalViewPop.vue')),
  },
  emits: ['updateFlagMateCheck'],
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: '',
          vMateCd: '',
          vLand1: '',
        }
      }
    }
  },
  setup(props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { openAsyncPopup, closeAsyncPopup } = useActions(['openAsyncPopup', 'closeAsyncPopup'])
    const searchParams = reactive({
      vLabNoteCd: props.popParams.vLabNoteCd,
      vMateCd: props.popParams.vMateCd,
      vLand1: props.popParams.vLand1,
    })
    const problemHis = reactive({
      list: [],
      tcodeList: [],
    })
    const land1List = reactive([
      {
        vSubCode: 'KR',
        vSubCodenm: 'ZPLM34',
      },
      {
        vSubCode: 'UN',
        vSubCodenm: 'ZPLM34E',
      }
    ])
    const popContent = ref(null)
    const popSelectFunc = ref(null)
    const popupParams = ref({})
    const closeFunc = ref({})

    const {
      selcetScmTcodeList,
    } = useLabCommon()

    const {
      updateLabNoteMateCheck,
    } = useMaterialCommon()

    const init = async () => {
      const result = await selcetScmTcodeList(searchParams)
      problemHis.list = result.glbList ? result.glbList : result.mstList
      problemHis.tcodeList = result.tcodeList
    }

    const onChange = (e) => {
      searchParams.vLand1 = e
      init()
    }

    const closeMateGlobalViewPop = () => {
      popContent.value = null
    }

    const onMateGlobalViewPop = (o, vSearchType) => {
      popContent.value = 'MateGlobalViewPop'
      popupParams.value = {
        vLabNoteCd: searchParams.vLabNoteCd,
        vSearchType,
        vConcd: o.vConcd,
        vConnm: o.vConnm,
        vLand1: searchParams.vLand1,
        vGcode: o.vGcode || '',
      }
      closeFunc.value = closeMateGlobalViewPop

      // openAsyncPopup()
      //   .then(res => {
      //   })
      //   .catch(err => {
      //     console.log(err)
      //   })
      //   .finally(() => {
      //     popContent.value = null
      //   })
    }

    const onMateCheck = async () => {
      await updateLabNoteMateCheck({
        vLabNoteCd: searchParams.vLabNoteCd,
        vMateCd: searchParams.vMateCd,
      })
      context.emit('updateFlagMateCheck')

      closeAsyncPopup({ message: '' })
    }

    init()

    return {
      t,
      commonUtils,
      searchParams,
      popContent,
      popSelectFunc,
      popupParams,
      closeFunc,
      problemHis,
      land1List,
      onChange,
      onMateGlobalViewPop,
      onMateCheck,
      closeAsyncPopup
    }
  }
}
</script>