<template>
  <div class="modal-content modal-content__width--701">
    <div class="modal-header">
      <div class="modal-title">상세조회</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({ message: '' })"></button>
    </div>
    <div class="modal-body">
      <div class="myboard-top d-flex">
        <div>* 적용 하실 LOT을 선택 후 적용버튼을 눌러주세요 ※</div>
      </div>
      <div class="modal-body__scroll">
        <div class="search-depart-table">
          <div class="search-depart-table__inner">
            <table class="ui-table__td--40">
              <colgroup>
                <col style="width:13rem">
                <col style="width:auto">
              </colgroup>
              <tbody>
                <tr>
                  <th>버전 / LOT</th>
                  <td>
                    <ap-selectbox v-model:value="hal4Params.nVersion" :options="verList" codeKey="nVersion"
                      codeNmKey="vVersionTxt" @change="onVerChange"></ap-selectbox>
                    <ap-selectbox v-model:value="hal4Params.vLotCd" :options="lotList" codeKey="vLotCd" codeNmKey="vLotNm"
                      @change="onLotChange"></ap-selectbox>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <template v-if="list">
            <div class="search-depart-table__inner">
              <table class="ui-table__td--40">
                <colgroup>
                  <col style="width:13rem">
                  <col style="width:auto">
                </colgroup>
                <tbody>
                  <tr>
                    <th>내용물명</th>
                    <td>
                      <div class="font-weight__600 color-blue">{{ list?.[0].vContNm }}</div>
                    </td>
                  </tr>
                  <tr>
                    <th>연구원</th>
                    <td>{{ list?.[0].vUsernm }}</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div class="search-detail-table mt-15">
              <div class="search-detail-table__inner">
                <table class="ui-table__modal">
                  <colgroup>
                    <col style="width:13rem">
                    <col style="width:auto">
                    <col style="width:14rem">
                  </colgroup>
                  <thead>
                    <tr>
                      <th>원료코드</th>
                      <th>원료명</th>
                      <th>{{ list?.[0].vLotNm }} 함량</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(vo, index) in list" :key="index">
                      <td>{{ vo.vMateCd }}</td>
                      <td class="text-left pl-10">{{ vo.vMateNm }}</td>
                      <td>{{ vo.nRate }}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </template>
        </div>

        <div class="board-bottom board-bottom__with--button">
          <div class="board-bottom__inner">
            <div class="ui-buttons ui-buttons__right">
              <button type="button" class="ui-button ui-button__bg--skyblue font-weight__300" @click="onApply">적용</button>
              <button type="button" class="ui-button ui-button__bg--lightgray"
                @click="closeAsyncPopup({ message: '닫기' })">닫기</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { reactive, ref, inject } from 'vue'
import { useMaterialCommon } from '@/compositions/labcommon/useMaterialCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'Hal4LotSetPop',
  components: {
  },
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: '',
          vContPkCd: '',
          nVersion: 0,
          vLotCd: '',
        }
      }
    }
  },
  emits: ['selectFuncHal4LotSet'],
  setup(props, context) {
    const t = inject('t')
    const { openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncAlert', 'closeAsyncPopup'])
    const contVO = ref(null)
    const verList = ref(null)
    const lotList = ref(null)
    const list = ref(null)
    const searchParams = reactive({
      vLabNoteCd: props.popParams.vLabNoteCd,
      vContPkCd: props.popParams.vContPkCd,
    })
    const lotParams = reactive({
      vContPkCd: props.popParams.vContPkCd,
      nVersion: '',
    })
    const mateParams = reactive({
      vLabNoteCd: props.popParams.vLabNoteCd,
      vContPkCd: props.popParams.vContPkCd,
      nVersion: '',
      vLotCd: '',
    })
    const hal4Params = reactive({
      nVersion: '',
      vLotCd: '',
    })

    const {
      selectLabNoteContInfo,
      selectLabNoteLotList,
      selectLabNoteMateRateInfo,
    } = useMaterialCommon()

    const init = async () => {
      const response = await selectLabNoteContInfo(searchParams)
      contVO.value = response.contVO
      verList.value = response.verList
    }

    const onVerChange = async (o) => {
      list.value = null
      lotList.value = null
      hal4Params.vLotCd = ''

      if (o !== '') {
        lotParams.nVersion = o
        const response = await selectLabNoteLotList(lotParams)
        lotList.value = response.lotList
      }
    }

    const onLotChange = async (o) => {
      list.value = null

      if (o !== '') {
        mateParams.nVersion = lotParams.nVersion
        mateParams.vLotCd = o
        list.value = await selectLabNoteMateRateInfo(mateParams)
      }
    }

    const onApply = () => {
      if (hal4Params.nVersion === '') {
        openAsyncAlert({ message: '버전을 선택해 주세요.' })
        return
      }
      else if (hal4Params.vLotCd === '') {
        openAsyncAlert({ message: 'LOT를 선택해 주세요.' })
        return
      }

      const verObj = verList.value.filter(o => o.nVersion + '' === hal4Params.nVersion + '')
      const lotObj = lotList.value.filter(o => o.vLotCd === hal4Params.vLotCd)
      // context.emit('selectFuncHal4LotSet', '[' + verObj?.[0].vVersionTxt + ' - ' + lotObj?.[0].vLotNm + ']')
      context.emit('selectFuncHal4LotSet', verObj, lotObj)
      closeAsyncPopup({ message: '' })
    }

    init()

    return {
      t,
      hal4Params,
      contVO,
      verList,
      lotList,
      list,
      onVerChange,
      onLotChange,
      onApply,
      closeAsyncPopup,
    }
  }
}
</script>