<template>
  <div class="modal-content modal-content__width--auto" style="width:431px">
    <div class="modal-header">
      <div class="modal-title">안정도 항목 설정</div>
      <button type="button" class="modal-close" @click="onClose"></button>
    </div>
    <div class="modal-body">
      <div class="modal-body__item material-setting">

        <div class="mateial-setting__item">

          <div class="mt-15">
            <div class="ui-checkbox__list ui-checkbox__list--column">
              <div class="ui-checkbox__inner flex-row">
                <template v-for="(vo, index) in info.list" :key="index">
                  <div class="ui-checkbox-block col-6">
                    <ap-input-check v-model:model="vo.vFlagCheck" :id="vo.vSubCode" :checked="vo.vFlagCheck === 'Y'"
                      value="Y" false-value="N" :label="vo.vSubCodeNm"></ap-input-check>
                  </div>
                </template>
              </div>
            </div>
          </div>
        </div>

        <div class="board-bottom board-bottom__with--button">
          <div class="board-bottom__inner">
            <div class="ui-buttons ui-buttons__right">
              <button type="button" class="ui-button ui-button__bg--skyblue font-weight__300" @click="onSave">저장</button>
              <button type="button" class="ui-button ui-button__bg--lightgray"
                @click="onClose">닫기</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { reactive, ref, inject } from 'vue'
import { useMaterialCommon } from '@/compositions/labcommon/useMaterialCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'StabilitySettingPop',
  components: {
  },
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: '',
          vLotCd: '',
        }
      }
    }
  },
  emits: ['closeFunc'],
  setup(props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncAlert', 'closeAsyncPopup'])
    const searchParams = reactive({
      vLabNoteCd: props.popParams.vLabNoteCd,
      vLotCd: props.popParams.vLotCd,
    })
    const info = ref({
      list: [],
    })

    const {
      selectLabNoteStabilityTitleAllList,
      insertLabNoteStabilityTitle,
    } = useMaterialCommon()

    const init = async () => {
      info.value = await selectLabNoteStabilityTitleAllList(searchParams)
    }

    const onSave = async () => {
      await insertLabNoteStabilityTitle({
        vLotCd: searchParams.vLotCd,
        stabilityCdList: info.value.list.filter(vo => vo.vFlagCheck === 'Y').map(vo => vo.vSubCode),
      })

      onClose()
    }

    const onClose = () => {
      context.emit('closeFunc')
    }

    init()

    return {
      t,
      commonUtils,
      searchParams,
      info,
      onSave,
      onClose,
    }
  }
}
</script>