<template>
  <div class="modal-content modal-content__width--auto" style="width: 760px;">
    <div class="modal-header">
      <div class="modal-title">원료배합 순서 바꾸기</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({ message: '' })"></button>
    </div>
    <div class="modal-body">

      <div class="modal-body__item">
        <div class="change-row-wrap">
          <ul class="change-row__item change-row__item--head">
            <li>
              <span class="change-row__item__no">NO</span>
              <span class="change-row__item__code">CODE</span>
              <span class="change-row__item__name">NAME</span>
              <span class="change-row__item__lot">{{ searchParams.vLotNm }} 함량</span>
            </li>
          </ul>
          <draggable v-model="info.mateList" group="mateList" item-key="vMatePkCd || vGrpCd || vMateCd" tag="ul"
            class="change-row__item change-row__item--cont" @start="onOrderStart" @end="onMateSort">
            <template #item="{ element: mate }">
              <li :class="{ 'color-skyblue': mate.vRecType === 'GRP' }">
                <template v-if="mate.vRecType === 'GRP'">
                  <em style="background: url();">{{ mate.vGrpNm }}</em>
                  <draggable group="mateList" v-model="mate.subMateList" item-key="vMatePkCd || vGrpCd || vMateCd"
                    tag="ul" class="change-row__item__grouping" @start="onOrderStart" @end="onMateSort">
                    <template #item="{ element: sub }">
              <li>
                <span class="change-row__item__no">{{ sub.nMateNum }}</span>
                <span class="change-row__item__code">{{ sub.vMateCd }}</span>
                <span class="change-row__item__name">{{ sub.vMateNm }}</span>
                <span class="change-row__item__lot">
                  {{ info.rateList.find(rate => rate.vMatePkCd === sub.vMatePkCd)?.nRate }}
                </span>
              </li>
            </template>
          </draggable>
          </template>
          <template v-else>
            <span class="change-row__item__no">{{ mate.nMateNum }}</span>
            <span class="change-row__item__code" style="text-align: left;">{{ mate.vMateCd }}</span>
            <span class="change-row__item__name">{{ mate.vMateNm }}</span>
            <span class="change-row__item__lot">
              {{ info.rateList.find(rate => rate.vMatePkCd === mate.vMatePkCd)?.nRate }}
            </span>
          </template>
          </li>
          </template>
          </draggable>
        </div>
      </div>
    </div>

    <div class="board-bottom board-bottom__with--button">
      <div class="board-bottom__inner">
        <div class="ui-buttons ui-buttons__right">
          <button type="button" class="ui-button ui-button__bg--skyblue font-weight__300" @click="onOrderChange">BOM
            전송</button>
          <button type="button" class="ui-button ui-button__bg--lightgray"
            @click="closeAsyncPopup({ message: '닫기' })">닫기</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { reactive, ref, inject } from 'vue'
import { useMaterialCommon } from '@/compositions/labcommon/useMaterialCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'MateOrderChangePop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: '',
          vContPkCd: '',
          nVersion: '',
          vLotCd: '',
          vLotNm: '',
          vContCd: '',
          vContNm: '',
        }
      }
    }
  },
  emits: ['selectFunc'],
  setup(props, context) {
    const t = inject('t')
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])
    const searchParams = reactive({
      vLabNoteCd: props.popParams.vLabNoteCd,
      vContPkCd: props.popParams.vContPkCd,
      nVersion: props.popParams.nVersion,
      vLotCd: props.popParams.vLotCd,
      vLotNm: props.popParams.vLotNm,
      vContCd: props.popParams.vContCd,
      vContNm: props.popParams.vContNm,
    })
    const info = ref({
      mateList: [],
      rateList: [],
    })

    const {
      selectMaterialFormulationChange,
      updateMaterialFormulationChange,
    } = useMaterialCommon()

    const init = async () => {
      info.value = await selectMaterialFormulationChange(searchParams)

      onMateSort()

      let copyMateList = [...info.value.mateList]
      let copySubMateList = [...info.value.mateList.filter(sub => sub.vRecType !== 'GRP' && sub.vGrpCd)]
      copyMateList = copyMateList
        .filter(mate => mate.vRecType === 'GRP' || (!mate.vGrpCd && mate.vMatePkCd))
        .map(mate => {
          return {
            ...mate,
            subMateList: copySubMateList.filter(sub => sub.vGrpCd === mate.vGrpCd)
          }
        })
      info.value.mateList = copyMateList
      info.value.rateList = info.value.rateList.filter(rate => rate.vKey.indexOf('_SUM') < 0)
    }

    init()

    const onOrderStart = (e) => {
      e.item.style.backgroundColor = '#5cc1a6'
    }

    const onMateSort = (e) => {
      if (e) {
        e.item.style.backgroundColor = '#fff'
      }

      let len = 0
      info.value.mateList = info.value.mateList.map((mate, idx) => {
        if (mate.subMateList && mate.subMateList.length > 0) {
          mate.subMateList = mate.subMateList.map(sub => {
            return {
              ...sub,
              nMateNum: ++len,
            }
          })
        }

        return {
          ...mate,
          nMateNum: mate.vRecType !== 'GRP' ? ++len : null,
        }
      })
    }

    const onOrderChange = async () => {
      // 순서 및 BOM 전송
      const copyMateList = [...info.value.mateList]
      const groupList = []
      const mateList = []
      let idx = 1

      copyMateList.map(mate => {
        if (mate.vRecType === 'GRP') {
          groupList.push({
            ...mate,
            nSort: idx++
          })

          mate.subMateList?.map(sub => {
            mateList.push({
              ...sub,
              vGrpCd: mate.vGrpCd,
              nSort: idx++
            })
          })
        }
        else {
          mateList.push({
            ...mate,
            vGrpCd: null,
            nSort: idx++
          })
        }
      })

      await updateMaterialFormulationChange({
        vLabNoteCd: searchParams.vLabNoteCd,
        vContPkCd: searchParams.vContPkCd,
        nVersion: searchParams.nVersion,
        vLotCd: searchParams.vLotCd,
        vContCd: searchParams.vContCd,
        vContNm: searchParams.vContNm,
        vLotNm: searchParams.vLotNm,
        groupList,
        mateList,
        vLand1: 'tmp',
        vPlantCd: 'tmp',
      })

      context.emit('selectFunc')
    }

    return {
      t,
      searchParams,
      info,
      onOrderStart,
      onMateSort,
      onOrderChange,
      closeAsyncPopup,
    }
  }
}
</script>