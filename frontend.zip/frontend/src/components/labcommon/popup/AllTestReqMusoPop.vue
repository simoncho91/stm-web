<template>
  <div class="modal-content modal-content__width--122">
    <div class="modal-header">
      <div class="modal-title">시험의뢰 (무소구)</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({ message: '' })"></button>
    </div>
    <div class="modal-body">
      <div class="search-detail-table">
        <div class="search-detail-table__inner">
          <table class="ui-table__modal pd">
            <colgroup>
              <col style="width:10%">
              <col style="width:17%">
              <col style="width:auto">
              <col style="width:12%">
              <col style="width:17%">
              <col style="width:17%">
            </colgroup>
            <thead>
              <tr>
                <th>대표</th>
                <th>내용물코드/제품코드</th>
                <th>내용물명</th>
                <th>플랜트</th>
                <th>LOT</th>
                <th>비고 </th>
              </tr>
            </thead>
            <tbody>
              <template v-if="resData.contList?.length > 0">
                  <tr v-for="(cvo, index) in resData.contList" :key="`tr_${index}`">
                  <td>
                    <div class="ui-label jc-c">
                     <ap-input-radio
                      v-model:model="payload.vRepContPkCd"
                      :value="cvo.vContPkCd"
                      :id="'flagNew_' + index"
                      name="flagNew"
                      @click="fnClickRep(cvo)"
                    ></ap-input-radio>
                  </div>
                  </td>
                  <td>{{ cvo.vContCd }} / {{ cvo.vPrdCd }}</td>
                  <td>
                    <div class="tit__inner">
                      {{ cvo.vContNm }}
                    </div>
                    </td>
                  <td>{{ cvo.vPlantCd}}</td>
                  <td>
                    <div class="ui-select-block">
                      <ap-selectbox
                        v-model:value="cvo.vLotCd"
                        :options="cvo.subList"
                        :disabled="payload.vRepContPkCd !== cvo.vContPkCd"
                        codeKey="vLotCd"
                        codeNmKey="vLotNm"
                        @change="fnSelectOption($event, cvo)"
                    >
                    </ap-selectbox>
                  </div>
                  </td>
                  <td></td>
                </tr>
              </template>
              <template v-else>
                <tr>
                  <td colspan="6">
                    <div class="no-result">
                      {{ t('common.msg.no_data') }}
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>

      <div class="tableTitle mt-2">정보 입력</div>
      <div class="board-top mb-0">
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">완료요청일<span class="ui-require"><span class="for-a11y">(필수)</span></span></dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="search-form">
                <div class="search-form__inner">
                  <ap-date-picker
                    v-model:date="payload.vTrCompleteReqDt"
                    :read-only="true"
                  />
                </div>
              </div>

            </dd>
          </dl>
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100"><span>제형</span></dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="search-form">
                <div class="search-form__inner">
                  <ap-selectbox
                    v-model:value="payload.vDosageFormCd"
                    :options="codeGroupMaps['DOSAGE_FORM']"
                  />
                </div>
              </div>
            </dd>
          </dl>

        </div>
        <div class="search-bar__row search-bar__row--modal">

          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">{{ payload.vTestTypeNm || '-'}}</dt>
            <dd class="search-bar__val search-bar__val--flexible" style="text-align: left;">
              {{ payload.vTestValue }}
            </dd>
          </dl>

          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100"><span>pH</span></dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <ap-input :is-number="false" v-model:value="payload.vTrPh"></ap-input>
            </dd>
          </dl>
        </div>
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100"><span>인증 제품명</span></dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="tit__inner ta-l">
                {{ vChiceContNm }}
              </div>
            </dd>
          </dl>
        </div>
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100"><span>연관 제품코드</span></dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="tit__inner ta-l">
                {{ vChicePrdCd }}
              </div>
            </dd>
          </dl>
        </div>
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">무소구 성분</dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="tit__inner ta-l">
                <div style="padding: 5px; height: 26px; line-height: 26px;">
                  <span v-if="payload.vFlagNotAdd == 'Y' && payload.vFlagApPromise == 'Y'">AP Promise(안심감 강화 제품), 무소구 성분</span>
                  <span v-if="payload.vFlagNotAdd == 'Y'">무소구 성분</span>
                  <span v-if="payload.vFlagApPromise == 'Y'">AP Promise(안심감 강화 제품)</span>
                </div>

                  <table v-if="payload.vFlagApPromise == 'Y'" class="ui-table ui-table__material-pop text-center">
                    <colgroup>
                      <col style="width:75%;">
                      <col style="width:25%;">
                    </colgroup>
                    <thead>
                      <tr>
                        <th>관리성분</th>
                        <th>비고</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          <template v-for="(vo, index) in resData.mtr03List" :key="index">
                            {{ vo.vSubCodenm }}<br/>
                          </template>
                        </td>
                        <td>
                          {{ payload.vFlagApPromiseNote }}
                        </td>
                      </tr>
                    </tbody>
                  </table>

                  <table v-if="payload.vFlagNotAdd == 'Y'" class="ui-table ui-table__material-pop text-center">
                    <colgroup>
                      <col style="width:25%;">
                      <col style="width:25%;">
                      <col style="width:25%;">
                      <col style="width:25%;">
                    </colgroup>
                    <thead>
                      <tr>
                        <th>공통항목</th>
                        <th>특화항목</th>
                        <th>제한항목</th>
                        <th>비고</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          <template v-for="(vo, index) in resData.mtr04List" :key="index">
                            {{ vo.vSubCodenm }}<br/>
                          </template>
                        </td>
                        <td>
                          <template v-for="(vo, index) in resData.mtr05List" :key="index">
                            {{ vo.vSubCodenm }}<br/>
                          </template>
                        </td>
                        <td>
                          <template v-for="(vo, index) in resData.mtr06List" :key="index">
                            {{ vo.vSubCodenm }}<br/>
                          </template>
                        </td>
                        <td>
                          {{ vNotAddNoteTxt }}
                        </td>
                      </tr>
                    </tbody>
                  </table>

              </div>
            </dd>
          </dl>
        </div>
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100 mt-m3"><span>메시지</span></dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="ui-textarea-box ui-textarea-box__height--100">
                <ap-text-area 
                  v-model:value="payload.vTrComment"
                  :is-with-byte="true" 
                  :maxlength="2000"
                />
              </div>
            </dd>
          </dl>
        </div>
      </div>

      <div class="modal-body__item" style="padding-top: 40px;" v-if="resData.list && resData.list.length > 0">
        <!-- <div class="tableTitle mt-2" v-if="resData.list && resData.list.length > 0">내용물 정보</div> -->
        <div class="modal-sub-title modal-sub-title__flex">
          <div class="modal-sub-title__text">내용물 정보</div>
          <div class="modal-sub-title__right">
            ○: 무소구 가능 / <span class="color-yellow">검토: 추가 확인 필요</span> / <span class="color-red">불가: 무소구 불가</span>
          </div>
        </div>
        <div class="ui-table__wrap ui-table__scroll-x" v-if="resData.list && resData.list.length > 0">
          <table class="ui-table ui-table__material-pop text-center ui-table__td--40 ui-table__th--border-radius--0" style="width:1600px;">
            <colgroup>
              <col style="width:7%;">
              <col style="width:10%;">
              <col style="width:5%;">
              <template v-for="(vo, index) in resData.list" :key="index">
                <col style="width:3%;">
              </template>
            </colgroup>
            <thead>
              <tr>
                <th>원료코드</th>
                <th>원료명</th>
                <th>함량(%)</th>
                <template v-for="(vo, index) in resData.list" :key="index">
                  <th :class="vo.vContent1">{{ vo.vSubCodenm }}</th>
                </template>
              </tr>
            </thead>
            <tbody class="tb_musogu">
              <template v-for="(vo, index) in resData.musoguYnList" :key="index">
                <tr>
                  <template v-if="vo.nLv2Num === 0">
                  <td v-if="vo.vFlagRequest === 'Y'" class="bg-red">
                    <a href="javascript:void(0)" class="tit-link" @click="clickHal4(vo.vMateCd, vo.vPlantCd)"><span
                        class="color-red">{{ vo.vMateCd}}</span></a>
                  </td>
                  <td v-else :class="getBgRed(vo)">{{ !vo.vMateCd ? vo.vMateTempCd : vo.vMateCd }}</td>
                </template>
                <template v-else>
                  <td :class="getBgRed(vo)">ㄴ {{ vo.vMateCd }}</td>
                </template>
                  <td>{{ vo.vMateNm }}</td>
                  <td>{{ commonUtils.getDecimalPointFormat(vo.nRate) }}</td>
                  <td :style="getBgBlue(0)"><span :class="'color-'+(vo.vColor0)">{{ vo.vCode0 }}</span></td>
                  <td :style="getBgBlue(1)"><span :class="'color-'+(vo.vColor1)">{{ vo.vCode1 }}</span></td>
                  <td :style="getBgBlue(2)"><span :class="'color-'+(vo.vColor2)">{{ vo.vCode2 }}</span></td>
                  <td :style="getBgBlue(3)"><span :class="'color-'+(vo.vColor3)">{{ vo.vCode3 }}</span></td>
                  <td :style="getBgBlue(4)"><span :class="'color-'+(vo.vColor4)">{{ vo.vCode4 }}</span></td>
                  <td :style="getBgBlue(5)"><span :class="'color-'+(vo.vColor5)">{{ vo.vCode5 }}</span></td>
                  <td :style="getBgBlue(6)"><span :class="'color-'+(vo.vColor6)">{{ vo.vCode6 }}</span></td>
                  <td :style="getBgBlue(7)"><span :class="'color-'+(vo.vColor7)">{{ vo.vCode7 }}</span></td>
                  <td :style="getBgBlue(8)"><span :class="'color-'+(vo.vColor8)">{{ vo.vCode8 }}</span></td>
                  <td :style="getBgBlue(9)"><span :class="'color-'+(vo.vColor9)">{{ vo.vCode9 }}</span></td>
                  <td :style="getBgBlue(10)"><span :class="'color-'+(vo.vColor10)">{{ vo.vCode10 }}</span></td>
                  <td :style="getBgBlue(11)"><span :class="'color-'+(vo.vColor11)">{{ vo.vCode11 }}</span></td>
                  <td :style="getBgBlue(12)"><span :class="'color-'+(vo.vColor12)">{{ vo.vCode12 }}</span></td>
                  <td :style="getBgBlue(13)"><span :class="'color-'+(vo.vColor13)">{{ vo.vCode13 }}</span></td>
                  <td :style="getBgBlue(14)"><span :class="'color-'+(vo.vColor14)">{{ vo.vCode14 }}</span></td>
                  <td :style="getBgBlue(15)"><span :class="'color-'+(vo.vColor15)">{{ vo.vCode15 }}</span></td>
                  <td :style="getBgBlue(16)"><span :class="'color-'+(vo.vColor16)">{{ vo.vCode16 }}</span></td>
                  <td :style="getBgBlue(17)"><span :class="'color-'+(vo.vColor17)">{{ vo.vCode17 }}</span></td>
                  <td :style="getBgBlue(18)"><span :class="'color-'+(vo.vColor18)">{{ vo.vCode18 }}</span></td>
              </tr>
            </template>
            <tr>
              <td colspan="2">총 합량 합계</td>
              <td>{{ getSumRate() }}</td>
              <td colspan="19"></td>
            </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div class="board-bottom board-bottom__with--button" style="margin-top: 35px;">
        <div class="board-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--skyblue font-weight__300" @click="fnTestReqSave">시험의뢰</button>
            <button type="button" class="ui-button ui-button__bg--lightgray" @click="closeAsyncPopup({ message: '닫기' })">닫기</button>
          </div>
        </div>
      </div>
      
    </div>
  </div>
</template>

<script>
import { reactive, ref, inject } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useActions } from 'vuex-composition-helpers'
import { useTestReqCommon } from '@/compositions/labcommon/useTestReqCommon'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'

export default {
  name: 'AllTestReqMusoPop',
  components: {
  },
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: ''
        , vContPkCd: ''
        , nVersion: ''
        , vLotCd: ''
        , vPlantCd: ''
        , vMrqTypeCd: ''
        }
      }
    }
  },
  emits: ['selectFunc'],
  setup(props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { openAsyncConfirm, openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncConfirm', 'openAsyncAlert', 'closeAsyncPopup'])

    const flagLotCompleYn = ref('')

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const musogu = reactive({
      rvo: {},
      lastTrVo: {},
      list: [],
      musoguYnList: [],
      lotList: [],
      contList: [],
      mtrList: [],
      mtr03List: [],
      mtr04List: [],
      mtr05List: [],
      mtr06List: [], 
    })

    const backColorIdxs = reactive({
      num: [],
    })

    const { 
      goSkinTestReqSave
      , selectMusoguList
      , selectMusoguContensDetailList
    } = useTestReqCommon()
    
    const { insertHal4Mate } = useLabCommon()

    const searchParams = {
      vLabNoteCd: props.popParams.vLabNoteCd
        //, vContPkCd: props.popParams.vContPkCd
        , vOtherContPkCd: props.popParams.vContPkCd
        , nVersion: props.popParams.nVersion
        , vLotCd: props.popParams.vLotCd
        , vPlantCd: props.popParams.vPlantCd
        , vMrqTypeCd: props.popParams.vMrqTypeCd
        , vLand1: 'UN'
    } 

    const resData = ref({})

    const payload = ref({
      vLabNoteCd: searchParams.vLabNoteCd
      , vContPkCd: searchParams.vContPkCd
      , nVersion: searchParams.nVersion
      , vPlantCd: searchParams.vPlantCd
      , vMrqTypeCd: searchParams.vMrqTypeCd
      , vLotCd: ''
      , vTrCompleteReqDt: ''
      , vContcd: ''
      , vRepContPkCd: ''
      , vDosageFormCd: ''
      , vTrPh: ''
      , vGateCd: props.popParams.vGateCd
      , vFlagAction: 'SAVE_TEST_REQ'
      , vTrRelationProductCd: ''
      , vTrMrqTypeCd: ''
      , vTrGoalCd: ''
      , vTrComment: ''
      , vFlagNotAdd: ''
      , vFlagApPromise: ''
      , vTrMusoguProductNm: ''
      , vTrRelationProductCd: ''
      , vTrMusoguProductNm: ''
      , vFlagApPromiseNote: ''
      , vContNm: ''
      , vLotNm: ''
      , vLand1: 'UN'
    })


    const vNotAddNoteTxt = ref('')
    const vChicePrdCd = ref('')
    const vChiceContNm = ref('')

    const fnSelectOption = async (value, vo) => {
      
      const lvo = vo.subList.find(svo => svo.vLotCd === value)

      if (lvo) {
        payload.value.vTestTypeNm = lvo.vTestTypeNm
        payload.value.vTestValue = lvo.vTestValue
        payload.value.vTrPh = lvo.vPh
        flagLotCompleYn.value = lvo.vFlagComplete

        vo.nVersion = lvo.nVersion
        vo.vLotNm = lvo.vLotNm

        payload.value.vContcd = vo.vContCd
        payload.value.vTrRelationProductCd = vo.vPrdCd
        searchParams.vLotCd = value

        payload.value.vContNm = vo.vContNm
        payload.value.vLotNm = lvo.vLotNm

        const result = await selectMusoguContensDetailList(searchParams)
        resData.value.rvo = result.rvo
        resData.value.list = result.list

        resData.value.musoguYnList = result.musoguYnList

        resData.value.mtr03List = result.mtr03List
        resData.value.mtr04List = result.mtr04List
        resData.value.mtr05List = result.mtr05List
        resData.value.mtr06List = result.mtr06List

        musogu.mtrList = [
          ...resData.value.mtr04List,
          ...resData.value.mtr05List,
          ...resData.value.mtr06List,
        ]
        musogu.list = resData.value.list

        musogu.list.map((vo, idx) => {
          if (musogu.mtrList.filter(mtr => mtr.vBuffer1 === vo.vBuffer1).length > 0) {
            backColorIdxs.num.push(idx)
          }
        })

      } else {
        payload.value.vTestTypeNm = ''
        payload.value.vTestValue = ''
        payload.value.vTrPh = ''
        flagLotCompleYn.value = ''

        vo.nVersion = ''
        vo.vLotNm = ''

        payload.value.vContcd = ''
        payload.value.vTrRelationProductCd = ''
        searchParams.vLotCd = ''

        payload.value.vContNm = ''
        payload.value.vLotNm = ''

      }

    }

    const fnClickRep = async (vo) => {
      const lotCd = vo?.vLotCd
      
      vChicePrdCd.value = vo.vPrdCd
      vChiceContNm.value = vo.vContNm
      if (lotCd) {
        const lvo = vo.subList.find(svo => svo.vLotCd === lotCd)

        if (lvo) {
          payload.value.vTestType = lvo.vTestType
          payload.value.vTestTypeNm = lvo.vTestTypeNm
          payload.value.vTestValue = lvo.vTestValue
          payload.value.vTrPh = lvo.vPh

          payload.value.vTestTypeNm = lvo.vTestTypeNm
          payload.value.vTestValue = lvo.vTestValue
          payload.value.vTrPh = lvo.vPh
          flagLotCompleYn.value = lvo.vFlagComplete

          vo.nVersion = lvo.nVersion
          vo.vLotNm = lvo.vLotNm

          payload.value.vContcd = vo.vContCd
          payload.value.vTrRelationProductCd = vo.vPrdCd
          searchParams.vLotCd = lotCd

          payload.value.vContNm = vo.vContNm
          payload.value.vLotNm = lvo.vLotNm

          const result = await selectMusoguContensDetailList(searchParams)
          resData.value.rvo = result.rvo
          resData.value.list = result.list
          resData.value.musoguYnList = result.musoguYnList

          resData.value.mtr03List = result.mtr03List
          resData.value.mtr04List = result.mtr04List
          resData.value.mtr05List = result.mtr05List
          resData.value.mtr06List = result.mtr06List

          musogu.mtrList = [
            ...resData.value.mtr04List,
            ...resData.value.mtr05List,
            ...resData.value.mtr06List,
          ]
          musogu.list = resData.value.list

          musogu.list.map((vo, idx) => {
            if (musogu.mtrList.filter(mtr => mtr.vBuffer1 === vo.vBuffer1).length > 0) {
              backColorIdxs.num.push(idx)
            }
          })

        } else {
          payload.value.vTestType = ''
          payload.value.vTestTypeNm = ''
          payload.value.vTestValue = ''
          payload.value.vTrPh = ''
          flagLotCompleYn.value = ''

          resData.value.rvo = {}
          resData.value.list = []
          resData.value.musoguYnList = []

          // resData.value.mtr03List = []
          // resData.value.mtr04List = []
          // resData.value.mtr05List = []
          // resData.value.mtr06List = []

        }
      } else {
        payload.value.vTestType = ''
        payload.value.vTestTypeNm = ''
        payload.value.vTestValue = ''
        payload.value.vTrPh = ''
        flagLotCompleYn.value = ''

        resData.value.rvo = {}
        resData.value.list = []
        resData.value.musoguYnList = []

        // resData.value.mtr03List = []
        // resData.value.mtr04List = []
        // resData.value.mtr05List = []
        // resData.value.mtr06List = []
      }
    }

    const getSumRate = () => {
      let rateSum = 0
      resData.value.musoguYnList.filter(o => o.nLv2Num === 0).forEach(o => {
        rateSum += o.nRate
      })
      return commonUtils.getDecimalPointFormat(rateSum.toFixed(6))
    }

    const getBgBlue = (idx) => {
      return backColorIdxs.num.filter(num => num === idx).length > 0 ? 'background-color: #87cefa;' : ''
    }

    const getBgRed = (obj) => {
      if (obj.vCode0 === '불가' || obj.vCode1 === '불가' || obj.vCode3 === '불가' || obj.vCode4 === '불가' || obj.vCode5 === '불가'
        || obj.vCode6 === '불가' || obj.vCode7 === '불가' || obj.vCode8 === '불가' || obj.vCode9 === '불가' || obj.vCode10 === '불가'
        || obj.vCode11 === '불가' || obj.vCode12 === '불가' || obj.vCode13 === '불가' || obj.vCode14 === '불가' || obj.vCode15 === '불가'
        || obj.vCode16 === '불가' || obj.vCode17 === '불가' || obj.vCode18 === '불가') {
        return 'bg-red'
      }
      return ''
    }

    const clickHal4 = async (vMateCd, vPlantCd) => {
      if (commonUtils.isEmpty(vMateCd) || commonUtils.isEmpty(vPlantCd)) {
        openAsyncAlert({ message: '4자코드 필수정보가 없습니다.' })
        return
      }

      if (!await openAsyncConfirm({ message: '4자 코드 정보를 불러오시겠습니까?' })) {
          return
      }
      
      const payload = {
        vMateCd: vMateCd,
        vPlantCd: vPlantCd,
        vLand1: 'UN',
      }

      const res = await insertHal4Mate(payload)

      //SAP 호출 된 정보를 내용물 처방에 넣어준다.
      const result = await selectMusoguContensDetailList(searchParams)
      // musogu.list = result.list
      // musogu.musoguYnList = result.musoguYnList 

      if(result){
        resData.value.list = result.list
        resData.value.musoguYnList = result.musoguYnList

        musogu.mtrList = [
          ...resData.value.mtr04List,
          ...resData.value.mtr05List,
          ...resData.value.mtr06List,
        ]
        musogu.list = resData.value.list

        musogu.list.map((vo, idx) => {
          if (musogu.mtrList.filter(mtr => mtr.vBuffer1 === vo.vBuffer1).length > 0) {
            backColorIdxs.num.push(idx)
          }
        })

        openAsyncAlert({ message: '갱신되었습니다.' })
      }


    }

    const fnTestReqSave = async () => {   
      const vRepContPkCd = payload.value.vRepContPkCd

      if (commonUtils.isEmpty(vRepContPkCd)) {
        await openAsyncAlert({ message: '대표 내용물을 선택해 주세요.' })
        return
      }

      const repCvo = resData.value.contList.find(cvo => cvo.vContPkCd === vRepContPkCd)

      if (repCvo) {
        const vRepLotCd = repCvo.vLotCd
      
        if (commonUtils.isEmpty(vRepLotCd)) {
          await openAsyncAlert({ message: 'Lot를 선택해 주세요.' })
          return
        }

        if (commonUtils.isEmpty(payload.value.vTrCompleteReqDt)) {
          await openAsyncAlert({ message: "완료요청일을 선택해 주세요." })
          return
        }

      }

      const msgReq = resData.value.musoguYnList.filter(cvo => cvo.vFlagRequest === 'Y')
      if(msgReq.length > 0){
        await openAsyncAlert({ message: "정보가 존재하지 않는 4자코드가 있습니다.<br/>붉은 색으로 표시된 4자코드를 클릭하여 갱신해 주시기 바랍니다." })
        return
      }
      
      const sumRateValue = getSumRate()

      if (sumRateValue != 100) {
        await openAsyncAlert({ message: "처방 합계가 100%가 되어야 무소구 시험의뢰가 가능합니다.<br/>원료배합을 확인해주세요." })
        return
      }
      
      const qsLen = document.querySelectorAll('.bg-red').length

      if (qsLen > 0) {
        await openAsyncAlert({ message: "무소구 시험의뢰가 안되는 원료가 포함되어 있습니다.<br/>원료배합을 확인해주세요." })
        return
      }

      payload.value.vContcd = repCvo.vContCd || ''
      payload.value.vPlantCd = repCvo.vPlantCd || ''
      payload.value.nVersion = repCvo.nVersion || ''
      payload.value.vLotCd = repCvo.vLotCd || ''
      payload.value.vContPkCd = repCvo.vContPkCd || ''
      payload.value.vFlagNotAdd = resData.value.noteVo.vFlagNotAdd
      payload.value.vFlagApPromise = resData.value.noteVo.vFlagApPromise

      if(flagLotCompleYn.value !== "Y"){
        const confirmMessage = '<span style="font-weight:bold; color:red;">시험의뢰시 해당 Lot은 더이상 수정 할 수 없습니다.</span><br/>저장 하시겠습니까?'
        if (!await openAsyncConfirm({ message: confirmMessage })) {
          return
        }
      }

      const params = {
        ...payload.value,
        ...{
          contList: resData.value.contList.filter(cvo => cvo.vContPkCd === payload.value.vRepContPkCd) || []
        }
      }

      goSkinTestReqSave(params)
    }

    const init = async () => {
      findCodeList(['DOSAGE_FORM'])
      //DOSAGE_FORM:제형

      //실험노트 정보 불러오기
      //실험노트 마스터 정보
      //실험노트 내용물 정보
      //실험노트 로트 정보
      resData.value = await selectMusoguList(searchParams)
      
      if (resData.value) {
        payload.value.vTrGoalCd = resData.value.vTrGoalCd
        payload.value.vTrMrqTypeCd = resData.value.vTrMrqTypeCd
        payload.value.vFlagNotAdd = resData.value.noteVo.vFlagNotAdd
        payload.value.vFlagApPromise = resData.value.noteVo.vFlagApPromise
        payload.value.vFlagApPromiseNote = resData.value.noteVo.vFlagApPromiseNote
        vNotAddNoteTxt.value = resData.value.noteVo.vNotAddNote
        
        if (resData.value.contList) {
          const repCvo = resData.value.contList.find(cvo => cvo.vContPkCd === searchParams.vOtherContPkCd)
  
          if (repCvo) {
            payload.value.vRepContPkCd = repCvo.vContPkCd
            vChicePrdCd.value = repCvo.vPrdCd
            vChiceContNm.value = repCvo.vContNm
            payload.value.vTrRelationProductCd = repCvo.vPrdCd
            payload.value.vTrMusoguProductNm = repCvo.vContNm
          }
        }

        if (resData.value.lastTrVo) {
          payload.value.vDosageFormCd = resData.value.lastTrVo.vDosageFormCd
        }
      } else {
        closeAsyncPopup()
      }

    }

    init()

    return {
      t,
      commonUtils,
      codeGroupMaps,
      useLabCommon,
      closeAsyncPopup,
      searchParams,
      selectMusoguList,
      selectMusoguContensDetailList,
      vChicePrdCd,
      vChiceContNm,
      musogu,
      resData,
      payload,
      fnTestReqSave,
      fnSelectOption,
      fnClickRep,
      getSumRate,
      getBgBlue,
      getBgRed,
      clickHal4,
      flagLotCompleYn,
      vNotAddNoteTxt,
    }
  }
}
</script>