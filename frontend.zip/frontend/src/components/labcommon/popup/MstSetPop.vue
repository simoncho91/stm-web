<template>
  <div class="modal-content modal-content__width--auto" style="width: 900px;">
    <div class="modal-header">
      <div class="modal-title">Select information</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({ message: '' })"></button>
    </div>
    <div class="modal-body">
      <div class="modal-body__item material-setting">

        <div v-if="noteType === 'MU' || noteType === 'HBO'" class="ui-checkbox__inner flex-row">
          <div style="width: 50%; -webkit-box-flex: 1; flex: 1 1 50%;">
            <template v-for="(cont, index) in mstInfo.contList" :key="index">
              <template v-if="(index + 1) % 2 === 1">
                <div class="modal-sub-title">{{ cont.vContCd }}</div>
                <div class="material-setting__content">
                  <div class="ui-radio__list">
                    <div class="ui-radio__inner">
                      <template v-for="(ver, verIndex) in mstInfo.verList" :key="verIndex">
                        <ap-input-check v-if="cont.vContPkCd === ver.vContPkCd" v-model:model="ver.vFlagView"
                          :id="ver.vContPkCd + '_' + ver.nVersion" :checked="ver.vFlagView === 'Y' || ver.nVersion === 0"
                          value="Y" false-value="N" :label="ver.vVersionTxt"></ap-input-check>
                      </template>
                    </div>
                  </div>
                </div>
                <br v-if="mstInfo.contList.length !== (index + 1)" />
              </template>
            </template>
          </div>

          <div style="width: 50%; -webkit-box-flex: 1; flex: 1 1 50%;">
            <template v-for="(cont, index) in mstInfo.contList" :key="index">
              <template v-if="(index + 1) % 2 === 0">
                <div class="modal-sub-title">{{ cont.vContCd }}</div>
                <div class="material-setting__content">
                  <div class="ui-radio__list">
                    <div class="ui-radio__inner">
                      <template v-for="(ver, verIndex) in mstInfo.verList" :key="verIndex">
                        <ap-input-check v-if="cont.vContPkCd === ver.vContPkCd" v-model:model="ver.vFlagView"
                          :id="ver.vContPkCd + '_' + ver.nVersion" :checked="ver.vFlagView === 'Y' || ver.nVersion === 0"
                          value="Y" false-value="N" :label="ver.vVersionTxt"></ap-input-check>
                      </template>
                    </div>
                  </div>
                </div>
                <br v-if="mstInfo.contList.length !== (index + 1)" />
              </template>
            </template>
          </div>
        </div>
        <template v-else>
          <template v-for="(cont, index) in mstInfo.contList" :key="index">
            <div class="modal-sub-title">{{ cont.vContCd }}</div>
            <div class="material-setting__content">
              <div class="ui-radio__list">
                <div class="ui-radio__inner">
                  <template v-for="(ver, verIndex) in mstInfo.verList" :key="verIndex">
                    <ap-input-check v-if="cont.vContPkCd === ver.vContPkCd" v-model:model="ver.vFlagView"
                      :id="ver.vContPkCd + '_' + ver.nVersion" :checked="ver.vFlagView === 'Y' || ver.nVersion === 0"
                      value="Y" false-value="N" :label="ver.vVersionTxt"></ap-input-check>
                  </template>
                </div>
              </div>
            </div>
            <br v-if="mstInfo.contList.length !== (index + 1)" />
          </template>
        </template>

        <div class="divide-line mt-15 mb-20"></div>

        <div class="modal-sub-title">Lot 추가 시</div>
        <div class="material-setting__content">
          <div class="ui-radio__list ui-radio__list--tripartition">
            <div class="ui-radio__inner">
              <ap-input-radio v-model:model="lotAddType.chk" value="B" style="width: 40%" label="이전 Lot 함량 복사"
                id="lotAddTypeY" name="lotAddTypeY"></ap-input-radio>
              <ap-input-radio v-model:model="lotAddType.chk" value="E" label="빈 Lot 생성" id="lotAddTypeN"
                name="lotAddTypeN"></ap-input-radio>
            </div>
          </div>
        </div>

        <div class="divide-line mt-15 mb-20"></div>

        <div class="mateial-setting__item">
          <div class="ui-buttons">
            <button type="button"
              class="ui-button ui-button__height--28 ui-button__font--12 ui-button__radius--2 ui-button__border--blue"
              @click="onAllSelect(false)">Select
              all</button>
            <button type="button"
              class="ui-button ui-button__height--28 ui-button__font--12 ui-button__radius--2 ui-button__border--blue"
              @click="onAllSelect(true)">Clear
              all</button>
          </div>

          <div class="mt-15">
            <div class="ui-checkbox__list ui-checkbox__list--column">
              <div class="ui-checkbox__inner flex-row">
                <template v-for="(mstSet, index) in mstInfo.mstSetList" :key="index">
                  <div class="ui-checkbox-block col-6">
                    <ap-input-check v-model:model="mstSet.vFlagHide" :id="mstSet.vColumnSetCd"
                      :checked="mstSet.vFlagHide === 'Y'" value="N" false-value="Y"
                      :label="mstSet.vColumnSetCdnm"></ap-input-check>
                  </div>
                </template>
              </div>
            </div>
          </div>
        </div>

        <div class="board-bottom board-bottom__with--button">
          <div class="board-bottom__inner">
            <div class="ui-buttons ui-buttons__right">
              <button type="button" class="ui-button ui-button__bg--skyblue font-weight__300"
                @click="onMstSetSave">저장</button>
              <button type="button" class="ui-button ui-button__bg--lightgray"
                @click="closeAsyncPopup({ message: '닫기' })">닫기</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { reactive, ref, inject } from 'vue'
import { useMaterialCommon } from '@/compositions/labcommon/useMaterialCommon'
import { useStore } from 'vuex'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'MstSetPop',
  components: {
  },
  emits: ['selectFuncMstSetPop'],
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: '',
          vContPkCd: '',
          vPlantCd: '',
          vCodeType: '',
          vLotAddType: 'B',
        }
      }
    }
  },
  setup(props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncAlert', 'closeAsyncPopup'])
    const store = useStore()
    const noteType = store.getters.getNoteType()
    const searchParams = reactive({
      vLabNoteCd: props.popParams.vLabNoteCd,
      vContPkCd: props.popParams.vContPkCd,
      vPlantCd: props.popParams.vPlantCd,
      vCodeType: props.popParams.vCodeType,
    })
    const mstInfo = ref({
      contList: [],
      verList: [],
      mstSetList: [],
    })
    const lotAddType = reactive({
      chk: props.popParams.vLotAddType
    })

    const {
      selcetLabNoteVersionList,
      updateVersionView,
    } = useMaterialCommon()

    const init = async () => {
      mstInfo.value = await selcetLabNoteVersionList(searchParams)
    }

    const onAllSelect = (flag) => {
      mstInfo.value.mstSetList = mstInfo.value.mstSetList.map(o => {
        return {
          ...o,
          vFlagHide: flag ? 'Y' : 'N'
        }
      })
    }

    const onMstSetSave = async () => {
      const contVerList = mstInfo.value.verList.map(o => {
        return {
          vContPkCd: o.vContPkCd,
          nVersion: o.nVersion,
          vFlagView: o.vFlagView
        }
      })

      if (contVerList.filter(o => o.vFlagView === 'Y').length === 0) {
        openAsyncAlert({ message: '적어도 한개 이상의 버전을 선택해야 합니다.' })
        return
      }
      else if (!lotAddType.chk) {
        openAsyncAlert({ message: 'Lot 추가 옵션을 선택해 주세요.' })
        return
      }

      const mstSetList = mstInfo.value.mstSetList

      const response = await updateVersionView({
        contVerList,
        mstSetList,
        vLabNoteCd: searchParams.vLabNoteCd,
        vLotAddType: lotAddType.chk,
      })
      if (response === 'success') {
        openAsyncAlert({ message: '저장되었습니다.' })
        context.emit('selectFuncMstSetPop')
      }
      closeAsyncPopup({ message: '' })
    }

    init()

    return {
      t,
      commonUtils,
      noteType,
      searchParams,
      mstInfo,
      lotAddType,
      onAllSelect,
      onMstSetSave,
      closeAsyncPopup,
    }
  }
}
</script>