<template>
  <div class="modal-content modal-content__width--950">
    <div class="modal-header">
      <div class="modal-title">4M 원료 검색</div>
      <button type="button" class="modal-close" @click="fnClose()"></button>
    </div>
    <div class="modal-body">
      <div class="board-top">
        <div class="board-flex">
          <div class="board-cell">
            <div class="search-form">
              <div class="search-form__inner">
                <ap-input
                  v-model:value="searchParams.vKeyword"
                  input-class="ui-input ui-input__width--535"
                  placeholder="4M이력번호 OR 원료코드 OR 원료명 OR 협력사"
                  id="vUserSearchPopKeyword"
                  @keypress-enter="fnSearch(1)"
                >
                </ap-input>
                <button 
                  type="button"
                  class="button-search"
                  @click="fnSearch(1)"
                >
                  검색
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="myboard-table">
        <div class="myboard-table__inner">
          <table class="ui-table ui-table__th--border-radius--0 ui-table__td--40 text-center">
            <colgroup>
              <col style="width:5%">
              <col style="width:15%">
              <col style="width:15%">
              <col style="width:15%">
              <col style="width:10%">
              <col style="width:10%">
              <col style="width:10%">
              <col style="width:10%">
              <col style="width:10%">
            </colgroup>
            <thead>
              <tr>
                <th>NO</th>
                <th>4M이력번호</th>
                <th>원료코드</th>
                <th>원료명</th>
                <th>협력사</th>
                <th>변경요청일</th>
                <th>담당자</th>
                <th>진행상태</th>
                <th>처리결과</th>
              </tr>
            </thead>
            <tbody>
              <template v-if="list && list.length > 0">
                <tr v-for="(vo, idx) in list" :key="'user_' + idx" @click="fnApply(vo)">
                  <td>{{ page.totalCnt - ((page.pageSize * (page.nowPageNo-1)) + idx)}}</td>
                  <td>{{ vo.v4mHisNum }}</td>
                  <td>{{ vo.vSapCd }}</td>
                  <td>{{ vo.vMatNm }}</td>
                  <td>{{ vo.vCompNm }}</td>
                  <td>{{ vo.vModReqDtm }}</td>
                  <td>{{ vo.vReqcnm }}</td>
                  <td>{{ vo.vStatusCdnm }}</td>
                  <td>{{ vo.vResStatusCdnm }}</td>
                </tr>
              </template>
              <template v-else>
                <tr>
                  <td colspan="9">
                    <div class="no-result">
                      {{ t('common.msg.no_data') }}
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>

        <div class="board-bottom">
          <div class="board-bottom__inner">
            <Pagination
              v-if="list && list.length > 0"
              :page-info="page"
              @click="fnSearch"
            >
            </Pagination>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, inject, reactive, onMounted } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'Mat4MMstSearchPop',
  components: {
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue'))
  },
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vKeyword: '',
          vSearchType: 'lab_note',
          vMaterialCd: '',
          vLabDeptCd: '',
          vLabNoteCd: '',
        }
      }
    }
  },
  emits: ['selectFunc'],
  setup (props, context) {
    const t = inject('t')
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])
    const {
      page,
      list,
      selectMat4MMstList,
    } = useLabCommon()

    const searchParams = reactive({
      vKeyword: props.popParams.vKeyword || '',
      vSearchType: props.popParams.vSearchType || 'lab_note',
      vMaterialCd: props.popParams.vMaterialCd || '',
      vLabDeptCd: props.popParams.vLabDeptCd || '',
      vLabNoteCd: props.popParams.vLabNoteCd || '',
      nowPageNo: 1
    })

    const fnSearch = async (pg) => {
      if (!pg) {
        pg = 1
      }

      searchParams.nowPageNo = pg

      await selectMat4MMstList(searchParams)

      if (list.value && list.value.length === 1) {
        fnApply(list.value[0])
      }
    }

    const fnApply = (item) => {
      context.emit('selectFunc', item)

      fnClose()
    }

    const fnClose = () => {
      closeAsyncPopup()
    }

    const init = () => {
      fnSearch(1)
    }

    init()

    onMounted(() => {
      const input = document.querySelector('#vUserSearchPopKeyword')
      input.focus()
    })

    return {
      t,
      searchParams,
      page,
      list,
      fnSearch,
      fnApply,
      fnClose,
    }
  }
}
</script>

<style scoped>
  .ui-table tbody tr {
    cursor: pointer;
  }
</style>