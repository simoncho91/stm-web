<template>
  <div class="modal-content modal-content__width--701">
    <div class="modal-header">
      <div class="modal-title">상세조회</div>
      <button type="button" class="modal-close" @click="onClose"></button>
    </div>
    <div class="modal-body">

      <div class="modal-body__scroll">
        <div class="search-depart-table">
          <div class="search-depart-table__inner">
            <table class="ui-table__td--40">
              <colgroup>
                <col style="width:13rem">
                <col style="width:auto">
              </colgroup>
              <tbody>
                <tr>
                  <th>내용물명</th>
                  <td><div class="font-weight__600 color-blue">{{ list?.[0].vContNm }}</div></td>
                </tr>
                <tr>
                  <th>연구원</th>
                  <td>{{ list?.[0].vUsernm }}</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div class="search-detail-table mt-15">
            <div class="search-detail-table__inner">
              <table class="ui-table__modal">
                <colgroup>
                  <col style="width:13rem">
                  <col style="width:auto">
                  <col style="width:14rem">
                </colgroup>
                <thead>
                  <tr>
                    <th>원료코드</th>
                    <th>원료명</th>
                    <th>{{ list?.[0].vLotNm }} 함량</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="(vo, index) in list" :key="index">
                    <td>{{ vo.vMateCd }}</td>
                    <td class="text-left pl-10">{{ vo.vMateNm }}</td>
                    <td>{{ vo.nRate }}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <div class="search-detail-total">
            <div class="search-detail-total__inner">
              <div class="search-detail-total__text">합계</div>
              <div class="search-detail-total__num">{{ list?.[0].nRateSum }}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { reactive, ref, inject } from 'vue'
import { useMaterialCommon } from '@/compositions/labcommon/useMaterialCommon'

export default {
  name: 'BookmarkMateRatePop',
  components: {
  },
  emits: ['selectFunc'],
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: '',
          vContPkCd: '',
          nVersion: 0,
          vLotCd: '',
        }
      }
    }
  },
  emits: ['closeFunc'],
  setup(props, context) {
    const t = inject('t')
    const list = ref(null)
    const searchParams = reactive({
      vLabNoteCd: props.popParams.vLabNoteCd,
      vContPkCd: props.popParams.vContPkCd,
      nVersion: props.popParams.nVersion,
      vLotCd: props.popParams.vLotCd,
    })

    const {
      selcetLabNoteMateRateInfo,
    } = useMaterialCommon()

    const init = async () => {
      list.value = await selcetLabNoteMateRateInfo(searchParams)
    }

    const onClose = () => {
      context.emit('closeFunc')
    }

    init()

    return {
      t,
      list,
      onClose,
    }
  }
}
</script>