<template>
  <div class="modal-content modal-content__width--122">
    <div class="modal-header">
      <div class="modal-title">시험의뢰 (부향)</div>
      <button
        type="button"
        class="modal-close"
        @click="closeAsyncPopup"
      ></button>
    </div>
    <div class="modal-body">
      <div class="search-detail-table">
        <div class="search-detail-table__inner">
          <table class="ui-table__modal pd">
            <colgroup>
              <col style="width:10%">
              <col style="width:17%">
              <col style="width:auto">
              <col style="width:12%">
              <col style="width:17%">
              <col style="width:17%">
            </colgroup>
            <thead>
              <tr>
                <th>대표</th>
                <th>내용물코드/제품코드</th>
                <th>내용물명</th>
                <th>플랜트</th>
                <th>LOT</th>
                <th>비고 </th>
              </tr>
            </thead>
            <tbody>
              <template v-if="resData.contList?.length > 0">
                <tr v-for="(cvo, idx1) in resData.contList" :key="`tr_${idx1}`">
                  <td>
                    <div class="ui-label jc-c">
                      <ap-input-radio
                        v-model:model="payload.vRepContPkCd"
                        :value="cvo.vContPkCd"
                        :id="`flagNew_${idx1}`"
                        name="flagNew"
                        @click="fnClickRep(cvo)"
                      ></ap-input-radio>
                    </div>
                  </td>
                  <td>{{ cvo.vContCd }} / {{ cvo.vPrdCd }}</td>
                  <td>
                    <div class="tit__inner">
                      {{ cvo.vContNm }}
                    </div>
                    </td>
                  <td>{{ cvo.vPlantCd }}</td>
                  <td>
                    <div class="ui-select-block">
                      <ap-selectbox
                        v-model:value="cvo.vLotCd"
                        :options="cvo.subList"
                        :disabled="payload.vRepContPkCd !== cvo.vContPkCd"
                        codeKey="vLotCd"
                        codeNmKey="vLotNm"
                        @change="fnSelectOption($event, cvo)"
                      >
                      </ap-selectbox>
                    </div>
                  </td>
                  <td></td>
                </tr>
              </template>
              <template v-else>
                <tr>
                  <td colspan="6">
                    <div class="no-result">
                      {{ t('common.msg.no_data') }}
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>

      <div class="tableTitle mt-2">정보 입력</div>
      <div class="board-top mb-0">
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">완료요청일<span class="ui-require"><span class="for-a11y">(필수)</span></span></dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="search-form">
                <div class="search-form__inner">
                  <ap-date-picker
                    v-model:date="payload.vTrCompleteReqDt"
                    :read-only="true"
                  />
                </div>
              </div>

            </dd>
          </dl>
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">제형<span class="ui-require"><span class="for-a11y">(필수)</span></span></dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="search-form">
                <div class="search-form__inner">
                  <ap-selectbox
                    v-model:value="payload.vDosageFormCd"
                    :options="codeGroupMaps['DOSAGE_FORM']"
                  />
                </div>
              </div>
            </dd>
          </dl>

        </div>
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">{{ payload.vTestTypeNm || '-' }}</dt>
            <dd class="search-bar__val search-bar__val--flexible" style="text-align: left;">
              {{ payload.vTestValue }}
            </dd>
          </dl>
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">pH</dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <ap-input :is-number="false" v-model:value="payload.vTrPh"></ap-input>
            </dd>
          </dl>

        </div>
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100 mt-m3">메시지</dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <ap-text-area
                :is-with-byte="true"
                v-model:value="payload.vTrComment"
                :maxlength="2000"
              ></ap-text-area>
            </dd>
          </dl>

        </div>
      </div>
      <div class="board-bottom ">
        <div class="board-bottom__inner">
          <div class="ui-buttons ml-auto ui-buttons__right">
            <button
              type="button"
              class="ui-button ui-button__bg--skyblue font-weight__300"
              @click="fnTestReqSave"
            >시험의뢰</button>
            <button
              type="button"
              class="ui-button ui-button__bg--lightgray"
              @click="closeAsyncPopup"
            >닫기</button>
          </div>
        </div>

      </div>
    </div>
  </div>
</template>

<script>
import { reactive, ref, inject } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useActions } from 'vuex-composition-helpers'
import { useTestReqCommon } from '@/compositions/labcommon/useTestReqCommon'

export default {
  name: 'AllTestReqFlavorPop',
  components: {
  },
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: ''
        , vContPkCd: ''
        , nVersion: ''
        , vLotCd: ''
        , vPlantCd: ''
        , vMrqTypeCd: ''
        }
      }
    }
  },
  emits: ['selectFunc'],
  setup(props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { openAsyncConfirm, openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncConfirm', 'openAsyncAlert', 'closeAsyncPopup'])

    const flagLotCompleYn = ref('')

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const { 
      selectPrdTestReqFlavorInfo,
      goSkinTestReqSave,
    } = useTestReqCommon()

    const searchParams = ref({
      vLabNoteCd: props.popParams.vLabNoteCd,
      // vContPkCd: props.popParams.vContPkCd,
      vOtherContPkCd: props.popParams.vContPkCd,
      nVersion: props.popParams.nVersion,
      vLotCd: props.popParams.vLotCd,
      vPlantCd: props.popParams.vPlantCd,
      vMrqTypeCd: props.popParams.vMrqTypeCd,
      vTrMrqTypeCd: props.popParams.vMrqTypeCd,
      vGateCd: props.popParams.vGateCd,
    })

    // 테스트용
    // const searchParams = ref({
    //   vLabNoteCd: 'LMS20230313010281',
    //   vOtherContPkCd: 'LCO20230313011941',
    //   nVersion: 4,
    //   vLotCd: props.popParams.vLotCd,
    //   vPlantCd: '1110',
    //   vMrqTypeCd: props.popParams.vMrqTypeCd,
    //   vTrMrqTypeCd: props.popParams.vMrqTypeCd,
    //   vGateCd: 'GATE_1',
    // })

    const resData = ref({})

    const payload = ref({
      vRepContPkCd: '',
      vRepContCd: '',
      vRepLotCd: '',
      vRepPlantCd: '',
      nRepVersion: '',

      vFlagAction: 'SAVE_TEST_REQ',

      // 완료 요청일
      vTrCompleteReqDt: '',
      // 제형
      vDosageFormCd: '',
      // 점도
      vTestType: '',
      vTestTypeNm: '',
      vTestValue: '',
      // pH
      vTrPh: '',
      // 메시지
      vTrComment: '',

      vTrPrdCd: '',
    })

    const fnSelectOption = (value, vo) => {
      const lvo = vo.subList.find(svo => svo.vLotCd === value)

      if (lvo) {
        payload.value.vTestType = lvo.vTestType
        payload.value.vTestTypeNm = lvo.vTestTypeNm
        payload.value.vTestValue = lvo.vTestValue
        payload.value.vTrPh = lvo.vPh
        flagLotCompleYn.value = lvo.vFlagComplete

        vo.nVersion = lvo.nVersion
        vo.vLotNm = lvo.vLotNm
      } else {
        payload.value.vTestType = ''
        payload.value.vTestTypeNm = ''
        payload.value.vTestValue = ''
        payload.value.vTrPh = ''
        flagLotCompleYn.value = ''

        vo.nVersion = ''
        vo.vLotNm = ''
      }
    }

    const fnClickRep = (vo) => {
      const lotCd = vo?.vLotCd

      if (lotCd) {
        const lvo = vo.subList.find(svo => svo.vLotCd === lotCd)

        if (lvo) {
          payload.value.vTestType = lvo.vTestType
          payload.value.vTestTypeNm = lvo.vTestTypeNm
          payload.value.vTestValue = lvo.vTestValue
          payload.value.vTrPh = lvo.vPh
          flagLotCompleYn.value = lvo.vFlagComplete
        } else {
          payload.value.vTestType = ''
          payload.value.vTestTypeNm = ''
          payload.value.vTestValue = ''
          payload.value.vTrPh = ''
          flagLotCompleYn.value = ''
        }
      } else {
        payload.value.vTestType = ''
        payload.value.vTestTypeNm = ''
        payload.value.vTestValue = ''
        payload.value.vTrPh = ''
        flagLotCompleYn.value = ''
      }
    }

    const fnTestReqSave = async () => {
      const vRepContPkCd = payload.value.vRepContPkCd

      if (commonUtils.isEmpty(vRepContPkCd)) {
        await openAsyncAlert({ message: '대표 내용물을 선택해 주세요.' })
        return
      }

      const repCvo = resData.value.contList.find(cvo => cvo.vContPkCd === vRepContPkCd)

      if (repCvo) {
        const vRepLotCd = repCvo.vLotCd

        if (commonUtils.isEmpty(vRepLotCd)) {
          await openAsyncAlert({ message: 'Lot를 선택해 주세요.' })
          return
        }
        
        if (commonUtils.isEmpty(payload.value.vTrCompleteReqDt)) {
          await openAsyncAlert({ message: '완료 요청일을 입력해 주세요.' })
          return
        }

        if (commonUtils.isEmpty(payload.value.vDosageFormCd)) {
          await openAsyncAlert({ message: '제형을 선택해 주세요.' })
          return
        }
        
        if (!commonUtils.checkByte(payload.value.vTrComment, 2000)) {
          await openAsyncAlert({ message: '메시지는 2000byte (한글 : 666자, 영문 : 2000자) 이내로 입력해 주세요.' })
          return
        }

        payload.value.vRepContCd = repCvo.vContCd || ''
        payload.value.vRepLotCd = vRepLotCd
        payload.value.vRepPlantCd = repCvo.vPlantCd || ''
        payload.value.nRepVersion = repCvo.nVersion || ''

        // payload.value.vTrPrdCd = repCvo.vTrPrdCd || ''
      }

      if(flagLotCompleYn.value !== "Y"){
        const confirmMessage = '<span style="font-weight:bold; color:red;">시험의뢰시 해당 Lot은 더이상 수정 할 수 없습니다.</span><br/>저장 하시겠습니까?'
        if (!await openAsyncConfirm({ message: confirmMessage })) {
          return
        }
      }

      const params = {
        ...searchParams.value,
        ...payload.value,
        ...{
          contList: resData.value.contList.filter(cvo => cvo.vContPkCd === payload.value.vRepContPkCd) || []
        }
      }

      goSkinTestReqSave(params)
    }

    const init = async () => {
      await findCodeList(['DOSAGE_FORM'])
      
      resData.value = await selectPrdTestReqFlavorInfo(searchParams.value)

      if (resData.value) {
        if (resData.value.contList) {
          const repCvo = resData.value.contList.find(cvo => cvo.vContPkCd === searchParams.value.vOtherContPkCd)
  
          if (repCvo) {
            payload.value.vRepContPkCd = repCvo.vContPkCd
          }
        }
        if (resData.value.lastTrVo) {
          payload.value.vDosageFormCd = resData.value.lastTrVo.vDosageFormCd
        }
      } else {
        closeAsyncPopup()
      }
    }

    init()

    return {
      t,
      codeGroupMaps,
      closeAsyncPopup,
      selectPrdTestReqFlavorInfo,
      resData,
      payload,
      fnSelectOption,
      fnClickRep,
      flagLotCompleYn,
      fnTestReqSave,
    }
  }
}
</script>