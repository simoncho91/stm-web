<template>
  <div class="modal-content" style="width: 130rem;">
    <div class="modal-header">
      <div class="modal-title">알러젠 표기 / 미표기 비교하기</div>
      <button
        type="button"
        class="modal-close"
        @click="closeAsyncPopup"
      ></button>
    </div>
    <div class="modal-body">
      <div class="modal-body__scroll">
        <div class="form-flex form-flex__start">
          <div class="form-flex__cell">
            <div class="like-search-bar__key">알러젠 표기</div>
            <div class="search-detail-table mt-15">
              <div class="search-detail-table__inner">
                <table class="ui-table__modal">
                  <colgroup>
                    <col style="width:8.2rem">
                    <col style="width:auto">
                    <col style="width:15rem">
                  </colgroup>
                  <thead>
                    <tr>
                      <th>성분코드</th>
                      <th>표시명(한글)</th>
                      <th>함량 (%)</th>
                    </tr>
                  </thead>
                  <tbody>
                    <template v-if="popParams.allergenList?.length > 0">
                      <tr
                        v-for="(vo, idx) in popParams.allergenList"
                        :key="`tr_al_${idx}`"
                        :style="`background:${vo.vZarjcd === 'X' ? 'yellow' : ''}`"
                      >
                        <td>{{ vo.vConcd }}</td>
                        <td class="text-left pl-10">{{ vo.vPsnameKo }}</td>
                        <td>{{ vo.nConPer }}</td>
                      </tr>
                    </template>
                    <template v-else>
                      <tr>
                        <td colspan="3">
                          <div class="no-result">
                            {{ t('common.msg.no_data') }}
                          </div>
                        </td>
                      </tr>
                    </template>
                  </tbody>
                </table>
              </div>
            </div>
            <div class="search-detail-total">
              <div class="search-detail-total__inner">
                <div class="search-detail-total__text">합계</div>
                <div class="search-detail-total__num search-detail-total__num--width-150">{{ popParams.allergenList[0]?.nSumPer ?? 0 }}</div>
              </div>
            </div>
          </div>
          <div class="form-flex__cell">
            <div class="like-search-bar__key">알러젠 미표기</div>
            <div class="search-detail-table mt-15">
              <div class="search-detail-table__inner">
                <table class="ui-table__modal">
                  <colgroup>
                    <col style="width:8.2rem">
                    <col style="width:auto">
                    <col style="width:15rem">
                  </colgroup>
                  <thead>
                    <tr>
                      <th>성분코드</th>
                      <th>표시명(한글)</th>
                      <th>함량 (%)</th>
                    </tr>
                  </thead>
                  <tbody>
                    <template v-if="popParams.noAllergenList?.length > 0">
                      <tr v-for="(vo, idx) in popParams.noAllergenList" :key="`tr_nal_${idx}`">
                        <td>{{ vo.vConcd }}</td>
                        <td class="text-left pl-10">{{ vo.vPsnameKo }}</td>
                        <td>{{ vo.nConPer }}</td>
                      </tr>
                    </template>
                    <template v-else>
                      <tr>
                        <td colspan="3">
                          <div class="no-result">
                            {{ t('common.msg.no_data') }}
                          </div>
                        </td>
                      </tr>
                    </template>
                  </tbody>
                </table>
              </div>
            </div>
            <div class="search-detail-total">
              <div class="search-detail-total__inner">
                <div class="search-detail-total__text">합계</div>
                <div class="search-detail-total__num search-detail-total__num--width-150">{{ popParams.noAllergenList[0]?.nSumPer ?? 0 }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, inject } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'IngrdCompareInfoPop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          // vContPkcd: '',
          // vLand: '',
          // vLeaveType: ''
          allergenList: [],
          noAllergenList: []
        }
      }
    }
  },
  setup(props, context) {
    const t = inject('t')
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])

    // const {
    //   selectIngrdCompareInfo
    // } = useLabCommon()

    // const resData = ref({})

    // const init = async () => {
    //   if (props.popParams) {
    //     resData.value = await selectIngrdCompareInfo(props.popParams)

    //     if (!resData.value) {
    //       closeAsyncPopup()
    //     }
    //   }
    // }

    // init()

    return {
      // resData,
      t,
      closeAsyncPopup,
    }
  }
}
</script>
