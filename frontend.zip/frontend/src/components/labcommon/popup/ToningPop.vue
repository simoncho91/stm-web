<template>
  <div class="modal-content modal-content__width--auto" style="width:431px">
    <div class="modal-header">
      <div class="modal-title">조색 설정</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({ message: '' })"></button>
    </div>
    <div class="modal-body">
      <div class="search-depart-table">
        <div class="search-depart-table__inner">
          <table class="ui-table__td--40">
            <colgroup>
              <col style="width:10rem">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr>
                <th>단위</th>
                <td>
                  <div class="ui-radio__list">
                    <div class="ui-radio__inner">
                      <ap-input-radio v-model:model="toningParams.vToningType" value="g" label="gram" id="vToningTypeG"
                        name="vToningType" />
                      <ap-input-radio v-model:model="toningParams.vToningType" value="p" label="%" id="vToningTypeP"
                        name="vToningType" />
                    </div>
                  </div>
                </td>
              </tr>
              <tr>
                <th>값 설정</th>
                <td>
                  <ap-input v-model:value="toningParams.nToning" :isNumber="true" :point="2" :maxlength="5"
                    class="ui-input ui-input__width--124 ui-input__height--25" />
                  &nbsp;{{ toningParams.vToningType === 'g' ? 'g' : '%' }}
                </td>
              </tr>
              <tr>
                <th>기준 LOT</th>
                <td>
                  <ap-selectbox v-model:value="toningParams.vToningLotCd"
                    :defaultBlank="{ blank: true, value: '', name: '이전 Lot' }" codeKey="vLotCd" codeNmKey="vLotNm"
                    :options="toningParams.lotList.filter(lot => lot.vLotCd.indexOf('tmp_lot') < 0)" />
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div class="board-bottom">
        <div class="board-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--skyblue" @click="onSave">저장</button>
            <button type="button" class="ui-button ui-button__bg--lightgray"
              @click="closeAsyncPopup({ message: '닫기' })">닫기</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { reactive, ref, inject } from 'vue'
import { useMaterialCommon } from '@/compositions/labcommon/useMaterialCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'ToningPop',
  emits: ['selectFuncMstSetPop'],
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: '',
          vToningType: '',
          nToning: '',
          vToningLotCd: '',
          lotList: [],
        }
      }
    }
  },
  setup(props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncAlert', 'closeAsyncPopup'])
    const toningParams = reactive({
      vLabNoteCd: props.popParams.vLabNoteCd,
      vToningType: props.popParams.vToningType,
      nToning: props.popParams.nToning,
      vToningLotCd: props.popParams.vToningLotCd,
      lotList: props.popParams.lotList,
    })

    const {
      updateLabNoteToning,
    } = useMaterialCommon()

    const onSave = async () => {
      if (!toningParams.vToningType) {
        openAsyncAlert({ message: '단위를 선택해 주세요.' })
        return
      }
      else if (!toningParams.nToning) {
        openAsyncAlert({ message: '값 설정을 입력해 주세요.' })
        return
      }

      const response = await updateLabNoteToning(toningParams)
      if (response === 'success') {
        openAsyncAlert({ message: '저장되었습니다.' })
        context.emit('selectFuncMstSetPop')
      }
      closeAsyncPopup({ message: '' })
    }

    return {
      t,
      commonUtils,
      toningParams,
      onSave,
      closeAsyncPopup,
    }
  }
}
</script>