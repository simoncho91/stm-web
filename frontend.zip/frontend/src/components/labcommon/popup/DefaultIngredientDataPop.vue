<template>
  <div class="modal-content modal-content__width--600">
    <div class="modal-header">
      <div class="modal-title">전성분 {{ popParams.vFlagChoice === 'PREVIEW' ? '미리보기' : '등록' }}</div>
      <button
        type="button"
        class="modal-close"
        @click="closeAsyncPopup()"
      ></button>
    </div>

    <div class="modal-body">

      <div class="board-top">
        <div class="board-flex text-left line-height__l">
          ※ Leave-on / Wash-off 에 따라 전성분이 달라지므로, 선택에 주의해주세요.<br>※ Leave-on : 알러젠 착향료가 0.001% 초과시 전성분에 표시됨<br>※ Wash-off : 알러젠 착향료가 0.01% 초과시 전성분에 표시됨
        </div>
      </div>


      <div class="search-depart-table">
        <div class="search-depart-table__inner">
          <table class="ui-table__td--40">
            <colgroup>
              <col style="width:19rem">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr v-if="popParams.vFlagChoice !== 'PREVIEW'">
                <th>내용물코드</th>
                <td>
                  <template v-if="resData.contList && resData.contList.length > 0">
                    <div class="ui-radio__list">
                      <div class="ui-radio__inner">
                        <template v-for="(vo, idx) in resData.contList" :key="'radio_' + idx">
                          <ap-input-radio
                            v-model:model="returnObj.vContPkCd"
                            :value="vo.vContPkCd"
                            :label="vo.vContCd"
                            :id="'ex_radio' + idx"
                            name="exRadio"
                          >
                          </ap-input-radio>
                        </template>
                      </div>
                    </div>
                  </template>
                </td>
              </tr>
              <tr>
                <th>ZPLM34E / ZPLM34</th>
                <td>
                  <div class="ui-radio__list">
                    <div class="ui-radio__inner">
                      <ap-input-radio
                        v-model:model="returnObj.vLand"
                        :value="'UN'"
                        :label="'ZPLM34E'"
                        :id="'land_radio1'"
                        name="landRadio"
                      >
                      </ap-input-radio>
                      <ap-input-radio
                        v-model:model="returnObj.vLand"
                        :value="'KR'"
                        :label="'ZPLM34'"
                        :id="'land_radio2'"
                        name="landRadio"
                      >
                      </ap-input-radio>
                    </div>
                  </div>
                </td>
              </tr>
              <tr>
                <th>LEAVE-ON / WASH-OFF</th>
                <td>
                  <div class="ui-radio__list">
                    <div class="ui-radio__inner">
                      <ap-input-radio
                        v-model:model="returnObj.vLeaveType"
                        :value="'L'"
                        :label="'Leave-on'"
                        :id="'leave_type_radio1'"
                        name="leaveTypeRadio"
                      >
                      </ap-input-radio>
                      <ap-input-radio
                        v-model:model="returnObj.vLeaveType"
                        :value="'R'"
                        :label="'Wash-off'"
                        :id="'leave_type_radio2'"
                        name="leaveTypeRadio"
                      >
                      </ap-input-radio>
                    </div>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div class="board-bottom ">
        <div class="board-bottom__inner">
          <div class="ui-buttons ml-auto ui-buttons__right">
            <button
              v-if="popParams.vFlagChoice === 'PREVIEW'"
              type="button"
              class="ui-button ui-button__bg--skyblue font-weight__300"
              @click="fnReg()"
            >미리보기</button>
            <button
              v-else
              type="button"
              class="ui-button ui-button__bg--skyblue font-weight__300"
              @click="fnReg()"
            >등록</button>
            <button
              type="button"
              class="ui-button ui-button__bg--lightgray"
              @click="closeAsyncPopup()"
            >닫기</button>
          </div>
        </div>

      </div>

    </div>
  </div>
</template>

<script>
import { ref } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useMaterialCommon } from '@/compositions/labcommon/useMaterialCommon'

export default {
  name: 'DefaultIngredientDataPop',
  emits: ['selectFunc'],
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: '',
          vFlagChoice: ''
        }
      }
    }
  },
  setup (props, context) {
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])

    const resData = ref({})
    const returnObj = ref({})

    const {
      selectLabNoteDefaultIngredientData
    } = useMaterialCommon()

    const fnReg = () => {
      context.emit('selectFunc', returnObj)
      closeAsyncPopup()
    }

    const init = async () => {
      if (props.popParams.vLabNoteCd) {
        resData.value = await selectLabNoteDefaultIngredientData(props.popParams)
        returnObj.value = { ...returnObj.value, ...resData.value.deVO }
      }
    }

    init()

    return {
      closeAsyncPopup,
      resData,
      returnObj,
      fnReg,
    }
  }
}
</script>
