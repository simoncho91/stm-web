<template>
  <div class="modal-content" id="evaluate_pop" style="width: 110rem;">
    <div class="modal-header">
      <div class="modal-title">심사번호 검색</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({message: ''})"></button>
    </div>
    <div class="modal-body">
      <div class="board-top">
        <div class="search-form">
          <div class="search-bar__left">
            <div class="search-bar__row">
              <dl class="search-bar__item">
                <dt class="search-bar__key search-bar__width--90">주성분</dt>
                <dd class="search-bar__val">
                  <div class="form-flex">
                    <div class="form-flex-cell form-flex__cell--5">
                      <ap-selectbox
                        v-model:value="searchParams.vSearchPrior"
                        :options="[{vSubCode: 'A', vSubCodenm: 'AND'}, {vSubCode: 'O', vSubCodenm: 'OR'}, {vSubCode: 'N', vSubCodenm: 'NOT'}]"
                      >
                      </ap-selectbox>
                    </div>
                    <div class="form-flex-cell form-flex__cell--5">
                      <div class="search-form">
                        <div class="search-form__inner">
                          <ap-input
                            v-model:value="searchParams.vMateKeyword"
                            input-class="ui-input ui-input__width--450"
                            placeholder="원료코드"
                            @keypress-enter="fnEvaluationMaterialSearchPop()"
                          >
                          </ap-input>
                          <button type="button" class="button-search ui-button__width-auto" @click="fnEvaluationMaterialSearchPop()">주성분 리스트 보기</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </dd>
              </dl>
            </div>

            <!-- 2023.03.29 : add : 검색 조건 추가 -->
            <div class="search-bar__row">
              <dl class="search-bar__item search-bar__item--bipartite">
                <dt class="search-bar__key search-bar__width--90">제형</dt>
                <dd class="search-bar__val">
                  <div class="form-flex">
                    <div class="form-flex-cell form-flex__cell--5 reset_filter_area">
                      <ap-choosebox
                        v-if="codeGroupMaps['EVL01']"
                        v-model:modelChkAll="searchParams.vDosageSrcAllYn"
                        v-model:model="searchParams.arrDosageCode"
                        id="dosagecd"
                        :options="codeGroupMaps['EVL01']"
                      >
                      </ap-choosebox>
                    </div>
                  </div>
                </dd>
              </dl>
              <dl class="search-bar__item search-bar__item--bipartite">
                <dt class="search-bar__key search-bar__width--90">구분</dt>
                <dd class="search-bar__val">
                  <div class="form-flex">
                    <div class="form-flex-cell form-flex__cell--5 reset_filter_area">
                      <ap-choosebox
                        v-if="codeGroupMaps['EV_MATERIAL_TYPE']"
                        v-model:modelChkAll="searchParams.vTypeSrcAllYn"
                        v-model:model="searchParams.arrType"
                        id="funcType"
                        :options="codeGroupMaps['EV_MATERIAL_TYPE']"
                      >
                      </ap-choosebox>
                    </div>
                  </div>
                </dd>
              </dl>
            </div>
            <div class="search-bar__row">
              <dl class="search-bar__item search-bar__item--bipartite">
                <dt class="search-bar__key search-bar__width--90">내수성</dt>
                <dd class="search-bar__val">
                  <div class="form-flex">
                    <div class="form-flex-cell form-flex__cell--5">
                      <div class="ui-checkbox__list">
                        <div class="ui-checkbox__inner reset_filter_area">
                          <ap-input-check
                            v-model:model="searchParams.vChkWrFlag"
                            id="vChkWrFlag"
                            value="Y"
                            label="내수성"
                          >
                          </ap-input-check>
                          <ap-input-check
                            v-model:model="searchParams.vChkLwrFlag"
                            id="vChkLwrFlag"
                            value="Y"
                            label="지속 내수성"
                          >
                          </ap-input-check>
                          <ap-input-check
                            v-model:model="searchParams.vChkWrAllFlag"
                            id="vChkWrAllFlag"
                            value="Y"
                            label="내수성 or 지속 내수성"
                          >
                          </ap-input-check>
                        </div>
                      </div>
                    </div>
                    
                  </div>
                </dd>
              </dl>
              <dl class="search-bar__item search-bar__item--bipartite">
                <dt class="search-bar__key search-bar__width--90">효능</dt>
                <dd class="search-bar__val">
                  <div class="form-flex">
                    <div class="form-flex-cell form-flex__cell--5">
                      <ap-choosebox
                        v-if="codeGroupMaps['EV_MATERIAL_FUNC2']"
                        v-model:modelChkAll="searchParams.vEffSrcAllYn"
                        v-model:model="searchParams.arrEff"
                        id="effFunc"
                        ref="effchoose"
                        :options="codeGroupMaps['EV_MATERIAL_FUNC2']"
                      >
                      </ap-choosebox>
                    </div>
                    <div class="form-flex-cell form-flex__cell--5">
                      <div class="ui-checkbox__list">
                        <div class="ui-checkbox__inner">
                          <ap-input-check
                            v-model:model="searchParams.vSrcIncEffYn"
                            :checked="searchParams.vSrcIncEffYn === 'Y'"
                            value="Y"
                            id="vSrcIncEffYn"
                            label="선택효능 포함한 모든 조합 검색"
                          >
                          </ap-input-check>
                        </div>
                      </div>
                    </div>
                  </div>
                </dd>
              </dl>
            </div>
            <div class="search-bar__row">
              <dl class="search-bar__item search-bar__item--bipartite">
                <dt class="search-bar__key search-bar__width--90">SPF</dt>
                <dd class="search-bar__val">
                  <div class="form-flex">
                    <div class="form-flex-cell form-flex__cell--5">
                      <ap-selectbox
                        v-model:value="searchParams.vSrcSpf"
                        :options="codeGroupMaps['LNC_EV_SPF']"
                      >
                      </ap-selectbox>
                    </div>
                  </div>
                </dd>
              </dl>
              <dl class="search-bar__item search-bar__item--bipartite">
                <dt class="search-bar__key search-bar__width--90">PA</dt>
                <dd class="search-bar__val reset_filter_area">
                  <div class="form-flex">
                    <div class="form-flex-cell form-flex__cell--5">
                      <ap-choosebox
                        v-model:model="searchParams.arrPa"
                        v-model:modelChkAll="searchParams.vPaSrcAllYn"
                        id="pa"
                        :options="[{ vSubCode: 'PA+'}, { vSubCode: 'PA++'}, { vSubCode: 'PA+++'}, { vSubCode: 'PA++++'}]"
                        code-nm-key="vSubCode"
                      >
                      </ap-choosebox>
                    </div>
                  </div>
                </dd>
              </dl>
            </div>

            <div class="search-bar__row">
              <dl class="search-bar__item">
                <dt class="search-bar__key search-bar__width--90">검색</dt>
                <dd class="search-bar__val">
                  <div class="form-flex">
                    <div class="form-flex-cell form-flex__cell--5">
                      <div class="search-form">
                        <div class="search-form__inner">
                          <ap-input
                            v-model:value="searchParams.vKeyword"
                            input-class="ui-input ui-input__width--450"
                            placeholder="심사번호 or 제품명 or 내용물 코드 or 내용물명 or 임상코드 or 용법·용량"
                            @keypress-enter="fnSearch(1)"
                          >
                          </ap-input>
                          <button type="button" class="button-search" @click="fnSearch(1)">검색</button>
                        </div>
                      </div>
                    </div>
                    <div class="form-flex-cell form-flex__cell--5">
                      <div class="ui-checkbox__list">
                        <div class="ui-checkbox__inner">
                          <ap-input-check
                            value="Y"
                            label="검색 초기화"
                            id="evalResetChk"
                            @click="resetSearchFilter"
                          >
                          </ap-input-check>
                        </div>
                      </div>
                    </div>
                  </div>
                </dd>
              </dl>
            </div>
          </div>
        </div>
      </div>

      <div class="ui-table__wrap">
        <table class="ui-table text-center ui-table__td--40">
          <colgroup>
            <col style="width:16rem;">
            <col style="width:auto;">
            <col style="width:13rem;">
            <col style="width:20rem;">
            <col style="width:13rem;">
            <col style="width:13rem;">
          </colgroup>
          <thead>
            <tr>
              <th>심사번호</th>
              <th>제품명</th>
              <th>구분</th>
              <th>기능성분류</th>
              <th>SPF</th>
              <th>PA</th>
            </tr>
          </thead>
          <tbody>
            <template v-if="list && list.length > 0">
              <tr v-for="(vo, index) in list" :key="'eval_' + index" @click="fnEvalSelect(vo)">
                <td>
                  {{ vo.vEvaluateno }}
                </td>
                <td class="t-left">{{ vo.vProductionNm }}</td>
                <td>{{ vo.vBaseYnName }}</td>
                <td class="t-left td-ellipsis">
                  <div class="td-ellipsis__text">
                    {{ vo.vFunctionNm }}
                  </div>
                </td>
                <td>
                  <template v-if="commonUtils.isNotEmpty(vo.vSpfVal) || commonUtils.isNotEmpty(vo.vSpfError)">
                    {{ vo.vSpfVal }} ± {{ vo.vSpfError }}
                  </template>
                </td>
                <td>
                  <template v-if="commonUtils.isNotEmpty(vo.vPaVal) || commonUtils.isNotEmpty(vo.vPaError)">
                    {{ vo.vPaVal }} ± {{ vo.vPaError }}
                  </template>
                </td>
              </tr>
            </template>
            <template v-else>
            <tr>
              <td colspan="6">
                <div class="no-result">
                  {{ t('common.msg.no_data') }}
                </div>
              </td>
            </tr>
          </template>
          </tbody>
        </table>
      </div>
    </div>

    <div class="board-bottom">
      <div class="board-bottom__inner board-bottom__with--button">
        <Pagination
          :page-info="page"
          @click="fnSearch"
        >
        </Pagination>
        <div class="ui-buttons ui-buttons__right">
          <button type="button" class="ui-button ui-button__bg--lightgray" @click="closeAsyncPopup({ message: '닫기'})">닫기</button>
        </div>
      </div>
    </div>
    <teleport to="#common-modal-sub" v-if="popContent">
      <ap-popup>
        <component
          :is="popContent"
          :pop-params="popupParams"
          @selectFunc="popSelectFunc"
          @closeFunc="closeFunc"
        />
      </ap-popup>
    </teleport>
  </div>
  <div id="common-modal-sub"></div>
</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'EvaluateSearchPop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          arrEff: []
        }
      }
    }
  },
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
    EvaluationMaterialSearchPop: defineAsyncComponent(() => import('@/components/labcommon/popup/EvaluationMaterialSearchPop.vue')),
  },
  emits: ['selectFunc'],
  setup (props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { closeAsyncPopup, openAsyncPopup } = useActions(['closeAsyncPopup', 'openAsyncPopup'])
    const popContent = ref(null)
    const popSelectFunc = ref(null)
    const closeFunc = ref(null)
    const effchoose = ref(null)
    const popupParams = ref({})
    const searchParams = ref({
      vSearchPrior: 'A',
      vKeyword: '',
      vMateKeyword: '',
      vChkWrFlag: '',
      vChkLwrFlag: '',
      vChkWrAllFlag: '',
      vDosageSrcAllYn: '',
      arrDosageCode: [],
      vTypeSrcAllYn: '',
      arrType: [],
      vEffSrcAllYn: [],
      vSrcIncEffYn: 'Y',
      arrEff: props.popParams.arrEff || [],
      vSrcSpf: '',
      vPaSrcAllYn: '',
      arrPa: [],
      nowPageNo: 1
    })

    const arrMstCode = [
      'EVL01', 'EV_MATERIAL_TYPE', 'EV_MATERIAL_FUNC2', 'LNC_EV_SPF'
    ]

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const {
      page,
      list,
      selectEvaluationList
    } = useLabCommon()
    
    const resetSearchFilter = () => {
      searchParams.value = {
        vSearchPrior: 'A',
        vKeyword: '',
        vMateKeyword: '',
        vChkWrFlag: '',
        vChkLwrFlag: '',
        vChkWrAllFlag: '',
        vDosageSrcAllYn: '',
        arrDosageCode: [],
        vTypeSrcAllYn: '',
        arrType: [],
        vEffSrcAllYn: [],
        vSrcIncEffYn: 'Y',
        arrEff: props.popParams.arrEff || [],
        vSrcSpf: '',
        vPaSrcAllYn: '',
        arrPa: [],
        nowPageNo: 1
      }

      const popWrap = document.querySelector('#evaluate_pop')
      const resetFilterArea = popWrap.querySelectorAll('.reset_filter_area')

      if (resetFilterArea) {
        for (let i = 0; i < resetFilterArea.length; i++) {
          const checked = resetFilterArea[i].querySelectorAll('input[type=\'checkbox\']:checked')

          if (checked) {
            for (let j = 0; j < checked.length; j++) {
              checked[j].checked = false
            }
          }
        }
      }

      const chooseBoxTxt = codeGroupMaps.value['EV_MATERIAL_FUNC2'].filter(item => item.vSubCode === props.popParams.arrEff[0])[0]
      const effLen = props.popParams.arrEff.length
      effchoose.value.outTxt = chooseBoxTxt.vSubCodenm + (effLen > 1 ? ' 외 ' + (effLen - 1) + '건' : '')

      popWrap.querySelector('#vSrcIncEffYn').checked = true
      popWrap.querySelector('#evalResetChk').checked = false

      fnSearch(1)
    }

    const closeEvalMaterialSearchPop = () => {
      popContent.value = null
    }

    const fnEvaluationMaterialSearchPop = () => {
      popupParams.value = {
        vKeyword: searchParams.value.vMateKeyword
      }

      popSelectFunc.value = getEvaluationMaterialInfo
      closeFunc.value = closeEvalMaterialSearchPop
      popContent.value = 'EvaluationMaterialSearchPop'
    }

    const getEvaluationMaterialInfo = (list) => {
      let vMateKeyword = ''
      list.forEach((item, idx) => {
        vMateKeyword += item.vMaterialCd + (idx !== list.length - 1 ? ',' : '')
      })

      searchParams.value.vMateKeyword = vMateKeyword
      popContent.value = null
    }

    const fnEvalSelect = (item) => {
      context.emit('selectFunc', item)
      closeAsyncPopup({ message: '닫기' })
    }

    const fnSearch = (pg) => {
      if (!pg) {
        pg = 1
      }
      searchParams.value.nowPageNo = pg
      selectEvaluationList(searchParams.value)
    }

    const init = () => {
      findCodeList(arrMstCode)

      fnSearch(1)
    }

    init()

    return {
      t,
      commonUtils,
      page,
      list,
      popContent,
      popSelectFunc,
      closeFunc,
      popupParams,
      searchParams,
      codeGroupMaps,
      effchoose,
      resetSearchFilter,
      fnEvalSelect,
      fnEvaluationMaterialSearchPop,
      fnSearch,
      closeAsyncPopup,
    }
  }
}
</script>

<style scoped>
  tbody tr { cursor: pointer; }
</style>