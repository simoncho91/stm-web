<template>
  <div class="modal-content modal-content__width--auto" style="width:431px">
    <div class="modal-header">
      <div class="modal-title">메모 등록</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({ message: '' })"></button>
    </div>
    <div class="modal-body">
      <div class="ui-table__wrap">
        <table class="ui-table__reset ui-table__ver">
          <colgroup>
            <col style="width:auto">
          </colgroup>
          <tbody>
            <tr>
              <td>
                <ap-text-area v-model:value="contentParams.vContent"></ap-text-area>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="board-bottom">
        <div class="board-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--skyblue" @click="onSave">저장</button>
            <button type="button" class="ui-button ui-button__bg--lightgray"
              @click="closeAsyncPopup({ message: '닫기' })">닫기</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { reactive } from 'vue'
import { useMaterialCommon } from '@/compositions/labcommon/useMaterialCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'MateLotSideMemoPop',
  emits: ['selectFunc'],
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLotCd: '',
          vTitle: '',
          vContent: '',
          vFlagStability: '',
        }
      }
    }
  },
  setup(props, context) {
    const { openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncAlert', 'closeAsyncPopup'])
    const contentParams = reactive({
      vLotCd: props.popParams.vLotCd,
      vTitle: props.popParams.vTitle,
      vContent: props.popParams.vContent,
      vFlagStability: props.popParams.vFlagStability,
    })

    const { insertElabLotMemo } = useMaterialCommon()

    const onSave = async () => {
      const message = await insertElabLotMemo({
        vLotCd: contentParams.vLotCd,
        nSeqno: contentParams.nSeqno,
        vTitle: contentParams.vTitle,
        vContent: contentParams.vContent,
        vFlagStability: contentParams.vFlagStability,
        vFlagDel: 'N',
        vFlagOnlyMemo: 'Y',
      })

      context.emit('selectFunc', contentParams.vContent)
      closeAsyncPopup({ message: '닫기' })
    }

    return {
      closeAsyncPopup,
      contentParams,
      onSave
    }
  }
}
</script>