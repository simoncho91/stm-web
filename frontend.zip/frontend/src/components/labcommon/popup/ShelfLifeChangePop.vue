<template>
  <div class="modal-content" style="width: 110rem;">
    <div class="modal-header">
      <div class="modal-title">Shelf life 변경 요청</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({ message: '' })"></button>
    </div>
    <div class="modal-body">
      <div class="myboard-table">
        <div class="myboard-table__inner material-search-inner">
          <table class="ui-table ui-table__th--border-radius--0 ui-table__td--40 text-center">
            <colgroup>
              <col style="width: 5rem;"/>
              <col style="width: 8rem;"/>
              <col style="width: auto;"/>
              <col style="width: 20rem;"/>
              <col style="width: 10rem;"/>
              <col style="width: 10rem;"/>
            </colgroup>
            <thead>
              <th class="chk-header">
                <ap-input-check
                  v-model:model="checkAll"
                  id="shelf_cont_checkAll"
                  value="Y"
                  @click="fnCheckAllEvent"
                >
                </ap-input-check>
              </th>
              <th>내용물코드</th>
              <th>내용물명</th>
              <th>플랜트</th>
              <th>SHELF LIFE</th>
              <th>상태</th>
            </thead>
            <tbody>
              <template v-if="list && list.length > 0">
                <tr v-for="vo in list" :key="'cont_list_' + vo.vContCd">
                  <td>
                    <ap-input-check
                      v-model:model="vo.isChecked"
                      value="Y"
                      :id="'shelf_cont_' + vo.vContCd"
                      :disabled="vo.vStatusCd === 'SLS030'"
                      @click="fnCheckEvent"
                    >
                    </ap-input-check>
                  </td>
                  <td>{{ vo.vContCd }}</td>
                  <td>{{ vo.vMaktx }}</td>
                  <td>{{ vo.vPlantNm }}</td>
                  <td>{{ vo.vShelfLife }}</td>
                  <td>{{ vo.vStatusCdNm }}</td>
                </tr>
              </template>
              <template v-else>
                <tr>
                  <td colspan="6">
                    <div class="no-result">{{ t('common.msg.no_data') }}</div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>

      <div class="ui-buttons ui-buttons__right mt-2">
        <button type="button" class="ui-button ui-button__bg--skyblue font-weight__300" @click="fnShelfLifeModify()">변경요청</button>
        <button type="button" class="ui-button ui-button__bg--lightgray" @click="closeAsyncPopup({ message: ''})">닫기</button>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, inject } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useStore } from 'vuex'
import { useActions } from 'vuex-composition-helpers'
import { useRouter } from 'vue-router'

export default {
  name: 'ShelfLifeChangePop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          contCdList: [],
          vPlantCd: '',
          vNoteType: '',
          vLabNoteCd: '',
        }
      }
    }
  },
  setup(props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncAlert', 'closeAsyncPopup'])
    const store = useStore()
    const router = useRouter()
    const noteTypeNm = store.getters.getNoteTypeNm()
    const list = ref(null)
    const checkAll = ref('')

    const {
      selectOneShelfLifeContInfo,
    } = useLabCommon()

    const fnCheckAllEvent = (value) => {
      if (value === 'Y') {
        list.value.forEach(item => {
          if (item.vStatusCd !== 'SLS030') {
            item.isChecked = 'Y'
            document.querySelector('#shelf_cont_' + item.vContCd).checked = true
          }
        })
      } else {
        list.value.forEach(item => {
          item.isChecked = ''
          document.querySelector('#shelf_cont_' + item.vContCd).checked = false
        })
      }
    }

    const fnCheckEvent = () => {
      const availableList = list.value.filter(v => v.vStatusCd !== 'SLS030')
      if (availableList && availableList.length > 0) {
        if (list.value.filter(item => item.isChecked === 'Y').length === availableList.length) {
          checkAll.value = 'Y'
          document.querySelector('#shelf_cont_checkAll').checked = true
        } else {
          checkAll.value = ''
          document.querySelector('#shelf_cont_checkAll').checked = false
        }
      }
    }

    const fnValidate = () => {
      let isOk = true

      const checkedList = list.value.filter(v => v.isChecked === 'Y')
      if (!checkedList || checkedList.length === 0) {
        openAsyncAlert({ message: '하나 이상의 내용물코드를 선택해 주세요.' })
        isOk = false
        return
      }

      const checkFirstInfo = checkedList[0]

      list.value.some(item => {
        if (item.vStatusCd !== checkFirstInfo.vStatusCd) {
          openAsyncAlert({ message: '같은 상태의 내용물코드만 선택 할 수 있습니다.' })
          isOk = false
          return true
        }

        if (item.vPlantCd !== checkFirstInfo.vPlantCd) {
          openAsyncAlert({ message: '같은 플랜트만 선택할 수 있습니다.' })
          isOk = false
          return true
        }
      })

      return isOk
    }


    const fnShelfLifeModify = () => {
      if (list.value && list.value.length > 0) {
        if (!fnValidate()) {
          return
        }

        const query = {
          contCdList: list.value.filter(v => v.isChecked === 'Y').map(v => v.vContCd),
          vLabNoteCd: props.popParams.vLabNoteCd,
          vNoteType: props.popParams.vNoteType,
        }

        closeAsyncPopup({ message: '' })
        router.push({ path: `/${noteTypeNm}/all-lab-note-shelf-register`, query })
      } else {
        openAsyncAlert({ message: '변경 가능한 내용물이 없습니다.'})
        return
      }
    }

    const init = async () => {
      const result = await selectOneShelfLifeContInfo(props.popParams)

      if (result) {
        list.value = result
      }
    }

    init()

    return {
      t,
      commonUtils,
      closeAsyncPopup,
      list,
      checkAll,
      fnCheckAllEvent,
      fnCheckEvent,
      fnShelfLifeModify,
    }
  }
}
</script>