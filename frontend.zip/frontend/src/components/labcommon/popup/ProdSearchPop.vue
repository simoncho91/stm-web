<template>
  <div class="modal-content modal-content__width--950">
    <div class="modal-header">
      <div class="modal-title">제품코드 검색</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({message: ''})"></button>
    </div>

    <div class="modal-body">
      <div class="board-top">
        <section class="search-bar p-0">
          <h2 class="for-a11y">검색</h2>
          <div class="search-bar__left">
            <div class="search-bar__row">
              <dl class="search-bar__item search-bar__item--width-100">
                <dt class="search-bar__key">검색</dt>
                <dd class="search-bar__val search-bar__val--flex">
                  <div class="search-form">
                    <div class="search-form__inner">
                      <ap-input
                        v-model:value="searchParams.vKeyword"
                        placeholder="원료코드 or 원료명"
                        @keypress-enter="fnSearch(1)"
                      >
                      </ap-input>
                      <button type="button" class="button-search" @click="fnSearch(1)">검색</button>
                    </div>
                  </div>
                </dd>
              </dl>
            </div>
          </div>
        </section>
      </div>

      <div class="ui-table__wrap">
        <table class="ui-table text-center ui-table__td--40">
          <colgroup>
            <col style="width:5rem;">
            <col style="width:15rem;">
            <col style="width:auto;">
            <col style="width:auto;">
          </colgroup>
          <thead>
            <tr>
              <th>No.</th>
              <th>제품코드</th>
              <th>제품명</th>
              <th>제품명(영문)</th>
            </tr>
          </thead>
          <tbody>
            <template v-if="list && list.length > 0">
              <tr v-for="vo in list" :key="'prod_' + vo.vPrdCd" @click="fnProdSelect(vo)">
                <td>{{ vo.nNum }}</td>
                <td>{{ vo.vPrdCd }}</td>
                <td>{{ vo.vPrdNm }}</td>
                <td>{{ vo.vPrdNmEn }}</td>
              </tr>
            </template>
            <template v-else>
              <tr>
                <td colspan="4">
                  <div class="no-result">
                    {{ t('common.msg.no_data') }}
                  </div>
                </td>
              </tr>
            </template>
          </tbody>
        </table>
      </div>

      <div class="board-bottom board-bottom__with--button">
        <div class="board-bottom__inner">
          <Pagination
            :page-info="page"
            @click="fnSearch"
          >
          </Pagination>
          <div class="ui-buttons ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--lightgray" @click="closeAsyncPopup({ message: '닫기'})">닫기</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, inject, ref } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'ProdSearchPop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vKeyword: ''
        }
      }
    }
  },
  components: {
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
  },
  emits: ['selectFunc'],
  setup (props, context) {
    const t = inject('t')
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])
    const searchParams = ref({
      vKeyword: props.popParams.vKeyword,
      nowPageNo: 1
    })

    const {
      page,
      list,
      selectSearchProdList
    } = useLabCommon()

    const fnSearch = (pg) => {
      if (!pg) {
        pg = 1
      }

      searchParams.value.nowPageNo = pg

      selectSearchProdList(searchParams.value)
    }

    const init = () => {
      fnSearch(1)
    }

    init()

    const fnProdSelect = (vo) => {
      context.emit('selectFunc', vo)
      closeAsyncPopup({ message: '닫기' })
    }

    return {
      t,
      page,
      list,
      searchParams,
      closeAsyncPopup,
      fnProdSelect,
      fnSearch
    }
  }
}

</script>

<style scoped>
  .ui-table tbody tr {
    cursor: pointer;
  }
</style>