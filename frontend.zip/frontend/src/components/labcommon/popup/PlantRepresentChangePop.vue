<template>
  <div class="modal-content modal-content__width--640">
    <div class="modal-header">
      <div class="modal-title">대표 플랜트 변경</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({message: ''})"></button>
    </div>
    <div class="model-body">
      <div class="basic-info__table">
        <table class="ui-table__contents plant-table">
          <colgroup>
            <col style="width:16%">
            <col style="width:41.5%">
            <col style="width:1%">
            <col style="width:41.5%">
          </colgroup>
          <tbody>
            <tr>
              <th>플랜트</th>
              <td id="error_wrap_vPlantCd">
                <ap-selectbox
                  v-if="plantList.length > 0"
                  v-model:value="regParams.vPlantCd"
                  input-class="ui-select__width--full"
                  :options="plantList"
                  codeKey="vPlantCd"
                  codeNmKey="vPlantNm"
                  @change="fnValidate('vPlantCd');changePlantCd();"
                >
                </ap-selectbox>
                <span class="error-msg" id="error_msg_vPlantCd"></span>
              </td>
              <td></td>
              <td id="error_wrap_vSiteType">
                <ap-selectbox
                  v-if="codeGroupMaps['MA_PLANT']"
                  v-model:value="regParams.vSiteType"
                  input-class="ui-select__width--full"
                  :options="codeGroupMaps['MA_PLANT'].filter(item => item.vBuffer1 === regParams.vPlantCd)"
                  @change="fnValidate('vSiteType')"
                >
                </ap-selectbox>
                <span class="error-msg" id="error_msg_vSiteType"></span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <p>※대표 플랜트 변경은 확장된 플랜트로만 가능합니다.</p>
      <p>플랜트 선택 항목 추가가 필요하시면 플랜트 확장 후 대표플랜트 변경 진행해 주세요.</p>
    </div>

    <div class="board-bottom">
        <div class="board-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button
              type="button"
              class="ui-button ui-button__bg--skyblue font-weight__300"
              @click="fnSave()"
            >저장</button>
            <button type="button" class="ui-button ui-button__bg--lightgray" @click="closeAsyncPopup({message: ''})">닫기</button>
          </div>
        </div>
      </div>
  </div>
</template>

<script>
import { reactive, ref, inject } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useRequestCommon } from '@/compositions/labcommon/useRequestCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'PlantRepresentChangePop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  emits: ['callbackFunc'],
  setup (props, context) {
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert, openAsyncConfirm, closeAsyncPopup } = useActions(['openAsyncAlert', 'openAsyncConfirm', 'closeAsyncPopup'])
    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const {
      selectLabNoteSavePlantList,
      updatePlantAndSiteType,
    } = useRequestCommon()

    const plantList = ref([])

    const regParams = reactive({
      vLabNoteCd: props.popParams.vLabNoteCd || '',
      vPlantCd: props.popParams.vPlantCd || '',
      vSiteType: props.popParams.vSiteType || '',
      vOldPlantCd: props.popParams.vPlantCd || '',
      vNoteType: props.popParams.vNoteType || '',
      vContCd: props.popParams.vContCd || '',
    })

    const changePlantCd = () => {
      regParams.vSiteType = ''
    }

    const fnValidateAll = (arrChkKey) => {
      let isOk = true
      commonUtils.hideErrorMessageAll(arrChkKey)

      arrChkKey.forEach(key => {
        if (!fnValidate(key)) {
          isOk = false
        }
      })

      return isOk
    }

    const fnValidate = (key) => {
      let isOk = true
      let errorMsg = '필수 입력 사항입니다.'

      commonUtils.hideErrorMessage(key)

      if (commonUtils.isEmpty(regParams[key])) {
        isOk = false
      }

      if (!isOk) {
        commonUtils.showErrorMessage(key, errorMsg)
      }

      return isOk
    }

    const fnSave = async () => {
      const arrChkKey = ['vPlantCd', 'vSiteType']
      if (!fnValidateAll(arrChkKey)) {
        openAsyncAlert({ message : '필수 입력사항을 확인해 주세요.' })
        return
      }

      if (!await openAsyncConfirm({ message: '대표 플랜트를 수정하시겠습니까?' })) {
        return
      }

      const result = updatePlantAndSiteType(regParams)

      if (result) {
        await openAsyncAlert({ message : '수정 되었습니다.' })
        context.emit('callbackFunc')
      }
    }

    const init = async () => {
      findCodeList(['MA_PLANT'])
      const vLabNoteCd = props.popParams.vLabNoteCd
      const result = await selectLabNoteSavePlantList(vLabNoteCd)

      if (result) {
        plantList.value = [ ...result ]
      }
    }

    init()

    return {
      codeGroupMaps,
      regParams,
      plantList,
      changePlantCd,
      fnSave,
      fnValidate,
      closeAsyncPopup
    }
  }
}
</script>

<style scoped>
  .plant-table th { vertical-align: middle; }
  .plant-table td { vertical-align: top; }
  p { font-size: 1.2rem; color: #336fe6; font-weight: 600; }
</style>