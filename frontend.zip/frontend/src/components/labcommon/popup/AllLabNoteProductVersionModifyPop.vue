<template>
  <div class="modal-content" style="width: 120rem;">
    <div class="modal-header">
      <div class="modal-title">버전 정보 수정</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({message: ''})"></button>
    </div>
    <div class="modal-body">
      <div class="basic-info__table">
        <table class="ui-table__contents">
          <colgroup>
            <col style="width:17rem">
            <col style="width:auto">
            <col style="width:17rem">
            <col style="width:auto">
          </colgroup>
          <tbody>
            <!-- <tr>
              <th>카운터</th>
              <td class="t-left" colspan="3">
                {{ verParams.vCounterTypeNm ? verParams.vCounterTypeNm : '없음' }}
              </td>
            </tr>
            <tr v-if="verParams.vCounterTypeCd !== ''">
              <td colspan="4" class="inside-td t-left">
                <table class="ui-table__contents">
                  <colgroup>
                    <col style="width:14rem">
                  </colgroup>
                  <tbody>
                    <tr v-if="verParams.vCounterTypeCd === 'LNC04_01'">
                      <th>자사카운터</th>
                      <td>
                        <template v-if="commonUtils.isNotEmpty(verParams.vCounterInvenCd)">
                          [{{ verParams.vCounterSpCd }}]
                        </template>
                        {{ commonUtils.isNotEmpty(verParams.vCounterInvenCd) ? 
                            verParams.vCounterInvenNm : verParams.vCounterContNm }}
                      </td>
                    </tr>
                    <template v-else-if="verParams.vCounterTypeCd === 'LNC04_02'">
                      <tr>
                        <th>브랜드</th>
                        <td>
                          {{ verParams.vCounterBrdNm }}
                        </td>
                      </tr>
                      <tr>
                        <th>제품명</th>
                        <td>
                          {{ verParams.vCounterPrdNm }}
                        </td>
                      </tr>
                    </template>
                    <template v-else-if="verParams.vCounterTypeCd === 'LNC04_03'">
                      <tr>
                        <th>SP 정보</th>
                        <td>
                          {{ verParams.vCounterSpInfo }}
                        </td>
                      </tr>
                      <tr>
                        <th>선행파일럿</th>
                        <td>
                          {{ commonUtils.changeStrDatePattern(verParams.vPrePilotDt, '.') }}
                        </td>
                      </tr>
                    </template>
                    <template v-else-if="verParams.vCounterTypeCd === 'LNC04_04'">
                      <tr>
                        <th>골격처방</th>
                        <td>
                          {{ verParams.vSsrPrdnm }}
                        </td>
                      </tr>
                    </template>
                    <tr>
                      <th>비고</th>
                      <td v-html="commonUtils.removeHTMLChangeBr(verParams.vCounterNote)"></td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr> -->
            <tr>
              <th>신원료 유무<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td colspan="3">
                <div class="ui-radio__list" id="error_wrap_vFlagNewItem">
                  <div class="ui-radio__inner">
                    <ap-input-radio
                      v-for="(vo, index) in [{vSubCode: 'Y', vSubCodenm: '유'}, {vSubCode: 'N', vSubCodenm: '무'}]" :key="'newItem_' + index"
                      v-model:model="verParams.vFlagNewItem"
                      :value="vo.vSubCode"
                      :label="vo.vSubCodenm"
                      :id="'newItem_' + index"
                      name="newItem"
                      @click="resetMateList(verParams.vFlagNewItem, verParams, 'newMateList');fnValidate('vFlagNewItem')"
                    ></ap-input-radio>
                  </div>
                  <span class="error-msg" id="error_msg_vFlagNewItem"></span>
                </div>
              </td>
            </tr>
            <!-- 신원료 'Y'일 경우 -->
            <tr v-if="verParams.vFlagNewItem === 'Y'">
              <td colspan="4" class="inside-td">
                <table class="ui-table__contents">
                  <colgroup>
                    <col style="width:14rem">
                  </colgroup>
                  <tbody>
                    <tr>
                      <th>신원료 추가</th>
                      <td>
                        <div class="search-form">
                          <div class="search-form__inner">
                            <ap-input
                              v-model:value="searchParams.mateNewKeyword"
                              input-class="ui-input__width--340"
                              placeholder="검색어를 입력하세요."
                              @keypress-enter="fnOpenMateSearchPop(searchParams.mateNewKeyword, 'Y', getSearchNewMateResult, 'tempSearch')"
                            >
                            </ap-input>
                            <button type="button" class="button-search" @click="fnOpenMateSearchPop(searchParams.mateNewKeyword, 'Y', getSearchNewMateResult, 'tempSearch')">검색</button>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr v-if="verParams.newMateList.length > 0">
                      <td colspan="2">
                        <MateSearchResultTableRegister
                          v-model:mate-list="verParams.newMateList"
                          type="new"
                          modify-pop-flag="Y"
                          stock-dt-yn="Y"
                          mate-chg-yn="Y"
                        >
                        </MateSearchResultTableRegister>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>

            <!-- 향료정보 -->
            <tr>
              <th>향료정보</th>
              <td colspan="3">
                <div class="ui-radio__list">
                  <div class="ui-radio__inner">
                    <ap-input-radio
                      v-for="(vo, index) in fragDivList" :key="'fragType_' + index"
                      v-model:model="verParams.vPerfumeCd"
                      :value="vo.vSubCode"
                      :label="vo.vSubCodenm"
                      :id="'fragType_' + index"
                      name="fragType"
                      @click="resetMateList(verParams.vPerfumeCd, verParams, 'perfMateList');"
                    ></ap-input-radio>
                  </div>
                </div>
              </td>
            </tr>
            <tr v-if="verParams.vPerfumeCd !== '' && verParams.vPerfumeCd !== 'LNC11_99'">
              <td colspan="4" class="inside-td">
                <table class="ui-table__contents">
                  <colgroup>
                    <col style="width:14rem">
                  </colgroup>
                  <tbody>
                    <tr>
                      <th>향료 추가</th>
                      <td>
                        <div class="form-flex">
                          <!-- 향료 변경일 경우만 해당 영역 노출 -->
                          <div class="ui-select-box form-flex__cell--5 mr-20" v-if="verParams.vPerfumeCd === 'LNC11_03'">
                            <div class="ui-radio__list">
                              <div class="ui-radio__inner">
                                <ap-input-radio
                                  v-for="(vo, index) in [{vSubCode: 'Y', vSubCodenm: '신향'}, {vSubCode: 'N', vSubCodenm: ' 기존향'}]" :key="'fragranceNew_' + index"
                                  v-model:model="verParams.vFlagPerfumeNew"
                                  :value="vo.vSubCode"
                                  :label="vo.vSubCodenm"
                                  :id="'fragranceNew_' + index"
                                  name="fragranceNew"
                                ></ap-input-radio>
                              </div>
                            </div>
                          </div>
                          <div class="ui-select-box form-flex__cell--5">
                            <div class="search-form">
                              <div class="search-form__inner">
                                <ap-input
                                  v-model:value="searchParams.perfumeKeyword"
                                  input-class="ui-input__width--340"
                                  placeholder="검색어를 입력하세요."
                                  @keypress-enter="fnOpenMateSearchPop(searchParams.perfumeKeyword, 'Y', getSearchPerfMateResult)"
                                >
                                </ap-input>
                                <button type="button" class="button-search" @click="fnOpenMateSearchPop(searchParams.perfumeKeyword, 'Y', getSearchPerfMateResult)">검색</button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr v-if="verParams.perfMateList.length > 0">
                      <td colspan="2">
                        <MateSearchResultTableRegister
                          v-model:mate-list="verParams.perfMateList"
                          type="perf"
                          modify-pop-flag="Y"
                          stock-dt-yn="Y"
                        >
                        </MateSearchResultTableRegister>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
            <!-- 기능성 -->
            <!-- <tr>
              <th>기능성</th>
              <td colspan="3" class="t-left">
                <template v-if="funcList.length > 0">
                  <template v-for="(vo, idx) in funcList" :key="'func_' + idx">
                    {{ idx !== 0 ? ', ' : '' }}{{ vo.vSubCodenm }}
                  </template>
                </template>
              </td>
            </tr>
            <template v-if="funcList.length > 0">
              <tr>
                <th>관련근거</th>
                <td class="t-left" colspan="3">
                  {{ verParams.vRefTypeNm }}
                </td>
              </tr>
              <tr v-if="verParams.vRefTypeCd === 'LNC05_02'">
                <th>심사번호</th>
                <td class="t-left" colspan="3">
                  {{ verParams.vEvaluateno }} {{ commonUtils.isNotEmpty(verParams.vEvaluateGosiCd) ? '/ ' + verParams.vEvaluateGosiNo : '' }}
                </td>
              </tr>
              <tr v-if="verParams.vRefTypeCd === 'LNC05_03' || verParams.vRefTypeCd === 'LNC05_04'">
                <th>심사항목</th>
                <td class="t-left">{{ verParams.vRefNote }}</td>
              </tr>
              <tr>
                <th>기능성 원료</th>
                <td colspan="3">
                </td>
              </tr>
              <tr>
                <td colspan="4" class="inside-td">
                  <MateSearchResultTableView
                    :mate-list="verParams.funcMateList"
                    input-class="ui-table__reset ui-table__search-result text-center"
                  ></MateSearchResultTableView>
                </td>
              </tr>
            </template> -->

            <!-- 필수 원료 -->
            <tr>
              <th>필수원료</th>
              <td colspan="3">
                <div class="form-flex form-flex__col">
                  <div class="form-flex__cell form-flex__cell--5">
                    <div class="search-form">
                      <div class="search-form__inner">
                        <ap-input
                          v-model:value="searchParams.requKeyword"
                          input-class="ui-input__width--340"
                          placeholder="원료를 검색해주세요."
                          @keypress-enter="fnOpenMateSearchPop(searchParams.requKeyword, 'Y', getSearchRequMateResult)"
                        >
                        </ap-input>
                        <button type="button" class="button-search" @click="fnOpenMateSearchPop(searchParams.requKeyword, 'Y', getSearchRequMateResult)">원료추가</button>
                      </div>
                    </div>
                  </div>
                </div>
              </td>
            </tr>
            <tr v-if="verParams.requMateList.length > 0">
              <td colspan="4">
                <MateSearchResultTableRegister
                  v-model:mate-list="verParams.requMateList"
                  type="requ"
                  modify-pop-flag="Y"
                >
                </MateSearchResultTableRegister>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <div class="page-bottom">
      <div class="page-bottom__inner">
        <div class="ui-buttons ui-buttons__right">
          <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnVersionModify()">수정</button>
          <button type="button" class="ui-button ui-button__bg--lightgray" @click="closeAsyncPopup({message: ''})">닫기</button>
        </div>
      </div>
    </div>
    <teleport to="#common-modal-sub" v-if="popContent">
      <ap-popup>
        <component
          :is="popContent"
          :pop-params="popupParams"
          @selectFunc="popSelectFunc"
          @closeFunc="closeFunc"
        />
      </ap-popup>
    </teleport>
  </div>
  <div id="common-modal-sub"></div>
</template>

<script>
import { defineAsyncComponent, ref, reactive, inject } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useRequestCommon } from '@/compositions/labcommon/useRequestCommon'
import { useStore } from 'vuex'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'AllLabNoteProductVersionModifyPop',
  components: {
    MateSearchResultTableView: defineAsyncComponent(() => import('@/components/labcommon/MateSearchResultTableView.vue')),
    MateSearchResultTableRegister: defineAsyncComponent(() => import('@/components/labcommon/MateSearchResultTableRegister.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    MateSearchPop: defineAsyncComponent(() => import('@/components/labcommon/popup/MateSearchPop.vue')),
  },
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  emits: ['callbackFunc'],
  setup (props, context) {
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncAlert', 'closeAsyncPopup'])
    const popContent = ref(null)
    const popupParams = ref(null)
    const popSelectFunc = ref(null)
    const closeFunc = ref(null)
    const fragDivList = ref(null)
    const store = useStore()
    const noteType = store.getters.getNoteType()
    
    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const {
      resetMateList,
    } = useLabCommon()

    const {
      selectLabNoteMstVerInfo,
      updateLabNoteVersionInfo,
    } = useRequestCommon()

    const searchParams = reactive({
      mateNewKeyword: '',
      perfumeKeyword: '',
      requKeyword: ''
    })

    const verParams = ref({
      vLabNoteCd: '',
      vContPkCd: props.popParams.vContPkCd,
      nVersion: '',
      vCounterTypeCd: '',
      vCounterCd: '',
      vCounterContPkCd: '',
      vCounterInvenCd: '',
      vCounterInvenJoinCd: '',
      vCounterSpCd: '',
      vCounterInvenNm: '',
      vCounterContNm: '',
      vCounterBrdNm: '',
      vCounterPrdNm: '',
      vCounterSpInfo: '',
      vCounterNmTemp: '',
      vPrePilotDt: '',
      vSsrPrdnm: '',
      vSsrid: '',
      vCounterNote: '',
      vFlagNewItem: '',
      newMateList: [],
      vPerfumeCd: '',
      vFlagPerfumeNew: '',
      perfMateList: [],
      vFlagFuncTest: '',
      funcList: [],
      vRefTypeCd: '',
      vEvaluateno: '',
      vEvaluateCd: '',
      vEvaluateGosiNo: '',
      vEvaluateGosiCd: '',
      vFlagGosi: '',
      vRefNote: '',
      funcMateList: [],
      requMateList: [],
    })

    const funcList = ref([])

    const mateDefaultObj = {
      vFlagTo100: '',
      nMateRate: '',
      vMatePutDt: '',
      vMateNote: '',
      vFlagMateNew: 'Y'
    }

    const getSearchPerfMateResult = (list) => {
      const perfMateDefault = {
        vMateEvalCd: '',
        vMateFuncCd: '',
        vFlagRequired: 'N',
      }
      list.forEach(item => {
        const perfMateList = verParams.value.perfMateList.filter(vo => vo.vKey === item.vKey)
        if (perfMateList.length === 0) {
          verParams.value.perfMateList.push({ ...item, ...mateDefaultObj, ...perfMateDefault })
        }
      })
    }

    const getSearchNewMateResult = (list) => {
      const newMateDefault = {
        vMateEvalCd: '',
        vMateFuncCd: '',
        vFlagRequired: 'N',
      }
      list.forEach(item => {
        const newMateList = verParams.value.newMateList.filter(vo => vo.vKey === item.vKey)
        if (newMateList.length === 0) {
          verParams.value.newMateList.push({ ...item, ...mateDefaultObj, ...newMateDefault })
        }
      })
    }

    const getSearchRequMateResult = (list) => {
      const requMateDefault = {
        vMateEvalCd: '',
        vMateFuncCd: '',
        vFlagRequired: 'N',
      }
      list.forEach(item => {
        const requMateList = verParams.value.requMateList.filter(vo => vo.vKey === item.vKey)
        if (requMateList.length === 0) {
          verParams.value.requMateList.push({ ...item, ...mateDefaultObj, ...requMateDefault })
        }
      })
    }

    const fnOpenMateSearchPop = (keyword, flagSearchInit, selectFunc, defaultTab) => {
      const noteInfo = store.getters.getNoteInfo()
      const plantCd = noteInfo.vPlantCd
      const siteType = noteInfo.vSiteType
      const labNoteCd = noteInfo.vLabNoteCd

      popupParams.value = {
        vKeyword: keyword,
        vPlantCd: plantCd,
        vSiteType: siteType,
        vFlagSearchInit: flagSearchInit,
        vLabNoteCd: labNoteCd,
        vDefaultTab: defaultTab || 'sapSearch',
        vNoteType: noteType,
        popType: 'SUB',
      }

      popSelectFunc.value = selectFunc
      popContent.value = 'MateSearchPop'
      closeFunc.value = fnClose
    }

    const fnValidate = (key) => {
      let isOk = true
      let errorMsg = '필수 입력 사항입니다.'
      commonUtils.hideErrorMessage(key)

      if (commonUtils.isEmpty(verParams.value[key])) {
        isOk = false
      }

      if (!isOk) {
        commonUtils.showErrorMessage(key, errorMsg)
      }

      return isOk
    }

    const fnClose = () => {
      popContent.value = null
    }

    const fnVersionModify = async () => {
      if (!fnValidate('vFlagNewItem')) {
        openAsyncAlert({ message: '필수 입력 사항을 확인해 주세요.'})
        return
      }

      const payload = {
        vLabNoteCd: verParams.value.vLabNoteCd,
        nVersion: verParams.value.nVersion,
        vFlagNewItem: verParams.value.vFlagNewItem,
        vFlagPerfumeNew: verParams.value.vFlagPerfumeNew,
        vPerfumeCd: verParams.value.vPerfumeCd,
        newMateList: verParams.value.newMateList,
        perfMateList: verParams.value.perfMateList,
        requMateList: verParams.value.requMateList,
        vContPkCd: props.popParams.vContPkCd,
        vContCd: props.popParams.vContCd,
        vContNm: props.popParams.vContNm
      }

      const result = await updateLabNoteVersionInfo(payload)

      if (result) {
        await openAsyncAlert({ message: '수정되었습니다.' })
        context.emit('callbackFunc')
      }
    }

    const init = async () => {
      await findCodeList(['LNC11'])
      fragDivList.value = commonUtils.getCodeList(codeGroupMaps, 'LNC11', 'BKR')
      const payload = {
        vLabNoteCd: props.popParams.vLabNoteCd,
        nVersion: props.popParams.nVersion,
        vContPkCd: props.popParams.vContPkCd,
      }

      const result = await selectLabNoteMstVerInfo(payload)

      if (result) {
        verParams.value = { ...verParams.value, ...result }
      }
    }

    init()

    return {
      commonUtils,
      closeAsyncPopup,
      codeGroupMaps,
      fragDivList,
      searchParams,
      verParams,
      funcList,
      popContent,
      popupParams,
      popSelectFunc,
      closeFunc,
      fnValidate,
      fnVersionModify,
      fnOpenMateSearchPop,
      getSearchPerfMateResult,
      getSearchNewMateResult,
      getSearchRequMateResult,
      resetMateList,
    }
  }
}
</script>