<template>
  <div class="modal-content modal-content__width--701">
    <div class="modal-header">
      <div class="modal-title">{{ headerDescObj[popParams.vSearchType] }}</div>
      <button
        type="button"
        class="modal-close"
        @click="closeAsyncPopup"
      ></button>
    </div>
    <div class="modal-body">
      <div class="search-depart-table">
        <div class="search-depart-table__inner">
          <table class="ui-table ui-table__td--40">
            <colgroup>
              <col style="width:100%">
            </colgroup>
            <thead>
              <tr>
                <th style="text-align: center;">{{ headerDescObj[popParams.vSearchType] }}</th>
              </tr>
            </thead>
            <tbody>
              <template v-if="gvo">
                <template v-if="popParams.vSearchType === 'DISPLAY'">
                  <tr>
                    <td v-html="gvo.vZdisplayLt"></td>
                  </tr>
                </template>
                <template v-else-if="popParams.vSearchType === 'WARNING'">
                  <tr>
                    <td v-html="gvo[`vZwarningLt${popParams.vLang || ''}`]"></td>
                  </tr>
                </template>
                <template v-else>
                  <tr>
                    <td>{{ t('common.msg.no_data') }}</td>
                  </tr>
                </template>
              </template>
              <template v-else>
                <tr>
                  <td>
                    <div class="no-result">
                      {{ t('common.msg.no_data') }}
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>

      <div class="board-bottom ">
        <div class="board-bottom__inner">
          <div class="ui-buttons ml-auto ui-buttons__right">
            <button
              type="button"
              class="ui-button ui-button__bg--skyblue font-weight__300"
              @click="fnReflect('Y')"
            >승인 화면에 반영</button>
            <button
              type="button"
              class="ui-button ui-button__bg--skyblue font-weight__300"
              @click="fnReflect('N')"
            >승인 화면에 미반영</button>
            <button
              type="button"
              class="ui-button ui-button__bg--lightgray"
              @click="closeAsyncPopup"
            >닫기</button>
          </div>
        </div>

      </div>
    </div>
  </div>
</template>

<script>
import { reactive, ref, inject } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'IngrdApprDescPop',
  emits: ['selectFunc'],
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: '',
          vSearchType: '',
          vConcd: '',
          vConnm: '',
          vLand1: '',
          vGcode: '',
          vLang: '',
        }
      }
    }
  },
  setup(props, context) {
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])
    const t = inject('t')
    const commonUtils = inject('commonUtils')

    const headerDescObj = {
      'DISPLAY': '표시성분',
      'WARNING': '주의사항',
    }

    const gvo = ref({})
    const searchParams = reactive({
      vLabNoteCd: props.popParams.vLabNoteCd,
      vSearchType: props.popParams.vSearchType,
      vConcd: props.popParams.vConcd,
      vConnm: props.popParams.vConnm,
      vLand1: props.popParams.vLand1,
      vGcode: props.popParams.vGcode,
    })

    const {
      selectZplmt12List,
    } = useLabCommon()

    const fnReflect = (flag) => {
      if (!flag) {
        return

      }
      const searchType = props.popParams.vSearchType

      let returnObj = {
        reflectYn: flag,
        vSearchType: props.popParams.vSearchType,
        concd: props.popParams.vConcd,
      }

      if (searchType === 'DISPLAY') {
        returnObj = {
          ...returnObj,
          ...{
            vDispArea: 'vReflectDispYn',
            connm: props.popParams.vConnm,
          }
        }
      }
      if (searchType === 'WARNING') {
        let text = gvo.value[`vZwarningLt${props.popParams.vLang || ''}`]

        let startIdx = 0
        let endIdx = 0
        let substrTxt = ''

        // text = text.replace(/<br \/>/gi, '')

        while (startIdx >= 0) {
          startIdx = text.indexOf('[[')
          endIdx = text.indexOf(']]')
          substrTxt = text.substring(startIdx, endIdx + 2)

          text = text.replace(substrTxt, '')
        }

        text = text.replace(/<br \/>|br \/>/gi, '')

        returnObj = {
          ...returnObj,
          ...{
            vDispArea: `vReflectWarning${props.popParams.vLang || ''}`,
            vLang: props.popParams.vLang,
            desc: text
          }
        }
      }
      context.emit('selectFunc', returnObj)
      closeAsyncPopup()
    }

    const init = async () => {
      const result = await selectZplmt12List(searchParams)

      if (result) {
        gvo.value = result.vo

        if (props.popParams.vSearchType === 'DISPLAY') {
          gvo.value.vZdisplayLt = commonUtils.removeHTMLChangeBr(gvo.value.vZdisplayLt)
        } 
        if (props.popParams.vSearchType === 'WARNING') {
          gvo.value[`vZwarningLt${props.popParams.vLang || ''}`] = commonUtils.removeHTMLChangeBr(gvo.value[`vZwarningLt${props.popParams.vLang || ''}`])
        } 
      }
    }

    init()

    return {
      t,
      commonUtils,
      headerDescObj,
      gvo,
      closeAsyncPopup,
      fnReflect,
    }
  }
}
</script>
