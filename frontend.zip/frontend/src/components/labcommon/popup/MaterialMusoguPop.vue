<template>
  <div class="modal-content modal-content__max-20">
    <div class="modal-header">
      <div class="modal-title">무소구 가능항목 상세보기</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({ message: '' })"></button>
    </div>

    <div class="modal-body">

      <div class="modal-body__item">
        <div class="modal-sub-title">기본정보</div>
        <table class="ui-table__reset ui-table__ver">
          <colgroup>
            <col style="width:14rem">
            <col style="width:auto">
            <col style="width:14rem">
            <col style="width:auto">
          </colgroup>
          <tbody>
            <tr>
              <th>내용물코드</th>
              <td class="ta-l">{{ musogu.rvo.vContCd }}</td>
              <th>Ver-Lot 번호</th>
              <td>Ver #{{ musogu.rvo.vVersionTxt }} / {{ musogu.rvo.vLotNm }}</td>
            </tr>
            <tr>
              <th>내용물 명</th>
              <td colspan="3">무펄) 라네즈 비스포크Swirl 립슬리핑 마스크_거미베어</td>
            </tr>
            <tr>
              <th>무소구 가능항목</th>
              <td colspan="3">
                <div class="text-des">
                  <template v-for="(vo, index) in musogu.list" :key="index">
                    *{{ vo.vSubCodenm }}
                  </template>
                </div>
                <div class="text-des text-des__blue">[
                  <template v-for="(musoguGroup, index) in musogu.musoguGroupList" :key="index">
                    {{ musoguGroup }}
                  </template>
                  은 각 그룹 중 선택된 항목에 한정하여 무소구 가능합니다.] <br>
                  ※오일은 광물성오일/실리콘오일과 함께 선택 불가합니다. EX)오일+광물성오일=불가, 광물성오일+실리콘오일=가능<br>
                  ※피이지 항목은 PEG. PEG 계면활성제, PEG 화합물 등을 포함합니다.<br>
                  ※카본블랙은흑색 계열 제품에 한정합니다. <br>
                  <template v-if="searchParams.vNoteType === 'SC'">
                    ※ 트리클로산은 데오도런트(스프레이 유형 제외)만 무소구 가능합니다.<br>
                  </template>
                  <template v-else-if="searchParams.vNoteType === 'MU'">
                    ※ 트리클로산은 페이스파우더, 피부결점을 감추기 위해 국소적으로 사용하는 파운데이션(예 : 블레미쉬컨실러)만 무소구 가능합니다.<br>
                  </template>
                  <template v-else-if="searchParams.vNoteType === 'HBO'">
                    ※ 트리클로산은 사용 후 씻어내는 인체 세정용만 무소구 가능합니다.<br>
                    ※ 솝(Soap)은 페이셜/바디/헤어 세정용만 무소구 가능합니다.<br>
                    ※ 파라페닐렌디아민은 산화형 염모제만 무소구 가능합니다.<br>
                  </template>
                  ※파라벤, 벤조페논, 이디티에이, 글루텐, 과불화화합물은 협의 항목으로 무소구 의뢰 전 유관 부서(분석랩, QA 등) 협의 후 의뢰 가능합니다.
                </div>
              </td>
            </tr>
            <tr>
              <th>
                <div class="d-flex align-center">주의사항 <i class="icon-caution__gray ml-05"></i></div>
              </th>
              <td colspan="3">
                <div>
                  <div class="text-des text-des__red">
                    ※무소구 가능여부를 판단하기 위한 참고용 데이터로, 인증 프로세스를 진행 해 주세요. <br>
                    ※파라벤, 향, 벤조페논, 이디티에이, 글루텐, 과불화화합물은 시험/평가가 필요하므로 시험품이 송부(to 분석 랩)되어야 합니다.<br>
                    ※향 또는 인공향 무소구 인증은성분과 내용물에 대한 취를 확인하여 가능 여부를 판정합니다.<br>
                    ※무소구인증 의뢰접수는 매달 첫째, 셋째 월~화요일 진행(2주단위)되므로 접수일을 확인하세요. (접수 후 약 2~4주 소요)
                  </div>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="modal-body__item">
        <div class="modal-sub-title modal-sub-title__flex">
          <div class="modal-sub-title__text">내용물 처방</div>
          <div class="modal-sub-title__right">
            ○: 무소구 가능 / <span class="color-yellow">검토: 추가 확인 필요</span> / <span class="color-red">불가: 무소구 불가</span>
          </div>
        </div>

        <div class="ui-table__wrap">
          <table class="ui-table ui-table__material-pop text-center ui-table__td--40 ui-table__th--border-radius--0">
            <colgroup>
              <col style="width:9rem;">
              <col style="width:18%;">
              <col style="width:7%;">
              <template v-for="(vo, index) in musogu.list" :key="index">
                <col style="width:5rem;">
              </template>
            </colgroup>
            <thead>
              <tr>
                <th>원료코드</th>
                <th>원료명</th>
                <th>함량(%)</th>
                <template v-for="(vo, index) in musogu.list" :key="index">
                  <th :class="vo.vContent1">{{ vo.vSubCodenm }}</th>
                </template>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(vo, index) in musogu.musoguYnList" :key="index">
                <template v-if="vo.nLv2Num === 0">
                  <td v-if="vo.vFlagRequest === 'Y'" class="bg-red">
                    <a href="javascript:void(0)" class="tit-link" @click="onClick(vo.vMateCd, vo.vPlantCd)"><span
                        class="color-red">{{ vo.vMateCd
                        }}</span></a>
                  </td>
                  <td v-else :class="getBgRed(vo)">{{ !vo.vMateCd ? vo.vMateTempCd : vo.vMateCd }}</td>
                </template>
                <template v-else>
                  <td :class="getBgRed(vo)">ㄴ {{ vo.vMateCd }}</td>
                </template>
                <td>{{ vo.vMateNm }}</td>
                <td>{{ commonUtils.getDecimalPointFormat(vo.nRate) }}</td>
                <td :style="getBgBlue(0)"><span :class="'color-' + vo.vColor0">{{ vo.vCode0 }}</span></td>
                <td :style="getBgBlue(1)"><span :class="'color-' + vo.vColor1">{{ vo.vCode1 }}</span></td>
                <td :style="getBgBlue(2)"><span :class="'color-' + vo.vColor2">{{ vo.vCode2 }}</span></td>
                <td :style="getBgBlue(3)"><span :class="'color-' + vo.vColor3">{{ vo.vCode3 }}</span></td>
                <td :style="getBgBlue(4)"><span :class="'color-' + vo.vColor4">{{ vo.vCode4 }}</span></td>
                <td :style="getBgBlue(5)"><span :class="'color-' + vo.vColor5">{{ vo.vCode5 }}</span></td>
                <td :style="getBgBlue(6)"><span :class="'color-' + vo.vColor6">{{ vo.vCode6 }}</span></td>
                <td :style="getBgBlue(7)"><span :class="'color-' + vo.vColor7">{{ vo.vCode7 }}</span></td>
                <td :style="getBgBlue(8)"><span :class="'color-' + vo.vColor8">{{ vo.vCode8 }}</span></td>
                <td :style="getBgBlue(9)"><span :class="'color-' + vo.vColor9">{{ vo.vCode9 }}</span></td>
                <td :style="getBgBlue(10)"><span :class="'color-' + vo.vColor10">{{ vo.vCode10 }}</span></td>
                <td :style="getBgBlue(11)"><span :class="'color-' + vo.vColor11">{{ vo.vCode11 }}</span></td>
                <td :style="getBgBlue(12)"><span :class="'color-' + vo.vColor12">{{ vo.vCode12 }}</span></td>
                <td :style="getBgBlue(13)"><span :class="'color-' + vo.vColor13">{{ vo.vCode13 }}</span></td>
                <td :style="getBgBlue(14)"><span :class="'color-' + vo.vColor14">{{ vo.vCode14 }}</span></td>
                <td :style="getBgBlue(15)"><span :class="'color-' + vo.vColor15">{{ vo.vCode15 }}</span></td>
                <td :style="getBgBlue(16)"><span :class="'color-' + vo.vColor16">{{ vo.vCode16 }}</span></td>
                <td :style="getBgBlue(17)"><span :class="'color-' + vo.vColor17">{{ vo.vCode17 }}</span></td>
                <td :style="getBgBlue(18)"><span :class="'color-' + vo.vColor18">{{ vo.vCode18 }}</span></td>
              </tr>
              <tr>
                <td colspan="2">총 합량 합계</td>
                <td>{{ getSumRate() }}</td>
                <td colspan="19"></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div class="board-bottom">
        <div class="board-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--lightgray"
              @click="closeAsyncPopup({ message: '닫기' })">닫기</button>
          </div>
        </div>
      </div>
    </div>
  </div><!-- /.modal-content -->
</template>

<script>
import { reactive, inject } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useMaterialCommon } from '@/compositions/labcommon/useMaterialCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'MaterialMusoguPop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: '',
          vLotCd: '',
          vLand1: '',
          vNoteType: '',
        }
      }
    }
  },
  components: {
  },
  setup(props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncAlert', 'closeAsyncPopup'])
    const musogu = reactive({
      rvo: {},
      list: [],
      musoguGroupList: [],
      musoguYnList: [],
      mtrList: [],
    })
    const searchParams = reactive({
      vLabNoteCd: props?.popParams?.vLabNoteCd,
      vLotCd: props?.popParams?.vLotCd,
      vLand1: props?.popParams?.vLand1,
      vNoteType: props?.popParams?.vNoteType,
    })
    const backColorIdxs = reactive({
      num: [],
    })

    const { insertHal4Mate } = useLabCommon()

    const { selectMusoguList } = useMaterialCommon()

    const init = async () => {
      const result = await selectMusoguList(searchParams)

      musogu.rvo = result.rvo
      musogu.list = result.list
      musogu.musoguGroupList = result.musoguGroupList
      musogu.musoguYnList = result.musoguYnList
      musogu.mtrList = [
        ...result.mtr04List,
        ...result.mtr05List,
        ...result.mtr06List,
      ]

      musogu.list.map((vo, idx) => {
        if (musogu.mtrList.filter(mtr => mtr.vBuffer1 === vo.vBuffer1).length > 0) {
          backColorIdxs.num.push(idx)
        }
      })
    }

    const getBgBlue = (idx) => {
      return backColorIdxs.num.filter(num => num === idx).length > 0 ? 'background-color: #87cefa;' : ''
    }

    const getBgRed = (obj) => {
      if (obj.vCode0 === '불가' || obj.vCode1 === '불가' || obj.vCode3 === '불가' || obj.vCode4 === '불가' || obj.vCode5 === '불가'
        || obj.vCode6 === '불가' || obj.vCode7 === '불가' || obj.vCode8 === '불가' || obj.vCode9 === '불가' || obj.vCode10 === '불가'
        || obj.vCode11 === '불가' || obj.vCode12 === '불가' || obj.vCode13 === '불가' || obj.vCode14 === '불가' || obj.vCode15 === '불가'
        || obj.vCode16 === '불가' || obj.vCode17 === '불가' || obj.vCode18 === '불가') {
        return 'bg-red'
      }
      return ''
    }

    const getSumRate = () => {
      let rateSum = 0
      musogu.musoguYnList.filter(o => o.nLv2Num === 0).forEach(o => {
        rateSum += o.nRate
      })
      return commonUtils.getDecimalPointFormat(rateSum.toFixed(6))
    }

    const onClick = (vMateCd, vPlantCd) => {
      if (commonUtils.isEmpty(vMateCd) || commonUtils.isEmpty(vPlantCd)) {
        openAsyncAlert({ message: '4자코드 필수정보가 없습니다.' })
        return
      }

      const res = insertHal4Mate({
        vMateCd,
        vPlantCd,
        vLand1: searchParams.vLand1,
      })
    }

    init()

    return {
      t,
      commonUtils,
      musogu,
      searchParams,
      closeAsyncPopup,
      getBgBlue,
      getBgRed,
      getSumRate,
      onClick,
    }
  }
}
</script>