<template>
  <div class="modal-content modal-content__max-122">
    <div class="modal-header">
      <div class="modal-title">배합한도 세부사항</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({ message: '' })"></button>
    </div>

    <div class="modal-body">

      <div class="search-depart-table">
        <div class="search-depart-table__inner">
          <table class="ui-table__td--40">
            <colgroup>
              <col style="width:10rem">
              <col style="width:14rem">
              <col style="width:auto">
            </colgroup>
            <thead>
              <tr style="height: 40px;">
                <th></th>
                <th style="text-align: center;">최대사용량</th>
                <th style="text-align: center;">비고</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(vo, index) in maxmix.list" :key="index">
                <th>{{ vo.vMrqNm }}</th>
                <td style="text-align: right;">{{ vo.nMaxMix }}</td>
                <td class="ta-l">{{ vo.vTesterComment }}</td>
              </tr>
              <tr v-if="maxmix.list.length === 1">
                <th>안정성</th>
                <td style="text-align: right;">0</td>
                <td></td>
              </tr>
              <tr>
                <th>향료</th>
                <td style="text-align: right;">NA</td>
                <td></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div class="board-bottom">
        <div class="board-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--lightgray"
              @click="closeAsyncPopup({ message: '닫기' })">닫기</button>
          </div>
        </div>
      </div>
    </div>
  </div><!-- /.modal-content -->
</template>

<script>
import { reactive, inject } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'MaxMixPop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: '',
          vMateCd: '',
          nVersion: '',
        }
      }
    }
  },
  components: {
  },
  setup(props, context) {
    const t = inject('t')
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])
    const maxmix = reactive({
      list: [],
    })
    const searchParams = reactive({
      vLabNoteCd: props.popParams.vLabNoteCd,
      vMateCd: props.popParams.vMateCd,
      nVersion: props.popParams.nVersion,
    })

    const { selectLabNoteMaxMixMrqList } = useLabCommon()

    const init = async () => {
      maxmix.list = await selectLabNoteMaxMixMrqList(searchParams)
    }

    init()

    return {
      t,
      maxmix,
      closeAsyncPopup,
    }
  }
}
</script>