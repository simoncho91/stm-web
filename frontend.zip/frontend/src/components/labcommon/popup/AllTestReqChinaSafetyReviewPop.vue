<template>
  <div class="modal-content modal-content__width--122">
    <div class="modal-header">
      <div class="modal-title">시험의뢰 (중국 안전성 사전검토)</div>
      <button
        type="button"
        class="modal-close"
        @click="closeAsyncPopup"
      ></button>
    </div>
    <div class="modal-body">
      <div class="search-detail-table">
        <div class="search-detail-table__inner">
          <table class="ui-table__modal pd">
            <colgroup>
              <col style="width:6%">
              <col style="width:6%">
              <col style="width:15%">
              <col style="width:auto">
              <col style="width:8%">
              <col style="width:13%">
              <col style="width:13%">
              <col style="width:10%">
            </colgroup>
            <thead>
              <tr>
                <th>
                  <ap-input-check
                    v-model:model="chkAll"
                    :value="'Y'"
                    :false-value="'N'"
                    :id="'ex_check_all'"
                    @click="fnCheckAll"
                  >
                  </ap-input-check>
                </th>
                <th>대표</th>
                <th>내용물코드/제품코드</th>
                <th>내용물명</th>
                <th>플랜트</th>
                <th>버전</th>
                <th>LOT</th>
                <th>비고 </th>
              </tr>
            </thead>
            <tbody>
              <template v-if="resData.contList?.length > 0">
                <tr v-for="(cvo, idx1) in resData.contList" :key="`tr_${idx1}`">
                  <td>
                    <ap-input-check
                      v-model:model="testReqTergetList"
                      :value="cvo.vContPkCd"
                      :id="`ex_check_${idx1}`"
                      @click="fnAddTestReqTarget($event, idx1)"
                    >
                    </ap-input-check>
                  </td>
                  <td>
                    <div class="ui-label jc-c">
                      <ap-input-radio
                        v-model:model="payload.vRepContPkCd"
                        :value="cvo.vContPkCd"
                        :id="`flagNew_${idx1}`"
                        name="flagNew"
                        @click="fnClickRep(cvo)"
                      ></ap-input-radio>
                    </div>
                  </td>
                  <td>{{ cvo.vContCd }} / {{ cvo.vPrdCd }}</td>
                  <td>
                    <div class="tit__inner">
                      {{ cvo.vContNm }}
                    </div>
                    </td>
                  <td>{{ cvo.vPlantCd }}</td>
                  <td>
                    <div class="ui-select-block">
                      <ap-selectbox
                        v-model:value="cvo.nVersion"
                        input-class="ui-select__width--120"
                        :options="resData.verList"
                        :disabled="testReqTergetList.indexOf(cvo.vContPkCd) === -1"
                        codeKey="nVersion"
                        codeNmKey="vVersionTxt"
                        @change="fnChangeVersion($event, cvo)"
                      >
                      </ap-selectbox>
                    </div>
                  </td>
                  <td>
                    <div class="ui-select-block">
                      <ap-selectbox
                        v-model:value="cvo.vLotCd"
                        input-class="ui-select__width--120"
                        :options="cvo.subList"
                        :disabled="testReqTergetList.indexOf(cvo.vContPkCd) === -1"
                        codeKey="vLotCd"
                        codeNmKey="vLotNm"
                        @change="fnSelectOption($event, cvo)"
                      >
                      </ap-selectbox>
                    </div>
                  </td>
                  <td></td>
                </tr>
              </template>
              <template v-else>
                <tr>
                  <td colspan="8">
                    <div class="no-result">
                      {{ t('common.msg.no_data') }}
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>

      <div class="tableTitle mt-2">정보 입력</div>
      <div class="board-top mb-0">
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">영문명<span class="ui-require"><span class="for-a11y">(필수)</span></span></dt>
            <dd class="search-bar__val--flexible">
              <ap-input :is-number="false" v-model:value="payload.vTrContNmEn" :inputClass="'ui-input__width--full'"></ap-input>
            </dd>
          </dl>
        </div>
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">TDD제품유형<span class="ui-require"><span class="for-a11y">(필수)</span></span></dt>
            <dd class="search-bar__val--flexible">
              <div>
                <TddProductClassTree
                  v-model:classcd="payload.vProductClass"
                  v-model:classnm="payload.vProductClassNm"
                />
              </div>
            </dd>
          </dl>
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">LEAVE-ON/<br/>RINSE-OFF<span class="ui-require"><span class="for-a11y">(필수)</span></span></dt>
            <dd class="search-bar__val--flexible">
              <div class="form-flex">
                <div class="form-flex-cell form-flex__cell--5">
                  <div class="ui-checkbox__list">
                    <div class="ui-checkbox__inner">
                      <ap-input-radio
                        v-model:model="payload.vLeaveOnYn"
                        :value="'Y'"
                        :id="`leaveOnYn_y`"
                        :label="'leave-on'"
                        name="leaveOnYn"
                      ></ap-input-radio>
                      <ap-input-radio
                        v-model:model="payload.vLeaveOnYn"
                        :value="'N'"
                        :id="`leaveOnYn_n`"
                        :label="'rinse-off'"
                        name="leaveOnYn"
                      ></ap-input-radio>
                    </div>
                  </div>
                </div>
                
              </div>
            </dd>
          </dl>
        </div>
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100">신원료 포함 여부</dt>
            <dd class="search-bar__val--flexible">
              <div class="form-flex">
                <div class="form-flex-cell form-flex__cell--5">
                  <div class="ui-checkbox__list">
                    <div class="ui-checkbox__inner">
                      <ap-input-radio
                        v-model:model="payload.vNewContYn"
                        :value="'Y'"
                        :id="`NewCont_y`"
                        :label="'Y'"
                        name="NewCont"
                      ></ap-input-radio>
                      <ap-input-radio
                        v-model:model="payload.vNewContYn"
                        :value="'N'"
                        :id="`NewCont_n`"
                        :label="'N'"
                        name="NewCont"
                      ></ap-input-radio>
                    </div>
                  </div>
                </div>
                
              </div>
            </dd>
          </dl>
        </div>

        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--100 mt-m3">메시지</dt>
            <dd class="search-bar__val--flexible">
              <ap-text-area
                :is-with-byte="true"
                v-model:value="payload.vTrComment"
                :maxlength="2000"
              ></ap-text-area>
            </dd>
          </dl>
        </div>
      </div>
      <div class="board-bottom ">
        <div class="board-bottom__inner">
          <div class="ui-buttons ml-auto ui-buttons__right">
            <button
              type="button"
              class="ui-button ui-button__bg--skyblue font-weight__300"
              @click="fnTestReqSave"
            >시험의뢰</button>
            <button
              type="button"
              class="ui-button ui-button__bg--lightgray"
              @click="closeAsyncPopup"
            >닫기</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, inject, defineAsyncComponent, watch, getCurrentInstance } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useTestReqCommon } from '@/compositions/labcommon/useTestReqCommon'

export default {
  name: 'AllTestReqChinaSafetyReviewPop',
  components: {
    TddProductClassTree: defineAsyncComponent(() => import('@/components/comm/TddProductClassTree.vue')),
  },
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: ''
        , vContPkCd: ''
        , nVersion: ''
        , vLotCd: ''
        , vPlantCd: ''
        , vMrqTypeCd: ''
        }
      }
    }
  },
  emits: ['selectFunc'],
  setup(props, context) {
    const app = getCurrentInstance();
    const tiumUrl = app.appContext.config.globalProperties.tiumUrl
    
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { openAsyncConfirm, openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncConfirm', 'openAsyncAlert', 'closeAsyncPopup'])

    const flagLotCompleYn = ref('')

    const { 
      selectPrdTestReqChinaSafetyReviewInfo,
      goSkinTestReqSave,
      selectTestReqLotList,
    } = useTestReqCommon()

    const searchParams = ref({
      vLabNoteCd: props.popParams.vLabNoteCd,
      // vContPkCd: props.popParams.vContPkCd,
      vOtherContPkCd: props.popParams.vContPkCd,
      nVersion: props.popParams.nVersion,
      vLotCd: props.popParams.vLotCd,
      vPlantCd: props.popParams.vPlantCd,
      vMrqTypeCd: props.popParams.vMrqTypeCd,
      vTrMrqTypeCd: props.popParams.vMrqTypeCd,
      vGateCd: props.popParams.vGateCd,
    })

    // 테스트용
    // const searchParams = ref({
    //   vLabNoteCd: 'LMS20230313010281',
    //   vOtherContPkCd: 'LCO20230313011941',
    //   nVersion: 4,
    //   vLotCd: props.popParams.vLotCd,
    //   vPlantCd: '1110',
    //   vMrqTypeCd: props.popParams.vMrqTypeCd,
    //   vTrMrqTypeCd: props.popParams.vMrqTypeCd,
    //   vGateCd: 'GATE_1',
    // })

    const resData = ref({})

    const testReqTergetList = ref([])
    const chkAll = ref('N')

    const payload = ref({
      vRepContPkCd: '',
      vRepContCd: '',
      vRepLotCd: '',
      vRepPlantCd: '',
      nRepVersion: '',

      vFlagAction: 'SAVE_TEST_REQ',

      // 점도
      vTestType: '',
      vTestTypeNm: '',
      vTestValue: '',
      // pH
      vTrPh: '',
      // 영문명
      vTrContNmEn: '',

      // 메시지
      vTrComment: '',

      vTrPrdCd: '',
      vTddProdType1Cd: '',
      vTddProdType2Cd: '',

      // TDD제품유형
      vProductClass: '',
      vProductClassNm: '',
      // LEAVE-ON/RINSE-OFF
      vLeaveOnYn: 'Y',
      // 신원료 포함 여부
      vNewContYn: '',
    })

    const fnSelectOption = (value, vo) => {
      const lvo = vo.subList.find(svo => svo.vLotCd === value)
      
      if (payload.value.vRepContPkCd && payload.value.vRepContPkCd === vo.vContPkCd) {
          payload.value.vTestType = lvo ? lvo.vTestType : ''
          payload.value.vTestTypeNm = lvo ? lvo.vTestTypeNm : ''
          payload.value.vTestValue = lvo ? lvo.vTestValue : ''
          payload.value.vTrPh = lvo ? lvo.vPh :''
          flagLotCompleYn.value = lvo ? lvo.vFlagComplete : ''
      }

      // vo.nVersion = lvo ? lvo.nVersion : ''
      vo.vLotNm = lvo ? lvo.vLotNm : ''
    }

    const fnClickRep = (vo) => {
      const lotCd = vo?.vLotCd

      if (lotCd) {
        const lvo = vo.subList.find(svo => svo.vLotCd === lotCd)

        if (lvo) {
          payload.value.vTestType = lvo.vTestType
          payload.value.vTestTypeNm = lvo.vTestTypeNm
          payload.value.vTestValue = lvo.vTestValue
          payload.value.vTrPh = lvo.vPh
          flagLotCompleYn.value = lvo.vFlagComplete

          vo.vLotNm = lvo.vLotNm
        } else {
          payload.value.vTestType = ''
          payload.value.vTestTypeNm = ''
          payload.value.vTestValue = ''
          payload.value.vTrPh = ''
          flagLotCompleYn.value = ''

          vo.vLotNm = ''
        }
      } else {
        payload.value.vTestType = ''
        payload.value.vTestTypeNm = ''
        payload.value.vTestValue = ''
        payload.value.vTrPh = ''
        flagLotCompleYn.value = ''

        vo.vLotNm = ''
      }
    }

    const fnTestReqSave = async () => {
      if (testReqTergetList.value.length === 0) {
        await openAsyncAlert({ message: '시험의뢰할 대상을 선택해 주세요.' })
        return
      }

      const vRepContPkCd = payload.value.vRepContPkCd

      if (commonUtils.isEmpty(vRepContPkCd)) {
        await openAsyncAlert({ message: '대표 내용물을 선택해 주세요.' })
        return
      }

      const repCvo = resData.value.contList.find(cvo => cvo.vContPkCd === vRepContPkCd)

      if (repCvo) {
        const vRepLotCd = repCvo.vLotCd

        // if (commonUtils.isEmpty(vRepLotCd)) {
        //   await openAsyncAlert({ message: 'Lot를 선택해 주세요.' })
        //   return
        // }
        const targetList = resData.value.contList.filter(cvo => testReqTergetList.value.indexOf(cvo.vContPkCd) > -1)

        if (targetList.some(vo => commonUtils.isEmpty(vo.vLotCd))) {
          await openAsyncAlert({ message: 'Lot를 선택해 주세요.' })
          return
        }

        if (commonUtils.isEmpty(payload.value.vTrContNmEn)) {
          await openAsyncAlert({ message: '영문명을 입력해 주세요.' })
          return
        }

        if (commonUtils.isEmpty(payload.value.vProductClass) || payload.value.vProductClass === 'S000001') {
          await openAsyncAlert({ message: 'TDD 제품유형을 선택해 주세요' })
          return
        }

        if (commonUtils.isEmpty(payload.value.vNewContYn)) {
          await openAsyncAlert({ message: '신원료 포함 여부를 선택해 주세요.' })
          return
        } else {
          if (payload.value.vNewContYn === 'Y') {
            const url = `${tiumUrl}/china_zm/china_safe/ev/china_zm_safe_ev_reg.do?${[`i_sLotCd=${vRepLotCd}`, 'i_sActionFlag=NEW'].join('&')}`

            const message = 
            `신원료(2*****/1*****), Blank (6999999)포함시, 중국사전안전검토시스템 의뢰 불가합니다.<br/>
             BOM엑셀다운로드에서 해당 엑셀폼을 다운받아 따로 등록 요청드립니다.<br/>
             <span><a href='${url}' target='_blank' id='' style='text-decoration:underline;'>[중국 사전안전성 등록페이지로 이동하기]</a></span>`
  
            await openAsyncAlert({ message: message })
            return
          }
        }
        
        if (!commonUtils.checkByte(payload.value.vTrComment, 2000)) {
          await openAsyncAlert({ message: '메시지는 2000byte (한글 : 666자, 영문 : 2000자) 이내로 입력해 주세요.' })
          return
        }

        payload.value.vRepContCd = repCvo.vContCd || ''
        payload.value.vRepLotCd = vRepLotCd
        payload.value.vRepPlantCd = repCvo.vPlantCd || ''
        payload.value.nRepVersion = repCvo.nVersion || ''

        // payload.value.vTrPrdCd = repCvo.vTrPrdCd || ''
      }

      if(flagLotCompleYn.value !== "Y"){
        const confirmMessage = '<span style="font-weight:bold; color:red;">시험의뢰시 해당 Lot은 더이상 수정 할 수 없습니다.</span><br/>저장 하시겠습니까?'
        if (!await openAsyncConfirm({ message: confirmMessage })) {
          return
        }
      }

      const params = {
        ...searchParams.value,
        ...payload.value,
        ...{
          contList: resData.value.contList.filter(cvo => testReqTergetList.value.indexOf(cvo.vContPkCd) > -1) || [],
        }
      }

      goSkinTestReqSave(params)
    }

    const fnCheckAll = (value) => {
      if (value === 'Y') {
        testReqTergetList.value = resData.value.contList.map(cvo => cvo.vContPkCd)

        if (commonUtils.isEmpty(payload.value.vRepContPkCd)) {
          payload.value.vRepContPkCd = resData.value.contList.find(cvo => cvo.subList.length > 0).vContPkCd
        }
      } else {
        testReqTergetList.value = []
        payload.value.vRepContPkCd = ''
      }

    }

    const fnAddTestReqTarget = (value, idx) => {
      const targetList = testReqTergetList.value

      if (value) {
        // 시험 의뢰 대상 체크했을 때
        if (targetList.length === resData.value.contList.length) {
          chkAll.value = 'Y'
        }

        if (!payload.value.vRepContPkCd) {
          payload.value.vRepContPkCd = value
        }
      } else {
        // 시험 의뢰 대상 체크 해제했을 때
        if (targetList.length > 0) {
          const contList = resData.value.contList
          const existContPkCd = contList[idx].vContPkCd
          const repContPkCd = payload.value.vRepContPkCd

          if (existContPkCd && repContPkCd && existContPkCd === repContPkCd) {
            // 해제한 대상이 대표로 체크되어 있었는 지 확인
            payload.value.vRepContPkCd = contList.find(cvo => targetList.some(contPkCd => contPkCd === cvo.vContPkCd)).vContPkCd
          }
        } else {
          payload.value.vRepContPkCd = ''
        }
        chkAll.value = 'N'
      }
    }

    const fnChangeVersion = async (value, vo) => {
      vo.vLotCd = ''
      vo.vLotNm = ''

      if (commonUtils.isEmpty(value)) {
        vo.subList = []
      } else {
        const payload = {
          vContPkCd: vo.vContPkCd,
          nVersion: value
        }
  
        const result = await selectTestReqLotList(payload)
  
        if (result) {
          vo.subList = result
        }
      }
    }

    watch(() => payload.value.vRepContPkCd, (newVal, oldVal) => {
      if (commonUtils.isNotEmpty(newVal)) {
        const cvo = resData.value.contList.find(vo => vo.vContPkCd === newVal)
  
        if (cvo.vLotCd) {
          const lvo = cvo.subList.find(svo => svo.vLotCd === cvo.vLotCd)
  
          if (lvo) {
            payload.value.vTestType = lvo.vTestType
            payload.value.vTestTypeNm = lvo.vTestTypeNm
            payload.value.vTestValue = lvo.vTestValue
            payload.value.vTrPh = lvo.vPh
            flagLotCompleYn.value = lvo.vFlagComplete

            cvo.vLotNm = lvo.vLotNm
          } else {
            payload.value.vTestType = ''
            payload.value.vTestTypeNm = ''
            payload.value.vTestValue = ''
            payload.value.vTrPh = ''
            flagLotCompleYn.value = ''

            cvo.vLotNm = ''
          }
        } else {
          payload.value.vTestType = ''
          payload.value.vTestTypeNm = ''
          payload.value.vTestValue = ''
          payload.value.vTrPh = ''
          flagLotCompleYn.value = ''

          cvo.vLotNm = ''
        }
      } else {
        payload.value.vTestType = ''
        payload.value.vTestTypeNm = ''
        payload.value.vTestValue = ''
        payload.value.vTrPh = ''
        flagLotCompleYn.value = ''
      }
    })

    const init = async () => {
      resData.value = await selectPrdTestReqChinaSafetyReviewInfo(searchParams.value)
      
      if (resData.value) {
        if (resData.value.noteVo) {
          payload.value.vTddProdType1Cd = resData.value.noteVo.vTddProdType1Cd
          payload.value.vTddProdType2Cd = resData.value.noteVo.vTddProdType2Cd
          payload.value.vProductClass = resData.value.noteVo.vTddProdType2Cd
          payload.value.vLeaveOnYn = resData.value.noteVo?.vLeaveType === 'LNC14_01' ? 'Y' : 'N'
        }
        if (resData.value.contList) {
          const contList = resData.value.contList

          const repCvo = contList.find(cvo => cvo.vContPkCd === searchParams.value.vOtherContPkCd)
  
          if (repCvo) {
            payload.value.vRepContPkCd = repCvo.vContPkCd
            // testReqTergetList.value.push(repCvo.vContPkCd)
          }

          if (testReqTergetList.value.length === contList.length) {
            chkAll.value = 'Y'
          }

          contList.forEach(cvo => {
            if(cvo.subList && cvo.subList.length > 0) {
              testReqTergetList.value.push(cvo.vContPkCd)
            }
            cvo.nVersion = props.popParams.nVersion
          });
        }
      } else {
        closeAsyncPopup()
      }
    }

    init()

    return {
      t,
      closeAsyncPopup,
      selectPrdTestReqChinaSafetyReviewInfo,
      resData,
      payload,
      fnSelectOption,
      fnClickRep,
      flagLotCompleYn,
      fnTestReqSave,
      testReqTergetList,
      chkAll,
      fnCheckAll,
      fnAddTestReqTarget,
      fnChangeVersion,
    }
  }
}
</script>