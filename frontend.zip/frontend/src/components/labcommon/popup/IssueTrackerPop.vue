<template>
  <div class="modal-content modal-content__width--950">
    <div class="modal-header modal-header__mb--10">
      <div class="modal-title">ISSUE TRACK</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({message: ''})"></button>
    </div>
    <div class="modal-body">
      <div class="issue-track__item is-active" v-if="showRegArea()">
        <div class="issue-track__header">
          <div class="issue-track__title">등록</div>
          <button class="ui-button ui-button__circle ui-button__arrow--bottom"></button>
        </div>
        <div class="issue-track__body">
          <table class="ui-table__reset ui-table__ver ui-table__td--50">
            <colgroup>
              <col style="width:16rem">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr>
                <th>내용물코드</th>
                <td>
                  <template v-if="contList && contList.length > 0">
                    <template v-if="contList.length === 1">
                      {{ contList[0].vContCd }}
                    </template>
                    <template v-else>
                      <div class="ui-select-box ui-form-box__width--180">
                        <ap-selectbox
                          v-model:value="regParams.vContCd"
                          :options="contList"
                          code-key="vContCd"
                          code-nm-key="vContCd"
                          @change="fnVersionList();fnIssueTrackList();"
                        >
                        </ap-selectbox>
                      </div>
                    </template>
                  </template>
                </td>
              </tr> 
              <tr>
                <th>내용물명</th>
                <td>
                  <template v-if="contList && contList.length > 0">
                    <template v-if="contList.length === 1">
                      {{ contList[0].vContNm }}
                    </template>
                    <template v-else-if="commonUtils.isNotEmpty(regParams.vContCd)">
                      {{ contList.filter(item => item.vContCd === regParams.vContCd)[0].vContNm }}
                    </template>
                  </template>
                </td>
              </tr>
              <tr>
                <th>VER. / LOT</th>
                <td>
                  <div class="form-flex">
                    <div class="ui-select-box ui-form-box__width--180  form-flex__cell--5">
                      <ap-selectbox
                        v-model:value="regParams.nVersion"
                        :options="verList"
                        code-key="nVersion"
                        code-nm-key="vVersionNm"
                        @change="fnLotList"
                      >
                      </ap-selectbox>
                    </div>
                    <div class="ui-select-box ui-form-box__width--180  form-flex__cell--5">
                      <ap-selectbox
                        v-model:value="regParams.vLot"
                        :options="lotList"
                        code-key="vLotNm"
                        code-nm-key="vLotNm"
                      >
                      </ap-selectbox>
                    </div>
                  </div>
                </td>
              </tr>
              <tr>
                <th>구분</th>
                <td>
                  <div class="search-form">
                    <div class="search-form__inner">
                      <ap-input
                        v-model:value="addTypeTxt"
                        placeholder="구분명을 입력해 주세요. (최대 5글자)"
                        :maxlength="5"
                        @keypress-enter="fnAddTypeTxt"
                      >
                      </ap-input>
                      <button type="button" class="button-search" @click="fnAddTypeTxt()">추가</button>
                    </div>
                  </div>
                  <div class="mt-10" id="error_wrap_vTypeNm">
                    <div class="ui-bedges__wrap">
                      <div
                        class="p-relative bedge-area"
                        v-for="(vo, idx) in typeList"
                        :key="'type_' + idx"
                      >
                        <button
                          :class="['ui-bedge__type',
                                  'ui-bedge__type--' + vo.vBedgeColor,
                                  (regParams.vTypeNm === vo.vTypeNm ? 'is-click' : ''),
                                  (vo.vCodeFlag !== 'Y' ? 'bedge-pd' : '')]"
                          @click="fnSelectBedge(vo)"
                        >
                          {{ vo.vTypeNm }}
                        </button>
                        <a href="#"
                          class="ui-bedge__close"
                          v-if="vo.vCodeFlag !== 'Y'"
                          @click.prevent="removeAddTypeTxt(idx)"
                        ></a>
                      </div>
                    </div>
                    <span class="error-msg" id="error_msg_vTypeNm"></span>
                  </div>
                </td>
              </tr>
              <tr>
                <th>내용</th>
                <td>
                  <div class="ui-textarea-box" id="error_wrap_vContent">
                    <ap-text-area
                      v-model:value="regParams.vContent"
                      :is-with-byte="true"
                      :maxlength="1000"
                      id="vContent"
                      @input="fnValidate('vContent')"
                    >
                    </ap-text-area>
                    <span class="error-msg" id="error_msg_vContent"></span>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div class="issue-track__item is-active">
        <div class="issue-track__header">
          <div class="issue-track__title">내용보기</div>
          <button class="ui-button ui-button__circle ui-button__arrow--bottom"></button>
        </div>
        <div class="issue-track__body">
          <table class="ui-table__reset ui-table__ver ui-table__td--50">
            <colgroup>
              <col style="width:16rem">
              <col style="width:auto">
            </colgroup>
            <tbody v-if="list && list.length > 0">
              <tr v-for="vo in list" :key="vo.vIssueTrackCd">
                <th class="text-center">
                  <div class="ui-bedges__wrap ui-bedges__wrap--center pt-10">
                    <div class="ui-bedge__type  is-click" :class="'ui-bedge__type--' + vo.vTypeColor">{{ vo.vTypeNm }}</div>
                  </div>
                  <div class="issue-track__time">{{ commonUtils.changeStrDatePattern(vo.vRegDtm, '.', 'Y') }}</div>
                </th>
                <td>
                  <div class="issue-track__judge">
                    <div class="issue-track__judge--item">
                      <div class="issue-track__judge--title">
                        {{ commonUtils.isNotEmpty(vo.vContCd) ? '[' + vo.vContCd + '] ' : '' }}
                        <tempate v-if="commonUtils.isNotEmpty(vo.nVersion) && Number(vo.nVersion) !== 0">
                          Ver #{{ vo.nVersion > 9 ? vo.nVersion : '0' + vo.nVersion }}
                        </tempate>
                        <tempate v-if="commonUtils.isNotEmpty(vo.vLot)">
                         - {{ vo.vLot }}
                        </tempate>
                      </div>
                      <div
                        class="issue-track__judge--contents"
                        v-html="commonUtils.removeHTMLChangeBr(vo.vContent)"
                      ></div>
                    </div>
                  </div>
                </td>
              </tr>
            </tbody>
            <tbody v-else>
              <tr>
                <td colspan="2">
                  <div class="no-result">
                    등록된 내용이 없습니다.
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div class="page-bottom">
        <div class="page-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnSave()">저장</button>
            <button type="button" class="ui-button ui-button__bg--lightgray" @click="closeAsyncPopup({ message: '' })">닫기</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { reactive, ref, inject, onMounted } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useStore } from 'vuex'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'IssueTrackerPop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: '',
          noteInfo: {},
          vNoteType: '',
        }
      }
    }
  },
  setup (props) {
    const { openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncAlert', 'closeAsyncPopup'])
    const commonUtils = inject('commonUtils')
    const t = inject('t')
    const addTypeTxt = ref('')
    const list = ref([])
    const typeList = ref([])
    const contList = ref([])
    const verList = ref([])
    const lotList = ref([])
    const store = useStore()
    const myInfo = store.getters.getMyInfo()
    const noteInfo = props.popParams.noteInfo || {}
    const colorList = ['pink', 'orange', 'brown', 'darkyellow', 'lightgreen', 'green', 'deepgreen', 'blue', 'purple', 'lightpurple']
    const {
      codeGroupMaps,
      findCodeList,
    } = useCode()

    const {
      insertCommIssuetrack,
      selectCommIssuetrackList,
    } = useLabCommon()

    const regParams = reactive({
      vLabNoteCd: props.popParams.vLabNoteCd,
      vContCd: '',
      vContNm: '',
      nVersion: '',
      vLot: '',
      vTypeNm: '',
      vContent: '',
      vNoteType: props.popParams.vNoteType || '',
      vTypeColor: '',
    })

    const fnVersionList = () => {
      regParams.nVersion = ''
      regParams.vLot = ''
      if (commonUtils.isNotEmpty(regParams.vContCd)) {
        const vContPkCd = contList.value.filter(item => item.vContCd === regParams.vContCd)[0].vContPkCd
        verList.value = [ ...noteInfo.verList.filter(item => item.vContPkCd === vContPkCd )]
      } else {
        verList.value = []
      }

      if (verList.value.length === 1) {
        regParams.nVersion = verList.value[0].nVersion
        fnLotList()
      }
    }

    const fnLotList = () => {
      regParams.vLot = ''
      if (commonUtils.isNotEmpty(regParams.vContCd) && commonUtils.isNotEmpty(regParams.nVersion)) {
        const vContPkCd = contList.value.filter(item => item.vContCd === regParams.vContCd)[0].vContPkCd
        lotList.value = [...noteInfo.lotList.filter(item => item.vContPkCd === vContPkCd && item.nVersion === regParams.nVersion)]
      } else {
        lotList.value = []
      }

      if (lotList.value.length === 1) {
        regParams.vLot = lotList.value[0].vLotNm
      }
    }

    const fnAddTypeTxt = () => {
      if (commonUtils.isEmpty(addTypeTxt.value)) {
        openAsyncAlert({ message: '구분명을 입력해 주세요.' })
        return
      }
      const addObj = {
        vTypeNm: addTypeTxt.value,
        vCodeFlag: 'N',
        vBedgeColor: colorList[Math.floor(Math.random() * 9)]
      }

      typeList.value.push(addObj)
      addTypeTxt.value = ''
    }

    const removeAddTypeTxt = (idx) => {
      regParams.vTypeNm = ''
      regParams.vTypeColor = ''
      typeList.value.splice(idx, 1)
    }

    const fnSelectBedge = (item) => {
      regParams.vTypeNm = item.vTypeNm
      regParams.vTypeColor = item.vBedgeColor

      fnValidate('vTypeNm')
    }

    const fnValidate = (key) => {
      let isOk = true
      let errorMsg = '필수 입력 사항입니다.'
      commonUtils.hideErrorMessage(key)

      if (key === 'vContent') {
        if (commonUtils.isEmpty(regParams.vContent)) {
          isOk = false
        } else if (!commonUtils.checkByte(regParams.vContent, 1000)) {
          isOk = false
          errorMsg = t('common.msg.byte_msg2', { byteSize: commonUtils.setNumberComma(1000) })
        }
      } else if (commonUtils.isEmpty(regParams[key])) {
        isOk = false
      }

      if (!isOk) {
        commonUtils.showErrorMessage(key, errorMsg)
      }

      return isOk
    }

    const fnValidateAll = () => {
      let isOk = true
      const arrChkKey = ['vTypeNm', 'vContent']
      commonUtils.hideErrorMessageAll(arrChkKey)

      arrChkKey.forEach(key => {
        if (!fnValidate(key)) {
          isOk = false
        }
      })

      return isOk
    }

    const fnSave = async () => {
      if (!fnValidateAll()) {
        await openAsyncAlert({ message: '필수 입력사항을 확인해 주세요.' })
        return
      }

      if (commonUtils.isNotEmpty(regParams.vContCd)) {
        const contInfo = contList.value.filter(cont => cont.vContCd === regParams.vContCd)[0]
        regParams.vContNm = contInfo ? contInfo.vContNm : ''
      }
      
      const result = await insertCommIssuetrack(regParams)

      if (result) {
        await openAsyncAlert({ message: '저장되었습니다.' })
        regParams.vContent = ''
        regParams.vTypeNm = ''
        regParams.vTypeColor = ''
        fnIssueTrackList()
      }
    }

    const fnIssueTrackList = async () => {
      const payload = {
        vLabNoteCd: regParams.vLabNoteCd,
        vNoteType: regParams.vNoteType
      }
      const issueList = await selectCommIssuetrackList(payload)
      list.value = [ ...issueList ]
    }

    const showRegArea = () => {
      let isVisible = false
      const detailInfo = noteInfo.noteInfo
      if (detailInfo && detailInfo.vUserid === myInfo.loginId || commonUtils.checkAuth('S000000')) {
        isVisible = true
      }

      return isVisible
    }

    const init = async () => {
      await findCodeList(['ISSUE_TRACK_TYPE'])
      typeList.value = [ ...codeGroupMaps.value['ISSUE_TRACK_TYPE'].map(item => {
        return {
          vTypeNm: item.vSubCodenm,
          vCodeFlag: 'Y',
          vBedgeColor: item.vBuffer1
        }
      }) ]
      
      if (noteInfo) {
        if (noteInfo.lotList) {
          lotList.value = [ ...noteInfo.lotList ]
        }

        if (noteInfo.verList) {
          verList.value = [ ...noteInfo.verList ]
        }

        if (noteInfo.contList) {
          contList.value = [ ...noteInfo.contList ]

          if (contList.value.length === 1) {
            regParams.vContCd = contList.value[0].vContCd
          }
        }

        fnVersionList()
        fnLotList()
      }

      fnIssueTrackList()
    }

    init()

    const accorBtnEvent = () => {
      const accorBtn = document.querySelectorAll('.ui-button__arrow--bottom')

      for (let i = 0; i < accorBtn.length; i++) {
        accorBtn[i].addEventListener('click', (e) => {
          const accorItem = e.target.parentElement.closest('.issue-track__item')
          accorItem.classList.toggle('is-active')
        })
      }
    }

    onMounted(() => {
      accorBtnEvent()
    })

    return {
      closeAsyncPopup,
      commonUtils,
      t,
      codeGroupMaps,
      regParams,
      addTypeTxt,
      list,
      contList,
      verList,
      lotList,
      typeList,
      fnLotList,
      fnVersionList,
      fnAddTypeTxt,
      removeAddTypeTxt,
      fnSelectBedge,
      fnSave,
      fnValidate,
      showRegArea,
    }
  }
}
</script>
