<template>
  <div class="modal-content modal-content__width--701">
    <div class="modal-header">
      <div class="modal-title">배합규제</div>
      <button type="button" class="modal-close" @click="onClose"></button>
    </div>
    <div class="modal-body">
      <div class="search-depart-table">
        <div class="search-depart-table__inner">
          <table class="ui-table__td--40">
            <colgroup>
              <col style="width:13rem">
              <col style="width:auto">
              <col style="width:13rem">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr>
                <th>성분코드</th>
                <td colspan="3">{{ resData.vConcd }}</td>
              </tr>
              <tr>
                <th>일반 - 성분코드</th>
                <td>{{ resData.vZconcd }}</td>
                <th>표시기준</th>
                <td>{{ resData.vZabcde }}</td>
              </tr>
              <tr>
                <th>배합규제</th>
                <td colspan="3">{{ resData.vMixre }}</td>
              </tr>
              <tr v-if="!popParams.vIsInnerPop">
                <th>배합규제 상세(국문)</th>
                <td colspan="3" v-html="resData.vZcertTxt"></td>
              </tr>
              <tr v-if="!popParams.vIsInnerPop">
                <th>배합규제 상세(영문)</th>
                <td colspan="3" v-html="resData.vZcertTxtEn"></td>
              </tr>
              <tr v-else>
                <th>배합규제 상세</th>
                <td colspan="3" v-html="resData.vTdline"></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, inject } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'MatrMixreInfoPop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vConcd: '',
          vIsInnerPop: false,
        }
      }
    }
  },
  emits: ['closeFunc'],
  setup(props, context) {
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])
    const commonUtils = inject('commonUtils')

    const {
      selectMatrMixreInfo
    } = useLabCommon()

    const resData = ref({})

    const init = async () => {
      if (props.popParams.vConcd) {
        resData.value = await selectMatrMixreInfo(props.popParams)

        if (resData.value) {
          resData.value.vZcertTxt = commonUtils.removeHTMLChangeBr(resData.value.vZcertTxt)
          resData.value.vZcertTxtEn = commonUtils.removeHTMLChangeBr(resData.value.vZcertTxtEn)
          resData.value.vTdline = commonUtils.removeHTMLChangeBr(resData.value.vTdline)
        } else {
          if (props.popParams.vIsInnerPop) {
            context.emit('closeFunc')
          }
          else {
            closeAsyncPopup()
          }
        }
      }
    }

    const onClose = () => {
      if (props.popParams.vIsInnerPop) {
        context.emit('closeFunc')
      }
      else {
        closeAsyncPopup()
      }
    }

    init()

    return {
      resData,
      onClose,
    }
  }
}
</script>
