<template>
  <div class="modal-content modal-content__width--82">
    <div class="modal-header">
      <div class="modal-title">개발 취소</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({message: ''})"></button>
    </div>
    <div class="modal-body">
      <div class="search-depart-table">
        <div class="search-depart-table__inner">
          <table class="ui-table__td--40">
            <colgroup>
              <col style="width:15rem">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr>
                <th>개발 취소 사유</th>
                <td>
                  <ap-input
                    v-model:value="params.vCancelOpinion"
                    input-class="ui-input__width--full"
                  >
                  </ap-input>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div class="board-bottom board-bottom__with--button">
        <div class="board-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--skyblue font-weight__300" @click="fnDevelopCancel()">개발취소</button>
            <button type="button" class="ui-button ui-button__bg--lightgray" @click="closeAsyncPopup({ message: '닫기'})">닫기</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { reactive } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useRequestCommon } from '@/compositions/labcommon/useRequestCommon'

export default {
  name: 'DevelopCancelPop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: '',
          vContCd: '',
          vContNm: '',
        }
      }
    }
  },
  emits: ['callbackFunc'],
  setup (props, context) {
    const { openAsyncConfirm, openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncConfirm', 'openAsyncAlert', 'closeAsyncPopup'])

    const params = reactive({
      vCancelOpinion: ''
    })
    const {
      updateElabNoteCancelInfo
    } = useRequestCommon()

    const fnDevelopCancel = async () => {
      if (await openAsyncConfirm({ message: '해당 실험노트에 대하여 개발 취소를 하시겠습니까?' })) {
        const payload = {
          vLabNoteCd: props.popParams.vLabNoteCd,
          vContCd: props.popParams.vContCd,
          vContNm: props.popParams.vContNm,
          vNotePageType: props.popParams.vNotePageType,
          vMessage: params.vCancelOpinion
        }

        const result = await updateElabNoteCancelInfo(payload)

        if (result === 'SUCC') {
          await openAsyncAlert({ message: '개발 취소되었습니다.' })
          context.emit('callbackFunc', props.popParams.vLabNoteCd)
          closeAsyncPopup({ message: '' })
        }
      }
    }

    return {
      params,
      fnDevelopCancel,
      closeAsyncPopup,
    }
  }
}
</script>

<style scoped>
  .modal-popup .modal-content {
    min-height: inherit;
  }
</style>