<template>
  <div class="modal-content modal-content__width--82">
    <div class="modal-header modal-header__mb--10">
      <div class="modal-title">처방 불러오기</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({ message: '' })"></button>
    </div>
    <div class="modal-body">
      <div class="contents-tab ap_contents_tab">
        <div class="contents-tab__inner">
          <ApTab mst-id="bookmark-search-pop" :tab-list="tabList" @click="getSelectedTabEvent"
            :default-tab="searchParams.vDefaultTab">
          </ApTab>
          <div class="contents-tab__body" id="SIMILAR">
            <section class="search-bar">
              <h2 class="for-a11y">검색</h2>
              <div class="search-bar__left">
                <div class="search-bar__row">
                  <dl class="search-bar__item search-bar__item--width-100">
                    <dt class="search-bar__key">검색</dt>
                    <dd class="search-bar__val search-bar__val--flex">
                      <div class="search-form">
                        <div class="search-form__inner">
                          <ap-input v-model:value="searchParams.vKeyword" placeholder="내용물코드 or 내용물명 or 작성자"
                            inputClass="ui-input ui-input__width--full" @keypress-enter="onSearch">
                          </ap-input>
                          <button type="button" class="button-search" @click="onSearch">검색</button>
                        </div>
                      </div>
                    </dd>
                  </dl>
                </div>
              </div>
            </section>

            <div class="myboard-table">
              <div class="myboard-table__inner">
                <table class="ui-table ui-table__th--border-radius--0 ui-table__td--40 text-center">
                  <colgroup>
                    <col style="width:12%">
                    <col style="width:10%">
                    <col style="width:10%">
                    <col style="width:10%">
                    <col style="width:auto">
                    <col style="width:8%">
                    <col style="width:14%">
                  </colgroup>
                  <thead>
                    <tr>
                      <th>내용물코드</th>
                      <th>플랜트</th>
                      <th>버전</th>
                      <th>LOT</th>
                      <th>내용물명</th>
                      <th>작성자</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(vo, index) in list" :key="index">
                      <td>{{ vo.vContCd }}</td>
                      <td>{{ vo.vPlantCd }}</td>
                      <td>{{ vo.vVersionTxt }}</td>
                      <td>{{ vo.vLotNm }}</td>
                      <td class="tit">
                        <div class="tit__inner"><a href="javascript:void(0)" class="tit-link"
                            @click="onMateRatePop(vo)">{{ vo.vContNm }}</a></div>
                      </td>
                      <td>{{ vo.vUsernm }}</td>
                      <td>
                        <div class="ui-buttons">
                          <button type="button"
                            class="ui-button ui-button__width--40 ui-button__height--23 ui-button__bg--skyblue ui-button__radius--2"
                            @click="onPlantCheck(vo, 'SIMILAR')">적용</button>
                          <button type="button"
                            class="ui-button ui-button__width--40 ui-button__height--23 ui-button__border--blue ui-button__radius--2"
                            @click="closeAsyncPopup({ message: '닫기' })">삭제</button>
                        </div>
                      </td>
                    </tr>
                    <template v-if="list.length === 0">
                      <tr>
                        <td colspan="7">
                          <div class="no-result">
                            {{ t('common.msg.no_data') }}
                          </div>
                        </td>
                      </tr>
                    </template>
                  </tbody>
                </table>
              </div>
            </div>

            <div class="board-bottom">
              <div class="board-bottom__inner">
                <Pagination :page-info="page" @click="onSearch">
                </Pagination>
              </div>
            </div>
          </div>
          <div class="contents-tab__body" id="COUNTER">
            <section class="search-bar">
              <h2 class="for-a11y">검색</h2>
              <div class="search-bar__left">
                <div class="search-bar__row">
                  <dl class="search-bar__item search-bar__item--width-100">
                    <dt class="search-bar__key">검색</dt>
                    <dd class="search-bar__val search-bar__val--flex">
                      <div class="search-form">
                        <div class="search-form__inner">
                          <ap-input v-model:value="searchParams.vKeyword" placeholder="내용물코드 or 내용물명 or 작성자"
                            inputClass="ui-input ui-input__width--full" @keypress-enter="onSearch">
                          </ap-input>
                          <button type="button" class="button-search" @click="onSearch">검색</button>
                        </div>
                      </div>
                    </dd>
                  </dl>
                </div>
              </div>
            </section>
            <div class="myboard-table">
              <div class="myboard-table__inner">
                <table class="ui-table ui-table__th--border-radius--0 ui-table__td--40 text-center">
                  <colgroup>
                    <col style="width:12%">
                    <col style="width:10%">
                    <col style="width:10%">
                    <col style="width:10%">
                    <col style="width:auto">
                    <col style="width:8%">
                    <col style="width:14%">
                  </colgroup>
                  <thead>
                    <tr>
                      <th>내용물코드</th>
                      <th>플랜트</th>
                      <th>버전</th>
                      <th>LOT</th>
                      <th>내용물명</th>
                      <th>작성자</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(vo, index) in list" :key="index">
                      <td>{{ vo.vContCd }}</td>
                      <td>{{ vo.vPlantCd }}</td>
                      <td>{{ vo.vVersionTxt }}</td>
                      <td>{{ vo.vLotNm }}</td>
                      <td class="tit">
                        <div class="tit__inner"><a href="javascript:void(0)" class="tit-link"
                            @click="onMateRatePop(vo)">{{ vo.vContNm }}</a></div>
                      </td>
                      <td>{{ vo.vUsernm }}</td>
                      <td>
                        <div class="ui-buttons jc-c">
                          <button type="button"
                            class="ui-button ui-button__width--40 ui-button__height--23 ui-button__bg--skyblue ui-button__radius--2"
                            @click="onPlantCheck(vo, 'COUNTER')">적용</button>
                        </div>
                      </td>
                    </tr>
                    <template v-if="list.length === 0">
                      <tr>
                        <td colspan="7">
                          <div class="no-result">
                            {{ t('common.msg.no_data') }}
                          </div>
                        </td>
                      </tr>
                    </template>
                  </tbody>
                </table>
              </div>
            </div>

            <div class="board-bottom">
              <div class="board-bottom__inner">
                <Pagination :page-info="page" @click="onSearch">
                </Pagination>
              </div>
            </div>
          </div>
          <div class="contents-tab__body" id="SAP">
            <section class="search-bar">
              <h2 class="for-a11y">SAP SYNC</h2>
              <div class="search-bar__left">
                <div class="search-bar__row">
                  <dl class="search-bar__item search-bar__item--width-100">
                    <dt class="search-bar__key minWidth10">내용물코드</dt>
                    <dd class="search-bar__val search-bar__val--flex">
                      <div class="search-form">
                        <div class="search-form__inner">
                          <div class="form">
                            <div class="ui-select-box ui-form-box__width--200  form-flex__cell--5">
                              <ap-selectbox v-model:value="searchParams.vPlantCdTemp"
                                inputClass="ui-select ui-select__width--90" :options="codeList"></ap-selectbox>
                            </div>
                          </div>
                          <ap-input v-model:value="sapSyncParams.vContCd" inputClass="ui-input ui-input__width--90 ml-05"
                            @keypress-enter="onSearch"></ap-input>
                          <button type="button" class="button-search w80" @click="onSapSync">SAP SYNC</button>
                        </div>
                      </div>
                    </dd>
                  </dl>
                </div>
              </div>
            </section>
          </div>
          <div class="contents-tab__body" id="BASE">
            <section class="search-bar">
              <h2 class="for-a11y">검색</h2>
              <div class="search-bar__left">
                <div class="search-bar__row">
                  <dl class="search-bar__item search-bar__item--width-100">
                    <dt class="search-bar__key">검색</dt>
                    <dd class="search-bar__val search-bar__val--flex">
                      <div class="search-form">
                        <div class="search-form__inner">
                          <ap-input v-model:value="searchParams.vKeyword" placeholder="내용물코드 or 내용물명 or 작성자"
                            inputClass="ui-input ui-input__width--full" @keypress-enter="onSearch">
                          </ap-input>
                          <button type="button" class="button-search" @click="onSearch">검색</button>
                        </div>
                      </div>
                    </dd>
                  </dl>
                </div>
              </div>
            </section>
            <div class="myboard-table">
              <div class="myboard-table__inner">
                <table class="ui-table ui-table__th--border-radius--0 ui-table__td--40 text-center">
                  <colgroup>
                    <col style="width:12%">
                    <col style="width:10%">
                    <col style="width:10%">
                    <col style="width:10%">
                    <col style="width:auto">
                    <col style="width:8%">
                    <col style="width:14%">
                  </colgroup>
                  <thead>
                    <tr>
                      <th>내용물코드</th>
                      <th>플랜트</th>
                      <th>버전</th>
                      <th>LOT</th>
                      <th>내용물명</th>
                      <th>작성자</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(vo, index) in list" :key="index">
                      <td>{{ vo.vContCd }}</td>
                      <td>{{ vo.vPlantCd }}</td>
                      <td>{{ vo.vVersionTxt }}</td>
                      <td>{{ vo.vLotNm }}</td>
                      <td class="tit">
                        <div class="tit__inner"><a href="javascript:void(0)" class="tit-link"
                            @click="onMateRatePop(vo)">{{ vo.vContNm }}</a></div>
                      </td>
                      <td>{{ vo.vUsernm }}</td>
                      <td>
                        <div class="ui-buttons jc-c">
                          <button type="button"
                            class="ui-button ui-button__width--40 ui-button__height--23 ui-button__bg--skyblue ui-button__radius--2"
                            @click="onPlantCheck(vo, 'BASE')">적용</button>
                        </div>
                      </td>
                    </tr>
                    <template v-if="list.length === 0">
                      <tr>
                        <td colspan="7">
                          <div class="no-result">
                            {{ t('common.msg.no_data') }}
                          </div>
                        </td>
                      </tr>
                    </template>
                  </tbody>
                </table>
              </div>
            </div>

            <div class="board-bottom">
              <div class="board-bottom__inner">
                <Pagination :page-info="page" @click="onSearch">
                </Pagination>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <teleport to="#common-modal-sub" v-if="popContent">
      <ap-popup>
        <component :is="popContent" :pop-params="popupParams" @selectFunc="popSelectFunc" @closeFunc="closeFunc" />
      </ap-popup>
    </teleport>
    <div id="common-modal-sub"></div>
  </div>
</template>

<script>
import { defineAsyncComponent, reactive, ref, inject } from 'vue'
import { useMaterialCommon } from '@/compositions/labcommon/useMaterialCommon'
import { useCode } from '@/compositions/useCode'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'BookmarkSearchPop',
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
    BookmarkMateRatePop: defineAsyncComponent(() => import('@/components/labcommon/popup/BookmarkMateRatePop.vue')),
  },
  emits: ['selectFuncMateAndGrp'],
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vSearchField: 'SIMILAR',
          vKeyword: '',
          vLabNoteCd: '',
          vCodeType: '',
          vFlagRepresent: '',
          vFlagBookPop: '',
          vNoteType: '',
          vSiteType: '',
          vLabNoteCdTemp: '',
          vPlantCdTemp: '',
        }
      }
    }
  },
  setup(props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const {
      openAsyncConfirm, openAsyncAlert, openAsyncPopup, closeAsyncPopup
    } = useActions(['openAsyncConfirm', 'openAsyncAlert', 'openAsyncPopup', 'closeAsyncPopup'])
    const searchParams = reactive({
      vSearchField: props.popParams.vSearchField,
      vKeyword: props.popParams.vKeyword,
      vLabNoteCd: props.popParams.vLabNoteCd,
      vCodeType: props.popParams.vCodeType,
      vFlagRepresent: props.popParams.vFlagRepresent,
      vFlagBookPop: props.popParams.vFlagBookPop,
      vNoteType: props.popParams.vNoteType,
      vSiteType: props.popParams.vSiteType,
      vLabNoteCdTemp: props.popParams.vLabNoteCdTemp,
      vPlantCdTemp: props.popParams.vPlantCdTemp,
      nowPageNo: 1,
      vDefaultTab: '',
    })
    const sapSyncParams = reactive({
      vContCd: '',
      vPlantCd: '',
      vCodeType: props.popParams.vCodeType,
    })
    const mateList = ref(null)
    const applyList = ref(null)
    const codeList = ref(null)
    const popContent = ref(null)
    const popSelectFunc = ref(null)
    const popupParams = ref({})
    const closeFunc = ref({})

    const tabList = [
      { tabId: 'SIMILAR', tabNm: '기존처방' },
      { tabId: 'COUNTER', tabNm: '자사카운터' },
      { tabId: 'SAP', tabNm: 'SAP SYNC' },
    ]

    if (searchParams.vNoteType === 'MU' && searchParams.vFlagRepresent === 'N') {
      tabList.push({
        tabId: 'BASE', tabNm: '베이스처방 불러오기',
      })
    }

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const {
      page,
      list,
      selectLabNoteBookmarkList,
      selectLabNoteMatePlantCheck,
      selectLabNoteBookmarkApplyList,
      insertLabNoteCounterSAPInfo,
    } = useMaterialCommon()

    const init = async (isGetCode) => {
      if (isGetCode) {
        findCodeList(['LAB_NOTE_PLANT'])
      }

      await selectLabNoteBookmarkList(searchParams)

      if (isGetCode) {
        codeList.value = commonUtils.getCodeList(codeGroupMaps, 'LAB_NOTE_PLANT', 'U', null, null)
      }
    }

    const getSelectedTabEvent = (item) => {
      searchParams.vSearchField = item.tabId
      if (searchParams.vSearchField !== 'SAP') {
        searchParams.nowPageNo = 1
        init(false)
      }
    }

    const closeMateRatePop = () => {
      popContent.value = null
    }

    const onMateRatePop = (o) => {
      popContent.value = 'BookmarkMateRatePop'
      popupParams.value = {
        vLabNoteCd: o.vLabNoteCd,
        vContPkCd: o.vContPkCd,
        nVersion: o.nVersion,
        vLotCd: o.vLotCd,
      }
      closeFunc.value = closeMateRatePop

      // openAsyncPopup()
      //   .then(res => {
      //   })
      //   .catch(err => {
      //     console.log(err)
      //   })
      //   .finally(() => {
      //     popContent.value = null
      //   })
    }

    const onPlantCheck = async (o, t) => {
      if (o.vPlantCd === '') {
        apply(o)
        return
      }

      const message = t === 'BASE' ? '베이스 처방을 불러오시겠습니까?' : '기존 처방을 불러오시겠습니까?'
      const answer = await openAsyncConfirm({ message })
      if (!answer) {
        return
      }

      mateList.value = await selectLabNoteMatePlantCheck({
        vContPkCd: o.vContPkCd,
        nVersion: o.nVersion,
        vLotCd: o.vLotCd,
        vPlantCdTemp: searchParams.vPlantCdTemp,
      })

      if (mateList.value.length > 0) {
        const answer = await openAsyncConfirm({
          message:
            '해당 Plant에서 생산되지 않는 원료<br/>' + mateList.value.join(",") + '<br/>가 포함되어 있습니다. 적용하시겠니까?'
        })
        if (!answer) {
          return
        }
      }

      apply(o)
    }

    const apply = async (o) => {
      applyList.value = await selectLabNoteBookmarkApplyList({
        vSearchField: searchParams.vSearchField,
        vContPkCd: o.vContPkCd,
        nVersion: o.nVersion,
        vLotCd: o.vLotCd,
        vLabNoteCdTemp: searchParams.vLabNoteCdTemp,
        vPlantCdTemp: searchParams.vPlantCdTemp,
        vSiteType: searchParams.vSiteType,
      })

      context.emit('selectFuncMateAndGrp', applyList.value)
      closeAsyncPopup({ message: '닫기' })
    }

    const onSearch = (pg) => {
      if (searchParams.vSearchField !== 'SAP') {
        searchParams.nowPageNo = !isNaN(pg) ? pg : 1
        init(false)
      }
    }

    const onSapSync = async () => {
      const vContCd = sapSyncParams.vContCd
      if (sapSyncParams.vCodeType === 'HAL4') {
        if (!vContCd.startsWith('4') || vContCd.length < 7) {
          openAsyncAlert({ message: '올바른 내용물 코드가 아닙니다' })
          return
        }
      }
      else {
        if ((!vContCd.startsWith('3') && !vContCd.startsWith('J')) || vContCd.length < 7) {
          openAsyncAlert({ message: '올바른 내용물 코드가 아닙니다' })
          return
        }
      }

      sapSyncParams.vPlantCd = searchParams.vPlantCdTemp
      const res = await insertLabNoteCounterSAPInfo(sapSyncParams)

      if (res.vMessage) {
        openAsyncAlert({ message: res.vMessage })
      }
      else {
        openAsyncAlert({ message: '등록되었습니다.' })
      }
    }

    init(true)

    return {
      t,
      searchParams,
      sapSyncParams,
      codeGroupMaps,
      popContent,
      popSelectFunc,
      popupParams,
      closeFunc,
      tabList,
      page,
      list,
      codeList,
      getSelectedTabEvent,
      onMateRatePop,
      onPlantCheck,
      onSearch,
      onSapSync,
      closeAsyncPopup
    }
  }
}
</script>