<template>
  <div class="modal-content modal-content__width--950">
    <div class="modal-header">
      <div class="modal-title">플랜트 확장</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({message: ''})"></button>
    </div>
    <div class="modal-body">
      <div class="search-depart-table">
        <div class="search-depart-table__inner">
          <table class="ui-table__td--40">
            <colgroup>
              <col style="width:13rem">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr>
                <th>내용물명</th>
                <td>
                  <div class="font-weight__600 color-blue">
                    {{ popParams.vContNm }}
                    <template v-if="commonUtils.isNotEmpty(popParams.nContNum) && Number(popParams.nContNum) > 0">
                      외 {{ popParams.nContNum }}종
                    </template>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div class="myboard-table mt-15">
        <div class="myboard-table__inner">
          <table class="ui-table ui-table__th--border-radius--0 ui-table__td--40 text-center">
            <colgroup>
              <col style="width:5.65rem;">
              <col style="width:10rem;">
              <col style="width:auto">
              <col style="width:20rem;">
              <col style="width:20rem;">
            </colgroup>
            <thead>
              <tr>
                <th>
                  <ap-input-check
                    id="plant_extend_chkAll"
                    value="Y"
                    @click="fnPlantExtendChkAllEvent"
                  >
                  </ap-input-check>
                </th>
                <th>내용물코드</th>
                <th>내용물명</th>
                <th>플랜트 정보</th>
                <th>확장 플랜트</th>
              </tr>
            </thead>
            <tbody>
              <template v-if="contList && contList.length > 0">
                <tr v-for="(vo, idx) in contList" :key="'plant_extend_' + idx">
                  <td>
                    <ap-input-check
                      v-model:model="vo.isChecked"
                      value="Y"
                      :id="'plant_extend_' + idx"
                      @click="fnPlantExtendChkEvent"
                    >
                    </ap-input-check>
                  </td>
                  <td>{{ vo.vContCd }}</td>
                  <td>{{ vo.vContNm }}</td>
                  <td v-html="commonUtils.removeXSS(vo.vPlantInfo)"></td>
                  <td :id="'error_wrap_vPlantCd_' + idx" class="t-left">
                    <ap-selectbox
                      v-model:value="vo.vPlantCd"
                      :options="vo.plantList"
                      :input-class="['ui-select__width--full']"
                      codeKey="vPlantCd"
                      codeNmKey="vPlantNm"
                      @change="fnValidate('vPlantCd_' + idx, vo.vPlantCd)"
                    >
                    </ap-selectbox>
                    <span class="error-msg" :id="'error_msg_vPlantCd_' + idx"></span>
                  </td>
                </tr>
              </template>
              <template v-else>
                <tr>
                  <td colspan="5">
                    <div class="no-result">
                      {{ t('common.msg.no_data') }}
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>

      <div class="board-bottom">
        <div class="board-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button
              type="button"
              class="ui-button ui-button__bg--skyblue font-weight__300"
              @click="fnExpand()"
            >플랜트 확장</button>
            <button type="button" class="ui-button ui-button__bg--lightgray" @click="closeAsyncPopup({message: ''})">닫기</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, inject } from 'vue'
import { useRequestCommon } from '@/compositions/labcommon/useRequestCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'PlantExtendPop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  setup (props) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncAlert', 'closeAsyncPopup'])
    const contList = ref([])

    const {
      selectLabNoteContPlantInfoList,
      insertLabNotePlantExpansion,
    } = useRequestCommon()

    const fnPlantExtendChkAllEvent = (value) => {
      if (value === 'Y') {
        contList.value.forEach((item, idx) => {
          item.isChecked = 'Y'
          document.querySelector('#plant_extend_' + idx).checked = true
        })
      } else {
        contList.value.forEach((item, idx) => {
          item.isChecked = ''
          document.querySelector('#plant_extend_' + idx).checked = false
        })
      }
    }

    const fnPlantExtendChkEvent = () => {
      if (contList.value.filter(item => item.isChecked === 'Y').length === contList.value.length) {
        document.querySelector('#plant_extend_chkAll').checked = true
      } else {
        document.querySelector('#plant_extend_chkAll').checked = false
      }
    }

    const fnValidate = (key, value) => {
      let errorCnt = 0

      commonUtils.hideErrorMessage(key)
      if (commonUtils.isEmpty(value)) {
        commonUtils.showErrorMessage(key, '* 필수 입력')
        errorCnt++
      }

      if (errorCnt > 0) {
        return false
      }

      return true
    }

    const fnExpand = async () => {
      const checkedLen = contList.value.filter(item => item.isChecked === 'Y').length
      if (checkedLen === 0) {
        openAsyncAlert({ message: '확장 대상을 선택해 주세요.'})
        return
      }

      let isOk = true
      contList.value.forEach((item, idx) => {
        if (item.isChecked === 'Y' && !fnValidate('vPlantCd_' + idx, item.vPlantCd)) {
          isOk = false
        }
      })

      if (!isOk) {
        openAsyncAlert({ message: '필수 입력 사항을 확인해 주세요.'})
        return
      }

      const payload = {
        ...props.popParams,
        extendContList: contList.value.filter(item => item.isChecked === 'Y')
      }
      const result = await insertLabNotePlantExpansion(payload)

      if (result) {
        let message = '플랜트가 확장되었습니다.'
        const copyLen = result.copyList ? result.copyList.length : 0
        const copyFailLen = result.copyFailList ? result.copyFailList.length : 0

        if (copyLen > 0) {
          message += '<br>* ' + result.copyList.join(', ') + '는 기존처방을 자동입력 하였습니다.<br>'
        }

        if (copyFailLen > 0) {
          message += '<br>* ' + result.copyFailList.join(', ') + '는 기존처방 미존재로 자동입력 진행되지 않습니다.'
        }

        await openAsyncAlert({ message: message })
        closeAsyncPopup({ message: '' })
      }
    }

    const init = async () => {
      const payload = {
        vLabNoteCd: props.popParams.vLabNoteCd,
        vCodeType: props.popParams.vCodeType
      }

      const result = await selectLabNoteContPlantInfoList(payload)

      if (result) {
        contList.value = [ ...result ]
        contList.value.forEach(item => {
          item.isChecked = 'Y'
        })

        fnPlantExtendChkEvent()
      }
    }

    init()

    return {
      t,
      commonUtils,
      contList,
      fnPlantExtendChkAllEvent,
      fnPlantExtendChkEvent,
      fnValidate,
      fnExpand,
      closeAsyncPopup,
    }
  }
}

</script>