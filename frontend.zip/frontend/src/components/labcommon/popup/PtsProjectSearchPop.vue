<template>
  <div class="modal-content" style="width: 95rem;">
    <div class="modal-header">
      <div class="modal-title">예산검색</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({message: ''})"></button>
    </div>
    <div class="modal-body">
      <div class="board-top">
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--70">수행년도</dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="search-form">
                <div class="search-form__inner">
                  <ap-year-picker
                    v-model:date="searchParams.vYear"
                    :disabled="yearAll === 'Y'"
                  >
                  </ap-year-picker>
                  <ap-input-check
                    id="pts_year_all"
                    v-model:model="yearAll"
                    value="Y"
                    @click="setYear"
                    label="전체"
                  >
                  </ap-input-check>
                </div>
              </div>
            </dd>
          </dl>
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--70">수행부서</dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="search-form">
                <div class="search-form__inner">
                  <DeptTree
                    v-model:deptcd="searchParams.vDeptCd"
                    udeptcd="10011"
                  >
                  </DeptTree>
                </div>
              </div>
            </dd>
          </dl>
        </div>
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--70">검색</dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="search-form">
                <div class="search-form__inner">
                  <ap-input
                    v-model:value="searchParams.vKeyword"
                    input-class="ui-input ui-input__width--full"
                    placeholder="예산코드 or 과제명 or P/L"
                    @keypress-enter="fnSearch(1)"
                  >
                  </ap-input>
                  <button 
                    type="button"
                    class="button-search"
                    @click="fnSearch(1)"
                  >
                    검색
                  </button>
                </div>
              </div>
            </dd>
          </dl>
        </div>
      </div>

      <div class="ui-table__wrap">
        <table class="ui-table text-center ui-table__td--40">
          <colgroup>
            <col style="width:6rem;">
            <col style="width:11%;">
            <col style="width:10%;">
            <col style="width:auto;">
            <col style="width:9%;">
            <col style="width:10%;">
            <col style="width:11%;">
            <col style="width:5rem">
          </colgroup>
          <thead>
            <tr>
              <th></th>
              <th>부서</th>
              <th>과제 유형</th>
              <th>과제명</th>
              <th>P/L</th>
              <th>수행년도</th>
              <th>상태</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <template v-if="list && list.length > 0">
              <tr v-for="vo in list" :key="'pts_' + vo.vPjtCd">
                <td>
                  <ap-input-check
                    v-model:model="vo.isChecked"
                    :id="'pts_' + vo.vPjtCd"
                    value="Y"
                  >
                  </ap-input-check>
                </td>
                <td>{{ vo.vDeptNm }}</td>
                <td>{{ vo.vPjtType2Nm }}</td>
                <td class="t-left">[{{ vo.vRpmsCd }}] {{ vo.vPjtNm }}</td>
                <td>{{ vo.vUserNm }}</td>
                <td>{{ vo.vSYear }} ~ {{ vo.vEYear }}</td>
                <td>{{ vo.vStatusNm }}</td>
                <td>
                  <div class="ui-buttons">
                    <button
                      type="button"
                      class="ui-button ui-button__width--40
                            ui-button__height--23 
                            ui-button__border--blue
                            ui-button__radius--2"
                      @click="goPjtDetail(vo.vPjtCd)"
                    >상세</button>
                  </div>
                </td>
              </tr>
            </template>
            <template v-else>
              <tr>
                <td colspan="8">
                  <div class="no-result">
                    {{ t('common.msg.no_data') }}
                  </div>
                </td>
              </tr>
            </template>
          </tbody>
        </table>
      </div>

      <div class="board-bottom">
        <div class="board-bottom__inner board-bottom__with--button">
          <Pagination
            :page-info="page"
            @click="fnSearch"
          >
          </Pagination>
        </div>

        <div class="ui-buttons ml-auto ui-buttons__right">
          <button
            type="button" 
            class="ui-button ui-button__bg--skyblue font-weight__300"
            @click="fnApply"
          >
            적용
          </button>
          <button type="button" class="ui-button ui-button__bg--lightgray" @click="closeAsyncPopup({ message: '닫기'})">닫기</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, reactive, inject, ref, getCurrentInstance } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'PtsProjectSearchPop',
  components: {
    DeptTree: defineAsyncComponent(() => import('@/components/comm/DeptTree.vue')),
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue'))
  },
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  emits: ['selectFunc'],
  setup (props, context) {
    const app = getCurrentInstance();
    const tiumUrl = app.appContext.config.globalProperties.tiumUrl

    const t = inject('t')
    const yearAll = ref('')
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncAlert', 'closeAsyncPopup'])

    const {
      page,
      list,
      selectPtsProjectList,
    } = useLabCommon()

    const searchParams = reactive({
      vKeyword: '',
      vYear: '',
      vDeptCd: '10011',
      nowPageNo: 1
    })

    const fnSearch = (pg) => {
      if (!pg) {
        pg = 1
      }

      searchParams.nowPageNo = pg
      selectPtsProjectList(searchParams)
    }

    const fnApply = () => {
      const applyList = list.value.filter(vo => vo.isChecked === 'Y')

      if (!applyList || applyList.length === 0) {
        openAsyncAlert({message: '적용 대상을 선택해 주세요.'})
        return
      }

      context.emit('selectFunc', applyList)
      closeAsyncPopup({message: ''})
    }

    const setYear = () => {
      if (yearAll.value === 'Y') {
        searchParams.vYear = ''
      }
    }

    const goPjtDetail = (vPjtCd) => {
      const targetUrl = `${tiumUrl}/pts/project2020/pts_project_link_view.do?i_sPjtCd=${vPjtCd}`

      window.open(targetUrl, 'pjt_view_pop')
    }

    const init = () => {
      if (commonUtils.isNotEmpty(props.popParams.vKeyword)) {
        searchParams.vKeyword = props.popParams.vKeyword
      }

      fnSearch(1)
    }

    init()

    return {
      t,
      yearAll,
      searchParams,
      page,
      list,
      fnSearch,
      fnApply,
      setYear,
      goPjtDetail,
      closeAsyncPopup
    }
  }
}
</script>

