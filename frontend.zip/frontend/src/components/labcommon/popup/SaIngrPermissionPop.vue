<template>
  <div class="modal-content modal-content__width--101">
    <div class="modal-header modal-header__mb--10">
      <div class="modal-title">의약외품 전성분 미리보기</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({ message: '닫기' })"></button>
    </div>
    <div class="modal-body">
      <div class="myboard-table">
        <div class="myboard-table__inner">
          <div class="modal-sub-title" style="color: red;">* 등록된 원료DB가 없는 경우 한글허가명/배합목적이 출력되지 않습니다.</div>

          <table class="ui-table ui-table__th--border-radius--0 ui-table__td--40 text-center">
            <colgroup>
              <col style="width:10%">
              <col style="width:30%">
              <col style="width:auto">
              <col style="width:20%">
              <col style="width:10%">
            </colgroup>
            <thead>
              <tr>
                <th>원료코드</th>
                <th>원료명</th>
                <th>한글허가명</th>
                <th>배합목적</th>
                <th>함량</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(bom, index) in info.bomList" :key="index">
                <td>{{ bom.rawCd }}</td>
                <td class="tit">{{ searchParams.bomList.find(param => param.rawCd === bom.rawCd)?.rawNm }}</td>
                <td>
                  <template v-if="bom.vMatNum === '4'">향료</template>
                  <template v-else-if="info.permissionList.filter(per => per.vMatrCd === bom.rawCd).length > 0">
                    <ap-selectbox v-model:value="bom.permission" codeKey="vPermissionKey" codeNmKey="vPermissionTxt"
                      :options="info.permissionList.filter(per => per.vMatrCd === bom.rawCd)"></ap-selectbox>
                  </template>
                </td>
                <td>
                  <ap-selectbox v-if="info.permissionList.filter(per => per.vMatrCd === bom.rawCd).length > 0 &&
                    info.codeList.filter(code => code.vMatrCd === bom.rawCd).length > 0 &&
                    bom.vMatNum !== '4'" v-model:value="bom.code" codeKey="vCmbCode" codeNmKey="vCmbCodeNm"
                    :options="info.codeList.filter(code => code.vMatrCd === bom.rawCd)"></ap-selectbox>
                </td>
                <td>{{ searchParams.bomList.find(param => param.rawCd === bom.rawCd)?.rawPer }}</td>
              </tr>
              <template v-if="info.bomList.length === 0">
                <tr>
                  <td colspan="5">
                    <div class="no-result">
                      {{ t('common.msg.no_data') }}
                    </div>
                  </td>
                </tr>
              </template>
              <template v-else>
                <tr>
                  <td colspan="4">합계</td>
                  <td>{{ searchParams.perSum }}</td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>

      <div class="board-bottom">
        <div class="board-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--skyblue font-weight__300" @click="onIngrApply">전성분
              적용</button>
          </div>
        </div>
      </div>

      <div class="modal-sub-title">전성분</div>
      <ap-text-area v-model:value="searchParams.vZtext"></ap-text-area>
    </div>
  </div>
</template>

<script>
import { reactive, ref, inject } from 'vue'
import { useMaterialCommon } from '@/compositions/labcommon/useMaterialCommon'
import { useActions } from 'vuex-composition-helpers'
import ApSelectbox from '../../comm/ApSelectbox.vue'

export default {
  components: { ApSelectbox },
  name: 'SaIngrPermissionPop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          bomList: [],
        }
      }
    }
  },
  setup(props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const {
      openAsyncConfirm, openAsyncAlert, openAsyncPopup, closeAsyncPopup
    } = useActions(['openAsyncConfirm', 'openAsyncAlert', 'openAsyncPopup', 'closeAsyncPopup'])
    const info = ref({
      bomList: [],
      selectSaIngrPermissionList: [],
      codeList: [],
    })
    const searchParams = reactive({
      bomList: props.popParams.bomList,
      perSum: '',
      vZtext: '',
    })

    const {
      selectSaIngrPermissionList,
    } = useMaterialCommon()

    const init = async () => {
      let perSum = 0
      for (let i = 0; i < props.popParams.bomList.length; i++) {
        perSum += Number(props.popParams.bomList[i].rawPer)
      }
      searchParams.perSum = perSum

      info.value = await selectSaIngrPermissionList(searchParams)

      info.value.permissionList = info.value.permissionList.map(per => {
        return {
          ...per,
          vPermissionKey: `${per.vPermissionKr}_${per.vStandard}`,
          vPermissionTxt: `${per.vPermissionKr} (${per.vStandard})`,
        }
      })

      const newCodeList = []
      info.value.codeList.map(code => {
        if (code.vCmbCode1)
          newCodeList.push({
            vMatrCd: code.vMatrCd,
            vCmbCode: code.vCmbCode1,
            vCmbCodeNm: code.vCmbCode1Nm,
          })

        if (code.vCmbCode2)
          newCodeList.push({
            vMatrCd: code.vMatrCd,
            vCmbCode: code.vCmbCode2,
            vCmbCodeNm: code.vCmbCode2Nm,
          })
      })
      info.value.codeList = newCodeList
    }

    init()

    const onIngrApply = () => {
      searchParams.vZtext = ''

      let cmb01list = []
      let cmb02list = []
      let cmb03list = []
      let cmb04list = []
      let vZtext = ''

      info.value.bomList.filter(bom => bom.permission && bom.code).map(bom => {
        const permission = getPermission(bom.permission)
        if (bom.code === 'MP01') {
          cmb01list.push(permission)
        }
        else if (bom.code === 'MP02') {
          if (bom.vMatNum === '4') {
            cmb02list.push('향료')
          }
          cmb02list.push(permission)
        }
        else if (bom.code === 'MP03') {
          cmb03list.push(permission)
        }
        else if (bom.code === 'MP04') {
          cmb04list.push(permission)
        }
      })

      if (cmb01list.length > 0) {
        cmb01list.sort();
        vZtext = '[유효성분] ' + cmb01list.join(', ') + '\n';
      }
      if (cmb02list.length > 0) {
        cmb02list.sort();
        vZtext += '[기타 첨가제] ' + cmb02list.join(', ') + '\n';
      }
      if (cmb03list.length > 0) {
        cmb03list.sort();
        vZtext += '[보존제] ' + cmb03list.join(', ') + '\n';
      }
      if (cmb04list.length > 0) {
        cmb04list.sort();
        vZtext += '[타르색소] ' + cmb04list.join(', ') + '\n';
      }

      if (vZtext) {
        searchParams.vZtext = vZtext
      }
    }

    const getPermission = (o) => {
      return o.substring(0, o.indexOf('_'))
    }

    return {
      t,
      info,
      searchParams,
      onIngrApply,
      closeAsyncPopup
    }
  }
}
</script>