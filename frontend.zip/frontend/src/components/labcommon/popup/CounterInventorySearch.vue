<template>
  <section class="search-bar p-0 mt-15">
    <h2 class="for-a11y">검색</h2>
    <div class="search-bar__left">
      <div class="search-bar__row">
        <dl class="search-bar__item search-bar__item--width-100">
          <dt class="search-bar__key">검색</dt>
          <dd class="search-bar__val search-bar__val--flex">
            <div class="search-form">
              <div class="search-form__inner">
                <ap-input
                  v-model:value="params.vKeyword"
                  placeholder="SP코드 or 인벤토리명"
                  @keypress-enter="fnSearch(1)"
                >
                </ap-input>
                <button type="button" class="button-search" @click="fnSearch(1)">검색</button>
              </div>
            </div>
          </dd>
        </dl>
      </div>
    </div>
  </section>

  <div class="myboard-table mt-15">
    <div class="myboard-table__inner">
      <table class="ui-table ui-table__th--border-radius--0 ui-table__td--40 text-center">
        <colgroup>
          <col style="width: 15rem">
          <col style="width: auto">
          <col style="width: 10rem">
          <col style="width: 10rem">
        </colgroup>
        <thead>
          <tr>
            <th>SP코드</th>
            <th>[인벤토리명] 과제명(Ver , Lot)</th>
            <th>상태</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <template v-if="list.length > 0">
            <tr v-for="vo in list" :key="'counter_inven_' + vo.vInvenJoinCd">
              <td>{{ vo.vInvenJoinPjtCd }}</td>
              <td class="t-left">
                [ {{ vo.vSubmitInvenNm }} ]<br>
                {{ vo.vContNm }} ({{ vo.vVersionNm }}, {{ vo.vLotNm }})
              </td>
              <td>{{ vo.vStatusNm }}</td>
              <td>
                <button type="button"
                  :class="['ui-button',
                          'ui-button__width--40',
                          'ui-button__height--23', 
                          'ui-button__border--blue', 
                          'ui-button__radius--2']"
                  @click="fnInventorySelect(vo)"
                >선택</button>
              </td>
            </tr>
          </template>
          <template v-else>
            <tr>
              <td colspan="4">
                <div class="no-result">
                  {{ t('common.msg.no_data') }}
                </div>
              </td>
            </tr>
          </template>
        </tbody>
      </table>
    </div>
  </div>

  <div class="board-bottom board-bottom__with--button">
    <div class="board-bottom__inner">
      <Pagination
        :page-info="page"
        @click="fnSearch"
      >
      </Pagination>
      <div class="ui-buttons ui-buttons__right">
        <button type="button" class="ui-button ui-button__bg--lightgray" @click="closeAsyncPopup({ message: '닫기'})">닫기</button>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, inject, defineAsyncComponent } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useSkincareCommon } from '@/compositions/skincare/useSkincareCommon'
import { useMakeupCommon } from '@/compositions/makeup/useMakeupCommon'
import { useHbdCommon } from '@/compositions/hbd/useHbdCommon'
import { useQdrugCommon } from '@/compositions/qdrug/useQdrugCommon'

export default {
  name: 'CounterInventorySearch',
  props: {
    searchParams: {
      type: Object,
      default: () => {
        return {
          vNoteType: '',
          vKeyword: '',
          vPlantCd: ''
        }
      }
    }
  },
  
  components: {
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
  },
  emits: ['applyFunc'],
  setup (props, context) {
    const t = inject('t')
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])
    const params = ref({
      vKeyword: props.searchParams.vKeyword,
      nowPageNo: 1
    })

    const page = ref({})
    const list = ref([])

    const {
      selectLabNoteSKinInventoryList,
      selectSkinLabNoteMatePlantCheckList,
    } = useSkincareCommon()

    const {
      selectLabNoteMakeupInventoryList,
      selectMakeupLabNoteMatePlantCheckList,
    } = useMakeupCommon()

    const {
      selectLabNoteHbdInventoryList,
      selectHbdLabNoteMatePlantCheckList,
    } = useHbdCommon()

    const {
      selectLabNoteQdrugInventoryList,
      selectQdrugLabNoteMatePlantCheckList,
    } = useQdrugCommon()

    const fnSearch = async (pg) => {
      if (!pg) {
        pg = 1
      }

      params.value.nowPageNo = pg

      let result = null
      if (props.searchParams.vNoteType === 'SC') {
        result = await selectLabNoteSKinInventoryList(params.value)
      } else if (props.searchParams.vNoteType === 'MU') {
        result = await selectLabNoteMakeupInventoryList(params.value)
      } else if (props.searchParams.vNoteType === 'HBO') {
        result = await selectLabNoteHbdInventoryList(params.value)
      } else if (props.searchParams.vNoteType === 'SA') {
        result = await selectLabNoteQdrugInventoryList(params.value)
      }

      if (result) {
        page.value = result.page
        list.value = result.list
      } else {
        page.value = {}
        list.value = []
      }
    }

    const fnInventorySelect = async (vo) => {
      let result = null
      vo.vPlantCd = props.searchParams.vPlantCd

      if (props.searchParams.vNoteType === 'SC') {
        result = await selectSkinLabNoteMatePlantCheckList(vo)
      } else if (props.searchParams.vNoteType === 'MU') {
        result = await selectMakeupLabNoteMatePlantCheckList(vo)
      } else if (props.searchParams.vNoteType === 'HBO') {
        result = await selectHbdLabNoteMatePlantCheckList(vo)
      } else if (props.searchParams.vNoteType === 'SA') {
        result = await selectQdrugLabNoteMatePlantCheckList(vo)
      }

      if (result && result.length > 0) {
        const arrMateCd = []

        const mateList = result.filter(item => item.vFlagExistYn !== 'Y')
        if (mateList && mateList.length > 0) {
          mateList.forEach(mate => {
            arrMateCd.push(mate.vMateCd)
          })
        }

        if (arrMateCd.length > 0) {
          const message = '해당 Plant에서 생상되지 않는 원료 ' + arrMateCd.join(', ') + '가 포함되어 있습니다. 적용하시겠습니까?'
          if (await openAsyncConfirm({ message: message })) {
            context.emit('applyFunc', vo)
            closeAsyncPopup({ message: '닫기' })
          }
        } else {
          context.emit('applyFunc', vo)
          closeAsyncPopup({ message: '닫기' })
        }
      } else {
        context.emit('applyFunc', vo)
        closeAsyncPopup({ message: '닫기' })
      }
    }

    const init = () => {
      fnSearch(1)
    }

    init()

    return {
      t,
      page,
      list,
      params,
      fnSearch,
      fnInventorySelect,
      closeAsyncPopup,
    }
  }
}
</script>