<template>
  <div class="modal-content modal-content__width--auto">
    <div class="modal-header modal-header__mb--10">
      <div class="modal-title">{{ popParams.vFlagStandard === 'Y' ? '표준품' : '일반' }} 라벨 출력</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({ message: '' })"></button>
    </div>
    <div class="modal-body">

      <div id="qrPrint" class="make-qr">
        <div class="make-qr__inner">
          <div class="make-qr__left">
            <div class="make-qr__image">
              <ap-qr-code :value="qrOptions.qrValue" :color="qrOptions.qrColor" :type="qrOptions.qrType"
                :scale="qrOptions.qrScale"></ap-qr-code>
            </div>
            <div class="make-qr__code"><span style="font-weight: 600;">{{ qrInfo?.vContCd }}</span>
              <br />{{ qrInfo?.vLotNmSimple }} {{ qrInfo?.vLotNmSimple }}
            </div>
            <div class="make-qr__tags">
              <div class="make-qr__tag make-qr__tag--blue" :style="'color:' + qrOptions.qrColor.dark">
                {{ qrInfo?.vLabelNm }}
              </div>
            </div>
          </div>
          <div class="make-qr__right">
            <div class="make-qr__right--top">
              <div class="make-qr__tags">
                <div class="make-qr__tag make-qr__tag--blue" :style="'color:' + qrOptions.qrColor.dark">
                  {{ qrInfo?.vLabelNm }}
                </div>
              </div>
              <div class="make-qr__code">{{ qrInfo?.vBrdNm }}</div>
            </div>
            <div class="make-qr__name" style="text-align: left;" :style="'color:' + qrOptions.qrColor.dark">
              {{ qrInfo?.vContNm }}
            </div>
            <div class="make-qr__detail">
              <div class="make-qr__image">
                <ap-qr-code :value="qrOptions.qrValue" :color="qrOptions.qrColor" :type="qrOptions.qrType"
                  :scale="qrOptions.qrScaleBig"></ap-qr-code>
              </div>
              <div class="make-qr__detail--right">
                <div class="make-qr__info">
                  <span class="make-qr__num">{{ qrInfo?.vContCd }}</span> {{ qrInfo?.vVersionNm }} {{ qrInfo?.vLotNm }}
                </div>
                <div class="make-qr__who">{{ qrInfo?.vDeptNm }} {{ qrInfo?.vUsernm }}</div>
                <div class="make-qr__date">출력일자: {{ qrInfo?.vToday }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="board-bottom board-bottom__with--button">
        <div class="board-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--skyblue font-weight__300" @click="onPrint">인쇄</button>
            <button type="button" class="ui-button ui-button__bg--lightgray"
              @click="closeAsyncPopup({ message: '닫기' })">닫기</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { reactive, ref, inject } from 'vue'
import { useMaterialCommon } from '@/compositions/labcommon/useMaterialCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'LotQrCodePop',
  components: {
  },
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vLotCd: '',
          vFlagStandard: '',
        }
      }
    }
  },
  setup(props, context) {
    const t = inject('t')
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])
    const searchParams = reactive({
      vLotCd: props.popParams.vLotCd,
      vFlagStandard: props.popParams.vFlagStandard,
    })
    const qrOptions = reactive({
      qrValue: '',
      qrColor: {},
      qrType: 'image/png',
      qrScale: 2,
      qrScaleBig: 2.5,
    })
    const qrInfo = ref(null)

    const {
      selectQrCodeElabNoteInfo,
    } = useMaterialCommon()

    const init = async () => {
      const response = await selectQrCodeElabNoteInfo(searchParams)

      qrInfo.value = response.qrInfoVO
      qrOptions.qrValue = qrInfo.value.vQrDivCode + '//Y//NOTE_LOT//' + qrInfo.value.vLotCd + '//' + qrInfo.value.vLabNoteCd
      qrOptions.qrColor.dark = qrInfo.value.vQrColor === 'BLUE' ? '#1764e7' : '#000000'
    }

    const onPrint = () => {
      const html = document.querySelector('html');
      const printContents = document.querySelector('.make-qr').innerHTML;
      const printDiv = document.createElement("DIV");
      printDiv.className = "print-div";

      html.appendChild(printDiv);
      printDiv.innerHTML = printContents;
      document.body.style.display = 'none';
      window.print();
      document.body.style.display = 'block';
      printDiv.style.display = 'none';

      closeAsyncPopup({ message: '닫기' })
    }

    init()

    return {
      t,
      qrOptions,
      qrInfo,
      onPrint,
      closeAsyncPopup,
    }
  }
}
</script>