<template>
  <template v-if="mateVo.vRecType === 'GRP'">
    <td class="anypjt-grid-td td-num">
      <a href="#" class="apg-rownum-text" @click.prevent="fnToggleRowSelect($event, rowIndex)"></a>
    </td>
    <td class="anypjt-grid-td border-right__deepgray" :colspan="columnsForzenLeft.length - 1">
      <div class="tr-group__wrap anypjt-grid-cell apg-material-code-wrap" :data-column-id="'vMateCd'"
        :data-row-index="rowIndex" :class="{
          'apg-material-group-folder':
            mateVo.vRecType === 'GRP' && mateVo.vGrpCd !== '',
        }">
        <button type="button" class="tr-group__button tr-group__button--plus" :class="[
          mateVo.vFlagGrpHide === 'Y'
            ? 'tr-group__button--plus'
            : 'tr-group__button--minus',
        ]" @click.prevent="fnToggleGroupOpen($event, rowIndex)"></button>
        <span class="tr-group__text">{{ mateVo.vGrpNm }}</span>
      </div>
    </td>
  </template>
  <template v-else v-for="(columnVo, colIndex) in columnsForzenLeft" :key="columnVo.code">
    <td v-if="columnVo.code === 'rowNum'" class="anypjt-grid-td td-num">
      <a href="#" class="apg-rownum-text" @click.prevent="fnToggleRowSelect($event, rowIndex)">
        {{ mateVo.nMateNum }}
      </a>
    </td>
    <td v-else-if="columnVo.code === 'vMateCd'" class="anypjt-grid-td">
      <div class="material-code__text anypjt-grid-cell apg-text-left" :data-column-id="'vMateCd'"
        :data-row-index="rowIndex" :data-v-mate-pk-cd="mateVo.vMatePkCd" :data-is-row-add="mateVo.isRowAdd"
        :class="{ 'apg-material-group-code': mateVo.vRecType === 'MATE' && mateVo.vGrpCd, }"
        style="display: -webkit-flex;">
        <template v-if="mateVo[columnVo.code]">
          <div class="material-code__text"
            :style="mateVo.vFlagExistsMate === 'N' || mateVo.vFlagUsableMate === 'N' ? 'color: #ff3434' : ''">
            <template v-if="mateVo.vParentMatePkCd">&nbsp;&nbsp;&nbsp;</template>
            {{ mateVo[columnVo.code] }}
          </div>
          <template v-if="mateVo.vFlagLabHal4Mate === 'Y' || mateVo.vFlagLabHal4Mate === 'EHM'">
            <div style="margin-left: auto; font-size: 12px;">
              <template v-if="mateVo.vFlagLabHal4Mate === 'Y'">
                <a href="javascript:void(0)" class="mate-list__link" style="margin-left: 38px;"
                  @click="onDetailHal4Pop(mateVo)">[상세]</a>
              </template>
            </div>
            <div style="margin-left: inherit;">
              <div style="width: 14px; position: relative; font-size: 12px;">
                <a href="javascript:void(0)" class="mate-list__link" @click="onSearchSubMateList(mateVo)">
                  {{ subList.isOpen ? '[▲]' : '[▼]' }}
                </a>
              </div>
            </div>
          </template>
        </template>
        <template v-if="!mateVo[columnVo.code] && mateVo.vMateTempCd">
          <div class="material-left">
            <div class="material-tags">
              <span class="material-tag material-tag__blue">임시코드</span>
            </div>
            <div class="material-name">{{ mateVo.vMateTempCd }}</div>
          </div>
        </template>
      </div>
    </td>
    <td v-else-if="columnVo.code === 'vMateNm'" class="anypjt-grid-td">
      <!-- [s] 원료명 -->
      <div class="material-wrap anypjt-grid-cell" :data-column-id="columnVo.code" :data-row-index="rowIndex">
        <div class="material-left">
          <div v-if="mateVo.mateIssue && mateVo.mateIssue.length > 0" class="material-tags">
            <span v-for="(issueVo, index) in mateVo.mateIssue" :key="index" class="material-tag"
              :class="issueVo.className">
              <template v-if="issueVo.issueNm === '구성성분 없음'">
                <a href="javascript:void(0)" style="color: #bda874; text-decoration: none;"
                  @click="onRefreshMatnr(mateVo)">{{ issueVo.issueNm }}</a>
              </template>
              <template v-else>{{ issueVo.issueNm }}</template>
            </span>
          </div>
          <div class="material-name" :style="mateVo.vFlagNotIngrYn === 'Y' && vLand1 === 'UN' ? 'color: #ff3434' : ''">
            <span style="cursor: pointer;" @click="onMateNmPop(mateVo)">{{ mateVo[columnVo.code] }}</span>
            <button v-if="mateVo.vMatePkCd.indexOf('add_mate_pk_cd') < 0 &&
              (mateVo.vFlagGlbBanMate === 'Y' || mateVo.vFlagGlbLimitMate === 'Y' || mateVo.vFlagTcodeMate === 'Y')"
              class="icon icon-info" :class="mateVo.vFlagMateCheck === 'Y' ? 'icon-info__green' : 'icon-info__red'"
              @click="onProblemHisPop(mateVo.vMateCd)"></button>
          </div>
        </div>
        <div style="margin-left: auto; font-size: 12px;">
          <a v-if="(mateVo.vMateDbTypeCd === 'LAB_CONT' || mateVo.vMateDbTypeCd === 'LAB_HAL4') &&
            mateVo.vMateDbMstCd && mateVo.vMateDbMstCd !== '' &&
            mateVo.vMatePkCd && mateVo.vMatePkCd !== '' && mateVo.vMatePkCd.indexOf('add_mate_pk_cd') < 0"
            href="javascript:void(0)" style="color: #545454; text-decoration: none;" @click="onHal4LotSetPop(mateVo)">
            {{ getMateDbLotInfoTxt(mateVo.vMatePkCd) || '[LOT 설정]' }}</a>
        </div>
        <div class="material-right" style="margin-left: inherit;">
          <div class="matarial-write__button-wrap" :class="[mateVo.flagMemoOpen === 'Y' ? 'is-active' : '']">
            <button v-if="mateVo.vMatePkCd && mateVo.vMatePkCd.indexOf('tmp_mate_pk_cd_') < 0" type="button"
              class="material-write__button"
              :class="[mateVo.vRamaMemoTxt !== undefined && mateVo.vRamaMemoTxt !== '' ? 'is-inputed' : '']"
              @click.prevent="fnMateMemoPopup($event, rowIndex)"></button>
          </div>
        </div>
      </div>
      <!-- [e] 원료명 -->
    </td>
    <td v-else class="anypjt-grid-td"
      :class="(colIndex + 1) === columnsForzenLeft.length ? 'border-right__deepgray' : ''">
      <div class="anypjt-grid-cell" :data-column-id="columnVo.code" :data-row-index="rowIndex" style="font-size: 12px;">
        <template v-if="columnVo.code === 'nReqRate'">
          {{ mateVo.vFlagTo100 === 'Y' ? 'To-100' : mateVo.nReqRate }}
        </template>
        <template v-else-if="columnVo.code === 'vMaxMixVer2'">
          <a href="javascript:void(0)"
            style="display: inline-block; position: relative; font-size: 12px; text-decoration: none;"
            :style="mateVo.rowSelectYn === 'Y' ? 'color: #ffffff;' : 'color: #545454;'" @click="onMaxMixPop(mateVo)">
            {{ mateVo.vMaxMixVer2 }}
          </a>
        </template>
        <template v-else>
          {{ mateVo[columnVo.code] }}
        </template>
      </div>
    </td>
  </template>
</template>

<script>
import { getCurrentInstance, reactive } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useStore } from 'vuex'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'AllLabNoteMaterialBodyLeft',
  props: {
    rowIndex: {
      type: Number,
      default: 0,
    },
    mateVo: {
      type: Object,
      default: () => {
        return {}
      },
    },
    lotList: {
      type: Array,
      default: () => {
        return []
      },
    },
    columnsForzenLeft: {
      type: Array,
      default: () => {
        return []
      },
    },
    materialIssueCodes: {
      type: Array,
      default: () => {
        return []
      },
    },
    vLabNoteCd: {
      type: String,
      default: null,
    },
    vLand1: {
      type: String,
      default: null,
    },
    vPlantCd: {
      type: String,
      default: null,
    },
    nVersion: {
      type: Number,
      default: 0,
    },
  },
  emits: [
    'fnToggleRowSelect',
    'fnMateMemoPopup',
    'fnToggleGroupOpen',
    'fnSearchRowMate',
    'onProblemHisPop',
    'onHal4LotSetPop',
    'onSearchSubMateList',
    'onMaxMixPop',
    'onTabClick',
  ],
  setup(props, context) {
    const { openAsyncConfirm, openAsyncAlert } = useActions(['openAsyncConfirm', 'openAsyncAlert'])
    const store = useStore()
    const noteType = store.getters.getNoteType()
    const noteTypeNm = store.getters.getNoteTypeNm()
    const app = getCurrentInstance()
    const tiumUrl = app.appContext.config.globalProperties.tiumUrl
    const subList = reactive({
      isOpen: false,
    })

    const { updateRefreshMatnr } = useLabCommon()

    const fnToggleRowSelect = ($event, rowIndex) => {
      context.emit('fnToggleRowSelect', $event, rowIndex)
    }

    const fnMateMemoPopup = ($event, rowIndex) => {
      context.emit('fnMateMemoPopup', $event, rowIndex)
    }

    const fnToggleGroupOpen = ($event, rowIndex) => {
      context.emit('fnToggleGroupOpen', $event, rowIndex)
    }

    const fnSearchRowMate = ($event, rowIndex) => {
      context.emit('fnSearchRowMate', $event, rowIndex)
    }

    const onProblemHisPop = (vMateCd) => {
      context.emit('onProblemHisPop', vMateCd)
    }

    const onHal4LotSetPop = (o) => {
      context.emit('onHal4LotSetPop', o)
    }

    const onDetailHal4Pop = (o) => {
      if (!o.vMateDbMstCd) {
        openAsyncAlert({ message: '실험노트에 존재 하지 않는 코드입니다.' })
        return
      }

      const hal4Pop = `/${noteTypeNm}/all-lab-note-half-material?vLabNoteCd=${o.vMateLabNoteCd}&vFlagRecentNotes=N`
      window.open(hal4Pop, 'lab_note_experiment_view_hal4_pop', 'width=1550, height=900, top=1')
    }

    const onSearchSubMateList = (o) => {
      subList.isOpen = !subList.isOpen

      context.emit('onSearchSubMateList', o)
    }

    const onMaxMixPop = (o) => {
      context.emit('onMaxMixPop', o)
    }

    const getCheckMu4Mate = (o) => {
      return noteType === 'MU' && (o.startsWith('4') || o.startsWith('[4'))
    }

    const onMateNmPop = (o) => {
      if (!o.vMaterialCd) {
        openAsyncAlert({ message: '해당 원료정보를 불러 올 수 없습니다.' })
        return
      }

      const tiumPop = tiumUrl + '/zm/mi/zm_mi_material_pool_view.do?i_sMaterialCd=' + o.vMaterialCd
      window.open(tiumPop, 'material_pool_view_pop', '1200, 600, 1')
    }

    const onRefreshMatnr = async (o) => {
      let message = '<span style=\"font-weight: bolder;\">[주의]</span> <span style=\"color: red; font-weight: bolder;\">Zplm34e 구성성분이 없는 원료</span>입니다'
      message += '<br/>BOM 임시전송/BOM승인 전에 반드시 <span style=\"color: red; font-weight: bolder;\">구성성분 등록</span>해주세요.'
      message += '<br/><br/>이미 등록하셨다면 \"구성성분 없음 태그해제\" 버튼을 클릭해 주세요 <br/>(태그해제 시 원료배합 화면이 새로고침 됩니다.)'
      if (await openAsyncConfirm({ message, confirmOk: '구성성분 없음 태그해제', })) {
        if (!o.vMateCd || !props.vLand1 || !props.vPlantCd) {
          openAsyncAlert({ message: '갱신을 위한 필수값이 없습니다. 관리자에게 문의해주세요.' })
          return
        }

        const response = await updateRefreshMatnr({
          vMatnr: o.vMateCd,
          vLand1: props.vLand1,
          vWerks: props.vPlantCd,
        })

        openAsyncAlert({ message: response === 'Y' ? '갱신 되었습니다.' : 'SAP에 구성성분을 등록하지 않았습니다.' })
        context.emit('onTabClick', props.nVersion)
      }
    }

    const getMateDbLotInfoTxt = (vMatePkCd) => {
      const lotList = props.lotList
      let rateList = []
      if (!vMatePkCd || vMatePkCd.indexOf('tmp_mate_pk_cd') > -1) {
        return null
      }

      for (let i = 0; i < lotList.length; i++) {
        if (lotList[i].activeYn === 'Y') {
          rateList = lotList[i].rateList
          break
        }
      }

      const mateDbLotInfo = rateList.find(rate => rate.vMatePkCd === vMatePkCd)
      if (mateDbLotInfo && mateDbLotInfo?.vHal4VersionTxt && mateDbLotInfo?.vHal4LotNm) {
        return '[' + mateDbLotInfo?.vHal4VersionTxt + ' - ' + mateDbLotInfo?.vHal4LotNm + ']'
      }
      else {
        return null
      }
    }

    return {
      subList,
      fnToggleRowSelect,
      fnMateMemoPopup,
      fnToggleGroupOpen,
      fnSearchRowMate,
      onProblemHisPop,
      onHal4LotSetPop,
      onDetailHal4Pop,
      onSearchSubMateList,
      onMaxMixPop,
      getCheckMu4Mate,
      onMateNmPop,
      onRefreshMatnr,
      getMateDbLotInfoTxt,
    }
  },
}

</script>
