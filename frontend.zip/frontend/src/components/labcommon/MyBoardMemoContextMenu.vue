<template>
  <div class="material-setting"
    :class="{ show: isShow }"
    :style="contextMenuStyle"
    style="z-index: 3"
  >
    <div class="material-setting__inner">
      <div class="material-setting__item">
        <div class="material-setting__buttons">
          <button class="material-setting__button" type="button" @click="changeColor('blue')">
            <i class="context-icon context-icon-blue"></i>
            <span class="material-setting__button--text">파랑</span>
          </button>
          <button class="material-setting__button" type="button" @click="changeColor('green')">
            <i class="context-icon context-icon-green"></i>
            <span class="material-setting__button--text">초록</span>
          </button>
          <button class="material-setting__button" type="button" @click="changeColor('pink')">
            <i class="context-icon context-icon-pink"></i>
            <span class="material-setting__button--text">분홍</span>
          </button>
          <button class="material-setting__button" type="button" @click="changeColor('purple')">
            <i class="context-icon context-icon-purple"></i>
            <span class="material-setting__button--text">보라</span>
          </button>
          <button class="material-setting__button" type="button" @click="changeColor('yellow')">
            <i class="context-icon context-icon-yellow"></i>
            <span class="material-setting__button--text">노랑</span>
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

export default {
  name: 'MyBoardMemoContextMenu',
  props: {
    isShow: {
      type: Boolean,
      default: false,
    },
    contextMenuStyle: {
      type: Object,
      default: () => {
        return {}
      }
    },
    index: {
      type: Number,
      default: 0
    }
  },
  emits: ['changeColor'],
  setup (props, context) {
    const changeColor = (color) => {
      const returnObj = {
        index: props.index,
        color
      }
      context.emit('changeColor', returnObj)
    }

    return {
      changeColor,
    }
  }
}
</script>