<template>
  <div class="search-result-table mate-register-table">
    <table class="ui-table__reset ui-table__search-result text-center">
      <colgroup>
        <col style="width:9rem;">
        <col style="width:auto;">
        <col style="width:12rem;">
        <col style="width:12rem;">
        <col v-if="stockDtYn === 'Y'" style="width:15rem;">
        <col v-if="mateChgYn === 'Y'" style="width:14rem;">
        <col style="width:18rem;">
        <col style="width:5rem;">
      </colgroup>
      <thead>
        <tr>
          <th>원료코드</th>
          <th>원료명</th>
          <th>TO-100</th>
          <th>함량</th>
          <th v-if="stockDtYn === 'Y'">입고완료 예정일</th>
          <th v-if="mateChgYn === 'Y'">소재팀 담당자</th>
          <th>비고</th>
          <th></th>
        </tr>
      </thead>
      <tbody v-if="list && list.length > 0">
        <tr v-for="(vo, index) in list" :key="'mate_' + type + index">
          <td>
            <template v-if="commonUtils.isEmpty(vo.vMateCd) && vo.vMateDbTypeCd === 'SUP'">
              {{ vo.vMateTempCd }}
            </template>
            <template v-else>
              {{ vo.vMateCd }}
            </template>
          </td>
          <td class="t-left">
            <MateName
              :mate-info="vo"
            >
            </MateName>
          </td>
          <td>
            <div class="ui-radio__list" v-if="vo.vFlagPermissionMate !== 'Y'">
              <div class="ui-radio__inner">
                <ap-input-radio
                  v-for="(item, idx) in [{vSubCode: 'Y', vSubCodenm: 'Y'}, {vSubCode: 'N', vSubCodenm: 'N'}]" :key="'flagTo100_' + idx"
                  v-model:model="vo.vFlagTo100"
                  :value="item.vSubCode"
                  :label="item.vSubCodenm"
                  :id="'flagTo100_' + item.vSubCode + type + index"
                  :name="'flagTo100_' + type + index"
                  @click="changeFlagTo100Event(vo)"
                >
                </ap-input-radio>
              </div>
            </div>
          </td>
          <td>
            <ap-input
              input-class="w97"
              v-if="vo.vFlagTo100 === 'N'"
              :is-number="true"
              point="10"
              v-model:value="vo.nReqRate"
            >
            </ap-input>
          </td>
          <td v-if="stockDtYn === 'Y'">
            <ap-date-picker
              v-model:date="vo.vMatePutDt"
            >
            </ap-date-picker>
          </td>
          <td v-if="mateChgYn === 'Y'">
            <div class="search-form">
              <div class="search-form__inner">
                <ap-input
                  v-model:value="vo.vMateUsernm"
                  input-class="w97"
                  :readonly="true"
                  @click="fnUserSearchPop(index)"
                >
                </ap-input>
                <button type="button"
                  class="ui-button__circle ui-button__close input-close-btn--1"
                  @click="removeMateUser(vo)"
                ></button>
              </div>
            </div>
          </td>
          <td>
            <ap-input
              v-model:value="vo.vNote"
            >
            </ap-input>
          </td>
          <td>
            <div class="ui-buttons ui-buttons__order ui-buttons__center" v-if="vo.vFlagPermissionMate !== 'Y'">
              <button 
                type="button"
                class="ui-button__circle ui-button__close"
                @click="removeMate(index)"
              ></button>
            </div>
          </td>
        </tr>
      </tbody>
      <tbody v-else>
        <tr>
          <td colspan="7">
            <div class="no-result">원료를 추가 해주세요.</div>
          </td>
        </tr>
      </tbody>
    </table>
    <teleport to="#common-modal-sub" v-if="popContent">
      <ap-popup>
        <component
          :is="popContent"
          :pop-params="popupParams"
          @selectFunc="popSelectFunc"
          @closeFunc="closeFunc"
        />
      </ap-popup>
    </teleport>
  </div>
  <div id="common-modal-sub"></div>
</template>

<script>
import { defineAsyncComponent, watch, ref, inject } from 'vue'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'MateSearchResultTableRegister',
  props: {
    mateList: {
      type: Array,
      default: () => {
        return []
      }
    },
    type: {
      type: String,
      default: ''
    },
    modifyPopFlag: {
      type: String,
      default: 'N'
    },
    mateChgYn: {
      type: String,
      default: 'N'
    },
    stockDtYn: {
      type: String,
      default: 'N'
    }
  },
  components: {
    MateName: defineAsyncComponent(() => import('@/components/labcommon/MateName.vue')),
    UserSearchPop: defineAsyncComponent(() => import('@/components/comm/popup/UserSearchPop.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
  },
  emits: ['update:mateList'],
  setup (props, context) {
    const commonUtils = inject('commonUtils')
    const { openAsyncPopup, closeAsyncPopup } = useActions(['openAsyncPopup', 'closeAsyncPopup'])
    const list = ref(props.mateList)
    let userIdx = null
    const popContent = ref(null)
    const popSelectFunc = ref(null)
    const closeFunc = ref(null)
    const popupParams = ref({})

    const changeFlagTo100Event = (vo) => {
      if (vo.vFlagTo100 === 'Y') {
        vo.vNote = 'To-100'
        vo.nReqRate = ''
      } else {
        vo.vNote = ''
        vo.nReqRate = ''
      }
    }

    const removeMate = (index) => {
      list.value.splice(index, 1)
    }

    const fnUserSearchPop = (index) => {
      userIdx = index

      popupParams.value = {
        vKeyword: '',
        popType: 'SUB',
        searchFlag: 'LAB'
      }

      popSelectFunc.value = getUserSearchInfo
      closeFunc.value = closeUserSearchPop
      popContent.value = 'UserSearchPop'

      if (props.modifyPopFlag !== 'Y') {
        openAsyncPopup()
      }
    }

    const closeUserSearchPop = () => {
      popContent.value = null
      if (props.modifyPopFlag !== 'Y') {
        closeAsyncPopup({ message: '' })
      }
    }

    const getUserSearchInfo = (item) => {
      list.value[userIdx].vMateUsernm = item.vUsernm
      list.value[userIdx].vMateUserid = item.vUserid

      userIdx = null
    }

    const removeMateUser = (item) => {
      item.vMateUserid = ''
      item.vMateUsernm = ''
    }

    watch(() => list.value, (newVal, oldVal) => {
      if (newVal !== oldVal) {
        context.emit('update:mateList', newVal)
      }
    })

    watch(() => props.mateList, (newVal) => {
      list.value = [ ...newVal ]
    })

    return {
      commonUtils,
      list,
      popContent,
      popSelectFunc,
      closeFunc,
      popupParams,
      changeFlagTo100Event,
      removeMate,
      fnUserSearchPop,
      removeMateUser,
    }
  }
}
</script>

<style scoped>
  .ui-button__circle { margin-left: 2px;}
</style>