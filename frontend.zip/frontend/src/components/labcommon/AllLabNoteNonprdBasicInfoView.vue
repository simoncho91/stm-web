<template>
  <div class="basic-information">
    <div class="basic-information__inner">
      <div class="basic-information__table">
        <div class="ui-table__basic-information--wrap">
          <table class="ui-table__basic-information" id="nonprd-basic-info-table">
            <colgroup>
              <col style="width:10%">
              <col style="width:40%">
              <col style="width:10%">
              <col style="width:40%">
            </colgroup>
            <tbody>
              <tr>
                <th>과제구분</th>
                <td>{{ info.vLabTypeNm }}</td>
                <th>보안구분</th>
                <td>{{ info.vFlagSecurity === 'Y' ? '보안(나만 보기)' : '일반' }}</td>
              </tr>
              <template v-if="info?.v4mMatCd">
                <tr>
                  <th>4M변경정보</th>
                  <td colspan="3">
                    {{ info.v4mHisNum }}
                    <span style="margin-left: 10px;">
                      <button type="button" class="ui-button ui-button__bg--skyblue" @click="go4mInfoView(info.v4mMatCd)">상세보기</button>
                    </span>
                    <span style="margin-left: 10px;color: blue;">
                      *해당 건은 4M변경에 대한 제형 검토를 위해서 생성 되었습니다.
                    </span>
                  </td>
                </tr>
              </template>
              <tr>
                <th>예산코드</th>
                <td colspan="3">
                  <div class="form-flex">
                    <div>
                      <template v-if="info.pjtList.length > 0">
                        <template v-for="(vo, index) in info.pjtList" :key="'pjt_' + index">
                          <a href="#" class="detail-link">[{{vo.vRpmsCd}}] {{ vo.vPjtNm }}</a><br>
                        </template>
                      </template>
                    </div>
                  </div>
                </td>
              </tr>
              <template v-if="info?.vFlagExistMatnr === 'Y'">
                <tr>
                  <th>브랜드</th>
                  <td>{{ info.vBrdNm }}</td>
                  <th>플랜트</th>
                <td>{{ info.vPlantNm }}</td>
                </tr>
                <tr>
                  <th>내용물 코드</th>
                  <td colspan="3">{{ info.vContCd }}</td>
                </tr>
              </template>
              <tr>
                <th>과제명</th>
                <td colspan="3">{{ info.vContNm }}</td>
              </tr>
              <tr>
                <th>연구담당자</th>
                <td>{{ info.vUsernm }}</td>
                <th>담당부서</th>
                <td>{{ info.vDeptNm }}</td>
              </tr>
              <tr>
                <th>고객베네핏</th>
                <td>{{ info.vBenefit }}</td>
                <th>제형특징</th>
                <td>{{ info.vShapeFeature }}</td>
              </tr>
              <tr>
                <th>비고</th>
                <td v-html="commonUtils.removeHTMLChangeBr(info.vNote)"></td>
              </tr>
              <tr>
                <th>첨부파일</th>
                <td colspan="3">
                  <UploadFileView
                    v-if="commonUtils.isNotEmpty(info.vLabNoteCd)"
                    :uploadid="fileUploadId[noteType]"
                    :recordid="info.vLabNoteCd"
                  >
                  </UploadFileView>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, inject, watch, getCurrentInstance } from 'vue'
import { useStore } from 'vuex'

export default {
  name: 'AllLabNoteNonprdBasicInfoView',
  components: {
    UploadFileView: defineAsyncComponent(() => import('@/components/comm/UploadFileView.vue')),
  },
  setup () {
    const app = getCurrentInstance();
    const tiumUrl = app.appContext.config.globalProperties.tiumUrl

    const commonUtils = inject('commonUtils')
    const reqInfo = inject('reqInfo')
    const store = useStore()
    const noteType = store.getters.getNoteType()

    const fileUploadId = {
      'SC': 'LAB_NOTE_ATT01',
      'MU': 'MAKEUP_NOTE_ATT01',
      'HBO': 'HBO_NOTE_ATT01',
      'SA': 'SA_NOTE_ATT01',
    }

    const info = ref({
      vBrdCd: '',
      vBrdNm: '',
      vFlagOem: '',
      vOemManufacturer: '',
      vPlantCd: '',
      vSiteType: '',
      pjtList: [],
      vContNm: '',
      vNoteContNm: '',
      vPrdCd: '',
      vContCd: '',
      vFlagNew: '',
      vProdType1Cd: '',
      vProdType1Nm: '',
      vProdType2Cd: '',
      vProdType2Nm: '',
      vProdTypeNote: '',
      vUsernm: '',
      vPlantNm: '',
      vSiteTypeNm: '',
      vNote: '',
    })

    const go4mInfoView = (matCd) => {
      if (!matCd) {
        return
      }

      // 인벤토리 등록 페이지
      const targetUrl = `${tiumUrl}/mat4m/mat4m/mat4m_info_view.do?i_sMatCd=${matCd}`

      //새창
      window.open(targetUrl, '_blank')
    }

    watch(() => reqInfo.value, (newValue) => {
      info.value = { ...info.value, ...newValue }
    })

    return {
      commonUtils,
      info,
      fileUploadId,
      noteType,
      go4mInfoView,
    }
  }
}
</script>
