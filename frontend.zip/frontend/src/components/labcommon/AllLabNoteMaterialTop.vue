<template>
  <div class="ui-buttons ui-buttons__comb">
    <button class="button-comb button-comb__pageInfo"></button>
    <button v-if="noteType === 'MU'" class="button-comb button-comb__toning" @click="onToningPop"></button>
    <!-- <button class="button-comb button-comb__testRequest"></button> -->
    <button class="button-comb button-comb__loadPres" @click="onBookmarkPop"></button>
    <button class="button-comb button-comb__settingMaterial" @click="onNoteMstSetPop"></button>
    <button class="button-comb button-comb__export" @click="onMateExportPop"></button>
  </div>

  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component :is="popupContent" :pop-params="popParams" @selectFunc="popSelectFunc"
        @selectFuncMstSetPop="popSelectFunc" @selectFuncMateAndGrp="popSelectFunc" />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, ref, inject, watch } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useStore } from 'vuex'
import mixmatUtils from '@/utils/mixmatUtils'

export default {
  name: 'AllLabNoteMaterialTop',
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    BookmarkSearchPop: defineAsyncComponent(() => import('@/components/labcommon/popup/BookmarkSearchPop.vue')),
    LabNoteAuthorityPop: defineAsyncComponent(() => import('@/components/labcommon/popup/LabNoteAuthorityPop.vue')),
    MateExportPop: defineAsyncComponent(() => import('@/components/labcommon/popup/MateExportPop.vue')),
    MstSetPop: defineAsyncComponent(() => import('@/components/labcommon/popup/MstSetPop.vue')),
    ToningPop: defineAsyncComponent(() => import('@/components/labcommon/popup/ToningPop.vue')),
  },
  emits: ['onTabClick', 'onAddMateAndGrp'],
  setup(props, context) {
    const reqInfo = inject('reqInfo')
    const store = useStore()
    const noteType = store.getters.getNoteType()

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
    } = useLabCommon()

    const info = ref({
      contVO: {},
      rvo: {},
      mateList: [],
      verVO: {},
    })

    watch(
      () => reqInfo.value,
      (o) => {
        info.value = { ...info.value, ...o }
      }
    )

    const onNoteMstSetPop = () => {
      popParams.value = {
        vLabNoteCd: info.value.contVO.vLabNoteCd,
        vContPkCd: info.value.contVO.vContPkCd,
        vPlantCd: info.value.contVO.vPlantCd,
        vCodeType: info.value.contVO.vCodeType,
        vLotAddType: info.value.rvo.vLotAddType || 'E',
      }
      popSelectFunc.value = selectFuncMstSetPop

      fnOpenPopup('MstSetPop', false)
    }

    const selectFuncMstSetPop = () => {
      context.emit('onTabClick', info.value.verVO.nVersion)
    }

    const onToningPop = () => {
      mixmatUtils.onFocusClear()
      mixmatUtils.clearMultipleSelectCell()

      popParams.value = {
        vLabNoteCd: info.value.contVO.vLabNoteCd,
        vToningType: info.value.rvo.vToningType || null,
        nToning: info.value.rvo.nToning || null,
        vToningLotCd: info.value.rvo.vToningLotCd || null,
        lotList: info.value.lotList,
      }
      popSelectFunc.value = selectFuncMstSetPop

      fnOpenPopup('ToningPop', false)
    }

    const onBookmarkPop = () => {
      mixmatUtils.onFocusClear()
      mixmatUtils.clearMultipleSelectCell()

      popParams.value = {
        vSearchField: 'SIMILAR',
        vKeyword: '',
        vLabNoteCd: info.value.contVO.vLabNoteCd,
        vCodeType: info.value.contVO.vCodeType,
        vFlagRepresent: info.value.contVO.vFlagRepresent,
        vFlagBookPop: '',
        vLabNoteCdTemp: info.value.contVO.vLabNoteCd,
        vPlantCdTemp: info.value.contVO.vPlantCd,
        vNoteType: noteType,
        vSiteType: info.value.rvo.vSiteType,
      }
      popSelectFunc.value = selectFuncMateAndGrp

      fnOpenPopup('BookmarkSearchPop')
    }

    const selectFuncMateAndGrp = (o) => {
      context.emit('onAddMateAndGrp', o)
    }

    const onMateExportPop = () => {
      popParams.value = {
        vLabNoteCd: info.value.contVO.vLabNoteCd,
        vContPkCd: info.value.contVO.vContPkCd,
        nVersion: info.value.verVO.nVersion,
        vLotCd: '',
        vPlantCd: info.value.contVO.vPlantCd,
        vLand1: info.value.contVO.vLand1,
      }
      popSelectFunc.value = onResultMateExport
      fnOpenPopup('MateExportPop')
    }

    const onResultMateExport = (t) => {
      if (t === 'auth') {
        fnNoteAuthPop()
      }
      else {
        context.emit('onTabClick', info.value.verVO.nVersion)
      }
    }

    const fnNoteAuthPop = () => {
      popParams.value = {
        vLabNoteCd: info.value.contVO.vLabNoteCd,
        vContCd: info.value.contVO.vContCd,
        vContNm: info.value.contVO.vContNm,
        vPageType: info.value.rvo.vLabTypeCd === 'LNC07_01' ? 'prd' :
          info.value.rvo.vLabTypeCd === 'LNC07_02' ? 'half' : 'nonprd',
      }

      fnOpenPopup('LabNoteAuthorityPop')
    }

    return {
      noteType,
      info,
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      onNoteMstSetPop,
      onToningPop,
      onBookmarkPop,
      onMateExportPop,
      selectFuncMstSetPop,
      selectFuncMateAndGrp,
    }
  },
}
</script>
