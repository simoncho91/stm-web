<template>
  <div class="basic-information">
    <div class="basic-information__inner">
<!--       <div class="basic-information__info">
        <div class="basic-information__detail">
          <div class="basic-information__img">
          </div>
          <div class="basic-information__name">{{ info.vUsernm }}</div>
        </div>
        <div class="basic-information__brand">{{ info.vBrdNm }}</div>
        <div class="basic-information__title">{{ info.vContNm }}</div>
        <div class="basic-information__status">
          <div>{{ info.vLabTypeNm }}</div>
          <div>{{ info.vStatusNm }}</div>
        </div>
        <div class="basic-information__tag--wrap" v-if="info.funcTagList">
          <div class="basic-information__tags">
            <span
              v-for="(vo, idx) in info.funcTagList" :key="'tag_' + idx"
              :class="'basic-information__tag basic-information__tag--' + vo.vClassnm"
            ># {{ vo.vSubCodenm }}</span>
          </div>
        </div>
      </div> -->
      <div class="basic-information__table">
        <div class="ui-table__basic-information--wrap">
          <table class="ui-table__basic-information">
            <colgroup>
              <col style="width:16rem">
              <col style="width:auto">
              <col style="width:16rem">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr v-if="commonUtils.isNotEmpty(info.vNoteContNm)">
                <th>실험노트 제품명</th>
                <td colspan="3">
                  {{ info.vNoteContNm }}
                </td>
              </tr>
              <tr>
                <th>예산코드</th>
                <td colspan="3">
                  <div class="form-flex">
                    <template v-if="info.pjtList.length > 0">
                      <template v-for="(vo, index) in info.pjtList" :key="'pjt_' + index">
                          <a href="#" class="detail-link">[{{vo.vRpmsCd}}] {{ vo.vPjtNm }}</a><br>
                        </template>
                      </template>
                  </div>
                </td>
              </tr>
              <tr>
                <th>브랜드</th>
                <td>
                  {{ info.vBrdNm }}
                </td>
                <th>플랜트</th>
                <td>
                  {{ info.vPlantNm }}
                </td>
              </tr>
              <tr>
                <th>반제품명</th>
                <td colspan="3">{{ info.vContNm }}</td>
              </tr>
              <tr>
                <th>반제품 코드</th>
                <td>{{ info.vContCd }}</td>
                <th>SHELF LIFE</th>
                <td>
                  <template v-if="info.vShelflifeStatus === 'SLS020' || info.vShelflifeStatus === 'SLS030' || info.vShelflifeStatus === 'SLS040'">
                    {{ info.vShelfLife }}
                    <template v-if="commonUtils.checkAuth('S000000') || myInfo.loginId === info.vUserid">
                      <button
                        type="button"
                        class="ui-button ui-button__height--28 ml-10 ui-button__border--blue"
                        @click="fnShelfLifeModify()"
                      >변경요청</button>
                    </template>
                  </template>
                </td>
              </tr>
              <tr v-if="noteTypeVal == 'MU'">
                <th>제품유형</th>
                <td>
                  {{ info.vProdType1Nm }} - {{ info.vProdType2Nm }}<bb v-if="info.vProdType1Cd.indexOf('MTR02_') > -1">기타(기타)</bb>
                </td>
                <th>자재그룹</th>
                <td>
                  <span v-if="info.vMaterialGroupCd != null">[{{info.vMaterialGroupCd}}] {{info.vMaterialGroupNm}}</span>
                </td>
              </tr>
              <tr>
                <th>연구담당자</th>
                <td>
                  {{ info.vUsernm }}
                </td>
                <th>담당부서</th>
                <td>
                  {{ info.vUsrDeptnm }}
                </td>
              </tr>
              <tr v-if="noteTypeVal == 'MU' && info.vColorUserid != null">
                <th>조색 담당자</th>
                <td>
                  {{ info.vColorUsernm }}
                </td>
                <th>조색 담당 부서</th>
                <td>
                  {{ info.vColorDeptnm }}
                </td>
              </tr>
              <tr>
                <th>비고</th>
                <td colspan="3" v-html="commonUtils.removeHTMLChangeBr(info.vNote)"></td>
              </tr>
              <tr>
                <th>첨부파일</th>
                <td colspan="3">
                  <UploadFileView
                    v-if="commonUtils.isNotEmpty(info.vLabNoteCd)"
                    uploadid="HAL4_NOTE_ATT01"
                    :recordid="info.vLabNoteCd"
                  >
                  </UploadFileView>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @callbackFunc="popSelectFunc"
        @selectFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, ref, inject, watch } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useRouter } from 'vue-router'
import { useActions } from 'vuex-composition-helpers'
import { useStore } from 'vuex'

export default {
  name: 'AllLabNoteBasicInfoView',
  components: {
    UploadFileView: defineAsyncComponent(() => import('@/components/comm/UploadFileView.vue')),
    PlantRepresentChangePop: defineAsyncComponent(() => import('@/components/labcommon/popup/PlantRepresentChangePop.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
  },
  setup () {
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert, openAsyncConfirm } = useActions(['openAsyncAlert', 'openAsyncConfirm'])
    const reqInfo = inject('reqInfo')
    const router = useRouter()
    const store = useStore()
    const myInfo = store.getters.getMyInfo()
    const noteType = store.getters.getNoteType()
    const noteTypeNm = store.getters.getNoteTypeNm()
    const noteTypeVal = ref('')

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
    } = useLabCommon()

    const info = ref({
      vBrdCd: '',
      vBrdNm: '',
      vFlagOem: '',
      vOemManufacturer: '',
      vPlantCd: '',
      vSiteType: '',
      pjtList: [],
      vContNm: '',
      vNoteContNm: '',
      vPrdCd: '',
      vContCd: '',
      vFlagNew: '',
      vProdType1Cd: '',
      vProdType1Nm: '',
      vProdType2Cd: '',
      vProdType2Nm: '',
      vProdTypeNote: '',
      vUsernm: '',
      vPlantNm: '',
      vSiteTypeNm: '',
      vNote: '',
    })

    const fnPlantRepresentPop = () => {
      popParams.value = {
        vLabNoteCd: reqInfo.value.vLabNoteCd,
        vPlantCd: reqInfo.value.vPlantCd,
        vSiteType: reqInfo.value.vSiteType,
        vContCd: reqInfo.value.vContCd,
        vNoteType: noteType
      }

      popSelectFunc.value = fnPopSaveResult
      fnOpenPopup('PlantRepresentChangePop')
    }

    const fnPopSaveResult = () => {
      window.location.reload(true)
    }

    const fnShelfLifeModify = () => {
      const query = {
        vContCd: reqInfo.value.vContCd,
        vLabNoteCd: reqInfo.value.vLabNoteCd,
        vNoteType: noteType,
        vCodeType: 'HAL4'
      }

      router.push({ path: `/${noteTypeNm}/all-lab-note-shelf-register`, query })
    }

    const showPlantModifyBtn = () => {
      let isVisible = false

      if ((myInfo.loginId === info.value.vUserid ||
        myInfo.loginId === info.value.vBsmUserid ||
        myInfo.loginId === info.value.vBsmUseridSub1 ||
        myInfo.loginId === info.value.vBsmUseridSub2 ||
        commonUtils.checkAuth('S000000')) &&
        info.value.vStatusCd !== 'LNC06_50'
      ) {
        isVisible = true
      }

      return isVisible
    }

    watch(() => reqInfo.value, (newValue) => {
      if (newValue && newValue.funcTagList) {
        const tagColor = ['green', 'blue', 'brown']
        newValue.funcTagList.forEach((item, idx) => {
          item.vClassnm = tagColor[idx % 3]
        })
      }

      info.value = { ...info.value, ...newValue }

      noteTypeVal.value = noteType
    })

    return {
      commonUtils,
      info,
      myInfo,
      popupContent,
      popParams,
      popSelectFunc,
      fnPlantRepresentPop,
      fnShelfLifeModify,
      showPlantModifyBtn,
      noteTypeVal,
    }
  }
}
</script>