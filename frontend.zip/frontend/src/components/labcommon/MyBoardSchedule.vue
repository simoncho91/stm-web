<template>
  <div class="myboard-schedule">
    <div class="myboard-schedule__inner">
      <template v-if="labNoteList && labNoteList.length > 0">
        <div class="myboard-schedule__item" v-for="(note, index) in labNoteList" :key="'note_schedule_' + index">
          <div class="myboard-schedule__info" @click="goNoteDetail(note.vLabNoteCd)">
            <div class="myboard-schedule__num">{{ note.vContCd }}</div>
            <div class="myboard-schedule__name">{{ note.vContNm }}</div>
          </div>
          <div class="myboard-schedule__progress">
            <ul class="ui-list schedule-progress__lists" v-if="note.scheduleList && note.scheduleList.length > 0">
              <li
                v-for="(schedule, idx) in note.scheduleList"
                :key="'note_schedule_' + index + '_' + idx"
                :class="['schedule-progress__list', schedule.vCurrStatMark]"
              >
                <span class="schedule-progress__check"></span>
                <span class="schedule-progress__text">{{ schedule.vSubCodenm }}</span>
              </li>
            </ul>
          </div>
        </div>
      </template>
    </div>
  </div>
</template>

<script>
import { ref, inject } from 'vue'
import { useStore } from 'vuex'
import { useRouter } from 'vue-router'
import { useCode } from '@/compositions/useCode'
import { useMyboardCommon } from '@/compositions/labcommon/useMyboardCommon'

export default {
  name: 'MyBoardSchedule',
  setup () {
    const commonUtils = inject('commonUtils')
    const labNoteList = ref([])
    const store = useStore()
    const router = useRouter()
    const noteTypeNm = store.getters.getNoteTypeNm()
    const {
      scheduleInfo,
      selectScheduleList,
    } = useMyboardCommon()

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const goNoteDetail = (vLabNoteCd) => {
      const path = `/${noteTypeNm}/all-lab-note-prd-view`
      router.push({ path, query: { vLabNoteCd }})
    }

    const init = async () => {
      await Promise.all([
        findCodeList(['AL_NOTE']),
        selectScheduleList()
      ])

      if (scheduleInfo.value) {
        const statusList = codeGroupMaps.value['AL_NOTE'].filter(code => commonUtils.isNotEmpty(code.vBuffer1) && code.vBuffer1.indexOf('TIME') > -1)
        const noteList = scheduleInfo.value

        if (noteList && noteList.length > 0) {
          noteList.forEach(item=> {
            const activeStatus = item.vActiveStatus
            const activeNum = Number(activeStatus.replace(/[^0-9]/g, ''))
            const copyStatusList = []

            statusList.forEach(status => {
              copyStatusList.push({...status})
            })

            const progressList = []

            copyStatusList.forEach(status => {
              const statusCd = status.vSubCode
              const progNum = Number(statusCd.replace(/[^0-9]/g, ''))
              let vCurrStatMark = ''
              
              if (commonUtils.isNotEmpty(activeStatus) && statusCd === activeStatus) {
                vCurrStatMark = 'is-ing'
              }

              if (progNum < activeNum) {
                vCurrStatMark = 'is-done'
              }

              progressList.push({ ...status, vCurrStatMark })
            })

            item.scheduleList = progressList
          })
        }

        labNoteList.value = noteList
      }
    }

    init()

    return {
      labNoteList,
      goNoteDetail,
    }
  }
}
</script>

<style scoped>
  .myboard-schedule__info { cursor: pointer; }
</style>