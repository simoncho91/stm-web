<template>
  <div class="contents-box contents-box__small">
    <MyBoardNote></MyBoardNote>
  </div>
  <div class="contents-box contents-box__large">
    <div class="contents-box__inner">
      <div class="ui-tab">
        <div class="ui-tab__inner">
          <div class="ui-tab__header">
            <ul class="ui-list ui-tab__lists">
              <li class="ui-tab__list"
                v-for="(vo, idx) in tabList"
                :class="selectedTab === vo.tabId ? 'is-active' : ''"
                :key="'myboardTab4_' + idx"
              >
                <a href="#" class="ui-tab__link" @click.prevent="fnSelectedTabEvent(vo)">
                  {{ vo.tabNm }}
                </a>
              </li>
            </ul>
          </div>
          <div class="ui-tab__body" id="myboard_schedule" v-if="selectedTab === 'myboard_schedule'">
            <MyBoardSchedule></MyBoardSchedule>
          </div>
          <div class="ui-tab__body" id="myboard_assignResearcher" v-if="selectedTab === 'myboard_assignResearcher'">
            <SkincareMyBoardAssignResearcher></SkincareMyBoardAssignResearcher>
          </div>
        </div>

      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, ref } from 'vue'
import { useStore } from 'vuex'
import { useRoute } from 'vue-router'
import { useRouter } from 'vue-router'
export default {
  name: 'MyBoardNS',
  components: {
    MyBoardNote: defineAsyncComponent(() => import('@/components/labcommon/MyBoardNote.vue')),
    MyBoardSchedule: defineAsyncComponent(() => import('@/components/labcommon/MyBoardSchedule.vue')),
    SkincareMyBoardAssignResearcher: defineAsyncComponent(() => import('@/components/skincare/SkincareMyBoardAssignResearcher.vue'))
  },
  setup () {
    const store = useStore()
    const selectedTab = ref('myboard_schedule')
    const tabList = [
      { tabId: 'myboard_schedule', tabNm: 'Schedule' },
    ]
    const route = useRoute()
    const router = useRouter()
    const vAssignResearcher = route.query.vAssignResearcher

    const fnSelectedTabEvent = (item) => {
      router.replace({ query: ''})
      selectedTab.value = item.tabId
    }
    
    const init = () => {
      const noteType = store.getters.getNoteType()

      if (noteType === 'SC') {
        tabList.push({ tabId: 'myboard_assignResearcher', tabNm: 'Assign researcher' })
      }

      //연구원 지정 파라미터가 있을 경우
      if(vAssignResearcher){
        selectedTab.value = 'myboard_assignResearcher'
      }
    }

    init()

    return {
      selectedTab,
      tabList,
      fnSelectedTabEvent,
    }
  }
}
</script>