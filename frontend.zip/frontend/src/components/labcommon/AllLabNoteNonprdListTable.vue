<template>
  <div class="note-table">
    <div class="note-table__inner">
      <table class="ui-table ui-table__td--40 text-center">
        <colgroup>
          <col style="width: 9%" />
          <col style="width: 9%" />
          <col style="width: auto" />
          <col style="width: 9%" />
          <col style="width: 9%" />
        </colgroup>
        <thead>
          <tr>
            <th>상태</th>
            <th>실험구분</th>
            <th>과제명</th>
            <th>연구담당자</th>
            <th>생성일</th>
          </tr>
        </thead>
        <tbody v-if="info.list && info.list.length > 0">
          <template v-for="(vo, index) in info.list" :key="index">
            <tr :class="vo.isOpenStatus ? 'is-active' : ''">
              <td>{{ vo.vStatusNm }}</td>
              <td>{{ vo.vLabTypeNm }}</td>
              <td class="tit">
                <div class="tit__inner">
                  <a href="#" class="tit-link" @click="goDetailPage(vo)">
                    <template v-if="vo?.vContCd"><span class="txt_blue">{{ vo.vContCd }}</span></template> {{vo.vContNm}}
                  </a>
                </div>
              </td>
              <td>{{ vo.vUsernm }}</td>
              <td>{{ commonUtils.changeStrDatePattern(vo.vRegDtm) }}</td>
            </tr>
          </template>
        </tbody>
        <tbody v-else>
          <tr>
            <td colspan="5">
              <div class="no-result">
                {{ t('common.msg.no_data') }}
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <div class="board-bottom">
    <div class="board-bottom__inner">
      <Pagination :page-info="info.page" @click="onPaging"> </Pagination>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, inject, watch } from 'vue'
import { useNonPrdCommon } from '@/compositions/labcommon/useNonPrdCommon'
import { useHalfProcessCommon } from '@/compositions/labcommon/useHalfProcessCommon'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'

export default {
  name: 'AllLabNoteNonprdListTable',
  components: {
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
  },
  props: {
    resultList: {
      type: Array,
      default: () => {
        return []
      }
    },
    resultPage: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  emits: ['onPaging', 'onSorting'],
  setup(props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const info = ref({
      list: [],
      page: {}
    })

    const {
      goNonprdView,
    } = useNonPrdCommon()

    const {
      selectProgressBar,
    } = useHalfProcessCommon()

    const {
      fnSetRecentLog,
    } = useLabCommon()

    const onPaging = (pg) => {
      context.emit('onPaging', pg)
    }

    const goDetailPage = async (item) => {
      if (commonUtils.isNotEmpty(item.vContCd)) {
        item.vPageType = 'nonprd'
        await fnSetRecentLog(item)
      }

      goNonprdView(item.vLabNoteCd)
    }

    const fnOpenStatus = async (item) => {
      item.isOpenStatus = !item.isOpenStatus

      if (item.progressCall !== 'Y') {
        const result = await selectProgressBar({ vLabNoteCd: item.vLabNoteCd })
        
        item.progressInfo = result.progressInfo
        item.vFlagCancel = result.vFlagCancel == undefined ? 'N' : result.vFlagCancel

        item.progressCall = 'Y'
      }
    }

    watch(() => props.resultList, (newVal) => {
      info.value.list = newVal
    })

    watch(() => props.resultPage, (newVal) => {
      info.value.page = newVal
    })

    return {
      t,
      commonUtils,
      onPaging,
      goDetailPage,
      fnOpenStatus,
      info,
    }
  },
}
</script>

<style scoped>
  .material-setting__button { background: transparent; }
</style>
