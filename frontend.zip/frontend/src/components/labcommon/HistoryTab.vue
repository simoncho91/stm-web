<template>
  <nav class="history-tab" v-if="commonUtils.isNotEmpty(vLabNoteCd) && recentNoteList && recentNoteList.length > 0">
    <h2 class="for-a11y">History Tab</h2>
    <div class="history-tab__inner">
      <ul class="ui-list history-tab__list">
        <li v-for="(vo, idx) in recentNoteList" :key="'recent_tab_' + idx" class="history-tab__item"
          :class="vo.vLabNoteCd === vLabNoteCd ? 'is-active' : ''">
          <div class="history-tab__block">
            <a href="#" class="history-tab__link ui-tooltip__parent" @click.prevent="goTabDetail(vo)">
              {{ vo.vContCd }}
              <span v-if="commonUtils.isNotEmpty(vo.vContNm)" class="ui-tooltip ui-tooltip__top">
                <span class="ui-tooltip__inner">{{ vo.vContNm }}</span>
              </span>
            </a>
            <div class="history-tab__buttons">
              <button v-if="vIsMaterial && vo.vLabNoteCd === vLabNoteCd" type="button"
                class="ui-button history-tab__3code" :class="materialArrow.show ? 'is-active' : ''"
                @click="onShowContList()"></button>
              <button type="button" class="ui-button history-tab__delete" @click="fnDeleteTab(idx, vo)">
                <span class="for-a11y">삭제</span>
              </button>
            </div>
          </div>
        </li>
      </ul>
    </div>
  </nav>
</template>

<script>
import { computed, inject, reactive } from 'vue'
import { useStore } from 'vuex'

export default {
  name: 'HistoryTab',
  props: {
    urlLink: {
      type: String,
      required: true
    },
    vLabNoteCd: {
      type: String,
    },
    vIsMaterial: {
      type: Boolean,
      default: false,
    }
  },
  emits: ['goList', 'onShowContList'],
  setup(props, context) {
    const commonUtils = inject('commonUtils')
    const store = useStore()
    const noteType = store.getters.getNoteType()
    const recentNoteList = computed(() => store.getters.getRecentNoteList(noteType))

    const materialArrow = reactive({
      show: true,
    })

    const goTabDetail = (item) => {
      const urlLink = props.urlLink.indexOf('{pageType}') > -1 && commonUtils.isNotEmpty(item.vPageType) 
                    ? props.urlLink.replace('{pageType}', item.vPageType)
                    : props.urlLink
      window.location.href = urlLink + item.vLabNoteCd
    }

    const fnDeleteTab = (index, item) => {
      store.dispatch('removeRecentNoteList', { noteType, index })

      if (recentNoteList.value.length === 0) {
        context.emit('goList')
      } else if (item.vLabNoteCd === props.vLabNoteCd) {
        goTabDetail(recentNoteList.value[0])
      }
    }

    const onShowContList = () => {
      materialArrow.show = !materialArrow.show

      context.emit('onShowContList', materialArrow.show)
    }

    return {
      commonUtils,
      recentNoteList,
      materialArrow,
      goTabDetail,
      fnDeleteTab,
      onShowContList,
    }
  }
}
</script>