<template>
  <div class="myboard-memo myboard-memo-area" ref="memoWrap">
    <button 
      type="button"
      class="tab-header__button memo-header__btn"
      @click="addMemo()"
    >
    </button>
    <div class="myboard-memo__inner" v-if="memoList && memoList.length > 0">
      <div
        @mousedown="memoUtils.mouseDownEvent($event)"
        class="myboard-memo__item"
        :class="'myboard-memo__item--' + memo.vMemoBgClrNm"
        v-for="(memo, index) in memoList"
        :key="'memo_' + index"
      >
        <div class="myboard-memo__delete">
          <button type="button" class="myboard-memo__button--delete" @click="deleteMemo(index, memo)"></button>
        </div>
        <div class="myboard-memo__content">
          <div class="myboard-memo__tit">
            <input type="text"
              v-model="memo.vMemoTtl"
              :spellcheck="false"
              @blur="fnSaveMemo(memo)"
            />
          </div>
          <div class="myboard-memo__text">
            <textarea
              v-model="memo.vMemoTxt"
              :spellcheck="false"
              @blur="fnSaveMemo(memo)"
            >
            </textarea>
          </div>
        </div>
      </div>
    </div>
    <div class="myboard-no-data" v-else>
      등록된 메모가 없습니다.
    </div>
  </div>
  <div ref="contextMenuWrap">
    <MyBoardMemoContextMenu
      v-if="contextMenu.isShow === true"
      :is-show="contextMenu.isShow"
      :context-menu-style="contextMenu.contextMenuStyle"
      :index="contextMenu.index"
      @change-color="changeColor"
    >
    </MyBoardMemoContextMenu>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, reactive, onMounted, inject } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useMyboardCommon } from '@/compositions/labcommon/useMyboardCommon'
import memoUtils from '@/utils/memoUtils'

export default {
  name: 'MyBoardMemo',
  components: {
    MyBoardMemoContextMenu: defineAsyncComponent(() => import('@/components/labcommon/MyBoardMemoContextMenu.vue')),
  },
  mounted () {
    document.addEventListener('click', memoUtils.onClick)
  },
  unmounted () {
    document.addEventListener('click', memoUtils.onClick)
  },
  setup () {
    const commonUtils = inject('commonUtils')
    const memoList = ref([])
    const memoWrap = ref(null)
    const contextMenuWrap = ref(null)
    const { openAsyncAlert } = useActions(['openAsyncAlert'])
    const colorList = ['blue', 'yellow', 'pink', 'purple', 'green']
    const contextMenu = reactive({
      isShow: false,
      index: null,
      contextMenuStyle: {
        left: null,
        top: null,
        position: 'absolute',
      }
    })

    const {
      selectMyBoardMemoList,
      saveMyBoardMemo,
      deleteMyBoardMemo,
    } = useMyboardCommon()

    const changeColor = (colorInfo) => {
      memoList.value[colorInfo.index].vMemoBgClrNm = colorInfo.color

      saveMyBoardMemo(memoList.value[colorInfo.index])
    }

    const addMemo = async () => {
      if (memoList.value && memoList.value.length === 8) {
        openAsyncAlert({ message: '메모는 최대 8개까지 등록 가능합니다.' })
        return
      }

      const memoObj = {
        vMemoTtl: '',
        vMemoTxt: '',
        vMemoBgClrNm: colorList[Math.floor(Math.random() * 4)]
      }

      const memoNo = await saveMyBoardMemo(memoObj)
      memoObj.vTumnTsntUserMemoNo = memoNo
      memoList.value.push(memoObj)
    }

    const deleteMemo = async (index, memo) => {
      await deleteMyBoardMemo(memo)
      memoList.value.splice(index, 1)
    }

    const fnSaveMemo = async (memo) => {
      const memoNo = await saveMyBoardMemo(memo)

      memo.vTumnTsntUserMemoNo = memoNo
    }

    const init = async () => {
      memoList.value = await selectMyBoardMemoList()
    }

    init()

    onMounted(() => {
      memoUtils.init({
        memoWrap,
        memoList,
        contextMenu,
        contextMenuWrap,
      })

      memoUtils.addEvents()
    })

    return {
      commonUtils,
      memoUtils,
      memoList,
      memoWrap,
      contextMenuWrap,
      contextMenu,
      changeColor,
      addMemo,
      deleteMemo,
      fnSaveMemo,
    }
  }
}
</script>