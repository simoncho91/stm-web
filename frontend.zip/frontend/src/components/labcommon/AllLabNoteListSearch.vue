<template>
  <div class="board-top">
    <!-- <div class="search-form search-form__right">
      <div class="search-form__inner">
        <div class="search-form__cell">
          <button
            type="button"
            class="ui-button ui-button__border--blue ui-button__icon--right ui-button__icon--plus ui-button__icon--plus-blue"
          >
            Create
          </button>
        </div>
        <div class="search-form__cell">
          <ap-input
            v-model:value="search.vKeyword"
            inputClass="ui-input ui-input__width--263"
            placeholder="검색어를 입력 해주세요."
            @keypressEnter="onSearch"
          >
          </ap-input>
          <button type="button" class="button-search" @click="onSearch">
            검색
          </button>
        </div>
      </div>
    </div> -->
    <div class="basic-info__table">
      <table class="ui-table__contents">
        <colgroup>
          <col style="width:17rem">
          <col style="width:auto">
          <col style="width:17rem">
          <col style="width:auto">
        </colgroup>
        <tbody>
          <tr>
            <th>브랜드</th>
            <td>
              <ap-choosebox
                v-if="codeGroupMaps['LAB_NOTE_BRAND']"
                v-model:modelChkAll="search.vBrdAllYn"
                v-model:model="search.brdCdList"
                id="searchBrd"
                :options="codeGroupMaps['LAB_NOTE_BRAND']"
                input-class="ui-select__width--277"
              >
              </ap-choosebox>
            </td>
            <th>상태</th>
            <td>
              <ap-choosebox
                v-model:modelChkAll="search.vStatusAllYn"
                v-model:model="search.statusCdList"
                id="searchStatus"
                :options="statusList"
                input-class="ui-select__width--277"
              >
              </ap-choosebox>
            </td>
          </tr>
          <tr>
            <th>검색조건</th>
            <td colspan="3">
              <div class="search-form form-flex">
                <ap-input
                  v-model:value="search.vKeyword"
                  inputClass="ui-input__width--468"
                  placeholder="내용물 코드 or 내용물명 or 연구 담당자"
                  @keypressEnter="onSearch"
                >
                </ap-input>
                <button type="button" class="button-search" @click="onSearch">
                  검색
                </button>
                <div class="ml-5">
                  <ap-input-check
                    v-if="!commonUtils.checkAuth('S000333')"
                    v-model:model="search.vFlagMyLabNote"
                    label="내 실험노트만 보기"
                    value="Y"
                    false-value="N"
                    id="vFlagLabNote"
                    @click="fnFlagMyLabNoteCheckEvent"
                  >
                  </ap-input-check>
                </div>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
import { ref, inject, watch } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useStore } from 'vuex'

export default {
  name: 'AllLabNoteListSearch',
  props: {
    searchParams: {
      type: Object,
      default: () => {
        return {}
      }
    },
    pageType: {
      type: String,
      default: "prd"
    }
  },
  components: {},
  emits: ['onSearch'],
  setup(props, context) {
    const commonUtils = inject('commonUtils')
    const statusList = ref([])
    const store = useStore()
    const noteType = store.getters.getNoteType()
    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const search = ref({
      vListType: 'HAL3',
      vBrdAllYn: '',
      brdCdList: [],
      vStatusAllYn: '',
      statusCdList: [],
      vDeptCd: '',
      vFlagMyLabNote: '',
      vKeyword: '',
      nowPageNo: 1,
    })

    const onSearch = () => {
      sessionStorage.setItem('searchParams' + '_' + props.pageType + '_' + noteType, JSON.stringify(search.value))
      context.emit('onSearch', search.value)
    }

    const fnFlagMyLabNoteCheckEvent = () => {
      onSearch()
    }

    const init = async () => {
      await findCodeList(['LAB_NOTE_BRAND', 'LNC06'])

      if (codeGroupMaps.value['LNC06'] && codeGroupMaps.value['LNC06'].length > 0) {
        statusList.value = codeGroupMaps.value['LNC06']
                            .filter(code => code.vBuffer2 === 'BKR' && (code.vBuffer3 === 'ALL' || code.vBuffer3.indexOf(noteType) > -1))
      }
    }

    init()

    watch(() => props.searchParams, (newVal) => {
      search.value = { ...search.value, ...newVal }
    })

    return {
      commonUtils,
      search,
      codeGroupMaps,
      statusList,
      onSearch,
      fnFlagMyLabNoteCheckEvent,
    }
  },
}
</script>
