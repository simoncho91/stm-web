<template>
  <div class="material-excel">
    <div class="material-excel__inner" id="material-excel__inner">
      <a href="javascript:void(0)" ref="refGridFocus" class="grid-focus-dummy"></a>
      <div ref="refDivGridWrap" class="material-excel__table--wrap apg-grid-wrap">
        <AllLabNoteMaterialTab @onTabClick="onTabClick" @onVerNmChange="onVerNmChange" />

        <div class="apg-grid-left" :style="gridStyle.divGridLeftStyle">
          <!--// [s] LEFT HEADER  -->
          <div>
            <table class="ui-table__reset material-excel__table text-center apg-grid-left-table"
              :style="gridStyle.tableHeaderLeftStyle">
              <colgroup>
                <col v-for="columnVo in gridVars.columnsForzenLeft" :style="{ width: columnVo.width + 'px' }"
                  :key="'col_left_header_' + columnVo.code" />
              </colgroup>
              <tbody>
                <tr class="thead">
                  <th v-for="columnVo in gridVars.columnsForzenLeft" :key="columnVo.code" :style="{
                    width: columnVo.width + 'px',
                    height: (gridStyle.size.headerHeight * 2) - 1 + 'px'
                  }" :class="columnVo.classHeader">
                    <b v-html="columnVo.header" style="font-weight: 500;"></b>
                  </th>
                </tr>
              </tbody>
            </table>
          </div>
          <!--// [e] LEFT HEADER  -->

          <!--// [s] LEFT BODY  -->
          <div ref="refDivBodyLeft" class="anypjt-grid-body-left" :style="gridStyle.divBodyLeftStyle">
            <div ref="refDivBodyLeftSelectLayer" class="anypjt-grid-body-left-select-layer"
              :style="gridStyle.commonMarginTopStyle"></div>
            <!--// [s] 원료 or 그룹명 -->
            <div ref="refDivBodyLeftInput" class="apg-layer-input apg-input-mode"
              :class="(gridVars.inputMode.show && gridVars.inputMode.tableId === 'tableBodyLeft') ? 'active' : ''"
              style="min-width: 130px; width: 136px;" :style="gridStyle.commonMarginTopStyle">
              <template v-if="gridVars.inputMode.columnId === 'MATE'">
                <div class="apg-layer-mate-search apg-input-mode material-search">
                  <input type="text" class="material-search__input apg-layer-mate-search-input apg-input-mode"
                    @keydown.enter="fnRawMaterialSearch()" />
                  <button type="button" class="button-search apg-layer-mate-search-button apg-input-mode"
                    @click.prevent="fnRawMaterialSearch()"></button>
                </div>
              </template>
              <template v-else>
                <input type="text" value="" class="apg-input-mode" @keydown.enter="mixmatUtils.fnInputValueChange($event)"
                  @keydown.tab="mixmatUtils.fnInputValueChange($event)" />
              </template>
              <p class="apg-inp-message"></p>
            </div>
            <!--// [e] 원료 or 그룹명 -->

            <!--// [s] 원료명 메모 -->
            <div ref="refLayerMateMemoWrap" class="apg-layer-mate-memo-wrap" :class="{ active: gridVars.isShowMateMemo }"
              :style="gridStyle.commonMarginTopStyle">
              <div class="apg-layer-mate-memo" style="height: 29px;">
                <textarea id="txt-mate-memo" class="apg-layer-mate-memo-textarea"
                  style="width: 140px; height: 16px; font-size: 11px;"></textarea>
                <p id="p-mate-memo" style="width: 152px; height: 16px; font-size: 11px;"></p>
                <button type="button" class="lot-detail__button-modify" style="margin-top: 6px;"
                  @click.prevent="mixmatUtils.fnMateMemoApply()">
                </button>
              </div>
            </div>
            <!--// [e] 원료명 메모 -->
            <table ref="refTableBodyLeft" id="tableBodyLeft"
              class="ui-table__reset material-excel__table text-center anypjt-grid-body-left"
              :style="gridStyle.tableBodyLeftStyle">
              <colgroup>
                <col v-for="columnVo in gridVars.columnsForzenLeft" :style="{ width: columnVo.width + 'px' }"
                  :key="'col_left_body_' + columnVo.code" />
              </colgroup>
              <draggable v-model="gridVars.materials" item-key="vMatePkCd || vGrpCd || vMateCd" tag="tbody"
                group="materialMateList" :disabled="!store.getters.getDragMateInfo().isClone" @dragenter="onDragAndDrop">
                <template #item="{ element: mateVo, index: ridx }">
                  <tr v-if="canShowMateOrGroup(mateVo)" class="anypjt-grid-tr" :class="[
                    mateVo.vRecType === 'GRP' ? 'tr-group anypjt-grid-tr-group' : '',
                    mateVo.rowSelectYn === 'Y' ? 'is-active apg-tr-select' : '',
                    `anypjt-grid-tr-ridx-${ridx}`
                  ]" :data-row-idx="ridx" :data-row-type="mateVo.vRecType"
                    :data-row-cd="mateVo.vMatePkCd || mateVo.vGrpCd" @mouseover="mixmatUtils.onTrMouseover($event, ridx)"
                    @mouseout="mixmatUtils.onTrMouseout($event, ridx)"
                    @contextmenu.prevent="!mateVo.vParentMatePkCd ? onContextMenu($event, mateVo) : ''">
                    <AllLabNoteMaterialBodyLeft :mate-vo="mateVo" :row-index="ridx" :v-lab-note-cd="info.rvo.vLabNoteCd"
                      :v-land1="info.contVO.vLand1" :v-plantCd="info.contVO.vPlantCd" :n-version="info.verVO.nVersion"
                      :material-issue-codes="materialIssueCodes = null" :columns-forzen-left="gridVars.columnsForzenLeft"
                      :lot-list="info.lotList" @fn-toggle-row-select="onToggleRowSelect"
                      @fn-mate-memo-popup="mixmatUtils.fnMateMemoPopup"
                      @fn-toggle-group-open="mixmatUtils.fnToggleGroupOpen"
                      @fn-search-row-mate="mixmatUtils.fnSearchRowMate" @onProblemHisPop="onProblemHisPop"
                      @onHal4LotSetPop="onHal4LotSetPop" @onSearchSubMateList="onSearchSubMateList"
                      @onMaxMixPop="onMaxMixPop" @onTabClick="onTabClick">
                    </AllLabNoteMaterialBodyLeft>
                  </tr>
                </template>
              </draggable>
            </table>
          </div>
          <!--// [e] LEFT BODY  -->

          <!--// [s] LEFT FOOTER  -->
          <div class="anypjt-grid-footer-left" :style="gridStyle.divFooterLeftStyle">
            <table class="ui-table__reset material-excel__table text-center anypjt-grid-footer-left"
              :style="gridStyle.tableFooterLeftStyle">
              <tbody>
                <tr v-if="!commonUtils.isEmpty(info?.rvo)" :style="{ height: gridStyle.size.columnHeight }"
                  class="tfoot border-top__deepgray">
                  <td class="border-right__deepgray">합계</td>
                </tr>
                <!-- <tr :style="{ height: gridStyle.size.columnHeight }" class="tfoot">
                  <td class="border-right__deepgray">중화도 (%)</td>
                </tr> -->
                <tr v-if="gridVars.rowsForzen.musogu === 'N'" :style="{ height: gridStyle.size.columnHeight }"
                  class="tfoot">
                  <td class="border-right__deepgray">무소구 가능 항목 (가능/전체)</td>
                </tr>
                <tr v-if="gridVars.rowsForzen.priceSum === 'N'" :style="{ height: gridStyle.size.columnHeight }"
                  class="tfoot">
                  <td class="border-right__deepgray">
                    가격비 합계 (
                    <template v-if="info.rvo.nTargetCost">
                      Target Cost : {{ info.rvo.nTargetCost }}원 /
                    </template>
                    용량 : {{ !info.rvo.nCapacity ? 100 : info.rvo.nCapacity }}
                    {{ !info.rvo.vCapacityNm ? 'g' : info.rvo.vCapacityNm }}
                    )
                  </td>
                </tr>
                <tr v-if="gridVars.rowsForzen.noi === 'N'" :style="{ height: gridStyle.size.columnHeight }" class="tfoot">
                  <td class="border-right__deepgray">
                    <div class="d-flex align-center justify-center">
                      <div>NOI 지수 합계</div>
                      <div class="caution-overlay ">
                        <button type="button" class="icon icon-info icon-info__gray icon-info__hover--blue ml-05"
                          @mouseover="showHideHelpLayer('showNoi', true)"
                          @mouseout="showHideHelpLayer('showNoi', false)"></button>
                        <!-- 전달사항 :: 활성화시 .is-active 붙습니다. -->
                        <div class="caution-overlay__text color-red"
                          :class="pageVars.helpLayer.showNoi ? 'is-active' : ''">
                          <div class="caution-overlay__text--inner">
                            원료의 천연유래지수(NOI)가 없을 경우, 품질&amp;RA 담당자에게 <br>
                            원료자료 확보요청을 해주시기 바랍니다.
                          </div>
                        </div>
                      </div>
                    </div>
                  </td>
                </tr>
                <tr v-if="gridVars.rowsForzen.biodegradability === 'N'" :style="{ height: gridStyle.size.columnHeight }"
                  class="tfoot">
                  <td class="border-right__deepgray">
                    <div class="d-flex align-center justify-center">
                      <div>생분해도 지수 합계</div>
                      <div class="caution-overlay ">
                        <button type="button" class="icon icon-info icon-info__gray icon-info__hover--blue ml-05"
                          @mouseover="showHideHelpLayer('showBio', true)"
                          @mouseout="showHideHelpLayer('showBio', false)"></button>
                        <!-- 전달사항 :: 활성화시 .is-active 붙습니다. -->
                        <div class="caution-overlay__text color-red"
                          :class="pageVars.helpLayer.showBio ? 'is-active' : ''">
                          <div class="caution-overlay__text--inner">
                            해당 수치는 변동될 수 있으며, 생분해성 성분 함량 문안 소구를 <br>
                            위해서는 안전성Lab 담당자 검토가 필요합니다.
                          </div>
                        </div>
                      </div>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <!--// [e] LEFT FOOTER  -->
        </div>

        <div class="apg-grid-center" :style="gridStyle.divGridCenterStyle">
          <!--// [s] CENTER HEADER  -->
          <div ref="refDivHeaderCenter" class="anypjt-grid-header-center" style="padding-top: 70px; margin-top: -70px;"
            :style="gridStyle.divHeaderCenterStyle">
            <table class="ui-table__reset material-excel__table text-center anypjt-grid-header-center"
              :style="gridStyle.tableHeaderCenterStyle">
              <colgroup>
                <template v-for="lotVo in gridVars.lots" :key="'col_header_center_' + lotVo.vLotCd">
                  <template v-if="lotVo.vFlagExposure !== 'N'">
                    <col style="width: 100px" />
                    <template v-if="lotVo.activeYn === 'Y' && lotVo.grams">
                      <col v-for="(gramVo, gramIndex) in lotVo.grams" :key="'gram1_' + gramIndex" style="width: 80px" />
                    </template>
                    <col v-if="lotVo.openYn === 'Y'" style="width: 250px" />
                  </template>
                </template>
              </colgroup>
              <tbody>
                <tr class="thead">
                  <template v-for="lotVo in gridVars.lots" :key="'lot1_' + lotVo.vLotCd">
                    <th v-if="lotVo.vFlagExposure !== 'N'" class="th-lot" :class="[
                      lotVo.openYn === 'Y' ? 'col-2 th-lot__open' : 'col-1',
                      lotVo.activeYn === 'Y' ? 'border-top__blue border-right__blue border-left__blue' : '',
                      lotVo.borderClass,
                    ]" :colspan="lotVo.colspan" :style="{ height: gridStyle.size.headerHeight + 'px' }"
                      @contextmenu.prevent="onContextHeader($event, lotVo)">
                      <div class="lot-cell__wrap">
                        <div class="lot-cell lot-cell__num right-lot-area" :style="{ width: lotVo.width.lotNm }">
                          <a href="javascript:void(0)" class="lot-click" @click="onLotClick(lotVo)">
                            <button v-if="lotVo.vFlagComplete === 'Y'" type="button"
                              class="material-status__button material-status__button--hide is-active"
                              style="width: 12px; height: 12px;"></button>
                            <span v-if="lotVo.nLotCircle" class="lot-status"
                              :class="`lot-status__color${lotVo.nLotCircle}`">
                              {{ lotVo.nLotCircle - (noteType !== 'SC' ? 1 : 0) }}
                            </span>
                            {{ lotVo.vLotNm }}
                          </a>
                          <button type="button"
                            @click.prevent="mixmatUtils.fnToggleLotExpand(lotVo), onLotSideInfo(lotVo)"
                            class="lot-cell__button"></button>
                        </div>
                        <!-- DD :: 텍스트 입력시 is-inputed, 연필 클릭시 .is-active, 텍스트 입력된 상태에서 textarea 클릭시도 is-inputed 붙습니다. -->
                        <div v-if="info.mstSetVO.find(set => set.vColumnSetCd === 'COLUMN11')?.vFlagHide === 'N'"
                          class="lot-write"
                          :class="lotVo.activeYn === 'Y' ? 'is-active' : (lotVo.vLotMemo ? 'is-inputed' : '')">
                          <div class="lot-write__inner" :style="lotVo.activeYn === 'Y' ? 'height: 7rem;' : ''">
                            <div class="lot-write__text">
                              <div class="lot-write__text--inner">
                                <textarea v-model="lotVo.vLotMemo" class="lot-write__text--form"
                                  placeholder="최대 30글자 입력하세요." maxlength="30"
                                  @click="mixmatUtils.onFocusClear()"></textarea>
                              </div>
                            </div>
                            <button class="lot-write__button" @click="onLotClick(lotVo)"></button>
                            <div v-if="lotVo.vLotMemo" class="lot-write__tooltip">
                              <div class="lot-write__tooltip--inner">{{ lotVo.vLotMemo }}</div>
                            </div>
                          </div>
                        </div>

                        <div v-if="lotVo.openYn === 'Y'" class="lot-cell" :style="{ width: lotVo.width.lotOpen }">
                          <div class="lot-tags">
                            <button v-if="mixmatUtils.getBtnShow('BOM', lotVo, info, noteType)"
                              class="lot-tag lot-tag__step1" @click="onProcess('BOM_TMP_SEND', lotVo)">
                              <span class="lot-tag__color lot-tag__color1"></span>BOM임시전송
                            </button>
                            <button v-if="mixmatUtils.getBtnShow('PILOT', lotVo, info)" class="lot-tag lot-tag__step2"
                              @click="onProcess('PILOT_PRESCRIPTION', lotVo)">
                              <span class="lot-tag__color lot-tag__color2"></span>파일럿처방
                            </button>
                            <button v-if="mixmatUtils.getBtnShow('DECIDE', lotVo, info)" class="lot-tag lot-tag__step3"
                              @click="onProcess('DECIDE_PRESCRIPTION', lotVo)">
                              <span class="lot-tag__color lot-tag__color3"></span>처방확정
                            </button>
                            <button v-if="mixmatUtils.getBtnShow('INGREDIENT', lotVo, info)"
                              class="lot-tag lot-tag__step4" @click="onProcess('INGREDIENT_APPR')">
                              <span class="lot-tag__color lot-tag__color4"></span>전성분승인
                            </button>
                            <button v-if="1 === 2" class="lot-tag lot-tag__step5">
                              <span class="lot-tag__color lot-tag__color5"></span>입고완료
                            </button>
                            <!-- <button v-if="mixmatUtils.getBtnShow('RELEASE', lotVo, info)" class="lot-tag lot-tag__step6"
                              @click="onProcess('RELEASE_COMPLETE')">
                              <span class="lot-tag__color lot-tag__color6"></span>출시완료
                            </button> -->
                            <button v-if="mixmatUtils.getBtnShow('CANCEL', lotVo, info)"
                              class="lot-tag lot-tag lot-tag__border-red" @click="onProcess('DECIDE_CANCEL', lotVo)">
                              <span class="lot-tag__color lot-tag__color-red"></span>확정해제
                            </button>
                          </div>
                        </div>
                      </div>
                    </th>
                  </template>
                </tr>
                <tr class="thead">
                  <template v-for="lotVo in gridVars.lots" :key="'lot2_' + lotVo.vLotCd">
                    <template v-if="lotVo.vFlagExposure !== 'N'">
                      <th class="th-content col-1" :class="[
                        lotVo.activeYn === 'Y' ? 'border-left__blue' : '',
                        lotVo.activeYn === 'N' && lotVo.openYn === 'Y' ? '' : lotVo.borderClass,
                      ]" :style="{ height: gridStyle.size.headerHeight + 'px' }"
                        @contextmenu.prevent="onContextHeader($event, lotVo)">
                        함량
                      </th>
                      <template v-if="lotVo.activeYn === 'Y' && lotVo.grams">
                        <th v-for="(gramVo, gramIndex) in lotVo.grams" :key="'gram2_' + gramIndex"
                          :style="{ height: gridStyle.size.headerHeight + 'px' }" class="th-gram col-2" :class="[
                            lotVo.activeYn === 'Y' && lotVo.openYn !== 'Y' && gramIndex == lotVo.grams.length - 1 ? 'border-right__blue' : ''
                          ]" @contextmenu.prevent="onContextHeader($event, lotVo)">
                          <template v-if="lotVo.vFlagComplete === 'Y' || info.rvo.vStatusCd === 'LNC06_50'">
                            {{ gramVo.nGram }}g
                          </template>
                          <template v-else>
                            <ap-input inputClass="material-calc__form" v-model:value="gramVo.nGram" :isNumber="true"
                              :point="5" :maxlength="7" @click="mixmatUtils.onFocusClear()"
                              @keypress="onLotGramChange(lotVo, true)" />
                          </template>
                        </th>
                      </template>
                      <th v-if="lotVo.openYn === 'Y'" class="apg-text-right" :class="[
                        lotVo.activeYn === 'Y' ? 'border-right__blue' : '',
                        lotVo.borderClass,
                      ]" :style="{ height: gridStyle.size.headerHeight + 'px' }">
                        <div class="lot-open">
                          <div class="lot-open__buttons">
                            <button v-if="mixmatUtils.getBtnShow('ORDER_BY', lotVo, info)" type="button"
                              class="lot-open__button lot-open__button--re-order" @click="onMateOrderChangePop(lotVo)">
                              <span class="for-a11y">순서변경</span>
                              <span class="lot-open__button-tooltip button-tooltip--reOrder">순서변경</span>
                            </button>
                            <button v-if="mixmatUtils.getBtnShow('CHECK_INGREDIENT', lotVo, info)" type="button"
                              class="lot-open__button lot-open__button--all-check" @click="onDefaultIngredientDataPop">
                              <span class="for-a11y">전성분 확인</span>
                              <span class="lot-open__button-tooltip button-tooltip--allCheck">전성분 확인</span>
                            </button>
                          </div>
                        </div>
                      </th>
                    </template>
                  </template>
                </tr>
              </tbody>
            </table>
          </div>
          <!--// [e] CENTER HEADER -->

          <!--// [s] CENTER BODY -->
          <div ref="refDivBodyCenter" class="anypjt-grid-body-center" :style="gridStyle.divBodyCenterStyle">
            <div ref="refDivBodyCenterSelectLayer" class="anypjt-grid-body-center-select-layer"
              :style="gridStyle.commonMarginTopLeftStyle"></div>
            <div ref="refDivBodyCenterInput" class="apg-layer-input apg-input-mode"
              :class="gridVars.inputMode.show && gridVars.inputMode.tableId === 'tableBodyCenter' ? 'active' : ''"
              :style="gridStyle.commonMarginTopLeftStyle">
              <input type="text" class="apg-input-mode" style="width: 100px;"
                @keydown.enter="mixmatUtils.fnInputValueChange($event)"
                @keydown.tab="mixmatUtils.fnInputValueChange($event)"
                @focusout="mixmatUtils.fnInputValueChange($event, true), onLotRateChange()" />
              <p class="apg-inp-message"></p>
            </div>
            <table ref="refTableBodyCenter" id="tableBodyCenter"
              class="ui-table__reset material-excel__table text-center anypjt-grid-body-center"
              :style="gridStyle.tableBodyCenterStyle">
              <colgroup>
                <template v-for="lotVo in gridVars.lots" :key="'col_body_center_' + lotVo.vLotCd">
                  <template v-if="lotVo.vFlagExposure !== 'N'">
                    <col style="width: 100px" />
                    <template v-if="lotVo.activeYn === 'Y' && lotVo.grams">
                      <col v-for="gramVo in lotVo.grams" :key="'gram3_' + gramVo.gramSeq" style="width: 80px" />
                    </template>
                    <col v-if="lotVo.openYn === 'Y'" style="width: 250px" />
                  </template>
                </template>
              </colgroup>
              <tbody>
                <template v-for="(mateVo, ridx) in gridVars.materials" :key="'mate2_' + mateVo.matSeq">
                  <tr v-if="canShowMateOrGroup(mateVo)" class="anypjt-grid-tr" :class="[
                    mateVo.vRecType === 'GRP' ? 'tr-group anypjt-grid-tr-group' : '',
                    mateVo.rowSelectYn === 'Y' ? 'is-active apg-tr-select' : '',
                    `anypjt-grid-tr-ridx-${ridx}`
                  ]" :data-row-idx="ridx" :data-row-type="mateVo.vRecType"
                    @mouseover="mixmatUtils.onTrMouseover($event, ridx)"
                    @mouseout="mixmatUtils.onTrMouseout($event, ridx)"
                    @contextmenu.prevent="!mateVo.vParentMatePkCd ? onContextMenu($event, mateVo) : ''">
                    <template v-for="lotVo in gridVars.lots" :key="'lot_data_' + lotVo.vLotCd">
                      <AllLabNoteMaterialBodyCenter v-if="lotVo.vFlagExposure !== 'N'" :lot-vo="lotVo" :mate-vo="mateVo"
                        :rvo="info.rvo" :rate-vo="mixmatUtils.getRateVo(lotVo.vLotCd, mateVo.vMatePkCd)"
                        :bf-lot-vo="info.bfLotVo" :row-index="ridx" :scroll-postion="scrollPostion"
                        :rowspan="gridVars.materials.length" :div-lot-test-result-style="gridStyle.divLotTestResultStyle"
                        :test-cd-list="info.testCdList" @onRateOneLotSelect="onRateOneLotSelect"
                        @onMateTestResultRegPop="onMateTestResultRegPop" @onLotGramChange="onLotGramChange">
                      </AllLabNoteMaterialBodyCenter>
                    </template>
                  </tr>
                </template>
              </tbody>
            </table>
          </div>
          <!--// [e] CENTER BODY -->

          <!--// [s] CENTER FOOTER -->
          <div ref="refDivFooterCenter" class="anypjt-grid-footer-center" :style="gridStyle.divFooterCenterStyle">
            <table ref="refTableFooterCenter"
              class="ui-table__reset material-excel__table text-center anypjt-grid-footer-center"
              :style="gridStyle.tableFooterCenterStyle">
              <colgroup>
                <template v-for="lotVo in gridVars.lots" :key="'lot_colgroup3_' + lotVo.vLotCd">
                  <template v-if="lotVo.vFlagExposure !== 'N'">
                    <col style="width: 100px" />
                    <template v-if="lotVo.activeYn === 'Y' && lotVo.grams">
                      <col v-for="gramVo in lotVo.grams" :key="'gram4_' + gramVo.gramSeq" style="width: 80px" />
                    </template>
                    <col v-if="lotVo.openYn === 'Y'" style="width: 250px" />
                  </template>
                </template>
              </colgroup>
              <tbody>
                <tr v-if="!commonUtils.isEmpty(info?.rvo)" class="tfoot border-top__deepgray"
                  :style="{ height: gridStyle.size.columnHeight }">
                  <template v-for="lotVo in gridVars.lots" :key="'lot_data_' + lotVo.vLotCd">
                    <template v-if="lotVo.vFlagExposure !== 'N'">
                      <td class="tf-lot anypjt-grid-td apg-text-right" :class="[
                        lotVo.activeYn === 'Y' ? 'border-left__blue' : '',
                        lotVo.activeYn === 'Y' && mixmatUtils.getLotBottomLine('sumData'),
                        lotVo.activeYn === 'N' && lotVo.openYn === 'Y' ? '' : lotVo.borderClass,
                      ]" :style="gridStyle.tdCellStyle">
                        {{ summaryDatas['lot_' + lotVo.vLotCd] }}
                      </td>
                      <template v-if="lotVo.activeYn === 'Y'">
                        <td v-for="(gramVo, gramIndex) in lotVo.grams" :key="'gram5_' + gramVo.gramSeq"
                          class="tf-lot anypjt-grid-td apg-text-right" :class="[
                            lotVo.activeYn === 'Y' && lotVo.openYn !== 'Y' && gramIndex == lotVo.grams.length - 1 ? 'border-right__blue' : '',
                            lotVo.activeYn === 'Y' && mixmatUtils.getLotBottomLine('sumData'),
                          ]" :style="gridStyle.tdCellStyle">
                          {{ summaryDatas['gram_' + gramVo.gramSeq] }}
                        </td>
                      </template>
                      <td v-if="lotVo.openYn === 'Y'" class="tf-lot anypjt-grid-td apg-text-center" :class="[
                        lotVo.activeYn === 'Y' ? 'border-right__blue' : '',
                        lotVo.activeYn === 'Y' && mixmatUtils.getLotBottomLine('sumData'),
                        lotVo.borderClass,
                      ]">
                      </td>
                    </template>
                  </template>
                </tr>
                <!-- <tr class="tfoot" :style="{ height: gridStyle.size.columnHeight }">
                  <template v-for="lotVo in gridVars.lots" :key="'lot_data_' + lotVo.vLotCd">
                    <td class="tf-lot anypjt-grid-td apg-text-right" :class="[
                        lotVo.activeYn === 'Y' ? 'border-left__blue' : '',
                        lotVo.activeYn === 'N' && lotVo.openYn === 'Y' ? '' : lotVo.borderClass,
                      ]" :style="gridStyle.tdCellStyle">
                    </td>
                    <template v-if="lotVo.activeYn === 'Y'">
                      <td v-for="(gramVo, gramIndex) in lotVo.grams" :key="'gram5_' + gramVo.gramSeq"
                        class="tf-lot anypjt-grid-td apg-text-right" :class="[
                            lotVo.activeYn === 'Y' && lotVo.openYn !== 'Y' && gramIndex == lotVo.grams.length - 1 ? 'border-right__blue' : ''
                          ]" :style="gridStyle.tdCellStyle">
                      </td>
                    </template>
                    <td v-if="lotVo.openYn === 'Y'" class="tf-lot anypjt-grid-td apg-text-center" :class="[
                        lotVo.activeYn === 'Y' ? 'border-right__blue' : '',
                        lotVo.borderClass,
                      ]">
                    </td>
                  </template>
                </tr> -->
                <tr v-if="gridVars.rowsForzen.musogu === 'N'" class="tfoot"
                  :style="{ height: gridStyle.size.columnHeight }">
                  <template v-for="lotVo in gridVars.lots" :key="'lot_data_' + lotVo.vLotCd">
                    <template v-if="lotVo.vFlagExposure !== 'N'">
                      <td class="tf-lot anypjt-grid-td apg-text-right" :class="[
                        lotVo.activeYn === 'Y' ? 'border-left__blue' : '',
                        lotVo.activeYn === 'Y' && mixmatUtils.getLotBottomLine('musogu'),
                        lotVo.activeYn === 'N' && lotVo.openYn === 'Y' ? '' : lotVo.borderClass,
                      ]" :style="gridStyle.tdCellStyle">
                        <template v-for="(number, numberIndex) in info.numberList" :key="numberIndex">
                          <template v-if="lotVo.vLotCd === number.vLotCd">
                            <a href="javascript:void(0)" class="tf-lot__link" @click="onMusoguPop(lotVo)">
                              {{ number.nCnt }} / {{ info.deno }}
                            </a>
                          </template>
                        </template>
                        <template
                          v-if="!info.numberList || info.numberList.filter(number => number.vLotCd === lotVo.vLotCd).length === 0">
                          <a href="javascript:void(0)" class="tf-lot__link" @click="onMusoguPop(lotVo)">
                            0 / {{ info.deno }}
                          </a>
                        </template>
                      </td>
                      <template v-if="lotVo.activeYn === 'Y'">
                        <td v-for="(gramVo, gramIndex) in lotVo.grams" :key="'gram5_' + gramVo.gramSeq"
                          class="tf-lot anypjt-grid-td apg-text-right" :class="[
                            lotVo.activeYn === 'Y' && lotVo.openYn !== 'Y' && gramIndex == lotVo.grams.length - 1 ? 'border-right__blue' : '',
                            lotVo.activeYn === 'Y' && mixmatUtils.getLotBottomLine('musogu'),
                          ]" :style="gridStyle.tdCellStyle">
                        </td>
                      </template>
                      <td v-if="lotVo.openYn === 'Y'" class="tf-lot anypjt-grid-td apg-text-center" :class="[
                        lotVo.activeYn === 'Y' ? 'border-right__blue' : '',
                        lotVo.activeYn === 'Y' && mixmatUtils.getLotBottomLine('musogu'),
                        lotVo.borderClass,
                      ]">
                      </td>
                    </template>
                  </template>
                </tr>
                <tr v-if="gridVars.rowsForzen.priceSum === 'N'" class="tfoot"
                  :style="{ height: gridStyle.size.columnHeight }">
                  <template v-for="lotVo in gridVars.lots" :key="'lot_data_' + lotVo.vLotCd">
                    <template v-if="lotVo.vFlagExposure !== 'N'">
                      <td class="tf-lot anypjt-grid-td apg-text-right" :class="[
                        lotVo.activeYn === 'Y' ? 'border-left__blue' : '',
                        lotVo.activeYn === 'Y' && mixmatUtils.getLotBottomLine('priceSum'),
                        lotVo.activeYn === 'N' && lotVo.openYn === 'Y' ? '' : lotVo.borderClass,
                      ]"
                        :style="[gridStyle.tdCellStyle, info.rvo.nTargetCost < lotVo.sumPrice ? 'color: #ff3434' : '']">
                        {{ lotVo.sumPrice }}
                      </td>
                      <template v-if="lotVo.activeYn === 'Y'">
                        <td v-for="(gramVo, gramIndex) in lotVo.grams" :key="'gram5_' + gramVo.gramSeq"
                          class="tf-lot anypjt-grid-td apg-text-right" :class="[
                            lotVo.activeYn === 'Y' && lotVo.openYn !== 'Y' && gramIndex == lotVo.grams.length - 1 ? 'border-right__blue' : '',
                            lotVo.activeYn === 'Y' && mixmatUtils.getLotBottomLine('priceSum'),
                          ]" :style="gridStyle.tdCellStyle">
                        </td>
                      </template>
                      <td v-if="lotVo.openYn === 'Y'" class="tf-lot anypjt-grid-td apg-text-center" :class="[
                        lotVo.activeYn === 'Y' ? 'border-right__blue' : '',
                        lotVo.activeYn === 'Y' && mixmatUtils.getLotBottomLine('priceSum'),
                        lotVo.borderClass,
                      ]">
                      </td>
                    </template>
                  </template>
                </tr>
                <tr v-if="gridVars.rowsForzen.noi === 'N'" class="tfoot" :style="{ height: gridStyle.size.columnHeight }">
                  <template v-for="lotVo in gridVars.lots" :key="'lot_data_' + lotVo.vLotCd">
                    <template v-if="lotVo.vFlagExposure !== 'N'">
                      <td class="tf-lot anypjt-grid-td apg-text-right" :class="[
                        lotVo.activeYn === 'Y' ? 'border-left__blue' : '',
                        lotVo.activeYn === 'Y' && mixmatUtils.getLotBottomLine('noi'),
                        lotVo.activeYn === 'N' && lotVo.openYn === 'Y' ? '' : lotVo.borderClass,
                      ]" :style="gridStyle.tdCellStyle">
                        {{ commonUtils.getDecimalPointFormat(summaryDatas['noi_' + lotVo.vLotCd], 7) }}
                      </td>
                      <template v-if="lotVo.activeYn === 'Y'">
                        <td v-for="(gramVo, gramIndex) in lotVo.grams" :key="'gram5_' + gramVo.gramSeq"
                          class="tf-lot anypjt-grid-td apg-text-right" :class="[
                            lotVo.activeYn === 'Y' && lotVo.openYn !== 'Y' && gramIndex == lotVo.grams.length - 1 ? 'border-right__blue' : '',
                            lotVo.activeYn === 'Y' && mixmatUtils.getLotBottomLine('noi'),
                          ]" :style="gridStyle.tdCellStyle">
                        </td>
                      </template>
                      <td v-if="lotVo.openYn === 'Y'" class="tf-lot anypjt-grid-td apg-text-center" :class="[
                        lotVo.activeYn === 'Y' ? 'border-right__blue' : '',
                        lotVo.activeYn === 'Y' && mixmatUtils.getLotBottomLine('noi'),
                        lotVo.borderClass,
                      ]">
                      </td>
                    </template>
                  </template>
                </tr>
                <tr v-if="gridVars.rowsForzen.biodegradability === 'N'" class="tfoot"
                  :style="{ height: gridStyle.size.columnHeight }">
                  <template v-for="lotVo in gridVars.lots" :key="'lot_data_' + lotVo.vLotCd">
                    <template v-if="lotVo.vFlagExposure !== 'N'">
                      <td class="tf-lot anypjt-grid-td apg-text-right" :class="[
                        lotVo.activeYn === 'Y' ? 'border-left__blue border-bottom__blue' : '',
                        lotVo.activeYn === 'N' && lotVo.openYn === 'Y' ? '' : lotVo.borderClass,
                      ]" :style="gridStyle.tdCellStyle">
                        {{ commonUtils.getDecimalPointFormat(summaryDatas['bio_' + lotVo.vLotCd], 2) }}
                      </td>
                      <template v-if="lotVo.activeYn === 'Y'">
                        <td v-for="(gramVo, gramIndex) in lotVo.grams" :key="'gram5_' + gramVo.gramSeq"
                          class="tf-lot anypjt-grid-td apg-text-right" :class="[
                            lotVo.activeYn === 'Y' ? 'border-bottom__blue' : '',
                            lotVo.activeYn === 'Y' && lotVo.openYn !== 'Y' && gramIndex == lotVo.grams.length - 1 ? 'border-right__blue' : ''
                          ]" :style="gridStyle.tdCellStyle">
                        </td>
                      </template>
                      <td v-if="lotVo.openYn === 'Y'" class="tf-lot anypjt-grid-td apg-text-center" :class="[
                        lotVo.activeYn === 'Y' ? 'border-right__blue border-bottom__blue' : '',
                        lotVo.borderClass,
                      ]">
                      </td>
                    </template>
                  </template>
                </tr>
              </tbody>
            </table>
            <div ref="refDivBodyScrollX" class="anypjt-grid-body-scroll-x" :style="gridStyle.divBodyScrollXStyle">
              <div :style="gridStyle.divDummyFooterScrollCenter"></div>
            </div>
          </div>
          <!--// [e] CENTER FOOTER -->
        </div>

        <div class="apg-grid-scroll-y">
          <button v-if="info.otherVO.vFlagDisabled !== 'Y'" class="button-plus__lot" style="width: 1.3rem;"
            @click="onAddLot"></button>

          <div ref="refDivHeaderScrollY" :style="gridStyle.divHeaderScrollYStyle" style="display: none;"></div>
          <div ref="refDivBodyScrollY" class="anypjt-grid-body-scroll-y" :style="gridStyle.divBodyScrollYStyle"
            style="display: none;">
            <table class="ui-table__reset material-excel__table text-center anypjt-grid-body-scroll-y"
              :style="gridStyle.tableBodyScrollYStyle">
              <tbody>
                <template v-for="mateVo in gridVars.materials" :key="'mate3_' + mateVo.matSeq">
                  <tr v-if="canShowMateOrGroup(mateVo)" class="anypjt-grid-tr" :class="[
                    mateVo.vRecType === 'GRP' ? 'tr-group anypjt-grid-tr-group' : '',
                  ]">
                    <td class="anypjt-grid-td">
                      <div class="anypjt-grid-cell" :style="{ width: '5px' }"></div>
                    </td>
                  </tr>
                </template>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <context-menu v-model:show="contextMenu.isShowMate" :options="contextMenu">
    <context-menu-item label="남은 함량 자동계산" :disabled="contextMenu.isHideRateRest"
      @click="onContextMenuItemClick('RATE_REST')">
      <template #icon><img src="/src/assets/images/icon/icon-calc__black.png" style="width: 16px;"></template>
    </context-menu-item>
    <context-menu-item label="자동계산 삭제" :disabled="contextMenu.isRateRest"
      @click="onContextMenuItemClick('DELETE_RATE_REST')" />
    <!-- <div class="mx-context-menu-item-sperator mx-context-no-clickable"></div>
    <context-menu-item label="원료코드 붙여넣기" @click="onContextMenuItemClick('PASTE_MATE')">
      <template #icon><img src="/src/assets/images/icon/icon-insert.png" style="width: 16px;"></template>
    </context-menu-item> -->
    <div class="mx-context-menu-item-sperator mx-context-no-clickable"></div>
    <context-menu-item label="행 삽입" :disabled="contextMenu.isHideRowAdd" @click="onContextMenuItemClick('ADD_ROW')">
      <template #icon><img src="/src/assets/images/icon/icon-insert.png" style="width: 16px;"></template>
    </context-menu-item>
    <context-menu-item label="행 삭제" :disabled="contextMenu.isDelete" @click="onContextMenuItemClick('DELETE_MATE')">
      <template #icon><img src="/src/assets/images/icon/icon-delete.png" style="width: 16px;"></template>
    </context-menu-item>
    <context-menu-item label="그룹추가" @click="onContextMenuItemClick('ADD_GROUP')">
      <template #icon><img src="/src/assets/images/icon/icon-group.png" style="width: 16px;"></template>
    </context-menu-item>
    <div class="mx-context-menu-item-sperator mx-context-no-clickable"></div>
    <context-menu-item label="위로 이동" shortcut="(Alt + ↑)" @click="onContextMenuItemClick('UP_MATE')">
      <template #icon><img src="/src/assets/images/icon/icon-arrow__up.png" style="width: 14px;"></template>
    </context-menu-item>
    <context-menu-item label="아래로 이동" shortcut="(Alt + ↓)" @click="onContextMenuItemClick('DOWN_MATE')">
      <template #icon><img src="/src/assets/images/icon/icon-arrow__down.png" style="width: 14px;"></template>
    </context-menu-item>
    <div class="mx-context-menu-item-sperator mx-context-no-clickable"></div>
    <context-menu-item label="숨기기" :disabled="contextMenu.isHideMate" @click="onContextMenuItemClick('HIDE_MATE')">
      <template #icon><img src="/src/assets/images/icon/icon-hide.png" style="width: 16px;"></template>
    </context-menu-item>
    <context-menu-item v-if="contextMenu.isHide" label="숨기기 취소" @click="onContextMenuItemClick('SHOW_MATE')" />
    <template v-if="contextMenu.isMakeup">
      <div class="mx-context-menu-item-sperator mx-context-no-clickable"></div>
      <context-menu-item v-if="!contextMenu.isColorMate" label="조색 원료 표시"
        @click="onContextMenuItemClick('MU_MATE_CHECK_Y')" />
      <context-menu-item v-else label="조색 원료 해제" @click="onContextMenuItemClick('MU_MATE_CHECK_N')" />
    </template>
    <template v-if="contextMenu.isHbd">
      <div class="mx-context-menu-item-sperator mx-context-no-clickable"></div>
      <context-menu-item v-if="!contextMenu.isMainMate" label="주성분 원료 표시"
        @click="onContextMenuItemClick('HBD_MATE_CHECK_Y')" />
      <context-menu-item v-else label="주성분 원료 해제" @click="onContextMenuItemClick('HBD_MATE_CHECK_N')" />
    </template>
    <template v-if="contextMenu.isQdrug">
      <div class="mx-context-menu-item-sperator mx-context-no-clickable"></div>
      <context-menu-item label="의약외품 전성분 미리보기" @click="onContextMenuItemClick('QDRUG_INGREDIENT_REVIEW')" />
    </template>
  </context-menu>
  <context-menu v-model:show="contextMenu.isShowGrp" :options="contextMenu">
    <context-menu-item label="위로 이동" shortcut="(Alt + ↑)" @click="onContextMenuItemClick('UP_GRP')">
      <template #icon><img src="/src/assets/images/icon/icon-arrow__up.png" style="width: 14px;"></template>
    </context-menu-item>
    <context-menu-item label="아래로 이동" shortcut="(Alt + ↓)" @click="onContextMenuItemClick('DOWN_GRP')">
      <template #icon><img src="/src/assets/images/icon/icon-arrow__down.png" style="width: 14px;"></template>
    </context-menu-item>
    <!-- <context-menu-item label="그룹명 변경" @click="onContextMenuItemClick('NM_CHG_GRP')">
      <template #icon><img src="/src/assets/images/icon/icon-group.png" style="width: 16px;"></template>
    </context-menu-item> -->
    <div class="mx-context-menu-item-sperator mx-context-no-clickable"></div>
    <context-menu-item label="삭제" :disabled="contextMenu.isDelete" @click="onContextMenuItemClick('DELETE_GRP')">
      <template #icon><img src="/src/assets/images/icon/icon-delete.png" style="width: 16px;"></template>
    </context-menu-item>
  </context-menu>
  <context-menu v-model:show="contextMenu.isShowLotHead" :options="contextMenu">
    <context-menu-item v-if="info.otherVO.vFlagDisabled !== 'Y'" label="함량 복사"
      @click="onContextMenuItemClick('RATE_COPY')">
      <template #icon><img src="/src/assets/images/icon/icon-copy.png" style="width: 14px;"></template>
    </context-menu-item>
    <context-menu-item v-if="info.otherVO.vFlagDisabled !== 'Y'" label="함량 붙여넣기" :disabled="contextMenu.isHidePaste"
      @click="onContextMenuItemClick('RATE_PASTE')" />
    <div v-if="info.otherVO.vFlagDisabled !== 'Y'" class="mx-context-menu-item-sperator mx-context-no-clickable"></div>
    <context-menu-item v-if="info.otherVO.vFlagDisabled !== 'Y'" label="함량 삭제" :disabled="contextMenu.isDelete"
      @click="onContextMenuItemClick('RATE_DELETE')">
      <template #icon><img src="/src/assets/images/icon/icon-delete.png" style="width: 16px;"></template>
    </context-menu-item>
    <div v-if="info.otherVO.vFlagDisabled !== 'Y'" class="mx-context-menu-item-sperator mx-context-no-clickable"></div>
    <context-menu-item v-if="info.otherVO.vFlagDisabled !== 'Y'" label="그램 추가" :disabled="contextMenu.isDelete"
      @click="onContextMenuItemClick('ADD_GRAM')">
      <template #icon><img src="/src/assets/images/icon/icon-insert.png" style="width: 16px;"></template>
    </context-menu-item>
    <context-menu-item v-if="info.otherVO.vFlagDisabled !== 'Y'" label="그램 삭제"
      @click="onContextMenuItemClick('DELETE_GRAM')">
      <template #icon><img src="/src/assets/images/icon/icon-delete.png" style="width: 16px;"></template>
    </context-menu-item>
    <div v-if="info.otherVO.vFlagDisabled !== 'Y'" class="mx-context-menu-item-sperator mx-context-no-clickable"></div>
    <context-menu-item label="기존 처방 등록하기" :disabled="contextMenu.isHideBookmark"
      @click="onContextMenuItemClick('REG_BOOKMARK')">
      <template #icon><img src="/src/assets/images/icon/icon-enroll.png" style="width: 16px;"></template>
    </context-menu-item>
    <context-menu-item v-if="noteType === 'MU' && info.contVO.vFlagRepresent === 'Y'" label="베이스 처방 등록하기"
      :disabled="contextMenu.isHideBase" @click="onContextMenuItemClick('REG_BASE')">
      <template #icon><img src="/src/assets/images/icon/icon-enroll.png" style="width: 16px;"></template>
    </context-menu-item>
    <div class="mx-context-menu-item-sperator mx-context-no-clickable"></div>
    <context-menu-item label="일반 라벨 출력" @click="onContextMenuItemClick('QRCODE_LOT')">
      <template #icon><img src="/src/assets/images/icon/icon-print.png" style="width: 16px;"></template>
    </context-menu-item>
    <context-menu-item label="표준품 라벨 출력" @click="onContextMenuItemClick('QRCODE_STANDARD_LOT')">
      <template #icon><img src="/src/assets/images/icon/icon-print.png" style="width: 16px;"></template>
    </context-menu-item>
  </context-menu>
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component :is="popupContent" :pop-params="popParams" @selectFunc="popSelectFunc"
        @selectFuncHal4LotSet="popSelectFunc" @updateFlagMateCheck="popSelectFunc" />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, computed, inject, onMounted, onUpdated, reactive, ref, watch, nextTick } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useMaterialCommon } from '@/compositions/labcommon/useMaterialCommon'
import { useStore } from 'vuex'
import { useRouter } from 'vue-router'
import { useActions } from 'vuex-composition-helpers'
import mixmatUtils from '@/utils/mixmatUtils'

import AllLabNoteMaterialBodyCenter from '@/components/labcommon/AllLabNoteMaterialBodyCenter.vue'
import AllLabNoteMaterialBodyLeft from '@/components/labcommon/AllLabNoteMaterialBodyLeft.vue'
import AllLabNoteMaterialTab from '@/components/labcommon/AllLabNoteMaterialTab.vue'
import Big from 'big.js'

export default ({
  name: 'AllLabNoteMaterialTable',
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    BomSendPop: defineAsyncComponent(() => import('@/components/labcommon/popup/BomSendPop.vue')),
    DefaultIngredientDataPop: defineAsyncComponent(() => import('@/components/labcommon/popup/DefaultIngredientDataPop.vue')),
    Hal4LotSetPop: defineAsyncComponent(() => import('@/components/labcommon/popup/Hal4LotSetPop.vue')),
    IngredientPop: defineAsyncComponent(() => import('@/components/labcommon/popup/IngredientPop.vue')),
    LotQrCodePop: defineAsyncComponent(() => import('@/components/labcommon/popup/LotQrCodePop.vue')),
    MateSearchPop: defineAsyncComponent(() => import('@/components/labcommon/popup/MateSearchPop.vue')),
    MateOrderChangePop: defineAsyncComponent(() => import('@/components/labcommon/popup/MateOrderChangePop.vue')),
    MateProblemHisPop: defineAsyncComponent(() => import('@/components/labcommon/popup/MateProblemHisPop.vue')),
    MaterialMusoguPop: defineAsyncComponent(() => import('@/components/labcommon/popup/MaterialMusoguPop.vue')),
    MateTestResultRegPop: defineAsyncComponent(() => import('@/components/labcommon/popup/MateTestResultRegPop.vue')),
    MaxMixPop: defineAsyncComponent(() => import('@/components/labcommon/popup/MaxMixPop.vue')),
    SaIngrPermissionPop: defineAsyncComponent(() => import('@/components/labcommon/popup/SaIngrPermissionPop.vue')),
    AllLabNoteMaterialTab,
    AllLabNoteMaterialBodyCenter,
    AllLabNoteMaterialBodyLeft,
  },
  mounted() {
    document.addEventListener('paste', mixmatUtils.onPaste)
    document.addEventListener('copy', mixmatUtils.onCopy)
    document.addEventListener('keydown', mixmatUtils.onKeydown)
    document.addEventListener('click', mixmatUtils.onClick)
  },
  unmounted() {
    document.removeEventListener('paste', mixmatUtils.onPaste)
    document.removeEventListener('copy', mixmatUtils.onCopy)
    document.removeEventListener('keydown', mixmatUtils.onKeydown)
    document.removeEventListener('click', mixmatUtils.onClick)
  },
  emits: [
    'onTabClick',
    'onLotClick',
    'onVerNmChange',
    'onChangeMateList',
    'onChangeRateList',
    'onAddMateAndGrp',
    'onIsChange',
  ],
  setup(props, context) {
    const reqInfo = inject('reqInfo')
    const commonUtils = inject('commonUtils')
    const store = useStore()
    const router = useRouter()
    const { openAsyncConfirm, openAsyncAlert } = useActions(['openAsyncConfirm', 'openAsyncAlert'])
    const myInfo = store.getters.getMyInfo()
    const noteType = store.getters.getNoteType()
    const noteTypeNm = store.getters.getNoteTypeNm()
    const info = ref({
      rvo: {},
      contVO: {},
      verVO: {},
      mateList: [],
      lotAllList: [],
      lotList: [],
      rateList: [],
      otherVO: {},
    })
    const contextMenu = reactive({
      isShowMate: false,
      isShowGrp: false,
      zIndex: 3,
      minWidth: 230,
      x: 500,
      y: 200,
      isHide: false,
      isHideMate: false,
      hideMatePx: 'height: 5px',
      isDelete: false,
      isRateRest: true,
      isAllRowRate: true,
      rateEmptyLotNum: -1,
      isOneRateRest: false,
      isHideRateRest: false,
      isHideRowAdd: false,
      isHidePaste: true,
      isHideBookmark: true,
      isHideBase: true,
      isMakeup: false,
      isColorMate: false,
      isHbd: false,
      isMainMate: false,
      isQdrug: false,
    })
    const selectedRows = ref([])
    const selectedGrps = ref([])
    const selectedLot = ref(null)
    const pasteLot = ref(null)

    const refDivGridWrap = ref(null)
    const refGridFocus = ref(null)

    const refDivHeaderCenter = ref(null)

    const refDivBodyLeft = ref(null)
    const refDivBodyLeftSelectLayer = ref(null)
    const refTableBodyLeft = ref(null)
    const refDivBodyLeftInput = ref(null)
    const refLayerMateMemoWrap = ref(null)

    const refDivBodyCenter = ref(null)
    const refDivBodyCenterSelectLayer = ref(null)
    const refDivBodyCenterInput = ref(null)
    const refDivFooterCenter = ref(null)
    const refTableBodyCenter = ref(null)

    const refDivBodyScrollX = ref(null)
    const refDivBodyScrollY = ref(null)
    const refContextMenuWrap = ref(null)

    const scrollPostion = reactive({
      top: 0,
      left: 0,
    })

    const gridheight = reactive({
      body: 0
    })

    const pageVars = reactive({
      helpLayer: {
        showNoi: false,
        showBio: false,
      }
    })

    const gridVars = reactive({
      materials: [],
      lots: [],
      ratesMap: {},
      isShowMateMemo: false,
      inputMode: {
        show: false,
        tableId: '',
        columnId: '',
      },
      isMouseDown: false,
      isFocusCell: false,
      focusCell: {},
      isMultipleSelect: false,
      isShowMenuCell: false,
      contextMenuCellStyle: {
        top: '0px',
        left: '0px',
      },
      isShowMenuHeader: false,
      contextMenuHeaderStyle: {
        top: '0px',
        left: '0px',
      },
      startCell: {},
      endCell: {},
      rowSelect: {
        isSelect: false,
        startIndex: -1,
      },
      mousePrevTarget: undefined,
      addMateIdx: 0,
      addLotIdx: 0,
      addGramIdx: 0,
      columnsForzenLeft: [],
      rowsForzen: [],
    })
    const pasteInfo = reactive({
      tableId: '',
      pasteVal: '',
      failVal: '',
    })
    const draggable = reactive({
      drop: false,
    })
    const defInit = reactive({
      clear: true,
    })

    const {
      list,
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      fnOpenMateSearchPop,
      selectSearchMateList,
      updateDecideCancel,
    } = useLabCommon()

    const {
      selectMaterialFormulationSum,
      selectLabNoteSubMateRateInfo,
      updateLabNoteLotBookmark,
      selectElabLotMemoList,
      updateLabNoteLotBase,
    } = useMaterialCommon()

    watch(
      () => reqInfo.value,
      (o) => {
        if (!o) {
          return
        }

        info.value = { ...info.value, ...o }

        if (o.constructor !== Object) {
          return
        }

        gridVars.reqInfo = reqInfo.value
        gridVars.info = info.value

        gridVars.columnsForzenLeft = o.columnsForzenLeft
        gridVars.rowsForzen = o.rowsForzen

        let len = 0
        gridVars.materials = o.mateList.map((mate) => {
          return mate = {
            ...mate,
            nMateNum: mate.vRecType !== 'GRP' ? ++len : null
          }
        })
        gridVars.lots = o.lotList

        gridVars.ratesMap = o.rateList.filter(rate => rate.vKey.indexOf('_SUM') < 0).reduce((rateMap, rate) => {
          const lotVo = o.lotList.filter(lot => lot.vLotCd === rate.vLotCd)

          const _rate = new Big(rate.nRate || 0)
          let maxGram, gram
          if (lotVo && lotVo.length > 0) {
            for (let gramVo of lotVo?.[0].grams) {
              if (gramVo.nGram) {
                maxGram = new Big(gramVo.nGram)
                gram = maxGram.times(_rate).div(100).round(4)
                rate['gram_' + gramVo.gramSeq] = gram
              }
            }
          }

          rateMap[rate.vKey] = rate
          return rateMap
        }, {})

        if (noteType === 'MU') {
          if (info.value.rvo.vToningLotCd) {
            info.value.bfLotVo = info.value.lotList.find(lot => lot.vLotCd === info.value.rvo.vToningLotCd)
          }
          else {
            let bfLotIdx = 0
            for (let i = 0; i < info.value.lotList.length; i++) {
              const lot = info.value.lotList[i]
              if (lot.activeYn === 'Y') {
                bfLotIdx = i - 1
                break
              }
            }

            info.value.bfLotVo = bfLotIdx > -1 ? info.value.lotList[bfLotIdx] : null
          }
        }

        // ** tbody height 조절
        gridheight.body = mixmatUtils.getGridHeight()
      }
    )

    const gridStyle = computed(() => {
      const columnForzenLeftWidth = gridVars.columnsForzenLeft.reduce(
        (sum, vo) => sum + vo.width,
        0
      )

      const columnDataWidth = gridVars.lots.filter(lot => lot.vFlagExposure !== 'N').reduce((sum, lotVo) => {
        let width = 100
        let colspan = 1

        if (lotVo.activeYn === 'Y' && lotVo.grams) {
          let gramsLen = lotVo.grams.length

          width += 80 * gramsLen
          colspan += gramsLen
        }
        lotVo.width = {
          lotNm: width + 'px',
          lotOpen: '250px',
        }
        if (lotVo.openYn === 'Y') {
          width += 250
          colspan++
        }
        lotVo.colspan = colspan // colspan 값 셋팅

        return sum + width
      }, 0)

      const size = {
        columnLeftDivWidth: columnForzenLeftWidth + 2 + 'px',
        columnLeftTableWidth: columnForzenLeftWidth + 'px',
        columnForzenLeftWidth: columnForzenLeftWidth + 1 + 'px',
        columnDataWidth: columnDataWidth + 'px',
        headerHeight: 24,
        columnHeight: '36px',
        columnFolderHeight: '24px',
        footerHeight: 'auto',
        yscrollWidth: '12px',
        topHeight: '45px',
      }

      const tableHeaderLeftStyle = {
        width: size.columnLeftTableWidth,
      }

      const divGridLeftStyle = {
        width: size.columnLeftDivWidth,
      }

      const divBodyLeftStyle = {
        height: gridheight.body + 'rem',
      }

      const tableBodyLeftStyle = {
        width: size.columnLeftTableWidth,
        marginTop: scrollPostion.top * -1 + 'px',
      }

      const divHeaderCenterStyle = {
        // width: `calc(100% - ${size.columnLeftDivWidth})`,
        height: size.headerHeight * 2 + 'px',
      }

      const divGridCenterStyle = {
        width: `calc(100% - ${size.columnLeftDivWidth} - ${size.yscrollWidth})`,
      }

      const tableHeaderCenterStyle = {
        width: size.columnDataWidth,
        marginLeft: scrollPostion.left * -1 + 'px',
      }

      const divBodyCenterStyle = {
        width: '100%',
        height: gridheight.body + 'rem',
      }

      const tableBodyCenterStyle = {
        width: size.columnDataWidth,
        marginTop: scrollPostion.top * -1 + 'px',
        marginLeft: scrollPostion.left * -1 + 'px',
      }

      const divHeaderScrollYStyle = {
        height: size.headerHeight + 'px',
      }

      const divBodyScrollYStyle = {
        width: size.yscrollWidth,
        height: gridheight.body + 'rem',
      }

      const tableBodyScrollYStyle = {
        width: '5px',
        border: '1xp solid red'
      }

      const divFooterLeftStyle = {
        width: size.columnForzenLeftWidth,
        height: size.footerHeight,
      }

      const tableFooterLeftStyle = {
        width: size.columnForzenLeftWidth,
      }

      const divFooterCenterStyle = {
        width: '100%',
        height: size.footerHeight,
      }

      const tableFooterCenterStyle = {
        width: size.columnDataWidth,
        marginLeft: scrollPostion.left * -1 + 'px',
      }

      const divBodyScrollXStyle = {
        width: '100%',
        height: '16px',
      }

      const divDummyFooterScrollCenter = {
        width: size.columnDataWidth,
      }

      const divLotTestResultStyle = {
        marginTop: scrollPostion.top + 'px',
        height: gridheight.body + 'rem',
      }

      const commonMarginTopStyle = {
        marginTop: scrollPostion.top * -1 + 'px',
      }

      const commonMarginTopLeftStyle = {
        marginTop: scrollPostion.top * -1 + 'px',
        marginLeft: scrollPostion.left * -1 + 'px',
      }

      return {
        tableHeaderLeftStyle,
        divGridLeftStyle,
        divBodyLeftStyle,
        tableBodyLeftStyle,
        divGridCenterStyle,
        divHeaderCenterStyle,
        tableHeaderCenterStyle,
        divBodyCenterStyle,
        tableBodyCenterStyle,
        tableFooterCenterStyle,
        divHeaderScrollYStyle,
        divBodyScrollYStyle,
        tableBodyScrollYStyle,
        divFooterLeftStyle,
        tableFooterLeftStyle,
        divFooterCenterStyle,
        divBodyScrollXStyle,
        divLotTestResultStyle,
        divDummyFooterScrollCenter,
        commonMarginTopStyle,
        commonMarginTopLeftStyle,
        size
      }
    })

    const summaryDatas = computed(() => {
      const map = {}

      if (!gridVars.ratesMap) {
        return {}
      }

      let rateVo
      let rate, gram, bio, noi
      for (let mateVo of gridVars.materials.filter(mate => !mate.vParentMatePkCd)) {
        for (let lotVo of gridVars.lots) {
          rateVo = gridVars.ratesMap[`${lotVo.vLotCd}_${mateVo.vMatePkCd}`]

          if (!rateVo) {
            continue
          }

          rate = map['lot_' + lotVo.vLotCd]

          if (!rate) {
            rate = new Big(0)
          }

          rate = rate.plus(rateVo.nRate || 0)
          map['lot_' + lotVo.vLotCd] = rate

          for (let gramVo of lotVo.grams) {
            gram = map['gram_' + gramVo.gramSeq]

            if (!gram) {
              gram = new Big(0)
            }

            gram = gram.plus(rateVo['gram_' + gramVo.gramSeq] || 0)
            map['gram_' + gramVo.gramSeq] = gram
          }

          if (mateVo.nBiodRsltVl && rateVo.nRate) {
            bio = map['bio_' + lotVo.vLotCd]

            if (!bio) {
              bio = new Big(0)
            }

            map['bio_' + lotVo.vLotCd] = bio.plus(((rateVo.nRate / 100) * mateVo.nBiodRsltVl) || 0)
          }

          if (mateVo.nNoiRsltVl && rateVo.nRate) {
            noi = map['noi_' + lotVo.vLotCd]

            if (!noi) {
              noi = new Big(0)
            }

            map['noi_' + lotVo.vLotCd] = noi.plus(((rateVo.nRate / 100) * mateVo.nNoiRsltVl) || 0)
          }
        }
      }
      return map
    })

    watch(
      () => pasteInfo.pasteVal,
      (o) => {
        if (pasteInfo.tableId && pasteInfo.pasteVal) {
          pasteMate(pasteInfo.tableId, o, pasteInfo.failVal)
          pasteInfo.tableId = ''
          pasteInfo.pasteVal = ''
          pasteInfo.failVal = ''
        }
      }
    )

    watch(
      () => store.getters.getDragMateInfo().isClone,
      (o) => {
        if (o === false && draggable.drop) {
          draggable.drop = false

          const list = store.getters.getDragMateInfo().list
          let pasteVal = ''
          list.map(val => {
            if (pasteVal) {
              pasteVal += ','
            }
            pasteVal += val.vMateCd
          })
          pasteMate('tableBodyLeft', pasteVal, null, true)
        }
      }
    )

    watch(
      () => info.value.lotAllList,
      (newVal) => {
        store.dispatch('setNoteLotList', {
          list: newVal,
          vVersionTxt: info.value.verVO.vVersionTxt
        })
      }
    )

    watch(
      () =>
        [
          store.getters.getNoteLotList().vLotCd,
          store.getters.getNoteLotList().vFlagExposure,
          store.getters.getNoteLotList().vFlagDecide
        ],
      ([o1, o2, o3]) => {
        if (o1 && o2) {
          let lotVO = gridVars.lots.find(lot => lot.vLotCd === o1)
          lotVO.vFlagExposure = o2
        }
        else if (o1 && o3) {
          context.emit('onTabClick', info.value.verVO.nVersion)
        }
      }
    )

    watch(
      () => store.getters.getSearchMateInfo().isSearch,
      (o) => {
        if (o) {
          getSearchRequMateResult(store.getters.getSearchMateInfo().list)

          store.dispatch('setSearchMateInfo', { isSearch: false })
        }
      })

    const canShowMateOrGroup = (mateVo) => {
      if (mateVo.vRecType === 'MATE') {
        if (mateVo.vFlagMateHide === 'Y') {
          return false
        }
        else if (mateVo.vGrpCd && mateVo.vFlagGrpHide === 'Y') {
          return false
        }
        // else if (mateVo.vGrpCd && mateVo.flagGroupOpen !== 'Y') {
        //   return false
        // }
      }
      // else if (mateVo.vRecType === 'GRP') {
      //   if (mateVo.vFlagGrpHide === 'Y') {
      //     return false
      //   }
      // }
      return true
    }

    const showHideHelpLayer = (id, isShow) => {
      pageVars.helpLayer[id] = isShow
    }

    const fnRawMaterialSearch = async () => {
      const { gridVars } = mixmatUtils.opts
      const { cellData } = gridVars.focusCell

      if (cellData && cellData?.vMatePkCd) {
        gridVars.rowAddMatePkCd = cellData.vMatePkCd
      }

      const $input = refDivBodyLeftInput.value.querySelector(
        '.apg-layer-mate-search-input'
      )

      if (!$input.value) {
        fnOpenMateSearchPop($input.value, 'Y', getSearchRequMateResult)

        mixmatUtils.onFocusClear()
        mixmatUtils.clearMultipleSelectCell()
        return
      }

      await selectSearchMateList({
        vPlantCd: info.value.contVO.vPlantCd,
        vLabNoteCd: info.value.contVO.vLabNoteCd,
        vNoteType: noteType,
        vSiteType: noteType,
        arrKeyword: $input.value,
        nowPageNo: 1
      })

      if (list.value && list.value.length === 1) {
        getSearchRequMateResult(list.value)
      }
      else {
        fnOpenMateSearchPop($input.value, 'Y', getSearchRequMateResult)
      }

      mixmatUtils.onFocusClear()
      mixmatUtils.clearMultipleSelectCell()
    }

    const getSearchRequMateResult = (o) => {
      const { gridVars } = mixmatUtils.opts

      let newMateList = info.value.mateList.
        filter(mate => mate.vRecType === 'GRP' || mate.vMatePkCd.indexOf('tmp_mate_pk_cd') < 0 || mate.isRowAdd)
      const newMateListLen = newMateList.length

      if (gridVars.rowAddMatePkCd) {
        let tmpMateList = []
        newMateList.map(mate => {
          if (gridVars.rowAddMatePkCd === mate.vMatePkCd) {
            gridVars.rowAddMatePkCd = null

            tmpMateList = [
              ...tmpMateList,
              ...o.map((addMate, idx) => {
                return {
                  ...addMate,
                  vMatePkCd: 'add_mate_pk_cd_' + (newMateListLen + idx + 1),
                  vRecType: 'MATE',
                  vLabNoteCd: info.value.contVO.vLabNoteCd,
                  vContPkCd: info.value.contVO.vContPkCd,
                  nVersion: info.value.verVO.nVersion,
                  vMateSimplePrice: addMate.nMateSimplePrice,
                  vMaxMixVer2: addMate.vMateMaxMix,
                  mateIssue: mixmatUtils.getMateTag(
                    addMate,
                    info.value.contVO.vLand1,
                    info.value.mstSetVO.find(set => set.vColumnSetCd === 'COLUMN08')?.vFlagHide,
                    noteType,
                  ),
                  vFlagColorMate: noteType === 'MU' && mixmatUtils.getCheckToningMate(addMate) ? 'Y' : addMate.vFlagColorMate,
                }
              })
            ]
          }
          else {
            tmpMateList.push(mate)
          }
        })

        newMateList = tmpMateList
      }
      else {
        newMateList = [
          ...newMateList,
          ...o.map((mate, idx) => {
            return {
              ...mate,
              vMatePkCd: 'add_mate_pk_cd_' + (newMateListLen + idx + 1),
              vRecType: 'MATE',
              vLabNoteCd: info.value.contVO.vLabNoteCd,
              vContPkCd: info.value.contVO.vContPkCd,
              nVersion: info.value.verVO.nVersion,
              vMateSimplePrice: mate.nMateSimplePrice,
              vMaxMixVer2: mate.vMateMaxMix,
              mateIssue: mixmatUtils.getMateTag(
                mate,
                info.value.contVO.vLand1,
                info.value.mstSetVO.find(set => set.vColumnSetCd === 'COLUMN08')?.vFlagHide,
                noteType,
              ),
              vFlagColorMate: noteType === 'MU' && mixmatUtils.getCheckToningMate(mate) ? 'Y' : mate.vFlagColorMate,
            }
          }),
        ]
      }

      if (newMateList.length < 15) {
        const copyLen = newMateList.length
        for (let i = 0; i < 15 - copyLen; i++) {
          newMateList.push({
            vMatePkCd: 'tmp_mate_pk_cd_' + (i + 1),
          })
        }
      }

      info.value.lotList.map(lot => {
        lot.rateList = [
          ...lot.rateList,
          ...o.map((mate, idx) => {
            const vMatePkCd = 'add_mate_pk_cd_' + (newMateListLen + idx + 1)
            return {
              vMatePkCd,
              vLotCd: lot.vLotCd,
              vKey: lot.vLotCd + '_' + vMatePkCd,
            }
          }),
        ]

        context.emit('onChangeRateList', lot.rateList)
      })

      // context.emit('onChangeMateList', sortMateList(newMateList))
      context.emit('onLotClick', sortMateList(newMateList), info.value.lotList)
      context.emit('onIsChange')
    }

    onMounted(() => {
      mixmatUtils.init({
        refDivGridWrap,
        refGridFocus,
        refDivHeaderCenter,
        refDivBodyLeft,
        refDivBodyLeftSelectLayer,
        refDivBodyCenterInput,
        refTableBodyLeft,
        refDivBodyCenter,
        refDivBodyCenterSelectLayer,
        refTableBodyCenter,
        refDivBodyScrollY,
        refDivBodyScrollX,
        refDivFooterCenter,
        refContextMenuWrap,
        refDivBodyLeftInput,
        refLayerMateMemoWrap,
        gridVars,
        gridheight,
        scrollPostion,
        pasteInfo,
      })
      // grid cell 선택 event
      mixmatUtils.addEvents()
    })

    //////////////////////////////////
    const onTabClick = (o = -1) => {
      context.emit('onTabClick', o)
    }

    const onVerNmChange = (o) => {
      context.emit('onVerNmChange', o)
    }

    const onMusoguPop = (o) => {
      const rateSum = o.rateList.filter(rate => !rate.vMatePkCd)

      if (!o.vLotCd || o.vLotCd === '' || !o.rateList || o.rateList.length === 0 || !rateSum || !rateSum?.[0].nRate || rateSum?.[0].nRate === 0) {
        openAsyncAlert({ message: '무소구 확인 가능한 원료가 없습니다.' })
        return
      }

      popParams.value = {
        vLabNoteCd: info.value?.rvo?.vLabNoteCd,
        vLotCd: o.vLotCd,
        vLand1: info.value?.contVO?.vLand1,
        vNoteType: noteType,
      }
      fnOpenPopup('MaterialMusoguPop', false)
    }

    const onProblemHisPop = (vMateCd) => {
      popParams.value = {
        vLabNoteCd: info.value?.rvo?.vLabNoteCd,
        vMateCd,
        vLand1: info.value?.contVO?.vLand1,
      }
      popSelectFunc.value = updateFlagMateCheck
      fnOpenPopup('MateProblemHisPop', false)
    }

    const updateFlagMateCheck = () => {
      const newMateList = info.value.mateList.find(mate => mate.vMateCd === popParams.value.vMateCd)
      if (newMateList) {
        info.value.mateList.find(mate => mate.vMateCd === popParams.value.vMateCd).vFlagMateCheck = 'Y'
        context.emit('onChangeMateList', info.value.mateList)
        context.emit('onIsChange')
      }
    }

    const onHal4LotSetPop = (o) => {
      if (info.value.otherVO.vFlagDisabled === 'Y') {
        return
      }

      popParams.value = {
        vLabNoteCd: o.vMateLabNoteCd,
        vContPkCd: o.vMateDbMstCd,
        vMatePkCd: o.vMatePkCd,
      }
      popSelectFunc.value = selectFuncHal4LotSet
      fnOpenPopup('Hal4LotSetPop', false)
    }

    const selectFuncHal4LotSet = (verObj, lotObj) => {
      info.value.mateList = info.value.mateList.map(mate => {
        return {
          ...mate,
          vMateDbLotInfoTxt: mate.vMatePkCd === popParams.value.vMatePkCd ? '[' + verObj?.[0].vVersionTxt + ' - ' + lotObj?.[0].vLotNm + ']' : null,
        }
      })

      info.value.lotList = info.value.lotList.map(lot => {
        const rateList = lot.rateList.map(rate => {
          if (lot.activeYn === 'Y') {
            const isHal4 = rate.vMatePkCd === popParams.value.vMatePkCd && lotObj?.[0].vLotCd
            return {
              ...rate,
              vFlagSave: isHal4 ? 'Y' : rate.vFlagSave,
              vHal4VersionTxt: isHal4 ? verObj?.[0].vVersionTxt : null,
              vHal4LotNm: isHal4 ? lotObj?.[0].vLotNm : null,
              vHal4LotCd: isHal4 ? lotObj?.[0].vLotCd : null,
              vMateDbLotCd: isHal4 ? lotObj?.[0].vLotCd : null,
            }
          }
          else {
            return { ...rate }
          }
        })

        return {
          ...lot,
          rateList,
        }
      })

      context.emit('onLotClick', info.value.mateList, info.value.lotList)
    }

    const onMateTestResultRegPop = (o) => {
      popParams.value = {
        vLabNoteCd: info.value.contVO.vLabNoteCd,
        vContPkCd: info.value.contVO.vContPkCd,
        nVersion: info.value.verVO.nVersion,
        vLotCd: o.vLotCd,
        testCdList: info.value.testCdList,
        vFlagDisabled: 'N',
        sum: summaryDatas?.value?.['lot_' + o.vLotCd]?.toNumber() || -1,
      }
      // popSelectFunc.value = selectFuncHal4LotSet
      fnOpenPopup('MateTestResultRegPop')
    }

    const onSearchSubMateList = async (o) => {
      let newMateList = []

      if (info.value.mateList.filter(mate => mate.vHal4MatePkCd === o.vMatePkCd).length > 0) {
        newMateList = info.value.mateList.filter(mate => mate.vHal4MatePkCd !== o.vMatePkCd)

        info.value.lotList = info.value.lotList.map(lot => {
          return {
            ...lot,
            rateList: lot.rateList.filter(rate => rate.vParentMatePkCd !== o.vMatePkCd),
          }
        })

        info.value.rateList = info.value.rateList.filter(rate => rate.vParentMatePkCd !== o.vMatePkCd)
      }
      else {
        const response = await selectLabNoteSubMateRateInfo({
          vMatePkCd: o.vMatePkCd,
          vMateCd: o.vMateCd,
          vFlagHal4: o.vFlagLabHal4Mate,
          vGrpCd: o.vGrpCd || '',
          vContPkCd: o.vMateDbMstCd || '',
          vLabNoteCd: o.vMateLabNoteCd || '',
          vLotCd: info.value.lotList.find(lot => lot.activeYn === 'Y')?.rateList?.
            find(rate => rate.vMatePkCd === o.vMatePkCd)?.vHal4LotCd || '',
          vPlantCd: info.value.contVO.vPlantCd,
          vLand1: info.value.contVO.vLand1,
          vSiteType: info.value.rvo.vSiteType,
        })

        const subMateLen = info.value.mateList.filter(mate => mate.vParentMatePkCd).length
        info.value.mateList.map(mate => {
          newMateList.push(mate)

          if (mate.vMatePkCd === o.vMatePkCd) {
            newMateList = [
              ...newMateList,
              ...response.map((res, idx) => {
                return {
                  ...res,
                  vMatePkCd: res.vMatePkCd || ((res.vMaterialCd || res.vMateCd) + (subMateLen + idx + 1)),
                  vMateCd: '[' + res.vHal4MateCd + '] ' + res.vMateCd,
                  vMateSimplePrice: '',
                  nCounterRate: res.nRate,
                  vParentMatePkCd: o.vMatePkCd,
                  mateIssue: mixmatUtils.getMateTag(
                    res,
                    reqInfo.value.contVO.vLand1,
                    info.value.mstSetVO.find(set => set.vColumnSetCd === 'COLUMN08')?.vFlagHide,
                    noteType,
                  ),
                }
              })
            ]
          }
        })

        response.map((res, idx) => {
          info.value.lotList = info.value.lotList.map(lot => {
            // const newRateList = lot.rateList.filter(rate => lot.vLotCd.indexOf('tmp_lot_') < 0 && rate.vMatePkCd === o.vMatePkCd).map(rate => {
            const newRateList = lot.rateList.filter(rate => rate.vMatePkCd === o.vMatePkCd).map(rate => {
              let nRate = null
              if ((res.vFlagDecide === 'Y' || res.vLotCd === rate.vMateDbLotCd) && rate.nRate) {
                nRate = Math.round(res.nRate * rate.nRate * 10000000) / 1000000000
              }

              return {
                nRate,
                vMatePkCd: res.vMatePkCd || ((res.vMaterialCd || res.vMateCd) + (subMateLen + idx + 1)),
                vLotCd: lot.vLotCd,
                vKey: lot.vLotCd + '_' + (res.vMatePkCd || ((res.vMaterialCd || res.vMateCd) + (subMateLen + idx + 1))),
                vParentMatePkCd: o.vMatePkCd,
              }
            })

            info.value.rateList = [
              ...info.value.rateList,
              ...newRateList.filter(rate => rate.nRate),
            ]

            return {
              ...lot,
              rateList: [
                ...lot.rateList,
                ...newRateList.filter(rate => rate.nRate),
              ],
            }
          })
        })
      }

      context.emit('onChangeRateList', info.value.rateList, false)

      context.emit('onLotClick', sortMateList(newMateList), info.value.lotList)
    }

    const onMaxMixPop = (o) => {
      popParams.value = {
        vLabNoteCd: info.value.contVO.vLabNoteCd,
        vMateCd: o.vMateCd,
        nVersion: info.value.verVO.nVersion,
      }
      fnOpenPopup('MaxMixPop')
    }

    const onLotClick = (o) => {
      const newMateList = gridVars.materials.map(mate => {
        return {
          ...mate,
          vMateDbLotInfoTxt: isNaN(o) ? getMateDbLotInfoTxt(o.rateList, mate.vMatePkCd) : ''
        }
      })

      let activeBFIndex = 0
      const newLotList = gridVars.lots.map((lot, lotIndex) => {
        const vIsLotSelect = o.vLotCd === lot.vLotCd

        if (vIsLotSelect) {
          activeBFIndex = lotIndex - 1
        }

        return {
          ...lot,
          vIsLotSelect,
          activeYn: vIsLotSelect ? 'Y' : 'N',
          // openYn: vIsLotSelect && o.vLotCd.indexOf('tmp_lot_') < 0 ? 'Y' : 'N',
          openYn: 'N',
          borderClass: null,
        }
      })

      if (activeBFIndex > -1) {
        newLotList[activeBFIndex].borderClass = 'border-right__blue'
      }

      context.emit('onLotClick', newMateList, newLotList)

      onLotFocus(activeBFIndex + 1)

      // if (o.vLotCd.indexOf('tmp_lot_') < 0) {
      //   o.openYn = 'Y'
      //   if (!o.sideList || o.sideList.length === 0) {
      //     onLotSideInfo(o)
      //   }
      // }
    }

    const getMateDbLotInfoTxt = (o, vMatePkCd) => {
      if (!vMatePkCd || vMatePkCd.indexOf('tmp_mate_pk_cd') > -1) {
        return null
      }

      const mateDbLotInfo = o.find(rate => rate.vMatePkCd === vMatePkCd)
      if (mateDbLotInfo && mateDbLotInfo?.vHal4VersionTxt && mateDbLotInfo?.vHal4LotNm) {
        return '[' + mateDbLotInfo?.vHal4VersionTxt + ' - ' + mateDbLotInfo?.vHal4LotNm + ']'
      }
      else {
        return null
      }
    }

    const onLotRateChange = async () => {
      const firstMate = info.value.mateList[0]
      if (firstMate?.vMatePkCd.indexOf('tmp_mate_pk_cd_') > -1
        && !firstMate?.vMateCd && !firstMate.vMateTempCd) {
        return
      }

      const lotVO = info.value.lotList.find(lot => lot.activeYn === 'Y')
      if (lotVO) {
        const rateList = await calcRate(lotVO)

        lotVO.rateList = rateList
        context.emit('onChangeRateList', rateList)
        context.emit('onLotClick', info.value.mateList, info.value.lotList)
        context.emit('onIsChange')
      }
    }

    const onLotGramChange = async (o, isInputGram = false) => {
      const firstMate = info.value.mateList[0]
      if (firstMate?.vMatePkCd.indexOf('tmp_mate_pk_cd_') > -1
        && !firstMate?.vMateCd && !firstMate.vMateTempCd) {
        return
      }

      const rateList = await calcRate(o)

      o.rateList = rateList
      if (isInputGram) {
        o.grams = o.grams.map(gram => {
          return {
            ...gram,
            vFlagSave: 'Y',
          }
        })
      }

      context.emit('onChangeRateList', rateList)
      context.emit('onLotClick', info.value.mateList, info.value.lotList)
      context.emit('onIsChange')
    }

    const onAddLot = () => {
      const vLotAddType = info.value.rvo.vLotAddType
      const copyLen = info.value.lotList.length + 1
      const copyObj = info.value.lotList[copyLen - 2]

      const newRateList = [
        ...copyObj.rateList.map(rate => {
          return {
            ...rate,
            vLotCd: 'tmp_lot_' + copyLen,
            vKey: 'tmp_lot_' + copyLen + '_' + (rate.vMatePkCd || 'SUM'),
            nRate: vLotAddType === 'B' ? rate.nRate : null,
            nMateGram1: null,
            nMateGram2: null,
            nMateGram3: null,
            nMateGram4: null,
            nMateGram5: null,
            nMateGram6: null,
            nMateGram7: null,
            nMateGram8: null,
            nMateGram9: null,
            nMateGram10: null,
            vFlagRateRest: 'N',
            vHal4LotCd: null,
            vHal4LotNm: null,
            vHal4VersionNm: null,
            vHal4VersionTxt: null,
            vMateDbLotInfoTxt: null,
          }
        })
      ]

      const newLotList = [{
        vLabNoteCd: info.value.contVO.vLabNoteCd,
        vContPkCd: info.value.contVO.vContPkCd,
        nVersion: info.value.verVO.nVersion,
        vLotCd: 'tmp_lot_' + copyLen,
        vLotNm: 'Lot #0' + copyLen,
        nSort: copyLen,
        vLotMemo: null,
        nGram1: null,
        nGram2: null,
        nGram3: null,
        nGram4: null,
        nGram5: null,
        nGram6: null,
        nGram7: null,
        nGram8: null,
        nGram9: null,
        nGram10: null,
        vIsLotSelect: false,
        activeYn: 'N',
        grams: [{
          vLotCd: 'tmp_lot_' + copyLen,
          nGram: null,
          gramSeq: 'tmp_gram_' + copyLen,
        }],
        sumPrice: 0,
        rateList: newRateList,
      }]

      info.value.lotList = [
        ...info.value.lotList,
        ...newLotList,
      ]

      context.emit('onChangeRateList', newRateList)
      context.emit('onLotClick', info.value.mateList, info.value.lotList)

      onLotFocus(info.value.lotList.length)
    }

    const onLotFocus = (focusIndex) => {
      nextTick(() => {
        const focusLot = refDivBodyScrollX.value
        if (focusLot) {
          focusLot.scrollLeft = focusLot.offsetLeft + (focusIndex * 100)
        }
      })
    }

    const onLotSideInfo = async (o) => {
      if (o.openYn === 'Y') {
        if (o.vLotCd.indexOf('tmp_lot_') > -1) {
          openAsyncAlert({ message: '저장 후 확장 가능합니다.' })
          o.openYn = 'N'
          return
        }

        const response = await selectElabLotMemoList({ vLotCd: o.vLotCd })
        const newLotList = info.value.lotList.map(lot => {
          const newSideList = response.map(side => {
            return {
              ...side,
              isClick: side.vFlagSave === 'Y',
            }
          })

          return {
            ...lot,
            sideList: lot.vLotCd === o.vLotCd ? newSideList : (lot.sideList || [])
          }
        })

        context.emit('onLotClick', info.value.mateList, newLotList)
      }
    }

    const onDefaultIngredientDataPop = () => {
      popParams.value = {
        vLabNoteCd: info.value.contVO.vLabNoteCd,
        vFlagChoice: 'PREVIEW',
      }
      popSelectFunc.value = onIngredientPop
      fnOpenPopup('DefaultIngredientDataPop')
    }

    const onIngredientPop = (o) => {
      popParams.value = {
        vLabNoteCd: info.value.contVO.vLabNoteCd,
        vLotCd: info.value.lotList.find(lot => lot.activeYn === 'Y')?.vLotCd,
        vPlantCd: info.value.contVO.vPlantCd,
        vLand1: o.value.vLand,
        vFlagLeaveType: o.value.vLeaveType,
      }

      setTimeout(() => {
        fnOpenPopup('IngredientPop', false)
      }, 500);
    }

    const onMateOrderChangePop = (o) => {
      popParams.value = {
        vLabNoteCd: info.value.contVO.vLabNoteCd,
        vContPkCd: info.value.contVO.vContPkCd,
        nVersion: info.value.verVO.nVersion,
        vLotCd: o.vLotCd,
        vLotNm: o.vLotNm,
        vContCd: info.value.contVO.vContCd,
        vContNm: info.value.contVO.vContNm,
      }
      popSelectFunc.value = orderChangBomSend
      fnOpenPopup('MateOrderChangePop')
    }

    const orderChangBomSend = async () => {
      if (await openAsyncConfirm({ message: 'BOM 전송이후 전성분 재 승인이 필요합니다.<br/>전성분 승인으로 이동하시겠습니까?' })) {
        goProcess('ingredient')
      }
      else {
        context.emit('onTabClick', info.value.verVO.nVersion)
      }
    }

    const onContextMenu = (e, o) => {
      contextMenu.x = e.x
      contextMenu.y = e.y
      contextMenu.isHide = info.value.mateList.filter(mate => mate.vFlagMateHide === 'Y').length > 0

      if (o.vMatePkCd && o.vMatePkCd !== '') {
        contextMenu.isShowMate = !contextMenu.isShowMate
        contextMenu.isShowGrp = false
      }
      else {
        contextMenu.isShowMate = false
        contextMenu.isShowGrp = !contextMenu.isShowGrp
      }

      if (o.vFlagReq === 'Y') {
        contextMenu.isHideMate = true
        contextMenu.isDelete = true
      }
      else {
        contextMenu.isHideMate = false
        contextMenu.isDelete = false
      }

      if (o.vMdlid && o.vMdlid !== '') {
        contextMenu.isDelete = true
      }

      if (!contextMenu.isOneRateRest) {
        contextMenu.isRateRest = true
        info.value.lotList.filter(lot => lot.vLotCd.indexOf('tmp_lot_') < 0).map(lot => {
          const rateVO = lot.rateList.filter(rate => rate.vMatePkCd === o.vMatePkCd)
          if ((rateVO?.[0]?.vFlagRateRest || 'N') === 'Y') {
            contextMenu.isRateRest = false
          }
        })
      }
      contextMenu.isOneRateRest = false

      contextMenu.isHideRateRest = false
      if (!o.vMateCd && !o.vMateTempCd) {
        contextMenu.isHideRateRest = true
      }

      contextMenu.isHideRowAdd = false
      if (o.vRecType !== 'GRP' && o.vMatePkCd.indexOf('tmp_mate_pk_cd_') > -1) {
        contextMenu.isHideRowAdd = true
      }

      contextMenu.isMakeup = false
      if (noteType === 'MU') {
        contextMenu.isMakeup = true
        contextMenu.isColorMate = o.vFlagColorMate === 'Y'
      }

      contextMenu.isHbd = false
      if (noteType === 'HBO') {
        contextMenu.isHbd = true
        contextMenu.isMainMate = o.vFlagMainIngredientMate === 'Y'
      }

      contextMenu.isQdrug = false
      if (noteType === 'SA') {
        contextMenu.isQdrug = true
      }

      onMateRowSelect(o)
    }

    const onMateRowSelect = (o) => {
      if (o.vRecType !== 'GRP' && selectedRows.value.filter(row => row.vMatePkCd === o.vMatePkCd).length === 0) {
        selectedRows.value = [...selectedRows.value, o]
      }
      else if (o.vRecType === 'GRP' && selectedGrps.value.filter(row => row.vGrpCd === o.vGrpCd).length === 0) {
        selectedGrps.value = [...selectedGrps.value, o]
      }
    }

    const onContextHeader = (e, o) => {
      contextMenu.x = e.x
      contextMenu.y = e.y

      contextMenu.isShowLotHead = !contextMenu.isShowLotHead

      contextMenu.isHidePaste = true
      if (pasteLot?.value?.isPaste && o.vFlagComplete !== 'Y') {
        contextMenu.isHidePaste = false
      }

      contextMenu.isDelete = o.vFlagComplete === 'Y'
      contextMenu.isHideBookmark = o.vLotCd.indexOf('tmp_lot_') > -1 ? true : o.vFlagComplete !== 'Y'
      contextMenu.isHideBase = o.vLotCd.indexOf('tmp_lot_') > -1

      selectedLot.value = o
    }

    const onRateOneLotSelect = (o, num) => {
      info.value.lotList.map(lot => lot.vIsCalcSelected = false)
      contextMenu.isAllRowRate = false
      contextMenu.rateEmptyLotNum = -1
      contextMenu.isRateRest = true
      contextMenu.isOneRateRest = true

      if (o.rateList.filter(lot => lot.vFlagRateRest === 'Y').length > 0) {
        contextMenu.isRateRest = false
      }

      if (o) {
        o.vIsCalcSelected = true
      }
      else {
        contextMenu.rateEmptyLotNum = num + info.value.lotList.length
      }
    }

    const selectedInit = () => {
      selectedRows.value = []
      selectedGrps.value = []

      info.value.lotList.map(lot => lot.vIsCalcSelected = false)
      contextMenu.rateEmptyLotNum = -1
      contextMenu.isAllRowRate = true

      if (defInit.clear) {
        mixmatUtils.clearFocusCell()
        mixmatUtils.clearMultipleSelectCell()
      }

      defInit.clear = true
    }

    const onContextMenuItemClick = (e) => {
      if (e === 'HIDE_MATE' || e === 'SHOW_MATE') {
        const hideList = gridVars.materials.filter(row => row.rowSelectYn === 'Y').length > 0 ?
          gridVars.materials.filter(row => row.rowSelectYn === 'Y') : selectedRows.value
        selectedRows.value = hideList.map(row => {
          if (e === 'HIDE_MATE' && row.vFlagReq === 'Y') {
            openAsyncAlert({ message: '필수 원료는 숨기기 불가능 합니다.' })
            return {}
          }
          else {
            row.vFlagMateHide = e === 'HIDE_MATE' ? 'Y' : 'N'
            return row
          }
        })

        info.value.mateList = info.value.mateList.map(mate => {
          if (e === 'HIDE_MATE') {
            if (selectedRows.value.filter(row => row.vMatePkCd === mate.vMatePkCd).length > 0) {
              return {
                ...mate,
                vFlagMateHide: e === 'HIDE_MATE' ? 'Y' : 'N',
              }
            }
            else {
              return mate
            }
          }
          else {
            return {
              ...mate,
              vFlagMateHide: 'N',
            }
          }
        })

        context.emit('onChangeMateList', sortMateList(info.value.mateList))
        context.emit('onIsChange')
      }
      else if (e === 'DELETE_MATE') {
        const deleteList = gridVars.materials.filter(row => row.rowSelectYn === 'Y')
        if (deleteList.length > 0) {
          deleteMataData(deleteList)
        }
        else {
          onDeleteKeyEvent({ key: 'Delete' })
        }
      }
      else if (e === 'ADD_GROUP') {
        const grpCnt = info.value.mateList.filter(mate => mate.vRecType === 'GRP').length + 1
        const grpCd = 'temp_grp_' + grpCnt
        const grpNm = '그룹명_' + grpCnt

        let newGrpMateList = []
        let nextGrpMateList = []
        const lastRow = selectedRows.value[selectedRows.value.length - 1]
        const grpList = gridVars.materials.filter(row => row.rowSelectYn === 'Y').length > 0 ?
          gridVars.materials.filter(row => row.rowSelectYn === 'Y') : selectedRows.value
        let isCreate = false
        info.value.mateList.map(mate => {
          if (grpList.filter(grp => grp.vMatePkCd === mate.vMatePkCd).length > 0) {
            if (!isCreate) {
              nextGrpMateList.push({
                vRecType: 'GRP',
                vGrpCd: grpCd,
                vGrpNm: grpNm,
              })
            }

            grpList.filter(row => row.vMatePkCd === mate.vMatePkCd).map(row => {
              nextGrpMateList.push({
                ...row,
                vGrpCd: grpCd,
              })
            })

            isCreate = true
          }
          else {
            if (grpList.filter(row => row.vMatePkCd === mate.vMatePkCd).length === 0) {
              if ((lastRow.vGrpCd && lastRow.vGrpCd !== mate.vGrpCd || !lastRow.vGrpCd) && nextGrpMateList.length > 0) {
                nextGrpMateList.map(next => {
                  next.rowSelectYn = 'N'
                  newGrpMateList.push(next)
                })
                nextGrpMateList = []
              }

              mate.rowSelectYn = 'N'
              newGrpMateList.push(mate)
            }
          }
        })

        // mixmatUtils.onKeydown({ key: 'Escape' })

        context.emit('onChangeMateList', sortMateList(newGrpMateList))
        context.emit('onIsChange')

        defInit.clear = false
      }
      else if (e === 'UP_MATE' || e === 'DOWN_MATE') {
        if (e === 'UP_MATE') {
          mixmatUtils.upRow()
        }
        else {
          mixmatUtils.downRow()
        }

        context.emit('onChangeMateList', sortMateList(gridVars.materials))
        context.emit('onIsChange')

        defInit.clear = false
      }
      else if (e === 'UP_GRP' || e === 'DOWN_GRP') {
        if (selectedGrps.value.length > 1) {
          openAsyncAlert({ message: '그룹은 1개의 그룹씩 이동 가능합니다.' })
          selectedInit()
          return
        }

        const oldMateList = [...info.value.mateList]
        const newMateList = []
        const firstGrp = selectedGrps.value[0]
        let moveIndex = 0

        oldMateList.map((mate, index) => {
          if (e === 'UP_GRP' && (!mate.vMatePkCd || mate.vMatePkCd === '') && mate.vGrpCd === firstGrp.vGrpCd) {
            moveIndex = index - 1
          }
          else if (e === 'DOWN_GRP' && (!mate.vMatePkCd || mate.vMatePkCd === '') && mate.vGrpCd === firstGrp.vGrpCd) {
            moveIndex = index + oldMateList.filter(old => old.vGrpCd === firstGrp.vGrpCd).length
          }
        })

        if (moveIndex < 0 || moveIndex > oldMateList.length) {
          selectedInit()
          return
        }

        const target = oldMateList.filter((mate, index) => moveIndex == index)
        if (target?.[0]?.vGrpCd) {
          if (e === 'UP_GRP') {
            moveIndex -= oldMateList.filter(mate => mate.vGrpCd === target[0].vGrpCd).length - 1
          }
          else if (e === 'DOWN_GRP') {
            moveIndex += oldMateList.filter(mate => mate.vGrpCd === target[0].vGrpCd).length
          }
        }
        else {
          if (e === 'DOWN_GRP') {
            moveIndex += 1
          }
        }

        oldMateList.map((mate, index) => {
          if (moveIndex === index) {
            oldMateList.filter(old => old.vGrpCd === firstGrp.vGrpCd).map(old => {
              newMateList.push(old)
            })
          }

          if (selectedGrps.value.filter(row => row.vGrpCd === mate.vGrpCd).length === 0) {
            newMateList.push(mate)
          }
        })

        if (moveIndex >= oldMateList.length) {
          oldMateList.map(mate => {
            if (mate.vGrpCd === firstGrp.vGrpCd) {
              newMateList.push(mate)
            }
          })
        }

        context.emit('onChangeMateList', sortMateList(newMateList))
        context.emit('onIsChange')
      }
      else if (e === 'NM_CHG_GRP') {
        // let newMateList = [...info.value.mateList]
        // selectedGrps.value.map(row => {
        //   newMateList = newMateList.map(mate => {
        //     return {
        //       ...mate,
        //       vFlagChgGrpNm: mate.vGrpCd === row.vGrpCd && (!mate.vMatePkCd || mate.vMatePkCd === '') ? 'Y' : 'N'
        //     }
        //   })
        // })

        // context.emit('onChangeMateList', sortMateList(newMateList))
      }
      else if (e === 'DELETE_GRP') {
        let deleteList = gridVars.materials.filter(row => row.rowSelectYn === 'Y').length > 0 ?
          [...gridVars.materials.filter(row => row.rowSelectYn === 'Y')] : selectedGrps.value

        deleteGrpData(deleteList)
      }
      else if (e === 'RATE_REST') {
        const lastRow = selectedRows.value[selectedRows.value.length - 1]

        info.value.lotList.map(async (lot, idx) => {
          if (contextMenu.isAllRowRate || (lot.vIsCalcSelected || contextMenu.rateEmptyLotNum === (idx + 1))) {
            const rateList = await calcRate(lot, lastRow)

            lot.rateList = rateList.map(rate => {
              return {
                ...rate,
                vFlagSave: rate.vMatePkCd === lastRow.vMatePkCd ? 'Y' : rate.vFlagSave,
              }
            })
            context.emit('onChangeRateList', lot.rateList)
          }
        })

        context.emit('onLotClick', sortMateList(info.value.mateList), info.value.lotList)
        context.emit('onIsChange')
      }
      else if (e === 'DELETE_RATE_REST') {
        const lastRow = selectedRows.value[selectedRows.value.length - 1]

        info.value.lotList.map((lot, idx) => {
          const rateList = lot.rateList.map(rate => {
            if ((contextMenu.isAllRowRate || (lot.vIsCalcSelected || contextMenu.rateEmptyLotNum === (idx + 1)))
              && rate.vMatePkCd === lastRow.vMatePkCd) {
              return {
                ...rate,
                vFlagRateRest: 'N',
                vFlagSave: 'Y',
              }
            }
            else {
              return { ...rate }
            }
          })

          lot.rateList = rateList

          context.emit('onChangeRateList', rateList)
        })

        context.emit('onLotClick', sortMateList(info.value.mateList), info.value.lotList)
        context.emit('onIsChange')
      }
      else if (e === 'ADD_ROW') {
        const lastRow = selectedRows.value[selectedRows.value.length - 1]

        if (lastRow.vMatePkCd.indexOf('tmp_mate_pk_cd_') > -1) {
          return
        }

        const newMateList = []
        const copyLen = info.value.mateList.length
        info.value.mateList.map(mate => {

          if (mate.vMatePkCd === (lastRow.vMatePkCd)) {
            newMateList.push({
              vMatePkCd: 'tmp_mate_pk_cd_' + (copyLen + 1),
              vRecType: mate.vRecType,
              vGrpCd: mate.vGrpCd ? mate.vGrpCd : null,
              isRowAdd: true,
            })
          }

          newMateList.push(mate)
        })

        context.emit('onChangeMateList', sortMateList(newMateList))
      }
      else if (e === 'RATE_COPY') {
        pasteLot.value = selectedLot.value
        pasteLot.value.isPaste = true
      }
      else if (e === 'RATE_PASTE') {
        const newLotList = info.value.lotList.map(lot => {
          if (lot.vLotCd === selectedLot.value.vLotCd) {
            const newRateList = lot.rateList.map(rate => {
              return {
                ...rate,
                nRate: pasteLot.value.rateList.find(paste => paste.vMatePkCd === rate.vMatePkCd).nRate || null
              }
            })

            context.emit('onChangeRateList', newRateList)

            return {
              ...lot,
              rateList: newRateList,
            }
          }
          else {
            return { ...lot }
          }
        })

        context.emit('onLotClick', sortMateList(info.value.mateList), newLotList)
        context.emit('onIsChange')
      }
      else if (e === 'RATE_DELETE') {
        const newLotList = info.value.lotList.map(lot => {
          if (lot.vLotCd === selectedLot.value.vLotCd) {
            const newRateList = lot.rateList.map(rate => {
              return {
                ...rate,
                nRate: null
              }
            })

            context.emit('onChangeRateList', newRateList)

            return {
              ...lot,
              rateList: newRateList,
            }
          }
          else {
            return { ...lot }
          }
        })

        context.emit('onLotClick', sortMateList(info.value.mateList), newLotList)
        context.emit('onIsChange')
      }
      else if (e === 'ADD_GRAM') {
        const gramLen = selectedLot.value.grams.length
        if (gramLen >= 10) {
          openAsyncAlert({ message: '10개 까지만 추가 가능합니다.' })
          return
        }

        const newLotList = info.value.lotList.map(lot => {
          if (lot.vLotCd === selectedLot.value.vLotCd) {

            return {
              ...lot,
              vIsLotSelect: true,
              activeYn: 'Y',
              grams: [
                ...lot.grams,
                {
                  vLotCd: lot.vLotCd,
                  nGram: null,
                  gramSeq: 'tmp_gram_' + lot.vLotCd + '_' + (gramLen + 1),
                }
              ],
            }
          }
          else {
            return {
              ...lot,
              vIsLotSelect: false,
              activeYn: 'N',
            }
          }
        })

        context.emit('onLotClick', sortMateList(info.value.mateList), newLotList)
      }
      else if (e === 'DELETE_GRAM') {
        const gramLen = selectedLot.value.grams.length
        if (gramLen === 1) {
          openAsyncAlert({ message: '기본 그램은 삭제 하실 수 없습니다.' })
          return
        }

        const gramSeq = selectedLot.value.grams[gramLen - 1]?.gramSeq
        if (gramSeq.indexOf('tmp_gram_') < 0) {
          openAsyncAlert({ message: '등록된 그램은 삭제 하실 수 없습니다.' })
          return
        }

        const newLotList = info.value.lotList.map(lot => {
          if (lot.vLotCd === selectedLot.value.vLotCd) {
            return {
              ...lot,
              vIsLotSelect: true,
              activeYn: 'Y',
              grams: lot.grams.filter(gram => gram.gramSeq !== gramSeq),
            }
          }
          else {
            return {
              ...lot,
              vIsLotSelect: false,
              activeYn: 'N',
            }
          }
        })

        context.emit('onLotClick', sortMateList(info.value.mateList), newLotList)
      }
      else if (e === 'REG_BOOKMARK') {
        updateBookmark()
      }
      else if (e === 'REG_BASE') {
        if (info.value.isChange) {
          openAsyncAlert({ message: '저장 후 베이스 처방 가능합니다.' })
          return
        }

        updateBase()
      }
      else if (e === 'QRCODE_LOT' || e === 'QRCODE_STANDARD_LOT') {
        popParams.value = {
          vLotCd: selectedLot.value.vLotCd,
          vFlagStandard: e === 'QRCODE_LOT' ? 'N' : 'Y',
        }
        fnOpenPopup('LotQrCodePop')
      }
      else if (e === 'PASTE_MATE') {
        navigator.clipboard
          .readText()
          .then((text) => {
            const rows = text.split('\n')
            const rowLen = rows.length
            let pasteVal = ''

            for (let i = 0; i < rowLen; i++) {
              const cell = rows[i].split('\t')
              const cellLen = cell.length

              if (cellLen > 0 && cell[0] && Number(cell[0]) && cell[0].trim().replace(/ /g, '').length === 7) {
                if (pasteVal) {
                  pasteVal += ','
                }

                pasteVal += cell[0]
              }
            }

            if (pasteVal) {
              pasteMate('tableBodyLeft', pasteVal)
            }
          })
      }
      else if (e === 'MU_MATE_CHECK_Y' || e === 'MU_MATE_CHECK_N') {
        const lastRow = selectedRows.value[selectedRows.value.length - 1]

        const newMateList = info.value.mateList.map(mate => {
          let vFlagColorMate = mate.vFlagColorMate
          let mateIssue = mate.mateIssue || []
          if (mate.vMatePkCd === lastRow.vMatePkCd) {
            vFlagColorMate = e === 'MU_MATE_CHECK_Y' ? 'Y' : 'N'

            if (vFlagColorMate === 'Y') {
              mateIssue.push({
                issueNm: '조색',
                className: 'material-tag__toning',
              })
            }
            else {
              mateIssue = mateIssue.filter(issue => issue.issueNm !== '조색')
            }
          }

          return {
            ...mate,
            vFlagColorMate,
            mateIssue,
          }
        })

        context.emit('onChangeMateList', sortMateList(newMateList))
        context.emit('onIsChange')
      }
      else if (e === 'HBD_MATE_CHECK_Y' || e === 'HBD_MATE_CHECK_N') {
        const lastRow = selectedRows.value[selectedRows.value.length - 1]

        const newMateList = info.value.mateList.map(mate => {
          let vFlagMainIngredientMate = mate.vFlagMainIngredientMate
          let mateIssue = mate.mateIssue || []
          if (mate.vMatePkCd === lastRow.vMatePkCd) {
            vFlagMainIngredientMate = e === 'HBD_MATE_CHECK_Y' ? 'Y' : 'N'

            if (vFlagMainIngredientMate === 'Y') {
              mateIssue.push({
                issueNm: '주성분',
                className: 'material-tag__blue',
              })
            }
            else {
              mateIssue = mateIssue.filter(issue => issue.issueNm !== '주성분')
            }
          }

          return {
            ...mate,
            vFlagMainIngredientMate,
            mateIssue,
          }
        })

        context.emit('onChangeMateList', sortMateList(newMateList))
        context.emit('onIsChange')
      }
      else if (e === 'QDRUG_INGREDIENT_REVIEW') {
        if (info.value.mateList.length === 0) {
          openAsyncAlert({ message: '등록된 원료가 없습니다.' })
          return
        }

        const lotVO = info.value.lotList.find(lot => lot.activeYn === 'Y')
        const bomList = info.value.mateList.filter(mate => mate.vMateCd || mate.vMateTempCd).map(mate => {
          const rateVO = lotVO.rateList.find(rate => rate.vMatePkCd === mate.vMatePkCd)
          if (rateVO.nRate) {
            return {
              rawCd: mate.vMateCd || mate.vMateTempCd,
              rawNm: mate.vMateNm,
              rawPer: rateVO.nRate,
            }
          }
        })

        popParams.value = {
          bomList: bomList.filter(bom => bom != null),
        }

        fnOpenPopup('SaIngrPermissionPop')
      }

      selectedInit()
    }

    const sortMateList = (list) => {
      return list.map((o, index) => {
        return {
          ...o,
          nSort: index,
        }
      })
    }

    const pasteMate = async (tId, o, fail = '', isDrag = false) => {
      if (tId === 'tableBodyLeft') {
        await selectSearchMateList({
          vPlantCd: info.value.contVO.vPlantCd,
          vLabNoteCd: info.value.contVO.vLabNoteCd,
          vNoteType: noteType,
          vSiteType: noteType,
          arrKeyword: o,
          nowPageNo: 1
        })

        const existsCnt = o.split(',').length - list.value.filter(mate => o.indexOf(mate.vMateCd) > -1).length
        if (existsCnt > 0) {
          o.split(',').map(vMateCd => {
            let isExistsMate = false
            for (let i = 0; i < list.value.length; i++) {
              if (Number(vMateCd) === Number(list.value[i].vMateCd)) {
                isExistsMate = true
                break
              }
            }

            if (!isExistsMate) {
              if (fail) {
                fail += ','
              }
              fail += vMateCd
            }
          })
        }

        if (fail) {
          openAsyncAlert({ message: fail + ' 는 올바르지 않은 원료코드입니다.' })
        }
        context.emit('onAddMateAndGrp', list.value, true, isDrag)
        context.emit('onIsChange')
      }
      else if (tId === 'tableBodyCenter') {
        const { gridVars } = mixmatUtils.opts
        const { cellData } = gridVars.focusCell
        const arrRate = o.split(',')
        const newRateList = []
        let pasteIdx = 0
        let pasteRateLen = 0

        const copyMateList = info.value.mateList.map((mate, mIdx) => {
          if (mIdx === (cellData.rowIndex + pasteRateLen) && pasteRateLen < arrRate.length) {
            pasteRateLen++
            return {
              ...mate,
              vFlagPaste: 'Y'
            }
          }
          else {
            return { ...mate }
          }
        })

        const newLotList = info.value.lotList.map(lot => {
          if (lot.vLotCd === cellData.vLotCd) {
            copyMateList.map(mate => {
              lot.rateList.filter(rate => rate.vKey.indexOf('_SUM') < 0 && mate.vMatePkCd === rate.vMatePkCd).map(rate => {
                if (mate.vFlagPaste !== 'Y') {
                  newRateList.push(rate)
                }
                else {
                  newRateList.push({
                    ...rate,
                    nRate: Number(arrRate[pasteIdx++]) || rate.nRate,
                    vFlagSave: 'Y',
                  })
                }
              })
            })

            context.emit('onChangeRateList', newRateList)

            return {
              ...lot,
              rateList: newRateList,
            }
          }
          else {
            return { ...lot }
          }
        })

        context.emit('onLotClick', sortMateList(info.value.mateList), newLotList)
        context.emit('onIsChange')
      }
    }

    const calcRate = async (lot, row) => {
      const mateSumList = info.value.mateList.
        filter(mate =>
          mate.vRecType !== 'GRP' &&
          !mate.vParentMatePkCd &&
          mate.vMatePkCd &&
          mate.vMatePkCd.indexOf('tmp_mate_pk_cd') < 0).
        map(mate => {
          const rateList = lot.rateList.filter(rate => rate.vMatePkCd === mate.vMatePkCd && rate.vLotCd === lot.vLotCd)
          const vFlagRateRest = row ? (mate.vMatePkCd === row.vMatePkCd ? 'Y' : 'N') : (rateList?.[0]?.vFlagRateRest || 'N')

          return {
            vMateCd: mate.vMateCd || mate.vMateTempCd || '',
            vMatePkCd: mate.vMatePkCd || '',
            vMateRate: rateList?.[0]?.nRate || '0',
            vFlagRateRest,
            vMateSimplePrice: mate.vMateSimplePrice,
          }
        })

      const mateSubList = info.value.mateList.filter(mate => mate.vParentMatePkCd).map(mate => {
        return {
          vMatePkCd: mate.vMatePkCd,
          nMateRatio: mate.nCounterRate,
          nParentMateRate: lot.rateList.find(rate => rate.vMatePkCd === mate.vParentMatePkCd && rate.vLotCd === lot.vLotCd)?.nRate || 0,
        }
      })

      let gramList = lot.grams.map(gram => { return gram.nGram })
      if (!lot.vLotCd || lot.vLotCd === '' || lot.vLotCd.indexOf('tmp_lot_') > -1) {
        gramList = [0]
      }

      const response = await selectMaterialFormulationSum({
        vLabNoteCd: info.value.contVO.vLabNoteCd,
        vContPkCd: info.value.contVO.vContPkCd,
        nVersion: info.value.verVO.nVersion,
        vLotCd: lot.vLotCd.indexOf('tmp_lot_') > -1 ? '' : lot.vLotCd,
        nLotSort: lot.nSort,
        nCapacity: info.value.rvo.nCapacity ? info.value.rvo.nCapacity : 100,
        gramList,
        mateSumList,
        mateSubList,
      })

      lot.sumPrice = response.sumPrice

      return lot.rateList.map(rate => {
        const vFlagRateRest = row ? (rate.vMatePkCd === row.vMatePkCd ? 'Y' : 'N') : rate.vFlagRateRest
        const vo = response.list.filter(o => o.vMatePkCd === rate.vMatePkCd)
        const sub = response.subList.filter(o => o.vMatePkCd === rate.vMatePkCd)

        if (sub && sub.length > 0) {
          return {
            ...rate,
            nRate: sub?.[0].nSubRate || null,
            nMateGram1: sub?.[0].nRowGram1 || 0,
            nMateGram2: sub?.[0].nRowGram2 || 0,
            nMateGram3: sub?.[0].nRowGram3 || 0,
            nMateGram4: sub?.[0].nRowGram4 || 0,
            nMateGram5: sub?.[0].nRowGram5 || 0,
            nMateGram6: sub?.[0].nRowGram6 || 0,
            nMateGram7: sub?.[0].nRowGram7 || 0,
            nMateGram8: sub?.[0].nRowGram8 || 0,
            nMateGram9: sub?.[0].nRowGram9 || 0,
            nMateGram10: sub?.[0].nRowGram10 || 0,
          }
        }
        else if (!rate.vMatePkCd) {
          return {
            ...rate,
            nRate: !rate.nRate ? 100 : rate.nRate,
            nMateGram1: response.sumGramVO.nGram1 || 0,
            nMateGram2: response.sumGramVO.nGram2 || 0,
            nMateGram3: response.sumGramVO.nGram3 || 0,
            nMateGram4: response.sumGramVO.nGram4 || 0,
            nMateGram5: response.sumGramVO.nGram5 || 0,
            nMateGram6: response.sumGramVO.nGram6 || 0,
            nMateGram7: response.sumGramVO.nGram7 || 0,
            nMateGram8: response.sumGramVO.nGram8 || 0,
            nMateGram9: response.sumGramVO.nGram9 || 0,
            nMateGram10: response.sumGramVO.nGram10 || 0,
          }
        }
        else if (vo.length > 0) {
          return {
            ...rate,
            vFlagRateRest,
            nMateGram1: vo?.[0].nRowGram1 || 0,
            nMateGram2: vo?.[0].nRowGram2 || 0,
            nMateGram3: vo?.[0].nRowGram3 || 0,
            nMateGram4: vo?.[0].nRowGram4 || 0,
            nMateGram5: vo?.[0].nRowGram5 || 0,
            nMateGram6: vo?.[0].nRowGram6 || 0,
            nMateGram7: vo?.[0].nRowGram7 || 0,
            nMateGram8: vo?.[0].nRowGram8 || 0,
            nMateGram9: vo?.[0].nRowGram9 || 0,
            nMateGram10: vo?.[0].nRowGram10 || 0,
          }
        }
        else {
          const isRate = 'N'
          return {
            ...rate,
            vFlagRateRest,
            nRate: isRate ? response.restRate : null,
            nMateGram1: isRate ? response.restGramVO.nGram1 : null,
            nMateGram2: isRate ? response.restGramVO.nGram2 : null,
            nMateGram3: isRate ? response.restGramVO.nGram3 : null,
            nMateGram4: isRate ? response.restGramVO.nGram4 : null,
            nMateGram5: isRate ? response.restGramVO.nGram5 : null,
            nMateGram6: isRate ? response.restGramVO.nGram6 : null,
            nMateGram7: isRate ? response.restGramVO.nGram7 : null,
            nMateGram8: isRate ? response.restGramVO.nGram8 : null,
            nMateGram9: isRate ? response.restGramVO.nGram9 : null,
            nMateGram10: isRate ? response.restGramVO.nGram10 : null,
          }
        }
      })
    }

    const deleteMataData = (deleteList = []) => {
      for (let i = 0; i < deleteList.length; i++) {
        if (deleteList[i].vMdlid && deleteList[i].vMdlid !== '') {
          openAsyncAlert({ message: '효능모듈 추가된 원료는 삭제 할 수 없습니다.' })
          selectedInit()
          return
        }
        else if (deleteList[i].vFlagReq === 'Y') {
          openAsyncAlert({ message: '필수 원료는 삭제가 불가능 합니다.' })
          selectedInit()
          return
        }
      }

      if (info.value.verVO.vFlagExistsComplete === 'Y') {
        for (let i = 0; i < deleteList.length; i++) {
          const rateVal = info.value.rateList.filter(rate => rate.nRate && rate.nRate > 0 && rate.vMatePkCd === deleteList[i].vMatePkCd).length
          if (rateVal > 0) {
            openAsyncAlert({ message: '함량이 존재하는 원료는 삭제 할 수 없습니다.' })
            selectedInit()
            return
          }
        }
      }

      let newMateList = [...info.value.mateList]
      deleteList.map(row => {
        newMateList = newMateList.filter(mate => mate.vMatePkCd !== row.vMatePkCd)
      })

      if (newMateList.length < 15) {
        const tmpMateList = []
        const copyLen = newMateList.length
        for (let i = 0; i < 15 - copyLen; i++) {
          tmpMateList.push({
            vMatePkCd: 'tmp_mate_pk_cd_' + (copyLen + i + 1),
          })
        }

        newMateList = [
          ...newMateList,
          ...tmpMateList,
        ]
      }

      const delMatePkCdList = deleteList.map(row => {
        return row.vMatePkCd
      })

      mixmatUtils.onKeydown({ key: 'Escape' })

      context.emit('onChangeMateList', sortMateList(newMateList), delMatePkCdList)
      context.emit('onIsChange')
    }

    const deleteGrpData = (deleteList) => {
      let newMateList = [...info.value.mateList]
      deleteList.map(row => {
        newMateList = newMateList.filter(mate => mate.vGrpCd !== row.vGrpCd || (mate.vMatePkCd && mate.vMatePkCd !== '')).map(mate => {
          return {
            ...mate,
            vGrpCd: mate.vGrpCd === row.vGrpCd ? null : mate.vGrpCd
          }
        })
      })

      context.emit('onChangeMateList', sortMateList(newMateList), [], deleteList.map(row => row.vGrpCd))
      context.emit('onIsChange')
    }

    const updateBookmark = async () => {
      const response = await updateLabNoteLotBookmark({ vLotCd: selectedLot.value.vLotCd })
      if (response) {
        openAsyncAlert({ message: response })
      }
    }

    const updateBase = async () => {
      const vLotCd = selectedLot.value?.vLotCd
      const vFlagComplete = selectedLot.value?.vFlagComplete
      if (vFlagComplete !== 'Y' && summaryDatas?.value?.['lot_' + vLotCd]?.toNumber() !== 100) {
        if (!await openAsyncConfirm({ message: '원료 배합 합이 100이 아닙니다.<br/>베이스 처방 후 LOT 이 잠깁니다.<br/>처방하시겠습니까?' })) {
          return
        }
      }

      const response = await updateLabNoteLotBase({
        vContPkCd: info.value.contVO.vContPkCd,
        vLotCd: selectedLot.value.vLotCd,
      })
      if (response) {
        openAsyncAlert({ message: response })
        context.emit('onTabClick', info.value.verVO.nVersion)
      }
    }

    const onProcess = async (e, o) => {
      let message = ''

      if (e === 'BOM_TMP_SEND') {

        if (info.value.isChange) {
          openAsyncAlert({ message: '저장 후 전송 가능합니다.' })
        }
        else if (!info.value.contVO?.vContCd) {
          openAsyncAlert({ message: '내용물 코드가 아직 생성되지 않았습니다.' })
        }
        else if (info.value.contVO.vFlagExistsDecide === 'Y') {
          openAsyncAlert({ message: '이미 확정된 LOT이 있습니다.' })
        }
        // else if (o.vFlagExistsBom === 'Y') {
        //   openAsyncAlert({ message: '이미 BOM 전송이 된 LOT입니다.' })
        // }
        else if (o.vFlagCheckNotIngrYn === 'Y' && info.value.contVO.vLand1 === 'UN') {
          if (myInfo.groups && myInfo.groups.filter(my => my.indexOf('S000272') > -1)?.length > 0) {
            message = '<span style="font-weight: bolder;">[주의]</span> <span style="color: red; font-weight: bolder;">Zplm34e 구성성분 없는  원료</span>가 존재합니다. <br/>'
            message += 'BOM 승인 전에 <span style="color: red; font-weight: bolder;">반드시 구성 성분 등록</span>해주세요.<br/><br/>'
            message += '<span>본 기능은 제조공정도를 그릴 목적으로만 사용 가능하며,</span> <br>'
            message += '<span>최종 BOM 전송은 PQC 자가체크 완료 후 승인 및 진행하셔야 합니다.</span>'
            if (await openAsyncConfirm({ message })) {
              onSendBomPop(o)
            }
          }
          else {
            message = '<span style="font-weight: bolder;">[주의]</span> <span style="color: red; font-weight: bolder;">Zplm34e 구성성분 없는  원료</span>가 존재하여 <br/>'
            message += 'BOM 임시전송이 <span style="color: red; font-weight: bolder;">불가</span> 합니다.'
            openAsyncAlert({ message })
          }
        }
        else {
          message = onTarValidate(o)

          if (message) {
            if (await openAsyncConfirm({ message })) {
              onSendBomPop(o)
            }
          }
          else {
            message = '본 기능은 제조공정도를 그릴 목적으로만 사용 가능하며, <br>'
            message += '최종 BOM 전송은 PQC 자가체크 완료 후 승인 및 진행하셔야 합니다.'
            if (await openAsyncConfirm({ message })) {
              onSendBomPop(o)
            }
          }
        }
      }
      else if (e === 'PILOT_PRESCRIPTION') {
        if (info.value.isChange) {
          openAsyncAlert({ message: '저장 후 처방 가능합니다.' })
          return
        }
        else if (!info.value.contVO?.vContCd) {
          openAsyncAlert({ message: '내용물 코드가 아직 생성되지 않았습니다.' })
          return
        }

        message = onTarValidate(o)

        if (message) {
          if (await openAsyncConfirm({ message })) {
            onPilotPrescription(o)
          }
        }
        else {
          message = '해당 LOT을 파일럿 처방으로 등록 하시겠습니까?'
          if (await openAsyncConfirm({ message })) {
            onPilotPrescription(o)
          }
        }
      }
      else if (e === 'DECIDE_PRESCRIPTION') {
        if (o.vFlagExistsDecide === 'Y') {
          openAsyncAlert({ message: '이미 확정된 LOT이 있습니다.' })
          return
        }
        else if (info.value.contVO.vCodeType === 'AEROSOL') {
          if (info.value.isChange) {
            openAsyncAlert({ message: '저장 후 처방확정 가능합니다.' })
            return
          }
          else if (summaryDatas?.value?.['lot_' + o.vLotCd]?.toNumber() !== 100) {
            openAsyncAlert({ message: '원료 배합 합이 100이 아닙니다.' })
            return false
          }
        }

        goProcess('confirm', o, info.value.contVO)
      }
      else if (e === 'INGREDIENT_APPR') {
        goProcess('ingredient')
      }
      else if (e === 'RELEASE_COMPLETE') {
        goProcess('complete')
      }
      else if (e === 'DECIDE_CANCEL') {
        let message = '<span class="txt_blue f-weight-700">[확정해제]시 BOM 승인 단계로 돌아가며<br>'
        message += 'Lot 추가 시-BOM 승인/전성분 승인/양산승인을,<br>'
        message += '기존 Lot (BOM 승인) 사용 시-전성분 승인/양산승인을 재수행해야 합니다.</span><br>'
        message += '<span class="txt_red f-weight-700">SCM등 유관부서와 논의 후 진행하시기 바랍니다.</span><br><br>'
        message += '확정해제 하시겠습니까?'

        if (await openAsyncConfirm({ message })) {
          const payload = {
            vLabNoteCd: info.value.contVO.vLabNoteCd,
            vContPkCd: info.value.contVO.vContPkCd,
            nVersion: info.value.verVO.nVersion,
            vLotCd: o.vLotCd,
            vNoteType: noteType,
          }

          const result = await updateDecideCancel(payload)
          if (result && result === 'SUCC') {
            await openAsyncAlert({ message: '확정해제 완료하였습니다.' })
            context.emit('onTabClick', payload.nVersion)
          }
        }
      }
    }

    const onTarValidate = (o) => {
      let vIsExistsTar = false
      const tarMateList = info.value.mateList.filter(mate => mate.vFlagTarMate === 'Y')
      for (let i = 0; i < tarMateList.length; i++) {
        if (o.rateList.filter(rate => rate.vMatePkCd === tarMateList[i].vMatePkCd && rate.nRate > 0).length > 0) {
          vIsExistsTar = true
          break
        }
      }

      let message = ''
      if (vIsExistsTar) {
        message = '해당 제품에는 타르계 색소 원료가 있습니다.<br>'
        message += '연구소 실험 시는 D.I.Water 로 1000배 희석해 실험하시더라도 <br>'
        message += '실험처방을 BOM 으로 입력 시, 처방량을 1/1000 로 바꿔서 입력하셔야 합니다. <br><br>'
        message += '<strong>예) 실험처방 / 1000 = BOM 입력값, 나머지 값은 to 100 원료 처방량에 추가 <br>'
        message += '0.2% / 1000 = 0.00002 % , 나머지 값 0.19998 (0.2%-0.00002%) 은 to 100 원료 처방량에 추가</strong><br><br>'
        message += '<span style="font-weight:bold; color:red;">해당 원료의 함량을 반드시 다시 확인하여 주세요</span> <br>'
        message += '확인하셨습니까?'
      }
      return message
    }

    const onValidate = (vLotCd) => {
      const validRateList = [...info.value.lotList.find(lot => lot.vLotCd === vLotCd)?.
        rateList.filter(rate => rate.nRate && rate.vKey.indexOf('_SUM') < 0)]
      const validMateList = [...info.value.mateList.filter(mate => mate.vRecType === 'MATE' &&
        validRateList.filter(rate => rate.vMatePkCd === mate.vMatePkCd).length > 0)]

      if (summaryDatas?.value?.['lot_' + vLotCd]?.toNumber() !== 100) {
        openAsyncAlert({ message: '원료 배합 합이 100이 아닙니다.' })
        return false
      }
      else if (validMateList.filter(mate => mate.vFlagExistsMate === 'N').length > 0) {
        openAsyncAlert({ message: '해당 플랜트에 없는 원료가 존재합니다.' })
        return false
      }
      else if (validMateList.filter(mate => mate.vFlagUsableMate === 'N').length > 0) {
        openAsyncAlert({ message: '해당 처방에 단종된 원료가 존재합니다.' })
        return false
      }
      else if (validMateList.filter(mate => mate.vMateBanInfo === 'P' || mate.vMateBanInfo === 'R').length > 0) {
        openAsyncAlert({ message: '해당 처방에 금지 원료 또는 비활성 원료가 존재합니다.' })
        return false
      }
      else if (validMateList.filter(mate => !mate.vMateCd).length > 0) {
        openAsyncAlert({ message: '해당 처방에 임시원료가 존재합니다.' })
        return false
      }
      else {
        return true
      }
    }

    const onSendBomPop = (o) => {
      if (onValidate(o.vLotCd)) {
        popParams.value = {
          vLabNoteCd: info.value.contVO.vLabNoteCd,
          vContPkCd: info.value.contVO.vContPkCd,
          nVersion: info.value.verVO.nVersion,
          vLotCd: o.vLotCd,
          vPlantCd: info.value.contVO.vPlantCd,
          vCodeType: info.value.contVO.vCodeType,
          vFlagTestRes: 'N', //임시전송(BOM_TEMP_SEND)일 경우
          vMoveUrl: `/${noteTypeNm}/all-lab-note-${info.value.contVO.vPageType}-process?vLabNoteCd=${info.value.contVO.vLabNoteCd}&vTabId=bom`,
        }

        popSelectFunc.value = onTabClick
        fnOpenPopup('BomSendPop', false)
      }
    }

    const onPilotPrescription = (o) => {
      if (onValidate(o.vLotCd)) {
        goProcess('pilot', o)
      }
    }

    const goProcess = (vTabId, lotVO = {}, contVO = {}) => {
      const query = {
        vLabNoteCd: info.value.contVO.vLabNoteCd,
        vTabId,
      }

      const isAerosol = vTabId === 'confirm' && contVO.vCodeType === 'AEROSOL'
      if (vTabId === 'pilot' || isAerosol) {
        query.nFormulaVer = info.value.verVO.nVersion
        query.vFormulaLotCd = lotVO.vLotCd

        if (isAerosol) {
          query.vFlagAerosol = 'Y'
        }
      }

      router.push({ path: `/${noteTypeNm}/all-lab-note-${info.value.contVO.vPageType}-process`, query })
    }

    const onToggleRowSelect = (e, i) => {
      const result = mixmatUtils.fnToggleRowSelect(e, i)
      if (result === 'SHIFT' || result === 'ALT') {
        const { gridVars } = mixmatUtils.opts
        const materials = gridVars.materials
        const rowSelectList = materials.filter(mate => mate.rowSelectYn === 'Y')
        if (rowSelectList.filter(mate => mate.vRecType === 'GRP').length > 0 && rowSelectList.filter(mate => mate.vRecType === 'MATE').length > 0) {
          openAsyncAlert({ message: '원료와 그룹은 동시에 선택할 수 없습니다.' })

          materials.map(mate => {
            mate.rowSelectYn = 'N'
          })
        }
      }
    }

    const onDragAndDrop = () => {
      draggable.drop = true
    }

    const onDeleteKeyEvent = (e) => {
      if (e.key === 'Delete') {
        if (!refTableBodyLeft.value || !refTableBodyCenter.value) {
          return
        }

        const $arrLeftCell = refTableBodyLeft.value.querySelectorAll('.anypjt-grid-cell-select')
        const $arrCenterCell = refTableBodyCenter.value.querySelectorAll('.anypjt-grid-cell-select')

        if ($arrLeftCell.length > 0 && $arrCenterCell.length > 0) {
          openAsyncAlert({ message: '원료와 함량은 동시에 삭제 할 수 없습니다.' })
          mixmatUtils.clearMultipleSelectCell()
          return
        }
        else if ($arrLeftCell.length > 0) {
          let matePkCdList = []
          let grpCdList = []
          let grpCnt = 0
          let mateCnt = 0
          for (let i = 0; i < $arrLeftCell.length; i++) {
            const cell = $arrLeftCell[i]?.parentElement?.dataset

            if (cell.rowType === 'GRP') {
              grpCnt++
              grpCdList = [...new Set([...grpCdList, cell.rowCd])]
            }
            else {
              mateCnt++
              matePkCdList = [...new Set([...matePkCdList, cell.rowCd])]
            }
          }

          if (grpCnt > 0 && mateCnt > 0) {
            openAsyncAlert({ message: '원료와 그룹은 동시에 삭제 할 수 없습니다.' })
            mixmatUtils.clearMultipleSelectCell()
            return
          }
          else if (grpCnt >= 2) {
            openAsyncAlert({ message: '그룹은 1개의 그룹씩 삭제 가능합니다.' })
            mixmatUtils.clearMultipleSelectCell()
            return
          }
          else {
            let deleteList = []
            if (grpCnt > 0) {
              deleteList = info.value.mateList.filter((mate) => grpCdList.includes(mate.vGrpCd))
              deleteGrpData(deleteList)
            }
            else {
              deleteList = info.value.mateList.filter((mate) => matePkCdList.includes(mate.vMatePkCd))
              deleteMataData(deleteList)
            }
          }

          mixmatUtils.clearFocusCell()
          mixmatUtils.clearMultipleSelectCell()
        }
        else if ($arrCenterCell.length > 0) {
          let newLotList = [...info.value.lotList]
          for (let i = 0; i < $arrCenterCell.length; i++) {
            const cell = $arrCenterCell[i]?.querySelector('.anypjt-grid-cell')?.dataset

            if (cell?.columnId === 'rate') {
              newLotList.filter(lot => lot.vLotCd === cell.vLotCd).map(lot => {
                lot.rateList.map(rate => {
                  if (rate.nRate && rate.vMatePkCd === cell.vMatePkCd) {
                    rate.vFlagSave = 'Y'
                    rate.nRate = null

                    context.emit('onChangeRateList', lot.rateList)
                  }
                })
              })
            }
          }

          context.emit('onLotClick', info.value.mateList, newLotList)
          context.emit('onIsChange')
          mixmatUtils.clearMultipleSelectCell()
        }
        else {
          return
        }
      }
    }

    const onLotDblClickEvent = (e) => {
      const $arrCenterCell = refTableBodyCenter.value.querySelector('.anypjt-grid-cell-focus')
      if ($arrCenterCell && $arrCenterCell.dataset && $arrCenterCell.dataset.vLotCd) {
        onLotClick(info.value.lotList.find(lot => lot.vLotCd === $arrCenterCell.dataset.vLotCd))
      }
    }

    onUpdated(() => {
      const contextMenuWrap = document.querySelector('.mx-context-menu-items')
      if (contextMenuWrap) {
        const items = contextMenuWrap.querySelectorAll('.mx-item-row')
        for (let i = 0; i < items.length; i++) {
          const sapn = items[i].querySelector('.label')
          if (sapn) {
            sapn.style.padding = '5px 0px 5px 0px'
          }
        }
      }

      const wrap = document.querySelector('.material-excel__ver--lists')
      if (wrap) {
        wrap.style.marginBlockStart = '-31px'
      }
    })

    onMounted(() => {
      document.addEventListener('keydown', onDeleteKeyEvent)
      // document.addEventListener('dblclick', onLotDblClickEvent)
    })

    return {
      commonUtils,
      info,
      store,
      contextMenu,
      pageVars,
      gridVars,
      gridStyle,
      summaryDatas,
      scrollPostion,
      mixmatUtils,
      noteType,

      popupContent,
      popParams,
      popSelectFunc,
      fnOpenMateSearchPop,

      refDivGridWrap,
      refGridFocus,
      refDivHeaderCenter,
      refDivBodyLeft,
      refDivBodyLeftSelectLayer,
      refDivBodyCenterInput,
      refTableBodyLeft,
      refDivBodyCenter,
      refDivBodyCenterSelectLayer,
      refTableBodyCenter,
      refDivBodyScrollY,
      refDivBodyScrollX,
      refDivFooterCenter,
      refContextMenuWrap,
      refDivBodyLeftInput,
      refLayerMateMemoWrap,

      canShowMateOrGroup,
      showHideHelpLayer,
      fnRawMaterialSearch,
      onTabClick,
      onVerNmChange,
      onMusoguPop,
      onProblemHisPop,
      onHal4LotSetPop,
      onMateTestResultRegPop,
      onSearchSubMateList,
      onMaxMixPop,
      onLotClick,
      onLotRateChange,
      onLotGramChange,
      onAddLot,
      onLotSideInfo,
      onDefaultIngredientDataPop,
      onMateOrderChangePop,
      onContextMenu,
      onContextHeader,
      onRateOneLotSelect,
      onContextMenuItemClick,
      onProcess,
      onToggleRowSelect,
      onDragAndDrop,
    }
  },
})
</script>
