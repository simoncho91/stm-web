<template>
  <div class="contents-box contents-box__large contents-box__53">
    <div class="contents-box__inner">
      <div class="ui-tab">
        <div class="ui-tab__inner">
          <div class="ui-tab__header">
            <ul class="ui-list ui-tab__lists">
              <li class="ui-tab__list"
                v-for="(vo, idx) in tab1List"
                :class="selectedTab[0] === vo.tabId ? 'is-active' : ''"
                :key="'myboardTab4_' + idx"
              >
                <a href="#" class="ui-tab__link" @click.prevent="fnSelectedTabEvent(vo, 0)">
                  {{ vo.tabNm }}
                </a>
              </li>
            </ul>
          </div>
          <div class="ui-tab__body" id="myboard_examination" v-if="selectedTab[0] === 'myboard_examination'">
            <MyBoardExamination></MyBoardExamination>
          </div>
          <div class="ui-tab__body" id="myboard_user_current" v-if="selectedTab[0] === 'myboard_user_current'">
            <MyBoardUserCurrentState></MyBoardUserCurrentState>
          </div>
          <div class="ui-tab__body" id="myboard_brand_current" v-if="selectedTab[0] === 'myboard_brand_current'">
            <MyBoardBrandCurrentState></MyBoardBrandCurrentState>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="contents-box contents-box__47">
    <div class="contents-box__inner">
      <div class="ui-tab">
        <div class="ui-tab__inner">
          <div class="ui-tab__header">
            <ul class="ui-list ui-tab__lists">
              <li class="ui-tab__list"
                v-for="(vo, idx) in tab2List"
                :class="selectedTab[1] === vo.tabId ? 'is-active' : ''"
                :key="'myboardTab4_' + idx"
              >
                <a href="#" class="ui-tab__link" @click.prevent="fnSelectedTabEvent(vo, 1)">
                  {{ vo.tabNm }}
                </a>
              </li>
            </ul>
          </div>
          <div class="ui-tab__body" id="myboard_memo" v-if="selectedTab[1] === 'myboard_memo'">
            <MyBoardMemo></MyBoardMemo>
          </div>
          <div class="ui-tab__body" id="myboard_alarm" v-if="selectedTab[1] === 'myboard_alarm'">
            <MyBoardAlarm ></MyBoardAlarm>
          </div>
          <div class="ui-tab__body" id="myboard_approval" v-if="selectedTab[1] === 'myboard_approval'">
            <MyBoardApproval></MyBoardApproval>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, ref } from 'vue'
import { useStore } from 'vuex'
export default {
  name: 'MyBoardEM',
  components: {
    MyBoardMemo: defineAsyncComponent(() => import('@/components/labcommon/MyBoardMemo.vue')),
    MyBoardAlarm: defineAsyncComponent(() => import('@/components/labcommon/MyBoardAlarm.vue')),
    MyBoardApproval: defineAsyncComponent(() => import('@/components/labcommon/MyBoardApproval.vue')),
    MyBoardExamination: defineAsyncComponent(() => import('@/components/labcommon/MyBoardExamination.vue')),
    MyBoardBrandCurrentState: defineAsyncComponent(() => import('@/components/labcommon/MyBoardBrandCurrentState.vue')),
    MyBoardUserCurrentState: defineAsyncComponent(() => import('@/components/labcommon/MyBoardUserCurrentState.vue')),
  },
  setup () {
    const store = useStore()
    const myInfo = store.getters.getMyInfo()
    const selectedTab = ref(['', 'myboard_memo'])
    const tab1List = ref([])
    const tab2List = [
      { tabId: 'myboard_memo', tabNm: 'Memo' },
      { tabId: 'myboard_alarm', tabNm: '알림' },
      { tabId: 'myboard_approval', tabNm: '결재함' },
    ]

    const fnSelectedTabEvent = (item, idx) => {
      selectedTab.value[idx] = item.tabId
    }

    const init = () => {
      if (myInfo) {
        if (myInfo.managerYn !== 'Y') {
          tab1List.value.push({ tabId: 'myboard_examination', tabNm: 'Examination' })
          selectedTab.value[0] = 'myboard_examination'
        } else {
          tab1List.value.push({ tabId: 'myboard_user_current', tabNm: '담당자별' })
          tab1List.value.push({ tabId: 'myboard_brand_current', tabNm: '브랜드별' })
          selectedTab.value[0] = 'myboard_user_current'
        }
      }
    }

    init()

    return {
      selectedTab,
      tab1List,
      tab2List,
      fnSelectedTabEvent,
    }
  }
}
</script>