<template>
  <table class="ui-table__contents">
    <colgroup>
      <col style="width:17rem">
      <col style="width:auto">
      <col style="width:17rem">
      <col style="width:auto">
    </colgroup>
    <tbody>
      <tr>
        <th>무소구 항목</th>
        <td colspan="3">
          <div class="ui-checkbox__list">
            <div class="ui-checkbox__inner">
              <ap-input-check
                v-model:model="flagNotAdd"
                value="Y"
                false-value="N"
                label="무소구 성분"
                id="flagNotAdd"
              >
              </ap-input-check>
            </div>
          </div>
        </td>
      </tr>
      <template v-if="flagNotAdd === 'Y'">
        <tr>
          <td colspan="4" class="inside-td">
            <table class="ui-table__contents">
              <colgroup>
                <col style="width:17rem">
              </colgroup>
              <tbody>
                <tr>
                  <td colspan="4">
                    <div class="search-result-table">
                      <table class="ui-table__reset ui-table__search-result ui-table__border table_not_add">
                        <thead>
                          <tr>
                            <th>공통항목</th>
                            <th>특화항목</th>
                            <th>협의항목</th>
                            <th>주의사항</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>
                              <ul class="ul_not_add" v-if="mtr04List">
                                <li 
                                  v-for="(vo, index) in mtr04List" :key="'mtr04_' + index"
                                  :class="[vo.inputClass ? vo.inputClass : '']"
                                >
                                  <ap-input-check
                                    v-model:model="vo.vTag2Cd"
                                    :value="vo.vSubCode"
                                    :label="vo.vSubCodenm"
                                    :id="'mtr04_' + index"
                                    @click="checkBuffer3Event"
                                  >
                                  </ap-input-check>
                                </li>
                                <template v-if="mtr04List && maxCodeSize > mtr04List.length">
                                  <li v-for="(vo) in (maxCodeSize - mtr04List.length)" :key="'mtr04temp_' + vo"></li>
                                </template>
                              </ul>
                            </td>
                            <td>
                              <ul class="ul_not_add" v-if="mtr05List">
                                <li
                                  v-for="(vo, index) in mtr05List" :key="'mtr05_' + index"
                                  :class="[vo.inputClass ? vo.inputClass : '']"
                                >
                                  <ap-input-check
                                    v-model:model="vo.vTag2Cd"
                                    :value="vo.vSubCode"
                                    :label="vo.vSubCodenm"
                                    :id="'mtr05_' + index"
                                  >
                                  </ap-input-check>
                                </li>
                                <template v-if="mtr05List && maxCodeSize > mtr05List.length">
                                  <li v-for="(vo) in (maxCodeSize - mtr05List.length)" :key="'mtr05temp_' + vo"></li>
                                </template>
                              </ul>
                            </td>
                            <td>
                              <ul class="ul_not_add" v-if="mtr06List">
                                <li v-for="(vo, index) in mtr06List" :key="'mtr06_' + index">
                                  <ap-input-check
                                    v-model:model="vo.vTag2Cd"
                                    :value="vo.vSubCode"
                                    :label="vo.vSubCodenm"
                                    :id="'mtr06_' + index"
                                  >
                                  </ap-input-check>
                                </li>
                                <template v-if="mtr06List && maxCodeSize > mtr06List.length">
                                  <li v-for="(vo) in (maxCodeSize - mtr06List.length)" :key="'mtr06temp_' + vo"></li>
                                </template>
                              </ul>
                            </td>
                            <td>
                              <div>
                                ※공통 항목 <br>
                                피이지 : 표시 예)PEG, PEG계면활성제, PEG화합물 등<br>
                                카본블랙 : 흑색계열한정<br>
                                <br>
                                ※특화 항목<br>
                                트리클로산 : 사용 후 씻어내는 인체세정용,<br>
                                데오도런트(스프레이 제품 제외), 페이스파우더,<br>
                                피부결점을 감추기 위해 국소적으로 사용하는 파운데이션<br>
                                (예: 블레미쉬컨실러) 만 허용<br>
                                솝(soap) : 페이셜/바디/헤어 세정만 허용<br>
                                파라페닐렌디아민 : 산화형 염모제만 허용<br>
                                <br>
                                ※협의 항목<br>
                                모든 [협의 항목]은 선택 전, 분석담당자와의 사전협의가<br>
                                반드시 필요합니다.
                              </div>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr>
          <th>비고</th>
          <td colspan="3">
            <div class="ui-textarea-box mt-15" id="error_wrap_vNotAddNote">
              <ap-text-area
                v-model:value="notAddNote"
                :maxlength="300"
                :is-with-byte="true"
                id="notAddNote"
              >
              </ap-text-area>
              <span class="error-msg" id="error_msg_vNotAddNote"></span>
            </div>
          </td>
        </tr>
      </template>
    </tbody>
  </table>
</template>

<script>
import { ref, watch, computed, inject } from 'vue'
import { useStore } from 'vuex'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'NotAddIngredientRegister',
  props: {
    vFlagNotAdd: {
      type: String,
      default: ''
    },
    vNotAddNote: {
      type: String,
      default: ''
    },
  },
  emits: ['update:vFlagNotAdd', 'update:vNotAddNote'],
  setup (props, context) {
    const maxCodeSize = ref()
    const store = useStore()
    const storedNoteInfo = computed(() => store.getters.getNoteInfo())
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert } = useActions(['openAsyncAlert'])
    const flagNotAdd = ref('N')
    const notAddNote = ref('')

    const mtr04List = ref(null)
    const mtr05List = ref(null)
    const mtr06List = ref(null)

    const checkBuffer3Event = async (tag2Cd) => {
      if (commonUtils.isNotEmpty(tag2Cd)) {
        const tagInfo = mtr04List.value.filter(item => item.vSubCode === tag2Cd)[0]

        if (tagInfo && commonUtils.isNotEmpty(tagInfo.vBuffer3) && (tagInfo.vBuffer3 === 'PIGMENT' || tagInfo.vBuffer3 === 'PERFUME')) {
          const partTagInfo = mtr04List.value.filter(item => item.vBuffer3 === tagInfo.vBuffer3)
          const anotherTagInfo = partTagInfo.filter(item => commonUtils.isNotEmpty(item.vTag2Cd) && item.vSubCode !== tag2Cd)
          if (partTagInfo && partTagInfo.length > 0 && anotherTagInfo && anotherTagInfo.length > 0) {
            let message = ''

            partTagInfo.forEach((item, idx) => {
              message += (idx !== 0 ? ', ' : '') + item.vSubCodenm
            })

            await openAsyncAlert({ message: commonUtils.checkPostPosition(message, ['은', '는']) + ' 1가지만 선택할 수 있습니다.' })
            mtr04List.value.forEach(item => {
              if (item.vBuffer3 === tagInfo.vBuffer3 && commonUtils.isNotEmpty(item.vTag2Cd) && item.vSubCode !== tag2Cd) {
                item.vTag2Cd = ''
              }
            })

          }
        } else if (tagInfo && commonUtils.isNotEmpty(tagInfo.vBuffer3) && (tagInfo.vBuffer3.indexOf('OIL') > -1)) {
          const anotherTagInfo = mtr04List.value.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)
                                                                && commonUtils.isNotEmpty(item.vBuffer3) 
                                                                && item.vBuffer3.indexOf('OIL') > -1
                                                                && item.vBuffer3 !== tagInfo.vBuffer3)


          let message = ''
          if (tagInfo.vBuffer3 === 'OIL01' && anotherTagInfo.length > 0) {
            message = '광물성/실리콘 오일은 오일과 동시 선택이 불가합니다.'
          } else if (tagInfo.vBuffer3 === 'OIL00' && anotherTagInfo.length > 0) {
            message = '오일은 광물성/실리콘 오일과 동시 선택이 불가합니다.'
          }

          if (message !== '') {
            await openAsyncAlert({ message })
            mtr04List.value.forEach(item => {
              if (commonUtils.isNotEmpty(item.vBuffer3) && item.vBuffer3.indexOf('OIL') > -1 && item.vBuffer3 !== tagInfo.vBuffer3) {
                item.vTag2Cd = ''
              }
            })
          }
        }
      }
    }

    const notAddNoteCheckByte = () => {
      let isOk = true

      if (!commonUtils.checkByte(notAddNote.value, 300)) {
        isOk = false
      }

      return isOk
    }

    const init = (noteInfo) => {
      const prodType1Cd = noteInfo.vProdType1Cd
      const prodType2Cd = noteInfo.vProdType2Cd

      flagNotAdd.value = props.vFlagNotAdd || 'N'
      notAddNote.value = props.vNotAddNote || ''

      if (noteInfo.mtr04List && noteInfo.mtr04List.length > 0) {
        if (commonUtils.isNotEmpty(prodType1Cd)) {
          if (commonUtils.isNotEmpty(prodType2Cd)) {
            mtr04List.value = noteInfo.mtr04List.filter(item => commonUtils.isEmpty(item.vBuffer2) || item.vBuffer2.indexOf(prodType2Cd) === -1)
          } else {
            mtr04List.value = noteInfo.mtr04List
          }
        }

        if (commonUtils.isNotEmpty(prodType2Cd)) {
          mtr05List.value = noteInfo.mtr05List.filter(item => commonUtils.isNotEmpty(item.vBuffer2) && item.vBuffer2.indexOf(prodType2Cd) > -1)
        }

        mtr06List.value = noteInfo.mtr06List

        if (mtr04List.value) {
          const pigmentList = mtr04List.value.filter(item => item.vBuffer3 === 'PIGMENT')
          const perfumeList = mtr04List.value.filter(item => item.vBuffer3 === 'PERFUME')
          const siliconeList = mtr04List.value.filter(item => item.vBuffer3 === 'SILICONE')
          const preserveList = mtr04List.value.filter(item => item.vBuffer3 === 'PRESERVE')

          const groupingList = [pigmentList, perfumeList, siliconeList, preserveList]

          groupingList.forEach(list => {
            if (list && list.length > 0) {
              list.forEach((item, index) => {
                if (index === 0) {
                  mtr04List.value.map((v) => {
                    if (v.vSubCode === item.vSubCode && mtr04List.value[index - 1]) {
                      mtr04List.value[index - 1].inputClass = 'border-bottom__deepgray'
                    } else if (v.vSubCode === item.vSubCode && !mtr04List.value[index - 1]) {
                      v.inputClass = 'border-top__deepgray'
                    }
                  })
                } else if (list.length !== 1 && index === list.length - 1) {
                  mtr04List.value.map(v => {
                    if (v.vSubCode === item.vSubCode) {
                      v.inputClass = 'border-bottom__deepgray'
                    }
                  })
                }
              })
            }
          })

          const arrCodeSize = [
                            mtr04List.value ? mtr04List.value.length : 0, 
                            mtr05List.value ? mtr05List.value.length : 0, 
                            mtr06List.value ? mtr06List.value.length : 0
                          ]

          maxCodeSize.value = Math.max(...arrCodeSize)
        }
      }
    }

    if (storedNoteInfo.value && commonUtils.isNotEmpty(storedNoteInfo.value.vLabNoteCd)) {
      init(storedNoteInfo.value)
    }

    // 내용물 개요 제품유형 변경 시 store에 noteInfo 적재. 변경 내용 추적을 위해 사용
    watch(() => storedNoteInfo.value, (newVal) => {
      init(newVal)
    })

    watch(() => flagNotAdd.value, (newVal) => {
      context.emit('update:vFlagNotAdd', newVal)
    })

    watch(() => props.vFlagNotAdd, (newVal) => {
      flagNotAdd.value = newVal
    })

    watch(() => props.vNotAddNote, (newVal) => {
      notAddNote.value = newVal
    })

    watch(() => notAddNote.value, (newVal) => {
      context.emit('update:vNotAddNote', newVal)
    })

    return {
      flagNotAdd,
      notAddNote,
      maxCodeSize,
      mtr04List,
      mtr05List,
      mtr06List,
      checkBuffer3Event,
      notAddNoteCheckByte,
    }
  }
}
</script>