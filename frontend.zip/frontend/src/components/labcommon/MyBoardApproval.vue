<template>
  <div class="myboard-table myboard-memo-area">
    <div class="myboard-table__inner">
      <table class="ui-table text-center">
        <colgroup>
          <!-- <col style="width:10%;"> -->
          <col style="width:40%;">
          <col style="width:13%;">
          <col style="width:17%;">
          <col style="width:15%;">
          <col style="width:15%;">
        </colgroup>
        <thead>
          <tr>
            <!-- <th>구분</th> -->
            <th>제목</th>
            <th>요청자</th>
            <th>요청일</th>
            <th>의견보기</th>
            <th>의견작성</th>
          </tr>
        </thead>
        <tbody v-if="approvalList && approvalList.length > 0">
          <tr v-for="(appr, index) in approvalList" :key="'appr_' + index">
            <!-- <td></td> -->
            <td class="text-left">
              <a
                href="#"
                class="tit-link"
                @click.prevent="fnGoView(appr)"
              >{{ appr.vDraftTitle }}</a>
            </td>
            <td>{{ appr.vDraftUsernm }}</td>
            <td>{{ commonUtils.changeStrDatePattern(appr.vDraftDtm) }}</td>
            <td>
              <button
                type="button"
                class="ui-button ui-button__width--70 ui-button__height--28 ui-button__border--blue ui-button__radius--2"
                @click="fnOpenOpinionViewPopup(appr.vApprCd)"
              >
                의견보기
              </button>
            </td>
            <td>
              <button
                type="button"
                class="ui-button ui-button__width--70 ui-button__height--28 ui-button__bg--blue ui-button__radius--2"
                @click="fnOpenOpinionWritePopup(appr)"
              >
                의견작성
              </button>
            </td>
          </tr>
        </tbody>
        <tbody v-else>
          <tr>
            <td colspan="6">
              <div class="no-result">{{ t('common.msg.no_data') }}</div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @selectFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'
import { useMyboardCommon } from '@/compositions/labcommon/useMyboardCommon'
import { useApproval } from '@/compositions/approval/useApproval'

export default {
  name: 'MyBoardApproval',
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    OpinionViewPop: defineAsyncComponent(() => import('@/components/approval/popup/OpinionViewPop.vue')),
    OpinionWritePop: defineAsyncComponent(() => import('@/components/approval/popup/OpinionWritePop.vue'))
  },
  setup () {
    const commonUtils = inject('commonUtils')
    const t = inject('t')
    const approvalList = ref([])

    const {
      selectMyBoardApprovalList,
    } = useMyboardCommon()

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenOpinionViewPopup,
      fnOpenOpinionWritePopup,
      fnGoView,
    } = useApproval()

    const init = async () => {
      const result = await selectMyBoardApprovalList()

      if (result) {
        approvalList.value = result
      }
    }

    init()

    return {
      commonUtils,
      t,
      approvalList,
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenOpinionViewPopup,
      fnOpenOpinionWritePopup,
      fnGoView,
    }
  }
}
</script>