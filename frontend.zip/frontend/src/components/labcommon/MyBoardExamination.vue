<template>
  <div class="myboard-table myboard-memo-area">
    <div class="myboard-table__inner">
      <table class="ui-table text-center">
        <!-- 2023.03.27 : col width 수치 수정 -->
        <colgroup>
          <col style="width:13%">
          <col style="width:auto">
          <col style="width:12%">
          <col style="width:15%">
          <col style="width:12%">
          <col style="width:14%">
        </colgroup>
        <!--// 2023.03.27 : col width 수치 수정 -->
        <thead>
          <tr>
            <th>CODE</th>
            <th>NAME</th>
            <th>LOT NO.</th>
            <th>EXAMINATION</th>
            <th>STATUS</th>
            <th>DATE</th>
          </tr>
        </thead>
        <tbody v-if="examinationList && examinationList.length > 0">
          <tr v-for="(exam, index) in examinationList" :key="'exam_' + index">
            <td>{{ exam.vContCd }}</td>
            <td class="tit">
              <div class="tit__inner">
                <a href="#" class="tit-link" @click.prevent="goNoteDetail(exam)">{{ exam.vContNm }}</a>
              </div>
            </td>
            <td>Ver #{{ Number(exam.nVersion) < 10 ? '0' + exam.nVersion : exam.nVersion }}<br/>{{ exam.vLotNm }}</td>
            <td>{{ exam.vLabMrqTypeNm }}</td>
            <td><span class="status-success">{{ exam.vStatusNm }}</span>
            </td>
            <td>{{ commonUtils.changeStrDatePattern(exam.vLabReqDtm) }}</td>
          </tr>
        </tbody>
        <tbody v-else>
          <tr>
            <td colspan="6">
              <div class="no-result">{{ t('common.msg.no_data') }}</div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
import { ref, inject } from 'vue'
import { useMyboardCommon } from '@/compositions/labcommon/useMyboardCommon'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useRouter } from 'vue-router'
import { useStore } from 'vuex'

export default {
  name: 'MyBoardExamination',
  setup () {
    const commonUtils = inject('commonUtils')
    const t = inject('t')
    const examinationList = ref([])
    const router = useRouter()
    const store = useStore()
    const noteTypeNm = store.getters.getNoteTypeNm()

    const {
      selectExaminationList,
    } = useMyboardCommon()

    const {
      fnSetRecentLog,
    } = useLabCommon()

    const goNoteDetail = async (item) => {
      const pageType = item.vLabTypeCd === 'LNC07_01' ? 'prd' : (item.vLabTypeCd === 'LNC07_02' ? 'half' : 'nonprd')
      if (commonUtils.isNotEmpty(item.vContCd)) {
        item.vPageType = pageType
        await fnSetRecentLog(item)
      }

      const path = `/${noteTypeNm}/all-lab-note-test-req-board`
      router.push({ path, query: { vLabNoteCd: item.vLabNoteCd }})
    }

    const init = async () => {
      examinationList.value = await selectExaminationList()
    }

    init()

    return {
      commonUtils,
      t,
      examinationList,
      goNoteDetail,
    }
  }
}
</script>