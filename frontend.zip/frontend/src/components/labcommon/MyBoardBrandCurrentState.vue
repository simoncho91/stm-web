<template>
  <div class="myboard-table myboard-memo-area mt-1">
    <div class="memo-header__btn form-flex">
      <ap-month-picker
        v-model:date="searchParams.vStartYm"
      >
      </ap-month-picker>
      &nbsp;&nbsp;~&nbsp;&nbsp;
      <ap-month-picker
        v-model:date="searchParams.vEndYm"
      >
      </ap-month-picker>
      <button class="ml-5 ui-button ui-button__bg--lightgray" @click="fnBrandCurrentStateSearch()">검색</button>
    </div>
    <div class="myboard-table__inner mt-1">
      <table class="ui-table text-center">
        <colgroup>
          <col style="width:7%">
          <col style="width:23%">
          <col style="width:15%">
          <col style="width:15%">
          <col style="width:15%">
          <col style="width:15%">
          <col style="width:10%">
        </colgroup>
        <thead>
          <tr>
            <th rowspan="2">No.</th>
            <th rowspan="2">브랜드</th>
            <th rowspan="2">현재 개발중</th>
            <th colspan="3">
              {{ commonUtils.changeStrDatePattern(vStartYm) }} ~ {{ commonUtils.changeStrDatePattern(vEndYm) }}
            </th>
            <th rowspan="2">합계</th>
          </tr>
          <tr class="border-square">
            <th>개발완료</th>
            <th>출시완료</th>
            <th>개발취소</th>
          </tr>
        </thead>
        <tbody v-if="list && list.length > 0">
          <tr v-for="(vo, index) in list" :key="'user_state_' + index" class="tr-contents">
            <td>{{ index + 1 }}</td>
            <td>{{ vo.vBrdNm }}</td>
            <td>
              <template v-if="vo.nIngCnt > 0">
                <a href="#" class="tit-link txt_blue" @click.prevent="fnCurrentStateSearch(vo, 'ING')">{{ vo.nIngCnt }}</a>
              </template>
              <template v-else>
                0
              </template>
            </td>
            <td>
              <template v-if="vo.nCompleteCnt > 0">
                <a href="#" class="tit-link txt_blue" @click.prevent="fnCurrentStateSearch(vo, 'COMPLETE')">{{ vo.nCompleteCnt }}</a>
              </template>
              <template v-else>
                0
              </template>
            </td>
            <td>
              <template v-if="vo.nReleaseCnt > 0">
                <a href="#" class="tit-link txt_blue" @click.prevent="fnCurrentStateSearch(vo, 'RELEASE')">{{ vo.nReleaseCnt }}</a>
              </template>
              <template v-else>
                0
              </template>
            </td>
            <td>
              <template v-if="vo.nCancelCnt > 0">
                <a href="#" class="tit-link txt_blue" @click.prevent="fnCurrentStateSearch(vo, 'CANCEL')">{{ vo.nCancelCnt }}</a>
              </template>
              <template v-else>
                0
              </template>
            </td>
            <td>{{ Number(vo.nIngCnt) + Number(vo.nCompleteCnt) + Number(vo.nReleaseCnt) + Number(vo.nCancelCnt) }}</td>
          </tr>
        </tbody>
        <tbody v-else>
          <tr>
            <td colspan="7">
              <div class="no-result">{{ t('common.msg.no_data') }}</div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
import { reactive, ref, inject } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useRouter } from 'vue-router'
import { useMyboardCommon } from '@/compositions/labcommon/useMyboardCommon'

export default {
  name: 'MyBoardUserCurrentState',
  setup () {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const router = useRouter()
    const { openAsyncAlert } = useActions(['openAsyncAlert'])
    const vStartYm = ref('')
    const vEndYm = ref('')
    const searchParams = reactive({
      vStartYm: '',
      vEndYm: '',
    })

    const list = ref(null)

    const {
      noteType,
      noteTypeNm,
      selectBrandCurrentStateInfo,
    } = useMyboardCommon()

    const fnBrandCurrentStateSearch = async () => {
      const startYm = Number(searchParams.vStartYm.replace('.', ''))
      const endYm = Number(searchParams.vEndYm.replace('.', ''))

      if (startYm > endYm) {
        openAsyncAlert({ message: '검색 년월 설정을 다시 확인해 주세요.' })
        return
      }

      list.value = await selectBrandCurrentStateInfo(searchParams)
      vStartYm.value = searchParams.vStartYm
      vEndYm.value = searchParams.vEndYm
    }

    const fnCurrentStateSearch = (info, flag) => {
      const params = {
        vStateBrdCd: info.vBrdCd,
        vStartYm: searchParams.vStartYm,
        vEndYm: searchParams.vEndYm,
        vFlagState: flag,
        vStateType: 'brand'
      }
      
      sessionStorage.setItem('searchParamsDashboard' + noteType, JSON.stringify(params))
      router.push({ path: `/${noteTypeNm}/all-lab-note-prd-list`})
    }

    const init = async () => {
      const date = new Date()
      let year = date.getFullYear()
      const month = date.getMonth() + 1

      if (Number(month) >= 7) {
        searchParams.vStartYm = (year - 1) + '07'
      } else {
        searchParams.vStartYm = year + '07'
      }

      searchParams.vEndYm = year + ('0' + month).slice(-2)

      fnBrandCurrentStateSearch()
    }

    init()

    return {
      t,
      commonUtils,
      searchParams,
      list,
      vStartYm,
      vEndYm,
      fnBrandCurrentStateSearch,
      fnCurrentStateSearch,
    }
  }
}
</script>

<style scoped>
  .border-square th { border-radius: inherit !important;}
</style>