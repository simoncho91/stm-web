<template>
  <div class="material-wrap material-wrap__pop">
    <div class="material-tags">
      <span
        class="material-tag material-tag__noIng color-gray"
        v-if="mateInfo.vFlagNotIngrYn === 'Y'"
      >구성성분 없음</span>
      <span
        class="material-tag material-tag__blue color-gray"
        v-if="mateInfo.vFlagTcodeMate === 'Y'"
      >문제이력</span>
      <span
        class="material-tag material-tag__labB color-gray"
        v-if="mateInfo.vFlagMrq030Mate === 'Y'"
      >연구용B</span>
      <span
        class="material-tag material-tag__noMusogu color-gray"
        v-if="mateInfo.vFlagFreeBanMate === 'Y'"
      >무소구금지</span>
      <span
        class="material-tag material-tag__function color-gray"
        v-if="mateInfo.vFlagMateFunc === 'Y'"
      >기능성</span>
      <span
        class="material-tag material-tag__ban color-gray"
        v-if="mateInfo.vMateBanInfo === 'P'"
      >금지</span>
      <span
        class="material-tag material-tag__disabled color-gray"
        v-if="mateInfo.vMateBanInfo === 'R'"
      >비활성</span>
      <span
        class="material-tag material-tag__Gban color-gray"
        v-if="mateInfo.vFlagMateGlobal === 'Y'"
      >G금지</span>
      <span
        class="material-tag material-tag__Glimit color-gray"
        v-if="mateInfo.vFlagGlbLimitMate === 'Y'"
      >G제한</span>
      <span
        class="material-tag material-tag__deepgray color-gray"
        v-if="mateInfo.vFlagExistsMate === 'N' || mateInfo.vFlagUsableMate === 'N'"
      >단종</span>
      <span
        class="material-tag material-tag__blue color-gray border-gray bg-gray"
        v-if="mateInfo.vMateDbTypeCd === 'SUP'"
      >임시코드</span>
    </div>
    <div class="material-name">
      {{ mateInfo.vMateNm }}
    </div>
  </div>
</template>

<script>
export default {
  name: 'MateName',
  props: {
    mateInfo: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  setup (props) {
    return {}
  }
}
</script>