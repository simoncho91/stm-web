<template>
  <td class="td-content anypjt-grid-td apg-text-right" :class="[
    lotVo.activeYn === 'Y' ? 'border-left__blue' : '',
    lotVo.activeYn === 'N' && lotVo.openYn === 'Y' ? '' : lotVo.borderClass,
  ]" @contextmenu="onRateOneLotSelect(lotVo)">
    <div v-if="isFolder" class="anypjt-grid-cell"></div>
    <div v-else class="material-calc__text anypjt-grid-cell" :data-column-id="'rate'"
      :data-v-mate-pk-cd="rateVo.vMatePkCd" :data-v-lot-cd="lotVo.vLotCd" :data-flag-auto="rateVo.flagAuto"
      :data-row-index="rowIndex" :style="rvo.vToningType &&
        lotVo.activeYn === 'Y' &&
        lotVo.vFlagComplete !== 'Y' &&
        rateVo.vFlagRateRest !== 'Y' &&
        mateVo.vIsArrow &&
        mateVo.vArrowLotCd &&
        mateVo.vArrowLotCd === lotVo.vLotCd ? 'float: left; width: 65px;' : ''">
      <i v-if="rateVo.vFlagRateRest === 'Y'" style="position: absolute;top: calc(50% - 9px);left: 3px;">
        <img src="/src/assets/images/icon/icon-calc__black.png" style="width: 16px;" />
      </i>
      <span :style="mateVo.vFlagReq === 'Y' && ((rateVo.nRate || 0) > (mateVo.nReqRate || 0)) ? 'color: red;' : ''">
        {{ rateVo.nRate }}
      </span>
    </div>

    <div v-if="rvo.vToningType &&
      lotVo.activeYn === 'Y' &&
      lotVo.vFlagComplete !== 'Y' &&
      rateVo.vFlagRateRest !== 'Y' &&
      mateVo.vIsArrow &&
      mateVo.vArrowLotCd &&
      mateVo.vArrowLotCd === lotVo.vLotCd" class="material-calc__control" style="float: left;">
      <button type="button" class="material-calc__control--up" @click="onToningRateUpDown('up', lotVo, rateVo)">
        <img src="/src/assets/images/icon/icon-arrow__top--whiteGray.png" alt="">
      </button>
      <button type="button" class="material-calc__control--down" @click="onToningRateUpDown('down', lotVo, rateVo)">
        <img src="/src/assets/images/icon/icon-arrow__bottom--whiteGray.png" alt="">
      </button>
    </div>
  </td>
  <template v-if="lotVo.activeYn === 'Y' && lotVo.grams">
    <td v-for="(gramVo, gramIndex) in lotVo.grams" :key="'gram_' + gramVo.gramSeq" class="anypjt-grid-td apg-text-right"
      :class="[
        lotVo.activeYn === 'Y' && lotVo.openYn !== 'Y' && gramIndex == lotVo.grams.length - 1 ? 'border-right__blue' : ''
      ]" @contextmenu="onRateOneLotSelect(lotVo)">
      <div v-if="isFolder" class="anypjt-grid-cell"></div>
      <div v-else class="material-calc__text anypjt-grid-cell" :data-column-id="'gram'"
        :data-v-mate-pk-cd="rateVo.vMatePkCd" :data-v-lot-cd="lotVo.vLotCd" :data-gram-seq="gramVo.gramSeq"
        :data-max-gram="gramVo.nGram" :data-flag-auto="rateVo.flagAuto" :data-row-index="rowIndex">
        {{ rateVo['gram_' + gramVo.gramSeq] }}
      </div>
    </td>
  </template>
  <td v-if="lotVo.openYn === 'Y' && rowIndex === 0" :rowspan="rowspan" style="background: #ffffff;"
    class="anypjt-grid-td apg-text-center apg-text-result-td" :class="[
      lotVo.activeYn === 'Y' ? 'border-right__blue' : '',
      lotVo.borderClass,
    ]" @contextmenu="onRateOneLotSelect(lotVo)">
    <div class="lot-test-result-box" :style="divLotTestResultStyle">
      <div class="lot-detail">
        <div class="lot-detail__items">
          <!-- DD :: 펼쳐졌을 때 .is-active 붙습니다. -->
          <div v-for="(side, sIdx) in lotVo.sideList" :key="sIdx" class="lot-detail__item lot-detail__item--safe"
            :class="side.isClick ? 'is-active is-click' : ''" :style="side.isClick ? '' : 'width: 202px'">
            <div class="lot-detail__header">
              <button class="button-color__change" :class="[
                side.vFlagStability === '' ? 'button-color__change--gray' : '',
                side.vFlagStability === 'Y' ? 'button-color__change--green' : '',
                side.vFlagStability === 'C' ? 'button-color__change--yellow' : '',
                side.vFlagStability === 'N' ? 'button-color__change--red' : '',
              ]" :disabled="side.vFlagSave === 'Y'" @click="onChangeStability(side)"></button>
              <div class="lot-detail__title">
                <ap-input v-if="side.isNmChange" v-model:value="side.vTitle" class="lot-detail__title--input"
                  :maxlength="7" placeholder="제목을 입력하세요." @keypress-enter="side.isNmChange = false"
                  @click="mixmatUtils.onFocusClear()" />
                <a v-else href="javascript:void(0)" style="font-size: 12px; color: #545454; text-decoration: none;"
                  @click="onSideToggle(side)">{{ side.vTitle }}</a>
              </div>
              <div class="lot-detail__date">{{ commonUtils.changeStrDatePattern(side.vMemoDtm) }}</div>
              <button v-if="side.nSeqno > 3" class="lot-detail__button-modify" @click="onSideNmChange(side)"></button>
              <button v-if="side.nSeqno > 3" class="lot-detail__button-delete"
                @click="onSideDelete(lotVo, side)"></button>
            </div>
            <div class="lot-detail__body">
              <template v-if="side.nSeqno === 1">
                <template v-if="side.vFlagSave === 'Y'">
                  <div class="lot-detail__body--item height-25">
                    <div class="lot-detail__body--title">
                      <div class="lot-detail__body--title-text">
                        {{ testCdList.find(test => test.vSubCode === side.vTestType)?.vSubCodenm }}
                      </div>
                    </div>
                    <div class="lot-detail__body--contents">{{ side.vTestValue }}</div>
                  </div>
                  <div class="lot-detail__body--item height-25">
                    <div class="lot-detail__body--title">
                      <div class="lot-detail__body--title-text">pH</div>
                    </div>
                    <div class="lot-detail__body--contents">{{ side.vPh }}</div>
                  </div>
                </template>
                <template v-else>
                  <div class="lot-detail__body--item">
                    <div class="lot-detail__body--title">
                      <ap-selectbox v-model:value="side.vTestType" inputClass="lot-detail__select"
                        :defaultBlank="{ blank: false }" :options="testCdList" />
                    </div>
                    <div class="lot-detail__body--contents">
                      <ap-input v-model:value="side.vTestValue" @click="mixmatUtils.onFocusClear()" />
                    </div>
                  </div>
                  <div class="lot-detail__body--item">
                    <div class="lot-detail__body--title">
                      <div class="lot-detail__body--title-text">pH</div>
                    </div>
                    <div class="lot-detail__body--contents">
                      <ap-input v-model:value="side.vPh" :isNumber="true" :point="6" class="height-25"
                        @click="mixmatUtils.onFocusClear()" />
                    </div>
                  </div>
                </template>
              </template>
              <div class="lot-detail__body--item">
                <div class="lot-detail__body--contents">
                  <div class="lot-textarea__wrap" :class="side.vFlagSave === 'Y' ? 'only-txt' : ''">
                    <pre v-if="side.vFlagSave === 'Y'"
                      style="font-size: 11px; overflow: auto; white-space: pre-wrap;">{{ side.vContent }}</pre>
                    <textarea v-else v-model="side.vContent" placeholder="내용을 입력하세요." class="lot-textarea"
                      :disabled="side.vFlagSave === 'Y'" @click="mixmatUtils.onFocusClear()"></textarea>
                  </div>
                </div>
              </div>
            </div>
            <div class="lot-detail__footer">
              <button
                class="ui-button ui-button__width--40 ui-button__height--23 ui-button__border--gray font-weight__400 ui-button__font--12 ui-button__radius--2"
                @click="onSideSave(side)">{{ side.vFlagSave === 'Y' ? '수정' : '저장' }}</button>
              <button class="lot-detail__button lot-detail__button-camera ml-auto" @click="onMateCarmera">
              </button>
              <button class="lot-detail__button lot-detail__button-file"
                @click="onUploadAddFilePop(lotVo.vLotCd, `LOT_ATT_${side.nSeqno}`)">
                <span v-if="side.nAttCnt > 0" class="lot-detail__button-count">{{ side.nAttCnt }}</span>
              </button>
              <button class="lot-detail__button lot-detail__button-zoom"
                @click="onTestResultRegPop(lotVo, side)"></button>
            </div>
          </div>
        </div>

        <button type="button" class="button-plus__etc" @click="onSideAdd(lotVo)"></button>
        <a href="microsoft.windows.camera:" ref="mateCamera" target="_blank" style="display: none;"></a>
      </div>
    </div>

    <teleport to="#common-modal" v-if="popupContent">
      <ap-popup>
        <component :is="popupContent" :pop-params="popParams" @selectFunc="popSelectFunc" />
      </ap-popup>
    </teleport>
  </td>
</template>

<script>
import { defineAsyncComponent, computed, inject, reactive, ref } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useMaterialCommon } from '@/compositions/labcommon/useMaterialCommon'
import { useActions } from 'vuex-composition-helpers'
import mixmatUtils from '@/utils/mixmatUtils'
import Big from 'big.js'

export default ({
  name: 'AllLabNoteMaterialBodyCenter',
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    MateLotSideMemoPop: defineAsyncComponent(() => import('@/components/labcommon/popup/MateLotSideMemoPop.vue')),
    UploadAddFilePop: defineAsyncComponent(() => import('@/components/labcommon/popup/UploadAddFilePop.vue')),
  },
  props: {
    rowIndex: {
      type: Number,
      default: 0,
    },
    rowspan: {
      type: Number,
      default: 1,
    },
    divLotTestResultStyle: {
      type: Object,
      default: () => {
        return {}
      },
    },
    scrollPostion: {
      type: Object,
      default: () => {
        return {
          top: 0,
        }
      },
    },
    lotVo: {
      type: Object,
      default: () => {
        return {}
      },
    },
    mateVo: {
      type: Object,
      default: () => {
        return {}
      },
    },
    rateVo: {
      type: Object,
      default: () => {
        return {}
      },
    },
    rvo: {
      type: Object,
      default: () => {
        return {}
      },
    },
    bfLotVo: {
      type: Object,
      default: () => {
        return {}
      },
    },
    testCdList: {
      type: Array,
      default: () => {
        return []
      }
    },
  },
  emits: ['fnAutoYnChange', 'onRateOneLotSelect', 'onMateTestResultRegPop', 'onLotGramChange'],
  setup(props, context) {
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert, openAsyncConfirm } = useActions(['openAsyncAlert', 'openAsyncConfirm'])

    const uploadParams = reactive({
      vRecordid: props.lotVo.vLotCd,
      items: []
    })
    const mateCamera = ref(null)

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
    } = useLabCommon()

    const { insertElabLotMemo } = useMaterialCommon()

    const isFolder = computed(() => {
      return props.mateVo.vRecType === 'GRP'
    })

    const fnAutoYnChange = (vLotCd, vMatePkCd) => {
      context.emit('fnAutoYnChange', { vLotCd, vMatePkCd })
    }

    const onRateOneLotSelect = (o) => {
      context.emit('onRateOneLotSelect', o)
    }

    const onSideToggle = (o) => {
      o.isClick = !o.isClick
    }

    const onSideNmChange = (o) => {
      if (o.nSeqno <= 3) {
        openAsyncAlert({ message: '기본 정보는 수정 불가능합니다.' })
        return
      }
      else if (!o.vTitle) {
        openAsyncAlert({ message: '제목을 입력하세요.' })
        return
      }

      o.isNmChange = !o.isNmChange
    }

    const onSideDelete = async (lotVo, side) => {
      if (side.nSeqno <= 3) {
        openAsyncAlert({ message: '기본 정보는 삭제 불가능합니다.' })
      }
      else if (side.isAdd) {
        lotVo.sideList = lotVo.sideList.filter(_side => _side.nSeqno !== side.nSeqno)
      }
      else if (await openAsyncConfirm({ message: '삭제 하시겠습니까?' })) {
        lotVo.sideList = lotVo.sideList.filter(_side => _side.nSeqno !== side.nSeqno)

        side.vFlagDel = 'Y'
        onSideSave(side)
      }
    }

    const onChangeStability = (o) => {
      if (o.vFlagStability === '' || !o.vFlagStability) {
        o.vFlagStability = 'N'
      }
      else if (o.vFlagStability === 'N') {
        o.vFlagStability = 'C'
      }
      else if (o.vFlagStability === 'C') {
        o.vFlagStability = 'Y'
      }
      else if (o.vFlagStability === 'Y') {
        o.vFlagStability = ''
      }
    }

    const onSideAdd = (o) => {
      if (o.sideList.length >= 10) {
        openAsyncAlert({ message: '최대 10개까지 가능합니다.' })
        return
      }

      const maxSeqno = Math.max(...o.sideList.map(side => side.nSeqno))
      o.sideList = [
        ...o.sideList,
        ...[
          {
            nSeqno: maxSeqno + 1,
            vLotCd: o.vLotCd,
            isNmChange: true,
            isAdd: true,
            isClick: true,
          }
        ]
      ]
    }

    const onSideSave = async (o) => {
      if (o.vFlagSave === 'Y') {
        o.vFlagSave = 'N'
        return
      }

      if (!o.vTitle) {
        openAsyncAlert({ message: '제목을 입력해 주세요.' })
        return
      }

      o.isAdd = false

      const message = await insertElabLotMemo({
        vLotCd: o.vLotCd,
        nSeqno: o.nSeqno,
        vTitle: o.vTitle,
        vContent: o.vContent,
        vFlagStability: o.vFlagStability,
        vFlagDel: o.vFlagDel || 'N',
        vTestType: o.vTestType,
        vTestValue: o.vTestValue,
        vPh: o.vPh,
        fileList: uploadParams.items,
        vFlagOnlyMemo: o.nSeqno === 1 ? null : 'Y',
      })

      if (message) {
        openAsyncAlert({ message: o.vFlagDel === 'Y' ? '삭제 되었습니다.' : '저장 되었습니다.' })

        o.vFlagSave = 'Y'

        if (o.vFlagDel !== 'Y') {
          o.vMemoDtm = commonUtils.getToday().replaceAll('-', '')
        }
      }
    }

    const onTestResultRegPop = (o, side) => {
      if (side.nSeqno === 1) {
        if (o.grams && o.grams.length > 0 && o.grams[0]?.nGram) {
          context.emit('onMateTestResultRegPop', o)
        }
        else {
          openAsyncAlert({ message: '실험결과는 해당 Lot에 Gram 입력 > 원료 배합 저장 후 등록 가능합니다.' })
        }
      }
      else {
        popParams.value = {
          vLotCd: o.vLotCd,
          nSeqno: side.nSeqno,
          vTitle: side.vTitle,
          vContent: side.vContent,
          vFlagStability: side.vFlagStability,
        }
        popSelectFunc.value = onMemoText
        fnOpenPopup('MateLotSideMemoPop')
      }
    }

    const onMemoText = (o) => {
      const side = props.lotVo.sideList.find(side => side.nSeqno === popParams.value.nSeqno)
      if (side) {
        side.vContent = o
      }
    }

    const onToningRateUpDown = (t, lotVO, rateVO) => {
      const vToningType = props.rvo.vToningType
      const nToning = props.rvo.nToning
      const vToningLotCd = props.rvo.vToningLotCd
      const bfLotVo = props.bfLotVo
      const bfRate = bfLotVo?.rateList?.find(rate => rate.vMatePkCd === rateVO.vMatePkCd)?.nRate
      let calc = nToning;

      if (!vToningLotCd && !bfLotVo) {
        openAsyncAlert({ message: '이전 Lot 이 없습니다.' })
        return
      }

      if (vToningType === 'p') {
        calc = bfRate * (nToning * 0.01)
        calc = Number(commonUtils.getDecimalPointFormat(calc, 2))
      }

      if (!rateVO.nRate || rateVO.nRate === 0) {
        rateVO.nRate = bfRate
      }

      if (!rateVO.nRate) {
        return
      }

      const nRate = new Big(rateVO.nRate).round(4).toNumber()
      if (t === 'up') {
        const plusRate = commonUtils.getDecimalPointFormat(nRate + calc, 2)
        if (plusRate > 100) {
          openAsyncAlert({ message: '최대 100 까지 입력 가능합니다.' })
          return
        }
        rateVO.nRate = plusRate
      }
      else {
        const minusRate = commonUtils.getDecimalPointFormat(nRate - calc, 2)
        if (minusRate < 0) {
          openAsyncAlert({ message: '최소 0 까지 입력 가능합니다.' })
          return
        }
        rateVO.nRate = minusRate
      }

      lotVO.rateList = lotVO.rateList.map(rate => {
        const isRate = rate.vMatePkCd === rateVO.vMatePkCd
        return {
          ...rate,
          nRate: isRate ? rateVO.nRate : rate.nRate,
          vFlagSave: isRate ? 'Y' : rate.vFlagSave,
        }
      })

      context.emit('onLotGramChange', lotVO)
    }

    const onUploadAddFilePop = (vRecordid, vUploadCd) => {
      popParams.value = {
        vRecordid,
        vUploadCd,
        vFlagDownload: 'Y',
      }
      popSelectFunc.value = onAterUpoadFile
      fnOpenPopup('UploadAddFilePop')
    }

    const onAterUpoadFile = (o) => {
      const side = props.lotVo.sideList.find(side => String(side.nSeqno) === mixmatUtils.getLotCircle(o.vUploadCd))
      if (side) {
        side.nAttCnt = o.items.length
      }
    }

    const onMateCarmera = () => {
      mateCamera.value.click()
    }

    return {
      mixmatUtils,
      commonUtils,
      uploadParams,
      mateCamera,
      popupContent,
      popParams,
      popSelectFunc,
      isFolder,
      fnAutoYnChange,
      onRateOneLotSelect,
      onSideToggle,
      onSideNmChange,
      onSideDelete,
      onChangeStability,
      onSideAdd,
      onSideSave,
      onTestResultRegPop,
      onToningRateUpDown,
      onUploadAddFilePop,
      onMateCarmera,
    }
  },
})
</script>
