<template>
  <div class="contents-box__inner">
    <div class="ui-tab">
      <div class="ui-tab__inner">
        <div class="ui-tab__header">
          <ul class="ui-list ui-tab__lists">
            <li class="ui-tab__list" :class="selectedTab === 'my' ? 'is-active' : ''">
              <a href="#" class="ui-tab__link" @click.prevent="fnSelectTabEvent('my')">
                My notes
              </a>
            </li>
            <li class="ui-tab__list" :class="selectedTab === 'recent' ? 'is-active' : ''">
              <a href="#" class="ui-tab__link" @click.prevent="fnSelectTabEvent('recent')">
                Recent notes
              </a>
            </li>
            <li class="ui-tab__list" :class="selectedTab === 'shared' ? 'is-active' : ''">
              <a href="#" class="ui-tab__link" @click.prevent="fnSelectTabEvent('shared')">
                Shared notes
              </a>
            </li>
          </ul>
          <button type="button" class="tab-header__button" v-if="!commonUtils.checkAuth('S000333')" @click="goNoteRegister()"></button>
        </div>
        <div class="ui-tab__body">
          <div class="note-card">
            <div class="note-card__inner">
              <template v-if="noteList && noteList.length > 0">
                <ul class="ui-list note-card__lists">
                  <li class="note-card__list"
                    v-for="vo in noteList"
                    :key="selectedTab + '_' + vo.vLabNoteCd"
                  >
                    <a href="#" class="note-card__link" @click.prevent="goNoteDetail(vo)">
                      <span class="note-card__num">{{ vo.vContCd }}</span>
                      <span class="note-card__brand">{{ vo.vBrdNm }}</span>
                      <span class="note-card__name">{{ vo.vContNm }}</span>
                    </a>
                  </li>
                </ul>
              </template>
              <template v-else>
                <div class="myboard-no-data">조회 내용이 없습니다.</div>
              </template>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, inject } from 'vue'
import { useMyboardCommon } from '@/compositions/labcommon/useMyboardCommon'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useRouter } from 'vue-router'
import { useStore } from 'vuex'

export default {
  name: 'MyBoardNote',
  setup () {
    const selectedTab = ref('my')
    const noteList = ref([])
    const commonUtils = inject('commonUtils')
    const router = useRouter()
    const store = useStore()
    const noteTypeNm = store.getters.getNoteTypeNm()

    const {
      selectMyNoteList,
      selectRecentNoteList,
      selectSharedNoteList,
    } = useMyboardCommon()

    const {
      fnSetRecentLog,
    } = useLabCommon()

    const fnSelectTabEvent = (tabid) => {
      selectedTab.value = tabid

      fnNoteList()
    }

    const fnNoteList = async () => {
      if (selectedTab.value === 'my') {
        noteList.value = await selectMyNoteList()
      } else if (selectedTab.value === 'recent') {
        noteList.value = await selectRecentNoteList()
      } else if (selectedTab.value === 'shared') {
        noteList.value = await selectSharedNoteList()
      }
    }

    const goNoteDetail = async (item) => {
      const pageType = item.vLabTypeCd === 'LNC07_01' ? 'prd' : (item.vLabTypeCd === 'LNC07_02' ? 'half' : 'nonprd')
      if (commonUtils.isNotEmpty(item.vContCd)) {
        item.vPageType = pageType
        await fnSetRecentLog(item)
      }

      const path = `/${noteTypeNm}/all-lab-note-${pageType}-view`
      router.push({ path, query: { vLabNoteCd: item.vLabNoteCd }})
    }

    const goNoteRegister = () => {
      const path = `/${noteTypeNm}/all-lab-note-prd-register`
      router.push({ path })
    }

    const init = () => {
      fnNoteList()
    }

    init()

    return {
      commonUtils,
      selectedTab,
      noteList,
      fnSelectTabEvent,
      goNoteDetail,
      goNoteRegister,
    }
  }
}
</script>