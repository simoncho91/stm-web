<template>
  <ApTab mst-id="materialTab" :tab-list="info.tabList" :tab-style="tabStyle" :default-tab="info.defaultTab"
    :isSlot="info.contVO.vFlagRepresent === 'Y'" @click="onTabClick" @contextmenu.prevent="onContextMenu($event)"
    @onKeypress="onKeypress">
    <template v-if="info.contVO.vFlagRepresent === 'Y'" v-slot:materialVersionPlusButton>
      <button class="button-plus__ver" @click="onAddVersion"></button>
    </template>
  </ApTab>
  <context-menu v-model:show="contextMenu.isShow" :options="contextMenu">
    <context-menu-item label="이름변경" @click="onContextMenuItemClick('VER_NM')">
      <template #icon><img src="/src/assets/images/icon/icon-enroll.png" style="width: 16px;"></template>
    </context-menu-item>
  </context-menu>
</template>

<script>
import { defineAsyncComponent, ref, inject, watch, reactive, onUpdated } from 'vue'
import { useMaterialCommon } from '@/compositions/labcommon/useMaterialCommon'
import { useActions } from 'vuex-composition-helpers'
import mixmatUtils from '@/utils/mixmatUtils'

export default {
  name: 'AllLabNoteMaterialTab',
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
  },
  emits: ['onTabClick', 'onVerNmChange'],
  setup(props, context) {
    const reqInfo = inject('reqInfo')
    const {
      openAsyncConfirm, openAsyncAlert, openAsyncPopup, closeAsyncPopup
    } = useActions(['openAsyncConfirm', 'openAsyncAlert', 'openAsyncPopup', 'closeAsyncPopup'])

    const info = ref({
      contVO: {},
      rvo: {},
      verVO: {},
      verList: [],
      tabList: [],
      defaultTab: 'VER_1',
    })

    const tabStyle = [
      'material-excel__ver',
      'ui-list material-excel__ver--lists',
      'material-excel__ver--list',
      'material-excel__ver--link',
    ]
    const contextMenu = reactive({
      isShow: false,
    })
    const selectedVer = ref(null)

    const { insertLabNoteNewVersion } = useMaterialCommon()

    watch(
      () => reqInfo.value,
      (o) => {
        if (!o) {
          return
        }
        info.value = { ...info.value, ...o }

        if (o.constructor !== Object) {
          return
        }

        const tabList = []
        o.verList
          .filter(ver => ver.vFlagView === 'Y')
          .map(ver => {
            tabList.push({
              nVersion: ver.nVersion,
              tabId: 'VER_' + String(ver.nVersion),
              tabNm: ver.vVersionTxt,
              isInput: false,
            })
          })

        info.value.tabList = tabList
        info.value.defaultTab = 'VER_' + String(o.verVO.nVersion)
      }
    )

    const onTabClick = (res) => {
      context.emit('onTabClick', res.tabId.substring(4))
    }

    const onAddVersion = async () => {
      const answer = await openAsyncConfirm({ message: '버전 추가시 PQC가 초기화 됩니다.<br>버전 추가하시겠습니까?' })
      if (!answer) {
        return
      }

      const response = await insertLabNoteNewVersion({
        vLabNoteCd: info.value.contVO.vLabNoteCd,
        vContPkCd: info.value.contVO.vContPkCd,
        vContCd: info.value.contVO.vContCd || '',
        vContNm: info.value.contVO.vContNm,
        vBsmUserid: info.value.rvo.vBsmUserid,
        vBsmUseridSub1: info.value.rvo.vBsmUseridSub1,
        vBsmUseridSub2: info.value.rvo.vBsmUseridSub2,
        vCtcUserid: info.value.rvo.vCtcUserid,
        vUserid: info.value.rvo.vUserid,
        vMoveUrl: `/skincare/all-lab-note-${info.value.contVO.vPageType}-process?vLabNoteCd=${info.value.contVO.vLabNoteCd}&vTabId=confirm`,
      })

      openAsyncAlert({ message: response })
      context.emit('onTabClick')
    }

    const onKeypress = (o) => {
      const ver = info.value.verList.find(ver => ver.nVersion === selectedVer.value.nVersion)
      ver.vVersionTxt = o

      context.emit('onVerNmChange', info.value.verList)
      const tab = info.value.tabList.find(tab => tab.isInput)
      tab.isInput = false
    }

    const onContextMenu = (e) => {
      const tab = info.value.tabList.find(tab => tab.tabNm === e.target.textContent)
      if (tab.nVersion !== info.value.verVO.nVersion) {
        return
      }

      contextMenu.x = e.x
      contextMenu.y = e.y
      contextMenu.isShow = true

      selectedVer.value = tab
    }

    const onContextMenuItemClick = (e) => {
      if (e === 'VER_NM') {
        mixmatUtils.onFocusClear()

        info.value.tabList.map(tab => {
          if (tab.tabId === selectedVer.value.tabId) {
            tab.isInput = true
          }
          else {
            tab.isInput = false
          }
        })
      }
    }

    onUpdated(() => {
      const contextMenuWrap = document.querySelector('.mx-context-menu-items')
      if (contextMenuWrap) {
        const items = contextMenuWrap.querySelectorAll('.mx-item-row')
        for (let i = 0; i < items.length; i++) {
          const sapn = items[i].querySelector('.label')
          if (sapn) {
            sapn.style.padding = '5px 0px 5px 0px'
          }
        }
      }
    })

    return {
      info,
      tabStyle,
      contextMenu,
      onTabClick,
      onAddVersion,
      onKeypress,
      onContextMenu,
      onContextMenuItemClick,
    }
  },
}
</script>
