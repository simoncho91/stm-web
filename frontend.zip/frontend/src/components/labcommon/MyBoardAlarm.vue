<template>
  <div class="myboard-table myboard-memo-area">
    <div class="myboard-table__inner">
      <table class="ui-table text-center">
        <colgroup>
          <col style="width:auto">
          <col style="width:11.5rem">
        </colgroup>
        <thead>
          <tr>
            <th>내용</th>
            <th>날짜</th>
          </tr>
        </thead>
        <tbody v-if="alarmList && alarmList.length > 0">
          <tr v-for="(vo, idx) in alarmList" :key="'alarm_' + idx">
            <td
              class="text-left pointer"
              v-html="commonUtils.removeHTMLChangeBr(vo.vMessage)"
              @click="goMoveUrl(vo)"
            >
            </td>
            <td>{{ commonUtils.changeStrDatePattern(vo.vRegDtm) }}</td>
          </tr>
        </tbody>
        <tbody v-else>
          <tr>
            <td colspan="2">
              <div class="no-result">{{ t('common.msg.no_data') }}</div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
import { ref, inject } from 'vue'
import { useMyboardCommon } from '@/compositions/labcommon/useMyboardCommon'

export default {
  name: 'MyBoardAlarm',
  setup () {
    const commonUtils = inject('commonUtils')
    const t = inject('t')
    const {
      selectMyBoardAlarmList,
    } = useMyboardCommon()

    const alarmList = ref([])

    const goMoveUrl = (item) => {
      if (commonUtils.isEmpty(item.vMoveUrl)) {
        return
      }

      window.location.href = item.vMoveUrl
    }

    const init = async () => {
      const result = await selectMyBoardAlarmList()

      if (result) {
        alarmList.value = result
      }
    }

    init()

    return {
      commonUtils,
      t,
      alarmList,
      goMoveUrl,
    }
  }
}
</script>

<style scoped>
  .pointer { cursor: pointer; }
</style>