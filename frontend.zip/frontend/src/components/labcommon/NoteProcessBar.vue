<template>
  <div class="ui-process" :class="isBig ? 'ui-process--big' : ''">
    <div class="ui-process__inner">
      <template v-if="isCancel && isBig">
        <div class="note_cancel_text">
          <span class="ui-require"><span class="for-a11y">(필수)</span></span> 개발취소 상태
        </div>
      </template>
      <div class="process-bar">
        <div class="process-bar__set" :class="isCancel ? 'cancel' : ''" :style="'width:' + progressBarWidth + 'px'"></div>
      </div>

      <div class="ui-process__text--wrap">
        <ul class="ui-list ui-process__lists" :class="isCancel ? 'cancel' : ''">
          <li v-for="(vo, idx) in progressInfo" :key="'pr_'+ idx" :class="'ui-process__list '+ vo.vCurrStatMark">
            <div class="ui-process__icon"></div>
            <div class="ui-process__text">
              <span class="ui-process__text--title">{{ vo.vStatusNm }}</span>
              <span v-if="isShowDate" class="ui-process__text--date">{{ commonUtils.changeStrDatePattern(vo.vSchdStDt) }}</span>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, watch, inject } from 'vue'
export default {
  name: 'NoteProcessBar',
  props: {
    isBig: {
      type: Boolean,
      default: true
    },
    isShowDate: {
      type: Boolean,
      default: false
    },
    progressInfo: {
      type: Array,
      default: () => {
        return []
      }
    },
    isCancel: {
      type: Boolean,
      default: false
    },
    isHalf:{
      type: Boolean,
      default: false
    }
  },
  setup (props) {
    const commonUtils = inject('commonUtils')
    const progressBarWidth = ref(0)
    const init = () => {
      if (props.progressInfo.length > 0) {
        let plusPixelNum = props.isHalf ? 255 : 128
        props.progressInfo.some((prog, idx) => {
          if(prog.vCurrStatMark === "is-active"){
            if(idx < props.progressInfo.length - 1){
              progressBarWidth.value = (30 + idx * plusPixelNum)
            }else{
              progressBarWidth.value = 800
            }
            return true
          }
        })
      }
    }

    init()

    watch(() => props.progressInfo, (newVal) => {
      init()
    })
    return {
      commonUtils,
      progressBarWidth,
    }
  }
}
</script>

