<template>
  <div class="page-bottom">
    <div class="page-bottom__inner">
      <div class="ui-buttons ui-buttons__right">
        <template v-if="!commonUtils.isEmpty(info?.rvo) &&
          info?.rvo?.vLabTypeCd !== 'LNC07_01' &&
          info?.rvo?.vLabTypeCd !== 'LNC07_02' &&
          info?.rvo?.vFlagExistMatnr !== 'Y'">
          <div class="myboard-top d-flex">
            <div>※ 비제품의 경우에는 가격비 합계는 1110(AP 오산)으로 예상하여 산출합니다.</div>
          </div>
          <button type="button" class="ui-button ui-button__border--gray" @click="onAllPlantPricePop">
            플랜트별 단가
          </button>
        </template>

        <!-- 시험의뢰 -->
        <AllLabNoteTestReq v-if="!commonUtils.isEmpty(info?.rvo) && info?.otherVO?.vFlagTestRequest != 'N'"
          :noteInfo="info.rvo" :nVersion="info.verVO.nVersion"
          :lotList="info.lotList"
          vGateCd="GATE_1"
          page="material"
        >
        </AllLabNoteTestReq>

        <button v-if="!commonUtils.isEmpty(info?.rvo) && mixmatUtils.getBtnShow('CHANGE_SAVE', null, info)" type="button"
          class="ui-button ui-button__bg--skyblue font-weight__300" @click="onMaterialSave">
          원료배합 저장
        </button>
        <button type="button" class="ui-button ui-button__border--gray" @click="onGoList">
          목록
        </button>
      </div>
    </div>

    <teleport to="#common-modal" v-if="popupContent">
      <ap-popup>
        <component :is="popupContent" :pop-params="popParams" @selectFunc="popSelectFunc" />
      </ap-popup>
    </teleport>
  </div>

</template>

<script>
import { defineAsyncComponent, ref, inject, watch } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import mixmatUtils from '@/utils/mixmatUtils'

import AllLabNoteTestReq from '@/components/labcommon/AllLabNoteTestReq.vue'

export default {
  name: 'AllLabNoteMaterialBottom',
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    AllPlantPricePop: defineAsyncComponent(() => import('@/components/labcommon/popup/AllPlantPricePop.vue')),
    AllLabNoteTestReq,
  },
  emits: ['onPlantPrice', 'onMaterialSave', 'goList'],
  setup(props, context) {
    const reqInfo = inject('reqInfo')
    const commonUtils = inject('commonUtils')

    const info = ref({
      contVO: {},
      rvo: {},
      lotList: [],
      verVO: {},
    })

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
    } = useLabCommon()

    watch(
      () => reqInfo.value,
      (o) => {
        info.value = { ...info.value, ...o }
      }
    )

    const onAllPlantPricePop = () => {
      const lotInfo = info.value.lotList.filter(o => o.vIsLotSelect)
      if (lotInfo && lotInfo.length > 0) {
        popParams.value = {
          vLabNoteCd: info.value.rvo.vLabNoteCd,
          vContPkCd: info.value.rvo.vContPkCd,
          nVersion: info.value.verVO.nVersion,
          vLotCd: lotInfo?.[0].vLotCd,
          nCapacity: 100,
          vPlantCd: info.value.rvo.vPlantCd || ''
        }
        popSelectFunc.value = onPlantPrice
        fnOpenPopup('AllPlantPricePop', false)
      }
    }

    const onPlantPrice = () => {
      context.emit('onPlantPrice')
    }

    const onMaterialSave = () => {
      context.emit('onMaterialSave')
    }

    const onGoList = () => {
      context.emit('goList')
    }

    return {
      commonUtils,
      mixmatUtils,
      info,
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      onAllPlantPricePop,
      onPlantPrice,
      onMaterialSave,
      onGoList,
    }
  },
}
</script>
