<template>
  <div class="note-table__inner">
    <table :class="inputClass">
      <colgroup>
        <col style="width:9rem;">
        <col style="width:auto;">
        <col style="width:12rem;">
        <col style="width:12rem;">
        <col v-if="stockDtYn === 'Y'" style="width:15rem;">
        <col v-if="mateChgYn === 'Y'" style="width:14rem;">
        <col style="width:18rem;">
      </colgroup>
      <thead>
        <tr>
          <th>원료코드</th>
          <th>원료명</th>
          <th>TO-100</th>
          <th>함량</th>
          <th v-if="stockDtYn === 'Y'">입고완료 예정일</th>
          <th v-if="mateChgYn === 'Y'">소재팀 담당자</th>
          <th>비고</th>
        </tr>
      </thead>
      <tbody v-if="mateList && mateList.length > 0">
        <tr v-for="(vo, index) in mateList" :key="'mate_' + index">
          <td>
            <template v-if="commonUtils.isEmpty(vo.vMateCd) && vo.vMateDbTypeCd === 'SUP'">
              {{ vo.vMateTempCd }}
            </template>
            <template v-else>
              {{ vo.vMateCd }}
            </template>
          </td>
          <td class="t-left">
            <MateName
              :mate-info="vo"
            >
            </MateName>
          </td>
          <td class="text-center">{{ vo.vFlagTo100 }}</td>
          <td class="text-center">{{ vo.vFlagTo100 !== 'Y' ? vo.nReqRate : '' }}</td>
          <td class="text-center" v-if="stockDtYn === 'Y'">{{ commonUtils.changeStrDatePattern(vo.vMatePutDt) }}</td>
          <td class="text-center" v-if="mateChgYn === 'Y'">{{ vo.vMateUsernm }}</td>
          <td>{{ vo.vNote }}</td>
        </tr>
      </tbody>
      <tbody v-else>
        <tr>
          <td :colspan="colspanCnt">
            <div class="no-result">
              {{ t('common.msg.no_data') }}
            </div>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
import { defineAsyncComponent, inject } from 'vue'

export default {
  name: 'MateSearchResultTableView',
  props: {
    mateList: {
      type: Array,
      default: () => {
        return []
      }
    },
    inputClass: {
      type: String,
      default: 'ui-table ui-table__td--40 text-center'
    },
    mateChgYn: {
      type: String,
      default: 'N'
    },
    stockDtYn: {
      type: String,
      default: 'N'
    }
  },
  components: {
    MateName: defineAsyncComponent(() => import('@/components/labcommon/MateName.vue')),
  },
  setup (props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    let colspanCnt = 5

    if (props.mateChgYn === 'Y') {
      colspanCnt++
    }

    if (props.stockDtYn === 'Y') {
      colspanCnt++
    }

    return {
      t,
      commonUtils,
      colspanCnt
    }
  }
}
</script>