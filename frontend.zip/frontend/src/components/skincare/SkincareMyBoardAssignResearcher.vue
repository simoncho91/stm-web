<template>
  <div class="myboard-table myboard-memo-area mt-1">
    <button
      type="button"
      class="ui-button ui-button__height--28 ui-button__bg--lightgray memo-header__btn"
      @click="fnAssignResearcherSave()"
    >
      담당자지정
    </button>
    <div class="myboard-table__inner">
      <table class="ui-table text-center">
        <colgroup>
          <col style="width:5%">
          <col style="width:12%">
          <col style="width:auto">
          <col style="width:10%">
          <col style="width:20%">
        </colgroup>
        <thead>
          <tr>
            <th class="chk-header">
              <ap-input-check
                id="assign_checkAll"
                value="Y"
                :disabled="!noteList || noteList.length === 0"
                @click="fnAssignCheckAllEvent"
              >
              </ap-input-check>
            </th>
            <th>BRAND</th>
            <th>NAME</th>
            <th>BS</th>
            <th>RESEARCHER</th>
          </tr>
        </thead>
        <tbody v-if="noteList && noteList.length > 0">
          <tr
            v-for="(note, index) in noteList"
            :key="'note_' + index"
            class="tr-contents"
          >
            <td>
              <ap-input-check
                v-model:model="note.isChecked"
                value="Y"
                :id="'assign_check_' + index"
                @click="fnAssignCheckEvent()"
              >
              </ap-input-check>
            </td>
            <td>{{ note.vBrdNm }}</td>
            <td class="text-left ml-20">{{ note.vContNm }}</td>
            <td>{{ note.vBsmUsernm }}</td>
            <td>
              <div class="search-form" :id="'error_wrap_vUsernm' + index">
                <div class="search-form__inner">
                  <ap-input
                    v-model:value="note.vUsernm"
                    input-class="w97"
                    :readonly="true"
                    @click="fnSearchUserPop(index)"
                  >
                  </ap-input>
                  <button type="button"
                    class="ui-button__circle ui-button__close input-close-btn--1"
                    @click="removeUserInfo(note)"
                  ></button>
                </div>
                <span class="error-msg" :id="'error_msg_vUsernm' + index"></span>
              </div>
            </td>
          </tr>
        </tbody>
        <tbody v-else>
          <tr>
            <td colspan="5">
              <div class="no-result">{{ t('common.msg.no_data') }}</div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @selectFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useMyboardCommon } from '@/compositions/labcommon/useMyboardCommon'
import { useSkinRequest } from '@/compositions/skincare/useSkinRequest'

export default {
  name: 'SkincareMyBoardAssignResearcher',
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    UserSearchPop: defineAsyncComponent(() => import('@/components/comm/popup/UserSearchPop.vue')),
  },
  setup () {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert } = useActions(['openAsyncAlert'])
    const noteList = ref([])
    let popIdx = null
    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
    } = useLabCommon()

    const {
      selectAssignResearcherList,
    } = useMyboardCommon()

    const {
      updateLabNoteMstUserList,
    } = useSkinRequest()

    const fnAssignCheckAllEvent = (value) => {
      if (value === 'Y') {
        noteList.value.forEach((item, idx) => {
          item.isChecked = 'Y'
          document.querySelector('#assign_check_' + idx).checked = true
        })
      } else {
        noteList.value.forEach((item, idx) => {
          item.isChecked = ''
          document.querySelector('#assign_check_' + idx).checked = false
        })
      }
    }

    const fnAssignCheckEvent = () => {
      if (noteList.value && noteList.value.filter(item => item.isChecked === 'Y').length === noteList.value.length) {
        document.querySelector('#assign_checkAll').checked = true
      } else {
        document.querySelector('#assign_checkAll').checked = false
      }
    }

    const getUserSearchInfo = (item) => {
      noteList.value[popIdx].vUserid = item.vUserid
      noteList.value[popIdx].vUsernm = item.vUsernm
      noteList.value[popIdx].vDeptCd = item.vSigmaDeptcd
      commonUtils.hideErrorMessage('vUsernm' + popIdx)

      popIdx = null
    }

    const fnSearchUserPop = (index) =>{
      popIdx = index

      popParams.value = {
        vKeyword: '',
        searchFlag: 'LAB'
      }

      popSelectFunc.value = getUserSearchInfo
      fnOpenPopup('UserSearchPop')
    }

    const removeUserInfo = (noteInfo) => {
      noteInfo.vUserid = ''
      noteInfo.vUsernm = ''
      noteInfo.vDeptCd = ''
    }

    const fnValidation = () => {
      let isOk = true
      let errorMsg = '필수 입력 사항입니다.'
      const checkedList = noteList.value.filter(item => item.isChecked === 'Y')
      if (checkedList.length === 0) {
        openAsyncAlert({ message: '대상을 선택해 주세요.'})
        return false
      }

      checkedList.forEach((item, idx) => {
        if (item.isChecked === 'Y') {
          commonUtils.hideErrorMessage('vUsernm' + idx)

          if (commonUtils.isEmpty(item.vUserid)) {
            isOk = false
            commonUtils.showErrorMessage('vUsernm' + idx, errorMsg)
          }
        }
      })

      return isOk
    }

    const fnAssignResearcherSave = async () => {
      if (!fnValidation()) {
        return
      }

      const checkedList = noteList.value.filter(item => item.isChecked === 'Y')
      const result = await updateLabNoteMstUserList({ noteList: checkedList })

      if (result) {
        fnSearchAssignResearcherList()
        document.querySelector('#assign_checkAll').checked = false
      }
    }

    const fnSearchAssignResearcherList = async () => {
      noteList.value = await selectAssignResearcherList()
    }

    const init = () => {
      fnSearchAssignResearcherList()
    }

    init()

    return {
      t,
      commonUtils,
      noteList,
      popupContent,
      popParams,
      popSelectFunc,
      fnAssignCheckAllEvent,
      fnAssignCheckEvent,
      fnSearchUserPop,
      removeUserInfo,
      fnAssignResearcherSave,
    }
  }
}

</script>