<template>
  <div class="contents-box__inner">
    <table class="ui-table__th--bg-gray">
      <colgroup>
        <col style="width:14rem">
        <col style="width:auto">
        <col style="width:14rem">
        <col style="width:auto">
      </colgroup>
      <tbody>
        <tr>
          <th>내용물명</th>
          <td>
            {{ gate02CheckParam.vContNm }}
          </td>
          <th>내용물 코드</th>
          <td>
            {{ gate02CheckParam.vContCd }}
          </td>
        </tr>
        <tr>
          <th>VER. - LOT</th>
          <td>
            {{ gate02CheckParam.vVersionTxt }} - {{ gate02CheckParam.vLotNm }}
          </td>
          <th>연구담당자</th>
          <td>
            {{ gate02CheckParam.vUsernm }} ({{ gate02CheckParam.vUserid }} / {{ gate02CheckParam.vDeptNm }})
          </td>
        </tr>
        <tr>
          <th>브랜드</th>
          <td>{{ gate02CheckParam.vBrdNm }}</td>
          <th>Plant</th>
          <td>[{{ gate02CheckParam.vPlantCd }}] {{ gate02CheckParam.vPlantNm }}</td>
        </tr>
      </tbody>
    </table>

    <div class="divide-line"></div>

    <div class="ui-table__wrap">
      <table class="ui-table text-center ui-table__td--40">
        <tr class="tr-contents">
          <td class="inside-td">
            <div class="inside-td__item">
              <ProcessPQCGateCheckInfo
                v-if="resultVo?.pqcList && resultVo?.pqcList.length > 0"
                v-model:pqc-list="resultVo.pqcList"
                :tr-map="resultVo.trMap"
                :gate-flag="'GATE2'"
              >
              </ProcessPQCGateCheckInfo>

              <div class="inside-td__item" v-if="resultVo?.pqcResVo">
                <div class="inside-td__item--title">준수율</div>
                <div class="inside-td__item--wrap">
                  <table class="ui-table__reset inside-td__table">
                    <colgroup>
                      <col style="width:21rem"> 
                      <col style="width:auto"> 
                    </colgroup>
                    <tbody>
                      <tr>
                        <th>준수율</th>
                        <td class="t-left">
                          {{ resultVo.pqcResVo.nObeyPer }} %
                        </td>
                      </tr>
                      <tr>
                        <th>연구원 의견</th>
                        <td class="t-left" v-html="commonUtils.removeHTMLChangeBr(resultVo.pqcResVo.vComment)"></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              <ProcessTrGate01List
                v-if="resultVo?.trGate1List && resultVo?.trGate1List.length > 0"
                :tr-gate1-list="resultVo.trGate1List"
              >
              </ProcessTrGate01List>
            </div>
          </td>
        </tr>
      </table>
    </div>
  </div>

  <div class="page-bottom">
    <div class="page-bottom__inner">
      <div class="ui-buttons ui-buttons__right">
        <button type="button" class="ui-button ui-button__bg--gray" @click="goList()">목록</button>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'
import { useRouter } from 'vue-router'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'

export default {
  name: 'ProcessPrescribeConfirmView',
  props: {
    vActionFlag: {
      type: String,
      default: 'R'
    },
    checkParams: {
      type: Object,
      default: () => {
        return {}
      }
    },
  },
  emits: ['update:vActionFlag'],
  components: {
    ProcessPQCGateCheckInfo: defineAsyncComponent(() => import('@/components/process/ProcessPQCGateCheckInfo.vue')),
    ProcessTrGate01List: defineAsyncComponent(() => import('@/components/process/ProcessTrGate01List.vue')),
  },
  setup (props, context) {
    const gate02CheckParam = ref(props.checkParams)
    const resultVo = ref(null)
    const commonUtils = inject('commonUtils')

    const {
      selectLabNoteGate2View,
      noteType,
    } = useProcessCommon()

    const goList = () => {
      setTimeout(() => {
        context.emit('update:vActionFlag', 'L')
      }, 200)
    }

    const init = async () => {
      resultVo.value = await selectLabNoteGate2View(props.checkParams)
    }

    init()

    return {
      commonUtils,
      gate02CheckParam,
      resultVo,
      noteType,
      goList,
    }
  }
}
</script>