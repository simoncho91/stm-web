<template>
  <div class="contents-box__inner process-area">
    <table class="ui-table__th--bg-gray">
      <colgroup>
        <col style="width:14rem">
        <col style="width:auto">
        <col style="width:14rem">
        <col style="width:auto">
      </colgroup>
      <tbody v-if="noteInfo">
        <tr>
          <th>제품/원료명</th>
          <td colspan="3">
            {{noteInfo.vContNm}} 
            <template v-if="noteInfo.nContNum > 0">
              외 {{ noteInfo.nContNum }}건
            </template>
          </td>
        </tr>
        <tr>
          <th>내용물 코드</th>
          <td>
            {{ noteInfo.vContCd }} 
            <template v-if="noteInfo.nContNum > 0">
              외 {{ noteInfo.nContNum }}건
            </template>
          </td>
          <th>연구담당자</th>
          <td>{{ noteInfo.vUsernm }} ({{ noteInfo.vUserid }} / {{ noteInfo.vUsrDeptnm }})</td>
        </tr>
        <tr>
          <th>브랜드</th>
          <td>{{ noteInfo.vBrdNm }}</td>
          <th>플랜트</th>
          <td>{{ noteInfo.vPlantNm }}</td>
        </tr>
      </tbody>
    </table>

    <div class="divide-line"></div>
    <div class="search-bar__row">
      <dl class="search-bar__item">
        <dt class="search-bar__key search-bar__key--width-auto">효력시작일</dt>
        <dd class="search-bar__val">
          <ap-date-picker-range v-model:startDt="searchParams.vStartDt" v-model:endDt="searchParams.vEndDt"></ap-date-picker-range>
        </dd>
      </dl>
      <dl class="search-bar__item">
        <dt class="search-bar__key search-bar__key--width-auto">검색조건</dt>
        <dd class="search-bar__val">
          <div class="search-form">
            <div class="search-form__inner">
              <ap-input
                  v-model:value="searchParams.vKeyword"
                  class="ui-input__width--258"
                  placeholder="내용물코드 or 내용물명 or 연구담당자"
                  @keypress-enter="fnSearch(1)"
                >
                </ap-input>
                <button type="button" class="button-search" @click="fnSearch(1)">검색</button>
            </div>
          </div>
        </dd>
      </dl>
    </div>

    <div class="mt-15">
      <div class="ui-table__wrap">
        <table class="ui-table text-center ui-table__td--40">
          <colgroup>
            <col style="width:7%;">
            <col style="width:11%;">
            <col style="width:10%;">
            <col width="*">
            <col style="width:15%;">
            <col style="width:10%;">
            <col style="width:10%;">
            <col style="width:8%;">
          </colgroup>
          <thead>
            <tr>
              <th>NO</th>
              <th>VER - LOT</th>
              <th>내용물코드</th>
              <th>내용물명</th>
              <th>플랜트</th>
              <th>연구담당자/담당부서</th>
              <th>효력 시작일</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <template v-if="list && list.length > 0">
              <tr v-for="(vo, idx) in list" :key="'tr_' + idx">
                <td>{{ list.length - idx }}</td>
                <td>{{ vo.vVersionTxt }} - {{ vo.vLotNm }}</td>
                <td>{{ vo.vContCd}}</td>
                <td class="tit">
                  <div class="tit__inner">
                    <a href="#" class="tit-link" @click.prevent="goView(vo)">{{ vo.vContNm }}</a>
                  </div>
                </td>
                <td>[{{ vo.vPlantCd }}] {{ vo.vPlantNm }}</td>
                <td>{{ vo.vUsernm }}<br>/ {{ vo.vDeptNm }}</td>
                <td>{{ commonUtils.changeStrDatePattern(vo.vEffectDtm) }}</td>
                <td>
                  <button
                    v-if="showDecideBtn(vo) && showRegBtn()"
                    type="button" 
                    class="ui-button ui-button__width--70 ui-button__height--28 ui-button__radius--2 ui-button__border--blue"
                    @click="fnFormulaDecide(vo)"
                  >처방 확정</button>
                  <button
                    v-if="showDecideCancelBtn(vo) && showRegBtn()"
                    type="button"
                    class="ui-button ui-button__width--70 ui-button__height--28 ui-button__radius--2 ui-button__border--blue"
                    @click="fnFormulaDecideCancel(vo)"
                  >확정 해제</button>
                </td>
              </tr>
            </template>
            <template v-else>
              <tr>
                <td colspan="8">
                  <div class="no-result">{{ t('common.msg.no_data') }}</div>
                </td>
              </tr>
            </template>
          </tbody>
        </table>
      </div>
    </div>

  </div>
</template>

<script>
import { reactive, ref, inject } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useRoute } from 'vue-router'
import { useStore } from 'vuex'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'

export default {
  name: 'SkincareProcessPrescribeConfirmList',
  emits: ['callbackFunc', 'update:checkParams', 'update:vActionFlag'],
  setup (props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const route = useRoute()
    const store = useStore()
    const myInfo = store.getters.getMyInfo()
    const { openAsyncConfirm, openAsyncAlert } = useActions(['openAsyncConfirm', 'openAsyncAlert'])
    const list = ref([])
    const page = ref({})
    const contList = ref([])
    const noteInfo = ref(null)

    const {
      selectLabNoteFormulaDecideList,
      noteType,
    } = useProcessCommon()

    const {
      updateDecideCancel,
      insertElabNoteLatestBomInfo,
    } = useLabCommon()

    const searchParams = reactive({
      vKeyword: '',
      vLabNoteCd: route.query.vLabNoteCd || '',
      vStartDt: '',
      vEndDt: '',
      nowPageNo: 1,
    })

    const fnFormulaDecide = async (item) => {
      const decideLen = contList.value.filter(v => v.vContPkCd === item.vContPkCd && v.vFlagExistsDecide === 'Y').length

      if (decideLen > 0) {
        openAsyncAlert({ message: '이미 확정된 LOT이 있습니다.' })
        return
      }

      let message = ''
      let flagSendDecideBom = ''
      const chkBom = await insertElabNoteLatestBomInfo({ vLotCd: item.vLotCd, vNoteType: noteType })

      if (chkBom === 'Y') {
        message = '<span class="txt_red f-weight-700">1. 확정하려는 LOT의 처방이 SAP에 등록된 BOM 처방과 동일합니다.</span><br>'
                + '해당 LOT로 확정을 진행할지 확인 부탁드립니다.<br>'
                + '(LOT이 확정 되면 해당 LOT의 처방으로 다른 제품에서 이 제품을 카운터로 선택하였을 때 사용됩니다.)<br><br>'
        flagSendDecideBom = 'N'
      } else {
        message = '<span class="txt_red f-weight-700">1. 확정하려는 LOT의 처방이 SAP에 등록된 BOM처방이 동일하지 않습니다.</span><br>'
                + '동일하지 않는 경우 확정시 해당 LOT의 처방이 SAP으로 자동전송됩니다.<br>'
                + '해당 LOT로 확정을 진행할지 확인 부탁드립니다.</p>'
                + '(LOT이 확정 되면 해당 LOT의 처방으로 다른 제품에서 이 제품을 카운터로 선택하였을 때 사용됩니다.)<br><br>'
        flagSendDecideBom = 'Y'
      }

      message += '<span class="txt_red f-weight-700">2. 확정하려는 LOT로 안전성 시험의뢰 했는지 확인해주세요</span><br>'
                  + '(다른 LOT로 이미 안정성 시험의뢰 하였더라도 확정하시려는 LOT로 반드시 시험의뢰 해주셔야합니다.)<br><br>'
                  + '확인하셨습니까?'

      if (await openAsyncConfirm({ message })) {
        const checkParams = {
          vNoteType: noteType,
          vLabNoteCd: searchParams.vLabNoteCd,
          arrContPkCd: [ item.vContPkCd ],
          arrLotCd: [ item.vLotCd ],
          vContPkCd: item.vContPkCd,
          vLotCd: item.vLotCd,
          nVersion: item.nVersion,
          vPlantCd: item.vPlantCd,
          vPlantMstCd: item.vPlantMstCd,
          vPqcGate1ResCd: item.vG1PqcResCd,
          vFlagRepresent: item.vFlagRepresent,
          vFlagSendDecideBom: flagSendDecideBom,
          // 상세 정보 보여주는 용도
          vBrdNm: item.vBrdNm,
          vContNm: item.vContNm,
          vContCd: item.vContCd,
          vLotNm: item.vLotNm,
          vVersionTxt: item.vVersionTxt,
          vUserid: item.vUserid,
          vUsernm: item.vUsernm,
          vDeptNm: item.vDeptNm,
          vPlantCd: item.vPlantCd,
          vPlantNm: item.vPlantNm,
        }

        context.emit('update:checkParams', checkParams)
        context.emit('update:vActionFlag', 'R')
      }
    }

    const fnFormulaDecideCancel = async (item) => {
      let message = '<span class="txt_blue f-weight-700">[확정해제]시 Pilot 승인 단계로 돌아가며<br>'
                  + 'Lot 추가 시-Pilot 승인/전성분 승인,<br>'
                  + '기존 Lot (Pilot 승인) 사용 시-전성분 승인을 재수행해야 합니다.</span><br>'
                  + '<span class="txt_red f-weight-700">SCM등 유관부서와 논의 후 진행하시기 바랍니다.</span><br><br>'
                  + '확정해제 하시겠습니까?'
      
      if (await openAsyncConfirm({ message })) {
        const payload = {
          vNoteType: noteType,
          vLabNoteCd: searchParams.vLabNoteCd,
          vContCd: item.vContCd,
          vContNm: item.vContNm,
          vContPkCd: item.vContPkCd,
          nVersion: item.nVersion,
          vLotCd: item.vLotCd,
          vLotNm: item.vLotNm,
          vDeptCd: item.vDeptCd,
        }

        const result = await updateDecideCancel(payload)
        if (result && result === 'SUCC') {
          await openAsyncAlert({ message: '확정해제 완료하였습니다.'})
          fnSearch(1)
          context.emit('callbackFunc')
        }
      }
    }

    const goView = (item) => {
      if (commonUtils.isEmpty(item.vApprCd)) {
        return
      }

      const checkParams = {
        vNoteType: noteType,
        vApprCd: item.vApprCd,
        // 상세 정보 보여주는 용도
        vBrdNm: item.vBrdNm,
        vContNm: item.vContNm,
        vContCd: item.vContCd,
        vLotNm: item.vLotNm,
        vVersionTxt: item.vVersionTxt,
        vUserid: item.vUserid,
        vUsernm: item.vUsernm,
        vDeptNm: item.vDeptNm,
        vPlantCd: item.vPlantCd,
        vPlantNm: item.vPlantNm,
      }

      context.emit('update:checkParams', checkParams)
      context.emit('update:vActionFlag', 'V')
    }

    const showRegBtn = () => {
      let isVisible = false

      if ((noteInfo.value && noteInfo.value.vUserid === myInfo.loginId) || commonUtils.checkAuth('S000000')) {
        isVisible = true
      }

      return isVisible
    }

    const showDecideBtn = (item) => {
      let isVisible = false
      const decideLen = contList.value.filter(v => v.vContPkCd === item.vContPkCd && v.vFlagExistsDecide === 'Y').length
      const apprLen = list.value.filter(lot => lot.vContPkCd === item.vContPkCd && commonUtils.isNotEmpty(lot.vApprStatus) && lot.vApprStatus !== 'APS020').length

      if (decideLen === 0 && apprLen === 0) {
        isVisible = true
      }

      return isVisible
    }

    const showDecideCancelBtn = (item) => {
      let isVisible = false
      
      if (item.vFlagDecide === 'Y') {
        isVisible = true
      }

      return isVisible
    }

    const fnSearch = async (pg) => {
      if (!pg) {
        pg = 1
      }

      searchParams.nowPageNo = pg
      const result = await selectLabNoteFormulaDecideList(searchParams)

      if (result) {
        list.value = result.list
        contList.value = result.contList
        noteInfo.value = result.noteInfo
      }
    }

    const init = () => {
      fnSearch(1)
    }

    init()

    return {
      t,
      commonUtils,
      searchParams,
      noteType,
      list,
      page,
      noteInfo,
      fnSearch,
      fnFormulaDecide,
      fnFormulaDecideCancel,
      showRegBtn,
      showDecideBtn,
      showDecideCancelBtn,
      goView,
    }
  }
}
</script>