<template>
  <div class="arrordion-item is-active">
    <div class="arrordion-header">
      <div class="arrordion-title">연구원 정보</div>
      <button type="button" class="ui-button__accordion"></button>
    </div>

    <div class="arrordion-body">
      <table class="ui-table__th--bg-gray note_contents_tb">
        <colgroup>
          <col style="width:12rem">
          <col style="width:38rem">
          <col style="width:12rem">
          <col style="width:38rem">
        </colgroup>
        <tbody>
          <tr>
            <th>연구 담당자</th>
            <td>
              <template v-if="commonUtils.isNotEmpty(info.vUserid)">
                {{ info.vUsernm }} ( {{ info.vUserid }} / {{ info.vUsrDeptnm }} )
              </template>
              <button
                type="button"
                class="ui-button ui-button__height--28 ui-button__border--blue"
                v-if="showAssignResearchBtn()"
                @click="fnAssignResearchPop()"
              >담당자 지정</button>
            </td>
            <th>연구원 코드</th>
            <td>
              {{ info.vLabContCd }}
            </td>
          </tr>
          <tr>
            <th>담당 BSM</th>
            <td class="inside-td">
              <template v-if="commonUtils.isNotEmpty(info.vBsmUserid)">
                <p class="pl-20">{{ info.vBsmUsernm }} ( {{ info.vBsmUserid }} / {{ info.vBsmDeptnm }} )</p>
              </template>
              <table class="ui-table__contents mt-1" v-if="commonUtils.isNotEmpty(info.vBsmUseridSub1) || commonUtils.isNotEmpty(info.vBsmUseridSub2)">
                <colgroup>
                  <col style="width:14rem">
                  <col style="width:auto">
                </colgroup>
                <tbody>
                  <tr class="ui-table__contents--item" v-if="commonUtils.isNotEmpty(info.vBsmUseridSub1)">
                    <th>담당 BSM SUB</th>
                    <td>
                        {{ info.vBsmUsernmSub1 }} ( {{ info.vBsmUseridSub1 }} / {{ info.vBsmDeptnmSub1 }} )
                    </td>
                  </tr>
                  <tr class="ui-table__contents--item" v-if="commonUtils.isNotEmpty(info.vBsmUseridSub2)">
                    <th>담당 BSM SUB</th>
                    <td>
                      <template>
                        {{ info.vBsmUsernmSub2 }} ( {{ info.vBsmUseridSub2 }} / {{ info.vBsmDeptnmSub2 }} )
                      </template>
                    </td>
                  </tr>
                </tbody>
              </table>
            </td>
            <th>브랜드 담당 PM</th>
            <td>
              <template v-if="commonUtils.isNotEmpty(info.vBrdUserid)">
                {{ info.vBrdUsernm }} ( {{ info.vBrdUserid }} / {{ info.vBrdDeptnm }} )
              </template>
            </td>
          </tr>
          <tr>
            <th>향 담당자</th>
            <td>
              <template v-if="commonUtils.isNotEmpty(info.vPerfUserid)">
                {{ info.vPerfUsernm }} ( {{ info.vPerfUserid }} / {{ info.vPerfDeptnm }} )
              </template>
            </td>
            <th>CTC 담당자</th>
            <td>
              <template v-if="commonUtils.isNotEmpty(info.vCtcUserid)">
                {{ info.vCtcUsernm }} ( {{ info.vCtcUserid }} / {{ info.vCtcDeptnm }} )
              </template>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @callbackFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, ref, inject, watch } from 'vue'
import { useRoute } from 'vue-router'
import { useStore } from 'vuex'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'

export default {
  name: 'AllLabNoteSkincareResearcherInfoView',
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    AssignResearcherPop: defineAsyncComponent(() => import('@/components/skincare/popup/AssignResearcherPop.vue')),
  },
  setup () {
    const reqInfo = inject('reqInfo')
    const commonUtils = inject('commonUtils')
    const store = useStore()
    const route = useRoute()
    const myInfo = store.getters.getMyInfo()

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
    } = useLabCommon()

    const info = ref({
      vLabContCd: '',
      vBsmUserid: '',
      vBsmUsernm: '',
      vBsmDeptnm: '',
      vBrdUserid: '',
      vBrdUsernm: '',
      vBrdDeptnm: '',
      vBsmUseridSub1: '',
      vBsmUsernmSub1: '',
      vBsmDeptnmSub1: '',
      vBsmUseridSub2: '',
      vBsmUsernmSub2: '',
      vBsmDeptnmSub2: '',
      vPerfUserid: '',
      vPerfUsernm: '',
      vPerfDeptnm: '',
      vCtcUserid: '',
      vCtcUsernm: '',
      vCtcDeptnm: '',
      vUserid: '',
      vUsernm: '',
      vUsrDeptnm: '',
      vDeptNm: '',
    })

    const showAssignResearchBtn = () => {
      let isVisible = false

      if (reqInfo.value && reqInfo.value.vStatusCd === 'LNC06_03' &&
        (myInfo.loginId === reqInfo.value.vCtcUserid || commonUtils.checkAuth('S000000'))
      ) {
        isVisible = true
      }

      return isVisible
    }

    const fnPopSaveResult = () => {
      window.location.reload(true)
    }

    const fnAssignResearchPop = () => {
      popParams.value = {
        vLabNoteCd: route.query.vLabNoteCd,
        vUserid: info.value.vUserid,
        vUsernm: info.value.vUsernm,
        vDeptCd: info.value.vDeptCd || ''
      }

      popSelectFunc.value = fnPopSaveResult

      fnOpenPopup('AssignResearcherPop', false)
    }

    watch(() => reqInfo.value, (newValue) => {
      info.value = { ...info.value, ...newValue }
    })

    return {
      commonUtils,
      info,
      popupContent,
      popParams,
      popSelectFunc,
      showAssignResearchBtn,
      fnAssignResearchPop,
    }
  }
}
</script>