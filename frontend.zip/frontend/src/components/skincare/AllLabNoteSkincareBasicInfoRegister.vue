<template>
  <div class="arrordion-item is-active">
    <div class="arrordion-header">
      <div class="arrordion-title">내용물 개요</div>
      <button type="button" class="ui-button__accordion"></button>
    </div>
    <div class="arrordion-body">
      <div class="basic-info__table">
        <table class="ui-table__contents">
          <colgroup>
            <col style="width:17rem">
            <col style="width:auto">
            <col style="width:17rem">
            <col style="width:auto">
          </colgroup>
          <tbody>
            <tr class="tr_vertical">
              <th>브랜드<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td>
                <template v-if="flagAction === 'R' || (regParams.vBsmUserid === myInfo.loginId || regParams.vIsLabNoteAdmin === 'Y' )">
                  <div class="form-flex">
                    <div class="ui-select-box form-flex__cell--5" id="error_wrap_vBrdCd">
                      <ap-selectbox
                        v-model:value="regParams.vBrdCd"
                        :input-class="['ui-select__width--full', 'min-187']"
                        :options="codeGroupMaps['LAB_NOTE_BRAND']"
                        @change="fnValidate('vBrdCd');changePerfUser();"
                      >
                      </ap-selectbox>
                      <span class="error-msg" id="error_msg_vBrdCd"></span>
                    </div>
                    <div class="form-flex__cell--5">
                      <ap-input-check
                        v-model:model="regParams.vFlagOem"
                        id="flagOem"
                        value="Y"
                        label="OEM"
                      >
                      </ap-input-check>
                    </div>
                    <div class="ui-select-box form-flex__cell--5" v-if="regParams.vFlagOem === 'Y'">
                      <ap-input
                        v-model:value="regParams.vOemManufacturer"
                        :maxlength="200"
                      >
                      </ap-input>
                    </div>
                  </div>
                  <p class="p_caution">* 브랜드 지정 시 향 담당자도 자동으로 등록됩니다.</p>
                </template>
                <div class="form-flex" v-else>
                  <div class="form-flex__cell--5">{{ regParams.vBrdNm }}</div>
                  <div class="form-flex__cell--5">
                    <ap-input-check
                      v-model:model="regParams.vFlagOem"
                      id="flagOem"
                      value="Y"
                      label="OEM"
                      :disabled="true"
                    >
                    </ap-input-check>
                    <div class="form-flex__cell--5" v-if="regParams.vFlagOem === 'Y'">
                      {{ regParams.vOemManufacturer }}
                    </div>
                  </div>
                </div>
              </td>
              <th>플랜트<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td>
                <div class="form-flex" :class="flagAction === 'R' ? 'form-flex-error' : ''">
                  <div class="ui-select-box ui-form-box__width--200 form-flex__cell--5" id="error_wrap_vPlantCd" v-if="flagAction === 'R'">
                    <ap-selectbox
                      v-model:value="regParams.vPlantCd"
                      input-class="ui-select__width--full"
                      :options="codeGroupMaps['LAB_NOTE_PLANT']"
                      @change="fnValidate('vPlantCd');changePlantCd(regParams.vPlantCd);"
                    >
                    </ap-selectbox>
                    <span class="error-msg" id="error_msg_vPlantCd"></span>
                  </div>
                  <div class="form-flex__cell--5" v-else>
                    <span class="span_plant">{{ regParams.vPlantNm }} / </span>
                  </div>
                  <div class="ui-select-box ui-form-box__width--200 form-flex__cell--5" id="error_wrap_vSiteType">
                    <ap-selectbox
                      v-if="codeGroupMaps['MA_PLANT']"
                      v-model:value="regParams.vSiteType"
                      input-class="ui-select__width--full"
                      :options="codeGroupMaps['MA_PLANT'].filter(item => item.vBuffer1 === (commonUtils.isEmpty(regParams.vPlantCd) ? 'CN20' : regParams.vPlantCd))"
                      @change="fnValidate('vSiteType');changeSiteType(regParams.vSiteType);"
                    >
                    </ap-selectbox>
                    <span class="error-msg" id="error_msg_vSiteType"></span>
                  </div>
                </div>
              </td>
            </tr>
            <tr class="tr_vertical">
              <th>내용물명<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td id="error_wrap_vContNm">
                <ap-input
                  v-model:value="regParams.vContNm"
                  input-class="ui-input__width--340"
                  placeholder="내용물 명을 입력해 주세요."
                  :maxlength="200"
                  @input="fnValidate('vContNm')"
                >
                </ap-input>
                <span class="error-msg" id="error_msg_vContNm"></span>
              </td>
              <template v-if="showNoteContNmArea()">
                <th>실험노트 제품명<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
                <td id="error_wrap_vNoteContNm">
                  <ap-input
                    v-model:value="regParams.vNoteContNm"
                    :maxlength="200"
                    input-class="ui-input__width--340"
                    placeholder="실험노트 제품명을 입력해 주세요."
                  >
                  </ap-input>
                  <span class="error-msg" id="error_msg_vContNm"></span>
                </td>
              </template>
            </tr>
            <tr>
              <th>예산코드<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td>
                <div class="search-form" id="error_wrap_pjtList">
                  <div class="search-form__inner">
                    <ap-input
                      v-model:value="searchParams.ptsProjectKeyword"
                      input-class="ui-input__width--340"
                      placeholder="검색어를 입력하세요."
                    >
                    </ap-input>
                    <button type="button" class="button-search" @click="fnSearchPtsProjectPop">검색</button>
                  </div>
                  <span class="error-msg" id="error_msg_pjtList"></span>
                </div>
              </td>
            </tr>
            <tr v-if="regParams.pjtList.length > 0">
              <th></th>
              <td colspan="3">
                <div class="search-result-table">
                  <table class="ui-table__reset ui-table__search-result text-center">
                    <colgroup>
                      <col style="width:15rem"/>
                      <col style="width:15rem"/>
                      <col style="width:15rem"/>
                      <col style="width:auto"/>
                      <col style="width:5rem"/>
                    </colgroup>
                    <thead>
                      <tr>
                        <th>예산코드</th>
                        <th>과제유형</th>
                        <th>과제성격</th>
                        <th>과제명</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-for="(vo, index) in regParams.pjtList" :key="'pjt_' + index">
                        <td>{{ vo.vRpmsCd }}</td>
                        <td>{{ vo.vPjtType2Nm }}</td>
                        <td>{{ vo.vPjtTag }}</td>
                        <td>{{ vo.vPjtNm }}</td>
                        <td>
                          <div class="ui-buttons ui-buttons__order ui-buttons__center">
                            <button type="button" class="ui-button ui-button__circle ui-button__close" @click="removePtsProject(index)"></button>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </td>
            </tr>
            <tr>
              <th>제품코드</th>
              <td>
                <div class="search-form" id="error_wrap_vPrdCd">
                  <div class="search-form__inner">
                    <ap-input
                      v-model:value="regParams.vPrdCd"
                      input-class="ui-input__width--340"
                      :readonly="true"
                      @click="fnOpenProdSearchPop()"
                    >
                    </ap-input>
                    <button type="button"
                      class="ui-button ui-button__circle ui-button__close input-close-btn--310"
                      @click="removePrdCd()"
                    ></button>
                    <button type="button" class="button-search" @click="fnOpenProdSearchPop()">검색</button>
                  </div>
                  <span class="error-msg" id="error_msg_vPrdCd"></span>
                </div>
              </td>
              <th>내용물코드</th>
              <td>
                {{ regParams.vContCd }}
              </td>
            </tr>
            <tr>
              <th>신상품 여부<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td>
                <div class="ui-radio__list" id="error_wrap_vFlagNew">
                  <div class="ui-radio__inner">
                    <ap-input-radio
                      v-model:model="regParams.vFlagNew"
                      v-for="(vo, index) in [{vSubCode: 'Y', vSubCodenm: 'NEW'}, {vSubCode: 'N', vSubCodenm: 'AD'}]" :key="'flagNew_' + index"
                      :value="vo.vSubCode"
                      :label="vo.vSubCodenm"
                      :id="'flagNew_' + index"
                      name="flagNew"
                      @click="fnValidate('vFlagNew')"
                    ></ap-input-radio>
                  </div>
                  <span class="error-msg" id="error_msg_vFlagNew"></span>
                </div>
              </td>
            </tr>
            <tr>
              <th>제품유형<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td>
                <div class="form-flex form-flex-error">
                  <div
                    class="ui-select-box form-flex__cell--5"
                    :class="'ui-form-box__width--' + (regParams.vProdType2Cd !== 'MTR02_91' ? '200' : '150')"
                    id="error_wrap_vProdType1Cd"
                  >
                    <ap-selectbox
                      v-model:value="regParams.vProdType1Cd"
                      input-class="ui-select__width--full"
                      :options="codeGroupMaps['MTR01'] ? 
                                codeGroupMaps['MTR01'].filter(item => item.vBuffer1 === 'SC') : []"
                      @change="fnValidate('vProdType1Cd');changeProdType1Cd(regParams.vProdType1Cd);"
                    >
                    </ap-selectbox>
                    <span class="error-msg" id="error_msg_vProdType1Cd"></span>
                  </div>
                  <div
                    class="ui-select-box form-flex__cell--5"
                    :class="'ui-form-box__width--' + (regParams.vProdType2Cd !== 'MTR02_91' ? '200' : '150')"
                    id="error_wrap_vProdType2Cd"
                  >
                    <ap-selectbox
                      v-model:value="regParams.vProdType2Cd"
                      input-class="ui-select__width--full"
                      :options="regParams.vProdType1Cd !== '' && codeGroupMaps['MTR02'] ?  codeGroupMaps['MTR02'].filter(item => item.vBuffer1 === regParams.vProdType1Cd) : []"
                      @change="fnValidate('vProdType2Cd');changeProdType2Cd(regParams.vProdType2Cd);"
                    >
                    </ap-selectbox>
                    <span class="error-msg" id="error_msg_vProdType2Cd"></span>
                  </div>
                  <div
                    v-if="commonUtils.isNotEmpty(regParams.vProdType2Cd) && Number(regParams.vProdType2Cd.replace('MTR02_', '')) > 90"
                    class="ui-select-box ui-form-box__width--150 form-flex__cell--5"
                  >
                    <ap-input
                      v-model:value="regParams.vProdTypeNote"
                      :maxlength="200"
                    >
                    </ap-input>
                  </div>
                </div>
              </td>
              <th>TDD 제품유형<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td>
                <div class="form-flex form-flex-error">
                  <div class="ui-select-box ui-form-box__width--200 form-flex__cell--5" id="error_wrap_vTddProdType1Cd">
                    <ap-selectbox
                      v-model:value="regParams.vTddProdType1Cd"
                      input-class="ui-select__width--full"
                      :options="tddProdType1List"
                      codeKey="vClassCd"
                      codeNmKey="vClassNm"
                      @change="fnValidate('vTddProdType1Cd');getTddProdType2List(regParams.vTddProdType1Cd);"
                    >
                    </ap-selectbox>
                    <span class="error-msg" id="error_msg_vTddProdType1Cd"></span>
                  </div>
                  <div class="ui-select-box ui-form-box__width--200 form-flex__cell--5" id="error_wrap_vTddProdType2Cd">
                    <ap-selectbox
                      v-model:value="regParams.vTddProdType2Cd"
                      input-class="ui-select__width--full"
                      :options="tddProdType2List.length > 0 ? tddProdType2List : []"
                      codeKey="vClassCd"
                      codeNmKey="vClassNm"
                      @change="fnValidate('vTddProdType2Cd');"
                    >
                    </ap-selectbox>
                    <span class="error-msg" id="error_msg_vTddProdType2Cd"></span>
                  </div>
                </div>
              </td>
            </tr>
            <tr>
              <th>적용 부위/방식</th>
              <td>
                <div class="form-flex form-flex-error">
                  <div class="ui-select-box ui-form-box__width--200 form-flex__cell--5" id="error_wrap_vPartCd">
                    <ap-selectbox
                      v-model:value="regParams.vPartCd"
                      input-class="ui-select__width--full"
                      :options="codeGroupMaps['TR_INDICATIO_PART']"
                    >
                    </ap-selectbox>
                    <span class="error-msg" id="error_msg_vPartCd"></span>
                  </div>
                  <div class="ui-select-box ui-form-box__width--200 form-flex__cell--5" id="error_wrap_vLeaveType">
                    <ap-selectbox
                      v-model:value="regParams.vLeaveType"
                      input-class="ui-select__width--full"
                      :options="codeGroupMaps['LNC14'] ? 
                                codeGroupMaps['LNC14'].filter(item => item.vBuffer2 === 'LN') : []"
                    >
                    </ap-selectbox>
                    <span class="error-msg" id="error_msg_vLeaveType"></span>
                  </div>
                </div>
              </td>
            </tr>
            <tr>
              <th>용기정보</th>
              <td>
                <div class="form-flex">
                  <div class="ui-select-box ui-form-box__width--200  form-flex__cell--5">
                    <ap-selectbox
                      v-model:value="regParams.vContainerCd"
                      input-class="ui-select__width--full"
                      :options="codeGroupMaps['LNC26']"
                    >
                    </ap-selectbox>
                  </div>
                  <div class="ui-select-box ui-form-box__width--200  form-flex__cell--5">
                    <ap-input
                      v-model:value="regParams.vContainerEtc"
                      :maxlength="300"
                      input-class="ui-input__width--full"
                    >
                    </ap-input>
                  </div>
                </div>
              </td>
            </tr>
            <tr>
              <th>출시국가/시기<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
            </tr>
            <tr>
              <td colspan="4" class="inside-td inside-td__nation">
                <table class="ui-table__contents">
                  <colgroup>
                    <col style="width:14rem">
                  </colgroup>
                  <tbody>
                    <tr
                      v-for="(key, index) in Object.keys(releaseMap)"
                      :key="'countryList_' + index"
                      class="ui-table__contents--item"
                    >
                      <th>{{ releaseMap[key].ariaNm }}</th>
                      <td :id="'error_wrap_releaseInfo' + key">
                        <div class="clearfix">
                          <div class="clearfix_inner" v-show="regParams['vFlagRelease' + key] !== 'U'">
                            <ap-input-check
                              v-model:model="regParams['vFlagRelease' + key]"
                              value="N"
                              label="대상아님"
                              :id="key + '_none'"
                              @click="fnValidate('releaseInfo' + key);checkReleaseDtGroup(regParams['vFlagRelease' + key], key)"
                            >
                            </ap-input-check>
                          </div>
                          <div class="clearfix_inner" v-show="regParams['vFlagRelease' + key] !== 'N'">
                            <ap-input-check
                              v-model:model="regParams['vFlagRelease' + key]"
                              value="U"
                              label="미정"
                              :id="key + '_undecided'"
                              @click="fnValidate('releaseInfo' + key);checkReleaseDtGroup(regParams['vFlagRelease' + key], key)"
                            >
                            </ap-input-check>
                          </div>
                          <div class="clearfix_wide d-flex" v-show="regParams['vFlagRelease' + key] !== 'N' && regParams['vFlagRelease' + key] !== 'U'">
                            <ap-input-check
                              v-model:model="regParams['vFlagReleaseAll' + key]"
                              value="Y"
                              label="전체선택"
                              :id="key + '_all'"
                              @click="fnValidate('releaseInfo' + key);checkReleaseAll(regParams['vFlagReleaseAll' + key], key)"
                            >
                            </ap-input-check>
                            <ap-month-picker
                              v-if="regParams['vFlagReleaseAll' + key] === 'Y'"
                              v-model:date="regParams['vReleaseAllDt' + key]"
                              @update:date="changeReleaseAllDt(regParams['vReleaseAllDt' + key], regParams['vFlagReleaseAll' + key], key);fnValidate('releaseInfo' + key);"
                            >
                            </ap-month-picker>
                          </div>
                        </div>
                        <div class="clearfix" v-if="regParams['vFlagRelease' + key] !== 'N' && regParams['vFlagRelease' + key] !== 'U'">
                          <template v-if="releaseMap[key].countryList" >
                            <div
                              v-for="(vo, idx) in releaseMap[key].countryList"
                              :key="key + '_' + idx"
                              class="clearfix_inner"
                              :class="vo.vSubCode === 'LNC02_04' ? 'clearfix_wide' : ''"
                            >
                              <ap-input-check
                                v-model:model="vo.vTag2Cd"
                                :value="vo.vSubCode"
                                :label="vo.vSubCodenm"
                                :id="key + '_' + idx"
                                @click="fnValidate('releaseInfo' + key);checkReleaseInfo(key)"
                              >
                              </ap-input-check>
                              <template v-if="vo.vSubCode !== 'LNC02_04'">
                                <ap-month-picker
                                  v-if="commonUtils.isNotEmpty(vo.vTag2Cd)"
                                  v-model:date="vo.vTagBuffer1"
                                  @update:date="fnValidate('releaseInfo' + key);"
                                >
                                </ap-month-picker>
                              </template>
                              <template v-else>
                                <div class="form-flex" v-if="commonUtils.isNotEmpty(vo.vTag2Cd)">
                                  <div class="form-flex__cell--5">
                                    <ap-month-picker
                                      v-model:date="vo.vTagBuffer1"
                                      @update:date="fnValidate('releaseInfo' + key);"
                                    >
                                    </ap-month-picker>
                                  </div>
                                  <div class="form-flex__cell--5">
                                    <ap-input
                                      v-if="vo.vSubCode === 'LNC02_04'"
                                      v-model:value="vo.vTagBuffer2"
                                    >
                                    </ap-input>
                                  </div>
                                </div>
                              </template>
                            </div>
                          </template>
                        </div>
                        <span class="error-msg" :id="'error_msg_releaseInfo' + key"></span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
            <tr>
              <th>파일럿</th>
              <td>
                <ap-month-picker
                  v-model:date="regParams.vPilotDt"
                  input-class="div_width--200"
                >
                </ap-month-picker>
              </td>
              <th>생산회의</th>
              <td>
                <ap-month-picker
                  v-model:date="regParams.vMeetingDt"
                  input-class="div_width--200"
                >
                </ap-month-picker>
              </td>
            </tr>
            <tr>
              <th>ONE POINT (기술관점)</th>
              <td colspan="3">
                <ap-input
                  v-model:value="regParams.vOnePointTech"
                  :maxlength="200"
                >
                </ap-input>
              </td>
            </tr>
            <tr>
              <th>비고</th>
              <td colspan="3">
                <div class="ui-textarea-box" id="error_wrap_vNote">
                  <ap-text-area
                    v-model:value="regParams.vNote"
                    :is-with-byte="true"
                    :maxlength="1000"
                    id="vNote"
                  ></ap-text-area>
                  <span class="error-msg" id="error_msg_vNote"></span>
                </div>
              </td>
            </tr>
            <tr>
              <th>첨부파일</th>
              <td colspan="3">
                <UploadFileRegister
                  uploadid="LAB_NOTE_ATT01"
                  :parent-info="uploadParams"
                >
                </UploadFileRegister>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @selectFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, reactive, ref, inject, watch, computed } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useStore } from 'vuex'

export default {
  name: 'AllLabNoteSkincareBasicInfoRegister',
  components: {
    UploadFileRegister: defineAsyncComponent(() => import('@/components/comm/UploadFileRegister.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    PtsProjectSearchPop: defineAsyncComponent(() => import('@/components/labcommon/popup/PtsProjectSearchPop.vue')),
    ProdSearchPop: defineAsyncComponent(() => import('@/components/labcommon/popup/ProdSearchPop.vue'))
  },
  props: {
    flagAction: {
      type: String,
      default: 'R'
    }
  },
  setup (props) {
    const reqInfo = inject('reqInfo')
    const commonUtils = inject('commonUtils')
    const store = useStore()
    const myInfo = store.getters.getMyInfo()
    const storedNoteInfo = computed(() => store.getters.getNoteInfo())
    let plantCd = ''

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const {
      tddProdType1List,
      tddProdType2List,
      selectTddProdTypeList,
      selectLabCodeRequired,
      popupContent,
      popParams,
      popSelectFunc,
      fnChangeNoteInfo,
      fnOpenPopup,
      releaseMap,
    } = useLabCommon()

    const searchParams = reactive({
      ptsProjectKeyword: ''
    })

    const regParams = ref({
      vBrdCd: '',
      vBrdNm: '',
      vFlagOem: '',
      vOemManufacturer: '',
      vPlantCd: '',
      vSiteType: '',
      pjtList: [],
      releaseList: [],
      vContNm: '',
      vNoteContNm: '',
      vPrdCd: '',
      vContCd: '',
      vFlagNew: '',
      vProdType1Cd: '',
      vProdType2Cd: '',
      vProdTypeNote: '',
      vTddProdType1Cd: '',
      vTddProdType2Cd: '',
      vPartCd: '',
      vLeaveType: '',
      vFlagReleaseASIA: '',
      vFlagReleaseASEAN: '',
      vFlagReleaseETC: '',
      vFlagReleaseAllASIA: '',
      vFlagReleaseAllASEAN: '',
      vFlagReleaseAllETC: '',
      vReleaseAllDtASIA: '',
      vReleaseAllDtASEAN: '',
      vReleaseAllDtETC: '',
      vPilotDt: '',
      vMeetingDt: '',
      vContainerCd: '',
      vContainerEtc: '',
      vIsLabNoteAdmin: '',
      vOnePointTech: '',
      vNote: ''
    })

    const uploadParams = reactive({
      vRecordid: '',
      items: []
    })

    const fnSearchPtsProjectPop = () => {
      popParams.value = {
        vKeyword: searchParams.ptsProjectKeyword
      }

      popSelectFunc.value = getPtsProject
      fnOpenPopup('PtsProjectSearchPop', false)
    }

    const getPtsProject = (selectList) => {
      selectList.forEach(item => {
        if (regParams.value.pjtList.filter(vo => vo.vPjtCd === item.vPjtCd).length === 0) {
          regParams.value.pjtList.push({ ...item })
        }
      })

      fnValidate('pjtList')
    }

    const removePtsProject = (index) => {
      regParams.value.pjtList.splice(index, 1)
      fnValidate('pjtList')
    }

    const fnOpenProdSearchPop = () => {
      popParams.value = {
        vKeyword: regParams.value.vPrdCd
      }

      popSelectFunc.value = getProdInfo
      fnOpenPopup('ProdSearchPop')
    }

    const getProdInfo = (item) => {
      regParams.value.vPrdCd = item.vPrdCd
    }

    const removePrdCd = () => {
      regParams.value.vPrdCd = ''
    }

    const getTddProdType2List = (tddProdType1Cd) => {
      regParams.value.vTddProdType2Cd = ''
      selectTddProdTypeList({vClassCd: tddProdType1Cd, vFlagSub: 'Y'}, 'TYPE2')
    }

    const changePlantCd = (selectCode) => {
      const noteInfo = store.getters.getNoteInfo()
      const newInfo = { ...noteInfo, ...{vPlantCd: selectCode} }
      setSiteType()
      fnChangeNoteInfo(newInfo)
    }

    const changeSiteType = (selectCode) => {
      const noteInfo = store.getters.getNoteInfo()
      const newInfo = { ...noteInfo, ...{vSiteType: selectCode} }
      fnChangeNoteInfo(newInfo)
    }

    const changeProdType1Cd = (selectCode) => {
      const noteInfo = store.getters.getNoteInfo()
      const newInfo = { ...noteInfo, ...{vProdType1Cd: selectCode} }
      fnChangeNoteInfo(newInfo)
    }

    const changeProdType2Cd = (selectCode) => {
      const noteInfo = store.getters.getNoteInfo()
      const newInfo = { ...noteInfo, ...{vProdType2Cd: selectCode} }
      fnChangeNoteInfo(newInfo)
    }

    const changePerfUser = () => {
      if (commonUtils.isEmpty(regParams.value.vBrdCd)) {
        return
      }

      const tempInfo = codeGroupMaps.value['LAB_NOTE_BRAND'].filter(item => item.vSubCode === regParams.value.vBrdCd)
      if (tempInfo) {
        const brdInfo = tempInfo[0]
        store.dispatch('setPerfUserid', brdInfo.vContent2)
      }
    }

    const setSiteType = () => {
      const siteOption = codeGroupMaps.value['MA_PLANT'].filter(item => item.vBuffer1 === (commonUtils.isEmpty(regParams.value.vPlantCd) ? 'CN20' : regParams.value.vPlantCd))
      regParams.value.vSiteType = siteOption.length === 1 ? siteOption[0].vSubCode : ''
    }

    const checkReleaseDtGroup = (value, key) => {
      if (value === 'N' || value === 'U') {
        regParams.value['vFlagReleaseAll' + key] = ''
        regParams.value['vReleaseAllDt' + key] = ''
        releaseMap.value[key].countryList.forEach(item => {
          item.vTag2Cd = ''
          item.vTagBuffer1 = ''
          item.vTagBuffer2 = ''
        })
      }
    }

    const checkReleaseAll = (value, key) => {
      if (value === 'Y') {
        releaseMap.value[key].countryList.forEach(item => {
          item.vTag2Cd = item.vSubCode
        })
      } else {
        releaseMap.value[key].countryList.forEach(item => {
          item.vTag2Cd = ''
          item.vTagBuffer1 = ''
        })
      }
    }

    const changeReleaseAllDt = (ym, value, key) => {
      if (value === 'Y') {
        releaseMap.value[key].countryList.forEach(item => {
          item.vTagBuffer1 = ym
        })
      }
    }

    const checkReleaseInfo = (key) => {
      const countryList = releaseMap.value[key].countryList
      const allLength = countryList.length
      const checkedLength = countryList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)).length

      if (allLength === checkedLength) {
        regParams.value['vFlagReleaseAll' + key] = 'Y'
      } else {
        regParams.value['vFlagReleaseAll' + key] = 'N'
      }

      regParams.value['vReleaseAllDt' + key] = ''
    }

    const showNoteContNmArea = () => {
      let isVisible = false
      if (props.flagAction === 'M' && plantCd === 'CN20' && 
            'LNC06_01;LNC06_02;LNC06_03;LNC06_04;LNC06_05;LNC06_06'.indexOf(regParams.value.vStatusCd) === -1) {
        isVisible = true
      }

      return isVisible
    }

    const fnValidateAll = (arrChkKey) => {
      let isOk = true
      commonUtils.hideErrorMessageAll(arrChkKey)

      arrChkKey.forEach(key => {
        if (!fnValidate(key)) {
          isOk = false
        }
      })

      return isOk
    }

    const fnValidate = (key) => {
      let isOk = true
      let errorMsg = '필수 입력 사항입니다.'
      commonUtils.hideErrorMessage(key)

      if (key === 'vNoteContNm') {
        if (showNoteContNmArea() && commonUtils.isEmpty(regParams.value[key])) {
          isOk = false
        }
      } else if (key === 'pjtList') {
        if (regParams.value.pjtList.length === 0) {
          isOk = false
        }
      } else if (key === 'releaseInfoASIA') {
        const countryLen = releaseMap.value['ASIA'].countryList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)).length
        const releaseDtLen = releaseMap.value['ASIA'].countryList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd) && commonUtils.isEmpty(item.vTagBuffer1)).length

        if (commonUtils.isEmpty(regParams.value.vFlagReleaseASIA) && countryLen === 0) {
          isOk = false
          errorMsg = '출시지역을 선택해 주세요.'
        } else if (commonUtils.isEmpty(regParams.value.vFlagReleaseASIA) && countryLen > 0 && releaseDtLen > 0) {
          isOk = false
          errorMsg = '출시시기를 입력해 주세요.'
        }
      } else if (key === 'releaseInfoASEAN') {
        const countryLen = releaseMap.value['ASEAN'].countryList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)).length
        const releaseDtLen = releaseMap.value['ASEAN'].countryList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd) && commonUtils.isEmpty(item.vTagBuffer1)).length

        if (commonUtils.isEmpty(regParams.value.vFlagReleaseASEAN) && countryLen === 0) {
          isOk = false
          errorMsg = '출시지역을 선택해 주세요.'
        } else if (commonUtils.isEmpty(regParams.value.vFlagReleaseASEAN) && countryLen > 0 && releaseDtLen > 0) {
          isOk = false
          errorMsg = '출시시기를 입력해 주세요.'
        }
      } else if (key === 'releaseInfoETC') {
        const countryLen = releaseMap.value['ETC'].countryList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)).length
        const releaseDtLen = releaseMap.value['ETC'].countryList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd) && commonUtils.isEmpty(item.vTagBuffer1)).length
        if (commonUtils.isEmpty(regParams.value.vFlagReleaseETC) && countryLen === 0) {
          isOk = false
          errorMsg = '출시지역을 선택해 주세요.'
        } else if (commonUtils.isEmpty(regParams.value.vFlagReleaseETC) && countryLen > 0 && releaseDtLen > 0) {
          isOk = false
          errorMsg = '출시시기를 입력해 주세요.'
        }
      } else if (key === 'vNote') {
        if (!commonUtils.checkByte(regParams.value.vNote, 1000)) {
          isOk = false
          errorMsg = t('common.msg.byte_msg2', { byteSize: commonUtils.setNumberComma(1000) })
        }
      } else if (commonUtils.isEmpty(regParams.value[key])) {
        isOk = false
      }

      if (!isOk) {
        commonUtils.showErrorMessage(key, errorMsg)
      }

      return isOk
    }

    const init = async () => {
      const arrMstCode = [
        'LAB_NOTE_BRAND', 'LAB_NOTE_PLANT', 'MA_PLANT', 'MTR01', 
        'MTR02', 'TR_INDICATIO_PART', 'LNC14', 'LNC26'
      ]
      await findCodeList(arrMstCode)
      selectTddProdTypeList({vNoteType: store.getters.getNoteType()}, 'TYPE1')

      if (commonUtils.isEmpty(regParams.value.vSiteType)) {
        setSiteType()
      }
    }

    init()

    watch(() => reqInfo.value, (newValue) => {
      regParams.value = { ...regParams.value, ...newValue }
      plantCd = newValue.vPlantCd

      if (regParams.value.releaseList && regParams.value.releaseList.length > 0) {
        regParams.value.releaseList.forEach(item => {
          releaseMap.value[item.vBuffer1].countryList.push({ ...item })
        })
      }

      if (commonUtils.isNotEmpty(reqInfo.value.vLabNoteCd)) {
        uploadParams.vRecordid = reqInfo.value.vLabNoteCd
      }

      fnChangeNoteInfo(regParams.value)
      selectTddProdTypeList({vClassCd: regParams.value.vTddProdType1Cd, vFlagSub: 'Y'}, 'TYPE2')

      if (commonUtils.isEmpty(regParams.value.vPerfUserid)) {
        changePerfUser()
      }
    })

    watch(() => storedNoteInfo.value, async (newVal) => {
      if (newVal && newVal.vDeptCd) {
        const result = await selectLabCodeRequired({ vDeptCd: newVal.vDeptCd})
        if (result && result.length === 1) {
          getPtsProject(result)
        }
      }
    })

    return {
      myInfo,
      codeGroupMaps,
      releaseMap,
      regParams,
      commonUtils,
      uploadParams,
      searchParams,
      tddProdType1List,
      tddProdType2List,
      popupContent,
      popParams,
      popSelectFunc,
      fnSearchPtsProjectPop,
      getTddProdType2List,
      changePlantCd,
      changeSiteType,
      changeProdType1Cd,
      changeProdType2Cd,
      changePerfUser,
      removePtsProject,
      fnOpenProdSearchPop,
      checkReleaseDtGroup,
      checkReleaseAll,
      changeReleaseAllDt,
      checkReleaseInfo,
      showNoteContNmArea,
      removePrdCd,
      fnValidateAll,
      fnValidate,
    }
  }
}
</script>

<style scoped>
  .span_plant { line-height: 3.5rem; }
</style>