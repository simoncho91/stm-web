<template>
  <SkincareProcessPrescribeConfirmList
    v-if="vActionFlag === 'L'"
    v-model:vActionFlag="vActionFlag"
    v-model:check-params="checkParams"
    @callbackFunc="setProgressInfo"
  >
  </SkincareProcessPrescribeConfirmList>
  <SkincareProcessPrescribeConfirmReg
    v-if="vActionFlag === 'R'"
    v-model:vActionFlag="vActionFlag"
    v-model:check-params="checkParams"
    @callbackFunc="setProgressInfo"
  >
  </SkincareProcessPrescribeConfirmReg>
  <SkincareProcessPrescribeConfirmView
    v-if="vActionFlag === 'V'"
    v-model:vActionFlag="vActionFlag"
    v-model:check-params="checkParams"
    @callbackFunc="setProgressInfo"
  >
  </SkincareProcessPrescribeConfirmView>
</template>

<script>
import { defineAsyncComponent, ref } from 'vue'


export default {
  name: 'SkincareProcessPrescribeConfirm',
  components: {
    SkincareProcessPrescribeConfirmList: defineAsyncComponent(() => import('@/components/skincare/SkincareProcessPrescribeConfirmList.vue')),
    SkincareProcessPrescribeConfirmReg: defineAsyncComponent(() => import('@/components/skincare/SkincareProcessPrescribeConfirmReg.vue')),
    SkincareProcessPrescribeConfirmView: defineAsyncComponent(() => import('@/components/skincare/SkincareProcessPrescribeConfirmView.vue')),
  },
  emits: ['callbackFunc'],
  setup (props, context) {
    const vActionFlag = ref('L')
    const checkParams = ref({})

    const setProgressInfo = () => {
      context.emit('callbackFunc')
    }

    return {
      vActionFlag,
      checkParams,
      setProgressInfo,
    }
  }
}
</script>