<template>
  <div class="modal-content modal-content__width--680">
    <div class="modal-header">
      <div class="modal-title">담당자 지정</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({message: ''})"></button>
    </div>

    <div class="modal-body">
      <section class="search-bar">
        <h2 class="for-a11y">검색</h2>
        <div class="search-bar__left">
          <div class="search-bar__row">
            <dl class="search-bar__item search-bar__item--width-100">
              <dt class="search-bar__key search-bar__key--width-8">
                담당자 지정
              </dt>
              <dd class="search-bar__val search-bar__val--flex">
                <div class="search-form">
                  <div class="search-form__inner">
                    <ap-input
                      v-model:value="searchUserKeyword"
                      :input-class="['ui-input', 'ui-input__width--full']"
                      @keypress-enter="fnSearchUser()"
                    >
                    </ap-input>
                    <button type="button" class="button-search" @click="fnSearchUser()">검색</button>
                    <button type="button" class="button-search" @click="fnRemoveResearcher()">삭제</button>
                  </div>
                </div>

                <div class="cont-input-scroll-area" :class="showArea ? '' : ' hide'">
                  <ul class="cont-input-scroll-list">
                    <template v-if="userList && userList.length > 0">
                      <li class="cont-input-scroll-item" v-for="(vo, idx) in userList" :key="'user_' + idx">
                        <p class="cont-input-scroll-tit text-left">{{ vo.vUsernm }} ({{ vo.vDeptnm }}) / {{ vo.vEmail }}</p>
                        <button type="button" class="ui-button ui-button__height--28 ui-button__bg--blue" @click="fnSelectUser(vo)">{{ t('common.label.select') }}</button>
                      </li>
                    </template>
                    <template v-else>
                      <li class="cont-input-scroll-item t-center">
                        {{ t('common.msg.no_data') }}
                      </li>
                    </template>
                  </ul>
                </div>
              </dd>
            </dl>
          </div>
        </div>
      </section>

      <div class="board-bottom">
        <div class="board-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--skyblue font-weight__300" @click="fnSave()">저장</button>
            <button type="button" class="ui-button ui-button__bg--lightgray" @click="closeAsyncPopup({message: ''})">닫기</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { inject, ref, reactive } from 'vue'
import { useComm } from '@/compositions/useComm'
import { useSkinRequest } from '@/compositions/skincare/useSkinRequest'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'AssignResearcherPop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  emits: ['callbackFunc'],
  setup (props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncAlert', 'closeAsyncPopup'])

    const {
      selectUserList,
      userList
    } = useComm()

    const {
      updateLabNoteMstUser,
    } = useSkinRequest()

    const regParams = reactive({
      vLabNoteCd: props.popParams.vLabNoteCd || '',
      vUserid: props.popParams.vUserid || '',
      vDeptCd: props.popParams.vDeptCd || '',
    })

    const searchUserKeyword = ref(props.popParams.vUsernm || '')
    const showArea = ref(false)

    const fnSelectUser = (item) => {
      if (commonUtils.isEmpty(item.vLabor)) {
        openAsyncAlert({ message: 'SAP 연구원코드가 존재하지 않습니다.<br>다른 연구원을 지정해주시기 바랍니다.' })
        return
      }
      regParams.vUserid = item.vUserid
      regParams.vDeptCd = item.vDeptcd
      searchUserKeyword.value = item.vUsernm
      showArea.value = false
    }

    const fnSearchUser = async () => {
      if (!searchUserKeyword.value) {
        openAsyncAlert({ message: t('common.msg.search_msg') })
        showArea.value = false
        return
      }

      if (searchUserKeyword.value.length < 2) {
        openAsyncAlert({ message: '두 글자 이상 입력해 주세요.'})
        showArea.value = false
        return
      }

      await selectUserList(searchUserKeyword.value)

      /* if (userList.value.length === 1) {
        fnSelectUser(userList.value[0])
      } else {
        showArea.value = true
      } */
      showArea.value = true
    }

    const fnRemoveResearcher = () => {
      regParams.vUserid = ''
      regParams.vDeptCd = ''
      searchUserKeyword.value = ''
    }

    const fnSave = async () => {
      if (commonUtils.isEmpty(regParams.vUserid)) {
        openAsyncAlert({ message: '담당자가 지정되지 않았습니다. 검색하여 지정해 주세요.'})
        return
      }

      const result = await updateLabNoteMstUser(regParams)

      if (result) {
        await openAsyncAlert({ message: '담당자 지정이 완료되었습니다.'})
        context.emit('callbackFunc')
      }
    }

    return {
      t,
      showArea,
      userList,
      searchUserKeyword,
      fnSearchUser,
      fnSelectUser,
      fnRemoveResearcher,
      closeAsyncPopup,
      fnSave,
    }
  }
}
</script>