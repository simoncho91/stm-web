<template>
  <div class="modal-content modal-content__width--680">
    <div class="modal-header">
      <div class="modal-title">골격처방 검색</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({message: ''})"></button>
    </div>

    <div class="modal-body">
      <div class="board-top">
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item">
            <dt class="search-bar__key search-bar__width--70">카테고리</dt>
            <dd class="search-bar__val">
              <ap-selectbox
                v-model:value="searchParams.vCtgCd"
                input-class="ui-select__width--170"
                :options="codeGroupMaps['SKT_CATEGORY']"
              >
              </ap-selectbox>
            </dd>
          </dl>
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key">검색</dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="search-form">
                <div class="search-form__inner">
                  <ap-input
                    v-model:value="searchParams.vKeyword"
                    input-class="ui-input ui-input__width--full"
                    placeholder="골격처방번호 or 브랜드 or 대표처방명"
                    @keypress-enter="fnSearch(1)"
                  >
                  </ap-input>
                  <button type="button" class="button-search" @click="fnSearch(1)">검색</button>
                </div>
              </div>
            </dd>
          </dl>
        </div>
      </div>

      <div class="ui-table__wrap">
        <table class="ui-table text-center ui-table__td--40">
          <colgroup>
            <col style="width:10rem">
            <col style="width:10rem">
            <col style="width:12rem;">
            <col style="width:auto;">
          </colgroup>
          <thead>
            <tr>
              <th>카테고리</th>
              <th>골격처방번호</th>
              <th>브랜드</th>
              <th>대표처방명</th>
            </tr>
          </thead>
          <tbody>
            <template v-if="list.length > 0">
              <tr v-for="vo in list" :key="vo.vFrameNo" @click="fnFormulaSelect(vo)">
                <td>{{ vo.vCtgnm }}</td>
                <td>{{ vo.vFrameShowno }}</td>
                <td>{{ vo.vBrand }}</td>
                <td>{{ vo.vPrdnm }}</td>
              </tr>
            </template>
            <template v-else>
              <tr>
                <td colspan="4">
                  <div class="no-result">
                    {{ t('common.msg.no_data') }}
                  </div>
                </td>
              </tr>
            </template>
          </tbody>
        </table>
      </div>

      <div class="board-bottom">
        <div class="board-bottom__inner">
          <Pagination
            :page-info="page"
            @click="fnSearch"
          >
          </Pagination>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, inject, ref } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useSkincareCommon } from '@/compositions/skincare/useSkincareCommon'

import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'SkeletonFormulaSearchPop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {
          vKeyword: ''
        }
      }
    }
  },
  components: {
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
  },
  emits: ['selectFunc'],
  setup (props, context) {
    const t = inject('t')
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])
    const searchParams = ref({
      vKeyword: props.popParams.vKeyword,
      vCtgCd: '',
      nowPageNo: 1
    })

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const {
      page,
      list,
      selectFrameFormulaList
    } = useSkincareCommon()

    const fnSearch = (pg) => {
      if (!pg) {
        pg = 1
      }

      searchParams.value.nowPageNo = pg

      selectFrameFormulaList(searchParams.value)
    }

    const fnFormulaSelect = (vo) => {
      context.emit('selectFunc', vo)
      closeAsyncPopup({ message: '닫기' })
    }

    const init = () => {
      findCodeList(['SKT_CATEGORY'])

      fnSearch(1)
    }

    init()

    return {
      t,
      page,
      list,
      searchParams,
      codeGroupMaps,
      closeAsyncPopup,
      fnFormulaSelect
    }
  }
}
</script>

<style scoped>
  .ui-table tbody tr {
    cursor: pointer;
  }
</style>