<template>
  <div class="modal-content modal-content__width--922">
    <div class="modal-header">
      <div class="modal-title">출시 완료</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({message: ''})"></button>
    </div>

    <div class="modal-body">
      <div class="board-top mb-0">
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--120">출시완료일<span class="ui-require"><span class="for-a11y">(필수)</span></span></dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="search-form" id="error_wrap_vCompleteDt">
                <div class="search-form__inner">
                  <ap-month-picker
                    v-model:date="regParams.vCompleteDt"
                    @update:date="fnValidate('vCompleteDt')"
                  >
                  </ap-month-picker>
                </div>
                <span class="error-msg" id="error_msg_vCompleteDt"></span>
              </div>
            </dd>
          </dl>
        </div>

        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--120">구분<span class="ui-require"><span class="for-a11y">(필수)</span></span></dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="form-flex">
                <div class="form-flex-cell form-flex__cell--5">
                  <div class="ui-radio__list" id="error_wrap_vFlagNp">
                    <div class="ui-radio__inner">
                      <ap-input-radio
                        v-for="(vo, index) in completeTypeList" :key="'vFlagNp_' + index"
                        v-model:model="regParams.vFlagNp"
                        :value="vo.vSubCode"
                        :label="vo.vSubCodenm"
                        :id="'vFlagNp_' + index"
                        name="vFlagNp"
                        @click="fnChangeFlagNp();fnValidate('vFlagNp');"
                      ></ap-input-radio>
                    </div>
                    <span class="error-msg" id="error_msg_vFlagNp"></span>
                  </div>
                </div>
              </div>
            </dd>
          </dl>
        </div>

        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible" v-if="regParams.contList && regParams.contList.length > 1">
            <dt class="search-bar__key search-bar__width--120">제형<span class="ui-require"><span class="for-a11y">(필수)</span></span></dt>
            <dd class="search-bar__val search-bar__val--flexible" id="error_wrap_vFlagSameShape">
              <div class="form-flex">
                <div class="form-flex-cell form-flex__cell--5">
                  <div class="ui-radio__list">
                    <div class="ui-radio__inner">
                      <ap-input-radio
                        v-for="(vo, index) in [{vSubCode: 'Y', vSubCodenm: '모든 내용물 제형 동일'}, {vSubCode: 'N', vSubCodenm: '제형 동일 X'}]" :key="'vFlagSameShape_' + index"
                        v-model:model="regParams.vFlagSameShape"
                        :value="vo.vSubCode"
                        :label="vo.vSubCodenm"
                        :id="'vFlagSameShape_' + index"
                        name="vFlagSameShape"
                        @click="fnValidate('vFlagSameShape')"
                      ></ap-input-radio>
                    </div>
                  </div>
                </div>
                <div class="form-flex-cell form-flex__cell--5 ml-20" v-if="regParams.vFlagSameShape === 'Y'">
                  <ap-selectbox
                    v-model:value="regParams.vCompleteShape"
                    :input-class="['ui-select__width--200']"
                    :options="codeGroupMaps['LAB_NOTE_SHAPE']"
                    @change="fnValidate('vFlagSameShape')"
                  >
                  </ap-selectbox>
                </div>
              </div>
              <span class="error-msg" id="error_msg_vFlagSameShape"></span>
            </dd>
          </dl>
        </div>

        <table class="ui-table__th--bg-gray mt-15">
          <colgroup>
            <col style="width:14rem;">
            <col style="width:auto">
            <col style="width:14rem;">
            <col style="width:auto">
          </colgroup>
          <tbody>
            <tr>
              <td
                colspan="4"
                class="inside-td"
              >
                <table class="ui-table__contents"
                  :class="idx !== 0 ? 'mt-15' : ''"
                  v-for="(vo, idx) in regParams.contList" :key="'compCont_' + idx"
                >
                  <colgroup>
                    <col style="width:10rem">
                    <col style="width:auto">
                  </colgroup>
                  <tbody>
                    <tr>
                      <td colspan="2" class="t-left">
                        <p class="p_bold">[{{ vo.vContCd }}] [{{ vo.vPlantCd }}] {{ vo.vContNm }}</p>
                      </td>
                    </tr>
                    <tr v-if="regParams.vFlagSameShape !== 'Y'">
                      <th>제형<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
                      <td>
                        <div class="search-form" :id="'error_wrap_vCompleteShape_' + idx">
                          <div class="search-form__inner">
                            <ap-selectbox
                              v-model:value="vo.vCompleteShape"
                              :input-class="['ui-select__width--200']"
                              :options="codeGroupMaps['LAB_NOTE_SHAPE']"
                              @change="fnValidate('vCompleteShape')"
                            >
                            </ap-selectbox>
                          </div>
                          <span class="error-msg" :id="'error_msg_vCompleteShape_' + idx"></span>
                        </div>
                      </td>
                    </tr>
                    <tr v-if="regParams.vFlagNp !== 'S'">
                      <th>카운터</th>
                      <td>
                        <div class="search-form">
                          <div class="search-form__inner">
                            <ap-input
                            v-model:value="vo.vCounterNmTemp"
                            input-class="ui-input__width--450"
                            :readonly="true"
                            @click="fnCounterSearchPop(idx)"
                          >
                          </ap-input>
                          <button type="button" class="button-search" @click="fnCounterSearchPop(idx)">검색</button>
                          <button type="button" class="button-search" @click="removeCounterInfo(idx)">삭제</button>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr v-else>
                      <th>카운터</th>
                      <td>
                        <template v-if="verList && verList.length > 0">
                          <div :id="'error_wrap_vCompleteSsrid_' + idx">
                            <ap-selectbox
                              v-model:value="vo.vCompleteSsrid"
                              :input-class="['ui-select__width--full']"
                              :options="verList"
                              code-key="vVersionKey"
                              code-nm-key="vVersionTxt"
                              @change="fnValidate('vCompleteSsrid')"
                            >
                            </ap-selectbox>
                            <span class="error-msg" :id="'error_msg_vCompleteSsrid_' + idx"></span>
                          </div>
                        </template>
                        <template v-else>
                          * 골격처방을 카운터로 지정한 버전이 없습니다.
                        </template>
                      </td>
                    </tr>
                    <tr>
                      <th>비고</th>
                      <td>
                        <ap-input
                          v-model:value="vo.vCompleteCounterNote"
                          input-class="ui-input__width--full"
                        >
                        </ap-input>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="board-bottom">
        <div class="board-bottom__inner">
          <div class="ui-buttons ml-auto ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--skyblue font-weight__300" @click="fnReleaseCompleteSave()">출시완료</button>
            <button type="button" class="ui-button ui-button__bg--lightgray" @click="closeAsyncPopup({ message: '' })">닫기</button>
          </div>
        </div>
      </div>
    </div>
  </div>
  <teleport to="#common-modal-sub" v-if="popContent">
    <ap-popup>
      <component
        :is="popContent"
        :pop-params="popupParams"
        @selectFunc="popSelectFunc"
        @closeFunc="closeFunc"
      />
    </ap-popup>
  </teleport>
  <div id="common-modal-sub"></div>
</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useSkinRequest } from '@/compositions/skincare/useSkinRequest'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'ReleaseCompletePop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    CompleteCounterSearchPop: defineAsyncComponent(() => import('@/components/labcommon/popup/CompleteCounterSearchPop.vue')),
  },
  emits: ['callbackFunc'],
  setup (props, context) {
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert, openAsyncConfirm, closeAsyncPopup } = useActions(['openAsyncAlert', 'openAsyncConfirm', 'closeAsyncPopup'])
    const popContent = ref(null)
    const popupParams = ref(null)
    const popSelectFunc = ref(null)
    const closeFunc = ref(null)
    const flagType = ref('R')
    let popIdx = null

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const {
      selectReleaseCompleteInfo,
      saveReleaseCompleteInfo,
    } = useSkinRequest()

    const verList = ref([])
    const completeTypeList = [
      {vSubCode: 'Y', vSubCodenm: 'NP'},
      {vSubCode: 'N', vSubCodenm: 'SP'},
      {vSubCode: 'S', vSubCodenm: '골격처방'},
    ]

    const regParams = ref({
      vLabNoteCd: props.popParams.vLabNoteCd || '',
      vCompleteDt: '',
      vFlagNp: 'Y',
      vFlagSameShape: 'Y',
      vCompleteShape: '',
      contList: [],
    })

    const fnChangeFlagNp = () => {
      if (regParams.value.vFlagNp !== 'Y') {
        regParams.value.contList.forEach(item => {
          item.vCounterNmTemp = ''
          item.vCompleteCounterCd = ''

          if (regParams.value.vFlagNp !== 'S') {
            item.vCompleteSsrid = ''
          }
        })
      } else {
        regParams.value.contList.forEach(item => {
          item.vCounterNmTemp = commonUtils.isEmpty(item.vCompleteCounterContNm) ? item.vInitCounterContNm : item.vCompleteCounterContNm
          item.vCompleteCounterCd = commonUtils.isEmpty(item.vCompleteCounterCd) ? item.vCounterContPkCd : item.vCompleteCounterCd
          item.vCompleteSsrid = ''
        })
      }
    }

    const getCounterSearchInfo = (item) => {
      regParams.value.contList[popIdx].vCounterNmTemp = '[' + item.vContCd + '] ' + item.vContNm
      regParams.value.contList[popIdx].vCompleteCounterCd = item.vContPkCd

      popIdx = null
      closeCounterPop()
    }

    const closeCounterPop = () => {
      popContent.value = null
    }

    const fnCounterSearchPop = (idx) => {
      popIdx = idx

      popupParams.value = {
        vFlagNp: regParams.value.vFlagNp,
        vCodeType: props.popParams.vCodeType,
      }

      popSelectFunc.value = getCounterSearchInfo
      closeFunc.value = closeCounterPop
      popContent.value = 'CompleteCounterSearchPop'
    }

    const removeCounterInfo = (idx) => {
      regParams.value.contList[idx].vCounterNmTemp = ''
      regParams.value.contList[idx].vCompleteCounterCd = ''
    }

    const fnValidate = (key) => {
      let isOk = true
      let errorMsg = '필수 입력 사항입니다.'
      commonUtils.hideErrorMessage(key)

      if (key === 'vFlagNp') {
        if (commonUtils.isEmpty(regParams.value.vFlagNp)) {
          isOk = false
        } else if (regParams.value.vFlagNp === 'S' && verList.value.length === 0) {
          errorMsg = '골격처방을 카운터로 지정한 버전이 없습니다. 구분을 다시 선택해 주세요.'
          isOk = false
        }
      } else if (key === 'vCompleteSsrid') {
        if (commonUtils.isNotEmpty(regParams.value.vFlagNp) &&
            regParams.value.vFlagNp === 'S' &&
            verList.value.length > 0
          ) {
          regParams.value.contList.forEach((item, idx) => {
            commonUtils.hideErrorMessage('vCompleteSsrid_' + idx)
            if (commonUtils.isEmpty(item.vCompleteSsrid)) {
              commonUtils.showErrorMessage('vCompleteSsrid_' + idx, errorMsg)
              isOk = false
            }
          })
        }
      } else if (key === 'vFlagSameShape') {
        if (regParams.value.contList.length > 1 && commonUtils.isEmpty(regParams.value.vFlagSameShape)) {
          isOk = false
        } else if (regParams.value.contList.length > 1 &&
          commonUtils.isNotEmpty(regParams.value.vFlagSameShape) &&
          regParams.value.vFlagSameShape === 'Y' &&
          commonUtils.isEmpty(regParams.value.vCompleteShape)
        ) {
          isOk = false
        }
      } else if (key === 'vCompleteShape') {
        if ((commonUtils.isNotEmpty(regParams.value.vFlagSameShape) && regParams.value.vFlagSameShape === 'N')
          || (regParams.value.contList && regParams.value.contList.length === 1)) {
          regParams.value.contList.forEach((item, idx) => {
            commonUtils.hideErrorMessage('vCompleteShape_' + idx)
            if (commonUtils.isEmpty(item.vCompleteShape)) {
              isOk = false
              commonUtils.showErrorMessage('vCompleteShape_' + idx, errorMsg)
            }
          })
        }
      } else if (commonUtils.isEmpty(regParams.value[key])) {
        isOk = false
      }

      if (!isOk) {
        commonUtils.showErrorMessage(key, errorMsg)
      }

      return isOk
    }

    const fnValidateAll = () => {
      let isOk = true
      const arrChkKey = ['vCompleteDt', 'vFlagNp', 'vFlagSameShape', 'vCompleteShape', 'vCompleteSsrid']
      commonUtils.hideErrorMessageAll(arrChkKey)

      arrChkKey.forEach(key => {
        if (!fnValidate(key)) {
          isOk = false
        }
      })

      return isOk
    }

    const fnReleaseCompleteSave = async () => {
      regParams.value.vFlagType = flagType.value
      if (regParams.value.vFlagSameShape === 'Y') {
        regParams.value.contList.forEach(item => {
          item.vCompleteShape = regParams.value.vCompleteShape
        })
      }

      if (!fnValidateAll()) {
        openAsyncAlert({ message: '필수 입력 사항을 확인해 주세요.' })
        return
      }

      if (!await openAsyncConfirm({ message: '해당 실험노트에 대하여 출시 완료를 하시겠습니까?' })) {
        return
      }

      const result = await saveReleaseCompleteInfo(regParams.value)

      if (result === 'SUCC') {
        await openAsyncAlert({ message: '저장 되었습니다.'})
        window.location.reload(true)
      }
    }

    const init = async () => {
      findCodeList(['LAB_NOTE_SHAPE'])

      const payload = {
        vLabNoteCd: props.popParams.vLabNoteCd,
        vCodeType: props.popParams.vCodeType,
      }
      const result = await selectReleaseCompleteInfo(payload)

      if (result) {
        const completeInfo = result.completeInfo
        if (result.contList && result.contList.length > 0) {
          result.contList.forEach(item => {
            if (commonUtils.isNotEmpty(completeInfo) && completeInfo.vFlagNp !== 'S') {
              item.vCounterNmTemp = commonUtils.isEmpty(item.vCompleteCounterContNm) ? item.vInitCounterContNm : item.vCompleteCounterContNm
              item.vCompleteCounterCd = commonUtils.isEmpty(item.vCompleteCounterCd) ? item.vCounterContPkCd : item.vCompleteCounterCd
            } else {
              item.vCompleteSsrid = (item.nCompleteVer || '') + '_' + (item.vCompleteSsrid || '')
            }
          })
          regParams.value.contList = [ ...result.contList ]
          regParams.value.vFlagSameShape = result.contList.length > 1 ? 'Y' : 'N'
        }

        if (completeInfo) {
          flagType.value = 'M'
          regParams.value = { ...regParams.value, ...completeInfo }
        }

        if (result.verList) {
          verList.value = [ ...result.verList ]
        }
      }
    }

    init()

    return {
      verList,
      completeTypeList,
      regParams,
      popContent,
      popSelectFunc,
      closeFunc,
      popupParams,
      codeGroupMaps,
      closeAsyncPopup,
      fnChangeFlagNp,
      fnCounterSearchPop,
      removeCounterInfo,
      fnReleaseCompleteSave,
      fnValidate,
    }
  }
}
</script>

<style scoped>
  .modal-body .ui-table__contents tr td .ui-select { margin-left: inherit; }
</style>