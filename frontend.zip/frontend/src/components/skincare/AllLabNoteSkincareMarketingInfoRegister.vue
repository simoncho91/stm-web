<template>
  <div class="arrordion-item is-active">
    <div class="arrordion-header">
      <div class="arrordion-title">마케팅 정보</div>
      <button type="button" class="ui-button__accordion"></button>
    </div>
    <div class="arrordion-body">
      <div class="basic-info__table">
        <table class="ui-table__contents">
          <colgroup>
            <col style="width:17rem">
            <col style="width:auto">
            <col style="width:17rem">
            <col style="width:auto">
          </colgroup>
          <tbody>
            <tr>
              <th>소비자가격/실제품용량</th>
              <td colspan="3">
                <div class="form-flex">
                  <div class="ui-select-box form-flex__cell--5">
                    <ap-input
                      v-model:value="regParams.nPrice"
                      :is-comma="true"
                      :is-number="true"
                      input-class="ui-input__width--150"
                    >
                    </ap-input>
                  </div>
                  <div class="ui-select-box form-flex__cell--5">
                    원 / 
                  </div>
                  <div class="ui-select-box form-flex__cell--5">
                    <ap-input
                      v-model:value="regParams.nProductCapacity"
                      :is-comma="true"
                      :is-number="true"
                      input-class="ui-input__width--150"
                    >
                    </ap-input>
                  </div>
                  <div class="ui-select-box form-flex__cell--5">
                    <div class="ui-radio__list">
                      <div class="ui-radio__inner">
                        <ap-input-radio
                          v-for="(vo, index) in codeGroupMaps['LNC03']" :key="'unit_' + index"
                          v-model:model="regParams.vProductCapacityCd"
                          :value="vo.vSubCode"
                          :label="vo.vSubCodenm"
                          :id="'unit_' + index"
                          name="unit"
                        ></ap-input-radio>
                      </div>
                    </div>
                  </div>
                </div>
              </td>
            </tr>
            <tr>
              <th>타겟 Cost/100g</th>
              <td>
                <div class="form-flex">
                  <div class="ui-select-box form-flex__cell--5" id="error_wrap_nTargetCost">
                    <ap-input
                      v-model:value="regParams.nTargetCost"
                      :is-comma="true"
                      :is-number="true"
                      input-class="ui-input__width--150"
                    >
                    </ap-input>
                    <span class="error-msg" id="error_msg_nTargetCost"></span>
                  </div>
                  <div class="ui-select-box form-flex__cell--5">
                    원
                  </div>
                </div>
              </td>
              <th>고객조사 시점</th>
              <td>
                <ap-month-picker
                  v-model:value="regParams.vCustResearchDt"
                  input-class="div_width--200"
                >
                </ap-month-picker>
              </td>
            </tr>
            <tr>
              <th>안심감요소</th>
              <td colspan="3">
                <div class="form-flex">
                  <div class="ui-checkbox__list form-flex__cell--5">
                    <div class="ui-checkbox__inner">
                      <ap-input-check
                        v-for="(vo, index) in regParams.reqEtcList" :key="'reqEtc_' + index"
                        v-model:model="vo.vTag2Cd"
                        :value="vo.vSubCode"
                        :label="vo.vSubCodenm"
                        :id="'reqEtc_' + index"
                      >
                      </ap-input-check>
                    </div>
                  </div>
                  <!-- LNC13_99일 때-->
                  <template v-for="(vo, index) in regParams.reqEtcList" :key="'reqEtc_' + index">
                    <div
                      class="ui-select-box form-flex__cell--5"
                      v-if="vo.vTag2Cd === 'LNC13_99'"
                    >
                      <ap-input
                        v-model:value="vo.vTagBuffer2"
                      >
                      </ap-input>
                    </div>
                  </template>
                </div>
              </td>
            </tr>
            <tr>
              <th>효능 임상</th>
              <td colspan="3">
                <div class="ui-checkbox__list pt-10 pb-10">
                  <div class="ui-checkbox__inner">
                    <ap-input-check
                      v-for="(vo, index) in regParams.effectList" :key="'effect_' + index"
                      v-model:model="vo.vTag2Cd"
                      :value="vo.vSubCode"
                      :label="vo.vSubCodenm + (vo.vContent2 ? ' (' + vo.vContent2 + ')' : '')"
                      :id="'effect_' + index"
                    >
                    </ap-input-check>
                    <!-- LNC15_99일 때-->
                    <template v-for="(vo, index) in regParams.effectList" :key="'effectEtc_' + index">
                      <div
                        class="ui-select-box"
                        v-if="vo.vTag2Cd === 'LNC15_99'"
                      >
                        <ap-input
                          v-model:value="vo.vTagBuffer2"
                        >
                        </ap-input>
                      </div>
                    </template>
                  </div>
                </div>
              </td>
            </tr>
            <tr v-if="regParams.effectList.length > 0 && regParams.effectList.filter(vo => commonUtils.isNotEmpty(vo.vTag2Cd)).length > 0">
              <td colspan="4" class="inside-td">
                <table class="ui-table__contents">
                  <colgroup>
                    <col style="width:14rem">
                  </colgroup>
                  <tbody>
                    <tr>
                      <th>시험기간</th>
                      <td>
                        <div class="form-flex">
                          <div class="ui-select-box ui-form-box__width--200  form-flex__cell--5">
                            <ap-input
                              input-class="ui-input ui-input__width--full"
                              :is-number="true"
                              v-model:value="regParams.nEffTestDcnt"
                            >
                            </ap-input>
                          </div>
                          <div class="ui-select-box ui-form-box__width--200  form-flex__cell--5">
                            <ap-selectbox
                              v-model:value="regParams.vEffTestDcntUnit"
                              input-class="ui-select__width--full"
                              :options="codeGroupMaps['LNC18']"
                            >
                            </ap-selectbox>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <th>소구문구 입력</th>
                      <td>
                        <ap-input
                          input-class="ui-input ui-input__width--full"
                          :maxlength="1000"
                          v-model:value="regParams.vEffTestSogooMemo"
                        >
                        </ap-input>
                      </td>
                    </tr>
                    <tr>
                      <th>임상 진행기관</th>
                      <td>
                        <div class="ui-radio__list">
                          <div class="ui-radio__inner">
                            <ap-input-radio
                              v-for="(vo, index) in codeGroupMaps['LNC16']" :key="'effectComp_' + index"
                              v-model:model="regParams.vEffCompTypeCd"
                              :value="vo.vSubCode"
                              :label="vo.vSubCodenm"
                              :id="'effectComp_' + index"
                              name="effectComp"
                            >
                            </ap-input-radio>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <th>임상 시작시점</th>
                      <td>
                        <ap-month-picker
                          v-model:date="regParams.vEffTestItemDt"
                          input-class="div_width--200"
                        >
                        </ap-month-picker>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
            <tr>
              <th>안전성 임상</th>
              <td colspan="3">
                <div class="ui-checkbox__list pt-10 pb-10">
                  <div class="ui-checkbox__inner">
                    <ap-input-check
                      v-for="(vo, index) in regParams.mti01List" :key="'testitem_' + index"
                      v-model:model="vo.vTag2Cd"
                      :value="vo.vSubCode"
                      :label="vo.vSubCodenm + (vo.vContent2 ? ' (' + vo.vContent2 + ')' : '')"
                      :id="'testitem_' + index"
                    >
                    </ap-input-check>
                    <!-- MTI01_07일 때 -->
                    <template v-for="(vo, index) in regParams.mti01List" :key="'testItemEtc_' + index">
                    <div
                      class="ui-select-box form-flex__cell--5"
                      v-if="vo.vTag2Cd === 'MTI01_07'"
                    >
                      <ap-input
                        v-model:value="vo.vTagBuffer2"
                      >
                      </ap-input>
                    </div>
                  </template>
                  </div>
                </div>
              </td>
            </tr>
            <tr v-if="regParams.mti01List.length > 0 && regParams.mti01List.filter(vo => commonUtils.isNotEmpty(vo.vTag2Cd)).length > 0">
              <td colspan="4" class="inside-td">
                <table class="ui-table__contents">
                  <colgroup>
                    <col style="width:14rem">
                  </colgroup>
                  <tbody>
                    <tr>
                      <th>임상 시작시점</th>
                      <td>
                        <ap-month-picker
                          v-model:date="regParams.vTestItemDt"
                          input-class="div_width--200"
                        >
                        </ap-month-picker>
                        <!-- 논코메도제닉 (8주), 하이포알러제닉 (12주), 안과 (8주) -->
                        <template v-if="regParams.mti01List.filter(vo => vo.vTag2Cd !== '' && 'MTI01_02,MTI01_03,MTI01_04'.indexOf(vo.vTag2Cd) > -1).length > 0">
                          <p class="p_caution">
                            ※ "임상심의"를 파일럿 D-1 개월까지 완료
                          </p>
                        </template>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
            <tr>
              <th>ONE POINT (고객관점)</th>
              <td colspan="3">
                <ap-input
                  v-model:value="regParams.vOnePoint"
                  :maxlength="200"
                >
                </ap-input>
              </td>
            </tr>
            <tr>
              <th>사용 고객</th>
              <td colspan="3">
                <div class="ui-checkbox__list">
                  <div class="ui-checkbox__inner">
                    <ap-input-check
                      value="Y"
                      label="전체"
                      id="usecstm_all"
                      v-model:model="useCstmAll"
                      @click="fnUseCstmCheckAllEvent"
                    >
                    </ap-input-check>
                    <ap-input-check
                      v-for="(vo, index) in regParams.tuserList" :key="'usecstm_' + index"
                      v-model:model="vo.vTag2Cd"
                      :value="vo.vSubCode"
                      :label="vo.vSubCodenm"
                      :id="'usecstm_' + index"
                      @click="fnUseCstmCheckEvent"
                    >
                    </ap-input-check>
                  </div>
                </div>
              </td>
            </tr>
            <tr>
              <th>타겟 고객</th>
              <td colspan="3">
                <ap-input
                  v-model:value="regParams.vTargetCustomer"
                  :maxlength="200"
                >
                </ap-input>
              </td>
            </tr>
          </tbody>
        </table>

        <!-- 무소구 -->
        <NotAddIngredientRegister
          ref="notAdd"
          v-model:vFlagNotAdd="regParams.vFlagNotAdd"
          v-model:vNotAddNote="regParams.vNotAddNote"
        >
        </NotAddIngredientRegister>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, inject, watch } from 'vue'
import { useCode } from '@/compositions/useCode'
export default {
  name: 'AllLabNoteSkincareMarketingInfoRegister',
  components: {
    NotAddIngredientRegister: defineAsyncComponent(() => import('@/components/labcommon/NotAddIngredientRegister.vue')),
  },
  setup () {
    const t = inject('t')
    const reqInfo = inject('reqInfo')
    const notAdd = ref(null)
    const useCstmAll = ref('')
    const commonUtils = inject('commonUtils')
    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const regParams = ref({
      nPrice: '',
      nProductCapacity: '',
      vProductCapacityCd: '',
      nTargetCost: '',
      nCapacity: '100',
      vCapacityCd: 'LNC03_01',
      reqEtcList: [],
      effectList: [],
      nEffTestDcnt: '',
      vEffTestDcntUnit: '',
      vEffTestSogooMemo: '',
      vEffCompTypeCd: '',
      vEffTestItemDt: '',
      mti01List: [],
      vTestItemDt: '',
      vOnePoint: '',
      tuserList: [],
      vTargetCustomer: '',
      vFlagNotAdd: '',
      vNotAddNote: '',
    })

    const fnUseCstmCheckAllEvent = (value) => {
      if (value === 'Y') {
        regParams.value.tuserList.forEach((item, idx) => {
          item.vTag2Cd = item.vSubCode
          document.querySelector('#usecstm_' + idx).checked = true
        })
      } else {
        regParams.value.tuserList.forEach((item, idx) => {
          item.vTag2Cd = ''
          document.querySelector('#usecstm_' + idx).checked = false
        })
      }
    }

    const fnUseCstmCheckEvent = () => {
      const checkedLen = regParams.value.tuserList.filter(item => commonUtils.isNotEmpty(item.vTag2Cd)).length
      if (regParams.value.tuserList.length === checkedLen) {
        useCstmAll.value = 'Y'
        document.querySelector('#usecstm_all').checked = true
      } else {
        useCstmAll.value = ''
        document.querySelector('#usecstm_all').checked = false
      }
    }

    const fnValidateAll = (arrChkKey) => {
      let isOk = true
      commonUtils.hideErrorMessageAll(arrChkKey)

      arrChkKey.forEach(key => {
        if (!fnValidate(key)) {
          isOk = false
        }
      })

      return isOk
    }

    const fnValidate = (key) => {
      let isOk = true
      let errorMsg = '필수 입력 사항입니다.'
      commonUtils.hideErrorMessage(key)

      if (key === 'vNotAddNote') {
        if (notAdd.value && !notAdd.value.notAddNoteCheckByte()) {
          isOk = false
          errorMsg = t('common.msg.byte_msg2', { byteSize: 300 })
        }
      } else if (commonUtils.isEmpty(regParams.value[key])) {
        isOk = false
      }

      if (!isOk) {
        commonUtils.showErrorMessage(key, errorMsg)
      }

      return isOk
    }

    const init = async () => {
      const arrMstCode = [
        'LNC03', 'LNC18', 'LNC16'
      ]
      await findCodeList(arrMstCode)
    }

    init()

    watch(() => reqInfo.value, (newValue) => {
      regParams.value = {...regParams.value, ...{
        nPrice: newValue.nPrice,
        nProductCapacity: newValue.nProductCapacity,
        vProductCapacityCd: newValue.vProductCapacityCd,
        nTargetCost: newValue.nTargetCost,
        reqEtcList: newValue.reqEtcList,
        effectList: newValue.effectList,
        mti01List: newValue.mti01List,
        tuserList: newValue.tuserList,
        nEffTestDcnt: newValue.effTestDcnt,
        vEffTestDcntUnit: newValue.vEffTestDcntUnit,
        vEffTestSogooMemo: newValue.vEffTestSogooMemo,
        vEffCompTypeCd: newValue.vEffCompTypeCd,
        vEffTestItemDt: newValue.vEffTestItemDt,
        vTestItemDt: newValue.vTestItemDt,
        vOnePoint: newValue.vOnePoint,
        vTargetCustomer: newValue.vTargetCustomer,
        vFlagNotAdd: newValue.vFlagNotAdd,
        vNotAddNote: newValue.vNotAddNote
      } }
    })

    return {
      notAdd,
      codeGroupMaps,
      regParams,
      commonUtils,
      useCstmAll,
      fnUseCstmCheckAllEvent,
      fnUseCstmCheckEvent,
      fnValidateAll,
      fnValidate,
    }
  }
}
</script>