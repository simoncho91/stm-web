<template>
  <div class="note-table">
    <div class="note-table__inner">
      <table class="ui-table ui-table__td--40 text-center">
        <colgroup>
          <col style="width: 10.3%" />
          <col style="width: 9%" />
          <col style="width: 9%" />
          <col style="width: auto" />
          <col style="width: 9%" />
          <col style="width: 9%" />
          <col style="width: 9%" />
          <col style="width: 9%" />
          <col style="width: 3.5rem" v-if="!commonUtils.checkAuth('S000333')"/>
          <col style="width: 6rem" />
        </colgroup>
        <thead>
          <tr>
            <th>상태</th>
            <th>
              내용물코드
              <button type="button"
                v-if="sortCol !== 'TBL.V_CONT_CD' || (sortCol === 'TBL.V_CONT_CD' && sortDir === 'DESC')"
                class="sort__btn sort__asc"
                @click="fnSort('TBL.V_CONT_CD', 'ASC')">
              </button>
              <button type="button"
                v-if="sortCol !== 'TBL.V_CONT_CD' || (sortCol === 'TBL.V_CONT_CD' && sortDir === 'ASC')"
                class="sort__btn sort__desc"
                @click="fnSort('TBL.V_CONT_CD', 'DESC')">
              </button>
            </th>
            <th>브랜드</th>
            <th>
              내용물명
              <button type="button"
                v-if="sortCol !== 'TBL.V_CONT_NM' || (sortCol === 'TBL.V_CONT_NM' && sortDir === 'DESC')"
                class="sort__btn sort__asc"
                @click="fnSort('TBL.V_CONT_NM', 'ASC')">
              </button>
              <button type="button"
                v-if="sortCol !== 'TBL.V_CONT_NM' || (sortCol === 'TBL.V_CONT_NM' && sortDir === 'ASC')"
                class="sort__btn sort__desc"
                @click="fnSort('TBL.V_CONT_NM', 'DESC')">
              </button>
            </th>
            <th>
              연구담당자
              <button type="button"
                v-if="sortCol !== 'TBL.V_USERNM' || (sortCol === 'TBL.V_USERNM' && sortDir === 'DESC')"
                class="sort__btn sort__asc"
                @click="fnSort('TBL.V_USERNM', 'ASC')">
              </button>
              <button type="button"
                v-if="sortCol !== 'TBL.V_USERNM' || (sortCol === 'TBL.V_USERNM' && sortDir === 'ASC')"
                class="sort__btn sort__desc"
                @click="fnSort('TBL.V_USERNM', 'DESC')">
              </button>
            </th>
            <th>
              생성일
              <button type="button"
                v-if="sortCol !== 'TBL.V_REG_DTM' || (sortCol === 'TBL.V_REG_DTM' && sortDir === 'DESC')"
                class="sort__btn sort__asc"
                @click="fnSort('TBL.V_REG_DTM', 'ASC')">
              </button>
              <button type="button"
                v-if="sortCol !== 'TBL.V_REG_DTM' || (sortCol === 'TBL.V_REG_DTM' && sortDir === 'ASC')"
                class="sort__btn sort__desc"
                @click="fnSort('TBL.V_REG_DTM', 'DESC')">
              </button>
            </th>
            <th>
              파일럿시기
              <button type="button"
                v-if="sortCol !== 'TBL.V_PILOT_DT' || (sortCol === 'TBL.V_PILOT_DT' && sortDir === 'DESC')"
                class="sort__btn sort__asc"
                @click="fnSort('TBL.V_PILOT_DT', 'ASC')">
              </button>
              <button type="button"
                v-if="sortCol !== 'TBL.V_PILOT_DT' || (sortCol === 'TBL.V_PILOT_DT' && sortDir === 'ASC')"
                class="sort__btn sort__desc"
                @click="fnSort('TBL.V_PILOT_DT', 'DESC')">
              </button>
            </th>
            <th>
              출시시기
              <button type="button"
                v-if="sortCol !== 'TBL.V_MASS_PROD_DT' || (sortCol === 'TBL.V_MASS_PROD_DT' && sortDir === 'DESC')"
                class="sort__btn sort__asc"
                @click="fnSort('TBL.V_MASS_PROD_DT', 'ASC')">
              </button>
              <button type="button"
                v-if="sortCol !== 'TBL.V_MASS_PROD_DT' || (sortCol === 'TBL.V_MASS_PROD_DT' && sortDir === 'ASC')"
                class="sort__btn sort__desc"
                @click="fnSort('TBL.V_MASS_PROD_DT', 'DESC')">
              </button>
            </th>
            <th v-if="!commonUtils.checkAuth('S000333')">복사</th>
            <th></th>
          </tr>
        </thead>
        <tbody v-if="info.list && info.list.length > 0">
          <template v-for="(vo, index) in info.list" :key="index">
            <tr :class="vo.isOpenStatus ? 'is-active' : ''">
              <td>{{ vo.vStatusNm }}</td>
              <td>{{ vo.vContCd }}</td>
              <td>{{ vo.vBrdNm }}</td>
              <td class="tit">
                <div class="tit__inner">
                  <a href="javascript:void(0)" class="tit-link" @click.prevent="goDetailPage(vo)">
                    {{vo.vContNm}}
                  </a>
                </div>
              </td>
              <td>{{ vo.vUsernm }}</td>
              <td>{{ commonUtils.changeStrDatePattern(vo.vRegDtm) }}</td>
              <td>{{ commonUtils.changeStrDatePattern(vo.vPilotDt) }}</td>
              <td>{{ commonUtils.changeStrDatePattern(vo.vMassProdDt) }}</td>
              <td v-if="!commonUtils.checkAuth('S000333')">
                  <button
                    type="button"
                    class="copy__button--icon copy__button--icon-copy"
                    @click="goCopy(vo.vLabNoteCd)"
                  >
                  </button>
              </td>
              <td>
                <button
                  v-if="vo.vStatusCd !== 'LNC06_01'"
                  type="button"
                  class="ui-button__accordion"
                  @click="fnOpenStatus(vo)"></button>
              </td>
            </tr>
            <tr class="tr-process" :class="vo.isOpenStatus ? 'is-active' : ''">
              <!-- 활성화시 tr-process 옆에 is-active 추가 -->
              <td :colspan="!commonUtils.checkAuth('S000333') ? 10 : 9">
                <NoteProcessBar
                  v-if="vo.progressInfo && vo.progressInfo.length > 0"
                  :progress-info="vo.progressInfo"
                  :is-big="false"
                  :is-show-date="true"
                  :is-cancel="vo.vFlagCancel == 'Y' ? true : false"
                >
                </NoteProcessBar>
              </td>
            </tr>
          </template>
        </tbody>
        <tbody v-else>
          <tr>
            <td :colspan="!commonUtils.checkAuth('S000333') ? 10 : 9">
              <div class="no-result">
                {{ t('common.msg.no_data') }}
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <div class="board-bottom">
    <div class="board-bottom__inner">
      <Pagination :page-info="info.page" @click="onPaging"> </Pagination>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, inject, watch } from 'vue'
import { useSkinRequest } from '@/compositions/skincare/useSkinRequest'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'

export default {
  name: 'AllLabNoteListTable',
  components: {
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
    NoteProcessBar: defineAsyncComponent(() => import('@/components/labcommon/NoteProcessBar.vue')),
  },
  props: {
    resultList: {
      type: Array,
      default: () => {
        return []
      }
    },
    resultPage: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  emits: ['onPaging', 'onSorting'],
  setup(props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const info = ref({
      list: [],
      page: {}
    })

    const sortCol = ref('')
    const sortDir = ref('')

    const {
      goModify,
      goView,
    } = useSkinRequest()

    const {
      selectProgressBar,
    } = useProcessCommon()

    const {
      fnSetRecentLog,
    } = useLabCommon()

    const onPaging = (pg) => {
      context.emit('onPaging', pg)
    }

    const goDetailPage = async (item) => {
      if (commonUtils.isNotEmpty(item.vContCd)) {
        item.vPageType = 'prd'
        await fnSetRecentLog(item)
      }
      sessionStorage.removeItem('searchParamsDashboardSC')
      goView(item.vLabNoteCd)
    }

    const fnOpenStatus = async (item) => {
      item.isOpenStatus = !item.isOpenStatus

      if (item.progressCall !== 'Y') {
        const result = await selectProgressBar({ vLabNoteCd: item.vLabNoteCd })
        
        item.progressInfo = result.progressInfo
        item.vFlagCancel = result.vFlagCancel == undefined ? 'N' : result.vFlagCancel

        item.progressCall = 'Y'
      }
    }

    const fnSort = (vSortCol, vSortDir) => {
      sortCol.value = vSortCol
      sortDir.value = vSortDir

      const sortInfo = {
        vSortCol,
        vSortDir
      }

      context.emit('onSorting', sortInfo)
    }

    const goCopy = (vLabNoteCd) => {
      goModify(vLabNoteCd, 'Y')
    }

    watch(() => props.resultList, (newVal) => {
      info.value.list = newVal
    })

    watch(() => props.resultPage, (newVal) => {
      info.value.page = newVal
    })

    return {
      t,
      commonUtils,
      onPaging,
      goDetailPage,
      fnOpenStatus,
      goCopy,
      fnSort,
      info,
      sortCol,
      sortDir,
    }
  },
}
</script>

<style scoped>
  .material-setting__button { background: transparent; }
</style>
