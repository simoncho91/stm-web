<template>
  <div class="arrordion-item is-active">
    <div class="arrordion-header">
      <div class="arrordion-title">연구원 정보</div>
      <button type="button" class="ui-button__accordion"></button>
    </div>
    <div class="arrordion-body">
      <div class="basic-info__table researcher-information-table">
        <table class="ui-table__contents">
          <colgroup>
            <col style="width:17rem">
            <col style="width:auto">
            <col style="width:17rem">
            <col style="width:auto">
          </colgroup>
          <tbody>
            <tr>
              <th>연구원 코드</th>
              <td colspan="3">
                {{ regParams.vLabContCd }}
              </td>
            </tr>
            <tr>
              <th>연구 담당자</th>
              <td>
                <div class="form-flex form-flex-error" v-if="showChgArea()">
                  <div class="search-form ui-form-box__width--340 ui-form-box__max-width--230">
                    <ap-input
                      v-model:value="regParams.vUsernm"
                      input-class="ui-input__width--full"
                      placeholder="검색어를 입력하세요."
                      :readonly="true"
                      @click="fnUserSearchPop('CHG')"
                    >
                    </ap-input>
                  </div>
                  <button type="button" class="ui-button ui-button__bg--lightgray ml-5" @click="deleteResearcherInfo('CHG')">삭제</button>
                </div>
                <template v-else-if="commonUtils.isNotEmpty(regParams.vUserid)">
                  {{ regParams.vUsernm }} ( {{ regParams.vUserid }} )
                </template>
              </td>
              <th>담당부서</th>
              <td>
                <DeptTree
                  ref="deptTree"
                  v-model:deptcd="regParams.vDeptCd"
                  udeptcd="1"
                />
              </td>
            </tr>
            <tr>
              <th>
                <div class="charge-bms__th">
                  <div class="">담당 BS</div>
                  <div class="charge-bms__button" v-if="showBsmArea()">
                    <button type="button" class="ui-button__plus" v-if="!showBsmSub" @click="showBsmSubEvent()"></button>
                    <button type="button" class="ui-button__minus" v-if="showBsmSub" @click="showBsmSubEvent()"></button>
                  </div>
                </div>
              </th>
              <td>
                <div class="form-flex" v-if="showBsmArea()">
                  <div class="search-form ui-form-box__width--340 ui-form-box__max-width--230">
                    <ap-input
                      v-model:value="regParams.vBsmUsernm"
                      input-class="ui-input__width--full"
                      placeholder="검색어를 입력하세요."
                      :readonly="true"
                      @click="fnUserSearchPop('Bsm')"
                    >
                    </ap-input>
                  </div>
                  <button type="button" class="ui-button ui-button__bg--lightgray ml-5" @click="deleteResearcherInfo('Bsm')">삭제</button>
                </div>
                <template v-else-if="commonUtils.isNotEmpty(regParams.vBsmUserid)">
                  {{ regParams.vBsmUsernm }} ( {{ regParams.vBsmUserid }} / {{ regParams.vBsmDeptnm }} )
                </template>
              </td>
              <th></th>
              <td></td>
            </tr>
            <tr v-if="showBsmSub">
              <td colspan="4" class="inside-td">
                <table class="ui-table__contents">
                  <colgroup>
                    <col style="width:14rem">
                    <col style="width:auto">
                    <col style="width:20rem">
                    <col style="width:auto">
                  </colgroup>
                  <tbody>
                    <tr>
                      <th>담당 BS SUB</th>
                      <td>
                        <div class="form-flex">
                          <div class="search-form ui-form-box__width--340 ui-form-box__max-width--230">
                            <ap-input
                              v-model:value="regParams.vBsmUsernmSub1"
                              input-class="ui-input__width--full"
                              placeholder="검색어를 입력하세요."
                              :readonly="true"
                              @click="fnUserSearchPop('BSMSUB1')"
                            >
                            </ap-input>
                          </div>
                          <button type="button"
                            class="ui-button ui-button__bg--lightgray ml-5" @click="deleteResearcherInfo('BSMSUB1')">삭제</button>
                        </div>
                      </td>
                      <th>담당 BS SUB</th>
                      <td>
                        <div class="form-flex">
                          <div class="search-form ui-form-box__width--340 ui-form-box__max-width--230">
                            <ap-input
                              v-model:value="regParams.vBsmUsernmSub2"
                              input-class="ui-input__width--full"
                              placeholder="검색어를 입력하세요."
                              :readonly="true"
                              @click="fnUserSearchPop('BSMSUB2')"
                            >
                            </ap-input>
                          </div>
                          <button type="button"
                            class="ui-button ui-button__bg--lightgray ml-5" @click="deleteResearcherInfo('BSMSUB2')">삭제</button>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
            <tr>
              <th>브랜드 담당 PM<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td>
                <div class="form-flex form-flex-error">
                  <div class="search-form ui-form-box__width--340 ui-form-box__max-width--230" id="error_wrap_vBrdUserid">
                    <ap-input
                      v-model:value="regParams.vBrdUsernm"
                      input-class="ui-input__width--full"
                      placeholder="검색어를 입력하세요."
                      :readonly="true"
                      @click="fnUserSearchPop('Brd')"
                    >
                    </ap-input>
                    <span class="error-msg" id="error_msg_vBrdUserid"></span>
                  </div>
                  <button type="button" class="ui-button ui-button__bg--lightgray ml-5" @click="deleteResearcherInfo('Brd')">삭제</button>
                </div>
              </td>
              <th>향 담당자<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td>
                <div class="form-flex form-flex-error">
                  <div class="search-form ui-form-box__width--340 ui-form-box__max-width--230" id="error_wrap_vPerfUserid">
                    <ap-input
                      v-model:value="regParams.vPerfUsernm"
                      input-class="ui-input__width--full"
                      placeholder="검색어를 입력하세요."
                      :readonly="true"
                      @click="fnUserSearchPop('Perf')"
                    >
                    </ap-input>
                    <span class="error-msg" id="error_msg_vPerfUserid"></span>
                  </div>
                  <button type="button" class="ui-button ui-button__bg--lightgray ml-5" @click="deleteResearcherInfo('Perf')">삭제</button>
                </div>
              </td>
            </tr>
            <tr colspan="3">
              <th>CTC 담당자<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td>
                <div class="form-flex form-flex-error" v-if="showCtcArea()">
                  <div class="search-form ui-form-box__width--340 ui-form-box__max-width--230" id="error_wrap_vCtcUserid">
                    <ap-input
                      v-model:value="regParams.vCtcUsernm"
                      input-class="ui-input__width--full"
                      placeholder="검색어를 입력하세요."
                      :readonly="true"
                      @click="fnUserSearchPop('Ctc')"
                    >
                    </ap-input>
                    <span class="error-msg" id="error_msg_vCtcUserid"></span>
                  </div>
                  <button type="button" class="ui-button ui-button__bg--lightgray ml-5" @click="deleteResearcherInfo('Ctc')">삭제</button>
                </div>
                <template v-else-if="commonUtils.isNotEmpty(regParams.vCtcUserid)">
                  {{ regParams.vCtcUsernm }} ( {{ regParams.vCtcUserid }} / {{ regParams.vCtcDeptnm }} )
                </template>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @selectFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, ref, inject, watch, computed } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useActions } from 'vuex-composition-helpers'
import { useStore } from 'vuex'

export default {
  name: 'AllLabNoteSkincareResearcherInfoRegister',
  props: {
    flagAction: {
      type: String,
      default: 'R'
    }
  },
  components: {
    DeptTree: defineAsyncComponent(() => import('@/components/comm/DeptTree.vue')),
    UserSearchPop: defineAsyncComponent(() => import('@/components/comm/popup/UserSearchPop.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
  },
  setup (props) {
    const reqInfo = inject('reqInfo')
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert } = useActions(['openAsyncAlert'])
    const store = useStore()
    const myInfo = store.getters.getMyInfo()
    const perfUserInfo = computed(() => store.getters.getPerfUserInfo())
    const deptTree = ref(null)
    const showBsmSub = ref(false)
    let searchFlag = ''

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      fnChangeNoteInfo,
    } = useLabCommon()

    const regParams = ref({
      vLabContCd: '',
      vUserid: '',
      vUsernm: '',
      vDeptCd: '',
      vUsrDeptnm: '',
      vBsmUserid: '',
      vBsmUsernm: '',
      vBsmDeptnm: '',
      vBrdUserid: '',
      vBrdUsernm: '',
      vPerfUserid: '',
      vPerfUsernm: '',
      vCtcUserid: '',
      vCtcUsernm: '',
      vCtcDeptnm: '',
      vBsmUseridSub1: '',
      vBsmUsernmSub1: '',
      vBsmUseridSub2: '',
      vBsmUsernmSub2: '',
      vIsLabNoteAdmin: '',
    })

    const showBsmSubEvent = () => {
      regParams.value.vBsmUseridSub1 = ''
      regParams.value.vBsmUsernmSub1 = ''
      regParams.value.vBsmUseridSub2 = ''
      regParams.value.vBsmUsernmSub2 = ''
      showBsmSub.value = !showBsmSub.value
    }

    const showBsmArea = () => {
      let isVisible = false

      if (props.flagAction === 'R' || regParams.value.vBsmUserid === myInfo.loginId || regParams.value.vIsLabNoteAdmin === 'Y') {
        isVisible = true
      }

      return isVisible
    }

    const showCtcArea = () => {
      let isVisible = false

      if (props.flagAction === 'R' || 
            regParams.value.vBsmUserid === myInfo.loginId || 
            regParams.value.vCtcUserid === myInfo.loginId || 
            regParams.value.vIsLabNoteAdmin === 'Y') {
        isVisible = true
      }

      return isVisible
    }

    const showChgArea = () => {
      let isVisible = false

      if (props.flagAction === 'R' ||
          regParams.value.vCtcUserid === myInfo.loginId ||
          regParams.value.vUserid === myInfo.loginId ||
          regParams.value.vIsLabNoteAdmin === 'Y'
      ) {
        isVisible = true
      }

      return isVisible
    }

    const deleteResearcherInfo = (flag) => {
      if (flag === 'BSMSUB1') {
        regParams.value.vBsmUsernmSub1 = ''
        regParams.value.vBsmUseridSub1 = ''
      } else if (flag === 'BSMSUB2') {
        regParams.value.vBsmUsernmSub2 = ''
        regParams.value.vBsmUseridSub2 = ''
      } else if (flag === 'CHG') {
        regParams.value.vUsernm = ''
        regParams.value.vUserid = ''
        regParams.value.vDeptCd = '10011'
      } else  {
        regParams.value['v' + flag + 'Usernm'] = ''
        regParams.value['v' + flag + 'Userid'] = ''

        fnValidate('v' + flag + 'Userid')
      }
    }

    const fnUserSearchPop = (flag) => {
      searchFlag = flag

      if (flag !== 'Brd') {
        popParams.value.searchFlag = 'LAB'
        popParams.value.vDeptCd = '10011'
      } else {
        popParams.value.searchFlag = 'ALL'
        popParams.value.vDeptCd = ''
      }
      popSelectFunc.value = getUserSearchInfo
      fnOpenPopup('UserSearchPop')
    }

    const getUserSearchInfo = (item) => {
      if (searchFlag === 'BSMSUB1') {
        regParams.value.vBsmUsernmSub1 = item.vUsernm
        regParams.value.vBsmUseridSub1 = item.vUserid
      } else if (searchFlag === 'BSMSUB2') {
        regParams.value.vBsmUsernmSub2 = item.vUsernm
        regParams.value.vBsmUseridSub2 = item.vUserid
      } else if (searchFlag === 'CHG') {
        const labor = item.vLabor

        if (commonUtils.isNotEmpty(labor)) {
          regParams.value.vUsernm = item.vUsernm
          regParams.value.vUserid = item.vUserid
          regParams.value.vDeptCd = item.vSigmaDeptcd

          const noteInfo = store.getters.getNoteInfo()
          const newInfo = { ...noteInfo, ...{ vUserid: item.vUserid, vDeptCd: item.vSigmaDeptcd } }

          fnChangeNoteInfo(newInfo)
        } else {
          openAsyncAlert({ message: 'SAP 연구원코드가 존재하지 않습니다.<br>다른 연구원을 지정해주시기 바랍니다.' })
          regParams.value.vUsernm = ''
          regParams.value.vUserid = ''
          regParams.value.vDeptCd = '10011'
        }

        fnValidate('vUserid')
      } else {
        regParams.value['v' + searchFlag + 'Usernm'] = item.vUsernm
        regParams.value['v' + searchFlag + 'Userid'] = item.vUserid

        fnValidate('v' + searchFlag + 'Userid')
      }
    }

    const fnValidateAll = (arrChkKey) => {
      let isOk = true
      commonUtils.hideErrorMessageAll(arrChkKey)

      arrChkKey.forEach(key => {
        if (!fnValidate(key)) {
          isOk = false
        }
      })

      return isOk
    }

    const fnValidate = (key) => {
      let isOk = true
      let errorMsg = '필수 입력 사항입니다.'
      commonUtils.hideErrorMessage(key)

      if (commonUtils.isEmpty(regParams.value[key])) {
        isOk = false
      }

      if (!isOk) {
        commonUtils.showErrorMessage(key, errorMsg)
      }

      return isOk
    }

    watch(() => reqInfo.value, (newValue) => {
      if (commonUtils.isEmpty(newValue.vDeptCd)) {
        newValue.vDeptCd = '10011'
      }

      regParams.value = { ...regParams.value, ...{
        vLabNoteCd: newValue.vLabNoteCd,
        vUserid: newValue.vUserid,
        vUsernm: newValue.vUsernm,
        vDeptCd: newValue.vDeptCd,
        vUsrDeptnm: newValue.vUsrDeptnm,
        vBsmUserid: newValue.vBsmUserid || myInfo.loginId,
        vBsmUsernm: newValue.vBsmUsernm || myInfo.userNm,
        vBsmDeptnm: newValue.vBsmDeptnm,
        vBrdUserid: newValue.vBrdUserid,
        vBrdUsernm: newValue.vBrdUsernm,
        vPerfUserid: newValue.vPerfUserid,
        vPerfUsernm: newValue.vPerfUsernm,
        vPerfDeptnm: newValue.vPerfDeptnm,
        vCtcUserid: newValue.vCtcUserid,
        vCtcUsernm: newValue.vCtcUsernm,
        vCtcDeptnm: newValue.vCtcDeptnm,
        vBsmUseridSub1: newValue.vBsmUseridSub1,
        vBsmUsernmSub1: newValue.vBsmUsernmSub1,
        vBsmDeptnmSub1: newValue.vBsmDeptnmSub1,
        vBsmUseridSub2: newValue.vBsmUseridSub2,
        vBsmUsernmSub2: newValue.vBsmUsernmSub2,
        vBsmDeptnmSub2: newValue.vBsmDeptnmSub2,
        vIsLabNoteAdmin: newValue.vIsLabNoteAdmin,
      } }
    })

    watch(() => perfUserInfo.value, (newValue) => {
      if (commonUtils.isNotEmpty(newValue)) {
        const perfUserid = perfUserInfo.value.split('/')[0]
        const perfUsernm = perfUserInfo.value.split('/')[1]
        regParams.value.vPerfUserid = perfUserid
        regParams.value.vPerfUsernm = perfUsernm
        fnValidate('vPerfUserid')
      } else {
        regParams.value.vPerfUserid = ''
        regParams.value.vPerfUsernm = ''
      }
    })

    return {
      popupContent,
      popParams,
      popSelectFunc,
      showBsmSub,
      regParams,
      showBsmSubEvent,
      showBsmArea,
      showCtcArea,
      showChgArea,
      deleteResearcherInfo,
      fnUserSearchPop,
      commonUtils,
      myInfo,
      deptTree,
      fnValidateAll,
      fnValidate,
    }
  }
}
</script>