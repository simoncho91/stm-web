<template>
  <div class="wrap">
    <header-template></header-template>
    <div class="ui-layout">
      <div class="ui-layout__inner">
        <!-- [START] left 메뉴 영역 -->
          <div class="left-menu is-open">
            <div class="left-menu__inner">
              <button type="button" class="left-menu__button"><i class="left-menu__button--icon"></i></button>
              <div class="left-menu__box">
                <!-- 전달사항 :: 클릭시 .left-menu__list에 is-active 붙여주세요. -->
                <div class="left-menu__item left-menu__item--repeat">
                  <left-menu></left-menu>
                </div>
              </div>
              <div class="left-menu__copyright">© Amorepacific Corp.</div>
            </div>
          </div>
        <!-- [END] left 메뉴 영역 -->
        <div class="contents">
          <div class="contents__inner">
            <router-view></router-view>
          </div>
        </div>
        <!-- [START] right 메뉴 영역 -->
        <!-- [END] right 메뉴 영역 -->
      </div>
    </div>
    
    <footer-template></footer-template>
    <teleport to="#common-modal">
      <ap-alert ref="modal"></ap-alert>
    </teleport>
  </div>
</template>

<script>
import HeaderTemplate from '@/components/comm/HeaderTemplate.vue'
import FooterTemplate from '@/components/comm/FooterTemplate.vue'
import LeftMenu from '@/components/comm/LeftMenu.vue'

export default {
  name: 'LayoutContentType',
  components: {
    HeaderTemplate,
    FooterTemplate,
    LeftMenu
  },
  setup() {
    return {
    }
  },
}
</script>