<template>
  <header-template></header-template>
  <router-view></router-view>
  <teleport to="#common-modal">
    <ap-alert ref="modal"></ap-alert>
  </teleport>
  <footer-template></footer-template>
</template>

<script>
import HeaderTemplate from '@/components/comm/HeaderTemplate.vue'
import FooterTemplate from '@/components/comm/FooterTemplate.vue'

export default {
  name: 'LayoutError',
  components: {
    HeaderTemplate: HeaderTemplate,
    FooterTemplate: FooterTemplate
  },
  setup() {
    return {}
  },
}
</script>
