<template>
  <router-view></router-view>
</template>

<script>
//import FooterTemplate from '@/components/comm/FooterTemplate.vue'

export default {
  name: 'LayoutBlank',
  // components: {
  //   FooterTemplate: FooterTemplate
  // },
  setup() {
    return {}
  },
}
</script>