<template>
  <div class="wrap wrap-common">
    <div class="ui-layout ui-layout__common">
      <div class="ui-layout__inner">
        <router-view></router-view>
      </div>
    </div>
    <teleport to="#common-modal">
      <ap-alert ref="modal"></ap-alert>
    </teleport>
  </div>
</template>

<script>
//import FooterTemplate from '@/components/comm/FooterTemplate.vue'

export default {
  name: 'LayoutBlank',
  // components: {
  //   FooterTemplate: FooterTemplate
  // },
  setup() {
    return {}
  },
}
</script>
