<template>
  <div class="wrap">
    <header-template></header-template>
    <div class="ui-layout">
      <div class="ui-layout__inner">
        <!-- [START] left 메뉴 영역 -->
        <left-menu-detail></left-menu-detail>
        <!-- [END] left 메뉴 영역 -->
        <div class="contents">
          <div class="contents__inner">
            <router-view></router-view>
          </div>
        </div>
        <!-- [START] left 메뉴 영역 -->
        <right-menu v-if="showRightMenu()"></right-menu>
        <!-- [END] left 메뉴 영역 -->
      </div>
    </div>
    
    <footer-template></footer-template>
    <teleport to="#common-modal">
      <ap-alert ref="modal"></ap-alert>
    </teleport>
  </div>
</template>

<script>
import { computed, inject } from 'vue'
import { useStore } from 'vuex'
import HeaderTemplate from '@/components/comm/HeaderTemplate.vue'
import FooterTemplate from '@/components/comm/FooterTemplate.vue'
import LeftMenuDetail from '@/components/comm/LeftMenuDetail.vue'
import RightMenu from '@/components/comm/RightMenu.vue'

export default {
  name: 'LayoutDetail',
  components: {
    HeaderTemplate,
    FooterTemplate,
    LeftMenuDetail,
    RightMenu,
  },
  setup() {
    const store = useStore()
    const noteInfo = computed(() => store.getters.getNoteInfo())
    const myInfo = store.getters.getMyInfo()
    const commonUtils = inject('commonUtils')

    const showRightMenu = () => {
      let isVisible = false
      if (noteInfo.value &&
          (noteInfo.value.vUserid === myInfo.loginId
           || noteInfo.value.vCtcUserid === myInfo.loginId
           || noteInfo.value.vSlUserid === myInfo.loginId
           || noteInfo.value.vBrdUserid === myInfo.loginId
           || noteInfo.value.vBsmUserid === myInfo.loginId
           || noteInfo.value.vBsmUseridSub1 === myInfo.loginId
           || noteInfo.value.vBsmUseridSub2 === myInfo.loginId
           || noteInfo.value.vFlagContUserYn === 'Y'
           || commonUtils.checkAuth('S000000'))) {
        isVisible = true
      }

      return isVisible
    }

    return {
      showRightMenu,
    }
  },
}
</script>
