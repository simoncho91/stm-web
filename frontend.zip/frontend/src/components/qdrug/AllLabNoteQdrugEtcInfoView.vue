<template>
  <div class="contents-box__tab mt-15">
    <ApTab
        mst-id="etcInfoTab"
        :tab-list="etcTabList"
        :tab-style="['contents-box__tab--inner', 'contents-box__tab--list', 'contents-box__tab--item', 'contents-box__tab--link']"
        :default-tab="selectTab"
        @click="getSelectedTabEvent"
      >
      </ApTab>
      <div class="contents-box__inner min-height__unset" id="etcTab01" v-show="selectTab === 'etcTab01'">
        <div class="note-table__inner">
          <table class="ui-table ui-table__td--40 text-center">
            <colgroup>
              <col style="width:15rem;">
              <col style="width:20rem;">
              <col style="width:15rem;">
              <col style="width:50rem;">
            </colgroup>
            <thead>
              <tr>
                <th>실험노트 구분</th>
                <th>내용물 코드</th>
                <th>버전</th>
                <th>내용물명 / 과제명</th>
              </tr>
            </thead>
            <tbody>
              <template v-if="counterList && counterList.length > 0">
                <tr v-for="(vo, idx) in counterList" :key="'counter_' + idx">
                  <td>{{ vo.vLabTypeNm }}</td>
                  <td>
                    <router-link class="a-deco-none" :to="{ path: goCounterDetail(vo), query: {vLabNoteCd: vo.vLabNoteCd }}" target="_blank">
                      {{ vo.vContCd }}
                    </router-link>
                  </td>
                  <td>
                    <router-link class="a-deco-none" :to="{ path: goCounterDetail(vo), query: {vLabNoteCd: vo.vLabNoteCd }}" target="_blank">
                      {{ vo.vVersionNm }}
                    </router-link>
                  </td>
                  <td>
                    <router-link class="a-deco-none" :to="{ path: goCounterDetail(vo), query: {vLabNoteCd: vo.vLabNoteCd }}" target="_blank">
                      {{ vo.vContNm }}
                    </router-link>
                  </td>
                </tr>
              </template>
              <template v-else>
                <tr>
                  <td colspan="4">
                    <div class="no-result">
                      {{ t('common.msg.no_data') }}
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>
      <template v-if="completeInfo.vStatusCd === 'LNC06_50'">
        <div class="contents-box__inner min-height__unset" id="etcTab02" v-show="selectTab === 'etcTab02'">
          <table class="ui-table__th--bg-gray">
            <colgroup>
              <col style="width:14rem;">
              <col style="width:auto">
              <col style="width:14rem;">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr>
                <th>출시 완료일</th>
                <td>{{ commonUtils.changeStrDatePattern(completeInfo.vCompleteDt) }}</td>
              </tr>
              <tr>
                <td
                  colspan="4"
                  class="inside-td"
                >
                  <table class="ui-table__contents"
                    :class="idx !== 0 ? 'mt-15' : ''"
                    v-for="(vo, idx) in completeInfo.compContList" :key="'compCont_' + idx"
                  >
                    <colgroup>
                      <col style="width:10rem">
                      <col style="width:auto">
                    </colgroup>
                    <tbody>
                      <tr>
                        <td colspan="2">
                          <p class="p_bold">[{{ vo.vContCd }}] [{{ vo.vPlantCd }}] {{ vo.vContNm }}</p>
                        </td>
                      </tr>
                      <tr>
                        <th>제형</th>
                        <td>
                          {{ vo.vCompleteShapeNm }}
                        </td>
                      </tr>
                      <tr>
                        <th>카운터</th>
                        <td>
                          {{ vo.vCompleteCounterContNm }}
                        </td>
                      </tr>
                      <tr>
                        <th>비고</th>
                        <td>
                          {{ vo.vCompleteCounterNote }}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </template>
  </div>
</template>

<script>
import { ref, reactive, defineAsyncComponent, inject, watch } from 'vue'

export default {
  name: 'AllLabNoteSkincareEtcInfoView',
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
  },
  setup (props) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const reqInfo = inject('reqInfo')
    const etcTabList = ref([])
    const counterList = ref([])
    const completeInfo = reactive({
      vCompleteDt: '',
      vFlagNp: '',
      vFlagNpNm: '',
      compContList: [],
      vStatusCd: ''
    })
    const selectTab = ref('etcTab01')
    const getSelectedTabEvent = (item) => {
      selectTab.value = item.tabId
    }

    const goCounterDetail = (item) => {

      const labTypeCd = item.vLabTypeCd === 'LNC07_01' ? 'prd' : (item.vLabTypeCd === 'LNC07_02' ? 'half' : 'nonprd')

      return `/qdrug/all-lab-note-${labTypeCd}-view`
    }

    const init = () => {
      const counterLen = reqInfo.value.counterList ? reqInfo.value.counterList.length : 0
      etcTabList.value = [
        { tabId: 'etcTab01', tabNm: '해당 내용물을 카운터로 사용한 내용물 (' + counterLen +')'}
      ]

      completeInfo.vStatusCd = reqInfo.value.vStatusCd
      if (reqInfo.value.vStatusCd === 'LNC06_50') {
        etcTabList.value.push({ tabId: 'etcTab02', tabNm: '출시 완료 정보' })

        completeInfo.vCompleteDt = reqInfo.value.vCompleteDt
        completeInfo.compContList = reqInfo.value.compContList
      }

      counterList.value = [ ...reqInfo.value.counterList ]
    }

    watch(() => reqInfo.value, (newValue) => {
      if (newValue) {
        init()
      }
    })

    return {
      t,
      commonUtils,
      etcTabList,
      selectTab,
      counterList,
      completeInfo,
      getSelectedTabEvent,
      goCounterDetail,
    }
  }
}
</script>

