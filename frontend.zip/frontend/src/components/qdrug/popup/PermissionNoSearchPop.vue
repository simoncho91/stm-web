<template>
  <div class="modal-content" id="evaluate_pop" style="width: 110rem;">
    <div class="modal-header">
      <div class="modal-title">허가번호 검색</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({message: ''})"></button>
    </div>
    <div class="modal-body">
      <div class="board-top">
        <div class="search-form">
          <div class="search-bar__left">
            <div class="search-bar__row">
              <dl class="search-bar__item">
                <dt class="search-bar__key search-bar__width--120">주성분(한글명)</dt>
                <dd class="search-bar__val">
                  <div class="form-flex">
                    <div class="form-flex-cell form-flex__cell--5">
                      <ap-selectbox
                        v-model:value="searchParams.vSearchPrior"
                        :options="[{vSubCode: 'A', vSubCodenm: 'AND'}, {vSubCode: 'O', vSubCodenm: 'OR'}, {vSubCode: 'N', vSubCodenm: 'NOT'}]"
                      >
                      </ap-selectbox>
                    </div>
                    <div class="form-flex-cell form-flex__cell--5">
                      <div class="search-form">
                        <div class="search-form__inner">
                          <ap-input
                            v-model:value="searchParams.vPriorContent"
                            input-class="ui-input ui-input__width--200"
                          >
                          </ap-input>
                        </div>
                      </div>
                    </div>
                  </div>
                </dd>
                <dt class="search-bar__key search-bar__width--120">최초심사완료연월</dt>
                <dd class="search-bar__val">
                  <div class="form-flex">
                    <div class="form-flex-cell form-flex__cell--5">
                      <ap-month-picker
                        v-model:date="searchParams.vCompDt"
                        :disabled="vCompReset === 'Y'"
                      >
                      </ap-month-picker>
                    </div>
                    <div class="form-flex-cell form-flex__cell--5">
                      <ap-input-check
                        v-model:model="vCompReset"
                        id="vCompReset"
                        value="Y"
                        label="전체"
                        @click="fnCompReset"
                      >
                      </ap-input-check>
                    </div>
                  </div>
                </dd>
              </dl>
            </div>
            <div class="search-bar__row">
              <dl class="search-bar__item">
                <dt class="search-bar__key search-bar__width--120">주성분(한글명)</dt>
                <dd class="search-bar__val">
                  <div class="form-flex">
                    <div class="form-flex-cell form-flex__cell--5">
                      <ap-selectbox
                        v-model:value="searchParams.vSearchPrior2"
                        :options="[{vSubCode: 'A', vSubCodenm: 'AND'}, {vSubCode: 'O', vSubCodenm: 'OR'}, {vSubCode: 'N', vSubCodenm: 'NOT'}]"
                      >
                      </ap-selectbox>
                    </div>
                    <div class="form-flex-cell form-flex__cell--5">
                      <div class="search-form">
                        <div class="search-form__inner">
                          <ap-input
                            v-model:value="searchParams.vPriorContent2"
                            input-class="ui-input ui-input__width--200"
                          >
                          </ap-input>
                        </div>
                      </div>
                    </div>
                  </div>
                </dd>
                <dt class="search-bar__key search-bar__width--120">구분</dt>
                <dd class="search-bar__val reset_filter_area" v-if="codeGroupMaps['QS_TYPE']">
                  <ap-choosebox
                    v-model:modelChkAll="searchParams.vQsTypeAllYn"
                    v-model:model="searchParams.arrQsTypeCd"
                    id="searchQsTypeCd"
                    :options="codeGroupMaps['QS_TYPE'].filter(item => item.vBuffer1 === 'A')"
                  >
                  </ap-choosebox>
                </dd>
              </dl>
            </div>
            <div class="search-bar__row">
              <dl class="search-bar__item">
                <dt class="search-bar__key search-bar__width--120">주성분(SAP명)</dt>
                <dd class="search-bar__val">
                  <div class="form-flex">
                    <div class="form-flex-cell form-flex__cell--5">
                      <ap-selectbox
                        v-model:value="searchParams.vSearchPrior3"
                        :options="[{vSubCode: 'A', vSubCodenm: 'AND'}, {vSubCode: 'O', vSubCodenm: 'OR'}, {vSubCode: 'N', vSubCodenm: 'NOT'}]"
                      >
                      </ap-selectbox>
                    </div>
                    <div class="form-flex-cell form-flex__cell--5">
                      <div class="search-form">
                        <div class="search-form__inner">
                          <ap-input
                            v-model:value="searchParams.vPriorContent3"
                            input-class="ui-input ui-input__width--200"
                          >
                          </ap-input>
                        </div>
                      </div>
                    </div>
                  </div>
                </dd>
                <dt class="search-bar__key search-bar__width--120">유형</dt>
                <dd class="search-bar__val reset_filter_area form-flex" v-if="codeGroupMaps['QS_CLASS']">
                  <ap-choosebox
                    v-model:modelChkAll="searchParams.vQsClassAllYn"
                    v-model:model="searchParams.arrQsClassCd"
                    :options="codeGroupMaps['QS_CLASS']"
                    id="searchQsClassCd"
                    
                  >
                  </ap-choosebox>
                  <button type="button" class="button-search" @click="fnSearch(1)">검색</button>
                </dd>
              </dl>
            </div>
          </div>
        </div>
      </div>

      <div class="ui-table__wrap">
        <table class="ui-table text-center ui-table__td--40">
          <colgroup>
            <col style="width:16rem;">
            <col style="width:auto;">
            <col style="width:20rem;">
            <col style="width:13rem;">
            <col style="width:13rem;">
          </colgroup>
          <thead>
            <tr>
              <th>허가번호</th>
              <th>허가명</th>
              <th>구분</th>
              <th>유형</th>
              <th>최초심사완료일</th>
            </tr>
          </thead>
          <tbody>
            <template v-if="list && list.length > 0">
              <tr v-for="(vo, index) in list" :key="'eval_' + index" @click="fnEvalSelect(vo)">
                <td>{{ vo.vEvaluateno }}</td>
                <td class="t-left">{{ vo.vEvaluateNm }}</td>
                <td>{{ vo.vEvaluateFlagNm }}</td>
                <td>{{ vo.vEvaluateClassNm }}</td>
                <td>{{ commonUtils.changeStrDatePattern(vo.vCompDtm) }}</td>
              </tr>
            </template>
          </tbody>
        </table>
      </div>
    </div>

    <div class="board-bottom">
      <div class="board-bottom__inner board-bottom__with--button">
        <Pagination
          :page-info="page"
          @click="fnSearch"
        >
        </Pagination>
        <div class="ui-buttons ui-buttons__right">
          <button type="button" class="ui-button ui-button__bg--lightgray" @click="closeAsyncPopup({ message: '닫기'})">닫기</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useQdrugRequest } from '@/compositions/qdrug/useQdrugRequest'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'PermissionNoSearchPop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  components: {
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
  },
  emits: ['selectFunc'],
  setup (props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])
    const vCompReset = ref('')
    const searchParams = ref({
      vSearchPrior: 'A',
      vSearchPrior2: 'A',
      vSearchPrior3: 'A',
      vPriorContent: '',
      vPriorContent2: '',
      vPriorContent3: '',
      vCompDt: '',
      vKeyword: '',
      vSearchType: 'ALL',
      vQsTypeAllYn: '',
      vQsClassAllYn: '',
      arrQsTypeCd: [],
      arrQsClassCd: ['QS_CLASS01', 'QS_CLASS06'],
      nowPageNo: 1,
    })

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const {
      list,
      page,
      selectAcceptQsList,
    } = useQdrugRequest()

    const arrMstCode = [
      'EVL01', 'QS_TYPE', 'QS_CLASS'
    ]

    const fnSearch = (pg) => {
      if (!pg) {
        pg = 1
      }
      searchParams.value.nowPageNo = pg

      selectAcceptQsList(searchParams.value)
    }

    const fnEvalSelect = (item) => {
      context.emit('selectFunc', item)
      closeAsyncPopup({ message: '닫기' })
    }

    const fnCompReset = (value) => {
      if (value === 'Y') {
        searchParams.value.vCompDt = ''
      }
    }

    const init = () => {
      findCodeList(arrMstCode)
      fnSearch(1)
    }

    init()

    return {
      t,
      commonUtils,
      list,
      page,
      vCompReset,
      searchParams,
      codeGroupMaps,
      closeAsyncPopup,
      fnSearch,
      fnEvalSelect,
      fnCompReset,
    }
  }
}
</script>

<style scoped>
  tbody tr { cursor: pointer; }
  .search-bar__val { width: inherit !important; }
</style>