<template>
  <div class="modal-content modal-content__width--922">
    <div class="modal-header">
      <div class="modal-title">출시 완료</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({message: ''})"></button>
    </div>

    <div class="modal-body">
      <div class="board-top mb-0">
        <div class="search-bar__row search-bar__row--modal">
          <dl class="search-bar__item search-bar__item--flexible">
            <dt class="search-bar__key search-bar__width--120">출시완료일<span class="ui-require"><span class="for-a11y">(필수)</span></span></dt>
            <dd class="search-bar__val search-bar__val--flexible">
              <div class="search-form" id="error_wrap_vCompleteDt">
                <div class="search-form__inner">
                  <ap-month-picker
                    v-model:date="regParams.vCompleteDt"
                    @update:date="fnValidate('vCompleteDt')"
                  >
                  </ap-month-picker>
                </div>
                <span class="error-msg" id="error_msg_vCompleteDt"></span>
              </div>
            </dd>
          </dl>
        </div>

        <table class="ui-table__th--bg-gray mt-15">
          <colgroup>
            <col style="width:14rem;">
            <col style="width:auto">
            <col style="width:14rem;">
            <col style="width:auto">
          </colgroup>
          <tbody>
            <tr>
              <td
                colspan="4"
                class="inside-td"
              >
                <table class="ui-table__contents"
                  :class="idx !== 0 ? 'mt-15' : ''"
                  v-for="(vo, idx) in regParams.contList" :key="'compCont_' + idx"
                >
                  <colgroup>
                    <col style="width:10rem">
                    <col style="width:auto">
                  </colgroup>
                  <tbody>
                    <tr>
                      <td colspan="2" class="t-left">
                        <p class="p_bold">[{{ vo.vContCd }}] [{{ vo.vPlantCd }}] {{ vo.vContNm }}</p>
                      </td>
                    </tr>
                    <tr>
                      <th>카운터</th>
                      <td>
                        <div class="search-form">
                          <div class="search-form__inner">
                            <ap-input
                            v-model:value="vo.vCounterNmTemp"
                            input-class="ui-input__width--450"
                            :readonly="true"
                            @click="fnCounterSearchPop(idx)"
                          >
                          </ap-input>
                          <button type="button" class="button-search" @click="fnCounterSearchPop(idx)">검색</button>
                          <button type="button" class="button-search" @click="removeCounterInfo(idx)">삭제</button>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <th>비고</th>
                      <td>
                        <ap-input
                          v-model:value="vo.vCompleteCounterNote"
                          input-class="ui-input__width--full"
                        >
                        </ap-input>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="board-bottom">
        <div class="board-bottom__inner">
          <div class="ui-buttons ml-auto ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--skyblue font-weight__300" @click="fnReleaseCompleteSave()">출시완료</button>
            <button type="button" class="ui-button ui-button__bg--lightgray" @click="closeAsyncPopup({ message: '' })">닫기</button>
          </div>
        </div>
      </div>
    </div>
  </div>
  <teleport to="#common-modal-sub" v-if="popContent">
    <ap-popup>
      <component
        :is="popContent"
        :pop-params="popupParams"
        @selectFunc="popSelectFunc"
        @closeFunc="closeFunc"
      />
    </ap-popup>
  </teleport>
  <div id="common-modal-sub"></div>
</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'
import { useQdrugRequest } from '@/compositions/qdrug/useQdrugRequest'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'ReleaseCompletePop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    CompleteCounterSearchPop: defineAsyncComponent(() => import('@/components/labcommon/popup/CompleteCounterSearchPop.vue')),
  },
  emits: ['callbackFunc'],
  setup (props, context) {
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert, openAsyncConfirm, closeAsyncPopup } = useActions(['openAsyncAlert', 'openAsyncConfirm', 'closeAsyncPopup'])
    const popContent = ref(null)
    const popupParams = ref(null)
    const popSelectFunc = ref(null)
    const closeFunc = ref(null)
    const flagType = ref('R')
    let popIdx = null

    const {
      selectReleaseCompleteInfo,
      saveReleaseCompleteInfo,
    } = useQdrugRequest()

    const regParams = ref({
      vLabNoteCd: props.popParams.vLabNoteCd || '',
      vCompleteDt: '',
      vFlagNp: 'Y',
      /* vFlagSameShape: 'Y',
      vCompleteShape: '', */
      contList: [],
    })

    const getCounterSearchInfo = (item) => {
      regParams.value.contList[popIdx].vCounterNmTemp = '[' + item.vContCd + '] ' + item.vContNm
      regParams.value.contList[popIdx].vCompleteCounterCd = item.vContPkCd

      popIdx = null
      closeCounterPop()
    }

    const closeCounterPop = () => {
      popContent.value = null
    }

    const fnCounterSearchPop = (idx) => {
      popIdx = idx

      popupParams.value = {
        vFlagNp: regParams.value.vFlagNp,
        vCodeType: props.popParams.vCodeType,
      }

      popSelectFunc.value = getCounterSearchInfo
      closeFunc.value = closeCounterPop
      popContent.value = 'CompleteCounterSearchPop'
    }

    const removeCounterInfo = (idx) => {
      regParams.value.contList[idx].vCounterNmTemp = ''
      regParams.value.contList[idx].vCompleteCounterCd = ''
    }

    const fnValidate = (key) => {
      let isOk = true
      let errorMsg = '필수 입력 사항입니다.'
      commonUtils.hideErrorMessage(key)

      if (commonUtils.isEmpty(regParams.value[key])) {
        isOk = false
      }

      if (!isOk) {
        commonUtils.showErrorMessage(key, errorMsg)
      }

      return isOk
    }

    const fnValidateAll = () => {
      let isOk = true
      const arrChkKey = ['vCompleteDt']
      commonUtils.hideErrorMessageAll(arrChkKey)

      arrChkKey.forEach(key => {
        if (!fnValidate(key)) {
          isOk = false
        }
      })

      return isOk
    }

    const fnReleaseCompleteSave = async () => {
      regParams.value.vFlagType = flagType.value

      if (!fnValidateAll()) {
        openAsyncAlert({ message: '필수 입력 사항을 확인해 주세요.' })
        return
      }

      if (!await openAsyncConfirm({ message: '해당 실험노트에 대하여 출시 완료를 하시겠습니까?' })) {
        return
      }

      const result = await saveReleaseCompleteInfo(regParams.value)

      if (result === 'SUCC') {
        await openAsyncAlert({ message: '저장 되었습니다.'})
        window.location.reload(true)
      }
    }

    const init = async () => {
      const payload = {
        vLabNoteCd: props.popParams.vLabNoteCd,
        vCodeType: props.popParams.vCodeType,
      }

      const result = await selectReleaseCompleteInfo(payload)

      if (result) {
        const completeInfo = result.completeInfo
        if (result.contList && result.contList.length > 0) {
          result.contList.forEach(item => {
            if (commonUtils.isNotEmpty(completeInfo) && completeInfo.vFlagNp !== 'S') {
              item.vCounterNmTemp = commonUtils.isEmpty(item.vCompleteCounterContNm) ? item.vInitCounterContNm : item.vCompleteCounterContNm
              item.vCompleteCounterCd = commonUtils.isEmpty(item.vCompleteCounterCd) ? item.vCounterContPkCd : item.vCompleteCounterCd
            } else {
              item.vCompleteSsrid = item.nCompleteVer + '_' + item.vCompleteSsrid
            }
          })
          regParams.value.contList = [ ...result.contList ]
        }

        if (completeInfo) {
          flagType.value = 'M'
          regParams.value = { ...regParams.value, ...completeInfo }
        }
      }
    }

    init()

    return {
      regParams,
      popContent,
      popSelectFunc,
      closeFunc,
      popupParams,
      closeAsyncPopup,
      fnCounterSearchPop,
      removeCounterInfo,
      fnReleaseCompleteSave,
      fnValidate,
    }
  }
}
</script>

<style scoped>
  .modal-body .ui-table__contents tr td .ui-select { margin-left: inherit; }
</style>

