<template>
  <div class="sub-contents__item mt-15">
    <dl class="sub-contents__dd">
      <dt class="sub-contents__dt">신고/허가</dt>
      <dd class="sub-contents__dd">
        <div class="basic-info__table">
          <table class="ui-table__contents">
            <colgroup>
              <col style="width:21.5rem">
              <col style="width:auto">
              <col style="width:21.5rem">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr>
                <td class="inside-td" colspan="4">
                  <table class="ui-table__contents mb-15 tb-permission">
                    <colgroup>
                      <col style="width:18rem">
                      <col style="width:auto">
                      <col style="width:18rem">
                      <col style="width:auto">
                    </colgroup>
                    <tbody>
                      <tr>
                        <th>심사구분</th>
                        <td>{{ versionInfo.vQsTypeNm }}</td>
                        <th>허가번호</th>
                        <td>{{ versionInfo.vEvaluateno }}</td>
                      </tr>
                      <tr>
                        <th>심사소요기간<br>(워킹데이기준)</th>
                        <td>
                          <template v-if="commonUtils.isNotEmpty(versionInfo.vValuateTime)">
                            {{ versionInfo.vValuateTime }} 일
                          </template>
                        </td>
                        <th>심사접수기한<br>(생산회의 - 소요기간)</th>
                        <td>
                          {{ commonUtils.changeStrDatePattern(versionInfo.vTimeLimit) }}
                        </td>
                      </tr>
                      <tr>
                        <th>기신고/허가 유무</th>
                        <td>
                          {{ versionInfo.vFlagPermission === 'Y' ? '유' : '무' }}
                        </td>
                        <th>신규별규 유무</th>
                        <td>
                          {{ versionInfo.vFlagNewannex === 'Y' ? '유' : '무' }}
                        </td>
                      </tr>
                      <tr>
                        <th>주성분</th>
                      </tr>
                      <tr>
                        <td colspan="4">
                          <MateSearchResultTableView
                            :mate-list="versionInfo.mainMateList"
                            input-class="ui-table__reset ui-table__search-result text-center"
                            type="main"
                          >
                          </MateSearchResultTableView>
                        </td>
                      </tr>
                      <tr>
                        <th>효능/효과</th>
                        <td colspan="3" v-html="commonUtils.removeHTMLChangeBr(versionInfo.vEfficacyEffect)"></td>
                      </tr>
                      <tr>
                        <th>용법/용량</th>
                        <td colspan="3" v-html="commonUtils.removeHTMLChangeBr(versionInfo.vCapacityUsage)"></td>
                      </tr>
                      <tr>
                        <th>사용상 주의사항</th>
                        <td colspan="3" v-html="commonUtils.removeHTMLChangeBr(versionInfo.vUseCautionNote)"></td>
                      </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </dd>
    </dl>
  </div>
  <div class="sub-contents__item">
    <dl class="sub-contents__dd">
      <dt class="sub-contents__dt">카운터</dt>
      <dd class="sub-contents__dd">
        <div class="ui-table__product--wrap">
          <table class="ui-table__product">
            <colgroup>
              <col style="width:21.5rem">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr>
                <th>구분</th>
                <td>{{ versionInfo.vCounterTypeNm ? versionInfo.vCounterTypeNm : '없음' }}</td>
              </tr>
              <tr v-if="versionInfo.vCounterTypeCd === 'LNC04_01'">
                <th>내용물 코드</th>
                <td>
                  <template v-if="commonUtils.isNotEmpty(versionInfo.vCounterInvenCd)">
                    [{{ versionInfo.vCounterSpCd }}]
                  </template>
                  {{ commonUtils.isNotEmpty(versionInfo.vCounterInvenCd) ? 
                      versionInfo.vCounterInvenNm : versionInfo.vCounterContNm }}
                </td>
              </tr>
              <template v-else-if="versionInfo.vCounterTypeCd === 'LNC04_02'">
                <tr>
                  <th>브랜드</th>
                  <td>
                    {{ versionInfo.vCounterBrdNm }}
                  </td>
                </tr>
                <tr>
                  <th>제품명</th>
                  <td>
                    {{ versionInfo.vCounterPrdNm }}
                  </td>
                </tr>
              </template>
              <template v-else-if="versionInfo.vCounterTypeCd === 'LNC04_03'">
                <tr>
                  <th>SP 정보</th>
                  <td>
                    {{ versionInfo.vCounterSpInfo }}
                  </td>
                </tr>
                <tr>
                  <th>선행파일럿</th>
                  <td>
                    {{ commonUtils.changeStrDatePattern(versionInfo.vPrePilotDt, '.') }}
                  </td>
                </tr>
              </template>
              <tr>
                <th>비고</th>
                <td v-html="commonUtils.removeHTMLChangeBr(versionInfo.vCounterNote)"></td>
              </tr>
            </tbody>
          </table>
        </div>
      </dd>
    </dl>
  </div>

  <div class="sub-contents__item">
    <dl class="sub-contents__dd">
      <dt class="sub-contents__dt">신원료</dt>
      <dd class="sub-contents__dd">
        <div class="ui-table__product--wrap">
          <table class="ui-table__product">
            <colgroup>
              <col style="width:21.5rem">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr>
                <th>신원료 정보</th>
                <td>{{ versionInfo.vFlagNewItem === 'Y' ? '유' : '무' }}</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="note-table mt-15 mb-15"
          v-if="versionInfo.vFlagNewItem === 'Y' && versionInfo.newMateList"
        >
          <MateSearchResultTableView
            :mate-list="versionInfo.newMateList"
            stock-dt-yn="Y"
            mate-chg-yn="Y"
          ></MateSearchResultTableView>
        </div>
      </dd>
    </dl>
  </div>

  <div class="sub-contents__item">
    <dl class="sub-contents__dd">
      <dt class="sub-contents__dt">향료정보</dt>
      <dd class="sub-contents__dd">
        <div class="ui-table__product--wrap">
          <table class="ui-table__product">
            <colgroup>
              <col style="width:21.5rem">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr>
                <th>구분</th>
                <td>
                  {{ versionInfo.vPerfumeNm }} 
                  <template v-if="versionInfo.vPerfumeCd === 'LNC11_03'">
                    ({{ versionInfo.vFlagPerfumeNew === 'Y' ? '신향' : '기존향' }})
                  </template>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <div class="note-table mt-15 mb-15"
          v-if="versionInfo.vPerfumeCd !== 'LNC11_99' && versionInfo.perfMateList"
        >
          <MateSearchResultTableView
            :mate-list="versionInfo.perfMateList"
            stock-dt-yn="Y"
          ></MateSearchResultTableView>
        </div>
      </dd>
    </dl>
  </div>

  <div class="sub-contents__item">
    <dl class="sub-contents__dd" v-if="versionInfo.requMateList && versionInfo.requMateList.length > 0">
      <dt class="sub-contents__dt">필수원료</dt>
      <dd class="sub-contents__dd">
        <div class="note-table mt-15 mb-15">
          <MateSearchResultTableView
            :mate-list="versionInfo.requMateList"
          ></MateSearchResultTableView>
        </div>
      </dd>
    </dl>
  </div>

  <div class="page-bottom">
    <div class="ui-buttons ui-buttons__right">
      <button type="button" class="ui-button ui-button__height--28 ui-button__bg--blue" v-if="reqInfo.vStatusCd !== 'LNC06_50'" @click="fnProductModifyPop()">버전수정</button>
      <button type="button" class="ui-button ui-button__height--28 ui-button__bg--blue" @click="fnProductHistoryPop()">변경이력</button>
    </div>
  </div>
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @callbackFunc="popSelectFunc"
        @selectFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, ref, inject, watch } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'AllLabNoteQdrugProductInfoView',
  components: {
    MateSearchResultTableView: defineAsyncComponent(() => import('@/components/labcommon/MateSearchResultTableView.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    AllLabNoteProductVersionModifyPop: defineAsyncComponent(() => import('@/components/labcommon/popup/AllLabNoteProductVersionModifyPop.vue')),
    ProductVersionHistoryPop: defineAsyncComponent(() => import('@/components/labcommon/popup/ProductVersionHistoryPop.vue')),
  },
  props: {
    versionInfo: {
      type: Object,
      default: () => {
        return {}
      }
    },
  },
  setup (props) {
    const commonUtils = inject('commonUtils')
    const reqInfo = inject('reqInfo')
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
    } = useLabCommon()

    const closeModifyPop = () => {
      closeAsyncPopup({ message: '' })
      window.location.reload(true)
    }

    const fnProductModifyPop = () => {
      popParams.value = {
        vLabNoteCd: props.versionInfo.vLabNoteCd,
        vContPkCd: reqInfo.value.vContPkCd,
        vContCd: reqInfo.value.vContCd,
        vContNm: reqInfo.value.vContNm,
        nVersion: props.versionInfo.nVersion,
      }

      popSelectFunc.value = closeModifyPop

      fnOpenPopup('AllLabNoteProductVersionModifyPop', false)
    }

    const fnProductHistoryPop = () => {
      const verList = []

      reqInfo.value.verList.forEach(item => {
        verList.push({...item})
      })
      popParams.value = {
        vLabNoteCd: props.versionInfo.vLabNoteCd,
        vContPkCd: reqInfo.value.vContPkCd,
        nVersion: props.versionInfo.nVersion,
        verList: verList,
      }

      fnOpenPopup('ProductVersionHistoryPop', false)
    }

    return {
      reqInfo,
      popupContent,
      popParams,
      popSelectFunc,
      commonUtils,
      fnProductModifyPop,
      fnProductHistoryPop,
    }
  }
}
</script>

<style scoped>
  td.inside-td .ui-table__contents th + td + th { padding-left: 2rem; }
</style>