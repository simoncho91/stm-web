<template>
  <div class="contents-box__inner">
    <table class="ui-table__th--bg-gray">
      <colgroup>
        <col style="width:14rem">
        <col style="width:auto">
        <col style="width:14rem">
        <col style="width:auto">
      </colgroup>
      <tbody>
        <tr>
          <th>내용물명</th>
          <td>
            {{ gate02CheckParam.vContNm }}
          </td>
          <th>내용물 코드</th>
          <td>
            {{ gate02CheckParam.vContCd }}
          </td>
        </tr>
        <tr>
          <th>VER. - LOT</th>
          <td>
            {{ gate02CheckParam.vVersionTxt }} - {{ gate02CheckParam.vLotNm }}
          </td>
          <th>연구담당자</th>
          <td>
            {{ gate02CheckParam.vUsernm }} ({{ gate02CheckParam.vUserid }} / {{ gate02CheckParam.vDeptNm }})
          </td>
        </tr>
        <tr>
          <th>브랜드</th>
          <td>{{ gate02CheckParam.vBrdNm }}</td>
          <th>Plant</th>
          <td>[{{ gate02CheckParam.vPlantCd }}] {{ gate02CheckParam.vPlantNm }}</td>
        </tr>
      </tbody>
    </table>

    <div class="divide-line"></div>

    <div class="ui-table__wrap">
      <table class="ui-table text-center ui-table__td--40">
        <tr class="tr-contents">
          <td class="inside-td">
            <div class="inside-td__item">
              <ProcessPQCGateCheckInfo
                v-if="resultVo?.pqcList && resultVo?.pqcList.length > 0"
                v-model:pqc-list="resultVo.pqcList"
                :tr-map="resultVo.trMap"
                :gate-flag="'GATE2'"
              >
              </ProcessPQCGateCheckInfo>

              <div class="inside-td__item" v-if="resultVo?.pqcResVo">
                <div class="inside-td__item--title">준수율</div>
                <div class="inside-td__item--wrap">
                  <table class="ui-table__reset inside-td__table">
                    <colgroup>
                      <col style="width:21rem"> 
                      <col style="width:auto"> 
                    </colgroup>
                    <tbody>
                      <tr>
                        <th>준수율</th>
                        <td class="t-left">
                          {{ resultVo.pqcResVo.nObeyPer }} %
                        </td>
                      </tr>
                      <tr>
                        <th>연구원 의견</th>
                        <td class="t-left" v-html="commonUtils.removeHTMLChangeBr(resultVo.pqcResVo.vComment)"></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              <ProcessTrGate01List
                v-if="resultVo?.trGate1List && resultVo?.trGate1List.length > 0"
                :tr-gate1-list="resultVo.trGate1List"
              >
              </ProcessTrGate01List>
            </div>
          </td>
        </tr>
      </table>
    </div>

    <div class="contents-box__inner mt-15 min-height__unset">
      <ApprovalView
        :appr-cd="checkParams.vApprCd"
        :appr-class="'LAB002_'+ noteType"
        ref="appr"
        v-model:appr-mst-info="apprMstInfo"
        v-model:appr-user-list="apprUserList"
        @callbackFunc="fnApprProc"
      >
      </ApprovalView>
    </div>
  </div>

  <div class="page-bottom">
    <div class="page-bottom__inner">
      <div class="ui-buttons ui-buttons__right">
        <button type="button" class="ui-button ui-button__border--gray" v-if="showOpinionPopBtn()" @click="fnViewApprOpinion()">의견보기</button>
        <template v-if="showApprovalBtn('USR010')">
            <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnAppr('ACCEPT')">승인</button>
            <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnAppr('REJECT')">반려</button>
          </template>
          <template v-if="showApprovalBtn('USR020')">
            <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnMutual('ACCEPT')">합의</button>
            <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnMutual('REJECT')">거부</button>
          </template>
        <button type="button" class="ui-button ui-button__bg--gray" @click="goList()">목록</button>
      </div>
    </div>
  </div>
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @selectFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'
import { useRouter } from 'vue-router'
import { useStore } from 'vuex'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'
import { useApproval } from '@/compositions/approval/useApproval'

export default {
  name: 'QdrugProcessPrescribeConfirmView',
  props: {
    vActionFlag: {
      type: String,
      default: 'R'
    },
    checkParams: {
      type: Object,
      default: () => {
        return {}
      }
    },
  },
  emits: ['update:vActionFlag'],
  components: {
    ProcessPQCGateCheckInfo: defineAsyncComponent(() => import('@/components/process/ProcessPQCGateCheckInfo.vue')),
    ProcessTrGate01List: defineAsyncComponent(() => import('@/components/process/ProcessTrGate01List.vue')),
    ApprovalView: defineAsyncComponent(() => import('@/components/comm/ApprovalView.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    OpinionViewPop: defineAsyncComponent(() => import('@/components/approval/popup/OpinionViewPop.vue')),
  },
  setup (props, context) {
    const gate02CheckParam = ref(props.checkParams)
    const commonUtils = inject('commonUtils')
    const store = useStore()
    const router = useRouter()
    const myInfo = store.getters.getMyInfo()
    const appr = ref(null)
    const resultVo = ref(null)
    const apprMstInfo = ref(null)
    const apprUserList = ref(null)
    let apprProcStatus = ''
    let apprProcSubStatus = ''

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
    } = useLabCommon()

    const {
      selectLabNoteGate2View,
      noteType,
      noteTypeNm,
    } = useProcessCommon()

    const {
      updateGate2Approval,
    } = useApproval()

    const fnAppr = (flag) => {
      if (appr.value) {
        if (flag === 'ACCEPT') {
          apprProcStatus = 'APS010'
        } else if (flag === 'REJECT') {
          apprProcStatus = 'APS020'
        }

        appr.value.fnApprovalOpinionPop()
      }
    }

    const fnMutual = (flag) => {
      apprProcStatus = 'APS050'
      if (appr.value) {
        if (flag === 'ACCEPT') {
          apprProcSubStatus = 'AGR010'
        } else {
          apprProcSubStatus = 'AGR030'
        }

        appr.value.fnApprovalOpinionPop()
      }
    }

    const fnApprProc = async (draftOpinion) => {
      store.dispatch('setLoading', true)
      const payload = {
        noteTypeNm,
        vLabNoteCd: resultVo.value.rvo.vLabNoteCd,
        nVersion: props.checkParams.nVersion,
        vPlantMstCd: resultVo.value.rvo.vPlantCd,
        vLotCd: props.checkParams.vLotCd,
        vUserid: resultVo.value.rvo.vUserid,
        lotList: resultVo.value.contList,
        ...apprMstInfo.value,
        ...{
          vApprStatus: apprProcStatus,
          vApprOpinion: draftOpinion.value
        }
      }

      const result = await updateGate2Approval(payload)
      if (result) {
        router.push({ path: '/approval/list' })
      } else{
        store.dispatch('setLoading', false)
      }
    }

    const fnViewApprOpinion = () => {
      popParams.value = { vApprCd: props.checkParams.vApprCd }

      fnOpenPopup('OpinionViewPop')
    }

    const showApprovalBtn = (apprUserType) => {
      let isVisible = false

      if (apprMstInfo.value &&
          apprMstInfo.value.vApprStatus === 'APS030' &&
          apprUserList.value?.length > 0) {
        const curApprUser = apprUserList.value.filter(v => v.nCurApprseq === apprMstInfo.value.nCurApprseq)

        if (curApprUser && curApprUser.length > 0 &&
            (curApprUser[0].vApprUserid === myInfo.loginId || commonUtils.checkAuth('S000000')) &&
            curApprUser[0].vApprUserType === apprUserType) {
          isVisible = true
        }
      }

      return isVisible
    }

    const showOpinionPopBtn = () => {
      let isVisible = false
      const userList = apprUserList.value && apprUserList.value.length > 0 ? apprUserList.value : []
      if (apprMstInfo.value && 
            (apprMstInfo.value.vDraftUserid === myInfo.loginId ||
            userList.length > 0 && userList.filter(v => v.vApprUserid === myInfo.loginId).length > 0 ||
            commonUtils.checkAuth('S000000'))
        ) {
        isVisible = true
      }

      return isVisible
    }

    const goList = () => {
      router.replace({ query: {vLabNoteCd: resultVo.value.rvo.vLabNoteCd} })
      setTimeout(() => {
        context.emit('update:vActionFlag', 'L')
      }, 200)
    }

    const init = async () => {
      resultVo.value = await selectLabNoteGate2View(props.checkParams)
    }

    init()

    return {
      commonUtils,
      gate02CheckParam,
      appr,
      resultVo,
      noteType,
      popupContent,
      popParams,
      popSelectFunc,
      apprMstInfo,
      apprUserList,
      fnAppr,
      fnMutual,
      fnApprProc,
      fnViewApprOpinion,
      showOpinionPopBtn,
      showApprovalBtn,
      goList,
    }
  }
}
</script>