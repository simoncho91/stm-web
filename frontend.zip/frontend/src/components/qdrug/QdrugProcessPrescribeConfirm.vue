<template>
  <QdrugProcessPrescribeConfirmList
    v-if="vActionFlag === 'L'"
    v-model:vActionFlag="vActionFlag"
    v-model:check-params="checkParams"
    @callbackFunc="setProgressInfo"
  >
  </QdrugProcessPrescribeConfirmList>
  <QdrugProcessPrescribeConfirmReg
    v-if="vActionFlag === 'R'"
    v-model:vActionFlag="vActionFlag"
    v-model:check-params="checkParams"
    @callbackFunc="setProgressInfo"
  >
  </QdrugProcessPrescribeConfirmReg>
  <QdrugProcessPrescribeConfirmView
    v-if="vActionFlag === 'V'"
    v-model:vActionFlag="vActionFlag"
    v-model:check-params="checkParams"
    @callbackFunc="setProgressInfo"
  >
  </QdrugProcessPrescribeConfirmView>
</template>

<script>
import { defineAsyncComponent, ref } from 'vue'

export default {
  name: 'QdrugProcessPrescribeConfirm',
  components: {
    QdrugProcessPrescribeConfirmList: defineAsyncComponent(() => import('@/components/qdrug/QdrugProcessPrescribeConfirmList.vue')),
    QdrugProcessPrescribeConfirmReg: defineAsyncComponent(() => import('@/components/qdrug/QdrugProcessPrescribeConfirmReg.vue')),
    QdrugProcessPrescribeConfirmView: defineAsyncComponent(() => import('@/components/qdrug/QdrugProcessPrescribeConfirmView.vue')),
  },
  emits: ['callbackFunc'],
  setup (props, context) {
    const vActionFlag = ref('L')
    const checkParams = ref({})

    const setProgressInfo = () => {
      context.emit('callbackFunc')
    }

    return {
      vActionFlag,
      checkParams,
      setProgressInfo,
    }
  }
}
</script>