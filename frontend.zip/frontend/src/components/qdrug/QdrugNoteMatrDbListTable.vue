<template>
  <div class="note-table">
    <div class="note-table__inner">
      <table class="ui-table ui-table__td--40 text-center">
        <colgroup>
          <col style="width: 7%" />
          <col style="width: 7%" />
          <col style="width: 25%" />
          <col style="width: 25%" />
          <col style="width: 13%" />
          <col style="width: 13%" />
          <col style="width: 10%" />
        </colgroup>
        <thead>
          <tr>
            <th>No</th>
            <th>원료코드</th>
            <th>원료명</th>
            <th>한글허가명</th>
            <th>배합목적1</th>
            <th>배합목적2</th>
            <th>등록일</th>
          </tr>
        </thead>
        <tbody v-if="info.list && info.list.length > 0">
          <template v-for="(vo, index) in info.list" :key="index">
            <tr>
              <td>{{ vo.nNum }}</td>
              <td>{{ vo.vMatrCd }}</td>
              <td class="tit">
                <div class="tit__inner">
                  <a href="javascript:void(0)" class="tit-link" @click="goView(vo.vMatrCd)">
                    {{ vo.vMatrNm }}
                  </a>
                </div>
              </td>
              <td v-html="commonUtils.removeHTMLChangeBr(vo.vPermissionKr)"></td>
              <td>{{ vo.vCmbCode1Nm }}</td>
              <td>{{ vo.vCmbCode2Nm }}</td>
              <td>{{ commonUtils.changeStrDatePattern(vo.vRegDtm) }}</td>
            </tr>
          </template>
        </tbody>
        <tbody v-else>
          <tr>
            <td colspan="10">
              <div class="no-result">
                {{ t('common.msg.no_data') }}
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <div class="board-bottom">
    <div class="board-bottom__inner">
      <Pagination :page-info="info.page" @click="onPaging"> </Pagination>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, inject, watch } from 'vue'
import { useStore } from 'vuex'
import { useQdrugMatrDb } from '@/compositions/qdrug/useQdrugMatrDb'

export default {
  name: 'QdrugNoteMatrDbListTable',
  components: {
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
  },
  props: {
    resultList: {
      type: Array,
      default: () => {
        return []
      }
    },
    resultPage: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  emits: ['onPaging'],
  setup(props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const store = useStore()
    const noteType = store.getters.getNoteType()
    const info = ref({
      list: [],
      page: {}
    })

    const {
      goView,
    } = useQdrugMatrDb()

    const onPaging = (pg) => {
      context.emit('onPaging', pg)
    }

    watch(() => props.resultList, (newVal) => {
      info.value.list = newVal
    })

    watch(() => props.resultPage, (newVal) => {
      info.value.page = newVal
    })

    return {
      t,
      commonUtils,
      onPaging,
      goView,
      info,
    }
  }
}
</script>