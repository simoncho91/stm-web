<template>
  <div class="basic-info__table">
    <table class="ui-table__contents">
      <colgroup>
        <col style="width:17rem">
        <col style="width:auto">
        <col style="width:17rem">
        <col style="width:auto">
      </colgroup>
      <tbody>
        <tr>
          <th>신고/허가</th>
        </tr>
        <tr>
          <td class="inside-td" colspan="4">
            <table class="ui-table__contents">
              <colgroup>
                <col style="width:18rem">
                <col style="width:auto">
                <col style="width:18rem">
                <col style="width:auto">
              </colgroup>
              <tbody>
                <tr>
                  <th>심사구분</th>
                  <td>
                    <div class="ui-select-box ui-form-box__width--350">
                      <ap-selectbox
                        v-model:value="verParams.vQsTypeCd"
                        :input-class="['ui-select__width--full']"
                        :options="codeGroupMaps['SA_NOTE_QS_TYPE']"
                        @change="changeQsTypeCd()"
                      >
                      </ap-selectbox>
                    </div>
                  </td>
                  <th>허가번호</th>
                  <td>
                    <div class="form-flex form-permission" v-if="verParams.vFlagPermission === 'Y'">
                      <div class="search-form">
                        <div class="search-form__inner">
                          <ap-input
                            v-model:value="verParams.vEvaluateno"
                            input-class="ui-input__width--200"
                            :readonly="true"
                            @click="fnOpenEvaluateSearchPop()"
                          >
                          </ap-input>
                          <button type="button"
                            class="ui-button ui-button__circle ui-button__close input-close-btn--1"
                            @click="removeEvaluateInfo()"
                          ></button>
                        </div>
                      </div>
                      <button type="button" class="ui-button ui-button__width-auto button-search ml-05" @click="fnOpenEvaluateSearchPop()">검색</button>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th>심사소요기간<br>(워킹데이기준)</th>
                  <td>
                    <template v-if="commonUtils.isEmpty(verParams.vQsTypeCd)">
                      <p class="txt_red">심사구분 미선택</p>
                    </template>
                    <template v-else>
                      {{ verParams.vValuateTime }} 일
                    </template>
                  </td>
                  <th>심사접수기한<br>(생산회의 - 소요기간)</th>
                  <td>
                    <template v-if="commonUtils.isEmpty(verParams.vTimeLimit) && commonUtils.isEmpty(verParams.vQsTypeCd)">
                      <p class="txt_red">심사구분 미선택</p>
                    </template>
                    <template v-else-if="commonUtils.isEmpty(verParams.vTimeLimit) && commonUtils.isNotEmpty(verParams.vQsTypeCd)">
                      <p class="txt_red">생산회의 미입력</p>
                    </template>
                    <template v-else>
                      {{ commonUtils.changeStrDatePattern(verParams.vTimeLimit) }}
                    </template>
                  </td>
                </tr>
                <tr>
                  <th>기신고/허가 유무</th>
                  <td>
                    <div class="ui-radio__list">
                      <div class="ui-radio__inner">
                        <ap-input-radio
                          v-model:model="verParams.vFlagPermission"
                          v-for="(vo, index) in [{vSubCode: 'Y', vSubCodenm: '유'}, {vSubCode: 'N', vSubCodenm: '무'}]" :key="'flagPermission_' + index"
                          :value="vo.vSubCode"
                          :label="vo.vSubCodenm"
                          :id="'flagPermission_' + index"
                          name="flagPermission"
                          @click="fnFlagPermissionEvent"
                        ></ap-input-radio>
                      </div>
                    </div>
                  </td>
                  <th>신규별규 유무</th>
                  <td>
                    <div class="ui-radio__list">
                      <div class="ui-radio__inner">
                        <ap-input-radio
                          v-model:model="verParams.vFlagNewannex"
                          v-for="(vo, index) in [{vSubCode: 'Y', vSubCodenm: '유'}, {vSubCode: 'N', vSubCodenm: '무'}]" :key="'flagNewannex_' + index"
                          :value="vo.vSubCode"
                          :label="vo.vSubCodenm"
                          :id="'flagNewannex_' + index"
                          name="flagNewannex"
                        ></ap-input-radio>
                      </div>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th>주성분</th>
                  <td colspan="3" class="t-left">
                    <div class="search-form">
                      <div class="search-form__inner">
                        <ap-input
                          v-model:value="searchParams.mateMainKeyword"
                          input-class="ui-input__width--340"
                          placeholder="검색어를 입력하세요."
                          @keypress-enter="fnOpenMateSearchPop(searchParams.mateMainKeyword, 'Y', getSearchMainMateResult)"
                        >
                        </ap-input>
                        <button type="button" class="button-search" @click="fnOpenMateSearchPop(searchParams.mateMainKeyword, 'Y', getSearchMainMateResult)">검색</button>
                      </div>
                    </div>
                  </td>
                </tr>
                <tr v-if="verParams.mainMateList.length > 0">
                  <td colspan="4">
                    <MateSearchResultTableRegister
                      v-model:mate-list="verParams.mainMateList"
                      type="main"
                    >
                    </MateSearchResultTableRegister>
                  </td>
                </tr>
                <tr>
                  <th>효능/효과</th>
                  <td colspan="3">
                    <div class="ui-textarea-box" id="error_wrap_vEfficacyEffect">
                      <ap-text-area
                        v-model:value="verParams.vEfficacyEffect"
                        :maxlength="1000"
                        :is-with-byte="true"
                        id="vEfficacyEffect"
                      >
                      </ap-text-area>
                      <span class="error-msg" id="error_msg_vEfficacyEffect"></span>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th>용법/용량</th>
                  <td colspan="3">
                    <div class="ui-textarea-box" id="error_wrap_vCapacityUsage">
                      <ap-text-area
                        v-model:value="verParams.vCapacityUsage"
                        :maxlength="1000"
                        :is-with-byte="true"
                        id="vCapacityUsage"
                      >
                      </ap-text-area>
                      <span class="error-msg" id="error_msg_vCapacityUsage"></span>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th>사용상 주의사항</th>
                  <td colspan="3">
                    <div class="ui-textarea-box" id="error_wrap_vUseCautionNote">
                      <ap-text-area
                        v-model:value="verParams.vUseCautionNote"
                        :maxlength="1000"
                        :is-with-byte="true"
                        id="vUseCautionNote"
                      >
                      </ap-text-area>
                      <span class="error-msg" id="error_msg_vUseCautionNote"></span>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <!-- 카운터 -->
        <tr>
          <th>카운터</th>
          <td colspan="3">
            <div class="ui-radio__list">
              <div class="ui-radio__inner">
                <ap-input-radio
                  v-model:model="verParams.vCounterTypeCd"
                  id="counter_none"
                  name="counterType"
                  value=""
                  label="없음"
                  @click="changeCounterTypeCd(verParams, verParams.vCounterTypeCd);"
                >
                </ap-input-radio>
                <template v-if="codeGroupMaps['LNC04']">
                  <ap-input-radio
                    v-for="(vo, index) in codeGroupMaps['LNC04'].filter(item => commonUtils.isNotEmpty(item.vBuffer1) && item.vBuffer1.indexOf('MU') > -1)"
                    :key="'counter_' + index"
                    v-model:model="verParams.vCounterTypeCd"
                    :value="vo.vSubCode"
                    :label="vo.vSubCodenm"
                    :id="'counter_' + index"
                    name="counterType"
                    @click="changeCounterTypeCd(verParams, verParams.vCounterTypeCd);"
                  >
                  </ap-input-radio>
                </template>
              </div>
            </div>
          </td>
        </tr>
        <tr v-if="verParams.vCounterTypeCd !== ''">
          <td colspan="4" class="inside-td">
            <table class="ui-table__contents">
              <colgroup>
                <col style="width:14rem">
              </colgroup>
              <tbody>
                <!-- 자사 -->
                <tr v-if="verParams.vCounterTypeCd === 'LNC04_01'">
                  <th>자사카운터</th>
                  <td>
                    <div class="search-form" id="error_wrap_vCounterNmTemp">
                      <div class="search-form__inner">
                        <ap-input
                          v-model:value="verParams.vCounterNmTemp"
                          input-class="ui-input__width--450"
                          placeholder="검색어를 입력하세요."
                          @keypress-enter="fnCounterSearchPop()"
                        >
                        </ap-input>
                        <button type="button" class="button-search" @click="fnCounterSearchPop()">검색</button>
                        <button type="button" class="button-search" @click="removeCounterInfo()">삭제</button>
                      </div>
                      <span class="error-msg" id="error_msg_vCounterNmTemp"></span>
                    </div>
                  </td>
                </tr>
                <!-- 타사 -->
                <template v-if="verParams.vCounterTypeCd === 'LNC04_02'">
                  <tr>
                    <th>브랜드</th>
                    <td id="error_wrap_vCounterBrdNm">
                      <ap-input
                        v-model:value="verParams.vCounterBrdNm"
                        :maxlength="200"
                        input-class="ui-input__width--340"
                        @input="fnValidate('vCounterBrdNm')"
                      >
                      </ap-input>
                      <span class="error-msg" id="error_msg_vCounterBrdNm"></span>
                    </td>
                  </tr>
                  <tr>
                    <th>제품명</th>
                    <td id="error_wrap_vCounterPrdNm">
                      <ap-input
                        v-model:value="verParams.vCounterPrdNm"
                        :maxlength="200"
                        input-class="ui-input__width--340"
                        @input="fnValidate('vCounterPrdNm')"
                      >
                      </ap-input>
                      <span class="error-msg" id="error_msg_vCounterPrdNm"></span>
                    </td>
                  </tr>
                </template>
                <!-- 신제형(SP) -->
                <template v-if="verParams.vCounterTypeCd === 'LNC04_03'">
                  <tr>
                    <th>SP 정보</th>
                    <td id="error_wrap_vCounterSpInfo">
                      <ap-input
                        v-model:value="verParams.vCounterSpInfo"
                        :maxlength="300"
                        input-class="ui-input__width--340"
                        @input="fnValidate('vCounterSpInfo')"
                      >
                      </ap-input>
                      <span class="error-msg" id="error_msg_vCounterSpInfo"></span>
                    </td>
                  </tr>
                  <tr>
                    <th>선행파일럿</th>
                    <td id="error_wrap_vPrePilotDt">
                      <ap-date-picker
                        v-model:date="verParams.vPrePilotDt"
                        @update:date="fnValidate('vPrePilotDt')"
                      >
                      </ap-date-picker>
                      <span class="error-msg" id="error_msg_vPrePilotDt"></span>
                    </td>
                  </tr>
                </template>
                <!-- 공통 -->
                <tr>
                  <th>비고</th>
                  <td>
                    <div class="ui-textarea-box" id="error_wrap_vCounterNote">
                      <ap-text-area
                        v-model:value="verParams.vCounterNote"
                        :is-with-byte="true"
                        :maxlength="1000"
                        id="vCounterNote"
                      ></ap-text-area>
                      <span class="error-msg" id="error_msg_vCounterNote"></span>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        
        <!-- 신원료 유무 -->
        <tr>
          <th>신원료 유무<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
          <td colspan="3">
            <div class="ui-radio__list" id="error_wrap_vFlagNewItem">
              <div class="ui-radio__inner">
                <ap-input-radio
                  v-for="(vo, index) in [{vSubCode: 'Y', vSubCodenm: '유'}, {vSubCode: 'N', vSubCodenm: '무'}]" :key="'newItem_' + index"
                  v-model:model="verParams.vFlagNewItem"
                  :value="vo.vSubCode"
                  :label="vo.vSubCodenm"
                  :id="'newItem_' + index"
                  name="newItem"
                  @click="resetMateList(verParams.vFlagNewItem, verParams, 'newMateList');fnValidate('vFlagNewItem')"
                ></ap-input-radio>
              </div>
              <span class="error-msg" id="error_msg_vFlagNewItem"></span>
            </div>
          </td>
        </tr>
        <!-- 신원료 'Y'일 경우 -->
        <tr v-if="verParams.vFlagNewItem === 'Y'">
          <td colspan="4" class="inside-td">
            <table class="ui-table__contents">
              <colgroup>
                <col style="width:14rem">
              </colgroup>
              <tbody>
                <tr>
                  <th>신원료 추가</th>
                  <td>
                    <div class="search-form">
                      <div class="search-form__inner">
                        <ap-input
                          v-model:value="searchParams.mateNewKeyword"
                          input-class="ui-input__width--340"
                          placeholder="검색어를 입력하세요."
                          @keypress-enter="fnOpenMateSearchPop(searchParams.mateNewKeyword, 'Y', getSearchNewMateResult, 'tempSearch')"
                        >
                        </ap-input>
                        <button type="button" class="button-search" @click="fnOpenMateSearchPop(searchParams.mateNewKeyword, 'Y', getSearchNewMateResult, 'tempSearch')">검색</button>
                      </div>
                    </div>
                  </td>
                </tr>
                <tr v-if="verParams.newMateList.length > 0">
                  <td colspan="2">
                    <MateSearchResultTableRegister
                      v-model:mate-list="verParams.newMateList"
                      type="new"
                      stock-dt-yn="Y"
                      mate-chg-yn="Y"
                    >
                    </MateSearchResultTableRegister>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <!-- 향료정보 -->
        <tr>
          <th>향료정보</th>
          <td colspan="3">
            <div class="ui-radio__list">
              <div class="ui-radio__inner">
                <ap-input-radio
                  v-for="(vo, index) in fragDivList" :key="'fragType_' + index"
                  v-model:model="verParams.vPerfumeCd"
                  :value="vo.vSubCode"
                  :label="vo.vSubCodenm"
                  :id="'fragType_' + index"
                  name="fragType"
                  @click="resetMateList(verParams.vPerfumeCd, verParams, 'perfMateList');"
                ></ap-input-radio>
              </div>
            </div>
          </td>
        </tr>
        <tr v-if="verParams.vPerfumeCd !== '' && verParams.vPerfumeCd !== 'LNC11_99'">
          <td colspan="4" class="inside-td">
            <table class="ui-table__contents">
              <colgroup>
                <col style="width:14rem">
              </colgroup>
              <tbody>
                <tr>
                  <th>향료 추가</th>
                  <td>
                    <div class="form-flex">
                      <!-- 향료 변경일 경우만 해당 영역 노출 -->
                      <div class="ui-select-box form-flex__cell--5 mr-20" v-if="verParams.vPerfumeCd === 'LNC11_03'">
                        <div class="ui-radio__list">
                          <div class="ui-radio__inner">
                            <ap-input-radio
                              v-for="(vo, index) in [{vSubCode: 'Y', vSubCodenm: '신향'}, {vSubCode: 'N', vSubCodenm: ' 기존향'}]" :key="'fragranceNew_' + index"
                              v-model:model="verParams.vFlagPerfumeNew"
                              :value="vo.vSubCode"
                              :label="vo.vSubCodenm"
                              :id="'fragranceNew_' + index"
                              name="fragranceNew"
                            ></ap-input-radio>
                          </div>
                        </div>
                      </div>
                      <div class="ui-select-box form-flex__cell--5">
                        <div class="search-form">
                          <div class="search-form__inner">
                            <ap-input
                              v-model:value="searchParams.perfumeKeyword"
                              input-class="ui-input__width--340"
                              placeholder="검색어를 입력하세요."
                              @keypress-enter="fnOpenMateSearchPop(searchParams.perfumeKeyword, 'Y', getSearchPerfMateResult)"
                            >
                            </ap-input>
                            <button type="button" class="button-search" @click="fnOpenMateSearchPop(searchParams.perfumeKeyword, 'Y', getSearchPerfMateResult)">검색</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </td>
                </tr>
                <tr v-if="verParams.perfMateList.length > 0">
                  <td colspan="2">
                    <MateSearchResultTableRegister
                      v-model:mate-list="verParams.perfMateList"
                      type="perf"
                      stock-dt-yn="Y"
                    >
                    </MateSearchResultTableRegister>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <!-- 필수 원료 -->
        <tr>
          <th>필수원료</th>
          <td>
            <div class="form-flex form-flex__col">
              <div class="form-flex__cell form-flex__cell--5">
                <div class="search-form">
                  <div class="search-form__inner">
                    <ap-input
                      input-class="ui-input__width--340"
                      placeholder="원료를 검색해주세요."
                      @keypress-enter="fnOpenMateSearchPop(searchParams.requKeyword, 'N', getSearchRequMateResult)"
                    >
                    </ap-input>
                    <button type="button" class="button-search" @click="fnOpenMateSearchPop(searchParams.requKeyword, 'N', getSearchRequMateResult)">원료추가</button>
                  </div>
                </div>
              </div>
            </div>
          </td>
        </tr>
        <tr v-if="verParams.requMateList.length > 0">
          <td colspan="4">
            <MateSearchResultTableRegister
              v-model:mate-list="verParams.requMateList"
              type="requ"
            >
            </MateSearchResultTableRegister>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @selectFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, ref, reactive, inject, watch, computed } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useQdrugRequest } from '@/compositions/qdrug/useQdrugRequest'
import { useActions } from 'vuex-composition-helpers'
import { useStore } from 'vuex'

export default {
  name: 'AllLabNoteQdrugProductInfoRegister',
  components: {
    MateSearchResultTableRegister: defineAsyncComponent(() => import('@/components/labcommon/MateSearchResultTableRegister.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    MateSearchPop: defineAsyncComponent(() => import('@/components/labcommon/popup/MateSearchPop.vue')),
    CounterSearchPop: defineAsyncComponent(() => import('@/components/labcommon/popup/CounterSearchPop.vue')),
    PermissionNoSearchPop: defineAsyncComponent(() => import('@/components/qdrug/popup/PermissionNoSearchPop.vue')),
  },
  props: {
    versionInfo: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  setup (props) {
    const t = inject('t')
    const reqInfo = inject('reqInfo')
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert } = useActions(['openAsyncAlert'])
    const store = useStore()
    const storedNoteInfo = computed(() => store.getters.getNoteInfo())
    const noteType = store.getters.getNoteType()
    const notAdd = ref(null)
    const fragDivList = ref(null)

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const arrMstCode = [
      'LNC04', 'LNC11', 'LNC05', 'SA_NOTE_QS_TYPE'
    ]

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenMateSearchPop,
      fnChangeNoteInfo,
      fnOpenPopup,
      resetMateList,
      changeCounterTypeCd,
    } = useLabCommon()

    const {
      selectEvaluateLimitedDtm,
      selectPermissionNoMateList,
    } = useQdrugRequest()

    const searchParams = reactive({
      mateMainKeyword: '',
      perfumeKeyword: '',
      funcKeyword: '',
      requKeyword: ''
    })

    const verParams = ref({
      vQsTypeCd: '',
      vCounterTypeCd: '',
      vCounterCd: '',
      vCounterContPkCd: '',
      vCounterInvenCd: '',
      vCounterInvenJoinCd: '',
      vCounterSpCd: '',
      vCounterInvenNm: '',
      vCounterContNm: '',
      vCounterBrdNm: '',
      vCounterPrdNm: '',
      vCounterSpInfo: '',
      vCounterNmTemp: '',
      vPrePilotDt: '',
      vCounterNote: '',
      vFlagNewItem: '',
      newMateList: [],
      vPerfumeCd: '',
      vFlagPerfumeNew: '',
      perfMateList: [],
      vRefTypeCd: '',
      vRefNote: '',
      requMateList: [],
      mainMateList: [],
      vEvaluateno: '',
      vEvaluateCd: '',
      vEvaluateNm: '',
      vValuateTime: '',
      vTimeLimit: '',
      vFlagPermission: '',
      vFlagNewannex: '',
      vEfficacyEffect: '',
      vCapacityUsage: '',
      vUseCautionNote: '',
    })

    const mateDefaultObj = {
      vFlagTo100: '',
      nMateRate: '',
      vMatePutDt: '',
      vMateNote: '',
      vFlagMateNew: 'Y'
    }

    const getSearchPerfMateResult = (list) => {
      const perfMateDefault = {
        vMateEvalCd: '',
        vMateFuncCd: '',
        vFlagRequired: 'N',
      }
      list.forEach(item => {
        const perfMateList = verParams.value.perfMateList.filter(vo => vo.vKey === item.vKey)
        if (perfMateList.length === 0) {
          verParams.value.perfMateList.push({ ...item, ...mateDefaultObj, ...perfMateDefault })
        }
      })
    }

    const getSearchNewMateResult = (list) => {
      const newMateDefault = {
        vMateEvalCd: '',
        vMateFuncCd: '',
        vFlagRequired: 'N',
      }
      list.forEach(item => {
        const newMateList = verParams.value.newMateList.filter(vo => vo.vKey === item.vKey)
        if (newMateList.length === 0) {
          verParams.value.newMateList.push({ ...item, ...mateDefaultObj, ...newMateDefault })
        }
      })
    }

    const getSearchRequMateResult = (list) => {
      const requMateDefault = {
        vMateEvalCd: '',
        vMateFuncCd: '',
        vFlagRequired: 'N',
      }
      list.forEach(item => {
        const requMateList = verParams.value.requMateList.filter(vo => vo.vKey === item.vKey)
        if (requMateList.length === 0) {
          verParams.value.requMateList.push({ ...item, ...mateDefaultObj, ...requMateDefault })
        }
      })
    }

    const getSearchMainMateResult = (list) => {
      const mainMateDefault = {
        vMateEvalCd: '',
        vMateFuncCd: '',
        vFlagRequired: 'N',
        vFlagMainIngredientMate: 'Y',
      }
      list.forEach(item => {
        const mainMateList = verParams.value.mainMateList.filter(vo => vo.vKey === item.vKey)
        if (mainMateList.length === 0) {
          verParams.value.mainMateList.push({ ...item, ...mateDefaultObj, ...mainMateDefault })
        }
      })
    }

    const fnCounterSearchPop = () => {
      const plantCd = store.getters.getNoteInfo().vPlantCd

      if (commonUtils.isEmpty(plantCd)) {
        openAsyncAlert({ message: '플랜트를 선택해 주세요.' })
        return
      }

      popParams.value = {
        vKeyword: verParams.value.vCounterNmTemp,
        vNoteType: noteType,
        vPlantCd: plantCd,
        vCodeType: 'HAL3',
        vDefaultTab: 'labNoteSearch',
      }

      popSelectFunc.value = getCounterInfo
      fnOpenPopup('CounterSearchPop')
    }

    const getCounterInfo = (item) => {
      if (commonUtils.isNotEmpty(item.vInvenJoinCd)) {
        verParams.value.vCounterCd = ''
        verParams.value.vCounterContPkCd = ''
        verParams.value.vCounterInvenCd = item.vInvenJoinCd
        verParams.value.vCounterInvenJoinCd = item.vInvenJoinCd
        verParams.value.vCounterNmTemp = '[' + item.vInvenJoinPjtCd + '] ' + item.vSubmitInvenNm
      } else {
        verParams.value.vCounterCd = item.vLabNoteCd
        verParams.value.vCounterContPkCd = item.vContPkCd
        verParams.value.vCounterInvenCd = ''
        verParams.value.vCounterInvenJoinCd = ''

        if (commonUtils.isNotEmpty(item.vLabNoteCd)) {
          verParams.value.vCounterNmTemp = '[' + item.vContCd + '] ' + item.vContNm
        } else {
          verParams.value.vCounterNmTemp = ''
        }
      }

      fnValidate('vCounterNmTemp')
    }

    const removeCounterInfo = () => {
      verParams.value.vCounterNmTemp = ''
      verParams.value.vCounterCd = ''
      verParams.value.vCounterContPkCd = ''
      verParams.value.vCounterInvenCd = ''
      verParams.value.vCounterInvenJoinCd = ''
      fnValidate('vCounterNmTemp')
    }

    const fnValidateAll = (arrChkKey) => {
      let isOk = true
      commonUtils.hideErrorMessageAll(arrChkKey)

      arrChkKey.forEach(key => {
        if (!fnValidate(key)) {
          isOk = false
        }
      })

      return isOk
    }

    const fnValidate = (key) => {
      let isOk = true
      let errorMsg = '필수 입력 사항입니다.'
      commonUtils.hideErrorMessage(key)

      if (key === 'vCounterNmTemp') {
        if (verParams.value.vCounterTypeCd === 'LNC04_01' && 
              commonUtils.isEmpty(verParams.value.vCounterInvenCd) && 
              commonUtils.isEmpty(verParams.value.vCounterContPkCd)) { // 카운터 : 자사
          isOk = false
        }
      } else if (key === 'vCounterBrdNm' || key === 'vCounterPrdNm') { // 카운터 : 타사
        if (verParams.value.vCounterTypeCd === 'LNC04_02' && commonUtils.isEmpty(verParams.value[key])) {
          isOk = false
        }
      } else if (key === 'vCounterSpInfo' || key === 'vPrePilotDt') { // 카운터 : 신제형
        if (verParams.value.vCounterTypeCd === 'LNC04_03' && commonUtils.isEmpty(verParams.value[key])) {
          isOk = false
        }
      } else if (key === 'vCounterNote' || key === 'vEfficacyEffect' || key === 'vCapacityUsage' || key === 'vUseCautionNote') {
        if (!commonUtils.checkByte(verParams.value[key], 1000)) {
          isOk = false
          errorMsg = t('common.msg.byte_msg2', { byteSize: commonUtils.setNumberComma(1000) })
        }
      } else if (commonUtils.isEmpty(verParams.value[key])) {
        isOk = false
      }

      if (!isOk) {
        commonUtils.showErrorMessage(key, errorMsg)
      }

      return isOk
    }

    const getEvaluateSearchInfo = async (item) => {
      verParams.value.vEvaluateno = item.vEvaluateno
      verParams.value.vEvaluateCd = item.vEvaluateCd
      verParams.value.vEvaluateNm = item.vEvaluateNm

      const mainMateDefault = {
        vMateEvalCd: '',
        vMateFuncCd: '',
        vFlagRequired: 'N',
        vFlagTo100: 'N',
        vFlagMainIngredientMate: 'Y',
        vFlagPermissionMate: 'Y'
      }

      const result = await selectPermissionNoMateList({ vEvaluateCd: item.vEvaluateCd, vPlantCd: store.getters.getNoteInfo().vPlantCd })
      if (result) {
        result.forEach(item => {
          const mainMateList = verParams.value.mainMateList.filter(vo => vo.vKey === item.vKey)
          if (mainMateList.length === 0) {
            verParams.value.mainMateList.push({ ...mateDefaultObj, ...mainMateDefault, ...item })
          }
        })
      }
    }

    const fnOpenEvaluateSearchPop = () => {
      const plantCd = store.getters.getNoteInfo().vPlantCd

      if (commonUtils.isEmpty(plantCd)) {
        openAsyncAlert({ message: '플랜트를 선택해 주세요.' })
        return
      }

      popParams.value = {}
      popSelectFunc.value = getEvaluateSearchInfo

      fnOpenPopup('PermissionNoSearchPop')
    }

    const removeEvaluateInfo = () => {
      verParams.value.vEvaluateno = ''
      verParams.value.vEvaluateCd = ''
      verParams.value.vEvaluateNm = ''

      verParams.value.mainMateList = [ ...verParams.value.mainMateList.filter(vo => vo.vFlagPermissionMate !== 'Y') ]
    }

    const changeQsTypeCd = () => {
      const noteInfo = store.getters.getNoteInfo()
      const newVersionInfo = { ...noteInfo.versionInfo, ...verParams.value }
      const newInfo = { ...noteInfo, ...{ versionInfo: newVersionInfo } }

      fnChangeNoteInfo(newInfo)
    }

    const fnFlagPermissionEvent = (value) => {
      if (value !== 'Y') {
        removeEvaluateInfo()
      }
    }

    const init = async () => {
      await findCodeList(arrMstCode)
      fragDivList.value = commonUtils.getCodeList(codeGroupMaps, 'LNC11', 'BKR')
      verParams.value = { ...verParams.value, ...props.versionInfo }

      if (commonUtils.isNotEmpty(verParams.value.vCounterInvenCd)) {
        verParams.value.vCounterNmTemp = '[' + verParams.value.vCounterSpCd + '] ' + verParams.value.vCounterInvenNm
      } else {
        verParams.value.vCounterNmTemp = verParams.value.vCounterContNm
      }
    }

    init()

    watch(() => reqInfo.value, (newValue) => {
      verParams.value = { ...verParams.value, ...newValue.versionInfo }

      if (commonUtils.isNotEmpty(verParams.value.vCounterInvenCd)) {
        verParams.value.vCounterNmTemp = '[' + verParams.value.vCounterSpCd + '] ' + verParams.value.vCounterInvenNm
      } else {
        verParams.value.vCounterNmTemp = verParams.value.vCounterContNm
      }
    })

    watch(() => props.versionInfo, (newValue) => {
      verParams.value = { ...verParams.value, ...newValue }
    })

    watch(() => storedNoteInfo.value, async (newVal) => {
      if (newVal && newVal.versionInfo) {
        const vQsTypeCd = newVal.versionInfo.vQsTypeCd
        const vMeetingDt = newVal.vMeetingDt
        const bufferInfo = codeGroupMaps.value['SA_NOTE_QS_TYPE'].filter(item => item.vSubCode === vQsTypeCd)[0]
        let date = ''
        if (bufferInfo && bufferInfo.vBuffer3) {
          date = bufferInfo.vBuffer3
        }

        if (commonUtils.isNotEmpty(date)) {
          verParams.value.vValuateTime = date
        }

        if (commonUtils.isNotEmpty(vMeetingDt) && commonUtils.isNotEmpty(date)) {
           const resultDtm = await selectEvaluateLimitedDtm({ vStartDtm: vMeetingDt, vDay: date })

           if (resultDtm) {
             verParams.value.vTimeLimit = resultDtm
           }
        }
      }
    })

    return {
      codeGroupMaps,
      fragDivList,
      verParams,
      searchParams,
      commonUtils,
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenMateSearchPop,
      getSearchPerfMateResult,
      getSearchNewMateResult,
      getSearchRequMateResult,
      getSearchMainMateResult,
      fnCounterSearchPop,
      getCounterInfo,
      removeCounterInfo,
      fnOpenEvaluateSearchPop,
      removeEvaluateInfo,
      fnValidateAll,
      fnValidate,
      changeQsTypeCd,
      fnFlagPermissionEvent,
      notAdd,
      resetMateList,
      changeCounterTypeCd,
    }
  }
}
</script>

<style scoped>
  td.inside-td .ui-table__contents th + td + th { padding-left: 2rem; }
</style>
No newline 