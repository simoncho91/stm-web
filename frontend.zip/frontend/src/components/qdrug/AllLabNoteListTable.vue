<template>
  <div class="note-table">
    <div class="note-table__inner">
      <table class="ui-table ui-table__td--40 text-center">
        <colgroup>
          <col style="width: 10.3%" />
          <col style="width: 9%" />
          <col style="width: 9%" />
          <col style="width: auto" />
          <col style="width: 9%" />
          <col style="width: 9%" />
          <col style="width: 9%" />
          <col style="width: 9%" />
          <col style="width: 4rem" v-if="!commonUtils.checkAuth('S000333')"/>
          <col style="width: 8rem" />
        </colgroup>
        <thead>
          <tr>
            <th>상태</th>
            <th>허가번호</th>
            <th>브랜드</th>
            <th>내용물명</th>
            <th>연구담당자</th>
            <th>생성일</th>
            <th>파일럿시기</th>
            <th>출시시기</th>
            <th v-if="!commonUtils.checkAuth('S000333')">복사</th>
            <th></th>
          </tr>
        </thead>
        <tbody v-if="info.list && info.list.length > 0">
          <template v-for="(vo, index) in info.list" :key="index">
            <tr :class="vo.isOpenStatus ? 'is-active' : ''">
              <td>{{ vo.vStatusNm }}</td>
              <td>{{ vo.vEvaluateno }}</td>
              <td>{{ vo.vBrdNm }}</td>
              <td class="tit">
                <div class="tit__inner">
                  <a href="javascript:void(0)" class="tit-link" @click.prevent="goDetailPage(vo)">
                    <span class="txt_blue">{{ vo.vContCd }}</span> {{vo.vContNm}}
                  </a>
                </div>
              </td>
              <td>{{ vo.vUsernm }}</td>
              <td>{{ commonUtils.changeStrDatePattern(vo.vRegDtm) }}</td>
              <td>{{ commonUtils.changeStrDatePattern(vo.vPilotDt) }}</td>
              <td>{{ commonUtils.changeStrDatePattern(vo.vMassProdDt) }}</td>
              <td v-if="!commonUtils.checkAuth('S000333')">
                  <button
                    type="button"
                    class="copy__button--icon copy__button--icon-copy"
                    @click="goCopy(vo.vLabNoteCd)"
                  >
                  </button>
              </td>
              <td>
                <button
                  v-if="vo.vStatusCd !== 'LNC06_01'"
                  type="button"
                  class="ui-button__accordion"
                  @click="fnOpenStatus(vo)"></button>
              </td>
            </tr>
            <tr class="tr-process" :class="vo.isOpenStatus ? 'is-active' : ''" v-if="vo.nSort === vo.nRowCnt">
              <!-- 활성화시 tr-process 옆에 is-active 추가 -->
              <td :colspan="!commonUtils.checkAuth('S000333') ? 10 : 9">
                <NoteProcessBar
                  v-if="vo.progressInfo && vo.progressInfo.length > 0"
                  :progress-info="vo.progressInfo"
                  :is-big="false"
                  :is-show-date="true"
                  :is-cancel="vo.vFlagCancel == 'Y' ? true : false"
                >
                </NoteProcessBar>
              </td>
            </tr>
          </template>
        </tbody>
        <tbody v-else>
          <tr>
            <td :colspan="!commonUtils.checkAuth('S000333') ? 10 : 9">
              <div class="no-result">
                {{ t('common.msg.no_data') }}
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <div class="board-bottom">
    <div class="board-bottom__inner">
      <Pagination :page-info="info.page" @click="onPaging"> </Pagination>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, inject, watch } from 'vue'
import { useStore } from 'vuex'
import { useQdrugRequest } from '@/compositions/qdrug/useQdrugRequest'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'

export default {
  name: 'AllLabNoteListTable',
  components: {
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
    NoteProcessBar: defineAsyncComponent(() => import('@/components/labcommon/NoteProcessBar.vue')),
  },
  props: {
    resultList: {
      type: Array,
      default: () => {
        return []
      }
    },
    resultPage: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  emits: ['onPaging'],
  setup(props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const store = useStore()
    const noteType = store.getters.getNoteType()
    const info = ref({
      list: [],
      page: {}
    })

    const {
      goModify,
      goView,
    } = useQdrugRequest()

    const {
      selectProgressBar
    } = useProcessCommon()

    const {
      fnSetRecentLog,
    } = useLabCommon()

    const onPaging = (pg) => {
      context.emit('onPaging', pg)
    }

    const goDetailPage = async (item) => {
      if (commonUtils.isNotEmpty(item.vContCd)) {
        item.vPageType = 'prd'
        await fnSetRecentLog(item)
      }
      sessionStorage.removeItem('searchParamsDashboardSA')
      goView(item.vLabNoteCd)
    }

    const fnOpenStatus = async (item) => {
      const lastIdx = item.nRowCnt
      const list = info.value.list
      const lastInfo = list.filter(v => v.vLabNoteCd === item.vLabNoteCd && v.nSort === lastIdx)

      if (lastInfo && lastInfo.length > 0) {
        lastInfo[0].isOpenStatus = !lastInfo[0].isOpenStatus

        if (lastInfo[0].progressCall !== 'Y') {
          const result = await selectProgressBar({ vLabNoteCd: item.vLabNoteCd })
          
          lastInfo[0].progressInfo = result.progressInfo
          lastInfo[0].vFlagCancel = result.vFlagCancel == undefined ? 'N' : result.vFlagCancel

          lastInfo[0].progressCall = 'Y'
        }
      }
    }

    const goCopy = (vLabNoteCd) => {
      goModify(vLabNoteCd, 'Y')
    }

    watch(() => props.resultList, (newVal) => {
      info.value.list = newVal
    })

    watch(() => props.resultPage, (newVal) => {
      info.value.page = newVal
    })

    return {
      t,
      commonUtils,
      onPaging,
      goDetailPage,
      fnOpenStatus,
      goCopy,
      info,
    }
  }
}
</script>