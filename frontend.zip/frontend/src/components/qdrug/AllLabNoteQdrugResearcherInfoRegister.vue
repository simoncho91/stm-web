<template>
  <div class="arrordion-item is-active">
    <div class="arrordion-header">
      <div class="arrordion-title">연구원 정보</div>
      <button type="button" class="ui-button__accordion"></button>
    </div>
    <div class="arrordion-body">
      <div class="basic-info__table researcher-information-table">
        <table class="ui-table__contents">
          <colgroup>
            <col style="width:17rem">
            <col style="width:auto">
            <col style="width:17rem">
            <col style="width:auto">
          </colgroup>
          <tbody>
            <tr>
              <th>SL 담당자<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td>
                <div class="form-flex form-flex-error">
                  <div class="search-form ui-form-box__width--340 ui-form-box__max-width--230" 
                      id="error_wrap_vSlUserid"
                  >
                    <ap-input
                      v-model:value="regParams.vSlUsernm"
                      input-class="ui-input__width--full"
                      placeholder="검색어를 입력하세요."
                      :readonly="true"
                      @click="fnUserSearchPop('Sl')"
                    >
                    </ap-input>
                    <span class="error-msg" id="error_msg_vSlUserid"></span>
                  </div>
                  <button type="button" class="ui-button ui-button__bg--lightgray ml-5" @click="deleteResearcherInfo('Sl')">삭제</button>
                </div>
              </td>
              <th>브랜드 담당 PM<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td>
                <div class="form-flex form-flex-error">
                  <div class="search-form ui-form-box__width--340 ui-form-box__max-width--230" 
                      id="error_wrap_vBrdUserid"
                  >
                    <ap-input
                      v-model:value="regParams.vBrdUsernm"
                      input-class="ui-input__width--full"
                      placeholder="검색어를 입력하세요."
                      :readonly="true"
                      @click="fnUserSearchPop('Brd')"
                    >
                    </ap-input>
                    <span class="error-msg" id="error_msg_vBrdUserid"></span>
                  </div>
                  <button type="button" class="ui-button ui-button__bg--lightgray ml-5" @click="deleteResearcherInfo('Brd')">삭제</button>
                </div>
              </td>
            </tr>
            <tr>
              <th>향 담당자<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td colspan="3">
                <div class="form-flex form-flex-error">
                  <div class="search-form ui-form-box__width--340 ui-form-box__max-width--230" id="error_wrap_vPerfUserid">
                    <ap-input
                      v-model:value="regParams.vPerfUsernm"
                      input-class="ui-input__width--full"
                      placeholder="검색어를 입력하세요."
                      :readonly="true"
                      @click="fnUserSearchPop('Perf')"
                    >
                    </ap-input>
                    <span class="error-msg" id="error_msg_vPerfUserid"></span>
                  </div>
                  <button type="button" class="ui-button ui-button__bg--lightgray ml-5" @click="deleteResearcherInfo('Perf')">삭제</button>
                </div>
              </td>
            </tr>
            <tr>
              <th>연구 담당자<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td>
                <div class="form-flex form-flex-error">
                  <div class="search-form ui-form-box__width--340 ui-form-box__max-width--230"  id="error_wrap_vUserid">
                    <ap-input
                      v-model:value="regParams.vUsernm"
                      input-class="ui-input__width--full"
                      placeholder="검색어를 입력하세요."
                      :readonly="true"
                      @click="fnUserSearchPop('CHG')"
                    >
                    </ap-input>
                    <span class="error-msg" id="error_msg_vUserid"></span>
                  </div>
                  <button type="button" class="ui-button ui-button__bg--lightgray ml-5" @click="deleteResearcherInfo('CHG')">삭제</button>
                </div>
              </td>
              <th>담당부서<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
              <td>
                <DeptTree
                  ref="deptTree"
                  v-model:deptcd="regParams.vDeptCd"
                  udeptcd="1"
                />
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @selectFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, ref, inject, watch, computed } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useActions } from 'vuex-composition-helpers'
import { useStore } from 'vuex'

export default {
  name: 'AllLabNoteQdrugResearcherInfoRegister',
  props: {
    flagAction: {
      type: String,
      default: 'R'
    }
  },
  components: {
    DeptTree: defineAsyncComponent(() => import('@/components/comm/DeptTree.vue')),
    UserSearchPop: defineAsyncComponent(() => import('@/components/comm/popup/UserSearchPop.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
  },
  setup (props) {
    const reqInfo = inject('reqInfo')
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert } = useActions(['openAsyncAlert'])
    const store = useStore()
    const perfUserInfo = computed(() => store.getters.getPerfUserInfo())
    let searchFlag = ''

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      fnChangeNoteInfo,
    } = useLabCommon()

    const regParams = ref({
      vSlUserid: '',
      vSlUsernm: '',
      vBrdUserid: '',
      vBrdUsernm: '',
      vPerfUserid: '',
      vPerfUsernm: '',
      vUserid: '',
      vUsernm: '',
      vDeptCd: '10011',
    })

    const fnUserSearchPop = (flag) => {
      searchFlag = flag

      if (flag !== 'Brd') {
        popParams.value.searchFlag = 'LAB'
        popParams.value.vDeptCd = '10011'
      } else {
        popParams.value.searchFlag = 'ALL'
        popParams.value.vDeptCd = ''
      }
      popSelectFunc.value = getUserSearchInfo
      fnOpenPopup('UserSearchPop')
    }

    const deleteResearcherInfo = (flag) => {
      if (flag === 'CHG') {
        regParams.value.vUsernm = ''
        regParams.value.vUserid = ''
        regParams.value.vDeptCd = '10011'

        fnValidate('vUserid')
      } else {
        regParams.value['v' + flag + 'Usernm'] = ''
        regParams.value['v' + flag + 'Userid'] = ''

        fnValidate('v' + flag + 'Userid')
      }
    }

    const getUserSearchInfo = (item) => {
      if (searchFlag === 'CHG') {
        const labor = item.vLabor

        if (commonUtils.isNotEmpty(labor)) {
          regParams.value.vUsernm = item.vUsernm
          regParams.value.vUserid = item.vUserid
          regParams.value.vDeptCd = item.vSigmaDeptcd

          const noteInfo = store.getters.getNoteInfo()
          const newInfo = { ...noteInfo, ...{ vUserid: item.vUserid, vDeptCd: item.vSigmaDeptcd } }

          fnChangeNoteInfo(newInfo)
          fnValidate('vUserid')
        } else {
          openAsyncAlert({ message: 'SAP 연구원코드가 존재하지 않습니다.<br>다른 연구원을 지정해주시기 바랍니다.' })
          regParams.value.vUsernm = ''
          regParams.value.vUserid = ''
          regParams.value.vDeptCd = '10011'
        }
      } else {
        regParams.value['v' + searchFlag + 'Usernm'] = item.vUsernm
        regParams.value['v' + searchFlag + 'Userid'] = item.vUserid

        fnValidate('v' + searchFlag + 'Userid')
      }
    }

    const fnValidateAll = (arrChkKey) => {
      let isOk = true
      commonUtils.hideErrorMessageAll(arrChkKey)

      arrChkKey.forEach(key => {
        if (!fnValidate(key)) {
          isOk = false
        }
      })

      return isOk
    }

    const fnValidate = (key) => {
      let isOk = true
      let errorMsg = '필수 입력 사항입니다.'
      commonUtils.hideErrorMessage(key)

      if (commonUtils.isEmpty(regParams.value[key])) {
        isOk = false
      }

      if (!isOk) {
        commonUtils.showErrorMessage(key, errorMsg)
      }

      return isOk
    }

    watch(() => reqInfo.value, (newValue) => {
      if (commonUtils.isEmpty(newValue.vDeptCd)) {
        newValue.vDeptCd = '10011'
      }

      regParams.value = { ...regParams.value, ...{
        vUserid: newValue.vUserid,
        vUsernm: newValue.vUsernm,
        vDeptCd: newValue.vDeptCd,
        vSlUserid: newValue.vSlUserid,
        vSlUsernm: newValue.vSlUsernm,
        vBrdUserid: newValue.vBrdUserid,
        vBrdUsernm: newValue.vBrdUsernm,
        vPerfUserid: newValue.vPerfUserid,
        vPerfUsernm: newValue.vPerfUsernm,
      } }
    })

    watch(() => perfUserInfo.value, (newValue) => {
      if (commonUtils.isNotEmpty(newValue)) {
        const perfUserid = perfUserInfo.value.split('/')[0]
        const perfUsernm = perfUserInfo.value.split('/')[1]
        regParams.value.vPerfUserid = perfUserid
        regParams.value.vPerfUsernm = perfUsernm
        fnValidate('vPerfUserid')
      } else {
        regParams.value.vPerfUserid = ''
        regParams.value.vPerfUsernm = ''
      }
    })

    return {
      popupContent,
      popParams,
      popSelectFunc,
      regParams,
      fnUserSearchPop,
      deleteResearcherInfo,
      fnValidateAll,
      fnValidate,
    }
  }
}
</script>