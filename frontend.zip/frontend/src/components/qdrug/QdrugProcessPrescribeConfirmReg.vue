<template>
  <div class="contents-box__inner">
    <table class="ui-table__th--bg-gray">
      <colgroup>
        <col style="width:14rem">
        <col style="width:auto">
        <col style="width:14rem">
        <col style="width:auto">
      </colgroup>
      <tbody>
        <tr>
          <th>내용물명</th>
          <td>
            {{ gate02CheckParam.vContNm }}
          </td>
          <th>내용물 코드</th>
          <td>
            {{ gate02CheckParam.vContCd }}
          </td>
        </tr>
        <tr>
          <th>VER. - LOT</th>
          <td>
            {{ gate02CheckParam.vVersionTxt }} - {{ gate02CheckParam.vLotNm }}
          </td>
          <th>연구담당자</th>
          <td>
            {{ gate02CheckParam.vUsernm }} ({{ gate02CheckParam.vUserid }} / {{ gate02CheckParam.vDeptNm }})
          </td>
        </tr>
        <tr>
          <th>브랜드</th>
          <td>{{ gate02CheckParam.vBrdNm }}</td>
          <th>Plant</th>
          <td>[{{ gate02CheckParam.vPlantCd }}] {{ gate02CheckParam.vPlantNm }}</td>
        </tr>
      </tbody>
    </table>

    <div class="divide-line"></div>

    <div class="ui-table__wrap">
      <table class="ui-table text-center ui-table__td--40">
        <tbody>
          <tr class="tr-contents">
            <td class="inside-td">
              <div class="inside-td__item mt-15">
                <ProcessPQCGateCheckList
                  v-if="resultVo?.pqcList && resultVo?.pqcList.length > 0"
                  v-model:pqc-list="resultVo.pqcList"
                  :tr-map="resultVo.trMap"
                  :gate-flag="'GATE2'"
                  v-model:pqc-user-comment="pqcUserComment"
                  ref="pqc"
                >
                </ProcessPQCGateCheckList>
                <ProcessTrGate01List
                  v-if="resultVo?.trGate1List && resultVo?.trGate1List.length > 0"
                  :tr-gate1-list="resultVo.trGate1List"
                >
                </ProcessTrGate01List>
              </div>

              <div class="inside-td__item">
                <ApprovalRegister
                  :appr-cd="resultVo?.rvo.vGate0ApprCd"
                  :appr-class="'LAB002_'+ noteType"
                  :default-list="resultVo?.userList"
                  ref="appr"
                  @callbackFunc="fnApprSave"
                >
                </ApprovalRegister>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <div class="page-bottom">
    <div class="page-bottom__inner">
      <div class="ui-buttons ui-buttons__right">
        <button type="button" class="ui-button ui-button__bg--skyblue" @click.prevent="fnAppr()">승인요청</button>
        <button type="button" class="ui-button ui-button__bg--gray" @click="goList()">목록</button>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'

export default {
  name: 'QdrugProcessPrescribeConfirmReg',
  props: {
    vActionFlag: {
      type: String,
      default: 'R'
    },
    checkParams: {
      type: Object,
      default: () => {
        return {}
      }
    },
  },
  emits: ['update:vActionFlag'],
  components: {
    ProcessPQCGateCheckList: defineAsyncComponent(() => import('@/components/process/ProcessPQCGateCheckList.vue')),
    ProcessTrGate01List: defineAsyncComponent(() => import('@/components/process/ProcessTrGate01List.vue')),
    ApprovalRegister: defineAsyncComponent(() => import('@/components/comm/ApprovalRegister.vue')),
  },
  setup (props, context) {
    const { openAsyncAlert, openAsyncConfirm } = useActions(['openAsyncAlert','openAsyncConfirm'])
    const gate02CheckParam = ref(props.checkParams)
    const commonUtils = inject('commonUtils')
    const pqc = ref(null)
    const appr = ref(null)
    const resultVo = ref(null)
    const pqcUserComment = ref(null)

    const {
      noteType,
      selectLabNoteGate2Reg,
      saveLabNoteGate02ApprovalRequest,
    } = useProcessCommon()

    const goList = () => {
      context.emit('update:vActionFlag', 'L')
    }

    const fnAppr = () => {
      if(!pqc.value.fnValidateAll()){
        openAsyncAlert({ message: '필수 입력사항을 확인해 주세요.' })
        return 
      }

      if (appr.value) {
        appr.value.fnApprovalOpinionPop()
      }
    }

    const fnApprSave = async (draftOpinion) => {
      if (!await openAsyncConfirm({ message: '결재 의뢰 하시겠습니까?' })) {
        return
      }

      if (appr.value) {
        const payload = {
          vNoteType: noteType,
          vLabNoteCd: props.checkParams.vLabNoteCd,
          nVersion: props.checkParams.nVersion,
          vApprTypeCd: 'LAB002_' + noteType,
          vContPkCd: props.checkParams.vContPkCd,
          vLotCd: props.checkParams.vLotCd,
          vLotNm: props.checkParams.vLotNm,
          vContCd: props.checkParams.vContCd,
          vContNm: props.checkParams.vContNm,
          // PQC GATE1, GATE2 함께 사용하기 때문에 단일값이지만 배열로 넘김
          arrContPkCd: props.checkParams.arrContPkCd,
          arrLotCd: props.checkParams.arrLotCd,
          apprReqInfo: {
            apprInfo: appr.value.apprInfo,
            apprList: appr.value.apprList
          },
          vPqcUserComment: pqcUserComment.value,
          pqcCheckList: resultVo.value.pqcList,
        }

        payload.apprReqInfo.apprInfo.vDraftOpinion = draftOpinion

        const result = await saveLabNoteGate02ApprovalRequest(payload)

        if (result && result === 'SUCC') {
          await openAsyncAlert({ message: '결재 요청되었습니다.' })
          goList()
        }
      }
    }

    const init = async () => {
      resultVo.value = await selectLabNoteGate2Reg(props.checkParams)
    }

    init()

    return {
      pqc,
      appr,
      commonUtils,
      gate02CheckParam,
      resultVo,
      pqcUserComment,
      noteType,
      goList,
      fnAppr,
      fnApprSave,
    }
  }
}
</script>