<template>
  <div class="basic-information">
    <div class="basic-information__inner">
      <div class="basic-information__info">
        <div class="basic-information__detail">
          <div class="basic-information__img">
            <img v-if="info.vProdType2Cd" :src="'/product/' + info.vProdType2Cd + '.png'" />
          </div>
          <div class="basic-information__name">{{ info.vUsernm }}</div>
        </div>
        <div class="basic-information__brand">{{ info.vBrdNm }}</div>
        <div class="basic-information__title">{{ info.vContNm }}</div>
        <div class="basic-information__status">
          <div>{{ info.vLabTypeNm }}</div>
          <div>{{ info.vStatusNm }}</div>
        </div>
        <div class="basic-information__tag--wrap" v-if="info.funcTagList">
          <div class="basic-information__tags">
            <span
              v-for="(vo, idx) in info.funcTagList" :key="'tag_' + idx"
              :class="'basic-information__tag basic-information__tag--' + vo.vClassnm"
            ># {{ vo.vSubCodenm }}</span>
          </div>
        </div>
      </div>
      <div class="basic-information__table">
        <div class="ui-table__basic-information--wrap">
          <table class="ui-table__basic-information note_contents_tb">
            <colgroup>
              <col style="width:16rem">
              <col style="width:auto">
              <col style="width:16rem">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr v-if="commonUtils.isNotEmpty(info.vNoteContNm)">
                <th>실험노트 제품명</th>
                <td colspan="3">
                  {{ info.vNoteContNm }}
                </td>
              </tr>
              <tr v-if="info.vFlagOem === 'Y'">
                <th>브랜드</th>
                <td colspan="3">
                  {{ info.vBrdNm }} [OEM: {{ info.vOemManufacturer }}]
                </td>
              </tr>
              <tr>
                <th>플랜트</th>
                <td colspan="3">
                  {{ info.vPlantNm }} / {{ info.vSiteTypeNm }}
                  <button
                    v-if="showPlantModifyBtn()"
                    type="button"
                    class="ui-button ui-button__height--28 ml-10 ui-button__border--blue"
                    @click="fnPlantRepresentPop()"
                  >대표 플랜트 변경</button>
                </td>
              </tr>
              <tr>
                <th>예산코드</th>
                <td colspan="3">
                  <div class="form-flex">
                    <div>
                      <template v-if="info.pjtList.length > 0">
                        <template v-for="(vo, index) in info.pjtList" :key="'pjt_' + index">
                          <a href="#" class="detail-link">[{{vo.vRpmsCd}}] {{ vo.vPjtNm }}</a><br>
                        </template>
                      </template>
                    </div>
                  </div>
                </td>
              </tr>
              <tr>
                <th>내용물명</th>
                <td colspan="3">
                  {{ info.vContNm }}
                </td>
              </tr>
              <tr>
                <th>내용물 코드</th>
                <td>{{ info.vContCd }}</td>
                <th>제품 코드</th>
                <td>{{ info.vPrdCd }}</td>
              </tr>
              <tr>
                <th>제품유형</th>
                <td>
                  {{ info.vProdType1Nm }} {{ commonUtils.isNotEmpty(info.vProdType1Nm) ? '-' : '' }} {{ info.vProdType2Nm }}
                  <template v-if="Number(info.vProdType2Cd.replace('MTR02_', '')) > 90">
                    ({{ info.vProdTypeNote }})
                  </template>
                </td>
                <th>TDD 제품유형</th>
                <td>
                  <template v-if="commonUtils.isNotEmpty(info.vTddProdType1Nm)">
                    {{ info.vTddProdType1Nm }} > {{ info.vTddProdType2Nm }}
                  </template>
                </td>
              </tr>
              <tr>
                <th>신상품 여부</th>
                <td>
                  {{ info.vFlagNew === 'Y' ? 'NEW' : 'AD' }}
                </td>
                <th>SHELF LIFE</th>
                <td>
                  <template v-if="info.vShelflifeStatus === 'SLS020' || info.vShelflifeStatus === 'SLS030' || info.vShelflifeStatus === 'SLS040'">
                    {{ info.vShelfLife }}
                    <template v-if="commonUtils.checkAuth('S000000') || myInfo.loginId === info.vUserid">
                      <button 
                        type="button"
                        class="ui-button ui-button__height--28 ml-10 ui-button__border--blue"
                        @click="fnShelfLifeModify()"
                      >변경요청</button>
                    </template>
                  </template>
                </td>
              </tr>
              <tr>
                <th>의약외품 여부</th>
                <td>
                  {{ info.vFlagSanitaryAid === 'Y' ? 'YES' : 'NO'}}
                </td>
              </tr>
              <tr>
                <th>적용 부위/방식</th>
                <td>
                  {{ info.vPartNm }} / {{ info.vLeaveTypeNm }}
                </td>
                <th>용기정보</th>
                <td>
                  {{ info.vContainerNm }} {{ commonUtils.isNotEmpty(info.vContainerEtc) ? '-' : '' }} {{ info.vContainerEtc }}
                </td>
              </tr>
              <tr>
                <th>생산회의</th>
                <td>
                  {{ commonUtils.changeStrDatePattern(info.vMeetingDt) }}
                </td>
                <th>파일럿<br>(신고/허가 미반영)</th>
                <td>
                  {{ commonUtils.changeStrDatePattern(info.vPilotDt) }}
                </td>
              </tr>
              <tr>
                <th>ONE POINT (기술관점)</th>
                <td colspan="3">
                  {{ info.vOnePointTech }}
                </td>
              </tr>
              <tr>
                <th>출시국가/시기</th>
                <td colspan="3" class="inside-td inside-td__nation">
                  <table class="ui-table__product">
                    <colgroup>
                      <col style="width:10rem">
                    </colgroup>
                    <tbody>
                      <tr
                        v-for="(key, index) in Object.keys(releaseMap)"
                        :key="'countryList_' + index"
                        class="ui-table__contents--item"
                      >
                        <th>{{ releaseMap[key].ariaNm }}</th>
                        <td>
                          <template v-if="info['vFlagRelease' + key] === 'N'">
                            대상아님
                          </template>
                          <template v-else-if="info['vFlagRelease' + key] === 'U'">
                            미정
                          </template>
                          <template v-else>
                            <template v-for="(vo, idx) in releaseMap[key].countryList" :key="'release_' + idx">
                              {{ idx !== 0 ? ', ' : '' }}{{ vo.vSubCodenm }} ({{commonUtils.changeStrDatePattern(vo.vTagBuffer1, '.')}})
                            </template>
                          </template>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              <tr>
                <th>임상실험</th>
                <td colspan="3">
                  <UploadFileView
                    v-if="commonUtils.isNotEmpty(info.vLabNoteCd)"
                    uploadid="SA_NOTE_CLINICAL_TEST"
                    :recordid="info.vLabNoteCd"
                  >
                  </UploadFileView>
                </td>
              </tr>
              <tr>
                <th>첨부파일</th>
                <td colspan="3">
                  <UploadFileView
                    v-if="commonUtils.isNotEmpty(info.vLabNoteCd)"
                    uploadid="SA_NOTE_ATT01"
                    :recordid="info.vLabNoteCd"
                  >
                  </UploadFileView>
                </td>
              </tr>
              <tr>
                <th>비고</th>
                <td colspan="3" v-html="commonUtils.removeHTMLChangeBr(info.vNote)"></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @callbackFunc="popSelectFunc"
        @selectFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, ref, inject, watch } from 'vue'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useActions } from 'vuex-composition-helpers'
import { useStore } from 'vuex'

export default {
  name: 'AllLabNoteQdrugBasicInfoView',
  components: {
    UploadFileView: defineAsyncComponent(() => import('@/components/comm/UploadFileView.vue')),
    PlantRepresentChangePop: defineAsyncComponent(() => import('@/components/labcommon/popup/PlantRepresentChangePop.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
  },
  setup () {
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert, openAsyncConfirm } = useActions(['openAsyncAlert', 'openAsyncConfirm'])
    const reqInfo = inject('reqInfo')
    const store = useStore()
    const myInfo = store.getters.getMyInfo()
    const noteType = store.getters.getNoteType()

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      releaseMap,
    } = useLabCommon()

    const info = ref({
      vBrdCd: '',
      vBrdNm: '',
      vFlagOem: '',
      vOemManufacturer: '',
      vPlantCd: '',
      vSiteType: '',
      pjtList: [],
      releaseList: [],
      vContNm: '',
      vNoteContNm: '',
      vPrdCd: '',
      vContCd: '',
      vFlagNew: '',
      vProdType1Cd: '',
      vProdType1Nm: '',
      vProdType2Cd: '',
      vProdType2Nm: '',
      vProdTypeNote: '',
      vTddProdType1Cd: '',
      vTddProdType1Nm: '',
      vTddProdType2Cd: '',
      vTddProdType2Nm: '',
      vPartCd: '',
      vPartNm: '',
      vLeaveType: '',
      vLeaveTypeNM: '',
      vFlagReleaseASIA: '',
      vFlagReleaseASEAN: '',
      vFlagReleaseETC: '',
      vFlagReleaseAllASIA: '',
      vFlagReleaseAllASEAN: '',
      vFlagReleaseAllETC: '',
      vReleaseAllDtASIA: '',
      vReleaseAllDtASEAN: '',
      vReleaseAllDtETC: '',
      vPilotDt: '',
      vMeetingDt: '',
      vContainerCd: '',
      vContainerNm: '',
      vContainerEtc: '',
      vUsernm: '',
      vPlantNm: '',
      vSiteTypeNm: '',
      vNote: '',
      vFlagSanitaryAid: '',
    })

    const fnPlantRepresentPop = () => {
      popParams.value = {
        vLabNoteCd: reqInfo.value.vLabNoteCd,
        vPlantCd: reqInfo.value.vPlantCd,
        vSiteType: reqInfo.value.vSiteType,
        vContCd: reqInfo.value.vContCd,
        vNoteType: noteType
      }

      popSelectFunc.value = fnPopSaveResult
      fnOpenPopup('PlantRepresentChangePop')
    }

    const fnPopSaveResult = () => {
      window.location.reload(true)
    }

    const showPlantModifyBtn = () => {
      let isVisible = false

      if ((myInfo.loginId === info.value.vUserid || commonUtils.checkAuth('S000000')) && info.value.vStatusCd !== 'LNC06_50') {
        isVisible = true
      }

      return isVisible
    }

    const fnShelfLifeModify = () => {
      const query = {
        vContCd: reqInfo.value.vContCd,
        vLabNoteCd: reqInfo.value.vLabNoteCd,
        vNoteType: noteType
      }

      router.push({ path: '/hbd/all-lab-note-shelf-register', query })
    }

    watch(() => reqInfo.value, (newValue) => {
      if (newValue && newValue.funcTagList) {
        const tagColor = ['green', 'blue', 'brown']
        newValue.funcTagList.forEach((item, idx) => {
          item.vClassnm = tagColor[idx % 3]
        })
      }

      info.value = { ...info.value, ...newValue }

      if (info.value.releaseList && info.value.releaseList.length > 0) {
        info.value.releaseList.forEach(item => {
          if (commonUtils.isNotEmpty(item.vTag2Cd)) {
            releaseMap.value[item.vBuffer1].countryList.push({ ...item })
          }
        })
      }
    })

    return {
      commonUtils,
      releaseMap,
      info,
      myInfo,
      popupContent,
      popParams,
      popSelectFunc,
      showPlantModifyBtn,
      fnPlantRepresentPop,
      fnShelfLifeModify,
    }
  }
}
</script>