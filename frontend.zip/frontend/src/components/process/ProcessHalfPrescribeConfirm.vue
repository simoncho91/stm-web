<template>
  <ProcessHalfPrescribeConfirmList
    @callbackFunc="setProgressInfo"
  >
  </ProcessHalfPrescribeConfirmList>
</template>

<script>
import { defineAsyncComponent, ref } from 'vue'
import { useStore } from 'vuex'

export default {
  name: 'ProcessHalfPrescribeConfirm',
  components: {
    ProcessHalfPrescribeConfirmList: defineAsyncComponent(() => import('@/components/process/ProcessHalfPrescribeConfirmList.vue')),
  },
  emits: ['callbackFunc'],
  setup (props, context) {
    const store = useStore()
    const noteType = store.getters.getNoteType()

    const setProgressInfo = () => {
      context.emit('callbackFunc')
    }

    return {
      noteType,
      setProgressInfo,
    }
  }
}
</script>