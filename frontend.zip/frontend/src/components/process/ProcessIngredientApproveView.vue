<template>
  <div>

    <div class="contents-box__inner min-height__unset">
      <div class="arrordion-item is-active">
        <div class="arrordion-header">
          <div class="arrordion-title">전성분 정보</div>
        </div>
        <div class="arrordion-body">
          <div class="basic-info__table">
            <table class="ui-table__reset ui-table__ver ui-table__td--40 text-center">
              <colgroup>
                <col style="width:17rem">
                <col style="width:auto">
                <col style="width:17rem">
                <col style="width:auto">
              </colgroup>
              <tbody>
                <tr>
                  <th>내용물코드</th>
                  <td>{{ resData.vMatnr }}</td>
                  <th>회차</th>
                  <td>{{ resData.vZversion }}</td>
                </tr>
                <tr>
                  <th>내용물명</th>
                  <td>{{ resData.vMatnrNm }}</td>
                  <th>등록자</th>
                  <td>{{ resData.vErnamNm }}</td>
                </tr>
                <tr>
                  <th>ZPLM34E/ZPLM34</th>
                  <td>{{ commonUtils.isNotEmpty(resData.vLand) ? (resData.vLand === 'UN' ? 'ZPLM34E' : 'ZPLM34')  : '' }}</td>
                  <th>Leave-on/Wash-off</th>
                  <td>{{ commonUtils.isNotEmpty(resData.vArjart) ? (resData.vArjart === 'L' ? 'Leave-on' : 'Wash-off')  : '' }}</td>
                </tr>
                <tr>
                  <th>국문[알러젠 표기]</th>
                  <td colspan="3">{{ resData.vZtext }}</td>
                </tr>
                <tr>
                  <th>국문[알러젠 미표기]</th>
                  <td colspan="3">{{ resData.vZtextKcp }}</td>
                </tr>
                <tr>
                  <th>영문[알러젠 표기]</th>
                  <td colspan="3">{{ resData.vZtextEn }}</td>
                </tr>
                <tr>
                  <th>영문[알러젠 미표기]</th>
                  <td colspan="3">{{ resData.vZtextEcp }}</td>
                </tr>
                <tr>
                  <th>중문</th>
                  <td colspan="3">{{ resData.vZtextZh }}</td>
                </tr>
                <tr>
                  <th>표시성분</th>
                  <td colspan="3">{{ resData.vDisplayLt }}</td>
                </tr>
                <tr>
                  <th>주의사항</th>
                  <td colspan="3" v-html="resData.vWarningLt"></td>
                </tr>
                <tr>
                  <th>영문 주의사항</th>
                  <td colspan="3" v-html="resData.vWarningLtEn"></td>
                </tr>
                <tr>
                  <th>중문 주의사항</th>
                  <td colspan="3" v-html="resData.vWarningLtZh"></td>
                </tr>
                <tr>
                  <th>전성분 재승인 사유</th>
                  <td colspan="3" v-html="resData.vApprovalNote"></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <div class="page-bottom">
      <div class="page-bottom__inner">
        <div class="ui-buttons ui-buttons__right">
          <button
            type="button"
            class="ui-button ui-button__bg--gray"
            @click="fnGoListPage()"
          >목록</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, inject, ref } from 'vue'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'

export default {
  name: 'ProcessIngredientApproveView',
  props: {
    viewParams: {
      type: Object,
      default: () => {
        return {
          vContPkCd: '',
          vMatnr: '',
          vWerks : '',
          vZversion : '',
          vFlagSAIngr: 'N',
        }
      }
    }
  },
  setup (props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')

    const resData = ref({})

    const {
      selectIngrdApprovalInfo
    } = useProcessCommon()

    const fnGoListPage = () => {
      context.emit('changePage', { actionFlag: 'LIST' })
    }

    const init = async () => {
      if (props.viewParams) {
        resData.value = await selectIngrdApprovalInfo(props.viewParams)

        resData.value.vWarningLt = commonUtils.removeHTMLChangeBr(resData.value.vWarningLt)
        resData.value.vWarningLtEn = commonUtils.removeHTMLChangeBr(resData.value.vWarningLtEn)
        resData.value.vWarningLtZh = commonUtils.removeHTMLChangeBr(resData.value.vWarningLtZh)
        resData.value.vApprovalNote = commonUtils.removeHTMLChangeBr(resData.value.vApprovalNote)

        if (!resData.value) {
          fnGoListPage()
        }
      }
    }

    init()

    return {
      t,
      commonUtils,
      resData,
      fnGoListPage,
    }
  }
}
</script>