<template>
  <div class="contents-box__inner" v-if="reportRegVo">
    <div class="page-bottom">
      <div class="page-bottom__inner">
        <div class="ui-buttons ui-buttons__right">
          <template v-if="commonUtils.checkAuth('S000000|S000003')
            || reportRegVo.epVo.vRegUserid === myInfo.loginId || 'AP491974' === myInfo.loginId">
            <button type="button"
              v-if="reportRegVo.epVo.vApprStatus != 'DOC500' && reportRegVo.epVo.vApprStatus != 'DOC020'"
              class="ui-button ui-button__bg--skyblue" @click="goModify">
              수정
            </button>
            <button type="button" v-if="reportRegVo.epVo.vApprStatus != 'DOC020'"
              class="ui-button ui-button__border--blue" @click="goDelete">
              삭제
            </button>
          </template>
          <button type="button" v-if="commonUtils.isNotEmpty(reportRegVo.epVo.vApprCd)"
            class="ui-button ui-button__bg--blue" @click="fnViewApprOpinion">
            의견보기
          </button>
          <template v-if="commonUtils.isNotEmpty(reportRegVo.epVo.vApprCd)
            && reportRegVo.epVo.vApprStatus != 'DOC010'">
            <template v-if="showApprovalBtn('USR010')">
              <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnApprAccept('ACCEPT')">승인</button>
              <button type="button" class="ui-button ui-button__border--blue" @click="fnApprAccept('REJECT')">반려</button>
            </template>
            <template v-if="showApprovalBtn('USR020')">
              <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnMutual('ACCEPT')">합의</button>
              <button type="button" class="ui-button ui-button__border--blue" @click="fnMutual('REJECT')">거부</button>
            </template>
          </template>
          <button type="button" class="ui-button ui-button__bg--gray" @click="goList">목록</button>
        </div>
      </div>
    </div>
    <div class="p_bold">기본 정보</div>
    <div class="ui-table__wrap mt-15 mb-15">
      <table class="ui-table__reset ui-table__ver">
        <colgroup>
          <col style="width:15%;">
          <col style="width:35%;">
          <col style="width:15%;">
          <col style="width:35%;">
        </colgroup>
        <tbody>
          <tr>
            <th>등록자</th>
            <td>{{ reportRegVo.epVo.vRegUserNm }}</td>
            <th>문서종류</th>
            <td>{{ reportRegVo.epVo.vDocTypenm }}</td>
          </tr>
          <tr>
            <th>문서구분</th>
            <td>{{ reportRegVo.epVo.vFullClassnm }}</td> <!--.replace('>기술원보고서>','')-->
            <th>문서번호</th>
            <td>
              <b>#{{ reportRegVo.epVo.vDeptnm }}({{ reportRegVo.epVo.vDocClassnm }}) {{ reportRegVo.epVo.vYearReg }}-{{
                reportRegVo.epVo.vFinishCd }}</b>
            </td>
          </tr>
          <tr>
            <th>심사 구분</th>
            <td colspan="3">
              <template v-for="(vo, i) in codeGroupMaps['QS_TYPE']" :key="'qsCdVo_' + i">
                <template v-if="reportRegVo.qsVo && reportRegVo.qsVo.vQsType.indexOf(vo.vSubCode) > -1">
                  {{ vo.vSubCodenm }}
                  <br />
                </template>
              </template>
            </td>
          </tr>
          <tr>
            <th>제조방법</th>
            <td colspan="3">
              <template v-for="(vo, index) in codeGroupMaps['MANU_METHOD']" :key="'menu_method_' + index">
                <template v-if="reportRegVo.qsVo && reportRegVo.qsVo.vManuMethod == vo.vSubCode">
                  {{ vo.vSubCodenm }}
                </template>
              </template>
            </td>
          </tr>
          <tr>
            <th>직급</th>
            <td>{{ reportRegVo.epVo.vPositnm }}</td>
            <th>부서</th>
            <td>{{ reportRegVo.epVo.vDeptnm }}</td>
          </tr>
          <tr>
            <th>전화</th>
            <td>{{ reportRegVo.epVo.vPhoneno }}</td>
            <th>이메일</th>
            <td>{{ reportRegVo.epVo.vEmail }}</td>
          </tr>
          <tr>
            <th>기안일</th>
            <td>{{ commonUtils.changeStrDatePattern(reportRegVo.epVo.vRegDtm, '.', 'Y') }}</td>
            <th>보존년한</th>
            <td><b>{{ reportRegVo.epVo.vStorageNm }}</b></td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="mt-20 mb-15">
      <ReferenceView v-if="reportRegVo.epVo.vApprCd" :record-id="reportRegVo.epVo.vApprCd">
      </ReferenceView>
    </div>

    <div class="mt-30 mb-15">
      <div class="p_bold">지정참조</div>
      <div class="ui-table__wrap mt-15">
        <table class="ui-table__reset ui-table__ver">
          <colgroup>
            <col style="width:15%;">
            <col style="width:auto;">
          </colgroup>
          <tbody>
            <tr>
              <th>지정참조</th>
              <td>
                <template v-for="(appointVo, idx) in reportRegVo.appointList" :key="'appointVo_'+idx">
                  {{ appointVo.vRefUsernm }} - <span class="p_bold">{{ appointVo.vRefDeptnm }}</span>&nbsp;
                </template>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <div class="mt-30 mb-15">
      <div class="p_bold">내용물코드</div>
      <div class="ui-table__wrap mt-15">
        <table class="ui-table text-center ui-table__td--40" id="error_wrap_contList">
          <colgroup>
            <col style="width:30%;">
            <col style="width:20%;">
            <col style="width:auto;">
          </colgroup>
          <thead>
            <tr>
              <th>내용물코드</th>
              <th>PLANT</th>
              <th>내용물 명</th>
            </tr>
          </thead>
          <tbody>
            <template v-for="(vo, idx) in reportRegVo.lstMat" :key="'contVo_'+idx">
              <template v-if="vo.vMtart == 'HAL3'">
                <tr>
                  <td>{{ vo.vMatnr }}</td>
                  <td>{{ vo.vPlantCd }}</td>
                  <td>{{ vo.vMaktx }}</td>
                </tr>
              </template>
              <template v-else>
                <tr>
                  <td colspan="3">:: 내용물이 존재하지 않습니다. ::</td>
                </tr>
              </template>
            </template>
          </tbody>
        </table>
      </div>
    </div>

    <div id="secretDocumentArea" class="mt-30 mb-15"
      :style="reportRegVo.epVo.vDocType === 'TYP030' ? 'display:block;' : 'display:none;'">
      <div class="p_bold mb-15">영업비밀문서 정보</div>
      <table class="ui-table text-center ui-table__td--40">
        <colgroup>
          <col style="width:5%;">
          <col style="width:20%;">
          <col style="width:auto;">
          <col style="width:15%;">
          <col style="width:30%;">
        </colgroup>
        <thead>
          <tr>
            <th>No</th>
            <th>자료명</th>
            <th>자료내용</th>
            <th>영업비밀</th>
            <th>관련자료보관소</th>
          </tr>
        </thead>
        <tbody>
          <template v-if="lstSecret && lstSecret.length > 0">
            <tr v-for="(secretVo, idx) in lstSecret" :key="'secretVo_' + idx">
              <td>{{ secretVo.nSeq }}</td>
              <td>{{ secretVo.vSecretNm }}</td>
              <td>{{ secretVo.vSecret }}</td>
              <td>{{ secretVo.nSecretLevel }}</td>
              <td>{{ secretVo.vSecretRoom }}</td>
            </tr>
          </template>
          <template v-else>
            <tr>
              <td colspan="5">:: 등록된 영업 비밀 정보가 없습니다. ::</td>
            </tr>
          </template>
        </tbody>
      </table>
    </div>

    <div class="mt-30 mb-15">
      <ApprovalView v-if="reportRegVo.epVo.vApprCd" 
        :appr-cd="reportRegVo.epVo.vApprCd" 
        appr-class="REPORT" 
        ref="appr"
        v-model:appr-mst-info="apprMstInfo" 
        v-model:appr-user-list="apprUserList" 
        @callbackFunc="fnApprProc"
      >
      </ApprovalView>
    </div>

    <div class="ui-table__wrap mt-15">
      <table class="ui-table__reset ui-table__ver">
        <colgroup>
          <col style="width:25%;">
          <col style="width:auto;">
        </colgroup>
        <tbody>
          <tr>
            <th>제목</th>
            <td>{{ reportRegVo.epVo.vTitle }}</td>
          </tr>
          <tr>
            <td colspan="2" v-html="commonUtils.removeHTMLChangeBr(reportRegVo.epVo.cContent)"></td>
          </tr>
          <tr>
            <th>검색조건</th>
            <td>{{ reportRegVo.epVo.vKeyword }}</td>
          </tr>
          <tr v-if="commonUtils.checkAuth('S000000|S000003')
            || reportRegVo.epVo.vRegUserid === myInfo.loginId || 'AP491974' === myInfo.loginId">
            <template v-if="reportRegVo.epVo.vApprStatus != 'DOC500' && reportRegVo.epVo.vApprStatus != 'DOC020'">
              <th>
                <span class="ui-require"><span class="for-a11y">(필수)</span></span>
                &nbsp;
                보안
              </th>
              <td>
                <AuthSecurityRegister flag-rec="AUTH030" :record-id="'EP_' + reportRegVo.epVo.vRecordid"
                  flag-attach-auth="Y">
                </AuthSecurityRegister>
              </td>
            </template>
          </tr>
          <tr>
            <th>첨부파일</th>
            <td>
              <UploadFileView v-if="commonUtils.isNotEmpty(reportRegVo.epVo.vRecordid)" uploadid="EPR001"
                :recordid="reportRegVo.epVo.vRecordid">
              </UploadFileView>
            </td>
          </tr>
          <tr>
            <th>분석보고서</th>
            <td>
              <button type="button" class="ui-button ui-button__border--blue mb-10" @click="openAddFilePop">추가</button>
              <UploadFileView v-if="commonUtils.isNotEmpty(reportRegVo.epVo.vRecordid)" 
                uploadid="EPR002"
                :recordid="reportRegVo.epVo.vRecordid">
              </UploadFileView>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="page-bottom">
      <div class="page-bottom__inner">
        <div class="ui-buttons ui-buttons__right">
          <template v-if="commonUtils.checkAuth('S000000|S000003')
            || reportRegVo.epVo.vRegUserid === myInfo.loginId">
            <button type="button"
              v-if="reportRegVo.epVo.vApprStatus != 'DOC500' && reportRegVo.epVo.vApprStatus != 'DOC020'"
              class="ui-button ui-button__bg--skyblue" @click="goModify">
              수정
            </button>
            <button type="button" v-if="reportRegVo.epVo.vApprStatus != 'DOC020'"
              class="ui-button ui-button__border--blue" @click="goDelete">
              삭제
            </button>
          </template>
          <button type="button" v-if="commonUtils.isNotEmpty(reportRegVo.epVo.vApprCd)"
            class="ui-button ui-button__bg--blue" @click="fnViewApprOpinion">
            의견보기
          </button>
          <template v-if="commonUtils.isNotEmpty(reportRegVo.epVo.vApprCd)
            && reportRegVo.epVo.vApprStatus != 'DOC010'">
            <template v-if="showApprovalBtn('USR010')">
              <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnApprAccept('ACCEPT')">승인</button>
              <button type="button" class="ui-button ui-button__border--blue" @click="fnApprAccept('REJECT')">반려</button>
            </template>
            <template v-if="showApprovalBtn('USR020')">
              <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnMutual('ACCEPT')">합의</button>
              <button type="button" class="ui-button ui-button__border--blue" @click="fnMutual('REJECT')">거부</button>
            </template>
          </template>
          <button type="button" class="ui-button ui-button__bg--gray" @click="goList">목록</button>
        </div>
      </div>
    </div>
  </div>

  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component :is="popupContent" :pop-params="popParams" @callbackFunc="popSelectFunc" />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, inject, ref, reactive } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useRoute, useRouter } from 'vue-router'
import { useActions } from 'vuex-composition-helpers'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'
import { useApproval } from '@/compositions/approval/useApproval'
import { useStore } from 'vuex'

export default {
  name: 'ProcessQdrugReportMissionView',
  components: {
    ReferenceView: defineAsyncComponent(() => import('@/components/comm/ReferenceView.vue')),
    ApprovalView: defineAsyncComponent(() => import('@/components/comm/ApprovalView.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    MateContTablePop: defineAsyncComponent(() => import('@/components/labcommon/popup/MateContTablePop.vue')),
    UploadFileView: defineAsyncComponent(() => import('@/components/comm/UploadFileView.vue')),
    UploadFileRegister: defineAsyncComponent(() => import('@/components/comm/UploadFileRegister.vue')),
    AuthSecurityRegister: defineAsyncComponent(() => import('@/components/comm/AuthSecurityRegister.vue')),
    ContSearchPop: defineAsyncComponent(() => import('@/components/labcommon/popup/ContSearchPop.vue')),
    OpinionViewPop: defineAsyncComponent(() => import('@/components/approval/popup/OpinionViewPop.vue')),
    UploadAddFilePop: defineAsyncComponent(() => import('@/components/labcommon/popup/UploadAddFilePop.vue')),
  },
  props: {
    vActionFlag: {
      type: Object,
      default: () => {
        return {}
      }
    },
    detailInfo: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  emits: ['callbackFunc'],
  setup(props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const reportRegVo = ref(null)
    const route = useRoute()
    const router = useRouter()
    const { openAsyncAlert, openAsyncConfirm } = useActions(['openAsyncAlert', 'openAsyncConfirm'])
    const uploadParams = reactive({
      vRecordid: '',
      items: []
    })

    const lstSecret = ref([])
    const contList = ref([])
    const selectedIdx = ref(null)
    const arrQsCd = ref(null)
    const appr = ref(null)
    const refComp = ref(null)
    const apprMstInfo = ref(null)
    const apprUserList = ref(null)
    const store = useStore()
    const myInfo = store.getters.getMyInfo()
    let apprProcStatus = ''
    let apprProcSubStatus = ''

    const {
      selectSaNoteEpReportView,
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      fnClosePopup,
      saveSaNoteEpReport
    } = useProcessCommon()

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const {
      updateReportApproval
    } = useApproval()

    const init = async () => {

      const payload = {
        vLabNoteCd: route.query.vLabNoteCd || '',
        vRecordid: props.detailInfo.vRecordid
      }

      const result = await selectSaNoteEpReportView(payload)
      reportRegVo.value = { ...reportRegVo.value, ...result }

      findCodeList(['RD_TYPE', 'RD_STORAGE', 'QS_TYPE', 'MANU_METHOD'])

      lstSecret.value = reportRegVo.value.lstSecret

      if (reportRegVo.value.lstMat && reportRegVo.value.lstMat.length > 0) {
        const len = reportRegVo.value.lstMat.length
        for (let i = 0; i < len; i++) {
          const obj = {
            vContCd: reportRegVo.value.lstMat[i].vMatnr,
            vContNm: reportRegVo.value.lstMat[i].vMaktx,
            vPlantCd: reportRegVo.value.lstMat[i].vPlantCd
          }
          contList.value.push(obj)
        }
      } else {
        contList.value = [{
          vContCd: reportRegVo.value.rvo.vContCd,
          vContNm: reportRegVo.value.rvo.vContNm,
          vPlantCd: reportRegVo.value.rvo.vPlantCd,
        }]
      }
    }

    init()

    const goList = () => {
      router.replace({ query: { vLabNoteCd: route.query.vLabNoteCd } }) //파라미터 복구
      setTimeout(() => {
        context.emit('update:vActionFlag', 'L')
      }, 200)
    }

    const goModify = () => {
      router.replace({ query: { vLabNoteCd: route.query.vLabNoteCd } }) //파라미터 복구
      setTimeout(() => {
        context.emit('update:vActionFlag', 'M')
        context.emit('update:detailInfo', props.detailInfo)
      }, 200)
    }

    const fnViewApprOpinion = () => {
      popParams.value = { vApprCd: reportRegVo.value.epVo.vApprCd }

      fnOpenPopup('OpinionViewPop')
    }

    const goDelete = async () => {
      if (!await openAsyncConfirm({ message: '삭제 하시겠습니까?' })) {
        return
      }

      //삭제처리
      const payload = {
        vActionFlag: 'D',
        epVo: reportRegVo.value.epVo
      }

      const result = await saveSaNoteEpReport(payload)
      if (result && result === 'SUCC') {
        await openAsyncAlert({ message: '삭제 되었습니다.' })
        goList()
      }
    }

    const openAddFilePop = () => {
      popParams.value = {
        vRecordid: reportRegVo.value.epVo.vRecordid,
        vUploadCd: 'EPR002'
      }

      popSelectFunc.value = fnCloseReload
      fnOpenPopup('UploadAddFilePop')
    }

    const fnCloseReload = () => {
      fnClosePopup('UploadAddFilePop')
      window.location.href = '/qdrug/all-lab-note-prd-process?vLabNoteCd=' + route.query.vLabNoteCd + '&vTabId=reportPermission'
    }

    const showApprovalBtn = (apprUserType) => {
      let isVisible = false

      if (apprMstInfo.value &&
        apprMstInfo.value.vApprStatus === 'APS030' &&
        apprUserList.value?.length > 0) {
        const curApprUser = apprUserList.value.filter(v => v.nCurApprseq === apprMstInfo.value.nCurApprseq)

        if (curApprUser && curApprUser.length > 0 &&
          (curApprUser[0].vApprUserid === myInfo.loginId || commonUtils.checkAuth('S000000')) &&
          curApprUser[0].vApprUserType === apprUserType) {
          isVisible = true
        }
      }

      return isVisible
    }

    const fnApprAccept = (flag) => {
      if (appr.value) {
        if (flag === 'ACCEPT') {
          apprProcStatus = 'APS010'
        } else if (flag === 'REJECT') {
          apprProcStatus = 'APS020'
        }

        appr.value.fnApprovalOpinionPop()
      }
    }

    const fnApprProc = async (draftOpinion) => {
      store.dispatch('setLoading', true)

      const payload = {
        ...apprMstInfo.value,
        ...{
          vApprStatus: apprProcStatus,
          vApprSubStatus: apprProcSubStatus,
          vApprOpinion: draftOpinion.value
        },
        vLabNoteCd : route.query.vLabNoteCd,
        vRecordid : props.detailInfo.vRecordid
      }

      const result = await updateReportApproval(payload)
      if (result) {
        router.push({ path: '/approval/list' })
      }else{
        store.dispatch('setLoading', false)
      }
    }

    const fnMutual = (flag) => {
      apprProcStatus = 'APS050'

      if (appr.value) {
        if (flag === 'ACCEPT') {
          apprProcSubStatus = 'AGR010'
        } else {
          apprProcSubStatus = 'AGR030'
        }

        appr.value.fnApprovalOpinionPop()
      }
    }

    return {
      t,
      commonUtils,
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      codeGroupMaps,
      reportRegVo,
      uploadParams,
      lstSecret,
      contList,
      goList,
      arrQsCd,
      appr,
      refComp,
      goModify,
      apprMstInfo,
      apprUserList,
      myInfo,
      fnViewApprOpinion,
      goDelete,
      openAddFilePop,
      fnCloseReload,
      showApprovalBtn,
      fnApprAccept,
      fnApprProc,
      fnMutual,
      apprProcStatus,
      apprProcSubStatus
    }
  }
}
</script>