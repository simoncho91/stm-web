<template>
  <div class="contents-box__inner process-area">
    <div class="timeline">
      <div class="timeline__inner">
        <ul class="ui-list timeline-lists">
          <li v-for="(vo, idx) in propProgressInfo" :key="'time_' + idx" :class="'timeline-item ' + vo.vCurrStatMark">
            <div class="timeline-status">
              <div class="timeline-status__num">{{idx + 1}}</div>
            </div>
            <div class="timeline-detail">
              <div class="timeline-title">{{vo.vStatusNm}}</div>
              <div class="timeline-history__item">
                <div class="timeline-date"></div>
                <ul class="ui-list timeline-history">
                  <template v-for="(line, idx) in timeLineList" :key="'timeline_' + idx">
                    <li v-if="vo.vStatusCd === line.vStatusCd" class="timeline-history__list">
                      <div v-html="commonUtils.removeHTMLChangeBr(line.vMessage)"></div>
                      <span class="timeline-history__time">{{line.vRegDtm}}</span>
                    </li>
                  </template>
                </ul>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>

  </div>
</template>

<script>
import { ref, inject } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useRoute } from 'vue-router'
import { useHalfProcessCommon } from '@/compositions/labcommon/useHalfProcessCommon'

export default {
  name: 'ProcessHalfTimeLine',
  props: {
    progressInfo: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  setup (props, context) {
    const commonUtils = inject('commonUtils')
    const route = useRoute()
    const selectedTab = ref(null)
    const timeLineList = ref(null)
    const propProgressInfo = ref([{
      vStatusCd : '',
      vStatusNm : '',
      vTimeStDt : '',
      vCurrStatMark : '',
      vTabId : '',
    }])

    const{
      selectTimeLineList
    } = useHalfProcessCommon()

    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])
    const getSelectedTabEvent = (item) => {
      selectedTab.value = item.tabId
    }

    propProgressInfo.value = props.progressInfo || {}

    const init = async () => {
      const vLabNoteCd = route.query.vLabNoteCd || ''
      timeLineList.value = await selectTimeLineList({vLabNoteCd : vLabNoteCd})

      timeLineList.value.some((item, idx) => {
        //모든 단계 가능(AL_NOTE0) 알림은 그 이전 or 이후 상태를 따라가도록 하기
        if(item.vStatusCd == 'AL_NOTE0'){
          if(timeLineList.value.length == 1){
            item.vStatusCd = 'AL_NOTE1'
          }else{
            const chgStatusCd = ref('')
            if(idx == 0){ //첫번째 일때
              chgStatusCd.value = timeLineList.value[idx + 1].vStatusCd
            }else{
              chgStatusCd.value = timeLineList.value[idx - 1].vStatusCd
            }

            item.vStatusCd = chgStatusCd.value == 'AL_NOTE0' ? 'AL_NOTE1' : chgStatusCd.value
          }
        }
      })
    }

    init()

    return {
      selectedTab,
      getSelectedTabEvent,
      closeAsyncPopup, 
      propProgressInfo,
      selectTimeLineList,
      timeLineList,
      commonUtils,
    }
  }
}
</script>

<style scoped>
  .timeline-history__time { padding-left: 0;}
</style>