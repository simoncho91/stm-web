<template>
  <div class="search-bar__row search-bar__row--mt12">
    <dl class="search-bar__item">
      <dt class="search-bar__key search-bar__key--width-220">내용물 정보</dt>
      <dd class="search-bar__val search-bar__val--flexible">
        <div class="note-table">
          <div class="note-table__inner">
            <table class="ui-table ui-table__td--40 text-center">
              <colgroup>
                <col v-if="reportRegInfo.contList.length > 1" style="width:10%;">
                <col style="width:12%;">
                <col style="width:13rem;">
                <col v-if="noteType == 'SC'" style="width:25%;">
                <col style="width:auto;">
                <col v-if="noteType == 'HBO'" style="width:10%;">
              </colgroup>
              <thead>
                <tr>
                  <th v-if="reportRegInfo.contList.length > 1">대표 홋수</th>
                  <th>내용물 코드</th>
                  <th>LOT</th>
                  <th v-if="noteType == 'SC'">차수 / 일자 / 제조번호</th>
                  <th>내용물 명</th>
                  <th v-if="noteType == 'HBO'"><button type="button" class="ui-button ui-button__height--28 ui-button__bg--skyblue" @click="addContCdPopup">추가</button></th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(vo, idx) in reportRegInfo.contList" :key="'contVo_' + idx" class="tr_contList">
                  <td v-if="reportRegInfo.contList.length > 1">{{ vo.vFlagRepresent == 'Y' ? '√' : '' }}</td>
                  <td class="cont_name">{{ vo.vContCd }}</td>
                  <td>
                    <div class="ui-select-block" v-if="commonUtils.isNotEmpty(vo.vLotCdList)">
                      <select :id="'selLotCd_' + idx" class="ui-select ui-select__width--120 selLotCd" title="title" @change="changeLotCd(idx)">
                        <option value="">선택</option>
                        <template v-for="(lvo, i) in vo.vLotCdList.split(',')" :key="'lot_'+i">
                          <option :value="lvo">{{vo.vLotDetailNmList.split(',')[i]}}</option>
                        </template>
                      </select>
                    </div>
                  </td>
                  <td v-if="noteType == 'SC'">
                    <div class="ui-select-block">
                      <select class="ui-select ui-select__width--full selQmsLotInfo" title="title">
                        <option value="">선택</option>
                        <template v-for="(qVo, idx) in reportRegInfo.qmsLotInfoList" :key="'qms_lot_' + idx">
                          <template v-if="vo.vContCd == qVo.vContCd">
                            <option :value="qVo.vSeq + '/' + qVo.vDate + '/' + qVo.vLot + '/' + qVo.vPlantCd">
                              {{ qVo.vSeq + ' / ' + qVo.vDate + ' / ' + qVo.vLot }}
                            </option>
                          </template>
                        </template>
                      </select>
                    </div>
                  </td>
                  <td class="tit">
                    <div class="tit__inner text-center">
                      {{ vo.vContNm }}
                    </div>
                  </td>
                  <td v-if="noteType == 'HBO'">
                    <!--삭제버튼 del_bm-->
                    <button type="button" class="ui-button ui-button__bg--lightgray" @click="deleteContList(idx)">삭제</button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </dd>
    </dl>
  </div>

  <div class="search-bar__row search-bar__row--mt12">
    <dl class="search-bar__item">
      <dt class="search-bar__key search-bar__key--width-220">주성분 원료코드/원료명/함량</dt>
      <dd class="search-bar__val search-bar__val--flexible">
        
        <template v-if="strFuncList">
          <table class="ui-table__reset ui-table__ver">
            <colgroup>
              <col style="width:13rem">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr>
                <th>기능성 분류</th>
                <td>
                  {{ strFuncList }}
                </td>
              </tr>
              <tr>
                <th>관련근거</th>
                <td>{{ reportRegInfo.verVo.vRefTypeNm }}</td>
              </tr>
              <tr v-if="reportRegInfo.verVo.vRefTypeCd == 'LNC05_01'">
                <th>주성분</th>
                <td></td>
              </tr>
              <tr>
                <th>제형</th>
                <td>
                  <div class="form-flex">
                    <div class="form-flex-cell" v-if="reportRegInfo.verVo.vRefTypeCd != 'LNC05_03'">
                      {{ reportRegInfo.verVo.vShape }}
                    </div>
                    <div v-if="noteType == 'SC'" class="form-flex-cell ml-40">
                      <div class="ui-checkbox__list">
                        <div class="ui-checkbox__inner">
                          <ap-input-check
                            value="Y"
                            label="2액 이상"
                            id="twoLiqChk"
                            v-model:value="regParam.vTwoLiq"
                            @click="showHideTwoLiqTxtArea"
                          >
                          </ap-input-check>
                          <ap-input
                            v-if="twoLiqYn == 'Y'"
                            :maxlength="200"
                            id="twoLiqTxt"
                            class="ui-input__width--258"
                            placeholder="원료코드,내용물코드,제품명,제품코드"
                            v-model:value="regParam.vTwoLiqTxt"
                          >
                          </ap-input>
                        </div>
                      </div>
                    </div>
                  </div>
                </td>
              </tr>
              <tr v-if="reportRegInfo.verVo.vRefTypeCd == 'LNC05_02'">
                <th>심사번호</th>
                <td>
                  <span class="color-lightblue">
                    <a href="javascript:;" @click.prevent="openEvaluatePop(reportRegInfo.verVo.vEvaluateCd)" class="tit-link txt_blue pl-0">
                      {{ reportRegInfo.verVo.vEvaluateno }}
                    </a>
                    <template v-if="commonUtils.isNotEmpty(reportRegInfo.verVo.vEvaluateGosiCd)">
                      /
                      <a href="javascript:;" @click.prevent="openEvaluatePop(reportRegInfo.verVo.vEvaluateGosiCd)" class="tit-link txt_blue pl-0">
                        {{ reportRegInfo.verVo.vEvaluateGosiNm }}
                      </a>
                    </template>
                  </span>
                </td>
              </tr>
              <tr v-if="reportRegInfo.verVo.vRefTypeCd == 'LNC05_03' || reportRegInfo.verVo.vRefTypeCd == 'LNC05_04'">
                <th>심사항목</th>
                <td>{{ reportRegInfo.verVo.vRefNote }}</td>
              </tr>
              <tr v-if="reportRegInfo.verVo.vRefTypeCd == 'LNC05_05'">
                <th>심사번호</th>
                <td>
                  <template v-if="refNoteBtnFlag == 'V'">
                    {{ reportRegInfo.verVo.vRefNote }}
                    <button type="button" class="ui-button ml-5 ui-button__bg--gray" @click.prevent="saveRefNote('V')">
                      수정
                    </button>
                  </template>
                  <template v-else>
                    <ap-input
                      :maxlength="200"
                      id="refNote"
                      class="ui-input__width--150"
                      v-model:value="regParam.vRefNote"
                    >
                    </ap-input>
                    <button type="button" class="ui-button ml-5 ui-button__bg--gray" @click.prevent="saveRefNote('M')">
                      저장
                    </button>
                  </template>
                </td>
              </tr>
            </tbody>
          </table>
        </template>

        <div class="note-table mt-12">
          <div class="note-table__inner">
            <table class="ui-table ui-table__td--40 text-center">
              <colgroup>
                <col style="width:15%;">
                <col style="width:20%;">
                <col style="width:12%;">
                <col style="width:auto;">
              </colgroup>
              <thead>
                <tr>
                  <th>원료 코드</th>
                  <th>원료명</th>
                  <th>함량</th>
                  <th>비고</th>
                </tr>
              </thead>
              <tbody>
                <template v-if="reportRegInfo.mateList && reportRegInfo.mateList.length > 0"> 
                  <tr v-for="(vo, idx) in reportRegInfo.mateList" :key="'mateList_'+ idx">
                    <td>
                      <template v-if="commonUtils.isEmpty(vo.vMateCd) && commonUtils.isNotEmpty(vo.vMateTempCd)">
                        임시코드 {{ vo.vMateTempCd }}
                      </template>
                      <template v-else>
                        {{ vo.vMateCd }}
                      </template>
                    </td>
                    <td>{{ vo.vMateNm }}</td>
                    <td>{{ vo.nReqRate }}</td>
                    <td class="text-left">{{ vo.vNote }}</td>
                  </tr>
                </template>
                <template v-else>
                  <tr>
                    <td colspan="4"> :: 등록된 필수원료가 없습니다. :: </td>
                  </tr>  
                </template>
              </tbody>
            </table>
          </div>
        </div>
      </dd>
    </dl>
  </div>

  <div class="search-bar__row search-bar__row--mt12">
    <dl class="search-bar__item">
      <dt class="search-bar__key search-bar__key--width-220">브랜드 담당 PM</dt>
      <dd class="search-bar__val search-bar__val--flexible">{{reportRegInfo.rvo.vBrdUsernm}} ({{reportRegInfo.rvo.vBrdUserid}} / {{reportRegInfo.rvo.vBrdDeptnm}})</dd>
    </dl>
  </div>

  <div class="search-bar__row search-bar__row--mt12">
    <dl class="search-bar__item">
      <dt class="search-bar__key search-bar__key--width-220">제품연구원</dt>
      <dd class="search-bar__val search-bar__val--flexible">{{reportRegInfo.rvo.vUsernm}} ({{reportRegInfo.rvo.vUserid}} / {{reportRegInfo.rvo.vUsrDeptnm}})</dd>
    </dl>
  </div>

  <div class="search-bar__row search-bar__row--mt12">
    <dl class="search-bar__item">
      <dt class="search-bar__key search-bar__key--width-220">출시지역</dt>
      <dd class="search-bar__val search-bar__val--flexible">
        <template v-for="(releaseVo, idx) in reportRegInfo.releaseDt" :key="'relase_dt_' + idx">
          {{ releaseVo.vSubCodenm }} ({{commonUtils.changeStrDatePattern(releaseVo.vTagBuffer1, '.')}})
          <template v-if="releaseVo.vSubCode == 'LNC02_04'">({{releaseVo.vTagBuffer2}})</template>
        </template>
      </dd>
    </dl>
  </div>

  <div class="search-bar__row search-bar__row--mt12">
    <dl class="search-bar__item">
      <dt class="search-bar__key search-bar__key--width-220">파일럿 시기</dt>
      <dd class="search-bar__val search-bar__val--flexible">{{commonUtils.changeStrDatePattern(reportRegInfo.rvo.vPilotDt, '.')}}</dd>
    </dl>
  </div>

  <div class="search-bar__row search-bar__row--mt12">
    <dl class="search-bar__item">
      <dt class="search-bar__key search-bar__key--width-220">양산일</dt>
      <dd class="search-bar__val search-bar__val--flexible">{{commonUtils.changeStrDatePattern(reportRegInfo.rvo.vMassProdDt, '.')}}</dd>
    </dl>
  </div>
  
  <template v-if="reportRegInfo.verVo.vRefTypeCd == 'LNC05_03'">
    <div class="search-bar__row search-bar__row--mt12">
      <dl class="search-bar__item search-bar__item--width-100">
        <dt class="search-bar__key search-bar__key--width-220">효능·효과</dt>
        <dd class="search-bar__val search-bar__val--flexible">
          <ap-input
            :maxlength="200"
            id="vEffect"
            v-model:value="regParam.vEffect"
          >
          </ap-input>
        </dd>
      </dl>
    </div>

    <div class="search-bar__row search-bar__row--mt12">
      <dl class="search-bar__item search-bar__item--width-100">
        <dt class="search-bar__key search-bar__key--width-220">용법·용량</dt>
        <dd class="search-bar__val search-bar__val--flexible">
          <ap-input
            :maxlength="200"
            id="vUsageCapacity"
            v-model:value="regParam.vUsageCapacity"
          >
          </ap-input>
        </dd>
      </dl>
    </div>
  </template>

  <template v-if="reportRegInfo.verVo.vRefTypeCd == 'LNC05_04'">
    <div class="search-bar__row search-bar__row--mt12">
      <dl class="search-bar__item search-bar__item--width-100">
        <dt class="search-bar__key search-bar__key--width-220">심사번호</dt>
        <dd class="search-bar__val search-bar__val--flexible">
          <ap-input
            :maxlength="200"
            id="vEvaluateNum"
            v-model:value="regParam.vEvaluateNum"
          >
          </ap-input>
        </dd>
      </dl>
    </div>
    <div class="search-bar__row search-bar__row--mt12">
      <dl class="search-bar__item search-bar__item--width-100">
        <dt class="search-bar__key search-bar__key--width-220">변경제품명</dt>
        <dd class="search-bar__val search-bar__val--flexible">
          <ap-input
            :maxlength="200"
            id="vChangeProduct"
            v-model:value="regParam.vChangeProduct"
          >
          </ap-input>
        </dd>
      </dl>
    </div>
    <div class="search-bar__row search-bar__row--mt12">
      <dl class="search-bar__item search-bar__item--width-100">
        <dt class="search-bar__key search-bar__key--width-220">변경내용물코드</dt>
        <dd class="search-bar__val search-bar__val--flexible">
          <ap-input
            :maxlength="200"
            id="vChangeCd"
            v-model:value="regParam.vChangeCd"
          >
          </ap-input>
        </dd>
      </dl>
    </div>
    <div class="search-bar__row search-bar__row--mt12">
      <dl class="search-bar__item search-bar__item--width-100">
        <dt class="search-bar__key search-bar__key--width-220">변경사항</dt>
        <dd class="search-bar__val search-bar__val--flexible">
          <ap-input
            :maxlength="200"
            id="vChangeNote"
            v-model:value="regParam.vChangeNote"
          >
          </ap-input>
        </dd>
      </dl>
    </div>
  </template>

  <template v-if="reportRegInfo.verVo.vRefTypeCd != 'LNC05_03' && reportRegInfo.verVo.vRefTypeCd != 'LNC05_04'">
    <div class="search-bar__row search-bar__row--mt12">
      <dl class="search-bar__item">
        <dt class="search-bar__key search-bar__key--width-220">홋수명</dt>
        <dd class="search-bar__val search-bar__val--flexible">
          <div class="text-caution">
            <p class="text-caution__text text-caution__text--ps color-tomato">참고: 내용물 코드별로 홋수명 기재바랍니다.
              <br>
              홋수명은 제품 포장(용기,단상자)에 표시되는 홋수대로 기재해야 하니, 반드시 담당PM에게 확인하여 최종 확정된 홋수명으로 의뢰해야 합니다. <br>
              단일홋수 제품이어도 제품 포장에 홋수명이 표시되어 있으면 보고 의뢰시 홋수명 기재하시기 바랍니다.</p>
            <p class="text-caution__text text-caution__text--ps color-tomato">홋수명이 보고사항과 일치하지 않을 경우
              기능성 미보고 또는 표시 오류로 처분 대상이 되므로 주의 필요 <br>
              예시) 용기/ 단상자: 21호 라이트 베이지, 23호 그린 베이지</p>
            <p class="text-caution__text color-tomato ml-45">
              → (O) 312345: 21호, 312346: 23호 <br>
              → (X)  312345: 1호, 312346: 2호</p>
          </div>
          <div class="mt-20">
            <div class="ui-textarea-box ui-textarea-box__height--100">
              <ap-text-area
                :is-with-byte="false"
                :maxlength="2000"
                id="vNumberNm"
                v-model:value="regParam.vNumberNm"
                :input-class="'ui-textarea__placeholder--red'"
                placeholder="※제품명에 포함될 홋수명 입력"
              ></ap-text-area>
            </div>
          </div>
        </dd>
      </dl>
    </div>
  
    <div class="search-bar__row search-bar__row--mt12">
      <dl class="search-bar__item">
        <dt class="search-bar__key search-bar__key--width-220">
          총TiO2, ZnO 함량 <br>
          (자외선차단제일 경우만 해당)
        </dt>
        <dd class="search-bar__val search-bar__val--flexible">
          <div class="note-table mt-12">
            <div class="note-table__inner">
              <table class="ui-table ui-table__td--40 text-center">
                <colgroup>
                  <col style="width:50%;">
                  <col style="width:50%;">
                </colgroup>
                <thead>
                  <tr>
                    <th>TiO2 함량</th>
                    <th>ZNO 함량</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>
                      <div class="ui-textarea-box ui-textarea-box__height--100">
                        <ap-text-area
                          :is-with-byte="false"
                          :maxlength="2000"
                          id="vTiotwoNote"
                          v-model:value="regParam.vTioTwoNote"
                          :input-class="'ui-textarea__placeholder--red'"
                          placeholder="※홋수별 구분 요망"
                        ></ap-text-area>
                        </div>
                      </td>
                      <td>
                        <div class="ui-textarea-box ui-textarea-box__height--100">
                          <ap-text-area
                          :is-with-byte="false"
                          :maxlength="2000"
                          id="vZnoNote"
                          v-model:value="regParam.vZnoNote"
                          :input-class="'ui-textarea__placeholder--red'"
                          placeholder="※홋수별 구분 요망"
                        ></ap-text-area>
                        </div>
                      </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </dd>
      </dl>
    </div>
  
    <div class="search-bar__row search-bar__row--mt12">
      <dl class="search-bar__item">
        <dt class="search-bar__key search-bar__key--width-220">제조원</dt>
        <dd class="search-bar__val search-bar__val--flexible">
          <p class="text-caution__text text-caution__text--ps color-tomato mt-0">반드시 샘플 제품을 포함하여 일부공정위탁(외부임가공)상의 제조원을 모두 기재해주시기 바랍니다. <br>
            (특히, 팩트성형, 마스크류 제품은 주의하여 기입 부탁 드립니다)</p>
  
            <div class="ui-radio__list mt-30 mb-10">
              <div class="ui-radio__inner">
                <ap-input-radio
                  v-for="(vo, index) in reportRegInfo.makerList.LAB_NOTE_PLANT" :key="'maker_list_' + index"
                  :value="vo.vSubCode"
                  :label="vo.vSubCodenm"
                  :id="'maker_list_' + index"
                  name="vMaker"
                  v-model:model="regParam.vMaker"
                ></ap-input-radio>
                <ap-input-radio
                  :value="'ETC'"
                  :label="'기타'"
                  :id="'maker_list_etc'"
                  name="vMaker"
                  v-model:model="regParam.vMaker"
                ></ap-input-radio>
                <ap-input
                  :maxlength="200"
                  id="vMakerTxt"
                  v-model:value="regParam.vMakerTxt"
                  class="ui-input__width--258"
                >
                </ap-input>
              </div>
            </div>
        </dd>
      </dl>
    </div>
  </template>

  <template v-if="reportRegInfo.verVo.vRefTypeCd == 'LNC05_03' || reportRegInfo.verVo.vRefTypeCd == 'LNC05_04'">
    <div class="search-bar__row search-bar__row--mt12">
      <dl class="search-bar__item search-bar__item--width-100">
        <dt class="search-bar__key search-bar__key--width-220">제조사업장<br>(대전/오산/기타)</dt>
        <dd class="search-bar__val search-bar__val--flexible">
          <ap-input
            :maxlength="200"
            id="vMakePlace"
            v-model:value="regParam.vMakePlace"
          >
          </ap-input>
        </dd>
      </dl>
    </div>
  </template>

  <div class="search-bar__row search-bar__row--mt12">
    <dl class="search-bar__item search-bar__item--width-100">
      <dt class="search-bar__key search-bar__key--width-220">PH(기준치±1.0)</dt>
      <dd class="search-bar__val search-bar__val--flexible">
        <div class="ui-input-block">
          <ap-input
            :maxlength="200"
            id="vPh"
            v-model:value="regParam.vPh"
          >
          </ap-input>
        </div>
      </dd>
    </dl>
  </div>

  <div class="search-bar__row search-bar__row--mt12">
    <dl class="search-bar__item search-bar__item--width-100">
      <dt class="search-bar__key search-bar__key--width-220">첨부파일</dt>
      <dd class="search-bar__val search-bar__val--flexible">
        <UploadFileRegister
          uploadid="NOTETAB08"
          :parent-info="uploadParams"
        >
        </UploadFileRegister>
      </dd>
    </dl>
  </div>

  <div class="board-bottom">
    <div class="board-bottom__inner">
      <div class="ui-buttons ui-buttons__right">
        <button type="button" class="ui-button ui-button__bg--skyblue" @click.prevent="sendFuncReqPop">요청하기</button>
        <button type="button" class="ui-button ui-button__bg--gray" @click="fnTestReqList">목록</button>
      </div>
    </div>
  </div>

  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @callbackFunc="popSelectFunc"
        @selectFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, reactive, ref, inject, watch, getCurrentInstance, provide } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useStore } from 'vuex'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'

export default {
  name: 'ProcessFuncTestReportRegVersion',
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    UploadFileRegister: defineAsyncComponent(() => import('@/components/comm/UploadFileRegister.vue')),
    ProcessFuncTestReportReqPop: defineAsyncComponent(() => import('@/components/process/popup/ProcessFuncTestReportReqPop.vue')),
    ProcessFuncTestReportProdListPop: defineAsyncComponent(() => import('@/components/process/popup/ProcessFuncTestReportProdListPop.vue')),
  },
  props : {
    reportRegInfo: {
      type: Object,
      default: () => {
        return {}
      }
    }, 
    
  },
  emits:['fnTestReqList'],
  setup (props, context) {

    const app = getCurrentInstance()
    const tiumUrl = app.appContext.config.globalProperties.tiumUrl

    const selectedTab = ref('testReport')
    const { openAsyncAlert, closeAsyncPopup, openAsyncConfirm } = useActions(['openAsyncAlert','closeAsyncPopup', 'openAsyncConfirm'])
    const commonUtils = inject('commonUtils')
    const reportRegInfo = ref(props.reportRegInfo)
    const strFuncList = ref(null)
    const twoLiqYn = ref('N')
    const store = useStore()
    const noteType = store.getters.getNoteType()
    const refNoteBtnFlag = ref('M')
    refNoteBtnFlag.value = commonUtils.isNotEmpty(reportRegInfo.value.verVo.vRefNote) ? 'V' : 'M'

    const {
      selectFuncTestEpReportReg,
      selectLabNoteMixCheckList,
      fnOpenPopup,
      fnClosePopup,
      popupContent,
      popParams,
      popSelectFunc,
      saveLabNoteSendFuncMail,
      updateNoteRefNote
    } = useProcessCommon()

    const defaultTab = null
    const tabList = ref([])
    const uploadParams = reactive({
      vRecordid: '',
      items: []
    })

    const regParam = ref({
      vNoteType : noteType,
      vLabNoteCd : reportRegInfo.value.basicInfo.vLabNoteCd,
      nVersion : reportRegInfo.value.basicInfo.nVersion, 
      vSenderId : '',
      vReqContent : '',
      vTitle : '',
      nSeqno : '',
      vRecordid : '',
      vNumberNm : '',
      nTioTwoRate : '',
      nZnoRate : '',
      vTioTwoNote : '',
      vZnoNote : '',
      vFlagOverEthanol : '',
      vPh : '',
      vMaker : '',
      vEvaluateNum : '',
      vChangeProduct : '',
      vChangeCd : '',
      vChangeNote : '',
      vEffect : '',
      vUsageCapacity: '',
      vMakePlace : '',
      vTwoLiq: '',
      vTwoLiqTxt : '',
      arrContCd : [],
      arrLotCd : [],
      arrQmsContNm : [],
      vUploadCd: 'NOTETAB08',   //첨부파일 uploadCd
      fileList: uploadParams.items,
      vRepresentCd : '',
      vMakerTxt : '',
      vRefNote : '',
      arrQmsLotInfo : [],
      vQmsPlantCd : '',
    })

    const getSelectedTabEvent = (item) => {
      selectedTab.value = item.tabId
    }

    const init = async () => {

      const funcList = props.reportRegInfo.funcList
      const arrFuncList = []
      if(funcList.length > 0){
        for(let i = 0; i < funcList.length; i++){
          if(commonUtils.isNotEmpty(funcList[i].vTag2Cd)){
            arrFuncList.push(funcList[i].vSubCodenm)
          }
        }
        strFuncList.value = arrFuncList.join(', ')
      }

    }

    init()

    const showHideTwoLiqTxtArea = () => {
      const flagShowHide = document.querySelector('#twoLiqChk').checked
      if(flagShowHide){
        twoLiqYn.value = 'Y'
      }else{
        twoLiqYn.value = 'N'
      }
    }

    const changeLotCd = async (idx) => {
      const selLotCd = document.querySelectorAll(".selLotCd")[idx]
      const lotCd = selLotCd.options[selLotCd.selectedIndex].value
      if(lotCd != ''){
        const result = await selectLabNoteMixCheckList({vLotCd : lotCd})
        if(result != 'SUCC'){
          if(await openAsyncAlert({ message: result })){
            selLotCd.options[0].selected = true
          }
        }
      }
    }

    const sendFuncReqMail = async (item) => {

      const isRepresent = ref(false)
      const arrContCd = ref([])
      const arrQmsContNm = ref([])
      const arrQmsLotInfo = ref([])
      const arrLotCd = ref([])
      const contList = props.reportRegInfo.contList
      contList.forEach((vo) =>{
        arrContCd.value.push(vo.vContCd)   
        arrQmsContNm.value.push(vo.vContNm)    
        if(vo.vFlagRepresent == 'Y'){
          isRepresent.value = true
        }
      })
      
      if(!isRepresent.value){
        arrContCd.value.sort()
        regParam.value.vRepresentCd = arrContCd[0]
      }

      const makerCheck = document.querySelector("input[name='vMaker']:checked")
      if(makerCheck == null || (makerCheck != null && makerCheck.value != 'ETC')){
        regParam.value.vMakerTxt = ''
      }

      const tr_contList = document.querySelectorAll(".tr_contList")
      for(let i = 0; i < tr_contList.length; i++){
        const selLotCd = tr_contList[i].querySelector(".selLotCd")
        arrLotCd.value.push(selLotCd.options[selLotCd.selectedIndex].value)

        if(noteType == 'SC'){
          const sQmsLot = tr_contList[i].querySelector(".selQmsLotInfo")
          arrQmsLotInfo.value.push(sQmsLot.options[sQmsLot.selectedIndex].value)
        }
      }

      regParam.value.vReqContent = item.vReqContent
      regParam.value.arrQaUserId = item.arrQaUserId
      regParam.value.arrContCd = arrContCd
      regParam.value.arrQmsContNm = arrQmsContNm
      regParam.value.arrLotCd = arrLotCd
      regParam.value.arrQmsLotInfo = arrQmsLotInfo

      const result = await saveLabNoteSendFuncMail(regParam.value)
      if(result == 'SUCC'){
        await openAsyncAlert({ message: '요청되었습니다.' })
        fnTestReqList()
      }
    }
    
    const sendFuncReqPop = () => {
      const verVo = props.reportRegInfo.verVo
      if(verVo.vRefTypeCd == undefined || verVo.vRefTypeCd == ''){
        openAsyncAlert({ message: '등록된 기능성이 없습니다.' })
        return 
      }

      const mateList = props.reportRegInfo.mateList
      if(mateList.length <= 0){
        openAsyncAlert({ message: '등록된 기능성 원료가 없습니다.' })
        return
      }

      const isChk = ref(false)
      const isQmsChk = ref(false)
      const lotnm = ref('')
      const tr_contList = document.querySelectorAll(".tr_contList")
      
      for(let i = 0; i < tr_contList.length; i++){
        const selLotCd = tr_contList[i].querySelector(".selLotCd")
        lotnm.value = tr_contList[i].querySelector(".cont_name").innerText

        if(selLotCd == undefined || selLotCd == null){
          isChk.value = true
          break
        }

        const lotCd = selLotCd.options[selLotCd.selectedIndex].value
        if(lotCd == undefined || lotCd == ''){
          isChk.value = true
          break
        }

        const vFlagQmsLotCheck = props.reportRegInfo.basicInfo.vFlagQmsLotCheck
        const vPlantCd = props.reportRegInfo.basicInfo.vPlantCd
        if(vFlagQmsLotCheck == 'Y'){
          //스킨케어일 경우 + 오산사업장은 Qms 제조번호 선택 필수
          if(noteType == 'SC' && vPlantCd == '1110'){
            //2액이상 체크 시, Qms 제조번호 selectbox 미선택 가능하도록
            const chkTwoLiq = document.querySelector("#twoLiqChk")
            if(!chkTwoLiq.checked){   //2액이상 체크 안했을 경우에만 
              const sQmsLot = tr_contList[i].querySelector(".selQmsLotInfo")
              if(sQmsLot.options[sQmsLot.selectedIndex].value == ""){
                lotnm.value = tr_contList[i].querySelector(".cont_name").innerText
                isQmsChk.value = true
                break
              }
            }	
          }
        }
      }

      if(isChk.value){
        openAsyncAlert({ message: "내용물 코드 : "+ lotnm.value +" 의 LOT가 존재하지 않습니다." })
        return
      }

      if(isQmsChk.value){
        openAsyncAlert({ message: "내용물 코드 : "+ lotnm.value +" 의 제조번호가 존재하지 않습니다." })
        return
      }

      const rvo = props.reportRegInfo.rvo
      popParams.value = {
        vNoteType : noteType, 
        vChargeUserId : rvo.vUserid,
        vChargeUserNm : rvo.vUsernm,
      } 

      popSelectFunc.value = sendFuncReqMail
      fnOpenPopup('ProcessFuncTestReportReqPop')
    }

    const fnTestReqList = () => {
      context.emit('fnTestReqList', 'L')
    }

    //reg.vue 에서 version 클릭 시 들어오는 데이터 변경되는 것 감지
    watch(() => props.reportRegInfo, (newVal) => {
      reportRegInfo.value = { ...newVal }

      //version 바뀌면 값 초기화
      regParam.value.vNoteType = noteType
      regParam.value.vLabNoteCd = reportRegInfo.value.basicInfo.vLabNoteCd
      regParam.value.nVersion = reportRegInfo.value.basicInfo.nVersion
      regParam.value.vReqContent = ''
      regParam.value.vRefNote = ''
      regParam.value.vEffect = ''
      regParam.value.vUsageCapacity = ''
      regParam.value.vEvaluateNum = ''
      regParam.value.vChangeProduct = ''
      regParam.value.vChangeCd = ''
      regParam.value.vChangeNote = ''
      regParam.value.vNumberNm = ''
      regParam.value.vTioTwoNote = ''
      regParam.value.vZnoNote = ''
      regParam.value.vMaker = ''
      regParam.value.vMakerTxt = ''
      regParam.value.vMakePlace = ''
      regParam.value.vPh = ''
      regParam.value.vRepresentCd = ''
      regParam.value.vQmsPlantCd = ''

      regParam.value.arrContCd = []
      regParam.value.arrLotCd = []
      regParam.value.arrQmsContNm = []
      regParam.value.arrQmsLotInfo = []
      regParam.value.arrQaUserId = []
    })
    
    const openEvaluatePop = (evaluateCd) => {
      const url = tiumUrl + "/supo/ev/supo_ev_evaluate_view.do?i_sEvaluateCd=" + evaluateCd
      window.open(url, "_blank" , "toolbar=no, menubar=no, location=no, scrollbars=yes, resizable=yes")
    }

    const saveRefNote = async (flag) => {

      if(flag == 'V'){
        refNoteBtnFlag.value = 'M'
        if(!regParam.value.vRefNote){
          regParam.value.vRefNote = reportRegInfo.value.verVo.vRefNote
        }
        return
      }

      if(regParam.value.vRefNote == ''){
        openAsyncAlert({ message: '심사 번호를 입력해주세요.' })
        return
      }

      const message = '심사번호를 저장하시겠습니까?'
      if (!await openAsyncConfirm({ message })) {
        return
      }

      const payload = {
        vNoteType : regParam.value.vNoteType,
        vLabNoteCd : regParam.value.vLabNoteCd,
        nVersion : regParam.value.nVersion, 
        vRefNote : regParam.value.vRefNote,
      }

      const result = await updateNoteRefNote(payload)

      if(result == 'SUCC'){
        await openAsyncAlert({ message: '정상적으로 저장되었습니다.' })
        
        refNoteBtnFlag.value = 'V'
        reportRegInfo.value.verVo.vRefNote = regParam.value.vRefNote
      }
    }

    const addContCdPopup = () => {
      popParams.value = {
        vNoteType : noteType, 
        vLabNoteCd : regParam.value.vLabNoteCd,
        nVersion : regParam.value.nVersion,
      } 

      popSelectFunc.value = setProductResult
      fnOpenPopup('ProcessFuncTestReportProdListPop')
    }

    const setProductResult = (vo) => {
      let isChk = false;
      const contList = props.reportRegInfo.contList
      contList.forEach((item) => {
        if(item.vContCd == vo.vContCd){
          isChk = true;
        }
      })
      
      fnClosePopup('ProcessFuncTestReportProdListPop')

      if(isChk){
        openAsyncAlert({ message : '이미 등록되어 있는 내용물코드 입니다.' })
        return
      }

      contList.push(vo)
    }

    const deleteContList = (idx) => {
      props.reportRegInfo.contList.splice(idx, 1)
    }

    return {
      tabList,
      selectedTab,
      defaultTab,
      getSelectedTabEvent,
      closeAsyncPopup, 
      selectFuncTestEpReportReg,
      reportRegInfo,
      commonUtils,
      strFuncList,
      showHideTwoLiqTxtArea,
      twoLiqYn,
      uploadParams,
      changeLotCd,
      sendFuncReqPop,
      sendFuncReqMail,
      fnOpenPopup,
      fnClosePopup,
      popupContent,
      popParams,
      popSelectFunc,
      noteType,
      regParam,
      openEvaluatePop,
      saveRefNote,
      refNoteBtnFlag,
      fnTestReqList,
      addContCdPopup,
      setProductResult,
      deleteContList
    }
  }
}
</script>