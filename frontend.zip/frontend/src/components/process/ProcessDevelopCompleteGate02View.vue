<template>
  <div class="ui-table__wrap mt-20">
    <table class="ui-table text-center ui-table__td--40 ui-table__thead-multi">
      <colgroup>
        <col style="width:6rem;">
        <col style="width:8%;">
        <col style="width:auto;">
        <col style="width:9%;">
        <col style="width:9%;">
        <col style="width:9%;">
        <col style="width:9%;">
        <col style="width:8%;">
      </colgroup>
      <tbody>
        <tr class="tr-contents">
          <td class="inside-td inside-td__p30" colspan="8">
            <div class="inside-td__item">
              <div class="inside-td__item--title">양산승인요청 내용물</div>
              <div class="inside-td__table--wrap">
                <table class="ui-table__reset inside-td__table">
                  <colgroup>
                    <col style="width:15%"> 
                    <col style="width:auto"> 
                  </colgroup>
                  <thead>
                    <tr>
                      <th>내용물코드</th>
                      <th>내용물명</th>
                    </tr>
                  </thead>
                  <tbody v-if="resultVo?.contList">
                    <tr v-for="(contVo, idx) in resultVo.contList" :key="'contVo_' + idx" class="tr_cont_list">
                      <td :data-contPkCd="contVo.vContPkCd" :data-lotCd="contVo.vLotCd">
                        {{ contVo.vContCd }}
                      </td>
                      <td class="tit">
                        <div class="tit__inner">
                          {{ contVo.vContNm }}
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <ProcessPQCGateCheckInfo
              v-if="resultVo?.pqcList && resultVo?.pqcList.length > 0"
              v-model:pqc-list="resultVo.pqcList"
              :tr-map="resultVo.trMap"
              :gate-flag="'GATE2'"
            >
            </ProcessPQCGateCheckInfo>
            
            <ProcessTrGate01List
              v-if="resultVo?.trGate1List && resultVo?.trGate1List.length > 0"
              :tr-gate1-list="resultVo.trGate1List"
            >
            </ProcessTrGate01List>
          </td>
        </tr>
      </tbody>
    </table>
  </div>

  <div class="contents-box__inner mt-15 min-height__unset"
    v-if="noteType == 'SC' || noteType == 'MU'"
  >
    <ApprovalView
      :appr-cd="gate02CheckParam.vApprCd"
      :appr-class="'LAB002_'+ noteType"
    >
    </ApprovalView>
  </div>

  <div class="page-bottom">
    <div class="page-bottom__inner">
      <div class="ui-buttons ui-buttons__right">
        <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnViewApprOpinion">의견보기</button>
        <button type="button" class="ui-button ui-button__bg--gray" @click="goList">목록</button>
      </div>
    </div>
  </div>

  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @selectFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, inject, ref, watch } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'
import { useRoute, useRouter } from 'vue-router'

export default {
  name: 'ProcessDevelopCompleteGate02',
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    ProcessPQCGateCheckInfo: defineAsyncComponent(() => import('@/components/process/ProcessPQCGateCheckInfo.vue')),
    ApprovalView: defineAsyncComponent(() => import('@/components/comm/ApprovalView.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    OpinionViewPop: defineAsyncComponent(() => import('@/components/approval/popup/OpinionViewPop.vue')),
    ProcessTrGate01List: defineAsyncComponent(() => import('@/components/process/ProcessTrGate01List.vue')),
  },
  emits: ['callbackFunc', 'update:flagOpenGate02'],
  props: {
    gate02CheckParam: {
      type: Object,
      default: () => {
        return {}
      }
    },
    gate0ApprCd : {
      type: Object,
      default : () => {
        return {}
      }
    },
    flagOpenGate02 : {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  setup (props, context) {
    const route = useRoute()
    const router = useRouter()
    
    const appr = ref(null)
    const resultVo = ref(null)
    const { openAsyncAlert, openAsyncConfirm, closeAsyncPopup } = useActions(['openAsyncAlert','openAsyncConfirm','closeAsyncPopup'])
    const commonUtils = inject('commonUtils')
    const {
      selectLabNoteGate2View,
      noteType,
    } = useProcessCommon()

    const init = async () => {
      resultVo.value = await selectLabNoteGate2View(props.gate02CheckParam)
    }

    init()

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
    } = useLabCommon()
    
    const fnViewApprOpinion = () => {
      popParams.value = { vApprCd: props.gate02CheckParam.vApprCd }

      fnOpenPopup('OpinionViewPop')
    }

    const goList = () => {
      router.replace({ query: {vLabNoteCd: route.query.vLabNoteCd }}) //파라미터 복구
      context.emit('update:flagOpenGate02', 'L')
    }

    return {
      closeAsyncPopup,
      resultVo,
      commonUtils,
      noteType,
      goList,
      popupContent,
      popParams,
      popSelectFunc,
      fnViewApprOpinion,
    }
  }
}
</script>