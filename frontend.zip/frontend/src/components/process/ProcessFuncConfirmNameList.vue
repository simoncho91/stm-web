<template>
  <div class="search-bar__row">
    <dl class="search-bar__item search-bar__item--bipartite">
      <dt class="search-bar__key search-bar__key--width-170">요청일</dt>
      <dd class="search-bar__val search-bar__val--flexible">
        <ap-date-picker-range 
          v-model:startDt="searchParams.vRequestStDt" 
          v-model:endDt="searchParams.vRequestEdDt"
          :read-only="false"
          >
        </ap-date-picker-range>
      </dd>
    </dl>
    <dl class="search-bar__item search-bar__item--bipartite">
      <dt class="search-bar__key search-bar__key--width-170">완료일</dt>
      <dd class="search-bar__val">
        <ap-date-picker-range 
          v-model:startDt="searchParams.vFinishStDt" 
          v-model:endDt="searchParams.vFinishEdDt"
          :read-only="false"
          >
        </ap-date-picker-range>
      </dd>
    </dl>
  </div>

  <div class="search-bar__row">
    <dl class="search-bar__item search-bar__item--bipartite">
      <dt class="search-bar__key search-bar__key--width-170">상태</dt>
      <dd class="search-bar__val search-bar__val--flexible">
        <ap-selectbox
          v-model:value="searchParams.vApprStatus"
          class="ui-select__width--full"
          :options="codeGroupMaps['NC0006']"
        >
        </ap-selectbox>
        <span class="error-msg" id="error_msg_select"></span>
      </dd>
    </dl>
    <dl class="search-bar__item search-bar__item--bipartite">
      <dt class="search-bar__key search-bar__key--width-170">검색조건</dt>
      <dd class="search-bar__val search-bar__val--flexible">
        <div class="search-form">
          <div class="search-form__inner">
            <ap-input
                v-model:value="searchParams.vKeyword"
                class="ui-input__width--full"
                placeholder="내용물명 or 기능성 확정제품명"
                @keypress-enter="fnSearchFuncDecideNameList(1)"
              >
              </ap-input>
              <button type="button" class="button-search" 
                @click="fnSearchFuncDecideNameList(1)">
                검색
              </button>
          </div>
        </div>
      </dd>
    </dl>
  </div>
  <div class="board-top mt-20">
    <div class="ui-buttons ui-buttons__right">
      <button type="button" class="ui-button ui-button__border--blue" @click.prevent="fnConfirmReg">제품명 확정</button>
    </div>
  </div>
  <div class="note-table">
    <div class="note-table__inner">
      <table class="ui-table ui-table__td--40 text-center">
        <colgroup>
          <col style="width:6%;">
          <col style="width:9%;">
          <col style="width:auto;">
          <col style="width:auto;">
          <col style="width:8%;">
          <col style="width:7%;">
          <col style="width:10%;">
          <col style="width:10%;">
        </colgroup>
        <thead>
          <tr>
            <th>NO</th>
            <th>내용물 코드</th>
            <th>내용물 명</th>
            <th>기능성 확정제품명</th>
            <th>등록자</th>
            <th>상태</th>
            <th>요청일</th>
            <th>완료일</th>
          </tr>
        </thead>
        <tbody>
          <template v-if="list">
            <template v-for="(vo, i) in list" :key="'decide_list_' + i">
              <template v-for="(decideVo, idx) in vo.fdnList" :key="idx">
                <tr v-if="idx == 0">
                  <td :rowspan="vo.fdnList.length">{{ page.totalCnt - decideVo.nNum + 1 }}</td>
                  <td>{{ decideVo.vContCd }}</td>
                  <td class="tit">
                    <div class="tit__inner">
                      <a href="javascript:void(0)" class="tit-link" @click.prevent="fnGoDetail(decideVo)">
                        {{ decideVo.vContNm }}
                      </a>
                    </div>
                  </td>
                  <td>{{ decideVo.vDecideContNm }}</td>
                  <td :rowspan="vo.fdnList.length">{{ decideVo.vRegUsernm }}</td>
                  <td :rowspan="vo.fdnList.length">{{ decideVo.vStatusNm }}</td>
                  <td :rowspan="vo.fdnList.length">{{ decideVo.vRegDtm }}</td>
                  <td :rowspan="vo.fdnList.length">{{ decideVo.vCompleteDtm }}</td>
                </tr>
                <tr v-else>
                  <td>{{ decideVo.vContCd }}</td>
                  <td class="tit">
                    <div class="tit__inner">
                      <a href="javascript:void(0)" class="tit-link" @click.prevent="fnGoDetail(decideVo)">
                        {{decideVo.vContNm}}
                      </a>
                    </div>
                  </td>
                  <td>{{ decideVo.vDecideContNm }}</td>
                </tr>
              </template>
            </template>
          </template>
          <template v-else>
            <tr class="ddd">
              <td colspan="8">:: 등록한 기능성 확장제품명이 존재하지 않습니다. ::</td>
            </tr>
          </template>
        </tbody>
      </table>
    </div>
  </div>

  <div class="board-bottom">
    <div class="board-bottom__inner">
      <Pagination
        :page-info="page"
        @click="fnSearchFuncDecideNameList"
      >
      </Pagination>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, reactive, ref, inject, provide } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useCode } from '@/compositions/useCode'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'
import { useRoute, useRouter } from 'vue-router'

export default {
  name: 'ProcessFuncConfirmNameList',
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
  },
  props: {
    actionFlag: {
      type: Object,
      default: () => {
        return {}
      }
    },
    flagSaveAction: {
      type: Object,
      default: () => {
        return {}
      }
    },
    decideInfo : {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  emits:['update:actionFlag', 'update:flagSaveAction', 'update:decideInfo'],
  setup (props, context) {

    const selectedTab = ref('prodName')
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])
    const route = useRoute()
    const router = useRouter()
    const decideInfo = ref(null)

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const {
      searchParams,
      page, 
      list,
      fnSearchFuncDecideNameList,
      selectLabNoteFuncDecideNameInfo
    } = useProcessCommon()

    const getSelectedTabEvent = (item) => {
      selectedTab.value = item.tabId
    }

    const fnConfirmReg = () => {
      context.emit('update:actionFlag', 'R')
      context.emit('update:flagSaveAction', 'R')
    }

    const fnGoDetail = (decideInfo) => {
      
      context.emit('update:actionFlag', 'R') //등록 페이지
      context.emit('update:flagSaveAction', 'M')   //수정 모드로
      context.emit('update:decideInfo', decideInfo)

    }
    
    const init = async () => {
      findCodeList(['NC0006'])

      const vSubTabId = route.query.vSubTabId
      const vApprCd = route.query.vApprCd
      if(vSubTabId){
        if(vApprCd){  //결재코드가 넘어오면 상세페이지로 이동
          const payload = {
            vLabNoteCd : route.query.vLabNoteCd || '',
            vApprCd : vApprCd,
          }
          decideInfo.value = await selectLabNoteFuncDecideNameInfo(payload)
          fnGoDetail(decideInfo.value)
        }
      }
      else{
        await fnSearchFuncDecideNameList(1)
      }
    }

    init()

    const pageInfo = ref({
      pageSize: 10,
      totalCnt: 50,
      nowPageNo: 1,
      totalPageCnt: 5,
      startPage: 1,
      endPage: 5
    })

    return {
      codeGroupMaps,
      findCodeList,
      selectedTab,
      getSelectedTabEvent,
      closeAsyncPopup, 
      fnConfirmReg,
      searchParams,
      page, 
      list,
      fnSearchFuncDecideNameList,
      pageInfo,
      fnGoDetail
    }
  }
}
</script>