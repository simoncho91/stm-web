<template>
  <div class="contents-box__inner process-area">
    <table class="ui-table__th--bg-gray">
      <colgroup>
        <col style="width:15%">
        <col style="width:35%">
        <col style="width:15%">
        <col style="width:35%">
      </colgroup>
      <tbody>
        <tr>
          <th>내용물 코드</th>
          <td class="text-left">
            <template v-if="!contList || contList.length === 0">
              내용물 코드가 존재하지 않습니다.
            </template>
            <template v-else-if="contList.length === 1">
              {{ contList[0].vContCd }}
            </template>
            <template v-else>
              <ap-selectbox
                v-model:value="vContCd"
                :input-class="['ui-select__width--200']"
                :options="contList"
                code-key="vContCd"
                code-nm-key="vContCd"
              >
              </ap-selectbox>
            </template>
          </td>
          <th>플랜트 코드</th>
          <td class="text-left">
            <template v-if="!plantList || plantList.length === 0">
              내용물 코드가 존재하지 않습니다.
            </template>
            <template v-else-if="plantList.length === 1">
              {{ plantList[0].vPlantNm }}
            </template>
            <template v-else>
              <ap-selectbox
                v-model:value="vPlantCd"
                :input-class="['ui-select__width--200']"
                :options="contList"
                code-key="vPlantCd"
                code-nm-key="vPlantNm"
              >
              </ap-selectbox>
            </template>
          </td>
        </tr>
      </tbody>
    </table>

    <div class="page-bottom">
      <div class="page-bottom__inner">
        <div class="ui-buttons ui-buttons__right">
          <button type="button" class="ui-button ui-button__bg--skyblue" @click.prevent="fnOpenQms()">QMS 바로가기</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, inject } from 'vue'
import { useRoute } from 'vue-router'
import { useStore } from 'vuex'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'

export default {
  name: 'ProcessQMS',
  setup (props, context) {
    const commonUtils = inject('commonUtils')
    const route = useRoute()
    const store = useStore()
    const myInfo = store.getters.getMyInfo()
    const contList = ref(null)
    const vContCd = ref('')
    const plantList = ref(null)
    const vPlantCd = ref('')
    const {
      selectQmsInfo,
      selectQmsPlantList,
    } = useProcessCommon()

    const fnPlantList = async () => {
      if (commonUtils.isNotEmpty(vContCd.value)) {
        const params = {
          vLabNoteCd: route.query.vLabNoteCd,
          vContCd: vContCd.value
        }
        const result = await selectQmsPlantList(params)

        if (result) {
          plantList.value = result
        }
      }
    }

    const fnOpenQms = () => {
      const vUserid = myInfo.loginId

      const url = "http://APQMS.AMOREPACIFIC.COM/APGQMS/callSystemLink.jsp?" +
                "URL=http://APQMS.AMOREPACIFIC.COM/APGQMS/APGQMS_UI/convey.jsp?" +
                "LANG_TYPE=KR^PROGRAM_ID=QSYSM_LINK^BIZ_CI=RND_NEWITEM^UID="+vUserid+"^PLANT="+vPlantCd.value+"^PARAM="+vContCd.value

      window.open(url, "QMS", "width=1200, height=700, menubar=no, toolbar=no, location=no, status=no, fullscreen=no, scrollbars=no, resizable=yes, top=0, left=0")
    }

    const init = async () => {
      if (route.query.vLabNoteCd) {
        const result = await selectQmsInfo({ vLabNoteCd: route.query.vLabNoteCd })
        if (result) {
          contList.value = result.contList
          plantList.value = result.plantList

          if (contList.value && contList.value.length > 0) {
            vContCd.value = contList.value[0].vContCd
          }

          if (plantList.value && plantList.value.length > 0) {
            vPlantCd.value = plantList.value[0].vPlantCd
          }

          if ((contList.value && contList.value.length === 1) &&
              (plantList.value && plantList.value.length === 1)
          ) {
            fnOpenQms()
          }
        }
      }
    }

    init()

    return {
      contList,
      vContCd,
      plantList,
      vPlantCd,
      fnPlantList,
      fnOpenQms,
    }
  }
}
</script>