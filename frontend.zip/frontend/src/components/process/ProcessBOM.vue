<template>
  <ProcessBOMList
    v-if="vActionFlag === 'L'"
    v-model:vActionFlag="vActionFlag"
    v-model:detailInfo="detailInfo"
  >
  </ProcessBOMList>
  
  <ProcessBOMView
    v-if="vActionFlag === 'V'"
    v-model:vActionFlag="vActionFlag"
    v-model:detailInfo="detailInfo"
  >
  </ProcessBOMView>
</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'

export default {
  name: 'ProcessBOM',
  components: {
    ProcessBOMList: defineAsyncComponent(() => import('@/components/process/ProcessBOMList.vue')),
    ProcessBOMView: defineAsyncComponent(() => import('@/components/process/ProcessBOMView.vue')),
  },
  setup (props, context) {
    const vActionFlag = ref('L')
    const detailInfo = ref(null)

    return {
      vActionFlag,
      detailInfo
    }
  }
}
</script>