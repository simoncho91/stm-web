<template>
  <div class="inside-td__item">
    <div class="inside-td__item--title">GATE1 시험의뢰</div>
    <div class="inside-td__table--wrap">
      <table class="ui-table__reset inside-td__table inside-td__table--borderR-none">
        <colgroup>
          <col style="width:8%">
          <col style="width:9%">
          <col style="width:9%">
          <col style="width:8%">
          <col style="width:8%">
          <col style="width:auto">
          <col style="width:8%">
          <col style="width:10%">
          <col style="width:8%">
          <col style="width:8%">
          <col style="width:8%">
        </colgroup>
        <thead>
          <tr>
            <th>의뢰날짜</th>
            <th>LOT</th>
            <th>내용물코드</th>
            <th>시험의뢰<br>담당자</th>
            <th>향취</th>
            <th>안정성</th>
            <th>방부</th>
            <th>분석<br>(기능성)</th>
            <th>분석<br>(유해)</th>
            <th>효능임상</th>
            <th>분석<br>(무소구)</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(svo, idx) in trGate1List" :key="'gate1_list_'+idx">
            <td>{{ commonUtils.isNotEmpty(svo.vLabReqDtm) ? commonUtils.changeStrDatePattern(svo.vLabReqDtm) : changeStrDatePattern(svo.vRegDtm) }}</td>
            <td>
              <template v-if="svo.vLabMrqTypeCd == 'CLINICAL'">
                <a :href="tiumUrl + '/ct/ct/clinical_test_discuss_renew_view.do?i_sTempStatusCd=DISCUSS&i_sTestCd=' + svo.vProductCd" target="_blank" class="tit-link txt_blue">
                  Ver {{ svo.nLabNoteVer }}{{ svo.vLabGateCd == 'GATE_2' ? 'Pilot' : '' }}
                </a>
              </template>
              <template v-else-if="svo.vLabMrqTypeCd != 'MRQ010' && svo.vLabGateCd == 'GATE_2'">
                <a :href="tiumUrl + '/zm/tr/zm_tr_product_view.do?i_sProductCd='+svo.vProductCd + '&&i_iVersion='+svo.nVersion" target="_blank" class="tit-link txt_blue">
                  Ver {{ svo.nLabNoteVer }}, {{ svo.vLotNm }} Pilot
                </a>
              </template>
              <template v-else-if="svo.vLabMrqTypeCd == 'MRQ010'">
                <a :href="tiumUrl + '/zm/safe/tr/zm_safe_tr_product_view.do?i_sProductCd=' +svo.vProductCd+'&i_iVersion='+svo.nVersion" target="_blank" class="tit-link txt_blue">
                  Ver {{ svo.nLabNoteVer }}, {{ svo.vLotNm }}
                </a>
              </template>
              <template v-else-if="svo.vLabMrqTypeCd == 'MRQ011'">
                <a :href="tiumUrl + '/zm/bb/tr/zm_bb_tr_product_view.do?i_sProductCd='+svo.vProductCd +'&i_iVersion='+svo.nVersion" target="_blank" class="tit-link txt_blue">
                  Ver {{ svo.nLabNoteVer }}, {{ svo.vLotNm }}
                </a>
              </template>
              <template v-else>
                <a :href="tiumUrl + '/zm/tr/zm_tr_product_view.do?i_sProductCd='+svo.vProductCd +'&i_iVersion='+svo.nVersion" target="_blank" class="tit-link txt_blue">
                  Ver {{ svo.nLabNoteVer }}, {{ svo.vLotNm }}
                </a>
              </template>
            </td>
            <td v-html="commonUtils.removeHTMLChangeBr(svo.vTargetContCd)"></td>
            <td>{{ svo.vUsernm }}</td>
            <td v-html="commonUtils.removeHTMLChangeBr(svo.vTrResMRQ060Txt)"></td>
            <td v-html="commonUtils.removeHTMLChangeBr(svo.vTrResMRQ010Txt)"></td>
            <td v-html="commonUtils.removeHTMLChangeBr(svo.vTrResMRQ011Txt)"></td>
            <td v-html="commonUtils.removeHTMLChangeBr(svo.vTrResMRQ040FuncTxt)"></td>
            <td v-html="commonUtils.removeHTMLChangeBr(svo.vTrResMRQ040HarmTxt)"></td>
            <td v-html="commonUtils.removeHTMLChangeBr(svo.vTrResClinicalTxt)"></td>
            <td v-html="commonUtils.removeHTMLChangeBr(svo.vTrResMRQ050Txt)"></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
import {  inject } from 'vue'
export default {
  name: 'ProcessTrGate01List',
  props: {
    trGate1List: {
      type: Array,
      default: () => {
        return []
      }
    }
  },
  setup (props) {
    const commonUtils = inject('commonUtils')
    return {
      commonUtils,
    }
  }
}
</script>