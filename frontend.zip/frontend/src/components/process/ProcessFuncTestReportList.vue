<template>
  <div class="search-bar__row">
    <dl class="search-bar__item search-bar__item--bipartite">
      <dt class="search-bar__key search-bar__key--width-170">요청일</dt>
      <dd class="search-bar__val search-bar__val--flexible">
        <ap-date-picker-range 
          v-model:startDt="searchParams.vRequestStDt" 
          v-model:endDt="searchParams.vRequestEdDt"
          :read-only="false"
          >
        </ap-date-picker-range>
      </dd>
    </dl>
    <dl class="search-bar__item search-bar__item--bipartite">
      <dt class="search-bar__key search-bar__key--width-170">완료일</dt>
      <dd class="search-bar__val">
        <ap-date-picker-range 
          v-model:startDt="searchParams.vFinishStDt" 
          v-model:endDt="searchParams.vFinishEdDt"
          :read-only="false"
          >
        </ap-date-picker-range>
      </dd>
    </dl>
  </div>

  <div class="search-bar__row">
    <dl class="search-bar__item search-bar__item--bipartite">
      <dt class="search-bar__key search-bar__key--width-170">상태</dt>
      <dd class="search-bar__val search-bar__val--flexible">
        <ap-selectbox
          v-model:value="searchParams.vApprStatus"
          class="ui-select__width--full"
          :options="codeGroupMaps['NC0006']"
        >
        </ap-selectbox>
        <span class="error-msg" id="error_msg_select"></span>
      </dd>
    </dl>
    <dl class="search-bar__item search-bar__item--bipartite">
      <dt class="search-bar__key search-bar__key--width-170">검색조건</dt>
      <dd class="search-bar__val search-bar__val--flexible">
        <div class="search-form">
          <div class="search-form__inner">
            <ap-input
                v-model:value="searchParams.vKeyword"
                class="ui-input__width--full"
                placeholder="QA담당자 or 제목"
                @keypress-enter="fnSearchFuncTestEpReportList(1)"
              >
              </ap-input>
              <button type="button" class="button-search"
                @click="fnSearchFuncTestEpReportList(1)">
                검색
              </button>
          </div>
        </div>
      </dd>
    </dl>
  </div>
  <div class="board-top mt-20">
    <div class="ui-buttons ui-buttons__right">
      <button type="button" class="ui-button ui-button__border--blue" @click.prevent="fnReportReq">시험성적서 요청</button>
    </div>
  </div>
  <div class="note-table">
    <div class="note-table__inner">
      <table class="ui-table ui-table__td--40 text-center">
        <colgroup>
          <col style="width:6%;">
          <col style="width:6%;">
          <col style="width:auto;">
          <col style="width:6%;">
          <col style="width:6%;">
          <col style="width:6%;">
          <col style="width:10%;">
          <col style="width:8%;">
          <col style="width:8%;">
          <col style="width:8%;">
          <col style="width:9rem;">
        </colgroup>
        <thead>
          <tr>
            <th>NO</th>
            <th>분류</th>
            <th>제목</th>
            <th>버전</th>
            <th>회차</th>
            <th>등록자</th>
            <th>QA담당자</th>
            <th>상태</th>
            <th>요청일</th>
            <th>완료일</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <template v-if="list && list.length > 0">
            <tr v-for="(vo, idx) in list" :key="'test_report_'+idx">
              <td>{{page.totalCnt - (page.nowPageNo - 1) * page.pageSize - idx}}</td>
              <td>{{ vo.vRefTypeNm}}</td>
              <td class="tit">
                <div class="tit__inner">
                  <a href="javascript:void(0)" class="tit-link" @click.prevent="fnGoDetail(vo)">{{ vo.vTitle }}</a>
                </div>
              </td>
              <td>{{ vo.vVersionTxt }}</td>
              <td>{{ vo.nSeqno }} 회차</td>
              <td>{{ vo.vSenderUserNm }}</td>
              <td>{{ vo.vQaUserNm }}</td>
              <td>{{ vo.vApprStatusNm }}</td>
              <td>{{ vo.vRequestDtm }}</td>
              <td>{{ vo.vReportDtm }}</td>
              <td>
                <button type="button" v-if="vo.vRefTypeCd == 'LNC05_02' || vo.vRefTypeCd == 'LNC05_05'" @click.prevent="goReport(vo, 'report')" class="ui-button ui-button__width--70 ui-button__height--28 ui-button__radius--2 ui-button__border--blue">
                  보고의뢰
                </button>
                <button type="button" v-else-if="vo.vRefTypeCd == 'LNC05_03'" @click.prevent="goReport(vo, 'new')" class="ui-button ui-button__width--70 ui-button__height--28 ui-button__radius--2 ui-button__border--blue">
                  신규심사
                </button>
                <button type="button" v-else-if="vo.vRefTypeCd == 'LNC05_04'" @click.prevent="goReport(vo, 'change')" class="ui-button ui-button__width--70 ui-button__height--28 ui-button__radius--2 ui-button__border--blue">
                  변경심사
                </button>
              </td>
            </tr>
          </template>
          <template v-else>
            <tr>
              <td colspan="11">:: 조회된 내용이 없습니다. ::</td>
            </tr>
          </template>
        </tbody>
      </table>
    </div>
  </div>

  <div class="board-bottom">
    <div class="board-bottom__inner">
      <Pagination
        :page-info="page"
        @click="fnSearchFuncTestEpReportList"
      >
      </Pagination>
    </div>
  </div>

  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, reactive, ref, getCurrentInstance } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useStore } from 'vuex'
import { useCode } from '@/compositions/useCode'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'
import { useRoute } from 'vue-router'

export default {
  name: 'ProcessFuncTestReportList',
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
    ProcessFuncTestReportUploadPop: defineAsyncComponent(() => import('@/components/process/popup/ProcessFuncTestReportUploadPop.vue')),
  },
  props: {
    actionFlag: {
      type: Object,
      default: () => {
        return {}
      }
    },
    flagSaveAction: {
      type: Object,
      default: () => {
        return {}
      }
    },
    detailInfo : {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  emits:['update:actionFlag', 'update:flagSaveAction', 'update:detailInfo'],
  setup (props, context) {
    const route = useRoute()
    const app = getCurrentInstance()
    const tiumUrl = app.appContext.config.globalProperties.tiumUrl
    const store = useStore()
    const selectedTab = ref('testReport')
    const { openAsyncConfirm, openAsyncAlert, closeAsyncPopup, openAsyncPopup } = useActions(['openAsyncConfirm', 'openAsyncAlert', 'closeAsyncPopup', 'openAsyncPopup'])
    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const {
      searchParams,
      page, 
      list,
      fnSearchFuncTestEpReportList,
      fnOpenPopup,
      popupContent,
      popParams
    } = useProcessCommon()

    const tabList = [
      { tabId: 'prodName', tabNm: '확정 제품명' },
      { tabId: 'testReport', tabNm: '시험 성적서' },
    ]

    const getSelectedTabEvent = (item) => {
      selectedTab.value = item.tabId
    }

    const fnReportReq = () => {
      context.emit('update:actionFlag', 'R')
    }

    const fnGoDetail = (vo) => {
      context.emit('update:actionFlag', 'V') //조회 페이지
      context.emit('update:detailInfo', vo)
    }

    const init = async () => {
      findCodeList(['NC0006'])

      const vSubTabId = route.query.vSubTabId
      if(vSubTabId){  
        if(route.query.nVersion){ //vSubTabId, nVersion, nSeqno 가 있으면 시험성적서 상세 페이지로 이동 (메일에서 넘어온 경로)
          const obj = {
            vLabNoteCd : route.query.vLabNoteCd,
            nVersion : route.query.nVersion,
            nSeqno : route.query.nSeqno
          }
          fnGoDetail(obj)
        }
        else{
          selectedTab.value = vSubTabId
        }
      }
      else{
        await fnSearchFuncTestEpReportList(1)
      }
    }

    init()

    const goReport = async (vo, flag) => {
      const noteType = store.getters.getNoteType()
      const recordId  = vo.vRecordid
			const tag  	  = vo.vTag
			const flag_new = vo.vFlagNew
      const key = (recordId == '' || recordId == null || flag_new == 'Y') ? 'new' : ((tag == '#2019') ? 'tag' : 'default')
      const arrParam = []
      //arrParam.push('i_sReturnUrl=' + '/elab/'+noteType.toLowerCase()+'/note/'+noteType.toLowerCase()+'_note_experiment_view.do')
      //returnUrl이 as-is 실험노트 상세페이지라 설정하지 않음 
      //(supo_ev_report_reg_v2 내부에서 returnUrl 없을 경우 설정해주는 로직이 있음) 
      arrParam.push('i_sReturnUrl=')  
      arrParam.push('i_sRecordId=' + (vo.vRecordid == undefined ? '' : vo.vRecordid))
      arrParam.push('i_sFlagReport=' + (key == 'new' ? 'Y' : ''))
      arrParam.push('i_sLabNoteSeqno=' + vo.nSeqno)
      arrParam.push('i_sLabNoteCd=' + vo.vLabNoteCd)
      arrParam.push('i_sNoteType=' + noteType)
      arrParam.push('i_sLabNoteVer=' + vo.nVersion)

      const obj = {
        'report' : {
          'new' : {type : 'url', action : tiumUrl + "/supo/ev/supo_ev_report_reg_v2.do?" + arrParam.join('&')},
          'tag' : {type : 'url', action : tiumUrl + "/supo/ev/supo_ev_report_view_v2.do?" + arrParam.join('&')},
          'default' : {type : 'url', action : tiumUrl + "/supo/ev/supo_ev_report_view.do?" + arrParam.join('&')},
        },
        'new' : {
          'new' : {type : 'function', action : ''},
          'tag' : {type : 'url', action : tiumUrl + "/supo/ev/supo_ev_new_view_v2.do?" + arrParam.join('&')},
          'default' : {type : 'url', action : tiumUrl + "/supo/ev/supo_ev_new_view.do?" + arrParam.join('&')},
        },
        'change' : {
          'new' : {type : 'function', action : ''},
          'tag' : {type : 'url', action : tiumUrl + "/supo/ev/supo_ev_modify_view_v2.do?" + arrParam.join('&')},
          'default' : {type : 'url', action : tiumUrl + "/supo/ev/supo_ev_modify_view.do?" + arrParam.join('&')},
        }
      }

      const object = obj[flag]
      if(!object || !object[key].type){
        openAsyncAlert({ message: '[docClass]를 찾을수 없습니다.' })
      }
      else if(object[key].type == 'url'){
        window.open(object[key].action, '_blank')
      }
      else if(object[key].type == 'function'){
        goView(vo, flag)
      }
    }

    const goView = async(vo, flag) => {
      const noteType = store.getters.getNoteType()
      const noteTypeNm = store.getters.getNoteTypeNm()
      const recordId  = vo.vRecordid
			const tag  	  = vo.vTag
      const arrParam = []
      const key = (recordId == '' || recordId == null) ? 'new' : ((tag == '#2019') ? 'tag' : 'default')
      if(key == 'new'){
        const message = ref('')
        if(vo.vRefTypeCd == 'LNC05_04'){
          message.value = '분석보고서가 등록되어 있지 않습니다.<br>직접 등록하시겠습니까?'
        }else{
          message.value = '시험성적서가 등록되어 있지 않습니다.<br>직접 등록하시겠습니까?'
        }
        
        const param = {
          vNoteType : noteType,
          vNoteTypeNm : noteTypeNm,
          vLabNoteCd : vo.vLabNoteCd,
          nVersion : vo.nVersion,
          nSeqno : vo.nSeqno,
          vRecordid : (vo.vRecordid == undefined ? '' : vo.vRecordid),
          vRefTypeCd : vo.vRefTypeCd,
          vFlagSelf : 'Y'
        }

        const answer = await openAsyncConfirm({ message : message.value})
        if (!answer) {
          return
        }else{
          popParams.value = param
          fnOpenPopup('ProcessFuncTestReportUploadPop')
        }
      }
      else{
        //arrParam.push('i_sReturnUrl=' + '/elab/'+noteType.toLowerCase()+'/note/'+noteType.toLowerCase()+'_note_experiment_view.do')
        //returnUrl이 as-is 실험노트 상세페이지라 설정하지 않음 
        //(supo_ev_report_reg_v2 내부에서 returnUrl 없을 경우 설정해주는 로직이 있음) 
        arrParam.push('i_sReturnUrl=')
        arrParam.push('i_sRecordId=' + (vo.vRecordid == undefined ? '' : vo.vRecordid))
        arrParam.push('i_sFlagReport=' + (key == 'new' ? 'Y' : ''))
        arrParam.push('i_sLabNoteSeqno=' + vo.nSeqno)
        arrParam.push('i_sLabNoteCd=' + vo.vLabNoteCd)
        arrParam.push('i_sNoteType=' + noteType)
        arrParam.push('i_sLabNoteVer=' + vo.nVersion)

        const obj = {
          'report' : {
            'tag' : {type : 'url', action : tiumUrl + "/supo/ev/supo_ev_report_view_v2.do?" + arrParam.join('&')},
            'default' : {type : 'url', action : tiumUrl + "/supo/ev/supo_ev_report_view.do?" + arrParam.join('&')},
          },
          'new' : {
            'tag' : {type : 'url', action : tiumUrl + "/supo/ev/supo_ev_new_view_v2.do?" + arrParam.join('&')},
            'default' : {type : 'url', action : tiumUrl + "/supo/ev/supo_ev_new_view.do?" + arrParam.join('&')},
          },
          'change' : {
            'tag' : {type : 'url', action : tiumUrl + "/supo/ev/supo_ev_modify_view_v2.do?" + arrParam.join('&')},
            'default' : {type : 'url', action : tiumUrl + "/supo/ev/supo_ev_modify_view.do?" + arrParam.join('&')},
          }
        }

        const object = obj[flag]
        if(!object || !object[key].type){
          openAsyncAlert({ message: '[docClass]를 찾을수 없습니다.' })
        }
        else if(object[key].type == 'url'){
          window.open(object[key].action, '_blank')
        }
      
      }
    }

    return {
      codeGroupMaps,
      findCodeList,
      tabList,
      selectedTab,
      getSelectedTabEvent,
      closeAsyncPopup, 
      page, 
      list, 
      searchParams,
      fnReportReq,
      fnSearchFuncTestEpReportList,
      goReport,
      popupContent,
      popParams,
      fnGoDetail
    }
  }
}
</script>