<template>
  <div>
    <div class="contents-box__inner">
  
      <div class="search-bar__row">
        <dl class="search-bar__item search-bar__item--flexible">
          <dt class="search-bar__key search-bar__key--width-22">ZPLM34E / ZPLM34</dt>
          <dd class="search-bar__val">{{ commonUtils.isNotEmpty(regParams.vLand) ? (regParams.vLand === 'UN' ? 'ZPLM34E' : 'ZPLM34')  : '' }}</dd>
        </dl>
        <dl class="search-bar__item search-bar__item--flexible">
          <dt class="search-bar__key search-bar__key--width-22">Leave-on / Wash-off</dt>
          <dd class="search-bar__val">{{ commonUtils.isNotEmpty(regParams.vLeaveType) ? (regParams.vLeaveType === 'L' ? 'Leave-on' : 'Wash-off')  : '' }}</dd>
        </dl>
      </div>
  
      <div class="version-tab__top mt-10 mb-0">
        <!-- <div class="version-tab__top__inner">
          <template v-if="resData.contList?.length > 0">
            <ul class="ui-list version-tab__top__lists">
              <li
                v-for="(vo, idx) in resData.contList"
                :key="`li_cont_${idx}`"
                :class="['version-tab__top__list', vRegParams.vContPkCd === vo.vContPkCd ? 'is-active' : '']"
              >
                <a href="#" class="version-tab__top__link" @click.prevent="fnChangeCont(vo.vContPkCd)">{{ vo.vContCd }}</a>
              </li>
            </ul>
          </template>
        </div> -->
        <ApTab
          mst-id="version-tab"
          :tab-list="tabList"
          @click="getSelectedTabEvent"
          :default-tab="defaultTab"
          :tab-style="['version-tab__top__inner', 'version-tab__top__lists', 'version-tab__top__list', 'version-tab__top__link']"
        >
        </ApTab>
      </div>
  
      <div
        v-if="regParams.vLand === 'UN'"
        class="normal-tab"
      >
        <div class="normal-tab__inner">
          <div class="normal-tab__header">
            <ul class="ui-list normal-tab__lists">
              <li :class="['normal-tab__list', allergenDispFlag === 'allergenList' ? 'is-active' : '']">
                <a href="#" @click.prevent="changeList('allergenList')" class="normal-tab__link">알러젠 표기</a>
              </li>
              <li :class="['normal-tab__list', allergenDispFlag === 'noAllergenList' ? 'is-active' : '']">
                <a href="#" @click.prevent="changeList('noAllergenList')" class="normal-tab__link">알러젠 미표기</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
  
      <div
        v-if="regParams.vLand === 'UN'"
        class="board-top mt-20"
      >
        <div class="ui-buttons ui-buttons__right">
          <button
            type="button"
            class="ui-button ui-button__border--blue"
            @click="fnOpenIngrdCompareInfoPop()"
          >알러젠 표기 / 미표기 비교하기</button>
        </div>
      </div>
  
  
      <div class="">
        <div class="color-tomato mt-10 mb-10 font-weight__m font-size__13"
          v-if="noteType == 'HBO'"
        >
          * 해당 3자의 AEROSOL 실험노트에서 LOT가 확정 되야 가스 원료포함된 처방으로 전성분 계산이 됩니다.
        </div>
        <div class="ui-table__wrap">
          <table class="ui-table text-center ui-table__td--40">
            <colgroup>
              <col style="width:5%;">
              <col style="width:10%;">
              <col style="width:auto">
              <col style="width:10%;">
  
              <col style="width:8%;">
              <col style="width:10%;">
              <col style="width:5%;"> <!-- //ewg -->
              <col style="width:6%;">
  
              <col style="width:6%;">
              <col style="width:6%;">
  
              <col style="width:4%;">
              <col style="width:4%;">
  
              <col v-if="regParams.vLand === 'UN'" style="width:4%;">
              <col v-if="regParams.vLand === 'UN'" style="width:4%;">
  
  
            </colgroup>
            <thead>
              <tr>
                <th>성분코드</th>
                <th>표시명<br>(한글)</th>
                <th>표시명<br>(영문)</th>
                <th>표시명<br>(중국어)</th>
                <th>함량</th>
                <th>기능</th>
                <th>EWG</th>
                <th>배합규제</th>
                <th>글로벌 수출<br>금지 여부</th>
                <th>글로벌 수출<br>제한 여부</th>
                <th>표시성분</th>
                <th>주의사항</th>
                <th v-if="regParams.vLand === 'UN'">주의사항<br>(영문)</th>
                <th v-if="regParams.vLand === 'UN'">주의사항<br>(중문)</th>
              </tr>
            </thead>
            <tbody>
              <template v-if="displayList?.length > 0">
                <tr v-for="(vo, idx) in displayList" :key="`tr_${idx}`">
                  <td>{{ vo.vConcd }}</td>
                  <td>{{ vo.vPsnameKo }}</td>
                  <td>{{ vo.vPsnameEn }}</td>
                  <td>{{ vo.vPsnameCh }}</td>
                  <td>{{ vo.nConPer }}</td>
                  <td>{{ vo.vFcnameEn }}</td>
                  <td :style="`background-color: ${vo.vEwgGrade !== 'NA' ? ewgGradeBgColor[vo.vEwgGrade] : ''}`">{{ vo.vEwgGrade !== 'NA' ? `${vo.nEwgGradeNum}등급` : vo.vEwgGrade }}</td>
                  <td><a href="#" class="tit-link txt_blue" @click.prevent="fnOpenMatrMixreInfoPop(vo)">{{ vo.vMixre }}</a></td>
                  <td><a href="#" class="tit-link txt_blue" @click.prevent="fnOpenMateGlobalViewPop(vo, 'BAN')">{{ regParams.vLand === 'UN' ? vo.vGbanTxt : vo.vZglobal }}</a></td>
                  <td><a href="#" class="tit-link txt_blue" @click.prevent="fnOpenMateGlobalViewPop(vo, 'LIMIT')">{{ regParams.vLand === 'UN' ? vo.vGlmtTxt : vo.vZgllim }}</a></td>
                  <td>
                    <span v-if="vo.vZdisplayLt">
                      <a href="#" style="text-decoration: none;" @click.prevent="fnOpenIngrdApprDescPop(vo, 'DISPLAY')">
                        <div class="form-flex">
                          <button :class="['ingrd_check_circle', `color_${commonUtils.isEmpty(vo.vReflectDispYn) ? 'red' : (vo.vReflectDispYn === 'Y' ? 'green' : 'yellow')}`]"></button>
                          <!-- <button class="ingrd_check_circle color_yellow"></button>
                          <button class="ingrd_check_circle color_green"></button> -->
                        </div>
                      </a>
                    </span>
                  </td>
                  <td>
                    <span v-if="vo.vZwarningLt">
                      <a href="#" style="text-decoration: none;" @click.prevent="fnOpenIngrdApprDescPop(vo, 'WARNING', '')">
                        <div class="form-flex">
                          <button :class="['ingrd_check_circle', `color_${commonUtils.isEmpty(vo.vReflectWarning) ? 'red' : (vo.vReflectWarning === 'Y' ? 'green' : 'yellow')}`]"></button>
                          <!-- <button class="ingrd_check_circle color_yellow"></button>
                          <button class="ingrd_check_circle color_green"></button> -->
                        </div>
                      </a>
                    </span>
                  </td>
                  <td v-if="regParams.vLand === 'UN'">
                    <span v-if="vo.vZwarningLtEn">
                      <a href="#" style="text-decoration: none;" @click.prevent="fnOpenIngrdApprDescPop(vo, 'WARNING', 'En')">
                        <div class="form-flex">
                          <button :class="['ingrd_check_circle', `color_${commonUtils.isEmpty(vo.vReflectWarningEn) ? 'red' : (vo.vReflectWarningEn === 'Y' ? 'green' : 'yellow')}`]"></button>
                          <!-- <button class="ingrd_check_circle color_yellow"></button>
                          <button class="ingrd_check_circle color_green"></button> -->
                        </div>
                      </a>
                    </span>
                  </td>
                  <td v-if="regParams.vLand === 'UN'">
                    <span v-if="vo.vZwarningLtZh">
                      <a href="#" style="text-decoration: none;" @click.prevent="fnOpenIngrdApprDescPop(vo, 'WARNING', 'Zh')">
                        <div class="form-flex">
                          <button :class="['ingrd_check_circle', `color_${commonUtils.isEmpty(vo.vReflectWarningZh) ? 'red' : (vo.vReflectWarningZh === 'Y' ? 'green' : 'yellow')}`]"></button>
                          <!-- <button class="ingrd_check_circle color_yellow"></button>
                          <button class="ingrd_check_circle color_green"></button> -->
                        </div>
                      </a>
                    </span>
                  </td>
                </tr>
                <tr>
                  <td colspan="4">합계</td>
                  <td>{{ commonUtils.isNotEmpty(resData.vSumRate) ? resData.vSumRate : displayList[0].nSumPer }}</td>
                  <td :colspan="regParams.vLand === 'UN' ? 9 : 7"></td>
                </tr>
              </template>
              <template v-else>
                <tr>
                  <td :colspan="regParams.vLand === 'UN' ? 14 : 12">
                    <div class="no-result">
                      조회된 내용이 없습니다.
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>
  
      <div
        v-if="noteType === 'MU'"
        class="mt-30"
      >
        <div class="arrordion-item is-active">
          <div class="arrordion-header">
            <div class="arrordion-title">May Contain</div>
          </div>
          <div class="arrordion-body">
            <div class="note-table mt-15">
              <div class="note-table__inner">
                <table class="ui-table ui-table__td--40 text-center">
                  <colgroup>
                    <col style="width:15%">
                    <col style="width:auto">
                    <col style="width:15%">
                    <col style="width:10%">
                    <col style="width:20%">
                  </colgroup>
                  <thead>
                    <tr>
                      <th>성분코드</th>
                      <th>표시명(한글)</th>
                      <th>표시명(영문)</th>
                      <th>표시명(중국어)</th>
                      <th>기능</th>
                    </tr>
                  </thead>
                  <tbody>
                    <template v-if="resData.mcList?.length > 0">
                      <tr v-for="(vo, idx) in resData.mcList" :key="'tr_mc_' + idx">
                        <td>{{ vo.vSuccTag === 'Y' ? '승계' : '' }}{{ vo.vConcd }}</td>
                        <td>{{ vo.vConnameKo }}</td>
                        <td>{{ vo.vConnameEn }}</td>
                        <td>{{ vo.vConnameCh }}</td>
                        <td>{{ vo.vFcnameKo }}</td>
                      </tr>
                    </template>
                    <template v-else>
                      <tr>
                        <td colspan="5">
                          <div class="no-result">
                            {{ t('common.msg.no_data') }}
                          </div>
                        </td>
                      </tr>
                    </template>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
  
      <div class="page-bottom">
        <div class="page-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <template v-if="noteType === 'MU'">
              <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnCreateMayContain">May Contain 생성</button>
              <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnSetInicName('Y')">May Contain 전성분 적용</button>
              <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnSetInicName('N')">일반 전성분 적용</button>
            </template>
            <template v-else>
              <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnSetInicName('N')">적용</button>
            </template>
          </div>
        </div>
      </div>
  
  
      <div class="search-bar__col">
        <dl class="search-bar__item">
          <dt class="search-bar__key">국문[알러젠 표기]<br>
            <span v-if="resData.vKidtab06 === 'Y'" class="color-tomato mt-5">ㆍ영유아/어린이 사용 대상 - 보존제 함량이 표기 됩니다</span>
          </dt>
          <dd class="search-bar__val">
            <div class="ui-textarea-box ui-textarea-box__height--100">
              <ap-text-area :is-with-byte="false" v-model:value="txtInfo.ztext"></ap-text-area>
            </div>
          </dd>
        </dl>
        <dl class="search-bar__item">
          <dt class="search-bar__key">국문[알러젠 미표기]<br>
            <span v-if="resData.vKidtab06 === 'Y'" class="color-tomato mt-5">ㆍ영유아/어린이 사용 대상 - 보존제 함량이 표기 됩니다</span>
          </dt>
          <dd class="search-bar__val">
            <div class="ui-textarea-box ui-textarea-box__height--100">
              <ap-text-area :is-with-byte="false" v-model:value="txtInfo.ztextKcp"></ap-text-area>
            </div>
          </dd>
        </dl>
        <dl class="search-bar__item">
          <dt class="search-bar__key">영문[알러젠 표기] <br>
            <span class="color-tomato mt-5">*(다색호) 태국 수출품에는 ‘may contain’, ‘+/-’ 표기 불가 - 활용 시, MKT/RA 문안 파트 담당자와 사전 협의 요청</span>
          </dt>
          <dd class="search-bar__val">
            <div class="ui-textarea-box ui-textarea-box__height--100">
              <ap-text-area :is-with-byte="false" v-model:value="txtInfo.ztextEn"></ap-text-area>
            </div>
          </dd>
        </dl>
        <dl class="search-bar__item">
          <dt class="search-bar__key">영문[알러젠 미표기] <br>
            <span class="color-tomato mt-5">*(다색호) 태국 수출품에는 ‘may contain’, ‘+/-’ 표기 불가 - 활용 시, MKT/RA 문안 파트 담당자와 사전 협의 요청</span>
          </dt>
          <dd class="search-bar__val">
            <div class="ui-textarea-box ui-textarea-box__height--100">
              <ap-text-area :is-with-byte="false" v-model:value="txtInfo.ztextEcp"></ap-text-area>
            </div>
          </dd>
        </dl>
        <dl class="search-bar__item">
          <dt class="search-bar__key">중문</dt>
          <dd class="search-bar__val">
            <div class="ui-textarea-box ui-textarea-box__height--100">
              <ap-text-area :is-with-byte="false" v-model:value="txtInfo.ztextCn"></ap-text-area>
            </div>
          </dd>
        </dl>
        <dl class="search-bar__item">
          <dt class="search-bar__key">표시내용<br><span class="color-tomato mt-5">*표시 성분 [10g(ml) 초과 50g(ml)이하 제품 중 전성분 기재하지 않을 경우 표시성분 기재]</span></dt>
          <dd class="search-bar__val">
            <div class="ui-textarea-box ui-textarea-box__height--100">
              <ap-text-area :is-with-byte="false" v-model:value="txtInfo.displayLt" :read-only="true"></ap-text-area>
            </div>
          </dd>
        </dl>
        <dl class="search-bar__item">
          <dt class="search-bar__key">주의사항<br>
            <span class="color-tomato mt-5">*사용시의 주의사항 [공통사항 - 성분별 주의사항] (유형에 따른 주의사항은 개별 확인 필요)</span>
          </dt>
          <dd class="search-bar__val">
            <div class="ui-textarea-box ui-textarea-box__height--140">
              <ap-text-area :is-with-byte="false" :rows="6" v-model:value="txtInfo.warningLt"></ap-text-area>
            </div>
          </dd>
        </dl>
        <template v-if="regParams.vLand === 'UN'">
          <dl class="search-bar__item">
            <dt class="search-bar__key">영문 주의사항<br>
              <span class="color-tomato mt-5">*사용시의 주의사항 [공통사항 - 성분별 주의사항] (유형에 따른 주의사항은 개별 확인 필요)</span>
            </dt>
            <dd class="search-bar__val">
              <div class="ui-textarea-box ui-textarea-box__height--140">
                <ap-text-area :is-with-byte="false" :rows="6" v-model:value="txtInfo.warningLtEn"></ap-text-area>
              </div>
            </dd>
          </dl>
          <dl class="search-bar__item">
            <dt class="search-bar__key">중문 주의사항<br>
              <span class="color-tomato mt-5">*사용시의 주의사항 [공통사항 - 성분별 주의사항] (유형에 따른 주의사항은 개별 확인 필요)</span>
            </dt>
            <dd class="search-bar__val">
              <div class="ui-textarea-box ui-textarea-box__height--140">
                <ap-text-area :is-with-byte="false" :rows="6" v-model:value="txtInfo.warningLtZh"></ap-text-area>
              </div>
            </dd>
          </dl>
        </template>
      </div>
  
      <div class="page-bottom">
        <div class="page-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button
              type="button"
              class="ui-button ui-button__bg--skyblue"
              @click="fnIngrdApprSave()"
            >전성분 승인</button>
            <button
              type="button"
              class="ui-button ui-button__border--gray"
              @click="fnGoListPage()"
            >목록</button>
          </div>
        </div>
      </div>
  
    </div>
    <teleport to="#common-modal" v-if="popupContent">
      <ap-popup>
        <component
          :is="popupContent"
          :pop-params="popParams"
          @selectFunc="popSelectFunc"
          @closeFunc="popCloseFunc"
        />
      </ap-popup>
    </teleport>
  </div>
</template>

<script>
import { defineAsyncComponent, inject, ref } from 'vue'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'ProcessIngredientApproveReg',
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    IngrdCompareInfoPop: defineAsyncComponent(() => import('@/components/labcommon/popup/IngrdCompareInfoPop.vue')), // 알러젠 표기/미표기 비교하기
    MatrMixreInfoPop: defineAsyncComponent(() => import('@/components/labcommon/popup/MatrMixreInfoPop.vue')),       // 배합규제
    MateGlobalViewPop: defineAsyncComponent(() => import('@/components/labcommon/popup/MateGlobalViewPop.vue')),     // 글로벌 수출금지 여부, 글로벌 수출제한 여부
    IngrdApprDescPop: defineAsyncComponent(() => import('@/components/labcommon/popup/IngrdApprDescPop.vue')),       // 표시성분, 주의사항 팝업
    MayContainCreatePop: defineAsyncComponent(() => import('@/components/makeup/popup/MayContainCreatePop.vue')),    // May Contain 생성 팝업
  },
  props: {
    regParams: {
      type: Object,
      default: () => {
        return {
          vContPkCd: '',
          vLand: '',
          vLeaveType : '',
          vFlagSAIngr: 'N',
        }
      }
    }
  },
  setup (props, context) {
    const { openAsyncAlert, openAsyncConfirm, closeAsyncPopup } = useActions(['openAsyncAlert', 'openAsyncConfirm', 'closeAsyncPopup'])
    const t = inject('t')
    const commonUtils = inject('commonUtils')

    const vRegParams = ref({ ...props.regParams })

    const resData = ref({})
    const displayList = ref([])
    const allergenDispFlag = ref('allergenList')
    // 주의사항, 주의사항(영문), 주의사항(국문) 고정문구
    const defaultTxtInfo = ref({
      'warningLt': [
        '1) 화장품 사용 시 또는 사용 후 직사광선에 의하여 사용부위가 붉은 반점, 부어오름 또는 가려움증 등의 이상 증상이나 부작용이 있는 경우 전문의 등과 상담할 것',
        '2) 상처가 있는 부위 등에는 사용을 자제할 것',
        '3) 보관 및 취급 시의 주의 사항\n가) 어린이의 손이 닿지 않는 곳에 보관할 것\n나) 직사광선을 피해서 보관할 것',
      ],
      'warningLtEn': [
        `1. Caution: For external use only. Avoid direct contact with eyes. If contact occurs rinse thoroughly with water. Discontinue use and consult a doctor if irritation occurs. Keep out of reach of children.\n[캐나다/EU 수출 고려하는 경우 불어 추가 표기 필수, 그 외 수출국가에는 불어 필수 표시가 아닙니다.]\n[Précautions d'emploi: Pour usage externe uniquement. Éviter le contact direct avec les yeux. En cas de contact, rincer abondamment avec de l'eau. Cesser l'utilisation et consulter un médecin en cas d'irritation. Garder hors de la portée des enfants.]`,
      ],
      'warningLtZh': [
        '1. 化妆品使用中或使用后因光线直射，使用部位若出现红点、肿胀、瘙痒等异常情况时，请咨询医院皮肤科医生。',
        '2. 有伤口的部位等请勿使用。',
        '3. 储存注意事项\n1) 请置于儿童不易触及的地方。\n2) 请避开直射光线保管。',
      ]
    })
    // 주의사항, 주의사항(영문), 주의사항(국문) [승인화면에 반영]된 문구
    const reflectTxtInfo = ref({
      'warningLt': [
        // Example
        // { 
        //   concd: '10626',
        //   desc: '4) 외용으로만 사용하고 눈에 들어가지 않도록 할 것외용으로만 사용하고 눈에 들어가지 않도록 할 것단상자/용기에 "화기엄금" 기재',
        // }
      ],
      'warningLtEn': [],
      'warningLtZh': [],
    })
    // 표시성분
    const displayConTxtInfo = ref([
      // Example
      // {
      //   concd: '10001',
      //   connm: 'WATER'
      // }
    ])
    const txtInfo = ref({
      ztext: '',
      ztextKcp: '',
      ztextEn: '',
      ztextEcp: '',
      ztextCn: '',
      displayLt: '',
      warningLt: '',
      warningLtEn: '',
      warningLtZh: '',
    })
    // [적용]버튼 클릭여부
    const isApply = ref(false)

    const ewgGradeBgColor = {
      'GREEN': '#00B700',
      'YELLOW': '#FFFF24',
      'RED': '#FF2424'
    }

    const defaultTab = ref(null)
    const tabList = ref([])

    const {
      selectIngrdApprovalRegRequiredInfo,
      insertIngrdApproval,
      searchParams,
      popupContent,
      popParams,
      popSelectFunc,
      popCloseFunc,
      fnOpenPopup,
      noteType,
    } = useProcessCommon()

    const fnGoListPage = () => {
      context.emit('changePage', { actionFlag: 'LIST' })
    }

    // 알러젠 표기 -> 'allergenList'
    // 알러젠 미표기 -> 'noAllergenList'
    const changeList = (allergenFlag) => {
      allergenDispFlag.value = allergenFlag
      displayList.value = resData.value[allergenFlag]
    }

    const resetInicName = () => {
      txtInfo.value = {
        ztext: '',
        ztextKcp: '',
        ztextEn: '',
        ztextEcp: '',
        ztextCn: '',
        displayLt: '',
        warningLt: '',
        warningLtEn: '',
        warningLtZh: ''
      }
    }

    // flagMc -> May Contain 전성분 적용 여부
    // 'Y' -> May Contain 전성분 적용
    // 'N' -> 일반 전성분 적용
    const fnSetInicName = (flagMc = 'N') => {
      if (flagMc === 'N' && displayList.value?.length === 0) {
        openAsyncAlert({ message: '적용 할 데이터가 없습니다' })
        return
      }
      if (flagMc === 'Y' && resData.value?.mcList?.length === 0) {
        openAsyncAlert({ message: '적용 할 데이터가 없습니다' })
        return
      }

      if (!isApply.value) {
        isApply.value = true
      }

      resetInicName()

      const vLand = props.regParams.vLand

      const kidYn = resData.value.vKidtab06

      const arrEn = []
      const arrKo = []
      const arrCn1 = []
      const arrCn2 = []
      const arrEcp = []
      const arrKcp = []

      const mcList = resData.value.mcList
      const lenMc = mcList?.length ?? 0

      for (let i = 0; i < displayList.value.length; i++) {
        const vo = displayList.value[i]

        const mixreTxt = vo.vMixre || ''
        const concd = vo.vConcd || ''
        const sumInPer = vo.nConPer || ''
        const zabcde = vo.vZabcde || ''
        const zconcd = vo.vZconcd || ''
        const legalYn = vo.vLegalYn || ''
        const zarjcd = vo.vZarjcd || ''

        if (vLand === 'KR') {
          if (mixreTxt.indexOf('삭제') > -1) {
            continue
          }
          if (mixreTxt.indexOf('CARRY OVER') > -1) {
            if (zabcde > sumInPer) {
              continue
            } else {
              if (commonUtils.isNotEmpty(zconcd) && zconcd != concd && displayList.value.some(vo => vo.vConcd === zconcd)) {
                continue
              }
            }
          }
        }        
        if (vLand === 'UN') {
          if (commonUtils.isEmpty(zarjcd) || zarjcd != "X") {
            // if (flagMc === 'N' || (flagMc === 'Y' && lenMc > 0 && !mcList.every(mvo => mvo.vConnameEn === vo.vPsnameEn))) {
            if (flagMc === 'N' || (flagMc === 'Y' && lenMc > 0 && !mcList.some(mvo => mvo.vConcd === vo.vConcd))) {
              arrEcp.push(vo.vPsnameEn)
            }
            
            if (kidYn == 'Y' && legalYn == 'Y') {
              arrKcp.push(`${vo.vPsnameKo}(${vo.nConPer}%)`)
            } else {
              // if (flagMc === 'N' || (flagMc === 'Y' && lenMc > 0 && !mcList.every(mvo => mvo.vConnameKo === vo.vPsnameKo))) {
              if (flagMc === 'N' || (flagMc === 'Y' && lenMc > 0 && !mcList.some(mvo => mvo.vConcd === vo.vConcd))) {
                arrKcp.push(vo.vPsnameKo)
              }
            }
          }
        }
        
        // if (flagMc === 'N' || (flagMc === 'Y' && lenMc > 0 && !mcList.every(mvo => mvo.vConnameEn === vo.vPsnameEn))) {
        if (flagMc === 'N' || (flagMc === 'Y' && lenMc > 0 && !mcList.some(mvo => mvo.vConcd === vo.vConcd))) {
          arrEn.push(vo.vPsnameEn)
        }
							
        if(kidYn == 'Y' && legalYn == 'Y'){
          arrKo.push(`${vo.vPsnameKo}(${vo.nConPer}%)`)
        }else{
          // if (flagMc === 'N' || (flagMc === 'Y' && lenMc > 0 && !mcList.every(mvo => mvo.vConnameKo === vo.vPsnameKo))) {
          if (flagMc === 'N' || (flagMc === 'Y' && lenMc > 0 && !mcList.some(mvo => mvo.vConcd === vo.vConcd))) {
            arrKo.push(vo.vPsnameKo)
          }
        }
        if(sumInPer > 0.1){
          arrCn1.push(vo.vPsnameCh)
        }else{
          arrCn2.push(vo.vPsnameCh)
        }
      }

      if (flagMc === 'Y' && resData.value?.mvo) {
        // if (arrEcp.length > 0) {
        //   // arrEcp.unshift(`[+/- (MAY CONTAIN) `)
        //   arrEcp.push(`${resData.value.mvo.vMayContainEn}]`)
        // }
        // if (arrKcp.length > 0) {
        //   // arrKcp.unshift(`+/- ${resData.value.mvo.vMayContainKo}`)
        //   arrKcp.push(`+/- ${resData.value.mvo.vMayContainKo}`)
        // }
        // if (arrEn.length > 0) {
        //   // arrEn.unshift(`[+/- (MAY CONTAIN) `)
        //   arrEn.push(`${resData.value.mvo.vMayContainEn}]`)
        // }
        // if (arrKo.length > 0) {
        //   // arrKo.unshift(`+/- ${resData.value.mvo.vMayContainKo}`)
        //   arrKo.push(`+/- ${resData.value.mvo.vMayContainKo}`)
        // }
        if (resData.value.mvo?.vMayContainEn) {
          arrEcp.push(`${resData.value.mvo.vMayContainEn}]`)
          arrEn.push(`${resData.value.mvo.vMayContainEn}]`)
        }
        if (resData.value.mvo?.vMayContainKo) {
          arrKcp.push(`+/- ${resData.value.mvo.vMayContainKo}`)
          arrKo.push(`+/- ${resData.value.mvo.vMayContainKo}`)
        }
      }
      
      txtInfo.value.ztextEcp = flagMc === 'Y' ? `[+/- (MAY CONTAIN) ${arrEcp.join(', ')}` : arrEcp.join(', ')
      txtInfo.value.ztextKcp = arrKcp.join(', ')
      txtInfo.value.ztextEn = flagMc === 'Y' ? `[+/- (MAY CONTAIN) ${arrEn.join(', ')}` : arrEn.join(', ')
      txtInfo.value.ztext = arrKo.join(', ') 
      
      if (arrCn2.length > 0) {
        txtInfo.value.ztextCn = `成分:${arrCn1.join(', ')}\n其他微量成分:${arrCn2.join(', ')}`
      }else{
        txtInfo.value.ztextCn = `成分:${arrCn1.join(', ')}`
      }

      setDisplayLt()
      setWarningLt()
      setWarningLt('En')
      setWarningLt('Zh')
    }

    const setDisplayLt = () => {
      txtInfo.value.displayLt = displayConTxtInfo.value.map(vo => vo.connm).join(',')
    }

    const setWarningLt = (lang) => {
      if (!lang) {
        lang = ''
      }

      txtInfo.value[`warningLt${lang}`] = [
        ...defaultTxtInfo.value[`warningLt${lang}`],
        ...reflectTxtInfo.value[`warningLt${lang}`].map(vo => vo.desc)
      ].join('\n')
    }

    // [승인 화면에 반영]
    const setSignalText = (obj) => {
      if (!obj) {
        return
      }

      if (obj.vSearchType === "DISPLAY") {
        // 표시성분
        const alreadyReflectFlag = displayConTxtInfo.value.some(vo => vo.concd === obj.concd)
        const isSameTextExist = displayConTxtInfo.value.some(vo => vo.connm === obj.connm)

        if (alreadyReflectFlag) {
          openAsyncAlert({ message: '이미 반영되었습니다' })
          return
        } else {
          if(isSameTextExist) {
            openAsyncAlert({ message: '동일한 내용이 반영되어있습니다' })
            return
          }
        }

        displayConTxtInfo.value.push({
          concd: obj.concd,
          connm: obj.connm
        })

        setDisplayLt()
      } else {
        // 주의사항
        const lang = obj.vLang || ''
        const alreadyReflectFlag = reflectTxtInfo.value[`warningLt${lang}`].some(vo => vo.concd === obj.concd)
        const isSameTextExist = reflectTxtInfo.value[`warningLt${lang}`].some(vo => vo.desc.indexOf(obj.desc) > -1)

        if (alreadyReflectFlag) {
          openAsyncAlert({ message: '이미 반영되었습니다' })
          return
        } else {
          if(isSameTextExist) {
            openAsyncAlert({ message: '동일한 내용이 반영되어있습니다' })
            return
          }
        }

        const idx = defaultTxtInfo.value[`warningLt${lang}`].length + reflectTxtInfo.value[`warningLt${lang}`].length + 1
        const numFormat = commonUtils.isNotEmpty(lang) ? '. ' : ') '

        reflectTxtInfo.value[`warningLt${lang}`].push({
          concd: obj.concd,
          desc: `${idx}${numFormat}${obj.desc}`
        })

        setWarningLt(lang)
        // txtInfo.value[`warningLt${lang}`] = [
        //   ...reflectTxtInfo.value[`warningLt${lang}`].map(vo => vo.desc)
        // ].join('\n')
      }
    }

    // [승인 화면에 미반영]
    const removeSignalText = (obj) => {
      if (!obj) {
        return
      }
      
      if (obj.vSearchType === "DISPLAY") {
        // 표시성분
        displayConTxtInfo.value.splice(displayConTxtInfo.value.findIndex(vo => vo.concd === obj.concd), 1)

        setDisplayLt()
      } else {
        // 주의사항
        const lang = obj.vLang || ''

        reflectTxtInfo.value[`warningLt${lang}`].splice(reflectTxtInfo.value[`warningLt${lang}`].findIndex(vo => vo.concd === obj.concd), 1)
      
        setWarningLt(lang)
        // txtInfo.value[`warningLt${lang}`] = [
        //   ...reflectTxtInfo.value[`warningLt${lang}`].map(vo => vo.desc)
        // ].join('\n')
      }
    }

    const fnReflectTxtInfo = (obj) => {
      if (!obj) {
        return
      }

      const vDispArea = obj.vDispArea
      const reflectYn = obj.reflectYn

      const vo = displayList.value.find(vo => vo.vConcd === obj.concd)
      vo[vDispArea] = reflectYn

      if (reflectYn === 'Y') {
        setSignalText(obj)
      }
      if (reflectYn === 'N') {
        removeSignalText(obj)
      }
    }

    // [알러젠 표기/미표기 비교하기] 팝업 열기
    const fnOpenIngrdCompareInfoPop = () => {
      // popParams.value = props.regParams
      popParams.value = {
        allergenList: resData.value?.allergenList ?? [],
        noAllergenList: resData.value?.noAllergenList ?? []
      }
      fnOpenPopup('IngrdCompareInfoPop')
    }

    // 배합 규제 팝업 열기
    const fnOpenMatrMixreInfoPop = (vo) => {
      if (!vo?.vConcd) {
        return
      }

      popParams.value = { vConcd: vo.vConcd }
      fnOpenPopup('MatrMixreInfoPop')
    }

    const fnCloseMateGlobalViewPop = () => {
      // popupContent.value = null
      closeAsyncPopup()
    }

    // 글로벌 수출금지 여부, 글로벌 수출제한 여부 팝업 열기
    const fnOpenMateGlobalViewPop = (vo, flag) => {
      if (!vo && !flag) {
        return
      }

      popParams.value = {
        vLabNoteCd: searchParams.value.vLabNoteCd,
        vSearchType: flag,
        vConcd: vo.vConcd,
        vLand1: props.regParams.vLand,
        vGcode: ''
      }

      popCloseFunc.value = fnCloseMateGlobalViewPop

      fnOpenPopup('MateGlobalViewPop')
    }

    // 표시성분, 주의사항 팝업 열기
    const fnOpenIngrdApprDescPop = (vo, flag, lang) => {
      if (!vo && !flag) {
        return
      }

      popParams.value = {
        vLabNoteCd: searchParams.value.vLabNoteCd,
        vSearchType: flag,
        vConcd: vo.vConcd,
        vConnm: vo.vPsnameKo,
        vLand1: props.regParams.vLand,
        vGcode: '',
        vLang: lang || ''
      }

      popSelectFunc.value = fnReflectTxtInfo

      fnOpenPopup('IngrdApprDescPop')
    }

    const fnIngrdApprSave = async () => {
      const flagCaution = resData.value.vFlagCaution
      let message = '전성분 승인 하시겠습니까?'

      if (flagCaution === 'Y') {
        message = `<span style=\"color : red; font-weight: bold;\">[주의] 전성분정보가 변경된 원료를 포함하고 있습니다. 글로벌 허가 대응을 위해 전성분 유지가 필요한 자재이니, 전성분 승인을 하지 말아주세요.<br>단계 변경 필요시,IT Helpdesk 데이터 수정 요청을 통해 랩노트 전성분 승인 단계 강제 진행 요청드립니다. <br>* 전성분 변경 필요 시 신규 승인 후, 품질&RA Lab에 전성분 Lock 대상 제외 요청해주세요.</span><br><br><span style=\" font-weight: bold;\">전성분 승인 하시겠습니까?</span>`
      }

      if (!await openAsyncConfirm({ message: message })) {
        return
      } else {
        if (!isApply.value) {
          openAsyncAlert({ message: '적용 되지 않았습니다.' })
          return
        }
      }

      const payload = {
        vLeaveType: props.regParams.vLeaveType,
        // vContPkCd: props.regParams.vContPkCd,
        vContPkCd: vRegParams.value.vContPkCd,
        vLabNoteCd: searchParams.value.vLabNoteCd,
        // vLand: props.regParams.vLand,
        // vNoteType: noteType,
        ingrdApprInfo: {
          land1: props.regParams.vLand,
          flag: noteType,
          ztext: txtInfo.value.ztext,
          ztextEn: txtInfo.value.ztextEn,
          ztextCn: txtInfo.value.ztextCn,
          ztextKcp: txtInfo.value.ztextKcp,
          ztextEcp: txtInfo.value.ztextEcp,
          displayLt: txtInfo.value.displayLt,
          warningLt: txtInfo.value.warningLt,
          warningLtEn: txtInfo.value.warningLtEn,
          warningLtZh: txtInfo.value.warningLtZh,
        },
        ingrdRateList: [
          // ...displayList.value.map((vo, idx) => {
          ...resData.value.allergenList.map((vo, idx) => {
            return {
              matnr: '',
              concd: vo.vConcd,
              zversion: '',
              land1: props.regParams.vLand,
              inSeq: idx + 1,
              inPer: vo.nConPer,
              inPerA: vo.nConPerA,
              erdat: '',
              ernam: '',
              casno: vo.vCasno,
            }
          })
        ]
      }

      const result = await insertIngrdApproval(payload)

      if (result && result === 'SUCC') {
        await openAsyncAlert({ message: '승인 되었습니다' })
      }
      
      fnGoListPage()
    }

    const fnCreateMayContain = () => {
      const vFlagExistsDecide = resData.value.vFlagExistsDecide
      if (vFlagExistsDecide === 'N') {
        openAsyncAlert({ message: '확정 처방이 안된 내용물 코드가 존재합니다.<br>확정 처방 후에 MayContain 사용이 가능합니다.' })
        return
      }

      popParams.value = {
        vLabNoteCd: searchParams.value.vLabNoteCd,
        vContPkCd: vRegParams.value.vContPkCd,
        vLeaveType: props.regParams.vLeaveType,
        vLand: props.regParams.vLand,
        vFlagTempReg: 'Y',
      }

      popSelectFunc.value = fnReloadPage
      popCloseFunc.value = fnCloseMayContainCreatePop

      fnOpenPopup('MayContainCreatePop')
    }

    const fnReloadPage = () => {
      closeAsyncPopup()
      init()
    }

    const fnCloseMayContainCreatePop = () => {
      // popupContent.value = null
      closeAsyncPopup()
    }

    const makeTabList = (pContList) => {
      const contList = pContList

      if(contList?.length > 0){
        contList.forEach(item => {
          const obj = {
            tabId : '',
            tabNm : ''
          }

          if(vRegParams.value.vContPkCd === item.vContPkCd){
            defaultTab.value = item.vContPkCd
          }

          obj.tabId = item.vContPkCd
          obj.tabNm = item.vContCd
          tabList.value.push(obj)
        })
      }
    }

    const init = async () => {
      // if (props.regParams) {
      //   const payload = {
      //     ...{ vLabNoteCd: searchParams.value.vLabNoteCd },
      //     ...props.regParams
      //   }

      //   resData.value = await selectIngrdApprovalRegRequiredInfo(payload)

      //   if (resData.value) {
      //     displayList.value = resData.value.allergenList
      //   } else {
      //     fnGoListPage()
      //   }
      // }
      const payload = {
        ...{ vLabNoteCd: searchParams.value.vLabNoteCd },
        ...vRegParams.value
      }

      resData.value = await selectIngrdApprovalRegRequiredInfo(payload)

      if (resData.value) {
        displayList.value = resData.value.allergenList

        if (resData.value?.contList?.length > 0) {
          tabList.value = []
          makeTabList(resData.value.contList)
        }
      } else {
        fnGoListPage()
      }
    }

    const fnChangeCont = (contPkCd) => {
      vRegParams.value.vContPkCd = contPkCd

      init()
    }

    const getSelectedTabEvent = async (item) => {
      if (item?.tabId) {
        fnChangeCont(item.tabId)
      }
    }

    init()

    return {
      t,
      commonUtils,
      resData,
      displayList,
      allergenDispFlag,
      popupContent,
      popParams,
      popSelectFunc,
      popCloseFunc,
      fnOpenPopup,
      fnGoListPage,
      changeList,
      ewgGradeBgColor,
      noteType,
      txtInfo,
      fnSetInicName,
      fnOpenIngrdCompareInfoPop,
      fnOpenMatrMixreInfoPop,
      fnOpenMateGlobalViewPop,
      fnOpenIngrdApprDescPop,
      displayConTxtInfo,
      fnIngrdApprSave,
      isApply,
      // fnChangeCont,
      vRegParams,
      fnCreateMayContain,
      defaultTab,
      tabList,
      getSelectedTabEvent,
    }
  }
}
</script>