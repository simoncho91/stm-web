<template>
  <ProcessHalfBOMList
    v-if="vActionFlag === 'L'"
    v-model:vActionFlag="vActionFlag"
    v-model:detailInfo="detailInfo"
  >
  </ProcessHalfBOMList>
  
  <ProcessHalfBOMView
    v-if="vActionFlag === 'V'"
    v-model:vActionFlag="vActionFlag"
    v-model:detailInfo="detailInfo"
  >
  </ProcessHalfBOMView>
</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'

export default {
  name: 'ProcessHalfBOM',
  components: {
    ProcessHalfBOMList: defineAsyncComponent(() => import('@/components/process/ProcessHalfBOMList.vue')),
    ProcessHalfBOMView: defineAsyncComponent(() => import('@/components/process/ProcessHalfBOMView.vue')),
  },
  setup (props, context) {
    const vActionFlag = ref('L')
    const detailInfo = ref(null)

    return {
      vActionFlag,
      detailInfo
    }
  }
}
</script>