<template>
  <div class="contents-box__inner process-area">

    <div class="version-tab__top">
      <ApTab
        mst-id="funcComplete-tab"
        :tab-list="tabList"
        @click="getSelectedTabEvent"
        :default-tab="selectedTab"
        :tab-style="['version-tab__top__inner', 'version-tab__top__lists version-tab__top__lists--l', 'version-tab__top__list', 'version-tab__top__link']"
      >
      </ApTab>
    </div>

    <div class="contents-tab__body" id="prodName">
      <ProcessFuncConfirmName
        v-if="selectedTab === 'prodName'"
      >
      </ProcessFuncConfirmName>
    </div>

    <div class="contents-tab__body" id="testReport">
      <ProcessFuncTestReport
        v-if="selectedTab === 'testReport'"
      >
      </ProcessFuncTestReport>
    </div>
    
  </div>
</template>

<script>
import { defineAsyncComponent, reactive, ref } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useRoute, useRouter } from 'vue-router'

export default {
  name: 'ProcessFuncPermission',
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    ProcessFuncConfirmName :  defineAsyncComponent(() => import('@/components/process/ProcessFuncConfirmName.vue')),
    ProcessFuncTestReport :  defineAsyncComponent(() => import('@/components/process/ProcessFuncTestReport.vue'))
  },
  setup (props, context) {

    const route = useRoute()
    const router = useRouter()
    
    const selectedTab = ref(null)
    const vSubTabId = route.query.vSubTabId //vSubTabId 파라미터 들어오면
    if(!vSubTabId){
      selectedTab.value = 'prodName'
    }else{
      selectedTab.value = vSubTabId
    }

    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])

    const tabList = [
      { tabId: 'prodName', tabNm: '확정 제품명' },
      { tabId: 'testReport', tabNm: '시험 성적서' },
    ]

    const getSelectedTabEvent = (item) => {
      router.replace({ query: {vLabNoteCd: route.query.vLabNoteCd }})
      setTimeout(() => {
        selectedTab.value = item.tabId
      }, 200)
    }

    return {
      tabList,
      selectedTab,
      getSelectedTabEvent,
      closeAsyncPopup, 
    }
  }
}
</script>