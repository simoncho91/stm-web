<template>
  <div>
    <div class="contents-core">
      <div class="contents-cell__wrap">
        <div class="contents-cell flex-none">
          <div class="contents-box contents-box__full">
            <div class="contents-box__inner min-height__unset">
              <div class="arrordion-item is-active">
                <div class="arrordion-header">
                  <div class="arrordion-title">의약외품 전성분 승인</div>
                </div>
                <div class="arrordion-body">
                  <div class="version-tab__top">
                    <ApTab
                      mst-id="tab_example5"
                      :tab-list="tabList"
                      :default-tab="'TI_INGR'"
                      @click="fnChangeTab"
                      :tab-style="['version-tab__top__inner', 'version-tab__top__lists version-tab__top__lists--s', 'version-tab__top__list', 'version-tab__top__link']"
                    >
                    </ApTab>
                  </div>
                  <div class="">
                    <div class="ui-table__wrap">
                      <table class="ui-table text-center ui-table__td--40">
                        <colgroup>
                          <col style="width:10%;">
                          <col style="width:auto">
                          <col style="width:30%;">
                          <col style="width:20%;">
                          <col style="width:10%;">
                        </colgroup>
                        <thead>
                          <th>원료코드</th>
                          <th>원료명</th>
                          <th>한글허가명</th>
                          <th>배합목적</th>
                          <th>함량</th>
                        </thead>
                        <tbody>
                          <template v-if="resData.bomList?.length > 0">
                            <tr v-for="(vo, idx) in resData.bomList" :key="`tr_${idx}`">
                              <td>{{ vo.rawCd }}</td>
                              <td>{{ vo.rawNm }}</td>
                              <td>
                                <template v-if="vTabIngrReg === 'TI_INGR'">
                                  <template v-if="vo.vMatNum === '4'">
                                    향료
                                  </template>
                                  <template v-else-if="vo.vMatNum === '6'">
                                    <template v-if="vo.permissionList?.length > 0">
                                      <ap-selectbox
                                        v-model:value="vo.vPermissionKrVal"
                                        :inputClass="'ui-select__width--full'"
                                        :options="vo.permissionList"
                                        :codeKey="'codeKey'"
                                        :codeNmKey="'codeNmKey'"
                                        :defaultBlank="{ blank: false }"
                                      >
                                      </ap-selectbox>
                                    </template>
                                    <template v-else>
                                      <span style="color:red;">* 등록된 원료DB가 없습니다. 원료 DB를 먼저 등록해 주세요.</span>
                                    </template>
                                  </template>
                                </template>
                                <template v-if="vTabIngrReg === 'TI_RAW'">
                                  <template v-if="vo.vMatNum === '4'">
                                    향료
                                  </template>
                                  <template v-else-if="vo.vMatNum === '6'">
                                    <template v-if="commonUtils.isNotEmpty(vo.vPermissionKr)">
                                      {{ vo.vIngrTxt }}
                                    </template>
                                    <template v-else>
                                      <span class="span_no_ingr" style='color:red;'>* 등록된 RawData가 없습니다. RawData를 먼저 저장해 주세요.</span>
                                    </template>
                                  </template>
                                </template>
                              </td>
                              <td>
                                <template v-if="vTabIngrReg === 'TI_INGR'">
                                  <template v-if="vo.vMatNum === '6' && vo.vCmbCode">
                                    <ap-selectbox
                                      v-model:value="vo.vCmbCode"
                                      :inputClass="'ui-select__width--full'"
                                      :options="vo.codeList"
                                      :codeKey="'vCmbCode'"
                                      :codeNmKey="'vCmbCodeNm'"
                                      :defaultBlank="{ blank: false }"
                                    >
                                    </ap-selectbox>
                                  </template>
                                </template>
                                <template v-if="vTabIngrReg === 'TI_RAW'">
                                  {{ vo.vCmbCodeNm }}
                                </template>
                              </td>
                              <td>{{ vo.rawPer }}</td>
                            </tr>
                            <tr>
                              <td colspan="4">합계</td>
                              <td>{{ resData.bomList.map(vo => Number(vo.rawPer)).reduce((acc, item) => acc + item).toFixed(10) }}</td>
                            </tr>
                          </template>
                          <template v-else>
                            <tr>
                              <td colspan="5">
                                <div class="no-result">
                                  {{ t('common.msg.no_data') }}
                                </div>
                              </td>
                            </tr>
                          </template>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
                <div class="page-bottom">
                  <div class="page-bottom__inner">
                    <div class="ui-buttons ui-buttons__right">
                      <template v-if="vTabIngrReg === 'TI_INGR'">
                        <button
                          type="button"
                          class="ui-button ui-button__bg--skyblue"
                          @click="fnSaveIngr('00', 'Y')"
                        >Raw Data 저장</button>
                      </template>
                      <template v-if="vTabIngrReg === 'TI_RAW'">
                        <button
                          type="button"
                          class="ui-button ui-button__bg--skyblue"
                          @click="fnReflectIngr"
                        >전성분 반영</button>
                      </template>
                    </div>
                  </div>
                </div>
              </div>
              <div class="mt-30"></div>
              <div class="arrordion-item is-active">
                <div class="arrordion-header">
                  <div class="arrordion-title">전성분</div>
                </div>
                <div class="arrordion-body">
                  <div class="ui-textarea-box ui-textarea-box__height--100">
                    <ap-text-area :is-with-byte="false" v-model:value="resData.ingrMstVo.vZtext"></ap-text-area>
                  </div>
                  <template v-if="vTabIngrReg === 'TI_RAW'">
                    <div class="page-bottom">
                      <div class="page-bottom__inner">
                        <div class="ui-buttons ui-buttons__right">
                          <button
                            type="button"
                            class="ui-button ui-button__bg--skyblue"
                            @click="fnOpenPermissionPop"
                          >기허가 검색</button>
                        </div>
                      </div>
                    </div>
                  </template>
                  <div class="mt-30"></div>
                  <div class="basic-info__table">
                    <table class="ui-table__reset ui-table__ver ui-table__td--40 text-center">
                      <colgroup>
                        <col style="width:17rem">
                        <col style="width:20rem">
                        <col style="width:17rem">
                        <col style="width:auto">
                      </colgroup>
                      <tbody>
                        <tr>
                          <th>내용물코드</th>
                          <td>{{ resData?.rvo?.vContCd }}</td>
                          <th>내용물명</th>
                          <td>{{ resData?.rvo?.vContNm }}</td>
                        </tr>
                        <tr>
                          <th>허가번호</th>
                          <td>{{ resData.ingrMstVo.vEvaluateno }}</td>
                          <th>허가 제품명</th>
                          <!-- <td>{{ resData.ingrMstVo.vEvaluateNm }}</td> -->
                          <td>
                            <ap-input :is-number="false" v-model:value="resData.ingrMstVo.vEvaluateNm"></ap-input>
                          </td>
                        </tr>
                        <tr>
                          <th>효능효과</th>
                          <td colspan="3">{{ resData.ingrMstVo.vEffect }}</td>
                        </tr>
                        <tr>
                          <th>용법용량</th>
                          <td colspan="3">{{ resData.ingrMstVo.vUsage }}</td>
                        </tr>
                        <tr>
                          <th>사용상의 주의사항</th>
                          <td colspan="3">{{ resData.ingrMstVo.vUseWarning }}</td>
                        </tr>
                        <tr>
                          <th>사용기한</th>
                          <td colspan="3">{{ resData.ingrMstVo.vTimeLimit }}</td>
                        </tr>
                        <tr>
                          <th>저장방법</th>
                          <!-- <td colspan="3">{{ resData.ingrMstVo.vStorage }}</td> -->
                          <td colspan="3">
                            <ap-input :is-number="false" v-model:value="resData.ingrMstVo.vStorage"></ap-input>
                          </td>
                        </tr>
                        <tr>
                          <th>전성분 변경 사유</th>
                          <!-- <td colspan="3">{{ resData.ingrMstVo.vReason }}</td> -->
                          <td colspan="3">
                            <ap-input :is-number="false" v-model:value="resData.ingrMstVo.vReason"></ap-input>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="page-bottom">
          <div class="page-bottom__inner">
            <div class="ui-buttons ui-buttons__right">
              <template v-if="vTabIngrReg === 'TI_RAW' && resData.ingrMstVo.vIngrStatusCd !== '01'">
                <button
                  type="button"
                  class="ui-button ui-button__bg--skyblue"
                  @click="fnSaveIngr('00', 'N')"
                >임시저장</button>
                <button
                  type="button"
                  class="ui-button ui-button__bg--skyblue"
                  @click="fnSaveIngr('01', 'N')"
                >전성분 승인</button>
              </template>
              <button
                type="button"
                class="ui-button ui-button__bg--skyblue"
                @click="fnGoListPage()"
              >목록</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <teleport to="#common-modal" v-if="popupContent">
      <ap-popup>
        <component
          :is="popupContent"
          :pop-params="popParams"
          @selectFunc="popSelectFunc"
          @closeFunc="popCloseFunc"
        />
      </ap-popup>
    </teleport>
  </div>
</template>

<script>
import { defineAsyncComponent, inject, ref } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'ProcessIngredientApproveRegSA',
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    PermissionNoSearchPop: defineAsyncComponent(() => import('@/components/qdrug/popup/PermissionNoSearchPop.vue')),
  },
  props: {
    regParams: {
      type: Object,
      default: () => {
        return {
          vContPkCd: '',
          vLand: '',
          vLeaveType : '',
          vFlagSAIngr: 'Y',
        }
      }
    }
  },
  setup (props, context) {
    const { openAsyncAlert, openAsyncConfirm, closeAsyncPopup } = useActions(['openAsyncAlert', 'openAsyncConfirm', 'closeAsyncPopup'])
    const t = inject('t')
    const commonUtils = inject('commonUtils')

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const {
      selectIngrdApprovalRegRequiredInfo,
      // insertIngrdApproval,
      searchParams,
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      // noteType,
      insertNoteIngr,
    } = useProcessCommon()

    const vTabIngrReg = ref('TI_INGR')

    const tabList = [
      { tabId: 'TI_INGR', tabNm: 'Raw Data'}, 
      { tabId: 'TI_RAW', tabNm: '전성분승인'},
    ]

    const resData = ref({
      ingrMstVo: {
        vLabNoteCd: searchParams.value.vLabNoteCd,
        vContPkCd: '',
        vWerks: '',
        vZversion: 1,
        vIngrStatusCd: '',
        vContCd: '',
        vContNm: '',
        vLand1: props.regParams.vLand,
        ztext: '',
        vEvaluateCd: '',
        vEvaluateno: '',
        vEvaluateNm: '',
        vStorage: '',
        vIngrApprDtm: '',
        vReason: '',

        vEffect: '',
        vUsage: '',
        vUseWarning: '',
        vTimeLimit: '',
      },
      bomList: []
    })

    const fnChangeTab = (item) => {
      if (item && item.tabId) vTabIngrReg.value = item.tabId
    }

    const fnGoListPage = () => {
      context.emit('changePage', { actionFlag: 'LIST' })
    }

    const saveValidation = async () => {
      let flag = true
			let msg = ''
			
			const vPermissionKrFlag = resData.value.bomList.some(vo => commonUtils.isEmpty(vo.vPermissionKr))
			
			if (vPermissionKrFlag) {
				msg  = '한글허가명이 등록되지 않은 원료가 존재합니다.'
				flag = false
			}
			
			const inp = resData.value.ingrMstVo.vReason
			const _zversion = Number(resData.value.ingrMstVo.vZversion);
			
			if (flag && commonUtils.isEmpty(inp) && _zversion > 1) {
				msg = "전성분 변경 사유는 필수값 입니다."
				flag = false
			}
			
			if (!flag && commonUtils.isNotEmpty(msg)) {
        await openAsyncAlert({ message: msg })
			}
			
			return flag
    }

    const fnSaveIngr = async (ingrStatusCd, flagIngr) => {
      if (ingrStatusCd === '01' && !await saveValidation()) {
        return
      }

      let payload = {
        ingrMstVo: resData.value.ingrMstVo,
        vIngrStatusCd: ingrStatusCd,
        vFlagIngr: flagIngr,
        vLabNoteCd: resData.value.ingrMstVo.vLabNoteCd,
        vContPkCd: resData.value.ingrMstVo.vContPkCd,
        vWerks: resData.value.ingrMstVo.vWerks,
        vZversion: resData.value.ingrMstVo.vZversion,
      }

      if (flagIngr === 'Y') {
        payload = {
          ...payload,
          ingrSubList: resData.value.bomList.map(vo => {
            return {
              vLabNoteCd: resData.value.ingrMstVo.vLabNoteCd,
              vContPkCd: resData.value.ingrMstVo.vContPkCd,
              vWerks: resData.value.ingrMstVo.vWerks,
              vZversion: resData.value.ingrMstVo.vZversion,
              vMatrCd: vo.rawCd,
              vMatNm: vo.rawNm,
              vMatNum: vo.vMatNum,
              nMatPer: vo.rawPer,
              // vPermissionKr: vo.vPermissionKr,
              // vStandard: vo.vStandard,
              vPermissionKr: vo.vPermissionKrVal ? (vo.vPermissionKrVal.split('_')[0] ?? '') : '',
              vStandard: vo.vPermissionKrVal ? (vo.vPermissionKrVal.split('_')[1] ?? '') : '',
              vCmbCode: vo.vCmbCode,
            }
          })
        }
      } else {
        payload.vNoteStatusCd = resData.value.rvo.vStatusCd
      }

      const result = await insertNoteIngr(payload)

      if (result && result === 'SUCC') {
        let message = ''

        if (ingrStatusCd === '00') {
          message = '저장되었습니다.'
        } else {
          message = '승인되었습니다.'
        }

        await openAsyncAlert({ message: message })

        if (ingrStatusCd === '00') {
          init()


          document.querySelector('#tab_example5')
                  .querySelectorAll('.ap_li_tab_item')[1]
                  .querySelector('.version-tab__top__link')
                  .click()
        } else {
          fnGoListPage()
        }
      }
    }

    const fnReflectIngr = () => {
      const len = resData.value.bomList?.length ?? 0

      if (len > 0) {
        const cmb01list = new Set()
				const cmb02list = new Set()
				const cmb03list = new Set()
				const cmb04list = new Set()
        
        resData.value.bomList.forEach(bvo => {
          const permission = bvo.vPermissionKr
          const mat_num = bvo.vMatNum

          if (mat_num === '4') {
            cmb02list.add('향료')
          }

          if (commonUtils.isNotEmpty(permission) && mat_num === '6') {
            const cmb = bvo.vCmbCode

            switch (cmb) {
              case 'MP01':
                cmb01list.add(permission);
                break;
              case 'MP02':
                cmb02list.add(permission);
                break;
              case 'MP03':
                cmb03list.add(permission);
                break;
              case 'MP04':
                cmb04list.add(permission);
                break;
              default:
                break;
            }
          }
        })

        let ztext = ''
				
				if (cmb01list.size > 0) {	
          ztext = `[유효성분] ${[...cmb01list].join(", ")}\n`
				}
				
				if (cmb02list.size > 0) {	
					ztext = ztext + `[기타 첨가제] ${[...cmb02list].sort().join(", ")}\n`
				}
				
				if (cmb03list.size > 0) {	
          ztext = ztext + `[보존제] ${[...cmb03list].sort().join(", ")}\n`
				}
				
				if (cmb04list.size > 0) {	
          ztext = ztext + `[타르색소] ${[...cmb04list].sort().join(", ")}\n`
				}
				
				if (commonUtils.isNotEmpty(ztext)) {	
					resData.value.ingrMstVo.vZtext = ztext
				}
      }
    }

    const settingValue = (item) => {
      const {
        vEvaluateCd,
        vEvaluateno,
        vEvaluateNm,
        vEffect,
        vUsage,
        vUseWarning,
        vTimeLimit
      } = item

      resData.value.ingrMstVo.vEvaluateCd = vEvaluateCd || ''
      resData.value.ingrMstVo.vEvaluateno = vEvaluateno || ''
      resData.value.ingrMstVo.vEvaluateNm = vEvaluateNm || ''
      resData.value.ingrMstVo.vEffect = vEffect || ''
      resData.value.ingrMstVo.vUsage = vUsage || ''
      resData.value.ingrMstVo.vUseWarning = vUseWarning || ''
      resData.value.ingrMstVo.vTimeLimit = vTimeLimit || ''
    }

    const fnOpenPermissionPop = () => {
      popSelectFunc.value = settingValue
      fnOpenPopup('PermissionNoSearchPop')
    }

    const init = async () => {
      if (props.regParams) {
        await findCodeList(['SA_MATR_CMB'])

        const payload = {
          ...{ vLabNoteCd: searchParams.value.vLabNoteCd },
          ...props.regParams
        }

        const result = await selectIngrdApprovalRegRequiredInfo(payload)

        if (result) {
          resData.value = { ...resData.value, ...result }

          resData.value.ingrMstVo.vLabNoteCd = searchParams.value.vLabNoteCd
          resData.value.ingrMstVo.vLand1 = props.regParams.vLand

          if (commonUtils.isNotEmpty(result.vZversion)) {
            resData.value.ingrMstVo.vZversion = result.vZversion ?? 1
          }

          // if (commonUtils.isNotEmpty(result.rvo) && commonUtils.isEmpty(result.ingrMstVo)) {
          if (commonUtils.isNotEmpty(result.rvo)) {
            resData.value.ingrMstVo.vContPkCd = result.rvo.vContPkCd
            resData.value.ingrMstVo.vWerks = result.rvo.vPlantCd
            // resData.value.ingrMstVo.vZversion = result.rvo.nMaxVersion
            resData.value.ingrMstVo.vContCd = result.rvo.vContCd
            resData.value.ingrMstVo.vContNm = result.rvo.vContNm
          }

          if (resData.value.permissionList?.length > 0) {
            resData.value.permissionList.forEach(pvo => {
              pvo.codeKey = `${pvo.vPermissionKr}_${pvo.vStandard}`
              pvo.codeNmKey = `${pvo.vPermissionKr} (${pvo.vStandard})`
            })
          }
          if (resData.value.bomList?.length > 0) {
            resData.value.bomList.forEach(bvo => {
              if (bvo.vPermissionKr && bvo.vStandard) {
                // Raw Data 에 기존 값이 존재하는 경우
                bvo.vPermissionKrVal = `${bvo.vPermissionKr}_${bvo.vStandard}`
              } else {
                // Raw Data 에 기존 값이 존재하지 않는 경우 - 해당 원료와 매칭되는 첫 허가 데이터와 맵핑
                if (resData.value.permissionList?.length > 0) {
                  const pvo = resData.value.permissionList.find(pvo => pvo.vMatrCd === bvo.rawCd)

                  if (pvo) {
                    bvo.vPermissionKrVal = `${pvo.vPermissionKr}_${pvo.vStandard}`
                  }
                }
              }

              if (resData.value.permissionList?.length > 0) {
                // 원료코드와 매칭되는 허가리스트 필터링
                bvo.permissionList = resData.value.permissionList.filter(pvo => pvo.vMatrCd === bvo.rawCd) || []
              }
              
              if (resData.value.codeList?.length > 0) {
                // bvo.codeList = resData.value.codeList.filter(cvo => cvo.vMatrCd === bvo.rawCd) || []
                bvo.codeList = []

                const resCodeList = resData.value.codeList.filter(cvo => cvo.vMatrCd === bvo.rawCd)

                if (resCodeList?.length > 0) {
                  resCodeList.forEach(vo => {
                    if (vo.hasOwnProperty('vCmbCode1')) {
                      const obj = {
                        vMatrCd: vo?.vMatrCd,
                        vCmbCode: vo.vCmbCode1,
                        vCmbCodeNm: vo?.vCmbCode1Nm,
                      }

                      bvo.codeList.push(obj)
                    }

                    if (vo.hasOwnProperty('vCmbCode2')) {
                      const obj = {
                        vMatrCd: vo?.vMatrCd,
                        vCmbCode: vo.vCmbCode2,
                        vCmbCodeNm: vo?.vCmbCode2Nm,
                      }

                      bvo.codeList.push(obj)
                    }
                  })
                }

                if (!bvo.vCmbCode) {
                  const cvo = resData.value.codeList.find(cvo => cvo.vMatrCd === bvo.rawCd)
  
                  if (cvo) {
                    bvo.vCmbCode = cvo.vCmbCode1
                  }
                }
              }
            })
          }
        } else {
          fnGoListPage()
        }
      }
    }

    init()

    return {
      t,
      commonUtils,
      tabList,
      resData,
      fnChangeTab,
      popupContent,
      popParams,
      popSelectFunc,
      fnGoListPage,
      vTabIngrReg,
      codeGroupMaps,
      fnSaveIngr,
      fnReflectIngr,
      fnOpenPermissionPop,

    }
  }
}
</script>

<style scoped>
.version-tab__top {
  margin-bottom: 1rem;
}
.contents-box__with--tab .contents-box__inner {
  border-top-left-radius: 0;
  height: calc(100% - 0.1rem);
}
</style>