<template>
  <div class="contents-box__inner" v-if="reportRegVo">
    <div class="ui-buttons ui-buttons__right">
      <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnAppr">결재의뢰</button>
      <button type="button" class="ui-button ui-button__border--blue" @click="fnSave">임시저장</button>
      <button type="button" class="ui-button ui-button__bg--gray" @click="goList">목록</button>
    </div>
    <div class="p_bold">기본 정보</div>
    <div class="ui-table__wrap mt-15 mb-15">
      <table class="ui-table__reset ui-table__ver">
        <colgroup>
          <col style="width:15%;">
          <col style="width:35%;">
          <col style="width:15%;">
          <col style="width:35%;">
        </colgroup>
        <tbody>
          <tr>
            <th>등록자</th>
            <td>{{ reportRegVo.epVo.vRegUserNm }}</td>
            <th>문서종류</th>
            <td>
              <div class="ui-radio__list" id="error_wrap_vDocType">
                <div class="ui-radio__inner">
                  <ap-input-radio
                    v-for="(vo, index) in codeGroupMaps['RD_TYPE']" :key="'rdType_' + index"
                    v-model:model="reportRegVo.epVo.vDocType"
                    :value="vo.vSubCode"
                    :label="vo.vSubCodenm"
                    :id="'rdType_' + index"
                    name="vDocType"
                    @click="changeDocType(vo.vSubCode);fnValidate('vDocType');"
                  >
                  </ap-input-radio>
                </div>
                <span class="error-msg" id="error_msg_vDocType"></span>
              </div>
            </td>
          </tr>
          <tr>
            <th>문서구분</th>
            <td id="error_wrap_vDocClassnm">
              <ap-input
                class="ui-input__width--150"
                v-model:value="reportRegVo.epVo.vDocClassnm"
                :disabled="true"
                :readonly="true"
                @click="fnValidate('vDocClassnm');"
              >
              </ap-input>
              <span class="error-msg" id="error_msg_vDocClassnm"></span>
            </td>
            <th>문서번호</th>
            <td>
              <template v-if="reportRegVo.vActionFlag != 'R'">
                <b>#{{ reportRegVo.epVo.vDeptnm }}({{ reportRegVo.epVo.vDocClassnm }}) {{ reportRegVo.epVo.vYearReg }}-{{ reportRegVo.epVo.vFinishCd }}</b>
              </template>
            </td>
          </tr>
          <tr>
            <th>심사 구분</th>
            <td colspan="3">
              <div class="ui-checkbox__list" id="error_wrap_arrQsCd">
                <div class="ui-checkbox__inner">
                  <template v-for="(vo, i) in codeGroupMaps['QS_TYPE']" :key="'qsCdVo_' + i">
                    <ap-input-check
                      v-model:model="regAddParam.arrQsCd"
                      :value="vo.vSubCode"
                      :id="'arrQsCd_'+ i"
                      :label="vo.vSubCodenm"
                      @click="fnValidate('arrQsCd');"
                    >
                    </ap-input-check>
                  </template>
                  <span class="txt_blue ml-10 mt-5">(복수체크 가능)</span>
                </div>
                <span class="error-msg" id="error_msg_arrQsCd"></span>
              </div>
            </td>
          </tr>
          <tr>
            <th>제조방법</th>
            <td colspan="3">
              <div class="ui-radio__list" id="error_wrap_vMenuType">
                <div class="ui-radio__inner">
                  <ap-input-radio
                    v-for="(vo, index) in codeGroupMaps['MANU_METHOD']" :key="'menu_method_' + index"
                    v-model:model="regAddParam.vMenuType"
                    :value="vo.vSubCode"
                    :label="vo.vSubCodenm"
                    :id="'menu_type_' + index"
                    name="vMenuType"
                    @click="fnValidate('vMenuType');"
                  ></ap-input-radio>
                </div>
                <span class="error-msg" id="error_msg_vMenuType"></span>
              </div>
            </td>
          </tr>
          <tr>
            <th>직급</th>
            <td>{{ reportRegVo.epVo.vPositnm }}</td>
            <th>부서</th>
            <td>{{ reportRegVo.epVo.vDeptnm }}</td>
          </tr>
          <tr>
            <th>전화</th>
            <td>{{ reportRegVo.epVo.vPhoneno }}</td>
            <th>이메일</th>
            <td>{{ reportRegVo.epVo.vEmail}}</td>
          </tr>
          <tr>
            <th>기안일</th>
            <td>{{ commonUtils.changeStrDatePattern(reportRegVo.epVo.vRegDtm, '.', 'Y')  }}</td>
            <th>보존년한</th>
            <td>
              <div class="ui-select-block" id="error_wrap_vStorageCd">
                <ap-selectbox
                  v-model:value="reportRegVo.epVo.vStorageCd"
                  id="storageCd"
                  :options="codeGroupMaps['RD_STORAGE']"
                  @change="fnValidate('vStorageCd');"
                />
                <span class="error-msg" id="error_msg_vStorageCd"></span>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
      <div class="mt-10">
        <p class="p_caution_red">※ 정확한 문서구분과 보존년한을 영구로 체크바랍니다.</p>
      </div>
    </div>
    
    <div class="mt-20 mb-15">
      <ReferenceRegister
        ref="refComp"
        record-id=""
        :default-list="referenceList"
      >
      </ReferenceRegister>
    </div>

    <div class="mt-30 mb-15">
      <div class="p_bold">지정참조</div>
      <div class="ui-table__wrap mt-15">
        <table class="ui-table__reset ui-table__ver">
          <colgroup>
            <col style="width:15%;">
            <col style="width:auto;">
          </colgroup>
          <tbody>
            <tr>
              <th>지정참조</th>
              <td>
                <template v-for="(appointVo, idx) in reportRegVo.appointList" :key="'appointVo_'+idx">
                  {{ appointVo.vRefUsernm }} - <span class="p_bold">{{ appointVo.vRefDeptnm }}</span>&nbsp; 
                </template>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <div class="mt-30 mb-15">
      <ApprovalRegister
        appr-cd=""
        appr-class="REPORT"
        ref="appr"
        :default-list="apprList"
        @callbackFunc="fnApprSave"
      >
      </ApprovalRegister>
    </div>

    <div class="mt-30 mb-15">
      <div class="p_bold">내용물코드</div>
      <div class="ui-table__wrap mt-15">
        <table class="ui-table text-center ui-table__td--40" id="error_wrap_contList">
          <colgroup>
            <col style="width:20%;">
            <col style="width:8%;">
            <col style="width:auto;">
            <col style="width:15%;">
            <col style="width:8%;">
          </colgroup>
          <thead>
            <tr>
              <th>내용물코드</th>
              <th>PLANT</th>
              <th>자재명</th>
              <th>실함량표 export</th>
              <th>
                <button type="button" class="ui-button ui-button__height--28 ui-button__bg--skyblue" @click="addContList">추가</button>
              </th>
            </tr>
          </thead>
          <tbody>
            <template v-if="contList && contList.length > 0">
              <tr v-for="(vo, idx) in contList" :key="'contVo_'+idx">
                <td >
                  <ap-input
                    :id="'vContentsCd_' +idx"
                    v-model:value="vo.vContCd"
                    class="ui-input__width--135"
                    :readonly="true"
                  >
                  </ap-input>
                  <button type="button"
                      :class="['ui-button',
                              'ui-button__width--40',
                              'ui-button__height--23', 
                              'ui-button__border--blue', 
                              'ui-button__radius--2',
                              'ml-10'
                              ]"
                      @click="fnSearchContPop(idx)"        
                    >검색</button>
                  <button type="button"
                      :class="['ui-button',
                              'ui-button__width--40',
                              'ui-button__height--23', 
                              'ui-button__radius--2',
                              'ml-5'
                              ]"
                      @click="fnDeleteContent(idx);"         
                    >삭제</button>
                </td>
                <td>
                  {{ vo.vPlantCd }}
                </td>
                <td>
                  <ap-input
                    :maxlength="200"
                    :id="'vContentsNm_' +idx"
                    v-model:value="vo.vContNm"
                    :readonly="true"
                  >
                  </ap-input>
                </td>
                <td>
                  <a href="javascript:;" class="tit-link txt_blue" @click="fnNoteContPop(vo)">상세보기</a>
                </td>
                <td>
                  <button type="button" class="ui-button ui-button__bg--lightgray" @click="removeContList(idx);">삭제</button>
                </td>
              </tr>
              <span class="error-msg" id="error_msg_contList"></span>
            </template>
          </tbody>
        </table>
      </div>
    </div>

    <div id="secretDocumentArea" class="mt-30 mb-15" :style="reportRegVo.epVo.vDocType === 'TYP030' ? 'display:block;': 'display:none;'">
      <div class="p_bold">영업비밀문서 정보</div>
      <div class="ui-select-block mt-15">
        <select id="secretContNum" class="ui-select ui-select__width--120" @change="changeSecretDocument()">
          <option v-for="num in 10" :key="num" :value="num" :selected="lstSecret != null ? lstSecret.length == num : false">
          {{ num }}
          </option>
        </select>
      </div>
      <p>입력할 항목의 수를 먼저 선택하십시오.(최대 입력수 10)</p>
      <table class="ui-table text-center ui-table__td--40">
        <colgroup>
          <col style="width:5%;">
          <col style="width:20%;">
          <col style="width:auto;">
          <col style="width:15%;">
          <col style="width:30%;">
        </colgroup>
        <thead>
          <tr>
            <th>No</th>
            <th>자료명</th>
            <th>자료내용</th>
            <th>영업비밀</th>
            <th>관련자료보관소</th>
          </tr>
        </thead>
        <tbody>
          <template v-if="lstSecret">
            <tr v-for="(secretVo, idx) in lstSecret" :key="'secretVo_' + idx">
              <td>
                {{ secretVo.nSeq }}
              </td>
              <td>
                <ap-input
                  :id="'vSecretNm_' + idx"
                  v-model:value="secretVo.vSecretNm"
                >
                </ap-input>
              </td>
              <td>
                <ap-input
                  :id="'vSecret_' +idx"
                  v-model:value="secretVo.vSecret"
                >
                </ap-input>
              </td>
              <td>
                <div class="ui-radio__list">
                  <div class="ui-radio__inner">
                    <ap-input-radio
                      v-model:model="secretVo.nSecretLevel"
                      :value="1"
                      :label="1"
                      :id="'vSecretType_' +secretVo.nSeq + '_1'"
                      :name="'vSecretType_' +secretVo.nSeq"
                    >
                    </ap-input-radio>
                    <ap-input-radio
                      v-model:model="secretVo.nSecretLevel"
                      :value="2"
                      :label="2"
                      :id="'vSecretType_' +secretVo.nSeq + '_2'"
                      :name="'vSecretType_' +secretVo.nSeq"
                    >
                    </ap-input-radio>
                    <ap-input-radio
                      v-model:model="secretVo.nSecretLevel"
                      :value="3"
                      :label="3"
                      :id="'vSecretType_' +secretVo.nSeq + '_3'"
                      :name="'vSecretType_' +secretVo.nSeq"
                    >
                    </ap-input-radio>
                  </div>
                </div>
              </td>
              <td>
                <ap-input
                  :id="'vSecretRoom_' + idx"
                  v-model:value="secretVo.vSecretRoom"
                >
                </ap-input>
              </td>
            </tr>
          </template>
        </tbody>
      </table>
    </div>

    <div class="ui-table__wrap mt-15">
      <table class="ui-table__reset ui-table__ver">
        <colgroup>
          <col style="width:25%;">
          <col style="width:auto;">
        </colgroup>
        <tbody>
          <tr>
            <th>제목</th>
            <td id="error_wrap_vTitle">
              <ap-input
                :maxlength="200"
                id="vTitle"
                v-model:value="reportRegVo.epVo.vTitle"
                @change="fnValidate('vTitle');"
              >
              </ap-input>
              <br/>
              <a href="javascript:;" class="tit-link txt_blue" @click="insertJoditEditorHtml('A')">[<b>기시, 안유, 허가, 신고</b> 양식]</a>
              &nbsp;&nbsp;
              <a href="javascript:;" class="tit-link txt_blue" @click="insertJoditEditorHtml('B')">[<b>기시변경, 허가변경, 변경신고</b> 양식]</a>
              <span class="error-msg" id="error_msg_vTitle"></span>
            </td>
          </tr>
          <tr>
            <td colspan="2">
              <jodit-editor
                v-model="reportRegVo.epVo.cContent"
                :uploadCd="uploadParams.uploadCd"
              >
              </jodit-editor>
            </td>
          </tr>
          <tr>
            <th>검색조건</th>
            <td>
              <ap-input
                :maxlength="200"
                id="vKeyword"
                v-model:value="reportRegVo.epVo.vKeyword"
              >
              </ap-input>
            </td>
          </tr>
          <tr v-if="reportRegVo.vActionFlag === 'M'">
            <th>
              <span class="ui-require"><span class="for-a11y">(필수)</span></span>
              &nbsp;
              보안
            </th>
            <td>
              <AuthSecurityRegister
                flag-rec="AUTH030"
                :record-id="'EP_'+reportRegVo.epVo.vRecordid"
                flag-attach-auth="Y"
              >
              </AuthSecurityRegister>
            </td>
          </tr>
          <tr>
            <th>첨부파일</th>
            <td>
              <UploadFileRegister
                uploadid="EPR001"
                :parent-info="uploadParams"
              >
              </UploadFileRegister>
              
            </td>
          </tr>
        </tbody>
      </table>
      <div>
        <p class="txt_red">*[기시, 안유, 허가] 의뢰시 의약외품 심사의뢰 양식 파일 작성하여 첨부할 것 (분석팀에 규격작업 의뢰하여 완료된 처방 포함)</p>
        <p class="txt_red">*[신고, 기시변경, 허가변경, 변경신고]의 경우 민원서식기 파일 첨부할 것 (분석팀에 규격작업 의뢰하여 완료된 처방 반영)</p>
      </div>
    </div>
    
    <div class="page-bottom">
      <div class="page-bottom__inner">
        <div class="ui-buttons ui-buttons__right">
          <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnAppr">결재의뢰</button>
          <button type="button" class="ui-button ui-button__border--blue" @click="fnSave">임시저장</button>
          <button type="button" class="ui-button ui-button__bg--gray" @click="goList">목록</button>
        </div>
      </div>
    </div>
  </div>

  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @callbackFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, inject, ref, reactive } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useRoute } from 'vue-router'
import { useActions } from 'vuex-composition-helpers'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'

export default {
  name: 'ProcessQdrugReportMissionReg',
  components: {
    ReferenceRegister: defineAsyncComponent(() => import('@/components/comm/ReferenceRegister.vue')),
    ApprovalRegister: defineAsyncComponent(() => import('@/components/comm/ApprovalRegister.vue')),
    JoditEditor: defineAsyncComponent(() => import('@/components/comm/JoditEditor.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    MateContTablePop: defineAsyncComponent(() => import('@/components/labcommon/popup/MateContTablePop.vue')),
    UploadFileRegister: defineAsyncComponent(() => import('@/components/comm/UploadFileRegister.vue')),
    AuthSecurityRegister: defineAsyncComponent(() => import('@/components/comm/AuthSecurityRegister.vue')),
    ContSearchPop: defineAsyncComponent(() => import('@/components/labcommon/popup/ContSearchPop.vue')),
  },
  props : {
    vActionFlag : {
      type: Object,
      default: () => {
        return {}
      }
    },
    detailInfo : {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  setup (props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const reportRegVo = ref(null)
    const route = useRoute()
    const { openAsyncAlert, openAsyncConfirm } = useActions(['openAsyncAlert', 'openAsyncConfirm'])
    const uploadParams = reactive({
      vRecordid: commonUtils.isNotEmpty(props.detailInfo.vRecordid) ? props.detailInfo.vRecordid : '',
      items: []
    })

    const lstSecret = ref([])
    const contList = ref([])
    const selectedIdx = ref(null)
    const arrQsCd = ref(null)
    const appr = ref(null)
    const refComp = ref(null)
    const apprList = ref(null)
    const referenceList = ref(null)

    const {
      selectSaNoteEpReportReg,
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      saveSaNoteEpReport
    } = useProcessCommon()

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const regAddParam = ref({
      arrQsCd : [],
      vMenuType : ''
    })

    const init = async () => {
      const payload = {
        vLabNoteCd : route.query.vLabNoteCd || '',
        vRecordid : commonUtils.isNotEmpty(props.detailInfo.vRecordid) ? props.detailInfo.vRecordid : ''
      }
      const result = await selectSaNoteEpReportReg(payload)
      reportRegVo.value = {...reportRegVo.value, ...result}

      findCodeList(['RD_TYPE', 'RD_STORAGE', 'QS_TYPE', 'MANU_METHOD'])

      if(reportRegVo.value.lstSecret && reportRegVo.value.lstSecret.length > 0){
        lstSecret.value = reportRegVo.value.lstSecret
      }else{
        lstSecret.value = [{
          vRecordid : '',
          vSecretNm : '',
          vSecret : '',
          nSeq : 1,
          nSecretLevel : '',
          vSecretRoom : '',
          vRegDtm : '',
          vRegUserid : '',
          vUpdateDtm : '',
          vUpdateUserid: ''
        }]
      }

      if(reportRegVo.value.vActionFlag == 'M'){
        if(reportRegVo.value.qsVo){
          regAddParam.value.arrQsCd = reportRegVo.value.qsVo.vQsType
          regAddParam.value.vMenuType = reportRegVo.value.qsVo.vManuMethod
        }
      }

      if(reportRegVo.value.lstMat && reportRegVo.value.lstMat.length > 0){
        const len = reportRegVo.value.lstMat.length
        for(let i = 0; i < len; i++){
          const obj = {
            vContCd : reportRegVo.value.lstMat[i].vMatnr,
            vContNm : reportRegVo.value.lstMat[i].vMaktx,
            vPlantCd : reportRegVo.value.lstMat[i].vPlantCd
          }
          contList.value.push(obj)
        }
      }else{
        contList.value = [{
          vContCd : reportRegVo.value.rvo.vContCd,
          vContNm : reportRegVo.value.rvo.vContNm,
          vPlantCd : reportRegVo.value.rvo.vPlantCd,
        }]
      }

      apprList.value = reportRegVo.value.apprList
      referenceList.value = reportRegVo.value.referenceList
    }

    init()

    const fnNoteContPop = async (vo) => {

      if(commonUtils.isEmpty(vo.vContCd)){
        await openAsyncAlert({ message: '내용물 코드가 존재하지 않습니다.' })
        return 
      }

      popParams.value = {
        vMatnr : vo.vContCd,
        vWerks : vo.vPlantCd,
        vLand1 : 'KR',
        vMaktx : vo.vContNm
      }

      fnOpenPopup('MateContTablePop')
    }

    const readHtmlFile = (file) => {
      var rawFile = new XMLHttpRequest();
      var allText = null
      try{
        rawFile.open("GET", file, false);
        rawFile.onreadystatechange = function ()
        {
          if(rawFile.readyState === 4)
          {
            if(rawFile.status === 200 || rawFile.status == 0)
            {
                allText = rawFile.responseText;
            }
          }
        }
        rawFile.send(null);
      }catch(e){
      }
      return allText
    }

    const insertJoditEditorHtml = (type) => {
      let allText = ''
      if(type == 'A'){
        allText = readHtmlFile('/file/qdrugReportForm1.html');
      }else{
        allText = readHtmlFile('/file/qdrugReportForm2.html');
      }

      if(commonUtils.isNotEmpty(allText)){
        reportRegVo.value.epVo.cContent = allText
      }
    }

    const changeSecretDocument = () => {
      const secretContNum = document.querySelector("#secretContNum")
      const selectNum = secretContNum.options[secretContNum.selectedIndex].value
      const currNum = lstSecret.value.length
      if(selectNum > currNum){
        const addNum = selectNum - currNum
        for(let i = 0; i < addNum; i++){
          const seq = currNum + (i + 1)
          const obj = {
            vRecordid : '',
            vSecretNm : '',
            vSecret : '',
            nSeq : seq,
            nSecretLevel : '',
            vSecretRoom : '',
            vRegDtm : '',
            vRegUserid : '',
            vUpdateDtm : '',
            vUpdateUserid: ''
          }
  
          lstSecret.value.push(obj)
        }
      }
      else{
        const minusNum = currNum - selectNum 
        lstSecret.value.splice(selectNum, minusNum)
      }
    }

    const changeDocType = (vSubCode) => {
      const secretDocumentArea = document.querySelector("#secretDocumentArea")
      if(vSubCode === 'TYP030') {   //보안문서일 때
        secretDocumentArea.style.display = 'block'
      }else{
        secretDocumentArea.style.display = 'none'
      }

      if(vSubCode === 'TYP030' || vSubCode === 'TYP020'){
        const storageCd = document.querySelector("#storageCd")
        storageCd.options.forEach((item) => {
          if(item.value === 'STR999'){  //영구(STR999)
            item.selected = true
          }else{
            item.selected = false
          }
        })

        storageCd.disabled = true
      }else{
        storageCd.disabled = false
      }
  
    }

    const addContList = () => {
      const obj = {
        vContCd : '',
        vContNm : '',
        vPlantCd : ''
      }
      contList.value.push(obj)
    }

    const removeContList = (idx) => {
      contList.value.splice(idx, 1)
    }

    const fnSearchContPop = (idx) => {
      popParams.value = {
        vDefaultTab : 'NOTE'
      }

      selectedIdx.value = idx
      popSelectFunc.value = searchContentResult
      fnOpenPopup('ContSearchPop')
    }

    const searchContentResult = (vo) => {
      contList.value[selectedIdx.value].vContCd = vo.vContCd
      contList.value[selectedIdx.value].vContNm = vo.vContNm
      contList.value[selectedIdx.value].vPlantCd = vo.vPlantCd
      fnValidate('contList')
    }

    const fnDeleteContent = (idx) => {
      selectedIdx.value = idx
      contList.value[selectedIdx.value].vContCd = ''
      contList.value[selectedIdx.value].vContNm = ''
      contList.value[selectedIdx.value].vPlantCd = ''
    }

    const fnValidate = (key) => {
      let isOk = true
      let errorMsg = '필수 입력 사항입니다.'
      commonUtils.hideErrorMessage(key)

      if(key === 'arrQsCd'){
        if(regAddParam.value.arrQsCd == null || regAddParam.value.arrQsCd.length == 0){
          isOk = false
        }
      }
      else if(key === 'vMenuType'){
        if (commonUtils.isEmpty(regAddParam.value[key])) {
          isOk = false
        }
      }
      else if(key === 'vStorageCd'){
        const storageCd = document.querySelector("#storageCd")
        if(commonUtils.isEmpty(storageCd.options[storageCd.selectedIndex].value)){
          isOk = false
        }
      }
      else if(key === 'contList'){
        if(contList.value.length == 0){
          isOk = false
        }

        if(contList.value.length > 0){
          contList.value.forEach((item) => {
            if(commonUtils.isEmpty(item.vContCd)){
              isOk = false
            }
          })
        }
      }
      else if (commonUtils.isEmpty(reportRegVo.value.epVo[key])) {
        isOk = false
      }

      if (!isOk) {
        commonUtils.showErrorMessage(key, errorMsg)
      }

      return isOk
    }

    const fnValidateAll = () => {
      let isOk = true
      const arrChkKey = ['vDocType', 'vDocClassnm', 'vStorageCd', 'vTitle', 'arrQsCd', 'vMenuType', 'contList']

      commonUtils.hideErrorMessageAll(arrChkKey)

      for (const chkKey of arrChkKey) {
        if (!fnValidate(chkKey)) {
          isOk = false
        }
      }

      return isOk
    }

    const fnSave = async () => {
      if(!fnValidateAll()){
        await openAsyncAlert({ message: '필수 입력사항을 확인해 주세요.' })
        window.scrollTo(0, 0)
        return
      }

      if (!await openAsyncConfirm({ message: '임시저장 하시겠습니까?' })) {
        return
      }

      const payload = {
        vLabNoteCd : route.query.vLabNoteCd || '',
        vActionFlag : reportRegVo.value.vActionFlag,
        vApprovalYn : 'N',
        epVo: reportRegVo.value.epVo,
        regAddParam: regAddParam.value,
        lstSecret: lstSecret.value,
        contList : contList.value,
        vUploadCd: 'EPR001',
        fileList: uploadParams.items,
        vApprTypeCd: 'REPORT',
        referenceList: refComp.value.referenceList,
        apprReqInfo: {
          apprInfo: appr.value.apprInfo,
          apprList: appr.value.apprList
        },
      }

      const result = await saveSaNoteEpReport(payload)
      if (result && result === 'SUCC') {
        await openAsyncAlert({ message: '임시저장 되었습니다.' })
        goList()
      }
    }

    const fnAppr = async () => {
      if(!fnValidateAll()){
        await openAsyncAlert({ message: '필수 입력사항을 확인해 주세요.' })
        window.scrollTo(0, 0)
        return
      }

      if (appr.value) {
        appr.value.fnApprovalOpinionPop()
      }
    }

    const fnApprSave = async (draftOpinion) => {
      if (!await openAsyncConfirm({ message: '결재 의뢰 하시겠습니까?' })) {
        return
      }

      if (appr.value) {
        const payload = {
          vLabNoteCd : route.query.vLabNoteCd || '',
          vActionFlag : reportRegVo.value.vActionFlag,
          vApprovalYn : 'Y',
          epVo: reportRegVo.value.epVo,
          regAddParam: regAddParam.value,
          lstSecret: lstSecret.value,
          contList : contList.value,
          vUploadCd: 'EPR001',
          fileList: uploadParams.items,
          vApprTypeCd: 'REPORT',
          referenceList: refComp.value.referenceList,
          apprReqInfo: {
            apprInfo: appr.value.apprInfo,
            apprList: appr.value.apprList
          },
        }

        payload.apprReqInfo.apprInfo.vDraftOpinion = draftOpinion

        const result = await saveSaNoteEpReport(payload)
        if (result && result === 'SUCC') {
          await openAsyncAlert({ message: '결재 요청되었습니다.' })
          goList()
        }
      }
    }

    const goList = () => {
      context.emit('update:vActionFlag', 'L')
      context.emit('update:detailInfo', {})
    }

    return {
      t,
      commonUtils,
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      codeGroupMaps,
      reportRegVo,
      uploadParams,
      fnNoteContPop,
      insertJoditEditorHtml,
      lstSecret,
      changeSecretDocument,
      changeDocType,
      contList,
      addContList,
      removeContList,
      fnSearchContPop,
      fnDeleteContent,
      searchContentResult,
      selectedIdx,
      fnSave,
      fnAppr,
      goList,
      arrQsCd,
      fnApprSave,
      appr,
      regAddParam,
      fnValidate,
      refComp,
      apprList,
      referenceList,
      readHtmlFile
    }
  }
}
</script>