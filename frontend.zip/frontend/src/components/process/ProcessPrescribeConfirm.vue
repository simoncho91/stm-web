<template>
  <ProcessPrescribeConfirmList
    v-if="noteType !== 'SC' && noteType !== 'SA'"
    @callbackFunc="setProgressInfo"
  >
  </ProcessPrescribeConfirmList>
  <SkincareProcessPrescribeConfirm
    v-if="noteType === 'SC'"
    @callbackFunc="setProgressInfo"
  >
  </SkincareProcessPrescribeConfirm>
  <QdrugProcessPrescribeConfirm
    v-if="noteType === 'SA'"
    @callbackFunc="setProgressInfo"
  >
  </QdrugProcessPrescribeConfirm>
</template>

<script>
import { defineAsyncComponent, ref } from 'vue'
import { useStore } from 'vuex'

export default {
  name: 'ProcessPrescribeConfirm',
  components: {
    ProcessPrescribeConfirmList: defineAsyncComponent(() => import('@/components/process/ProcessPrescribeConfirmList.vue')),
    QdrugProcessPrescribeConfirm: defineAsyncComponent(() => import('@/components/qdrug/QdrugProcessPrescribeConfirm.vue')),
    SkincareProcessPrescribeConfirm: defineAsyncComponent(() => import('@/components/skincare/SkincareProcessPrescribeConfirm.vue')),
  },
  emits: ['callbackFunc'],
  setup (props, context) {
    const checkParams = ref({})
    const store = useStore()
    const noteType = store.getters.getNoteType()

    const setProgressInfo = () => {
      context.emit('callbackFunc')
    }

    return {
      noteType,
      checkParams,
      setProgressInfo,
    }
  }
}
</script>