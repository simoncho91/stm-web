<template>
  <div class="contents-box__inner">
    <div class="ui-table__wrap">
      <table class="ui-table text-center ui-table__td--40">
        <tbody>
          <tr class="tr-contents">
            <td class="inside-td">
              <div class="inside-td__item mt-15">
                <ProcessPQCGateCheckList
                  v-if="resultVo?.pqcList && resultVo?.pqcList.length > 0"
                  v-model:pqc-list="resultVo.pqcList"
                  :tr-map="resultVo.trMap"
                  :gate-flag="'GATE2'"
                  v-model:pqc-user-comment="pqcUserComment"
                  ref="pqc"
                >
                </ProcessPQCGateCheckList>
                <ProcessTrGate01List
                  v-if="resultVo?.trGate1List && resultVo?.trGate1List.length > 0"
                  :tr-gate1-list="resultVo.trGate1List"
                >
                </ProcessTrGate01List>
              </div>

              <div class="inside-td__item">
                <ApprovalRegister
                  :appr-cd="resultVo?.rvo.vGate0ApprCd"
                  :appr-class="'LAB002_'+ noteType"
                  :default-list="resultVo?.userList"
                  ref="appr"
                  @callbackFunc="fnApprSave"
                >
                </ApprovalRegister>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <div class="page-bottom">
    <div class="page-bottom__inner">
      <div class="ui-buttons ui-buttons__right">
        <button type="button" class="ui-button ui-button__bg--skyblue" @click.prevent="fnAppr()">승인요청</button>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'

export default {
  name: 'ProcessPrescribeConfirmReg',
  props: {
    checkParams: {
      type: Object,
      default: () => {
        return {}
      }
    },
    flagOpenGate02: {
      type: String,
      default: ''
    }
  },
  emits: ['update:flagOpenGate02', 'callbackFunc'],
  components: {
    ProcessPQCGateCheckList: defineAsyncComponent(() => import('@/components/process/ProcessPQCGateCheckList.vue')),
    ProcessTrGate01List: defineAsyncComponent(() => import('@/components/process/ProcessTrGate01List.vue')),
    ApprovalRegister: defineAsyncComponent(() => import('@/components/comm/ApprovalRegister.vue')),
  },
  setup (props, context) {
    const { openAsyncAlert, openAsyncConfirm } = useActions(['openAsyncAlert','openAsyncConfirm'])
    const gate02CheckParam = ref(props.checkParams)
    const commonUtils = inject('commonUtils')
    const pqc = ref(null)
    const appr = ref(null)
    const resultVo = ref(null)
    const pqcUserComment = ref(null)

    const {
      noteType,
      selectLabNoteGate2Reg,
      saveLabNoteGate02ApprovalRequest,
    } = useProcessCommon()

    const fnAppr = () => {
      if(!pqc.value.fnValidateAll()){
        openAsyncAlert({ message: '필수 입력사항을 확인해 주세요.' })
        return 
      }

      if (appr.value) {
        appr.value.fnApprovalOpinionPop()
      }
    }

    const fnApprSave = async (draftOpinion) => {
      if (!await openAsyncConfirm({ message: '결재 의뢰 하시겠습니까?' })) {
        return
      }

      if (appr.value) {
        let vContCd = ''
        let vContNm = ''
        let vLotNm = ''
        const lotList = props.checkParams.lotList
        if (lotList && lotList.length > 0) {
          const lotInfo = lotList[0]
          vContCd = lotInfo.vContCd
          vContNm = lotInfo.vContNm
          vLotNm = lotInfo.vLotNm + (lotList.length > 1 ? (' 외 ' + (lotList.length - 1) + '건') : '')
        }

        const payload = {
          vNoteType: noteType,
          vLabNoteCd: props.checkParams.vLabNoteCd,
          nVersion: props.checkParams.nVersion,
          vApprTypeCd: 'LAB002_' + noteType,
          arrContPkCd: props.checkParams.arrContPkCd,
          arrLotCd: props.checkParams.arrLotCd,
          apprReqInfo: {
            apprInfo: appr.value.apprInfo,
            apprList: appr.value.apprList
          },
          vPqcUserComment: pqcUserComment.value,
          pqcCheckList: resultVo.value.pqcList,
          vContCd,
          vContNm,
          vLotNm,
        }

        payload.apprReqInfo.apprInfo.vDraftOpinion = draftOpinion

        const result = await saveLabNoteGate02ApprovalRequest(payload)

        if (result && result === 'SUCC') {
          await openAsyncAlert({ message: '결재 요청되었습니다.' })
          context.emit('callbackFunc')
          context.emit('update:flagOpenGate02', 'N')
        }
      }
    }

    const init = async () => {
      resultVo.value = await selectLabNoteGate2Reg(props.checkParams)
    }

    init()

    return {
      pqc,
      appr,
      commonUtils,
      gate02CheckParam,
      resultVo,
      pqcUserComment,
      noteType,
      fnAppr,
      fnApprSave,
    }
  }
}
</script>