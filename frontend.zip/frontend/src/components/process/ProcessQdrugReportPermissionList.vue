<template>
  <div class="contents-box__inner">
    <div class="search-bar__row">
      <dl class="search-bar__item search-bar__item--bipartite">
        <dt class="search-bar__key search-bar__key--width-170">식약청 접수일</dt>
        <dd class="search-bar__val search-bar__val--flexible">
          <ap-date-picker-range 
            v-model:startDt="searchParams.vReStDt" 
            v-model:endDt="searchParams.vReEndDt"
            :read-only="false"
            >
          </ap-date-picker-range>
        </dd>
      </dl>
      <dl class="search-bar__item search-bar__item--bipartite">
        <dt class="search-bar__key search-bar__key--width-170">허가 완료일</dt>
        <dd class="search-bar__val">
          <ap-date-picker-range 
            v-model:startDt="searchParams.vCoStDt" 
            v-model:endDt="searchParams.vCoEndDt"
            :read-only="false"
            >
          </ap-date-picker-range>
        </dd>
      </dl>
    </div>

    <div class="search-bar__row">
      <dl class="search-bar__item search-bar__item--bipartite">
        <dt class="search-bar__key search-bar__key--width-170">검색조건</dt>
        <dd class="search-bar__val search-bar__val--flexible">
          <div class="search-form">
            <div class="search-form__inner">
              <ap-input
                v-model:value="searchParams.vKeyword"
                class="ui-input__width--full"
                placeholder="제목 or 부서 or 연구 담당자"
                @keypress-enter="fnSearchSaNoteEpReportList(1)"
              >
              </ap-input>
              <button type="button" class="button-search" 
                @click="fnSearchSaNoteEpReportList(1)"
                >
                검색
              </button>
            </div>
          </div>
        </dd>
      </dl>
    </div>
    <div class="board-top">
      <div class="ui-buttons ui-buttons__right">
        <button type="button" class="ui-button ui-button__border--blue" @click="fnGoRegPage">심사의뢰</button>
      </div>
    </div>
    <div class="mt-15">
      <div class="ui-table__wrap">
        <table class="ui-table text-center ui-table__td--40">
          <colgroup>
            <col style="width:6%;">
            <col style="width:8%;">
            <col style="width:15%;">
            <col style="width:auto;">
            <col style="width:10%;">
            <col style="width:10%;">
            <col style="width:10%;">
            <col style="width:10%;">
            <col style="width:10%;">
          </colgroup>
          <thead>
            <tr>
              <th>No.</th>
              <th>심사구분</th>
              <th>제목</th>
              <th>(내용물 코드) 내용물명</th>
              <th>상태</th>
              <th>의뢰자</th>
              <th>부서</th>
              <th>식약청 접수일</th>
              <th>허가 완료일</th>
            </tr>
          </thead>
          <tbody>
            <template v-if="list && list.length > 0">
              <tr v-for="(vo, idx) in list" :key="'tr_' + idx">
                <td>{{page.totalCnt - (page.nowPageNo - 1) * page.pageSize - idx}}</td>
                <td>
                  <template v-for="(qsVo, i) in codeGroupMaps['QS_TYPE']" :key="'qsCdVo_' + i">
                    <template v-if="vo.vQsType.indexOf(qsVo.vSubCode) > -1">
                      {{ qsVo.vSubCodenm }}<br/>
                    </template>
                  </template>
                </td>
                <td class="tit">
                  <div class="tit__inner">
                    <a href="#" class="tit-link" @click.prevent="fnGoViewPage(vo)">
                      {{ vo.vTitle }}
                    </a>
                  </div>
                </td>
                <td>
                  <ul class="qdrug-cont-list">
                    <li v-for="(contVo, idx) in vo.contList" :key="'cont_'+idx">
                      <a href="#" class="tit-link" @click.prevent="fnGoViewPage(vo)"> 
                        ({{ contVo.vContCd }}) {{ contVo.vContNm }}
                      </a>
                    </li>
                  </ul>
                </td>
                <td>
                  <template v-if="vo.vApprStatus == 'DOC500' && commonUtils.isEmpty(vo.vApprStatus2)">
                    검토의뢰
                  </template>
                  <template v-else>
                    {{ vo.vApprStatusnm2 }}
                  </template>
                </td>
                <td>{{ vo.vRegUserNm }}</td>
                <td>{{ vo.vDeptnm }}</td>
                <td>{{ commonUtils.changeStrDatePattern(vo.vKfdaReceiveDtm) }}</td>
                <td>{{ commonUtils.changeStrDatePattern(vo.vEndDtm) }}</td>
              </tr>
            </template>
            <template v-else>
              <tr>
                <td colspan="9">
                  <div class="no-result">
                    {{ t('common.msg.no_data') }}
                  </div>
                </td>
              </tr>
            </template>
          </tbody>
        </table>
      </div>
    </div>
    <div class="board-bottom">
      <div class="board-bottom__inner">
        <Pagination
          :page-info="page"
          @click="fnSearchSaNoteEpReportList"
        />
      </div>
    </div>
  </div>
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @selectFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, inject, ref } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useRoute } from 'vue-router'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'

export default {
  name: 'ProcessQdrugReportMission',
  components: {
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    DefaultIngredientDataPop: defineAsyncComponent(() => import('@/components/labcommon/popup/DefaultIngredientDataPop.vue'))
  },
  props : {
    vActionFlag : {
      type: Object,
      default: () => {
        return {}
      }
    },
    detailInfo : {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  setup (props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const route = useRoute()
    
    const {
      page,
      list,
      selectSaNoteEpReportList,
      searchParams,
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup
    } = useProcessCommon()

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const fnGoRegPage = () => {
      context.emit('update:vActionFlag', 'R')
      context.emit('update:detailInfo', {})
    }

    const fnGoViewPage = (obj) => {
      context.emit('update:vActionFlag', 'V')
      context.emit('update:detailInfo', obj)
    }

    const fnSearchSaNoteEpReportList = (pg) => {
      if(!pg){
        pg = 1
      }

      searchParams.value.nowPageNo = pg

      const payload = Object.assign({}, searchParams.value)
      payload.vReStDt = commonUtils.isNotEmpty(payload.vReStDt) ? payload.vReStDt.replaceAll('.', '') : payload.vReStDt
      payload.vReEndDt = commonUtils.isNotEmpty(payload.vReEndDt) ? payload.vReEndDt.replaceAll('.', '') : payload.vReEndDt
      payload.vCoStDt = commonUtils.isNotEmpty(payload.vCoStDt) ? payload.vCoStDt.replaceAll('.', '') : payload.vCoStDt
      payload.vCoEndDt = commonUtils.isNotEmpty(payload.vCoEndDt) ? payload.vCoEndDt.replaceAll('.', '') : payload.vCoEndDt

      selectSaNoteEpReportList(payload)
    }
  
    const resetSearchFilter = () => {
      searchParams.value.vReStDt = ''
      searchParams.value.vReEndDt = ''
      searchParams.value.vCoStDt = ''
      searchParams.value.vCoEndDt = ''
      searchParams.value.vKeyword = ''

      fnSearchSaNoteEpReportList(1)
    }

    const init = () => {
      const vRecordid = route.query.vRecordid
      if(!vRecordid){
        fnSearchSaNoteEpReportList(1)
        findCodeList(['QS_TYPE'])
      }else{
        const obj = {
          vLabNoteCd : route.query.vLabNoteCd,
          vRecordid : route.query.vRecordid
        }
        fnGoViewPage(obj)
      }
    }

    init()

    return {
      t,
      commonUtils,
      searchParams,
      page,
      list,
      popupContent,
      popParams,
      popSelectFunc,
      fnSearchSaNoteEpReportList,
      fnOpenPopup,
      fnGoViewPage,
      fnGoRegPage,
      resetSearchFilter,
      codeGroupMaps
    }
  }
}
</script>