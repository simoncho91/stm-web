<template>
  <div class="version-tab__top">
    <ApTab
      mst-id="version-tab"
      :tab-list="tabList"
      @click="getSelectedTabEvent"
      :default-tab="defaultTab"
      :tab-style="['version-tab__top__inner', 'version-tab__top__lists', 'version-tab__top__list', 'version-tab__top__link']"
    >
    </ApTab>
  </div>

  <template v-if="reportRegVo">
    <ProcessFuncTestReportRegVersion
      :report-reg-info="reportRegVo"
      @fnTestReqList="fnTestReqList"
    >
    </ProcessFuncTestReportRegVersion>
  </template>
</template>

<script>
import { defineAsyncComponent, reactive, ref, inject } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'
import { useRoute } from 'vue-router'

export default {
  name: 'ProcessFuncTestReportReg',
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    ProcessFuncTestReportRegVersion: defineAsyncComponent(() => import('@/components/process/ProcessFuncTestReportRegVersion.vue')),
  },
  props : {
    actionFlag: {
      type: Object,
      default: () => {
        return {}
      }
    },
    flagSaveAction: {
      type: Object,
      default: () => {
        return {}
      }
    },
    detailInfo : {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  emits:['update:actionFlag', 'update:flagSaveAction', 'update:detailInfo'],
  setup (props, context) {

    const selectedTab = ref('testReport')
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])
    const route = useRoute()
    const {
      selectFuncTestEpReportReg
    } = useProcessCommon()

    const reportRegVo = ref(null)
    const defaultTab = ref(null)
    const tabList = ref([])

    const getSelectedTabEvent = async (item) => {
      selectedTab.value = item.tabId
      const selectVersion = item.tabId.split("_")[1]
      const payload = {
        vLabNoteCd : route.query.vLabNoteCd || '',
        nVersion : selectVersion
      }

      const result = await selectFuncTestEpReportReg(payload)
      reportRegVo.value = { ...result}

    }

    const init = async () => {
      const payload = {vLabNoteCd : route.query.vLabNoteCd || ''}
      const result = await selectFuncTestEpReportReg(payload)
      reportRegVo.value = {...reportRegVo.value, ...result}

      makeTabList(reportRegVo.value)
    }

    const makeTabList = (reportRegVo) => {
      const verList = reportRegVo.verList
      const basicInfo = reportRegVo.basicInfo

      if(verList.length > 0){
        verList.some(item => {
          const obj = {
            tabId : '',
            tabNm : ''
          }

          if(basicInfo.nVersion === item.nVersion){
            defaultTab.value = item.vVersionKey
          }

          obj.tabId = item.vVersionKey
          obj.tabNm = item.vVersionTxt
          tabList.value.push(obj)
        })
      }
    }

    init()

    const fnTestReqList = () => {
      context.emit('update:actionFlag', 'L')
    }

    return {
      tabList,
      selectedTab,
      defaultTab,
      getSelectedTabEvent,
      closeAsyncPopup, 
      selectFuncTestEpReportReg,
      reportRegVo,
      makeTabList,
      fnTestReqList
    }
  }
}
</script>