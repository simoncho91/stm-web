<template>
  <div class="contents-box__inner process-area">
    <div class="search-bar__row">
      <dl class="search-bar__item">
        <dt class="search-bar__key search-bar__key--width-auto">BOM 승인일</dt>
        <dd class="search-bar__val">
          <ap-date-picker-range v-model:startDt="searchParams.vStartDt" v-model:endDt="searchParams.vEndDt"></ap-date-picker-range>
        </dd>
      </dl>
      <dl class="search-bar__item">
        <dt class="search-bar__key search-bar__key--width-auto">검색조건</dt>
        <dd class="search-bar__val">
          <div class="search-form">
            <div class="search-form__inner">
              <ap-input
                v-model:value="searchParams.vKeyword"
                class="ui-input__width--258"
                :placeholder="'내용물코드 or 내용물명'"
                @keypress-enter="fnSearch(1)"
              >
              </ap-input>
              <button type="button" class="button-search" @click="fnSearch(1)">검색</button>
            </div>
          </div>
        </dd>
      </dl>
    </div>

    <div class="mt-15">
      <div class="ui-table__wrap">
        <table class="ui-table text-center ui-table__td--40">
          <colgroup>
            <col style="width:10rem;">
            <col style="width:8rem;">
            <col style="width:8rem;">
            <col style="width:auto;">
            <col style="width:16rem;">
            <col style="width:15rem;">
            <col style="width:12rem;">
          </colgroup>
          <thead>
            <tr>
              <th>전송구분</th>
              <th>버전</th>
              <th>LOT</th>
              <th>내용물명</th>
              <th>SAP 전송상태</th>
              <th>플랜트</th>
              <th>전송일</th>
            </tr>
          </thead>
          <tbody>
            <template v-if="list && list.length > 0">
              <tr v-for="(vo, idx) in list" :key="'bom_req_' + idx">
                <td>{{ vo.vPilotTestSeqnoNm }}</td>
                <td>{{ vo.vVersionTxt }}</td>
                <td>{{ vo.vLotNm }}</td>
                <td><a href="#" class="tit-link" @click.prevent="goView(vo)">{{ vo.vContNm }}</a></td>
                <td class="td_status">
                  <span :class="vo.vSapType === 'E' ? 'txt_red' : ''">{{ vo.vSapStatusnm }}</span>
                  <span class="status_tooltip" v-if="commonUtils.isNotEmpty(vo.vSapMessage)">
                    {{ vo.vSapStatusnm }} : {{vo.vSapMessage }}
                  </span>
                </td>
                <td>[{{ vo.vPlantCd }}] {{ vo.vPlantNm }}</td>
                <td>{{ commonUtils.changeStrDatePattern(vo.vRegDtm) }}</td>
              </tr>
            </template>
            <template v-else>
              <tr>
                <td colspan="7">
                  <div class="no-result">
                    {{ t('common.msg.no_data') }}
                  </div>
                </td>
              </tr>
            </template>
          </tbody>
        </table>
      </div>

      <div class="board-bottom">
        <div class="board-bottom__inner">
          <Pagination
            :page-info="page"
            @click="fnSearch"
          >
          </Pagination>
        </div>
      </div>

    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, reactive, inject } from 'vue'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'
import { useRoute } from 'vue-router'

export default {
  name: 'ProcessBOMList',
  components: {
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
  },
  props:{
    vActionFlag: {
      type: String,
      default: 'L'
    },
  },
  setup (props, context) {
    const commonUtils = inject('commonUtils')
    const t = inject('t')
    const route = useRoute()
    const {
      selectLabNoteBomSendList,
      list,
      page,
      noteType,
    } = useProcessCommon()

    const searchParams = reactive({
      vKeyword: '',
      vLabNoteCd: route.query.vLabNoteCd || '',
      vStartDt: '',
      vEndDt: '',
      nowPageNo: 1,
    })

    const fnSearch = (pg) => {
      if (!pg) {
        pg = 1
      }

      searchParams.nowPageNo = pg
      selectLabNoteBomSendList(searchParams)
    }

    const init = () => {
      fnSearch(1)
    }

    init()

    const goView = (item) => {
      const detailInfo = {
        vContPkCd: item.vContPkCd,
        nVersion: item.nVersion,
        vLotCd: item.vLotCd,
        vApprCd: item.vApprCd || '',
        vFlagApprBom: item.vFlagApprBom || '',
        vLabNoteCd: route.query.vLabNoteCd || '',
        vPqcResCd: item.vPqcResCd || '',
        vNoteType: noteType
      }

      context.emit('update:detailInfo', detailInfo)
      context.emit('update:vActionFlag', 'V')
    }

    return {
      t,
      commonUtils,
      searchParams,
      list,
      page,
      fnSearch,
      goView
    }
  }
}
</script>