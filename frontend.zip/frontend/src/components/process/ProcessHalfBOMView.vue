<template>
  <div class="contents-box__inner">
    <table class="ui-table__th--bg-gray mb-15" v-if="noteInfo">
      <colgroup>
        <col style="width:14rem">
        <col style="width:auto">
        <col style="width:14rem">
        <col style="width:auto">
      </colgroup>
      <tbody>
        <tr>
          <th>제품/원료명</th>
          <td colspan="3">
            {{ noteInfo.vContNm }}
            <template v-if="Number(noteInfo.nContNum) > 0">
              외 {{ noteInfo.nContNum }}건
            </template>
          </td>
        </tr>
        <tr>
          <th>내용물 코드</th>
          <td>
            {{ noteInfo.vContCd }}
            <template v-if="Number(noteInfo.nContNum) > 0">
              외 {{ noteInfo.nContNum }}건
            </template>
          </td>
          <th>연구담당자</th>
          <td>
            {{ noteInfo.vUsernm }} ({{ noteInfo.vUserid }} / {{ noteInfo.vUsrDeptnm }})
          </td>
        </tr>
        <tr>
          <th>브랜드</th>
          <td>{{ noteInfo.vBrdNm }}</td>
          <th>Plant</th>
          <td>{{ noteInfo.vPlantNm }}</td>
        </tr>
      </tbody>
    </table>
    <div class="ui-table__wrap">
      <table class="ui-table text-center ui-table__td--40">
        <tbody>
          <tr class="tr-contents">
            <td class="inside-td inside-td__p30">
              <div class="inside-td__item">
                <div class="inside-td__item--title">BOM 정보</div>
                <div class="inside-td__table--wrap">
                  <div class="code-contcd__wrap">
                    <ul class="ui-list code-contcd__list" v-if="lotList && lotList.length > 0">
                      <li class="code-contcd__item"
                        v-for="(vo, index) in lotList"
                        :key="'contcd_' + index"
                      >
                        <button
                          type="button"
                          class="code-contcd__button code-contcd__button--code"
                          :class="selectLotCd === vo.vLotCd ? 'is-click' : ''"
                          @click="fnLotBomList(vo)"
                        >
                          {{ vo.vContCd }}
                        </button>
                      </li>
                    </ul>
                  </div>
                  <table
                    class="ui-table__reset inside-td__table inside-td__table--borderR-none mt-20"
                    v-if="bomList && bomList.length > 0"
                  >
                    <colgroup>
                      <col style="width:15%"> 
                      <col style="width:20%"> 
                      <col style="width:auto"> 
                      <col style="width:10%"> 
                    </colgroup>
                    <thead>
                      <tr>
                        <th>NO</th>
                        <th>원료코드</th>
                        <th>원료명</th>
                        <th>
                          <span class="txt_gray f-weight-700 f-size-12">{{ bomList[0].vVersionTxt}} - {{ bomList[0].vLotNm}}</span><br>
                          함량
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-for="(vo, idx) in bomList" :key="'bom_' + idx">
                        <td>{{ idx + 1 }}</td>
                        <td>
                          <template v-if="commonUtils.isEmpty(vo.vMateCd) && vo.vMateDbTypeCd === 'SUP'">
                            {{ vo.vMateTempCd }}
                          </template>
                          <template v-else>
                            {{ vo.vMateCd }}
                          </template>
                        </td>
                        <td class="t-left">
                          <MateName
                            :mate-info="vo"
                          >
                          </MateName>
                        </td>
                        <td class="t-right">{{ vo.nRate }}</td>
                      </tr>
                      <tr class="inside-td__table--total">
                        <td class="inside-td__total--text">합계</td>
                        <td></td>
                        <td></td>
                        <td class="inside-td__total--num t-right">{{ bomList[0].nRateSum }}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <div class="page-bottom">
    <div class="page-bottom__inner">
      <div class="ui-buttons ui-buttons__right">
        <button type="button" class="ui-button ui-button__bg--gray" @click="goList()">목록</button>
      </div>
    </div>
  </div>
  
</template>

<script>
import { defineAsyncComponent, ref, inject, computed } from 'vue'
import { useHalfProcessCommon } from '@/compositions/labcommon/useHalfProcessCommon'
import { useActions } from 'vuex-composition-helpers'
import { useStore } from 'vuex'

export default {
  name: 'ProcessBomView',
  props: {
    vActionFlag: {
      type: String,
      default: 'V'
    },
    detailInfo: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: '',
          vContPkCd: '',
          nVersion: '',
          vLotCd: '',
          vApprCd: '',
          vFlagApprBom: '',
          vNoteType: '',
        }
      }
    }
  },
  components: {
    ApprovalView: defineAsyncComponent(() => import('@/components/comm/ApprovalView.vue')),
    ReferenceView: defineAsyncComponent(() => import('@/components/comm/ReferenceView.vue')),
    MateName: defineAsyncComponent(() => import('@/components/labcommon/MateName.vue')),
    ProcessPQCGateCheckInfo: defineAsyncComponent(() => import('@/components/process/ProcessPQCGateCheckInfo.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    OpinionViewPop: defineAsyncComponent(() => import('@/components/approval/popup/OpinionViewPop.vue')),
  },
  emits: ['update:vActionFlag'],
  setup (props, context) {
    const commonUtils = inject('commonUtils')
    const bomList = ref(null)
    const lotList = ref(null)
    const store = useStore()
    const { openAsyncConfirm, openAsyncAlert } = useActions(['openAsyncConfirm', 'openAsyncAlert'])
    const noteInfo = computed(() => store.getters.getNoteInfo())
    const selectLotCd = ref(null)

    const {
      selectLabNoteBomMateRateInfo,
      selectLabNoteBomMateView,
      noteType,
    } = useHalfProcessCommon()

    const goList = () => {
      context.emit('update:vActionFlag', 'L')
    }

    const init = async () => {
      const result = await selectLabNoteBomMateView(props.detailInfo)
      
      if(result){
        bomList.value = result.data.bomList
        lotList.value = result.data.lotList

        if(lotList.value && lotList.value.length > 0){
          selectLotCd.value = props.detailInfo.vLotCd
        }
      }
    }

    init()

    const fnLotBomList = async (item) => {
      if (selectLotCd.value !== item.vLotCd) {
        const payload = {
          ...props.detailInfo,
          ...{vLotCd : item.vLotCd, vContPkCd: item.vContPkCd}
        }

        const result = await selectLabNoteBomMateRateInfo(payload)

        if (result) {
          bomList.value = [ ...result ]
        }
      }

      selectLotCd.value = item.vLotCd
    }
    
    return {
      commonUtils,
      bomList,
      noteInfo,
      noteType,
      goList,
      lotList,
      selectLotCd
    }
  }
}
</script>

<style scoped>
  .contents-box__with--tab .contents-box__inner--border { margin-top: 1rem; }
</style>