<template>
  <table class="ui-table text-center ui-table__td--40">
    <colgroup>
      <col style="width:11%;">
      <col style="width:10%;">
      <col width="*">
      <col style="width:15%;">
      <col style="width:16%;">
      <col style="width:10%;">
      <col style="width:10%;">
    </colgroup>
    <thead>
      <tr>
        <th>LOT</th>
        <th>내용물코드</th>
        <th>내용물명</th>
        <th>플랜트</th>
        <th>연구담당자/담당부서</th>
        <th>결재상태</th>
        <th>효력 시작일</th>
      </tr>
    </thead>
    <tbody>
      <template v-if="apprLotList && apprLotList.length > 0">
        <tr v-for="(vo, idx) in apprLotList" :key="'tr_' + idx">
          <td>{{ vo.vVersionTxt }} - {{ vo.vG2PqcLotNm }}</td>
          <td>{{ vo.vContCd}}</td>
          <td class="tit">{{ vo.vContNm }}</td>
          <td>[{{ vo.vPlantCd }}] {{ vo.vPlantNm }}</td>
          <td>{{ noteInfo.vUsernm }} / {{ noteInfo.vDeptNm }}</td>
          <td>{{ vo.vApprStatusnm }}</td>
          <td>{{ commonUtils.changeStrDatePattern(vo.vEffectDtm) }}</td>
        </tr>
      </template>
      <template v-else>
        <tr>
          <td colspan="7">
            <div class="no-result">{{ t('common.msg.no_data') }}</div>
          </td>
        </tr>
      </template>
    </tbody>
  </table>
</template>

<script>
import { inject } from 'vue'
export default {
  name: 'ProcessPrescribeConfirmLotList',
  props: {
    apprLotList: {
      type: Array,
      default: () => {
        return []
      }
    },
    noteInfo: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  setup (props) {
    const commonUtils = inject('commonUtils')
    return {
      commonUtils,
    }
  }
}
</script>