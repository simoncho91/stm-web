<template>
  <div class="h-100">
    <template v-if="vActionFlag === undefined || vActionFlag === 'LIST'">
      <template v-if="noteType === 'SA'">
        <ProcessIngredientApproveListSA
          @changePage="fnChangePage"
        />
      </template>
      <template v-else>
        <ProcessIngredientApproveList
          @changePage="fnChangePage"
        />
      </template>
    </template>
    <template v-if="vActionFlag === 'REG'">
      <template v-if="noteType === 'SA' && regParams.vFlagSAIngr === 'Y'">
        <ProcessIngredientApproveRegSA
          :reg-params="regParams"
          @changePage="fnChangePage"
        />
      </template>
      <template v-else>
        <ProcessIngredientApproveReg
          :reg-params="regParams"
          @changePage="fnChangePage"
        />
      </template>
    </template>
    <template v-if="vActionFlag === 'VIEW'">
      <template v-if="noteType === 'SA' && viewParams.vFlagSAIngr === 'Y'">
        <ProcessIngredientApproveViewSA
          :view-params="viewParams"
          @changePage="fnChangePage"
        />
      </template>
      <template v-else>
        <ProcessIngredientApproveView
          :view-params="viewParams"
          @changePage="fnChangePage"
        />
      </template>
    </template>
  </div>
</template>

<script>
import { defineAsyncComponent, ref } from 'vue'
import { useStore } from 'vuex'

export default {
  name: 'ProcessIngredientApprove',
  components: {
    ProcessIngredientApproveList: defineAsyncComponent(() => import('@/components/process/ProcessIngredientApproveList.vue')),
    ProcessIngredientApproveListSA: defineAsyncComponent(() => import('@/components/process/ProcessIngredientApproveListSA.vue')),
    ProcessIngredientApproveReg: defineAsyncComponent(() => import('@/components/process/ProcessIngredientApproveReg.vue')),
    ProcessIngredientApproveRegSA: defineAsyncComponent(() => import('@/components/process/ProcessIngredientApproveRegSA.vue')),
    ProcessIngredientApproveView: defineAsyncComponent(() => import('@/components/process/ProcessIngredientApproveView.vue')),
    ProcessIngredientApproveViewSA: defineAsyncComponent(() => import('@/components/process/ProcessIngredientApproveViewSA.vue')),
  },
  setup () {
    const store = useStore()
    const noteType = store.getters.getNoteType()

    const vActionFlag = ref('LIST')
    const regParams = ref({
      vContPkCd: '',
      vLand: '',
      vLeaveType : '',
      vFlagSAIngr: 'N',
    })
    const viewParams = ref({
      vContPkCd: '',
      vLand: '',
      vLeaveType : ''
    })

    const fnChangePage = (obj) => {
      if (!obj) {
        return
      }

      const actionFlag = obj.constructor === Object ? obj.actionFlag : obj

      vActionFlag.value = actionFlag

      if (actionFlag === 'REG') {
        // const { vContPkCd, vLand, vLeaveType, vFlagSAIngr } = obj

        // regParams.value = {
        //   vContPkCd: vContPkCd,
        //   vLand: vLand,
        //   vLeaveType : vLeaveType,
        //   vFlagSAIngr: vFlagSAIngr,
        // }
        regParams.value = obj
      }
      if (actionFlag === 'VIEW') {
        // const { vContPkCd, vMatnr, vWerks, vZversion, vFlagSAIngr } = obj

        // viewParams.value = {
        //   vContPkCd: vContPkCd,
        //   vMatnr: vMatnr,
        //   vWerks : vWerks,
        //   vZversion : vZversion
        // }
        viewParams.value = obj
      }
    }

    return {
      noteType,
      vActionFlag,
      regParams,
      viewParams,
      fnChangePage,
    }
  }
}
</script>