<template>
  <ProcessPilotList
    v-if="vActionFlag === 'L'"
    v-model:vActionFlag="vActionFlag"
    v-model:detail-info="detailInfo"
  >
  </ProcessPilotList>
  <ProcessPilotRegister
    v-if="vActionFlag === 'R'"
    v-model:vActionFlag="vActionFlag"
    @callbackFunc="setProgressInfo"
  >
  </ProcessPilotRegister>
  <ProcessPilotView
    v-if="vActionFlag === 'V'"
    v-model:vActionFlag="vActionFlag"
    v-model:detail-info="detailInfo"
  >
  </ProcessPilotView>

</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'
import { useRoute } from 'vue-router'

export default {
  name: 'ProcessPilot',
  components: {
    ProcessPilotList: defineAsyncComponent(() => import('@/components/process/ProcessPilotList.vue')),
    ProcessPilotRegister: defineAsyncComponent(() => import('@/components/process/ProcessPilotRegister.vue')),
    ProcessPilotView: defineAsyncComponent(() => import('@/components/process/ProcessPilotView.vue')),
  },
  emits: ['callbackFunc'],
  setup (props, context) {
    const route = useRoute()
    const vActionFlag = ref('L')
    const detailInfo = ref({})
    const commonUtils = inject('commonUtils')

    const setProgressInfo = () => {
      context.emit('callbackFunc')
    }

    const init = () => {
      const version = route.query.nFormulaVer
      const lotCd = route.query.vFormulaLotCd

      if (commonUtils.isNotEmpty(version) && commonUtils.isNotEmpty(lotCd)) {
        vActionFlag.value = 'R'
      }
    }

    init()

    return {
      vActionFlag,
      detailInfo,
      setProgressInfo,
    }
  }
}
</script>