<template>
  <div class="contents-box__inner process-area">
    <div class="search-bar__row">
      <dl class="search-bar__item">
        <dt class="search-bar__key search-bar__key--width-75">효력 시작일</dt>
        <dd class="search-bar__val">
          <ap-date-picker-range v-model:startDt="searchParams.vStartDt" v-model:endDt="searchParams.vEndDt"></ap-date-picker-range>
        </dd>
      </dl>
      <dl class="search-bar__item">
        <dt class="search-bar__key search-bar__key--width-75">검색조건</dt>
        <dd class="search-bar__val">
          <div class="search-form">
            <div class="search-form__inner">
              <ap-input
                v-model:value="searchParams.vKeyword"
                :placeholder="'내용물코드 or 내용물명'"
                @keypress-enter="fnSearch(1)"
              >
              </ap-input>
              <button type="button" class="button-search" @click="fnSearch(1)">검색</button>
            </div>
          </div>
        </dd>
      </dl>
      <div class="pilot-btn-area">
        <ap-selectbox
          v-model:value="selectedVer"
          :options="verList"
          input-class="ui-select__width--110"
          codeKey="nVersion"
          codeNmKey="vVersionTxt"
        >
        </ap-selectbox>
        <AllLabNoteTestReq
          v-if="noteInfo?.vLabTypeCd !== 'LNC07_02'"
          :noteInfo="noteInfo"
          :nVersion="selectedVer"
          vGateCd="GATE_2"
        ></AllLabNoteTestReq>
        <button type="button" class="ui-button ui-button__bg--skyblue ml-5" v-if="showRegBtn()" @click="goReg()">등록</button>
      </div>
    </div>
    <div class="mt-15">
      <div class="ui-table__wrap">
        <table class="ui-table text-center ui-table__td--40">
          <colgroup>
            <col style="width:9rem;">
            <col style="width:8rem;">
            <col style="width:auto;">
            <col style="width:16rem;">
            <col style="width:8rem;">
            <col style="width:8rem;">
            <col style="width:10rem;">
            <col style="width:10rem;">
            <col v-if="noteType === 'SC'" style="width:8rem;">
            <col style="width:15rem;">
          </colgroup>
          <thead>
            <tr>
              <th>PILOT회차</th>
              <th>내용물코드</th>
              <th>내용물명</th>
              <th>플랜트</th>
              <th>버전</th>
              <th>LOT</th>
              <th>SAP 전송상태</th>
              <th>효력시작일</th>
              <th v-if="noteType === 'SC'">결재상태</th>
              <th>연구담당자</th>
            </tr>
          </thead>
          <tbody>
            <template v-if="list && list.length > 0">
              <tr v-for="(vo, idx) in list" :key="'bom_req_' + idx">
                <td>{{ vo.nSendSeq }}회차</td>
                <td>{{ vo.vContCd }}</td>
                <td>
                  <a href="#" class="tit-link" @click.prevent="goView(vo)">{{ vo.vContNm }}</a>
                </td>
                <td>[{{ vo.vPlantCd }}] {{ vo.vPlantNm }}</td>
                <td>{{ vo.vVersionTxt }}</td>
                <td>{{ vo.vLotNm }}</td>
                <td class="td_status">
                  <span :class="vo.vSapType === 'E' ? 'txt_red' : ''">{{ vo.vSapStatusnm }}</span>
                  <span class="status_tooltip" v-if="commonUtils.isNotEmpty(vo.vSapMessage)">
                    {{ vo.vSapStatusnm }} : {{vo.vSapMessage }}
                  </span>
                </td>
                <td>{{ commonUtils.changeStrDatePattern(vo.vEffectDtm) }}</td>
                <td v-if="vo.nSort === 1 && noteType === 'SC'" :rowspan="vo.nRowCnt">{{ vo.vStatusNm }}</td>
                <td v-if="vo.nSort === 1" :rowspan="vo.nRowCnt">
                  {{ vo.vUsernm }} 
                  <br> ({{ vo.vDeptNm }})
                </td>
              </tr>
            </template>
            <template v-else>
              <tr>
                <td :colspan="noteType === 'SC' ? '10' : '9'">
                  <div class="no-result">
                    {{ t('common.msg.no_data') }}
                  </div>
                </td>
              </tr>
            </template>
          </tbody>
        </table>
      </div>
    </div>
    <div class="board-bottom">
      <div class="board-bottom__inner">
        <Pagination
          :page-info="page"
          @click="fnSearch"
        >
        </Pagination>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, reactive, ref, inject, computed } from 'vue'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useRoute } from 'vue-router'
import { useStore } from 'vuex'

export default {
  name: 'ProcessPilotList',
  components: {
    AllLabNoteTestReq: defineAsyncComponent(() => import('@/components/labcommon/AllLabNoteTestReq.vue')),
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
  },
  props: {
    vActionFlag: {
      type: String,
      default: 'L'
    },
    detailInfo: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: '',
          vContPkCd: '',
          nVersion: '',
          vLotCd: '',
          vApprCd: '',
          vFlagApprBom: '',
          vNoteType: '',
        }
      }
    },
  },
  emits:['update:vActionFlag', 'update:detailInfo'],
  setup (props, context) {

    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const route = useRoute()
    const store = useStore()
    const myInfo = store.getters.getMyInfo()
    const noteInfo = computed(() => store.getters.getNoteInfo())
    const verList = ref(null)
    const selectedVer = ref('')
    
    const {
      selectLabNotePilotList,
      selectGate1ApprDetailInfo,
      list,
      page,
      noteType,
    } = useProcessCommon()

    const {
      selectNoteMstVerList,
    } = useLabCommon()

    const searchParams = reactive({
      vKeyword: '',
      vLabNoteCd: route.query.vLabNoteCd || '',
      vStartDt: '',
      vEndDt: '',
      nowPageNo: 1,
    })

    const showRegBtn = () => {
      let isVisible = false

      if ((noteInfo.value && noteInfo.value.vUserid === myInfo.loginId) || commonUtils.checkAuth('S000000')) {
        isVisible = true
      }

      return isVisible
    }

    const goReg = () => {
      context.emit('update:vActionFlag', 'R')
    }

    const goView = (item) => {
      const detailInfo = {
        vContPkCd: item.vContPkCd,
        nVersion: item.nVersion,
        vLotCd: item.vLotCd,
        vApprCd: item.vApprCd,
        vFlagApprBom: item.vFlagApprBom,
        vLabNoteCd: route.query.vLabNoteCd || '',
        vPqcResCd: item.vPqcResCd,
        vNoteType: noteType
      }

      context.emit('update:detailInfo', detailInfo)
      context.emit('update:vActionFlag', 'V')
    }

    const fnSearch = (pg) => {
      if (!pg) {
        pg = 1
      }

      searchParams.nowPageNo = pg
      selectLabNotePilotList(searchParams)
    }

    const init = async () => {
      const vApprCd = route.query.vApprCd

      if (!vApprCd || noteType !== 'SC') {
        fnSearch(1)
      } else {
        const payload = {
          vLabNoteCd: route.query.vLabNoteCd,
          vApprCd: route.query.vApprCd
        }
        const result = await selectGate1ApprDetailInfo(payload)

        if (result) {
          goView(result)
        }
      }

      verList.value = await selectNoteMstVerList({ vLabNoteCd: route.query.vLabNoteCd })
    }

    init()

    return {
      t,
      noteType,
      commonUtils,
      searchParams,
      list,
      page,
      noteInfo,
      verList,
      selectedVer,
      fnSearch,
      showRegBtn,
      goReg,
      goView,
    }
  }
}
</script>

<style scoped>
  .pilot-btn-area { position: absolute; right: 2.5rem; display: flex;}
</style>