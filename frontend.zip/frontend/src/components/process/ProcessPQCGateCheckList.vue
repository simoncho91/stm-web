<template>
  <div class="inside-td__item">
    <div class="inside-td__item--title">{{ gateFlag }} 자가체크</div>
    
    <div class="inside-td__table--wrap">
      <table class="ui-table__reset inside-td__table">
        <colgroup>
          <col style="width:20rem"> 
          <col style="width:auto"> 
          <col style="width:8rem"> 
          <col style="width:57rem"> 
        </colgroup>
        <thead>
          <tr>
            <th>항목</th>
            <th>
              <div class="gate-check-title">
                자가체크 사항
              </div>
              <ap-input-check
                v-model:model="chkAll"
                :value="'Y'"
                :false-value="'N'"
                :id="'pqc_chk_all'"
                :label="'전체 체크'"
                @click="chkAllPqcCont"
              >
              </ap-input-check>
            </th>
            <th>준수여부</th>
            <th>비고</th>
          </tr>
        </thead>
        <tbody v-if="pqcList">
          <template v-for="(vo, idx) in pqcList" :key="'pqcVo_'+idx">
            <tr class="tr_pqc_chk_title">
              <td rowspan="2">
                <span class="item-title">
                  {{ vo.vPqcItemNm }}
                  <i v-if="commonUtils.isNotEmpty(vo.vPqcChkDesc)" class="ui-icon ui-icon__question" :title="vo.vPqcChkDesc"></i>
                </span>
              </td>
              <td class="text-left"><span class="question-mark">Q.</span> {{ vo.vPqcChkText }}</td>
              <td rowspan="2">
                <span class="span_item_clear_check">{{ vo.vItemClearCheck }}</span>
              </td>
              <td rowspan="2">
                <template v-if="commonUtils.isNotEmpty(vo.vBuffer1) && commonUtils.isNotEmpty(trMap[vo.vBuffer1])">
                  <table class="ui-table__reset inside-td__table">
                    <colgroup>
                      <col style="width:18%">
                      <col style="width:25%">
                      <col style="width:20%">
                      <col style="width:auto">
                    </colgroup>
                    <thead>
                      <tr>
                        <th>의뢰날짜</th>
                        <th>Lot</th>
                        <th>내용물코드</th>
                        <th>시험결과</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-for="(svo, idx) in trMap[vo.vBuffer1]" :key="'trSubMap_'+idx">
                        <td>
                          {{ commonUtils.isNotEmpty(svo.vLabReqDtm) ? commonUtils.changeStrDatePattern(svo.vLabReqDtm) : changeStrDatePattern(svo.vRegDtm) }}
                        </td>
                        <td>
                          <template v-if="svo.vLabMrqTypeCd == 'CLINICAL'">
                            <a :href="tiumUrl + '/ct/ct/clinical_test_discuss_renew_view.do?i_sTempStatusCd=DISCUSS&i_sTestCd=' + svo.vProductCd" target="_blank" class="tit-link txt_blue">
                              Ver {{ svo.nLabNoteVer }}{{ svo.vLabGateCd == 'GATE_2' ? 'Pilot' : '' }}
                            </a>
                          </template>
                          <template v-else-if="svo.vLabMrqTypeCd != 'MRQ010' && svo.vLabGateCd == 'GATE_2'">
                            <a :href="tiumUrl + '/zm/tr/zm_tr_product_view.do?i_sProductCd='+svo.vProductCd + '&&i_iVersion='+svo.nVersion" target="_blank" class="tit-link txt_blue">
                              Ver {{ svo.nLabNoteVer }}, {{ svo.vLotNm }} Pilot
                            </a>
                          </template>
                          <template v-else-if="svo.vLabMrqTypeCd == 'MRQ010'">
                            <a :href="tiumUrl + '/zm/safe/tr/zm_safe_tr_product_view.do?i_sProductCd=' +svo.vProductCd+'&i_iVersion='+svo.nVersion" target="_blank" class="tit-link txt_blue">
                              Ver {{ svo.nLabNoteVer }}, {{ svo.vLotNm }}
                            </a>
                          </template>
                          <template v-else-if="svo.vLabMrqTypeCd == 'MRQ011'">
                            <a :href="tiumUrl + '/zm/bb/tr/zm_bb_tr_product_view.do?i_sProductCd='+svo.vProductCd +'&i_iVersion='+svo.nVersion" target="_blank" class="tit-link txt_blue">
                              Ver {{ svo.nLabNoteVer }}, {{ svo.vLotNm }}
                            </a>
                          </template>
                          <template v-else>
                            <a :href="tiumUrl + '/zm/tr/zm_tr_product_view.do?i_sProductCd='+svo.vProductCd +'&i_iVersion='+svo.nVersion" target="_blank" class="tit-link txt_blue">
                              Ver {{ svo.nLabNoteVer }}, {{ svo.vLotNm }}
                            </a>
                          </template>
                        </td>
                        <td v-html="commonUtils.removeHTMLChangeBr(svo.vTargetContCd)"></td>
                        <td v-html="commonUtils.removeHTMLChangeBr(svo['vTrRes'+vo.vBuffer1+'Txt'])"></td>
                      </tr>
                    </tbody>
                  </table>
                </template>
              </td>
            </tr>
            <tr class="tr_pqc_item_list">
              <td class="text-left">
                  <template v-if="vo.vItemTypeCd.indexOf('TCOST') > -1">
                    {{ vo.vGateBeforeHtml }}
                  </template>
                  <template v-if="vo.vItemTypeCd.indexOf('PILOT') > -1">
                    {{ vo.vGateBeforeHtml }}
                  </template>
                  <template v-if="vo.vItemTypeCd.indexOf('GLB_BAN') > -1">
                    {{ vo.vChoiceVal01 === 'Y' ? '확인' : '미확인' }}
                  </template>
                  <template v-if="vo.vItemTypeCd.indexOf('PAO') > -1">
                    <div class="form-flex mt-15">
                      <div class="form-flex__cell--5 f-size-12">
                        사용기한 : 
                      </div>
                      <div class="ui-form-box__width--150 form-flex__cell--5" :id="'error_wrap_vTextVal01_' + idx">
                        <ap-input
                          v-model:value="vo.vTextVal01"
                          input-class="ui-select__width--full"
                          :name="'text_' + vo.vPqcCd + '_' + idx + '_01'"
                          @change="gateCheck();fnValidate(vo, idx, 'vTextVal01');"
                        >
                        </ap-input>
                        <span class="error-msg" :id="'error_msg_vTextVal01_' + idx"></span>
                      </div>
                      <div class="form-flex__cell--5 f-size-12">
                        PAO :
                      </div>
                      <div class="ui-form-box__width--150 form-flex__cell--5" :id="'error_wrap_vTextVal02_' + idx">
                        <ap-input
                          v-model:value="vo.vTextVal02"
                          input-class="ui-select__width--full"
                          :name="'text_' + vo.vPqcCd + '_' + idx + '_02'"
                          @change="gateCheck();fnValidate(vo, idx, 'vTextVal02');"
                        >
                        </ap-input>
                        <span class="error-msg" :id="'error_msg_vTextVal02_' + idx"></span>
                      </div>
                    </div>
                  </template>
                  <template v-if="vo.vItemTypeCd.indexOf('G2_GQMS') > -1">
                    <div class="form-flex mt-15">
                      <div class="ui-input__width--60 f-size-12">
                        점도 :
                      </div>
                      <div class="ui-form-box__width--370" :id="'error_wrap_vBufferVal01_' + idx">
                        <ap-input
                          v-model:value="vo.vBufferVal01"
                          input-class="ui-select__width--full"
                          :name="'buffer01_'+ vo.vPqcCd  + '_' + idx"
                          placeholder="예시) 0000±0000, Spindle: 64번, 12rpm, 2min"
                          @change="gateCheck();fnValidate(vo, idx, 'vBufferVal01');"
                        >
                        </ap-input>
                        <span class="error-msg" :id="'error_msg_vBufferVal01_' + idx"></span>
                      </div>
                    </div>
                    <div class="form-flex mt-15">
                      <div class="ui-input__width--60 f-size-12">
                        경도 :
                      </div>
                      <div class="ui-form-box__width--150" :id="'error_wrap_vBufferVal02_' + idx">
                        <ap-input
                          v-model:value="vo.vBufferVal02"
                          input-class="ui-select__width--full"
                          :name="'buffer02_'+ vo.vPqcCd  + '_' + idx"
                          @change="gateCheck();fnValidate(vo, idx, 'vBufferVal02');"
                        >
                        </ap-input>
                        <span class="error-msg" :id="'error_msg_vBufferVal02_' + idx"></span>
                      </div>
                      <div class="ui-input__width--60 ml-10 f-size-12">
                        비중 :
                      </div>
                      <div class="ui-form-box__width--150" :id="'error_wrap_vBufferVal03_' + idx">
                        <ap-input
                          v-model:value="vo.vBufferVal03"
                          input-class="ui-select__width--full"
                          :name="'buffer03_'+ vo.vPqcCd  + '_' + idx"
                          @change="gateCheck();fnValidate(vo, idx, 'vBufferVal03');"
                        >
                        </ap-input>
                        <span class="error-msg" :id="'error_msg_vBufferVal03_' + idx"></span>
                      </div>
                    </div>
                    <div class="form-flex mt-15" :id="'error_wrap_vBufferVal05_' + idx">
                      <div class="ui-input__width--60 f-size-12">
                        pH :
                      </div>
                      <div class="ui-form-box__width--150" :id="'error_wrap_vBufferVal04_' + idx">
                        <ap-input
                          v-model:value="vo.vBufferVal04"
                          input-class="ui-select__width--full"
                          :name="'buffer04_'+ vo.vPqcCd  + '_' + idx"
                          @change="gateCheck();fnValidate(vo, idx, 'vBufferVal04');"
                        >
                        </ap-input>
                        <span class="error-msg" :id="'error_msg_vBufferVal04_' + idx"></span>
                      </div>
                      <div class="ui-input__width--60 ml-10 f-size-12">
                        추가규격 :
                      </div>
                      <div class="ui-form-box__width--150">
                        <ap-input
                          v-model:value="vo.vBufferVal05"
                          input-class="ui-select__width--full"
                          :name="'buffer05_'+ vo.vPqcCd  + '_' + idx"
                          @change="gateCheck();fnValidate(vo, idx, 'vBufferVal05');"
                        >
                        </ap-input>
                        <span class="error-msg" :id="'error_msg_vBufferVal05_' + idx"></span>
                      </div>
                    </div>
                    <div class="form-flex mt-15">
                      <div class="ui-input__width--60 f-size-12">
                        변경사유 :
                      </div>
                      <div class="ui-form-box__width--370" :id="'error_wrap_vBufferVal06_' + idx">
                        <ap-input
                          v-model:value="vo.vBufferVal06"
                          input-class="ui-select__width--full"
                          @change="gateCheck();fnValidate(vo, idx, 'vBufferVal06');"
                        >
                        </ap-input>
                        <span class="error-msg" :id="'error_msg_vBufferVal06_' + idx"></span>
                      </div>
                    </div>
                  </template>
                  <template v-if="vo.vItemTypeCd.indexOf('CHOICE') > -1 && vo.vItemTypeCd.indexOf('G1_GQMS') === -1">
                    <template v-if="vo.codeList && vo.codeList.length > 0">
                      <div :id="'error_wrap_vChoiceVal01_' + idx">
                        <div class="form-flex">
                          <template v-for="(cvo, index) in vo.codeList" :key="vo.vPqcCd + '_' + idx + '_' + index">
                            <ap-input-radio
                              v-model:model="vo.vChoiceVal01"
                              :value="cvo.v_val"
                              :label="cvo.v_text"
                              :id="vo.vPqcCd + '_' + idx + '_' + index"
                              :name="'radio_' + vo.vPqcCd + '_' + idx"
                              @click="gateCheck();fnValidate(vo, idx, 'vChoiceVal01');"
                            >
                            </ap-input-radio>
                            <template v-if="cvo.v_flag_chk_text === 'Y'">
                              <template v-if="commonUtils.isNotEmpty(cvo.v_chk_html)">
                                <div v-html="cvo.v_chk_html"></div>
                              </template>
                              <template v-else-if="cvo.v_val === vo.vChoiceVal01">
                                <div class="form-flex__cell--5 mr-10 f-size-12" v-if="commonUtils.isNotEmpty(cvo.v_before_text)">
                                  <span>{{ cvo.v_before_text }}</span>
                                </div>
                                <div class="ui-form-box__width--150 form-flex__cell--5" :id="'error_wrap_vChoiceTextVal01_' + idx">
                                  <ap-input
                                    v-model:value="vo.vChoiceTextVal01"
                                    input-class="ui-select__width--full"
                                    :name="'text_' + vo.vPqcCd + '_' + idx"
                                    @change="gateCheck();fnValidate(vo, idx, 'vChoiceTextVal01');"
                                  >
                                  </ap-input>
                                  <span class="error-msg" :id="'error_msg_vChoiceTextVal01_' + idx"></span>
                                </div>
                                <div class="form-flex__cell--5 mr-10 f-size-12" v-if="commonUtils.isNotEmpty(cvo.v_after_text)">
                                  <span>{{ cvo.v_after_text }}</span>
                                </div>
                              </template>
                            </template>
                          </template>
                        </div>
                        <span class="error-msg" :id="'error_msg_vChoiceVal01_' + idx"></span>
                      </div>
                    </template>
                  </template>
                  <template v-if="vo.vItemTypeCd.indexOf('CHOICE') > -1 && vo.vItemTypeCd.indexOf('G1_GQMS') > -1">
                    <template v-if="vo.codeList && vo.codeList.length > 0">
                      <div :id="'error_wrap_vChoiceVal01_' + idx">
                        <div class="form-flex">
                          <ap-input-radio
                            v-for="(cvo, index) in vo.codeList"
                            v-model:model="vo.vChoiceVal01"
                            :key="vo.vPqcCd + '_' + idx + '_' + index"
                            :value="cvo.v_val"
                            :label="cvo.v_text"
                            :id="vo.vPqcCd + '_' + idx + '_' + index"
                            :name="'radio_' + vo.vPqcCd + '_' + idx"
                            @click="gateCheck();fnValidate(vo, idx, 'vChoiceVal01');"
                          >
                          </ap-input-radio>
                        </div>
                        <span class="error-msg" :id="'error_msg_vChoiceVal01_' + idx"></span>
                      </div>
                    </template>
                    <template v-if="commonUtils.isNotEmpty(vo.vChoiceVal01) && vo.vChoiceVal01 === 'Y'">
                      <div class="form-flex mt-15">
                        <div class="ui-input__width--60 f-size-12">
                          점도 :
                        </div>
                        <div class="ui-form-box__width--370" :id="'error_wrap_vBufferVal01_' + idx">
                          <ap-input
                            v-model:value="vo.vBufferVal01"
                            input-class="ui-select__width--full"
                            :name="'buffer01_'+ vo.vPqcCd  + '_' + idx"
                            placeholder="예시) 0000±0000, Spindle: 64번, 12rpm, 2min"
                            @change="gateCheck();fnValidate(vo, idx, 'vBufferVal01');"
                          >
                          </ap-input>
                          <span class="error-msg" :id="'error_msg_vBufferVal01_' + idx"></span>
                        </div>
                      </div>
                      <div class="form-flex mt-15">
                        <div class="ui-input__width--60 f-size-12">
                          경도 :
                        </div>
                        <div class="ui-form-box__width--150" :id="'error_wrap_vBufferVal02_' + idx">
                          <ap-input
                            v-model:value="vo.vBufferVal02"
                            input-class="ui-select__width--full"
                            :name="'buffer02_'+ vo.vPqcCd  + '_' + idx"
                            @change="gateCheck();fnValidate(vo, idx, 'vBufferVal02');"
                          >
                          </ap-input>
                          <span class="error-msg" :id="'error_msg_vBufferVal02_' + idx"></span>
                        </div>
                        <div class="ui-input__width--60 ml-10 f-size-12">
                          비중 :
                        </div>
                        <div class="ui-form-box__width--150" :id="'error_wrap_vBufferVal03_' + idx">
                          <ap-input
                            v-model:value="vo.vBufferVal03"
                            input-class="ui-select__width--full"
                            :name="'buffer03_'+ vo.vPqcCd  + '_' + idx"
                            @change="gateCheck();fnValidate(vo, idx, 'vBufferVal03');"
                          >
                          </ap-input>
                          <span class="error-msg" :id="'error_msg_vBufferVal03_' + idx"></span>
                        </div>
                      </div>
                      <div class="form-flex mt-15">
                        <div class="ui-input__width--60 f-size-12">
                          pH :
                        </div>
                        <div class="ui-form-box__width--150" :id="'error_wrap_vBufferVal04_' + idx">
                          <ap-input
                            v-model:value="vo.vBufferVal04"
                            input-class="ui-select__width--full"
                            :name="'buffer04_'+ vo.vPqcCd  + '_' + idx"
                            @change="gateCheck();fnValidate(vo, idx, 'vBufferVal04');"
                          >
                          </ap-input>
                          <span class="error-msg" :id="'error_msg_vBufferVal04_' + idx"></span>
                        </div>
                        <div class="ui-input__width--60 ml-10 f-size-12">
                          추가규격 :
                        </div>
                        <div class="ui-form-box__width--150" :id="'error_wrap_vBufferVal05_' + idx">
                          <ap-input
                            v-model:value="vo.vBufferVal05"
                            input-class="ui-select__width--full"
                            :name="'buffer05_'+ vo.vPqcCd  + '_' + idx"
                            @change="gateCheck();fnValidate(vo, idx, 'vBufferVal05');"
                          >
                          </ap-input>
                          <span class="error-msg" :id="'error_msg_vBufferVal05_' + idx"></span>
                        </div>
                      </div>
                    </template>  
                  </template>
                  <template v-if="vo.vItemTypeCd.indexOf('TEXT') > -1">
                    <div class="form-flex mt-15">
                      <div class="form-flex__cell--5 mr-10 f-size-12" v-if="commonUtils.isNotEmpty(vo.vBeforeText)">
                        <span>{{ vo.vBeforeText }}</span>
                      </div>
                      <div class="ui-form-box__width--150 form-flex__cell--5" :id="'error_wrap_vTextVal01_' + idx">
                        <ap-input
                          v-model:value="vo.vTextVal01"
                          input-class="ui-select__width--full"
                          :name="'text_' + vo.vPqcCd + '_' + idx"
                          @change="gateCheck();fnValidate(vo, idx, 'vTextVal01');"
                        >
                        </ap-input>
                        <span class="error-msg" :id="'error_msg_vTextVal01_' + idx"></span>
                      </div>
                      <div class="form-flex__cell--5 mr-10 f-size-12" v-if="commonUtils.isNotEmpty(vo.vAfterText)">
                        <span>{{ vo.vAfterText }}</span>
                      </div>
                    </div>
                  </template>
              </td>
            </tr>
          </template>

        </tbody>
      </table>
    </div>

    <div class="inside-td__table--wrap">
      <table class="ui-table__contents">
        <colgroup>
          <col style="width:9.5rem">
        </colgroup>
        <tbody>
          <tr>
            <th>준수율</th>
            <td class="text-left">
              <span id="span_obey_per">{{ pqcPercent }} {{ pqcCheckAllLength }}</span>
            </td>
          </tr>
          <tr>
            <th>연구원 의견<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
            <td id="error_wrap_vPqcUserComment">
              <div class="ui-textarea-box ui-textarea-box__height--100">
                <ap-text-area
                  v-model:value="userComment"
                  :is-with-byte="false"
                  :maxlength="1000"
                  id="vPqcUserComment"
                  @input="fnValidate(null, 0, 'vPqcUserComment')"
                >
                </ap-text-area>
              </div>
              <span class="error-msg" id="error_msg_vPqcUserComment"></span>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, inject, ref, watch, getCurrentInstance } from 'vue'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'ProcessPQCGateCheckList',
  components: {
  },
  emits: ['update:pqcList', 'update:pqcUserComment'],
  props: {
    pqcList: {
      type: Object,
      default: () => {
        return {}
      }
    },
    gateFlag : {
      type: Object,
      default: () => {
        return {}
      }
    },
    trMap : {
      type: Object, 
      default: () => {
        return {}
      }
    },
    pqcUserComment: {
      type: Object, 
      default: () => {
        return {}
      }
    },
    noteInfo: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  setup (props, context) {
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])
    const commonUtils = inject('commonUtils')
    const app = getCurrentInstance()
    const tiumUrl = app.appContext.config.globalProperties.tiumUrl
    const userComment = ref(null)
    const pqcCheckAllLength = ref(null)
    const pqcPercent = ref(0)
    const chkAll = ref('N')

    const gateCheck = () => {
      const len = props.pqcList.length
      let total_cnt = 0
      let clear_cnt = 0

      if(len > 0) {
        for(let i = 0; i < len; i++){
          const res = itemCheck(props.pqcList[i], i)
          if(res == "CLEAR"){
            total_cnt++
            clear_cnt++
          }
          else if(res == "FAIL" || res == "EMPTY"){
            total_cnt++
          }
        }

        if(total_cnt > 0) {
          const per = Math.round(clear_cnt / total_cnt * 100 * 100) / 100
          pqcPercent.value = per
          pqcCheckAllLength.value = '% (' + clear_cnt + '/' + total_cnt + ')'
        }else{
          pqcPercent.value = 0
          pqcCheckAllLength.value = '% (0/' + total_cnt + ')'
        }
      }
    }

    const itemCheck = (item, idx) => {
      const rtn = ref("EMPTY")
      const pqcCd = item.vPqcCd
      const pqc_item_cd = item.vPqcItemCd
      const item_type_cd = "|" + item.vItemTypeCd + "|"
      const item_clear_value = item.vItemClearValue

      if(item_type_cd.indexOf("|PILOT|") > -1){
        item.vItemClearCheck = '-'
        item.vChoiceVal01Required = false
        return "PASS"
      }
      else if(item_type_cd.indexOf("|TCOST|") > -1
        || item_type_cd.indexOf("|GLB_BAN|") > -1
        ){
          item.vChoiceVal01Required = false
        if(item.vChoiceVal01){
          if(item.vChoiceVal01 == 'Y'){
            item.vItemClearCheck = 'Y'
            return "CLEAR"
          }else{
            item.vItemClearCheck = 'N'
            return "FAIL"
          }
        }

      }
      else if(item_type_cd.indexOf("|PAO|") > -1){
        item.vChoiceVal01Required = false
        const val01 = item.vTextVal01
        const val02 = item.vTextVal02
        item.vTextVal01Required = true
        if(commonUtils.isNotEmpty(val01) && val01.trim() != '' && commonUtils.isNotEmpty(val02) && val02.trim()){
          item.vItemClearCheck = 'Y'
          return "CLEAR"
        }else{
          item.vItemClearCheck = 'N'
          return "FAIL"
        }
      }
      else{
        if (item_type_cd.indexOf('|TEXT|') > -1) {
          item.vTextVal01Required = true
        } else {
          item.vChoiceVal01Required = true
        }
        const choice_val = item.vChoiceVal01 || ''
        if(choice_val == ''){
          item.vItemClearCheck = '-'
          rtn.value = "EMPTY"
        }
        else if(choice_val == 'PASS'){
          item.vItemClearCheck = 'pass'
          rtn.value = "PASS"
        }
        else if(choice_val === item_clear_value){
          const codeInfo = item.codeList.filter(v => v.v_val === choice_val)[0]
          item.vItemClearCheck = 'Y'
          const codeVo = item.codeList.filter(vo => vo['v_val'] === item_clear_value)
          if(codeVo[0].v_flag_chk_text != undefined && codeVo[0].v_flag_chk_text == 'Y' && item.vItemTypeCd.indexOf('GQMS') === -1){
            item.vChoiceTextVal01Required = true
          }
          rtn.value = "CLEAR"
        }
        else{
          item.vItemClearCheck = 'N'
          rtn.value = "FAIL"
        }

        if (item_type_cd.indexOf("|G1_GQMS|") > -1) {
          if (rtn.value === 'CLEAR') {
            if (commonUtils.isNotEmpty(item.vBufferVal01) || commonUtils.isNotEmpty(item.vBufferVal02) || commonUtils.isNotEmpty(item.vBufferVal03)) {
              item.vBufferVal01Required = false
              item.vBufferVal02Required = false
              item.vBufferVal03Required = false
            } else {
              item.vBufferVal01Required = true
              item.vBufferVal02Required = true
              item.vBufferVal03Required = true
            }
            item.vBufferVal04Required = true
          } else {
            item.vBufferVal01Required = false
            item.vBufferVal02Required = false
            item.vBufferVal03Required = false
            item.vBufferVal04Required = false
          }
        } else if (item_type_cd.indexOf("|G2_GQMS|") > -1) {
          if (rtn.value === 'CLEAR') {
            if (commonUtils.isNotEmpty(item.vBufferVal01) || commonUtils.isNotEmpty(item.vBufferVal02) || commonUtils.isNotEmpty(item.vBufferVal03)) {
              item.vBufferVal01Required = false
              item.vBufferVal02Required = false
              item.vBufferVal03Required = false
            } else {
              item.vBufferVal01Required = true
              item.vBufferVal02Required = true
              item.vBufferVal03Required = true
            }

            item.vBufferVal04Required = true
          } else {
            item.vBufferVal01Required = false
            item.vBufferVal02Required = false
            item.vBufferVal03Required = false
            item.vBufferVal04Required = false
          }

          if (rtn.value === 'CLEAR' && (
            item.vG1BufferVal01 !== item.vBufferVal01 ||
            item.vG1BufferVal02 !== item.vBufferVal02 ||
            item.vG1BufferVal03 !== item.vBufferVal03 ||
            item.vG1BufferVal04 !== item.vBufferVal04 ||
            item.vG1BufferVal05 !== item.vBufferVal05)) {
            item.vBufferVal06Required = true
          } else {
            item.vBufferVal06Required = false
          }
        }

        //기존에 있던 text required class 추가/제거는 저장할 때 체크로 변경하기

      }

      return rtn.value
    }


    const fnValidateAll = () => {
      let isOk = true
      const arrChkKey = ['vTextVal01', 'vTextVal02', 
                  'vChoiceVal01', 'vChoiceTextVal01',
                  'vBufferVal01', 'vBufferVal02', 'vBufferVal03', 'vBufferVal04', 'vBufferVal05', 'vBufferVal06',
      ]

      arrChkKey.forEach((key, idx) => {
        props.pqcList.forEach((item, index) => {
          if (!fnValidate(item, index, key)) {
            isOk = false
          }
        })
      })

      if (!fnValidate(null, 0, 'vPqcUserComment')) {
        isOk = false
      }

      return isOk
    }

    const fnValidate = (item, index, key) => {
      let isOk = true
      let errorMsg = '필수 입력 사항입니다.'

      if (key !== 'vPqcUserComment') {
        commonUtils.hideErrorMessage(key + '_' + index)
  
        if (item[key + 'Required'] &&
            commonUtils.isEmpty(item[key])) {
          isOk = false
        }
  
        if (!isOk) {
          commonUtils.showErrorMessage(key + '_' + index, errorMsg)
        }
      } else {
        commonUtils.hideErrorMessage('vPqcUserComment')
        if (commonUtils.isEmpty(userComment.value)) {
          isOk = false
          commonUtils.showErrorMessage('vPqcUserComment')
        }
      }

      return isOk
    }

    /* watch(() => props.pqcList, (newVal, oldVal) => {
      if(newVal != oldVal){
        context.emit('update:pqcList', newVal)
      }
    }) */

    watch(() => userComment.value, (newVal, oldVal) => {
      if(newVal != oldVal){
        context.emit('update:pqcUserComment', newVal)
      }
    })

    gateCheck()

    //자가체크 사항 : 전체 체크
    const chkAllPqcCont = (value) => {
      const pqcList = props.pqcList

      if(value === 'Y'){
        pqcList.forEach(item => {
          if(item.vChoiceVal01Required || item.vItemTypeCd.indexOf('G1_GQMS') > -1){
            item.vChoiceVal01 = item.codeList[0].v_val
            item.vItemClearCheck = 'Y'
          }
          gateCheck()
        })
      }else{
        pqcList.forEach(item => {
          if(item.vChoiceVal01Required || item.vItemTypeCd.indexOf('G1_GQMS') > -1){
            item.vChoiceVal01 = ''
            item.vItemClearCheck = '-'
          }
          gateCheck()
        })
      }

      fnValidateAll()
    }

    return {
      tiumUrl,
      closeAsyncPopup,
      commonUtils,
      gateCheck,
      itemCheck,
      userComment,
      pqcCheckAllLength,
      pqcPercent,
      fnValidateAll,
      fnValidate,
      chkAll,
      chkAllPqcCont
    }
  }
}
</script>