<template>
  <div class="h-100">
    <div class="contents-box__inner process-area">
      <div class="search-bar__row">
        <dl class="search-bar__item">
          <dt class="search-bar__key search-bar__key--width-auto">효력시작일</dt>
          <dd class="search-bar__val">
            <ap-date-picker-range
              v-model:startDt="searchParams.vEffectStDT"
              v-model:endDt="searchParams.vEffectEdDT"
              :read-only="false"
              :resetable="true"
            />
          </dd>
        </dl>
        <dl class="search-bar__item">
          <dt class="search-bar__key search-bar__key--width-auto">검색조건</dt>
          <dd class="search-bar__val">
            <div class="search-form">
              <div class="search-form__inner">
                <ap-input
                  v-model:value="searchParams.vKeyword"
                  class="ui-input__width--258"
                  placeholder="내용물코드 or 내용물명 or 연구담당자"
                  @keypressEnter="fnSearchIngrdApprovalList(1)"
                />
                <button
                  type="button"
                  class="button-search"
                  @click="fnSearchIngrdApprovalList(1)"
                >검색</button>
                <button
                  type="button"
                  class="ui-button ui-button__bg--lightgray font-weight__500 ml-5"
                  @click="resetSearchFilter"
                >검색 초기화</button>
              </div>
            </div>
          </dd>
        </dl>
        <div class="ml-auto">
          <div class="ui-buttons">
            <button
              class="ui-button ui-button__bg--skyblue"
              @click="fnOpenPopup('DefaultIngredientDataPop')"
            >등록</button>
          </div>
        </div>
      </div>
  
      <div class="mt-15">
        <div class="ui-table__wrap">
          <table class="ui-table text-center ui-table__td--40">
            <colgroup>
              <col style="width:8rem;">
              <col style="width:12%;">
              <col style="width:8%;">
              <col style="width:auto;">
              <col style="width:15%;">
              <col style="width:6%;">
              <col style="width:12%;">
              <col style="width:10%;">
            </colgroup>
            <thead>
              <tr>
                <th>NO</th>
                <th>VER - LOT</th>
                <th>내용물코드</th>
                <th>내용물명</th>
                <th>플랜트</th>
                <th>회차</th>
                <th>연구담당자<br/>/담당부서</th>
                <th>효력 시작일</th>
              </tr>
            </thead>
            <tbody>
              <template v-if="list && list.length > 0">
                <tr v-for="(vo, idx) in list" :key="'tr_' + idx">
                  <td>{{ page.totalCnt - ((page.pageSize * (page.nowPageNo-1)) + idx)}}</td>
                  <td>{{ commonUtils.isNotEmpty(vo.nVersion) ? `Ver${vo.nVersion}` : '' }}{{ commonUtils.isNotEmpty(vo.vLotNm) ? ` - ${vo.vLotNm}` : '' }}</td>
                  <td>{{ vo.vContCd }}</td>
                  <td class="tit">
                    <div class="tit__inner">
                      <a
                        href="#"
                        class="tit-link"
                        @click.prevent="fnGoViewPage(vo)"
                      >{{ vo.vContNm }}</a>
                    </div>
                  </td>
                  <td>{{ commonUtils.isNotEmpty(vo.vPlantCd) ? `[${vo.vPlantCd}] ${vo.vPlantNm}` : '' }}</td>
                  <td>{{ commonUtils.isNotEmpty(vo.vZversion) ? `${vo.vZversion} 회차` : '' }}</td>
                  <td>{{ vo.vUsernm }}<br/>/ {{ vo.vDeptNm }}</td>
                  <td>{{ commonUtils.changeStrDatePattern(vo.vDatuv) }}</td>
                </tr>
              </template>
              <template v-else>
                <tr>
                  <td colspan="8">
                    <div class="no-result">
                      {{ t('common.msg.no_data') }}
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>
      <div class="board-bottom">
        <div class="board-bottom__inner">
          <Pagination
            :page-info="page"
            @click="fnSearchIngrdApprovalList"
          />
        </div>
      </div>
    </div>
    <teleport to="#common-modal" v-if="popupContent">
      <ap-popup>
        <component
          :is="popupContent"
          :pop-params="popParams"
          @selectFunc="popSelectFunc"
        />
      </ap-popup>
    </teleport>
  </div>
</template>

<script>
import { defineAsyncComponent, inject } from 'vue'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'

export default {
  name: 'ProcessIngredientApproveList',
  components: {
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    DefaultIngredientDataPop: defineAsyncComponent(() => import('@/components/labcommon/popup/DefaultIngredientDataPop.vue'))
  },
  setup (props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')

    const {
      page,
      list,
      selectIngrdApprovalList,
      searchParams,
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup
    } = useProcessCommon()

    const fnGoRegPage = (obj) => {
      context.emit('changePage', { ...obj.value, ...{ actionFlag: 'REG' } })
    }

    const fnGoViewPage = (obj) => {
      context.emit('changePage', { ...obj, ...{ actionFlag: 'VIEW' } })
    }

    const fnSearchIngrdApprovalList = (pg) => {
      if(!pg){
        pg = 1
      }

      searchParams.value.nowPageNo = pg

      selectIngrdApprovalList(searchParams.value)
    }
  
    const resetSearchFilter = () => {
      searchParams.value.vEffectStDT = ''
      searchParams.value.vEffectEdDT = ''
      searchParams.value.vKeyword = ''

      fnSearchIngrdApprovalList(1)
    }

    const init = () => {
      popParams.value = { vLabNoteCd: searchParams.value.vLabNoteCd }
      popSelectFunc.value = fnGoRegPage
      fnSearchIngrdApprovalList(1)
    }

    init()

    return {
      t,
      commonUtils,
      searchParams,
      page,
      list,
      popupContent,
      popParams,
      popSelectFunc,
      fnSearchIngrdApprovalList,
      fnOpenPopup,
      fnGoViewPage,
      resetSearchFilter,
    }
  }
}
</script>