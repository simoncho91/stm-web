<template>
<div class="ui-table__wrap">
    <table class="ui-table text-center ui-table__td--40">
      <tbody>
        <tr class="tr-contents">
          <td class="inside-td inside-td__p30">
            <div class="inside-td__item">
              <div class="inside-td__item--title">BOM 정보</div>
              <div class="inside-td__table--wrap">
                <ul class="ui-list code-contcd__list" v-if="gate01ApprParams.lotList && gate01ApprParams.lotList.length > 0">
                  <li class="code-contcd__item"
                    v-for="(vo, index) in gate01ApprParams.lotList"
                    :key="'contcd_' + index"
                  >
                    <button
                      type="button"
                      class="code-contcd__button code-contcd__button--code"
                      :class="selectLotCd === vo.vLotCd ? 'is-click' : ''"
                      @click="fnLotBomList(vo)"
                    >
                      {{ vo.vContCd }}
                    </button>
                  </li>
                </ul>
                <table
                    class="ui-table__reset inside-td__table inside-td__table--borderR-none mt-20"
                    v-if="info.bomList && info.bomList.length > 0"
                  >
                  <colgroup>
                    <col style="width:15%"> 
                    <col style="width:20%"> 
                    <col style="width:auto"> 
                    <col style="width:10%"> 
                  </colgroup>
                  <thead>
                    <tr>
                      <th>NO</th>
                      <th>원료코드</th>
                      <th>원료명</th>
                      <th>
                        <span class="txt_gray f-weight-700 f-size-12">{{ info.bomList[0].vLotNm }}</span><br>
                        함량
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(vo, idx) in info.bomList" :key="'bom_' + idx">
                      <td>{{ idx + 1 }}</td>
                      <td>
                        <template v-if="commonUtils.isEmpty(vo.vMateCd) && vo.vMateDbTypeCd === 'SUP'">
                          {{ vo.vMateTempCd }}
                        </template>
                        <template v-else>
                          {{ vo.vMateCd }}
                        </template>
                      </td>
                      <td class="t-left">
                        <MateName
                          :mate-info="vo"
                        >
                        </MateName>
                      </td>
                      <td class="t-right">{{ vo.nRate }}</td>
                    </tr>
                    <tr class="inside-td__table--total">
                      <td class="inside-td__total--text">합계</td>
                      <td></td>
                      <td></td>
                      <td class="inside-td__total--num t-right">{{ info.bomList[0].nRateSum }}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <ProcessPQCGateCheckList
              v-if="regParams?.pqcCheckList && regParams?.pqcCheckList.length > 0"
              v-model:pqc-list="regParams.pqcCheckList"
              v-model:pqc-user-comment="regParams.vPqcUserComment"
              :tr-map="info.trMap"
              gate-flag="GATE1"
              ref="pqc"
            >
            </ProcessPQCGateCheckList>

            <div class="inside-td__item" v-if="regParams.shelfLifeList && regParams.shelfLifeList.length > 0">
              <div class="inside-td__item--title">SHELF LIFE</div>
              <div class="inside-td__item--wrap">
                <table class="ui-table__reset inside-td__table">
                  <colgroup>
                    <col style="width:21rem"> 
                    <col style="width:auto"> 
                  </colgroup>
                  <tbody>
                    <tr>
                      <th>사용기한</th>
                      <td class="t-left">
                        <template
                          v-for="(vo, idx) in regParams.shelfLifeList"
                          :key="'shelf_life_' + idx"
                        >
                          <div class="form-flex">
                            <div class="ui-input__width--60 form-flex__cell--5">
                              {{ vo.vContCd }}
                            </div>
                            <div class="ui-input__width--200 form-flex__cell--5">
                              <template v-if="vo.vFlagLife === 'Y'">
                                {{ vo.vShelfLife }} M
                              </template>
                              <template v-else>
                                <div :id="'error_wrap_vShelfLife_' + idx">
                                  <ap-selectbox
                                    v-model:value="vo.vShelfLife"
                                    :options="codeGroupMaps['SHELF_LIFE_CODE']"
                                    input-class="ui-select__width--full"
                                    @change="fnValidate('vShelfLife')"
                                  >
                                  </ap-selectbox>
                                  <span class="error-msg" :id="'error_msg_vShelfLife_' + idx"></span>
                                </div>
                              </template>
                            </div>
                            <div class="ui-input__width--200 form-flex__cell--5" v-if="vo.vShelfLife === 'ETC'">
                              <ap-input
                                v-model:value="vo.vEtcLife"
                              >
                              </ap-input>
                            </div>
                          </div>
                        </template>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div class="inside-td__item">
              <ApprovalRegister
                appr-cd=""
                :appr-class="'LAB001_' + noteType"
                ref="appr"
                :default-list="apprList"
                @callbackFunc="fnApprSave"
              >
              </ApprovalRegister>
            </div>
            
            <div class="inside-td__item">
              <ReferenceRegister
                ref="refComp"
                record-id=""
                :default-list="referenceList"
              >
              </ReferenceRegister>
            </div>
          </td>
        </tr>
      </tbody>
    </table>

  </div>
  
  <div class="page-bottom">
    <div class="page-bottom__inner">
      <div class="ui-buttons ui-buttons__right">
        <!-- <button type="button" v-if="noteType == 'MU'" class="ui-button ui-button__bg--skyblue" @click.prevent="fnBomRequest()">BOM 승인</button> -->
        <button type="button" class="ui-button ui-button__bg--skyblue" @click.prevent="fnAppr()">승인 요청</button>
        <button type="button" class="ui-button ui-button__bg--gray" @click="goList()">목록</button>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'
import { useHalfProcessCommon } from '@/compositions/labcommon/useHalfProcessCommon'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useCode } from '@/compositions/useCode'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'ProcessHalfPilotGate01Reg',
  props: {
    gate01ApprParams: {
      type: Object,
      default: () => {
        return {}
      }
    },
    noteInfo: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  components: {
    MateName: defineAsyncComponent(() => import('@/components/labcommon/MateName.vue')),
    ProcessPQCGateCheckList: defineAsyncComponent(() => import('@/components/process/ProcessPQCGateCheckList.vue')),
    ApprovalRegister: defineAsyncComponent(() => import('@/components/comm/ApprovalRegister.vue')),
    ReferenceRegister: defineAsyncComponent(() => import('@/components/comm/ReferenceRegister.vue')),
  },
  emits: ['goList'],
  setup (props, context) {
    const commonUtils = inject('commonUtils')
    const pqc = ref(null)
    const { openAsyncConfirm, openAsyncAlert } = useActions(['openAsyncConfirm', 'openAsyncAlert'])
    const selectLotCd = ref('')
    const info = ref({})
    const flagShelfLife = ref('')
    const regParams = ref({
      vPqcUserComment: '',
    })
    const appr = ref(null)
    const refComp = ref(null)

    const {
      codeGroupMaps,
      findCodeList,
    } = useCode()

    const {
      selectLabNotePilotRegInfo,
      saveLabNoteGate01ApprovalRequest,
      noteType,
      saveLabNoteHal4BomProcess
    } = useHalfProcessCommon()

    const {
      selectLabNoteMateRateInfo,
    } = useLabCommon()

    const fnLotBomList = async (item) => {
      if (selectLotCd.value !== item.vLotCd) {
        const payload = {
          vLabNoteCd: props.gate01ApprParams.vLabNoteCd,
          nVersion: props.gate01ApprParams.nVersion,
          vContPkCd: item.vContPkCd,
          vLotCd: item.vLotCd,
          vNoteType: noteType
        }

        const result = await selectLabNoteMateRateInfo(payload)

        if (result) {
          info.value.bomList = [ ...result ]
        }
      }

      selectLotCd.value = item.vLotCd
    }

    const fnValidateAll = () => {
      let isOk = true
      const arrChkKey = ['vShelfLife', 'vPqcUserComment']

      arrChkKey.forEach(key => {
        if (!fnValidate(key)) {
          isOk = false
        }
      })

      return isOk
    }

    const fnValidate = (key) => {
      let isOk = true

      if (key === 'vShelfLife') {
        if (flagShelfLife.value !== 'Y' && regParams.value.shelfLifeList && regParams.value.shelfLifeList.length > 0) {
          regParams.value.shelfLifeList.forEach((item, idx) => {
            commonUtils.hideErrorMessage('vShelfLife_' + idx)
            if (commonUtils.isEmpty(item.vShelfLife)) {
              isOk = false
              commonUtils.showErrorMessage('vShelfLife_' + idx)
            }
          })
        }
      } else if (key === 'vPqcUserComment') {
        commonUtils.hideErrorMessage('vPqcUserComment')
        if (commonUtils.isEmpty(regParams.value.vPqcUserComment)) {
          isOk = false
          commonUtils.showErrorMessage('vPqcUserComment')
        }
      }

      return isOk
    }

    
    const fnAppr = async () => {
      const bomLen = info.value.bomList && info.value.bomList.length > 0 ? info.value.bomList.length : 0

      if (bomLen === 0) {
        openAsyncAlert({ message : '<span class=\'txt_red f-weight-700\'>[주의] Zplm34e 구성성분 없는</span> 원료가 존재하여<br>BOM <span class=\'txt_red f-weight-700\'>전송</span>이 불가합니다.'})
        return
      }

      let isOk = true
      if (!pqc.value.fnValidateAll()) {
        isOk = false
      }

      if (!fnValidateAll()) {
        isOk = false
      }

      if (!isOk) {
        openAsyncAlert({ message: '필수 입력 사항을 확인해 주세요.'})
        return
      }

      if (appr.value) {
        appr.value.fnApprovalOpinionPop()
      }
    }

    const fnApprSave = async (draftOpinion) => {
      if (!await openAsyncConfirm({ message: '결재 의뢰 하시겠습니까?' })) {
        return
      }

      const payload = {
        ...regParams.value,
        vApprTypeCd: 'LAB001_' + noteType,
        referenceList: refComp.value.referenceList,
        apprReqInfo: {
          apprInfo: appr.value.apprInfo,
          apprList: appr.value.apprList
        }
      }

      payload.apprReqInfo.apprInfo.vDraftOpinion = draftOpinion

      const result = await saveLabNoteGate01ApprovalRequest(payload)

      if (result && result === 'SUCC') {
        await openAsyncAlert({ message: '결재 요청되었습니다.' })
        goList()
      }
    }

    const goList = () => {
      context.emit('goList')
    }

    const fnBomRequest = async () => {
      if (!await openAsyncConfirm({ message: 'BOM 승인 요청하시겠습니까?' })) {
        return
      }

      const payload = {
        ...regParams.value,
        vApprTypeCd: 'LAB001_' + noteType,
        referenceList: refComp.value.referenceList,
      }

      const result = await saveLabNoteHal4BomProcess(payload)

      if (result && result === 'SUCC') {
        await openAsyncAlert({ message: '승인 요청되었습니다.' })
        goList()
      }
    }

    const init = async () => {
      findCodeList(['SHELF_LIFE_CODE'])
      const lotList = props.gate01ApprParams.lotList
      if (lotList && lotList.length > 0) {
        const lotInfo = lotList[0]
        selectLotCd.value = lotInfo.vSelectLotCd

        const arrLotCd = lotList.map(item => commonUtils.isNotEmpty(item.vLotCd) ? item.vLotCd : '').filter( v => v !== '')
        const arrContCd = lotList.map(item => commonUtils.isNotEmpty(item.vContCd) ? item.vContCd : '').filter( v => v !== '')
        const arrPlantCd = lotList.map(item => commonUtils.isNotEmpty(item.vPlantCd) ? item.vPlantCd : '').filter( v => v !== '')
        const arrContPkCd = lotList.map(item => commonUtils.isNotEmpty(item.vContPkCd) ? item.vContPkCd : '').filter( v => v !== '')

        const payload = {
          vLabNoteCd: props.gate01ApprParams.vLabNoteCd,
          nVersion: props.gate01ApprParams.nVersion,
          arrLotCd,
          arrContCd,
          arrPlantCd,
          arrContPkCd,
          vLotCd: lotInfo.vLotCd,
          vContPkCd: lotInfo.vContPkCd,
          vNoteType: noteType
        }

        regParams.value = { ...regParams.value, ...payload }
        const result = await selectLabNotePilotRegInfo(payload)
        if (result) {
          info.value = { ...result }
          regParams.value = { ...regParams.value, ...{
            pqcCheckList: [...result.pqcList],
            shelfLifeList: [...result.shelfLifeList],
            vLotNm: lotInfo.vLotNm + (lotList.length > 1 ? (' 외 ' + (lotList.length - 1) + '건') : ''),
            vContCd: lotInfo.vContCd,
            vContNm: lotInfo.vContNm,
          } }

          if (regParams.value.shelfLifeList && regParams.value.shelfLifeList.length > 0) {
            flagShelfLife.value = regParams.value.shelfLifeList.filter(v => commonUtils.isEmpty(v.vShelfLife)).length > 0 ? 'N' : 'Y'
          }
        }
      }
    }

    init()

    return {
      info,
      pqc,
      flagShelfLife,
      commonUtils,
      selectLotCd,
      regParams,
      noteType,
      codeGroupMaps,
      fnLotBomList,
      goList,
      fnValidate,
      appr, 
      refComp,
      fnAppr,
      fnApprSave,
      fnBomRequest
    }
  }
}
</script>