<template>
  <ProcessFuncTestReportList
    v-if="vActionFlag === undefined || vActionFlag === 'L'"
    v-model:action-flag="vActionFlag"
    v-model:flag-save-action="vFlagSaveAction"
    v-model:detail-info="detailInfo"
  >
  </ProcessFuncTestReportList>

  <ProcessFuncTestReportReg
    v-if="vActionFlag === 'R'"
    v-model:action-flag="vActionFlag"
    v-model:flag-save-action="vFlagSaveAction"
    v-model:detail-info="detailInfo"
  >
  </ProcessFuncTestReportReg>

  <ProcessFuncTestReportView
    v-if="vActionFlag === 'V' && detailInfo"
    v-model:action-flag="vActionFlag"
    v-model:flag-save-action="vFlagSaveAction"
    v-model:detail-info="detailInfo"
  >
  </ProcessFuncTestReportView>
</template>

<script>
import { defineAsyncComponent, reactive, ref } from 'vue'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'ProcessFuncTestReport',
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
    ProcessFuncTestReportList : defineAsyncComponent(() => import("@/components/process/ProcessFuncTestReportList.vue")),
    ProcessFuncTestReportReg : defineAsyncComponent(() => import("@/components/process/ProcessFuncTestReportReg.vue")),
    ProcessFuncTestReportView : defineAsyncComponent(() => import("@/components/process/ProcessFuncTestReportView.vue")),
  },
  setup (props, context) {

    const selectedTab = ref('testReport')
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])
    const vActionFlag = ref('L')
    const vFlagSaveAction = ref('R')
    const detailInfo = ref(null)

    const tabList = [
      { tabId: 'prodName', tabNm: '확정 제품명' },
      { tabId: 'testReport', tabNm: '시험 성적서' },
    ]

    const getSelectedTabEvent = (item) => {
      selectedTab.value = item.tabId
    }

    return {
      tabList,
      selectedTab,
      getSelectedTabEvent,
      closeAsyncPopup, 
      vActionFlag,
      vFlagSaveAction,
      detailInfo
    }
  }
}
</script>