<template>
  <div class="ui-table__wrap mt-20">
    <table class="ui-table text-center ui-table__td--40 ui-table__thead-multi">
      <colgroup>
        <col style="width:6rem;">
        <col style="width:8%;">
        <col style="width:auto;">
        <col style="width:9%;">
        <col style="width:9%;">
        <col style="width:9%;">
        <col style="width:9%;">
        <col style="width:8%;">
      </colgroup>
      <tbody>
        <tr class="tr-contents">
          <td class="inside-td inside-td__p30" colspan="8">
            <div class="inside-td__item">
              <div class="inside-td__item--title">양산승인요청 내용물</div>
              <div class="inside-td__table--wrap">
                <table class="ui-table__reset inside-td__table">
                  <colgroup>
                    <col style="width:15%"> 
                    <col style="width:auto"> 
                  </colgroup>
                  <thead>
                    <tr>
                      <th>내용물코드</th>
                      <th>내용물명</th>
                    </tr>
                  </thead>
                  <tbody v-if="resultVo?.contList">
                    <tr v-for="(contVo, idx) in resultVo.contList" :key="'contVo_' + idx" class="tr_cont_list">
                      <td :data-contPkCd="contVo.vContPkCd" :data-lotCd="contVo.vLotCd">
                        {{ contVo.vContCd }}
                      </td>
                      <td class="tit">
                        <div class="tit__inner">
                          {{ contVo.vContNm }}
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <ProcessPQCGateCheckList
              v-if="resultVo?.pqcList && resultVo?.pqcList.length > 0"
              v-model:pqc-list="resultVo.pqcList"
              :tr-map="resultVo.trMap"
              :gate-flag="'GATE2'"
              v-model:pqc-user-comment="pqcUserComment"
              ref="pqc"
            >
            </ProcessPQCGateCheckList>
            
            <ProcessTrGate01List
              v-if="resultVo?.trGate1List && resultVo?.trGate1List.length > 0"
              :tr-gate1-list="resultVo.trGate1List"
            >
            </ProcessTrGate01List>

            <div class="inside-td__item" v-if="noteType == 'SC' || noteType == 'MU'">
              <ApprovalRegister
                :appr-cd="gate0ApprCd"
                :appr-class="'LAB002_'+ noteType"
                :default-list="resultVo?.userList"
                ref="appr"
                @callbackFunc="fnApprSave"
              >
              </ApprovalRegister>
            </div>

          </td>
        </tr>
      </tbody>
    </table>
  </div>

  <div class="page-bottom">
    <div class="page-bottom__inner">
      <div class="ui-buttons ui-buttons__right">
        <button type="button" v-if="noteType == 'HBO' || noteType == 'SA'" class="ui-button ui-button__bg--skyblue" @click.prevent="fnMassApprPass">양산 승인</button>
        <button type="button" v-else class="ui-button ui-button__bg--skyblue" @click.prevent="fnAppr">결재 올리기</button>
        <button type="button" class="ui-button ui-button__bg--gray" @click="goList">목록</button>
      </div>
    </div>
  </div>

</template>

<script>
import { defineAsyncComponent, inject, ref, watch } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useStore } from 'vuex'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'

export default {
  name: 'ProcessDevelopCompleteGate02Reg',
  components: {
    ProcessPQCGateCheckList: defineAsyncComponent(() => import('@/components/process/ProcessPQCGateCheckList.vue')),
    ProcessTrGate01List: defineAsyncComponent(() => import('@/components/process/ProcessTrGate01List.vue')),
    ApprovalRegister: defineAsyncComponent(() => import('@/components/comm/ApprovalRegister.vue')),
  },
  emits: ['callbackFunc', 'update:flagOpenGate02'],
  props: {
    gate02CheckParam: {
      type: Object,
      default: () => {
        return {}
      }
    },
    gate0ApprCd : {
      type: Object,
      default : () => {
        return {}
      }
    },
    flagOpenGate02 : {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  setup (props, context) {
    const appr = ref(null)
    const pqc = ref(null)
    const store = useStore()
    const resultVo = ref(null)
    const noteType = store.getters.getNoteType()
    const { openAsyncAlert, openAsyncConfirm, closeAsyncPopup } = useActions(['openAsyncAlert','openAsyncConfirm','closeAsyncPopup'])
    const commonUtils = inject('commonUtils')
    const {
      selectLabNoteGate2Reg,
      saveLabNoteMassAppr,
      updateLabNoteMassPass
    } = useProcessCommon()

    const pqcUserComment = ref(null)
    const init = async () => {
      resultVo.value = await selectLabNoteGate2Reg(props.gate02CheckParam)
    }

    init()

    //결재요청
    const fnAppr = async () => {
      if(!pqc.value.fnValidateAll()){
        await openAsyncAlert({ message: '필수 입력사항을 확인해 주세요.' })
        return 
      }

      if (appr.value) {
        appr.value.fnApprovalOpinionPop()
      }
    }

    //결재요청 > 팝업에서 확인 후 return 메소드
    const fnApprSave = async (draftOpinion) => {
      if (!await openAsyncConfirm({ message: '결재 의뢰 하시겠습니까?' })) {
        return
      }

      if (appr.value) {
        const payload = {
          vNoteType: noteType,
          vLabNoteCd: props.gate02CheckParam.vLabNoteCd,
          nVersion: props.gate02CheckParam.nVersion,
          vApprTypeCd: 'LAB002_' + noteType,
          arrContPkCd: props.gate02CheckParam.arrContPkCd,
          arrLotCd: props.gate02CheckParam.arrLotCd,
          arrLotNm: props.gate02CheckParam.arrLotNm,
          apprReqInfo: {
            apprInfo: appr.value.apprInfo,
            apprList: appr.value.apprList
          },
          vPqcUserComment: pqcUserComment.value,
          pqcCheckList: resultVo.value.pqcList,
        }

        payload.apprReqInfo.apprInfo.vDraftOpinion = draftOpinion

        const result = await saveLabNoteMassAppr(payload) //SAVE_MASS_APPR

        if (result && result === 'SUCC') {
          await openAsyncAlert({ message: '결재 요청되었습니다.' })
          goList()
        }
      }
    }
    
    //HBO, SA 일 때
    const fnMassApprPass = async () => {
      const payload = {
        vNoteType: noteType,
        vLabNoteCd: props.gate02CheckParam.vLabNoteCd,
        nVersion: props.gate02CheckParam.nVersion,
        vApprTypeCd: 'LAB002_' + noteType,
        arrContPkCd: props.gate02CheckParam.arrContPkCd,
        arrLotCd: props.gate02CheckParam.arrLotCd,
        vPqcUserComment: pqcUserComment.value,
        pqcCheckList: resultVo.value.pqcList,
      }

      const result = await updateLabNoteMassPass(payload) //SAVE_MASS_APPR_PASS

      if (result && result === 'SUCC') {
        await openAsyncAlert({ message: '양산승인 되었습니다.' })
        goList()
      }
    }
    
    const goList = () => {
      context.emit('update:flagOpenGate02', 'L')
    }
    

    return {
      closeAsyncPopup,
      resultVo,
      commonUtils,
      fnAppr,
      fnApprSave,
      noteType,
      fnMassApprPass,
      appr,
      pqcUserComment,
      goList,
      pqc
    }
  }
}
</script>