<template>
  <ProcessQdrugReportPermissionList
    v-if="vActionFlag == '' || vActionFlag === 'L'"
    v-model:vActionFlag="vActionFlag"
    v-model:detail-info="detailInfo"
  >
  </ProcessQdrugReportPermissionList>

  <ProcessQdrugReportPermissionReg
    v-if="vActionFlag === 'R' || vActionFlag === 'M'"
    v-model:vActionFlag="vActionFlag"
    v-model:detail-info="detailInfo"
  >
  </ProcessQdrugReportPermissionReg>

  <ProcessQdrugReportPermissionView
    v-if="vActionFlag === 'V'"
    v-model:vActionFlag="vActionFlag"
    v-model:detail-info="detailInfo"
  >
  </ProcessQdrugReportPermissionView>
</template>

<script>
import { defineAsyncComponent, inject, ref } from 'vue'

export default {
  name: 'ProcessQdrugReportPermission',
  components: {
    ProcessQdrugReportPermissionList: defineAsyncComponent(() => import('@/components/process/ProcessQdrugReportPermissionList.vue')),
    ProcessQdrugReportPermissionReg: defineAsyncComponent(() => import('@/components/process/ProcessQdrugReportPermissionReg.vue')),
    ProcessQdrugReportPermissionView: defineAsyncComponent(() => import('@/components/process/ProcessQdrugReportPermissionView.vue')),
  },
  setup (props, context) {
    const vActionFlag = ref('L')
    const detailInfo = ref({})
    return {
      vActionFlag,
      detailInfo
    }

  }
}
</script>