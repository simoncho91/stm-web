<template>
  <div class="contents-box__inner process-area">
    <table class="ui-table__th--bg-gray">
      <colgroup>
        <col style="width:14rem">
        <col style="width:auto">
        <col style="width:14rem">
        <col style="width:auto">
      </colgroup>
      <tbody v-if="resultVo && resultVo != null">
        <tr>
          <th>제품/원료명</th>
          <td colspan="3">
            {{resultVo.rvo.vContNm}} 
            <template v-if="resultVo.rvo.nContNum > 0">
              외 {{ resultVo.rvo.nContNum }}건
            </template>
          </td>
        </tr>
        <tr>
          <th>내용물 코드</th>
          <td>
            {{ resultVo.rvo.vContCd }} 
            <template v-if="resultVo.rvo.nContNum > 0">
              외 {{ resultVo.rvo.nContNum }}건
            </template>
          </td>
          <th>연구담당자</th>
          <td>{{ resultVo.rvo.vUsernm }} ({{ resultVo.rvo.vUserid }} / {{ resultVo.rvo.vUsrDeptnm }})</td>
        </tr>
        <tr>
          <th>브랜드</th>
          <td>{{ resultVo.rvo.vBrdNm }}</td>
          <th>플랜트</th>
          <td>{{ resultVo.rvo.vPlantNm }}</td>
        </tr>
      </tbody>
    </table>

    <div class="divide-line"></div>

    <div class="ui-table__wrap">
      <table class="ui-table text-center ui-table__td--40 ui-table__thead-multi">
        <colgroup>
          <col style="width:15%;">
          <col style="width:auto;">
          <col style="width:9%;">
          <col style="width:9%;">
          <col style="width:9%;">
          <col style="width:9%;">
          <col style="width:9%;">
        </colgroup>
        <thead>
          <tr>
            <th rowspan="2">내용물코드</th>
            <th rowspan="2">내용물명</th>
            <th rowspan="2">버전</th>
            <th colspan="2">GATE1</th>
            <th colspan="2">GATE2</th>
          </tr>
          <tr>
            <th>LOT</th>
            <th>준수율</th>
            <th>LOT</th>
            <th>준수율</th>
          </tr>
        </thead>
        <tbody v-if="resultVo && resultVo != null">
          <template v-if="resultVo.contList && resultVo.contList.length > 0">
            <tr v-for="(contVo, idx) in resultVo.contList" :key="'contVo_'+ idx" class="tr_cont_list">
              <td>{{ contVo.vContCd }}</td>
              <td class="tit">
                <div class="tit__inner">
                  {{ contVo.vContNm }}
                </div>
              </td>
              <td>Ver #{{ contVo.nVersion < 10 ? '0' + contVo.nVersion : contVo.nVersion }}</td>
              <td>{{ contVo.vG1PqcLotNm }}</td>
              <td>
                <template v-if="commonUtils.isNotEmpty(contVo.nG1ObeyPer)">
                {{ contVo.nG1ObeyPer }}%
                </template>
              </td>
              <td>
                <template v-if="commonUtils.isNotEmpty(contVo.vG2PqcResCd)">
                {{ contVo.vG2PqcLotNm }}
                </template>
                <template v-else>
                  {{ contVo.vLotNm }}
                </template>
              </td>
              <td>
                <template v-if="commonUtils.isNotEmpty(contVo.nG2ObeyPer)">
                {{ contVo.nG2ObeyPer }}%
                </template>
              </td>
            </tr>
          </template>
          <template v-else>
            <tr>
              <td colspan="7">:: 개발 완료된 내용물이 없습니다. ::</td>
            </tr>
          </template>
        </tbody>
      </table>
    </div>

    <ProcessDevelopCompleteGate02Reg
      v-if="flagOpenGate02 == 'R' && gate02CheckParam"
      v-model:flag-open-gate02="flagOpenGate02"
      :gate02-check-param="gate02CheckParam"
      :gate0-appr-cd="resultVo?.rvo.vGate0ApprCd"
    >
    </ProcessDevelopCompleteGate02Reg>

    <ProcessDevelopCompleteGate02View
      v-if="flagOpenGate02 == 'V' && gate02CheckParam"
      v-model:flag-open-gate02="flagOpenGate02"
      :gate02-check-param="gate02CheckParam"
    >
    </ProcessDevelopCompleteGate02View>
  </div>

</template>

<script>
import { defineAsyncComponent, reactive, ref, inject } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useRoute, useRouter } from 'vue-router'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'

export default {
  name: 'ProcessDevelopComplete',
  components: {
    ProcessDevelopCompleteGate02Reg: defineAsyncComponent(() => import('@/components/process/ProcessDevelopCompleteGate02Reg.vue')),
    ProcessDevelopCompleteGate02View: defineAsyncComponent(() => import('@/components/process/ProcessDevelopCompleteGate02View.vue')),
  },
  setup (props, context) {
    const route = useRoute()
    const router = useRouter()
    const vLabNoteCd = route.query.vLabNoteCd || ''
    const vFlagEndAppr = route.query.vFlagEndAppr || ''
    const vApprCd = route.query.vApprCd || ''
    const nVersion = route.query.nVersion || ''

    const { openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncAlert','closeAsyncPopup'])
    const resultVo = ref(null)
    const gate02CheckParam = ref(null)
    const commonUtils = inject('commonUtils')

    const {
      selectLabNoteContDecideList,
      noteType,
    } = useProcessCommon()

    const tabList = ref([])
    const selectedTab = ref(null)
    const selectVersion = ref(null)
    const defaultTab = ref(null)
    const flagOpenGate02 = ref('N')

    const getSelectedTabEvent = async (item) => {
      router.replace({ query: {vLabNoteCd: route.query.vLabNoteCd }}) //파라미터 복구
      selectedTab.value = item.tabId
      selectVersion.value = item.tabId.split("_")[1]
      
      const payload = {
        vNoteType : noteType,
        vLabNoteCd : vLabNoteCd,
        nVersion : selectVersion.value,
        vFlagEndAppr : vFlagEndAppr,
        vApprCd : vApprCd
      }
      const result = await selectLabNoteContDecideList(payload)
      resultVo.value = { ...result}

      flagOpenGate02.value = 'N'
    }

    const init = async () => {

      const payload = {
        vNoteType : noteType,
        vLabNoteCd : vLabNoteCd,
        vFlagEndAppr : vFlagEndAppr,
        vApprCd : vApprCd
      }

      //vFlagEndAppr, vApprCd 는 결재승인 메일에서 파라미터가 넘어올 때만 값이 있음
      const result = await selectLabNoteContDecideList(payload)
      resultVo.value = { ...result}

      //TO-BE : 양산승인 단계 결재가 삭제되어 로직 삭제
      // makeTabList(resultVo.value)
      // if(vApprCd){
      //   openCompleteGate02View(vApprCd)
      // }
      
    }

    const makeTabList = (resultVo) => {
      const verList = resultVo.verList
      const rvo = resultVo.rvo

      if(verList.length > 0){
        verList.some(item => {
          const obj = {
            tabId : '',
            tabNm : ''
          }

          if(!vFlagEndAppr){  //기본 로딩
            if(rvo.nMaxVersion === item.nVersion){
              defaultTab.value = item.vVersionKey
              selectVersion.value = rvo.nMaxVersion
            }
          }else{  //파라미터 있는 경우
            if(nVersion == item.nVersion){
              defaultTab.value = item.vVersionKey
              selectVersion.value = nVersion
            }
          }

          obj.tabId = item.vVersionKey
          obj.tabNm = item.vVersionTxt
          tabList.value.push(obj)
        })
      }
    }

    init() 

    const openCompleteGate02 = () => {
      const chkLen = document.querySelectorAll(".chkContPkCd:checked").length
      if(chkLen == 0){
        openAsyncAlert({ message: '대상을 선택해 주세요.' })
        return 
      }

      const chkContPkCd = document.querySelectorAll(".chkContPkCd:checked")
     
      const arrContPkCd = ref([])
      const arrLotCd = ref([])
      const arrLotNm = ref([])
      chkContPkCd.forEach((item) => {
        arrContPkCd.value.push(item.value)
        arrLotCd.value.push(item.dataset.lotcd)
        arrLotNm.value.push(item.dataset.lotnm)
      })

      gate02CheckParam.value = {
        vNoteType : noteType,
        vLabNoteCd : vLabNoteCd,
        nVersion : selectVersion.value,
        vFlagEndAppr : vFlagEndAppr,
        vApprCd : vApprCd,
        arrContPkCd : arrContPkCd,
        arrLotCd : arrLotCd,
        arrLotNm : arrLotNm,
      }

      flagOpenGate02.value = 'R'
    }

    const openCompleteGate02View = (vG2ApprCd) => {

      gate02CheckParam.value = {
        vNoteType : noteType,
        vApprCd : vG2ApprCd
      }

      flagOpenGate02.value = 'V'
    }

    const chkContPkCdAll = () =>{
      const arrChkContPkCd = document.querySelectorAll(".chkContPkCd")
      if(!document.querySelector("#vContPkAll").checked){ //해제
        arrChkContPkCd.forEach((item) => {
          if(!item.disabled){
            item.checked = false
          }
        })
      }else{
        arrChkContPkCd.forEach((item) => {  //check
          if(!item.disabled){
            item.checked = true
          }
        })
      }
    }

    return {
      tabList,
      commonUtils,
      getSelectedTabEvent,
      closeAsyncPopup,
      resultVo,
      makeTabList,
      defaultTab,
      openCompleteGate02,
      flagOpenGate02,
      gate02CheckParam,
      openCompleteGate02View,
      chkContPkCdAll,
      noteType
    }
  }
}
</script>