<template>
  <div class="modal-content modal-content__width--640">
    <div class="modal-header">
      <div class="modal-title">내용물 코드 조회</div>
      <button type="button" class="modal-close" @click="closeAsyncPopup({message: ''})"></button>
    </div>
    <div class="modal-body">
      <div class="basic-info__table">
        <table class="ui-table ui-table__td--40 text-center">
          <colgroup>
            <col style="width:6%">
            <col style="width:14%">
            <col style="width:auto">
            <col style="width:auto">
          </colgroup>
          <thead>
            <tr>
              <th>No.</th>
              <th>내용물코드</th>
              <th>내용물명</th>
              <th>내용물명(영문)</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(vo, idx) in contList" :key="'contVo_'+ idx" class="tr_prod_info" @click="goCallBackFunc(vo)">
              <td>{{ idx + 1 }}</td>
              <td>{{ vo.vContCd }}</td>
              <td>{{ vo.vContNm }}</td>
              <td>{{ vo.vContNmEn }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <div class="board-bottom">
      <div class="board-bottom__inner">
        <div class="ui-buttons ui-buttons__right">
          <button type="button" class="ui-button ui-button__bg--lightgray" @click="closeAsyncPopup({message: ''})">닫기</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, reactive, inject } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'

export default {
  name: 'ProcessFuncTestReportProdListPop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue'))
  },
  emits: ['callbackFunc'],
  setup (props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncAlert', 'closeAsyncPopup'])
    const popContent = ref(null)
    const popSelectFunc = ref(null)
    const closeFunc = ref(null)
    const contList = ref(null)

    const {
      selectEvReportProdListPop
    } = useProcessCommon()

    const init = async () => {
      const vLabNoteCd = props.popParams.vLabNoteCd
      if (commonUtils.isNotEmpty(vLabNoteCd)) {
        contList.value = await selectEvReportProdListPop(props.popParams)
      }
    }

    init()

    const goCallBackFunc = (vo) => {
      
      context.emit('callbackFunc', vo)
    }

    return {
      t,
      popContent,
      popSelectFunc,
      closeFunc,
      closeAsyncPopup,
      contList,
      goCallBackFunc
    }
  }
}
</script>

<style scoped>
  .tr_prod_info{ cursor: pointer; }
</style>