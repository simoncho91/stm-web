<template>
  <div class="modal-content modal-content__width--640">
    <div class="modal-header">
      <div class="modal-title">시험 성적서 요청</div>
      <button
        type="button"
        class="modal-close"
        @click="fnClosePopup"
      ></button>
    </div>
    <div class="modal-body">
      <div class="search-depart-table">
        <div class="search-depart-table__inner">
          <table class="ui-table__td--40">
            <colgroup>
              <col style="width:13rem">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <template v-if="userList && userList.length > 0">
                <tr v-for="(vo, idx) in userList" :key="'user_list_'+idx">
                  <th>
                    <button v-if="idx == 0" class="tr-group__button tr-group__button--plus" @click="addUserList()"></button>
                    <button v-else class="tr-group__button tr-group__button--minus" @click="removeUserList(idx)"></button>
                    QA 담당자
                  </th>
                  <td>
                    <ap-input
                      :maxlength="200"
                      id="twoLiqTxt"
                      class="ui-input__width--150"
                      v-model:value="vo.vUsernm"
                      @keypressEnter="fnUserSearchPop(idx)"
                    >
                    </ap-input>
                    <button type="button" class="ui-button ui-button__circle ui-button__close input-close-btn--292" @click="clearInputUserNm(vo)"></button>
                    <button type="button" class="ui-button ui-button__width-auto button-search" style="margin-left:-15px;" @click="fnUserSearchPop(idx)">검색</button>
                  </td>
                </tr>
              </template>
              <tr>
                <th>
                  <button class="tr-group__button tr-group__button--minus"></button>
                  제품연구원
                </th>
                <td>
                  <ap-input
                      :maxlength="200"
                      class="ui-input__width--150"
                      v-model:value="chargeUserNm"
                      @keypressEnter="fnChargeUserSearchPop()"
                    >
                    </ap-input>
                    <button type="button" class="ui-button ui-button__circle ui-button__close input-close-btn--292" @click="clearInputUserNm(null, 'chargeUser')"></button>
                    <button type="button" class="ui-button ui-button__width-auto button-search" style="margin-left:-15px;" @click="fnChargeUserSearchPop()">검색</button>
                </td>
              </tr>
              <tr>
                <th>요청내용</th>
                <td>
                  <ap-text-area
                    :is-with-byte="true"
                    :maxlength="2000"
                    id="vReqContent"
                    v-model:value="vReqContent"
                  ></ap-text-area>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="board-bottom">
        <div class="board-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <span class="mr-auto txt_blue">메일 발송 확인을 위해 제품 연구원에게도 동일 메일이 보내집니다.</span>
            <button
              type="button"
              class="ui-button ui-button__bg--skyblue font-weight__300"
              @click="fnSendMail"
            >메일 전송</button>
            <button
              type="button"
              class="ui-button ui-button__bg--lightgray"
              @click="closeAsyncPopup({ message: '' })"
            >닫기</button>
          </div>
        </div>
      </div>
    </div>
  </div>
  <teleport to="#common-modal-sub" v-if="popContent">
    <ap-popup>
      <component
        :is="popContent"
        :pop-params="popupParams"
        @selectFunc="popSelectFunc"
        @closeFunc="closeFunc"
      />
    </ap-popup>
  </teleport>
  <div id="common-modal-sub"></div>
</template>

<script>
import { inject, ref, reactive, defineAsyncComponent } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'

export default {
  name: 'ProcessFuncTestReportReqPop',
  components:{
    UploadFileRegister: defineAsyncComponent(() => import('@/components/comm/UploadFileRegister.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    UserSearchPop: defineAsyncComponent(() => import('@/components/comm/popup/UserSearchPop.vue')),
  },
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  emits: ['callbackFunc'],
  setup (props, context) {
    const { openAsyncPopup, closeAsyncPopup } = useActions(['openAsyncPopup','closeAsyncPopup'])
    const rvo = ref(null)
    const userList = ref([])
    const uploadid = ref('')
    const popContent = ref(null)
    const popupParams = ref(null)
    const popSelectFunc = ref(null)
    const closeFunc = ref(null)
    const chargeUserNm = ref(null)
    const chargeUserId = ref(null)
    const vReqContent = ref('')
    let popIdx = null
    const uploadParams = reactive({
      vRecordid: '',
      items: []
    })

    const{
      selectGroupUserList,
      fnOpenPopup,
      fnClosePopup,
    } = useProcessCommon()

    const init = async () => {
      const result = await selectGroupUserList(props.popParams)
      rvo.value = {...rvo.value, ...result}
      
      chargeUserNm.value = rvo.value.vChargeUserNm
      chargeUserId.value = rvo.value.vChargeUserId
      
      userList.value = rvo.value.userList
      if(userList.value.length <= 0){
        addUserList()
      }
    }

    init()

    const fnSendMail = async () => {
      
      const qaUserIdList = ref([])
      userList.value.forEach(item => {
        qaUserIdList.value.push(item.vUserid)
      })

      qaUserIdList.value.push(chargeUserId.value)

      const payload = {
        vReqContent : vReqContent.value,
        arrQaUserId : qaUserIdList
      }

      context.emit('callbackFunc', payload)
    }

    const clearInputUserNm = (vo, flag) => {
      if(flag == 'chargeUser'){
        chargeUserNm.value = ''
        chargeUserId.value = ''
      }else{
        vo.vUsernm = ''
        vo.vUserid = ''
      }
    }

    const removeUserList = (idx) => {
      userList.value.splice(idx, 1)
    }

    const addUserList = () => {
      const obj = {
        nNum : 0,
        vUserid : '',
        vUsernm : '',
        vDeptcd : '',
        vEmail : ''
      }

      userList.value.push({...obj})
    }

    const fnUserSearchPop = (index) => {
      if(index == undefined || index == ''){
        index = 0
      }

      popIdx = index
      popupParams.value = {
        vKeyword: userList.value[popIdx].vUsernm,
        popType: 'SUB',
        searchFlag: 'ALL'
      }

      popSelectFunc.value = getUserSearchInfo
      closeFunc.value = closeUserSearchPop
      popContent.value = 'UserSearchPop'
      openAsyncPopup()
    }

    const getUserSearchInfo = (item) => {
      userList.value[popIdx].vUsernm = item.vUsernm
      userList.value[popIdx].vUserid = item.vUserid

      popIdx = null
      closeUserSearchPop()
    }

    const fnChargeUserSearchPop = () => {

      popupParams.value = {
        vKeyword: chargeUserNm.value,
        popType: 'SUB',
        searchFlag: 'ALL'
      }

      popSelectFunc.value = getChargeUserSearchInfo
      closeFunc.value = closeUserSearchPop
      popContent.value  = 'UserSearchPop'
      openAsyncPopup()
    }

    const getChargeUserSearchInfo = (item) => {
      chargeUserNm.value = item.vUsernm
      chargeUserId.value = item.vUserid

      closeUserSearchPop()
    }

    const closeUserSearchPop = () => {
      popContent.value = null
    }

    return {
      closeAsyncPopup,
      rvo,
      userList,
      uploadid,
      uploadParams,
      fnSendMail,
      fnOpenPopup,
      fnClosePopup, 
      clearInputUserNm,
      removeUserList,
      addUserList, 
      fnUserSearchPop,
      popContent,
      popupParams,
      popSelectFunc,
      closeFunc,
      closeUserSearchPop,
      chargeUserNm,
      chargeUserId,
      vReqContent,
      fnChargeUserSearchPop,
      getChargeUserSearchInfo
    }
  }
}
</script>