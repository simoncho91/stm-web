<template>
  <div class="modal-content modal-content__width--640">
    <div class="modal-header">
      <div class="modal-title">기능성 검사 서류 전송</div>
      <button
        type="button"
        class="modal-close"
        @click="fnClosePopup"
      ></button>
    </div>
    <div class="modal-body">
      <div class="search-depart-table">
        <div class="search-depart-table__inner">
          <table class="ui-table__td--40">
            <colgroup>
              <col style="width:13rem">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr>
                <th>제목</th>
                <td>
                  {{ rvo?.vTitle }}
                </td>
              </tr>
              <tr>
                <th>요청 내용</th>
                <td>{{ rvo?.vReqContent }}</td>
              </tr>
              <tr>
                <th>첨부파일</th>
                <td>
                  <UploadFileRegister
                    :uploadid="uploadid"
                    :parent-info="uploadParams"
                  >
                  </UploadFileRegister>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="board-bottom">
        <div class="board-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button
              type="button"
              class="ui-button ui-button__bg--skyblue font-weight__300"
              @click.prevent="fnUploadSendMail"
            >메일 전송</button>
            <button
              type="button"
              class="ui-button ui-button__bg--lightgray"
              @click="closeAsyncPopup({ message: '' })"
            >닫기</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { inject, ref, reactive, defineAsyncComponent } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'

export default {
  name: 'ProcessFuncTestReportUploadPop',
  components:{
    UploadFileRegister: defineAsyncComponent(() => import('@/components/comm/UploadFileRegister.vue')),
  },
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  emits: ['callbackFunc'],
  setup (props, context) {
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])
    const rvo = ref(null)
    const uploadid = ref('')
    const uploadParams = reactive({
      vRecordid: '',
      items: []
    })

    const{
      selectLabNoteFuncRequestQA,
      fnUploadSave,
      fnClosePopup
    } = useProcessCommon()

    const init = async () => {
      rvo.value = await selectLabNoteFuncRequestQA(props.popParams)

        if(props.popParams.vRefTypeCd == 'LNC05_02' || props.popParams.vRefTypeCd == 'LNC05_05'){
          uploadid.value = 'EPR010'
        }else if(props.popParams.vRefTypeCd == 'LNC05_03'){
          uploadid.value = 'EVDOC06'
        }else{
          uploadid.value = 'EPR001'
        }

        uploadParams.vRecordid = rvo?.value.vRecordid == undefined ? '' : rvo?.value.vRecordid
    }

    init()

    const fnUploadSendMail = async () => {
      
      const payload = {
        vNoteType : props.popParams.vNoteType, 
        vNoteTypeNm : props.popParams.vNoteTypeNm,
        vLabNoteCd : props.popParams.vLabNoteCd,
        nVersion : props.popParams.nVersion, 
        nSeqno : props.popParams.nSeqno,
        vRecordid: uploadParams.vRecordid == undefined ? '' : uploadParams.vRecordid,
        vUploadCd: uploadid.value,
        fileList: uploadParams.items,
        vRefTypeCd : props.popParams.vRefTypeCd,
        vFlagSelf : props.popParams.vFlagSelf,
        vTitle : rvo?.value.vTitle
      }
      
      await fnUploadSave(payload)
      fnClosePopup()
    }

    return {
      closeAsyncPopup,
      rvo,
      uploadid,
      uploadParams,
      fnUploadSendMail,
      fnClosePopup
    }
  }
}
</script>