<template>
  <div class="contents-core">
    <div class="contents-cell__wrap">
      <div class="contents-cell flex-none">
        <div class="contents-box contents-box__full">
          <div class="contents-box__inner min-height__unset">
            <div class="arrordion-item is-active">
              <div class="arrordion-header">
                <div class="arrordion-title">의약외품 전성분 정보</div>
              </div>
              <div class="arrordion-body">
                <div class="">
                  <div class="ui-table__wrap">
                    <table class="ui-table text-center ui-table__td--40">
                      <colgroup>
                        <col style="width:10%;">
                        <col style="width:auto">
                        <col style="width:30%;">
                        <col style="width:20%;">
                        <col style="width:10%;">
                      </colgroup>
                      <thead>
                        <th>원료코드</th>
                        <th>원료명</th>
                        <th>한글허가명</th>
                        <th>배합목적</th>
                        <th>함량</th>
                      </thead>
                      <tbody>
                        <template v-if="resData.ingrSubList?.length > 0">
                          <tr v-for="(vo, idx) in resData.ingrSubList" :key="`tr_${idx}`">
                            <td>{{ vo.vMatCd }}</td>
                            <td>{{ vo.vMatNm }}</td>
                            <td>
                              <template v-if="vo.vMatNum === '4'">
                                향료
                              </template>
                              <template v-else-if="vo.vMatNum === '6'">
                                {{ vo.vIngrTxt }}
                              </template>
                            </td>
                            <td>{{ vo.vCmbCodeNm }}</td>
                            <td>{{ vo.nMatPer.toFixed(10) }}</td>
                          </tr>
                          <tr>
                            <td colspan="4">합계</td>
                            <td>{{ resData.ingrSubList.map(vo => vo.nMatPer).reduce((acc, item) => acc + item).toFixed(10) }}</td>
                          </tr>
                        </template>
                        <template v-else>
                          <tr>
                            <td colspan="5">
                              <div class="no-result">
                                {{ t('common.msg.no_data') }}
                              </div>
                            </td>
                          </tr>
                        </template>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            <div class="mt-30"></div>
            <div class="arrordion-item is-active">
              <div class="arrordion-body">
                <div class="basic-info__table">
                  <table class="ui-table__reset ui-table__ver ui-table__td--40 text-center">
                    <colgroup>
                      <col style="width:17rem">
                      <col style="width:20rem">
                      <col style="width:17rem">
                      <col style="width:auto">
                    </colgroup>
                    <tbody>
                      <tr>
                        <th>내용물코드</th>
                        <td>{{ resData?.ingrMstVo?.vContCd }}</td>
                        <th>내용물명</th>
                        <td>{{ resData?.ingrMstVo?.vContNm }}</td>
                      </tr>
                      <tr>
                        <th>허가번호</th>
                        <td>{{ resData?.ingrMstVo?.vEvaluateno }}</td>
                        <th>허가 제품명</th>
                        <td>{{ resData?.ingrMstVo?.vEvaluateNm }}</td>
                      </tr>
                      <tr>
                        <th>전성분</th>
                        <td colspan="3">{{ resData?.ingrMstVo?.vZtext }}</td>
                      </tr>
                      <tr>
                        <th>효능효과</th>
                        <td colspan="3">{{ resData?.ingrMstVo?.vEffect }}</td>
                      </tr>
                      <tr>
                        <th>용법용량</th>
                        <td colspan="3">{{ resData?.ingrMstVo?.vUsage }}</td>
                      </tr>
                      <tr>
                        <th>사용상의 주의사항</th>
                        <td colspan="3">{{ resData?.ingrMstVo?.vUseWarning }}</td>
                      </tr>
                      <tr>
                        <th>사용기한</th>
                        <td colspan="3">{{ resData?.ingrMstVo?.vTimeLimit }}</td>
                      </tr>
                      <tr>
                        <th>저장방법</th>
                        <td colspan="3">{{ resData?.ingrMstVo?.vStorage }}</td>
                      </tr>
                      <tr>
                        <th>전성분 변경 사유</th>
                        <td colspan="3">{{ resData?.ingrMstVo?.vReason }}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="page-bottom">
        <div class="page-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button
              type="button"
              class="ui-button ui-button__bg--skyblue"
              @click="fnGoListPage()"
            >목록</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, inject, ref } from 'vue'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'

export default {
  name: 'ProcessIngredientApproveViewSA',
  props: {
    viewParams: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: '',
          vContPkCd: '',
          vWerks: '',
          vZversion: '',
          vFlagSAIngr: 'Y',
        }
      }
    }
  },
  setup (props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')

    const resData = ref({})

    const {
      selectIngrdApprovalInfo
    } = useProcessCommon()

    const fnGoListPage = () => {
      context.emit('changePage', { actionFlag: 'LIST' })
    }

    const init = async () => {
      if (props.viewParams) {
        resData.value = await selectIngrdApprovalInfo(props.viewParams)

        resData.value.vUsage = commonUtils.removeHTMLChangeBr(resData.value.vUsage)
        resData.value.vUseWarning = commonUtils.removeHTMLChangeBr(resData.value.vUseWarning)

        if (!resData.value) {
          fnGoListPage()
        }
      }
    }

    init()

    return {
      t,
      commonUtils,
      resData,
      fnGoListPage,
    }
  }
}
</script>

<style scoped>
.version-tab__top {
  margin-bottom: 1rem;
}
.contents-box__with--tab .contents-box__inner {
  border-top-left-radius: 0;
  height: calc(100% - 0.1rem);
}
</style>