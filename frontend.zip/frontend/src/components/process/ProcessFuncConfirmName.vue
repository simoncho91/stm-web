<template>
  <ProcessFuncConfirmNameList
    v-if="vActionFlag === undefined || vActionFlag === 'L'"
    v-model:action-flag="vActionFlag"
    v-model:flag-save-action="vFlagSaveAction"
    v-model:decide-info="decideInfo"
  >
  </ProcessFuncConfirmNameList>

  <ProcessFuncConfirmNameReg
    v-if="vActionFlag === 'R'"
    v-model:action-flag="vActionFlag"
    v-model:flag-save-action="vFlagSaveAction"
    v-model:decide-info="decideInfo"
  >
  </ProcessFuncConfirmNameReg>
</template>

<script>
import { defineAsyncComponent, reactive, ref } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'
import { useRoute, useRouter } from 'vue-router'

export default {
  name: 'ProcessFuncConfirmName',
  components: {
    ApTab: defineAsyncComponent(() => import("@/components/comm/ApTab.vue")),
    Pagination: defineAsyncComponent(() => import("@/components/comm/Pagination.vue")),
    ProcessFuncConfirmNameList : defineAsyncComponent(() => import("@/components/process/ProcessFuncConfirmNameList.vue")),
    ProcessFuncConfirmNameReg : defineAsyncComponent(() => import("@/components/process/ProcessFuncConfirmNameReg.vue")),
},
  setup (props, context) {

    const route = useRoute()
    const router = useRouter()
    const selectedTab = ref('prodName')

    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])
    const vActionFlag = ref('L')
    const vFlagSaveAction = ref('R')
    const decideInfo = ref(null)

    const tabList = [
      { tabId: 'prodName', tabNm: '확정 제품명' },
      { tabId: 'testReport', tabNm: '시험 성적서' },
    ]

    const getSelectedTabEvent = (item) => {
      router.replace({ query: {vLabNoteCd: route.query.vLabNoteCd }})
      setTimeout(() => {
        selectedTab.value = item.tabId
      }, 200)
    }

    return {
      tabList,
      selectedTab,
      getSelectedTabEvent,
      closeAsyncPopup, 
      vActionFlag,
      vFlagSaveAction,
      decideInfo,
    }
  }
}
</script>