<template>
  <div class="search-bar__row">
    <dl class="search-bar__item">
      <dt class="search-bar__key search-bar__key--width-170">내용물 정보</dt>
      <dd class="search-bar__val search-bar__val--flexible">
        <div class="ui-table__wrap">
          <table class="ui-table text-center ui-table__td--40">
            <colgroup>
              <col v-if="nameList.length > 1" style="width:7rem;">
              <col style="width:13rem;">
              <col style="width:auto;">
              <col style="width:auto;">
              <col v-if="nameList.length > 1 && resVo.vFlagNameModAuth === 'Y'" style="width:7.5rem;">
            </colgroup>
            <thead>
              <tr>
                <th v-if="nameList.length > 1">대표홋수</th>
                <th>내용물 코드</th>
                <th>내용물명</th>
                <th>기능성 확정제품명</th>
                <th v-if="nameList.length > 1 && resVo.vFlagNameModAuth === 'Y'"></th>
              </tr>
            </thead>
            <tbody>
              <template v-if="nameList && nameList.length > 0">
                <tr v-for="(vo, idx) in nameList" :key="'decideName_' + idx" :class="vo.vFlagDel == 'Y' ? 'del-func-confirm' : ''">
                  <td v-if="nameList.length > 1">
                    <template v-if="vo.vFlagRepresent === 'Y'">√</template>
                  </td>
                  <td>{{ vo.vContCd}}</td>
                  <td>{{ vo.vContNm }}</td>
                  <td v-if="resVo.vFlagNameModAuth === 'Y'">
                    <ap-input
                      class="ui-input decide_cont_nm"
                      placeholder="제품명을 입력해주세요"
                      v-model:value="vo.vDecideContNm"
                      :disabled="vo.vFlagDel === 'Y' ? true : false"
                    >
                    </ap-input>
                    <span class="error-msg" id="error_msg_vDecideContNm"></span>
                  </td>
                  <td v-else>{{ vo.vDecideContNm }}</td>
                  <td v-if="nameList.length > 1 && resVo.vFlagNameModAuth === 'Y'" :class="'td_del_btn'+idx">
                    <button type="button" v-if="vo.vFlagDel == 'Y'" class="ui-button ui-button__bg--skyblue" @click.prevent="contNmDelete('N', idx)">복원</button>
                    <button type="button" v-else class="ui-button ui-button__bg--lightgray" @click.prevent="contNmDelete('Y', idx)">삭제</button>
                  </td>
                </tr>
                
              </template>
            </tbody>
          </table>
        </div>
      </dd>
    </dl>
  </div>

  <div class="search-bar__row">
    <dl class="search-bar__item">
      <dt class="search-bar__key search-bar__key--width-170">
        주의사항<span class="ui-require"><span class="for-a11y">(필수)</span></span>
      </dt>
      <dd class="search-bar__val search-bar__val--flexible">
        <div class="text-caution">
          <p class="text-caution__text">※필수 준수※</p>
          <p class="text-caution__text">1. 
            <span class="color-tomato">
              기능성 확정 제품명 결재 후, 제품명 변경 절대 불가 - 불가피한 사유 발생 시, 기능성 재보고 위한 협의 필수(제품 담당자, 품질&RA lab
                담당자)
            </span>
          </p>
          <p class="text-caution__text">2. 기능성 확정 제품명 입력시 주의사항</p>
          <div class="text-caution__text-item">
            <p class="text-caution__text-text">① <span class="color-darkblue">띄어쓰기 없이 국문으로만 기재, 영문 입력 불가</span></p>
            <p class="text-caution__text-text">② <span class="color-darkblue">특수문자: + 와 . 이외 입력 불가</span></p>
            <p class="text-caution__text-tex text-caution__text-text-text">예시) 에이피 세럼 EX → 에이피세럼이엑스 ｜ 에이피 선크림 SPF50+PA+++ → 에이피선크림에스피에프50+피에이+++</p>
          </div>
          <p class="text-caution__text">3. 기능성 제품 원화에 표시되는 <span class="color-tomato">용량에 대하여 정해진 비율이나 표시 단위(g, ml 등)는 임의 변경 불가</span>하니, 변경하고자 하는 경우 반드시 제품 담당자, 품질&RA 담당자와 사전 확인요청</p>
        </div>
      </dd>
    </dl>
  </div>
  
  <div class="contents-box__inner contents-box__inner--border min-height__unset">
    <template v-if="resVo.vFlagNameModAuth === 'Y'">
      <ApprovalRegister
        v-if="apprList && apprList.length > 0"
        appr-cd=""
        appr-class="LAB_PRDNM_SET"
        :default-list="apprList"
        ref="appr"
        @callbackFunc="fnApprSave"
      >
      </ApprovalRegister>
    </template>
    <template v-else>
      <ApprovalView 
        v-if="resVo.vApprCd"
        :appr-cd="resVo.vApprCd"
        appr-class="LAB_PRDNM_SET"
        ref="apprView"
        v-model:appr-mst-info="apprMstInfo"
        v-model:appr-user-list="apprUserList"
        @callbackFunc="fnApprProc"
      >
      </ApprovalView>
    </template>
    <div class="notice-approval mt-15">
      <span v-if="noteType == 'SC'" class="color-tomato">결재라인) 담당자 기안  → 담당마케터  결재  → BS담당 결재  → PL(랩장) 전결</span>
      <span v-else-if="noteType == 'MU' || noteType == 'HBO'" class="color-tomato">결재라인) 담당자 기안  → 담당마케터  결재 → PL(랩장) 전결</span>
    </div>
  </div>

  <div class="page-bottom">
    <div class="page-bottom__inner">
      <div class="ui-buttons ui-buttons__right">
        <template v-if="resVo.vFlagNameModAuth === 'Y'">
          <button type="button" class="ui-button ui-button__border--blue" @click.prevent="fnSave">임시저장</button>
          <button type="button" class="ui-button ui-button__bg--skyblue font-weight__300" @click.prevent="fnAppr">결재요청</button>
        </template>
        <template v-if="commonUtils.isNotEmpty(resVo.vApprCd)">
          <template v-if="showApprovalBtn('USR010')">
            <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnApprAccept('ACCEPT')">승인</button>
            <button type="button" class="ui-button ui-button__border--blue"  @click="fnApprAccept('REJECT')">반려</button>
          </template>
          <template v-if="showApprovalBtn('USR020')">
            <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnMutual('ACCEPT')">합의</button>
            <button type="button" class="ui-button ui-button__border--blue" @click="fnMutual('REJECT')">거부</button>
          </template>
        </template>
        <button type="button" class="ui-button ui-button__bg--gray" @click.prevent="fnConfirmList">목록</button>
      </div>
    </div>
  </div>

</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useStore } from 'vuex'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'
import { useApproval } from '@/compositions/approval/useApproval'
import { useRoute, useRouter } from 'vue-router'

export default {
  name: 'ProcessFuncConfirmNameReg',
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    ApprovalRegister: defineAsyncComponent(() => import('@/components/comm/ApprovalRegister.vue')),
    ApprovalView: defineAsyncComponent(() => import('@/components/comm/ApprovalView.vue')),
  },
  props: {
    actionFlag: {
      type: Object,
      default: () => {
        return {}
      }
    },
    flagSaveAction : {
      type : Object,
      default : () => {
        return {}
      }
    },
    decideInfo : {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  emits:['update:actionFlag', 'update:flagSaveAction', 'update:decideInfo'],
  setup (props, context) {
    const appr = ref(null)
    const apprView = ref(null)
    const store = useStore()
    const myInfo = store.getters.getMyInfo()
    const noteType = store.getters.getNoteType()
    const selectedTab = ref('prodName')
    const commonUtils = inject('commonUtils')
    const { openAsyncConfirm, openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncConfirm', 'openAsyncAlert', 'closeAsyncPopup'])
    const route = useRoute()
    const router = useRouter()

    const apprMstInfo = ref(null)
    const apprUserList = ref(null)
    let apprProcStatus = ''
    let apprProcSubStatus = ''

    const tabList = [
      { tabId: 'prodName', tabNm: '확정 제품명' },
      { tabId: 'testReport', tabNm: '시험 성적서' },
    ]

    const {
      searchParams,
      resVo,
      apprList,
      nameList,
      selectLabContList,
      selectLabNoteFuncDecideContName,
      saveFuncDecideName,
      noteTypeNm,
    } = useProcessCommon()

    const {
      updateFuncDecideName
    } = useApproval() 

    const fnConfirmList = () => {
      router.replace({ query: {vLabNoteCd: route.query.vLabNoteCd }})
      setTimeout(() => {
        context.emit('update:actionFlag', 'L')
      }, 200)
    }

    const getSelectedTabEvent = (item) => {
      selectedTab.value = item.tabId
    }

    const init = async () => {
      if(props.flagSaveAction == '' || props.flagSaveAction == 'R'){
        await selectLabContList()
      }
      else if(props.flagSaveAction == 'M'){
        const payload = {
          vLabNoteCd : props.decideInfo.vLabNoteCd,
          vFlagSaveAction : props.flagSaveAction,
          nFdnVer : props.decideInfo.nFdnVer,
          vStatusCd : props.decideInfo.vStatusCd,
          vRegUserid : props.decideInfo.vRegUserid
        }
        
        await selectLabNoteFuncDecideContName(payload)
      }
    }

    init()
    
    const contNmDelete = (flagDelete, idx) => {
      if(flagDelete == 'Y'){  //Y : 삭제 해야 함
        nameList.value[idx].vFlagDel = 'Y'
        let tr = document.querySelector(".td_del_btn"+idx).closest("tr")
        tr.classList.add('del-func-confirm')
        tr.childNodes.forEach(item => {
          if(item.querySelector('.decide_cont_nm')){
            item.querySelector('.decide_cont_nm').disabled = true
          }
        })
      }else{  //N : 복원 해야 함
        nameList.value[idx].vFlagDel = 'N'
        let tr = document.querySelector(".td_del_btn"+idx).closest("tr")
        tr.classList.remove('del-func-confirm')
        tr.childNodes.forEach(item => {
          if(item.querySelector('.decide_cont_nm')){
            item.querySelector('.decide_cont_nm').disabled = false
          }
        })
      }
    }

    const fnSaveCheck = async (obj) => {
      let isOk = true
      obj.forEach(item => {
        if(item.vFlagDel == 'N' && (item.vDecideContNm === '' || item.vDecideContNm === undefined)){
          openAsyncAlert({ message: '기능성 확정 제품명을 입력해주세요.' })
          isOk = false
        }
      })
      return isOk
    }

    const checkOnlyKorean = async (nameList) => {
      let isOk = true
      nameList.forEach(item => {
        if(item.vFlagDel == 'N'){
          const contNm = item.vDecideContNm
          if(contNm.match(/[a-z]|[A-Z]/)){
            openAsyncAlert({ message: '기능성 확정 제품명은 <span style=\"color: red;font-weight: bolder;\">영문 입력이 불가</span> 합니다.<br/>국문으로 기재해주세요.' })
            isOk = false
          }
  
          if(contNm.match(/[-/()*"'@\[\]]/)){
            openAsyncAlert({ message: '기능성 확정 제품명은 <span style=\"color: red;font-weight: bolder;\">+ 와 . 이외 입력이 불가</span> 합니다.' })
            isOk = false
          }
        }
      })
      return isOk
    }

    //임시저장
    const fnSave = async () => {
      if (!await openAsyncConfirm({ message: '임시저장 하시겠습니까?' })) {
        return
      }

      if(!await fnSaveCheck(nameList.value)){
        return
      }

      if(!await checkOnlyKorean(nameList.value)){
        return
      }

      //reg param setting
      const arrDecideContList = ref([]) 
      nameList.value.forEach(item => {
        let obj = {
          vContPkCd : '',
          vFlagNmDel : '',
          vDecideContNm : '',
        }
        obj.vContPkCd = item.vContPkCd
        obj.vFlagNmDel = (item.vFlagDel == undefined || item.vFlagDel == '') ? 'N' : item.vFlagDel
        obj.vDecideContNm = item.vDecideContNm
        arrDecideContList.value.push(obj)
      })

      const payload = {
        vFlagSaveAction : resVo.value.vFlagSaveAction,
        vNoteType: noteType,
        vLabNoteCd: resVo.value.vLabNoteCd,
        vStatusCd : resVo.value.vFdnStatusCd,
        nFdnVer : props.flagSaveAction == 'M' ? props.decideInfo.nFdnVer : 0,
        arrDecideContList: arrDecideContList.value
      }

      const result = await saveFuncDecideName(payload)
      if (result && result === 'SUCC') {
        await openAsyncAlert({ message: '임시저장 되었습니다.' })
        fnConfirmList()
      }
    }

    //결재요청
    const fnAppr = () => {
      if (appr.value) {
        appr.value.fnApprovalOpinionPop()
      }
    }

    //결재요청 > 팝업에서 확인 후 return 메소드
    const fnApprSave = async (draftOpinion) => {
      if (!await openAsyncConfirm({ message: '결재 의뢰 하시겠습니까?' })) {
        return
      }

      if(!await fnSaveCheck(nameList.value)){
        return
      }

      if(!await checkOnlyKorean(nameList.value)){
        return
      }

      //reg param setting
      const arrDecideContList = ref([]) 
      nameList.value.forEach(item => {
        let obj = {
          vContPkCd : '',
          vFlagNmDel : '',
          vDecideContNm : '',
        }
        obj.vContPkCd = item.vContPkCd
        obj.vFlagNmDel = (item.vFlagDel == undefined || item.vFlagDel == '') ? 'N' : item.vFlagDel
        obj.vDecideContNm = item.vDecideContNm
        arrDecideContList.value.push(obj)
      })

      if (appr.value) {
        const payload = {
          vFlagSaveAction : resVo.value.vFlagSaveAction,
          vNoteType: noteType,
          vLabNoteCd: resVo.value.vLabNoteCd,
          nFdnVer : props.flagSaveAction == 'M' ? props.decideInfo.nFdnVer : 0,
          arrDecideContList: arrDecideContList.value,
          vApprTypeCd: 'LAB_PRDNM_SET',
          vStatusCd : 'DOC020',
          apprReqInfo: {
            apprInfo: appr.value.apprInfo,
            apprList: appr.value.apprList
          }
        }

        payload.apprReqInfo.apprInfo.vDraftOpinion = draftOpinion

        const result = await saveFuncDecideName(payload)

        if (result && result === 'SUCC') {
          await openAsyncAlert({ message: '결재 요청되었습니다.' })
          fnConfirmList()
        }
      }
    }
    
    const showApprovalBtn = (apprUserType) => {
      let isVisible = false

      if (apprMstInfo.value &&
          apprMstInfo.value.vApprStatus === 'APS030' &&
          apprUserList.value?.length > 0) {
        const curApprUser = apprUserList.value.filter(v => v.nCurApprseq === apprMstInfo.value.nCurApprseq)

        if (curApprUser && curApprUser.length > 0 &&
            (curApprUser[0].vApprUserid === myInfo.loginId || commonUtils.checkAuth('S000000')) &&
            curApprUser[0].vApprUserType === apprUserType) {
          isVisible = true
        }
      }

      return isVisible
    }

    const fnApprAccept = (flag) => {
      if (apprView.value) {
        if (flag === 'ACCEPT') {
          apprProcStatus = 'APS010'
        } else if (flag === 'REJECT') {
          apprProcStatus = 'APS020'
        }

        apprView.value.fnApprovalOpinionPop()
      }
    }
    
    const fnApprProc = async (draftOpinion) => {
      store.dispatch('setLoading', true)

      const payload = {
        noteTypeNm,
        ...apprMstInfo.value,
        ...{
          vApprStatus: apprProcStatus,
          vApprSubStatus: apprProcSubStatus,
          vApprOpinion: draftOpinion.value
        },
      }

      const result = await updateFuncDecideName(payload)
      if (result) {
        router.push({ path: '/approval/list' })
      }else{
        store.dispatch('setLoading', false)
      }
    }

    const fnMutual = (flag) => {
      apprProcStatus = 'APS050'

      if (apprView.value) {
        if (flag === 'ACCEPT') {
          apprProcSubStatus = 'AGR010'
        } else {
          apprProcSubStatus = 'AGR030'
        }

        apprView.value.fnApprovalOpinionPop()
      }
    }

    return {
      tabList,
      selectedTab,
      getSelectedTabEvent,
      closeAsyncPopup, 
      fnConfirmList,
      searchParams,
      selectLabContList,
      selectLabNoteFuncDecideContName,
      resVo,
      apprList,
      nameList,
      appr,
      fnApprSave,
      fnSave,
      fnAppr,
      checkOnlyKorean,
      contNmDelete,
      noteType,
      commonUtils,
      showApprovalBtn,
      apprView,
      fnApprProc,
      apprMstInfo,
      apprUserList,
      apprProcStatus,
      apprProcSubStatus,
      fnApprAccept,
      myInfo,
      fnMutual
    }
  }
}
</script>