<template>
  <div class="inside-td__item mt-15">
    <div class="inside-td__item--title">자가체크</div>
    <div class="inside-td__item--wrap">
      <table class="ui-table__reset inside-td__table">
        <colgroup>
          <col style="width:15rem"> 
          <col style="width:auto"> 
          <col style="width:12rem"> 
          <col style="width:auto"> 
        </colgroup>
        <thead>
          <tr>
            <th>항목</th>
            <th>자가체크 사항</th>
            <th>준수여부</th>
            <th>비고</th>
          </tr>
        </thead>
        <tbody>
          <template v-for="(vo, idx) in pqcList" :key="'pqc_list_'+idx">
            <tr class="tr_pqc_chk_title">
              <td rowspan="2">
                <span class="item-title">{{ vo.vPqcItemNm }}</span>
              </td>
              <td class="text-left">
                <span class="question-mark">Q.</span> {{ vo.vPqcChkText }}
              </td>
              <td rowspan="2">
                {{ vo.vFlagObey === 'P' ? 'PASS' : vo.vFlagObey }}
              </td>
              <td rowspan="2">
                <template v-if="commonUtils.isNotEmpty(vo.vBuffer1) && commonUtils.isNotEmpty(trMap[vo.vBuffer1])">
                  <table class="ui-table__reset inside-td__table">
                    <colgroup>
                      <col style="width:20%">
                      <col style="width:25%">
                      <col style="width:20%">
                      <col style="width:auto">
                    </colgroup>
                    <thead>
                      <tr>
                        <th>의뢰날짜</th>
                        <th>Lot</th>
                        <th>내용물코드</th>
                        <th>시험결과</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-for="(svo, idx) in trMap[vo.vBuffer1]" :key="'trSubMap_'+idx">
                        <td>
                          {{ commonUtils.isNotEmpty(svo.vLabReqDtm) ? commonUtils.changeStrDatePattern(svo.vLabReqDtm) : changeStrDatePattern(svo.vRegDtm) }}
                        </td>
                        <td>
                          <template v-if="svo.vLabMrqTypeCd == 'CLINICAL'">
                            <a class="tit-link txt_blue" :href="tiumUrl + '/ct/ct/clinical_test_discuss_renew_view.do?i_sTempStatusCd=DISCUSS&i_sTestCd=' + svo.vProductCd" target="_blank">
                              Ver {{ svo.nLabNoteVer }}{{ svo.vLabGateCd == 'GATE_2' ? 'Pilot' : '' }}
                            </a>
                          </template>
                          <template v-else-if="svo.vLabMrqTypeCd != 'MRQ010' && svo.vLabGateCd == 'GATE_2'">
                            <a class="tit-link txt_blue" :href="tiumUrl + '/zm/tr/zm_tr_product_view.do?i_sProductCd='+svo.vProductCd + '&&i_iVersion='+svo.nVersion" target="_blank">
                              Ver {{ svo.nLabNoteVer }}, {{ svo.vLotNm }} Pilot
                            </a>
                          </template>
                          <template v-else-if="svo.vLabMrqTypeCd == 'MRQ010'">
                            <a class="tit-link txt_blue" :href="tiumUrl + '/zm/safe/tr/zm_safe_tr_product_view.do?i_sProductCd=' +svo.vProductCd+'&i_iVersion='+svo.nVersion" target="_blank">
                              Ver {{ svo.nLabNoteVer }}, {{ svo.vLotNm }}
                            </a>
                          </template>
                          <template v-else-if="svo.vLabMrqTypeCd == 'MRQ011'">
                            <a class="tit-link txt_blue" :href="tiumUrl + '/zm/bb/tr/zm_bb_tr_product_view.do?i_sProductCd='+svo.vProductCd +'&i_iVersion='+svo.nVersion" target="_blank">
                              Ver {{ svo.nLabNoteVer }}, {{ svo.vLotNm }}
                            </a>
                          </template>
                          <template v-else>
                            <a class="tit-link txt_blue" :href="tiumUrl + '/zm/tr/zm_tr_product_view.do?i_sProductCd='+svo.vProductCd +'&i_iVersion='+svo.nVersion" target="_blank">
                              Ver {{ svo.nLabNoteVer }}, {{ svo.vLotNm }}
                            </a>
                          </template>
                        </td>
                        <td v-html="commonUtils.removeHTMLChangeBr(svo.vTargetContCd)"></td>
                        <td v-html="commonUtils.removeHTMLChangeBr(svo['vTrRes'+vo.vBuffer1+'Txt'])"></td>
                      </tr>
                    </tbody>
                  </table>
                </template>
              </td>
            </tr>
            <tr class="tr_pqc_item_list">
              <td class="text-left">
                <template v-if="vo.vItemTypeCd.indexOf('TCOST') > -1">
                  {{ vo.vChoiceVal01 === 'Y' ? '준수' : '미준수' }}
                </template>
                <template v-if="vo.vItemTypeCd.indexOf('PILOT') > -1">
                  <template v-if="versionInfo && versionInfo.vPrePilotDt">
                    선행 {{ commonUtils.changeStrDatePattern(versionInfo.vPrePilotDt) }}
                  </template>
                  <template v-else>
                    일반 {{ commonUtils.changeStrDatePattern(noteInfo.vPilotDt) }}
                  </template>
                </template>
                <template v-if="vo.vItemTypeCd.indexOf('GLB_BAN') > -1">
                  {{ vo.vChoiceVal01 === 'Y' ? '확인' : '미확인' }}
                </template>
                <template v-if="vo.vItemTypeCd.indexOf('PAO') > -1">
                  사용기한 : {{ vo.vTextVal01 }}, PAO : {{ vo.vTextVal02 }}
                </template>
                <template v-if="vo.vItemTypeCd.indexOf('G2_GQMS') > -1">
                  <div class="form-flex mt-15">
                    <div class="ui-input__width--60">
                      점도 :
                    </div>
                    <div class="ui-form-box__width--150">
                      {{ vo.vBufferVal01 }}
                    </div>
                    <div class="ui-input__width--60 ml-20">
                      경도 :
                    </div>
                    <div class="ui-form-box__width--150">
                      {{ vo.vBufferVal02 }}
                    </div>
                  </div>
                  <div class="form-flex mt-15">
                    <div class="ui-input__width--60">
                      비중 :
                    </div>
                    <div class="ui-form-box__width--150">
                      {{ vo.vBufferVal03 }}
                    </div>
                    <div class="ui-input__width--60 ml-20">
                      pH :
                    </div>
                    <div class="ui-form-box__width--150">
                      {{ vo.vBufferVal04 }}
                    </div>
                  </div>
                  <div class="form-flex mt-15">
                    <div class="ui-input__width--60">
                      추가규격 :
                    </div>
                    <div class="ui-form-box__width--150">
                      {{ vo.vBufferVal05 }}
                    </div>
                    <div class="ui-input__width--60 ml-20">
                      변경사유 :
                    </div>
                    <div class="ui-form-box__width--150">
                      {{ vo.vBufferVal06 }}
                    </div>
                  </div>
                </template>
                <template v-if="vo.vItemTypeCd.indexOf('CHOICE') > -1">
                  <template v-if="vo.codeList && vo.codeList.length > 0">
                    <template v-if="vo.codeList.filter(item => item.v_val === vo.vChoiceVal01).length > 0">
                      {{ vo.codeList.filter(item => item.v_val === vo.vChoiceVal01)[0].v_text }}
                    </template>
                    <template v-if="commonUtils.isNotEmpty(vo.vChoiceTextVal01)">
                      (<span v-if="vo.codeList.filter(item => item.v_val === vo.vChoiceVal01)[0] && commonUtils.isNotEmpty(vo.codeList.filter(item => item.v_val === vo.vChoiceVal01)[0].v_before_text)">{{ vo.codeList.filter(item => item.v_val === vo.vChoiceVal01)[0].v_before_text }}</span>
                      {{ vo.vChoiceTextVal01 }}
                      <span v-if="vo.codeList.filter(item => item.v_val === vo.vChoiceVal01)[0] && commonUtils.isNotEmpty(vo.codeList.filter(item => item.v_val === vo.vChoiceVal01)[0].v_after_text)">{{ vo.codeList.filter(item => item.v_val === vo.vChoiceVal01)[0].v_after_text }}</span>)
                    </template>
                  </template>
                </template>
                <template v-if="vo.vItemTypeCd.indexOf('G1_GQMS') > -1">
                  <br><br>( 점도:  {{ vo.vBufferVal01 }}, 경도: {{ vo.vBufferVal02 }}, 비중: {{ vo.vBufferVal03 }}, pH: {{ vo.vBufferVal04 }}, 추가규격: {{ vo.vBufferVal05 }}, 변경사유: {{ vo.vBufferVal06 }} )
                </template>
                <template v-if="vo.vItemTypeCd.indexOf('TEXT') > -1">
                  {{ vo.vBeforeText }} : {{ vo.vTextVal01 }}, {{ vo.vAfterText }}
                </template>
              </td>
            </tr>
          </template>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
import { inject, getCurrentInstance } from 'vue'
export default {
  name: 'ProcessPQCGateCheckInfo',
  props: {
    pqcList: {
      type: Array,
      default: () => {
        return []
      }
    },
    noteInfo: {
      type: Object,
      default: () => {
        return {}
      }
    },
    versionInfo: {
      type: Object,
      default: () => {
        return {}
      }
    },
    trMap: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  setup (props) {
    const commonUtils = inject('commonUtils')
    const app = getCurrentInstance()
    const tiumUrl = app.appContext.config.globalProperties.tiumUrl

    return {
      tiumUrl,
      commonUtils,
    }
  }
}
</script>