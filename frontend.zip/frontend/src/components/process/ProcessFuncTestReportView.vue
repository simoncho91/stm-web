<template>
  <template v-if="reportRegInfo">

    <div class="search-bar__row search-bar__row--mt12">
      <dl class="search-bar__item">
        <dt class="search-bar__key search-bar__key--width-220">버전</dt>
        <dd class="search-bar__val search-bar__val--flexible">
          <template v-if="reportRegInfo.qaVo.nVersion < 10">
            Ver #0{{ reportRegInfo.qaVo.nVersion }}
          </template>
          <template v-else-if="reportRegInfo.qaVo.nVersion >= 10">
            Ver #{{ reportRegInfo.qaVo.nVersion }}
          </template>
        </dd>
      </dl>
    </div>
    <div class="search-bar__row search-bar__row--mt12">
      <dl class="search-bar__item">
        <dt class="search-bar__key search-bar__key--width-220">내용물 정보</dt>
        <dd class="search-bar__val search-bar__val--flexible">
          <div class="note-table">
            <div class="note-table__inner">
              <table class="ui-table ui-table__td--40 text-center">
                <colgroup>
                  <col v-if="reportRegInfo.decideNmList.length > 1" style="width:10%;">
                  <col style="width:12%;">
                  <col style="width:13rem;">
                  <col v-if="noteType == 'SC'" style="width:25%;">
                  <col style="width:auto;">
                  <col style="width:auto;">
                </colgroup>
                <thead>
                  <tr>
                    <th v-if="reportRegInfo.decideNmList.length > 1">대표 홋수</th>
                    <th>내용물 코드</th>
                    <th>LOT</th>
                    <th v-if="noteType == 'SC'">차수 / 일자 / 제조번호</th>
                    <th>내용물 명</th>
                    <th>기능성 확정 제품명</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="(vo, idx) in reportRegInfo.decideNmList" :key="'contVo_' + idx" class="tr_contList">
                    <td v-if="reportRegInfo.decideNmList.length > 1">{{ vo.vFlagRepresent == 'Y' ? '√' : '' }}</td>
                    <td>{{ vo.vContCd }}</td>
                    <td>
                      <div v-if="commonUtils.isNotEmpty(vo.vLotCdList)">
                        <template v-for="(lvo, i) in vo.vLotCdList.split(',')" :key="'lot_'+i">
                          <template v-if="lvo === vo.vLotCd">
                            {{ vo.vLotNmList.split(',')[i] }}
                          </template>
                        </template>
                      </div>
                    </td>
                    <td v-if="noteType == 'SC'">
                      <div v-if="reportRegInfo.qmsLotInfoList && reportRegInfo.qmsLotInfoList.length > 0">
                        <template v-for="(qVo, idx) in reportRegInfo.qmsLotInfoList" :key="'qms_lot_' + idx">
                          <template v-if="vo.vContCd == qVo.vContCd && commonUtils.isNotEmpty(qVo.vSeq)">
                            {{ qVo.vSeq + ' / ' + qVo.vDate + ' / ' + qVo.vLot }}
                          </template>
                        </template>
                      </div>
                    </td>
                    <td class="tit">
                      <div class="tit__inner cont_name text-center">
                        {{ vo.vContNm }}
                      </div>
                    </td>
                    <td>
                      {{ vo.vDecideContNm }}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </dd>
      </dl>
    </div>

    <div class="search-bar__row search-bar__row--mt12">
      <dl class="search-bar__item">
        <dt class="search-bar__key search-bar__key--width-220">주성분 원료코드/원료명/함량</dt>
        <dd class="search-bar__val search-bar__val--flexible">
          
          <template v-if="strFuncList">
            <table class="ui-table__reset ui-table__ver">
              <colgroup>
                <col style="width:13rem">
                <col style="width:auto">
              </colgroup>
              <tbody>
                <tr>
                  <th>기능성 분류</th>
                  <td>
                    {{ strFuncList }}
                  </td>
                </tr>
                <tr>
                  <th>관련근거</th>
                  <td>{{ reportRegInfo.verVo.vRefTypeNm }}</td>
                </tr>
                <tr v-if="reportRegInfo.verVo.vRefTypeCd == 'LNC05_01'">
                  <th>주성분</th>
                  <td></td>
                </tr>
                <tr v-if="reportRegInfo.verVo.vRefTypeCd == 'LNC05_02'">
                  <th>제형</th>
                  <td>
                    <div class="form-flex">
                      <div class="form-flex-cell" v-if="reportRegInfo.verVo.vRefTypeCd != 'LNC05_03'">
                        {{ reportRegInfo.verVo.vShape }}
                      </div>
                      <div v-if="noteType == 'SC'" class="form-flex-cell ml-40">
                        2액 이상 : 
                        <template v-if="reportRegInfo.qaVo.vTwoLiqYn == 'Y'">
                          {{ reportRegInfo.qaVo.vTwoLiqYn }}, {{ reportRegInfo.qaVo.vTwoLiqTxt }}
                        </template>
                        <template v-else>N</template>
                      </div>
                    </div>
                  </td>
                </tr>
                <tr v-if="reportRegInfo.verVo.vRefTypeCd == 'LNC05_02'">
                  <th>심사번호</th>
                  <td>
                    <span class="color-lightblue">
                      <a href="javascript:;" @click.prevent="openEvaluatePop(reportRegInfo.verVo.vEvaluateCd)" class="tit-link txt_blue pl-0">
                        {{ reportRegInfo.verVo.vEvaluateno }}
                      </a>
                      <template v-if="commonUtils.isNotEmpty(reportRegInfo.verVo.vEvaluateGosiCd)">
                        /
                        <a href="javascript:;" @click.prevent="openEvaluatePop(reportRegInfo.verVo.vEvaluateGosiCd)" class="tit-link txt_blue pl-0">
                          {{ reportRegInfo.verVo.vEvaluateGosiNm }}
                        </a>
                      </template>
                    </span>
                  </td>
                </tr>
                <tr v-if="reportRegInfo.verVo.vRefTypeCd == 'LNC05_03' || reportRegInfo.verVo.vRefTypeCd == 'LNC05_04'">
                  <th>심사항목</th>
                  <td>{{ reportRegInfo.verVo.vRefNote }}</td>
                </tr>
                <tr v-if="reportRegInfo.verVo.vRefTypeCd == 'LNC05_05'">
                  <th>심사번호</th>
                  <td>
                    <template v-if="refNoteBtnFlag == 'V'">
                      {{ reportRegInfo.verVo.vRefNote }}
                      <button type="button" class="ui-button ml-5 ui-button__bg--gray" @click.prevent="saveRefNote('V')">
                        수정
                      </button>
                    </template>
                    <template v-else>
                      <ap-input
                        :maxlength="200"
                        id="refNote"
                        class="ui-input__width--150"
                        v-model:value="reportRegInfo.verVo.vRefNote"
                      >
                      </ap-input>
                      <button type="button" class="ui-button ml-5 ui-button__bg--gray" @click.prevent="saveRefNote('M')">
                        저장
                      </button>
                    </template>
                  </td>
                </tr>
              </tbody>
            </table>
          </template>

          <div class="note-table mt-12">
            <div class="note-table__inner">
              <table class="ui-table ui-table__td--40 text-center">
                <colgroup>
                  <col style="width:15%;">
                  <col style="width:20%;">
                  <col style="width:12%;">
                  <col style="width:auto;">
                </colgroup>
                <thead>
                  <tr>
                    <th>원료 코드</th>
                    <th>원료명</th>
                    <th>함량</th>
                    <th>비고</th>
                  </tr>
                </thead>
                <tbody>
                  <template v-if="reportRegInfo.mateList && reportRegInfo.mateList.length > 0"> 
                    <tr v-for="(vo, idx) in reportRegInfo.mateList" :key="'mateList_'+ idx">
                      <td>
                        <template v-if="commonUtils.isEmpty(vo.vMateCd) && commonUtils.isNotEmpty(vo.vMateTempCd)">
                          임시코드 {{ vo.vMateTempCd }}
                        </template>
                        <template v-else>
                          {{ vo.vMateCd }}
                        </template>
                      </td>
                      <td>{{ vo.vMateNm }}</td>
                      <td>{{ vo.nReqRate }}</td>
                      <td class="text-left">{{ vo.vNote }}</td>
                    </tr>
                  </template>
                  <template v-else>
                    <tr>
                      <td colspan="4"> :: 등록된 필수원료가 없습니다. :: </td>
                    </tr>  
                  </template>
                </tbody>
              </table>
            </div>
          </div>
        </dd>
      </dl>
    </div>

    <div class="search-bar__row search-bar__row--mt12">
      <dl class="search-bar__item">
        <dt class="search-bar__key search-bar__key--width-220">브랜드 담당 PM</dt>
        <dd class="search-bar__val search-bar__val--flexible">{{reportRegInfo.rvo.vBrdUsernm}} ({{reportRegInfo.rvo.vBrdUserid}} / {{reportRegInfo.rvo.vBrdDeptnm}})</dd>
      </dl>
    </div>

    <div class="search-bar__row search-bar__row--mt12">
      <dl class="search-bar__item">
        <dt class="search-bar__key search-bar__key--width-220">제품연구원</dt>
        <dd class="search-bar__val search-bar__val--flexible">{{reportRegInfo.rvo.vUsernm}} ({{reportRegInfo.rvo.vUserid}} / {{reportRegInfo.rvo.vUsrDeptnm}})</dd>
      </dl>
    </div>

    <div class="search-bar__row search-bar__row--mt12">
      <dl class="search-bar__item">
        <dt class="search-bar__key search-bar__key--width-220">출시지역</dt>
        <dd class="search-bar__val search-bar__val--flexible">
          <template v-for="(releaseVo, idx) in reportRegInfo.releaseDt" :key="'relase_dt_' + idx">
            {{ releaseVo.vSubCodenm }} ({{commonUtils.changeStrDatePattern(releaseVo.vTagBuffer1, '.')}})
            <template v-if="releaseVo.vSubCode == 'LNC02_04'">({{releaseVo.vTagBuffer2}})</template>
          </template>
        </dd>
      </dl>
    </div>

    <div class="search-bar__row search-bar__row--mt12">
      <dl class="search-bar__item">
        <dt class="search-bar__key search-bar__key--width-220">파일럿 시기</dt>
        <dd class="search-bar__val search-bar__val--flexible">{{commonUtils.changeStrDatePattern(reportRegInfo.rvo.vPilotDt, '.')}}</dd>
      </dl>
    </div>

    <div class="search-bar__row search-bar__row--mt12">
      <dl class="search-bar__item">
        <dt class="search-bar__key search-bar__key--width-220">양산일</dt>
        <dd class="search-bar__val search-bar__val--flexible">{{commonUtils.changeStrDatePattern(reportRegInfo.rvo.vMassProdDt, '.')}}</dd>
      </dl>
    </div>
    
    <template v-if="reportRegInfo.verVo.vRefTypeCd == 'LNC05_03'">
      <div class="search-bar__row search-bar__row--mt12">
        <dl class="search-bar__item search-bar__item--width-100">
          <dt class="search-bar__key search-bar__key--width-220">효능·효과</dt>
          <dd class="search-bar__val search-bar__val--flexible">
            {{ reportRegInfo.qaVo.vEffect }}
          </dd>
        </dl>
      </div>

      <div class="search-bar__row search-bar__row--mt12">
        <dl class="search-bar__item search-bar__item--width-100">
          <dt class="search-bar__key search-bar__key--width-220">용법·용량</dt>
          <dd class="search-bar__val search-bar__val--flexible">
            {{ reportRegInfo.qaVo.vUsageCapacity }}
          </dd>
        </dl>
      </div>
    </template>

    <template v-if="reportRegInfo.verVo.vRefTypeCd == 'LNC05_04'">
      <div class="search-bar__row search-bar__row--mt12">
        <dl class="search-bar__item search-bar__item--width-100">
          <dt class="search-bar__key search-bar__key--width-220">심사번호</dt>
          <dd class="search-bar__val search-bar__val--flexible">
            {{ reportRegInfo.qaVo.vEvaluateNum }}
          </dd>
        </dl>
      </div>
      <div class="search-bar__row search-bar__row--mt12">
        <dl class="search-bar__item search-bar__item--width-100">
          <dt class="search-bar__key search-bar__key--width-220">변경제품명</dt>
          <dd class="search-bar__val search-bar__val--flexible">
            {{ reportRegInfo.qaVo.vChangeProduct }}
          </dd>
        </dl>
      </div>
      <div class="search-bar__row search-bar__row--mt12">
        <dl class="search-bar__item search-bar__item--width-100">
          <dt class="search-bar__key search-bar__key--width-220">변경내용물코드</dt>
          <dd class="search-bar__val search-bar__val--flexible">
            {{ reportRegInfo.qaVo.vChangeCd }}
          </dd>
        </dl>
      </div>
      <div class="search-bar__row search-bar__row--mt12">
        <dl class="search-bar__item search-bar__item--width-100">
          <dt class="search-bar__key search-bar__key--width-220">변경사항</dt>
          <dd class="search-bar__val search-bar__val--flexible">
            {{ reportRegInfo.qaVo.vChangeNote }}
          </dd>
        </dl>
      </div>
    </template>

    <template v-if="reportRegInfo.verVo.vRefTypeCd != 'LNC05_03' && reportRegInfo.verVo.vRefTypeCd != 'LNC05_04'">
      <div class="search-bar__row search-bar__row--mt12">
        <dl class="search-bar__item">
          <dt class="search-bar__key search-bar__key--width-220">홋수명</dt>
          <dd class="search-bar__val search-bar__val--flexible">
            {{ commonUtils.removeHTMLChangeBr(reportRegInfo.qaVo.vNumberNm) }}
          </dd>
        </dl>
      </div>
    
      <div class="search-bar__row search-bar__row--mt12">
        <dl class="search-bar__item">
          <dt class="search-bar__key search-bar__key--width-220">
            총TiO2, ZnO 함량 <br>
            (자외선차단제일 경우만 해당)
          </dt>
          <dd class="search-bar__val search-bar__val--flexible">
            <div class="note-table mt-12">
              <div class="note-table__inner">
                <table class="ui-table ui-table__td--40 text-center">
                  <colgroup>
                    <col style="width:50%;">
                    <col style="width:50%;">
                  </colgroup>
                  <thead>
                    <tr>
                      <th>TiO2 함량</th>
                      <th>ZNO 함량</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <template v-if="commonUtils.isNotEmpty(reportRegInfo.qaVo.vTioTwoNote)">
                          {{ commonUtils.removeHTMLChangeBr(reportRegInfo.qaVo.vTioTwoNote) }}
                        </template>
                        <template v-else>
                          {{ reportRegInfo.qaVo.nTioTwoRate }}
                        </template>
                      </td>
                      <td>
                        <template v-if="commonUtils.isNotEmpty(reportRegInfo.qaVo.vZnoNote)">
                          {{ commonUtils.removeHTMLChangeBr(reportRegInfo.qaVo.vZnoNote) }}
                        </template>
                        <template v-else>
                          {{ reportRegInfo.qaVo.nZnoRate }}
                        </template>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </dd>
        </dl>
      </div>
    
      <div class="search-bar__row search-bar__row--mt12">
        <dl class="search-bar__item">
          <dt class="search-bar__key search-bar__key--width-220">제조원</dt>
          <dd class="search-bar__val search-bar__val--flexible">
            <template v-if="reportRegInfo.qaVo.vMaker != 'ETC'">
              {{ reportRegInfo.qaVo.vMakerNm }}
            </template>
            <template v-else>
              {{ reportRegInfo.qaVo.vMakerTxt }}
            </template>  
          </dd>
        </dl>
      </div>
    </template>

    <template v-if="reportRegInfo.verVo.vRefTypeCd == 'LNC05_03' || reportRegInfo.verVo.vRefTypeCd == 'LNC05_04'">
      <div class="search-bar__row search-bar__row--mt12">
        <dl class="search-bar__item search-bar__item--width-100">
          <dt class="search-bar__key search-bar__key--width-220">제조사업장<br>(대전/오산/기타)</dt>
          <dd class="search-bar__val search-bar__val--flexible">
            {{ reportRegInfo.qaVo.vMakePlace }}
          </dd>
        </dl>
      </div>
    </template>

    <div class="search-bar__row search-bar__row--mt12">
      <dl class="search-bar__item search-bar__item--width-100">
        <dt class="search-bar__key search-bar__key--width-220">PH(기준치±1.0)</dt>
        <dd class="search-bar__val search-bar__val--flexible">
          {{ reportRegInfo.qaVo.vPh }}
        </dd>
      </dl>
    </div>

    <div class="search-bar__row search-bar__row--mt12">
      <dl class="search-bar__item search-bar__item--width-100">
        <dt class="search-bar__key search-bar__key--width-220">첨부파일</dt>
        <dd class="search-bar__val search-bar__val--flexible">
          <UploadFileView
            v-if="commonUtils.isNotEmpty(detailInfo.vLabNoteCd)"
            uploadid="NOTETAB08"
            :recordid="detailInfo.vLabNoteCd + '_' + detailInfo.nVersion + '_' + detailInfo.nSeqno"
          >
          </UploadFileView>
        </dd>
      </dl>
    </div>

    <div class="board-bottom">
      <div class="board-bottom__inner">
        <div class="ui-buttons ui-buttons__right">
          <button type="button" class="ui-button ui-button__bg--gray" @click="fnTestReqList">목록</button>
        </div>
      </div>
    </div>

    <teleport to="#common-modal" v-if="popupContent">
      <ap-popup>
        <component
          :is="popupContent"
          :pop-params="popParams"
          @callbackFunc="popSelectFunc"
          @selectFunc="popSelectFunc"
        />
      </ap-popup>
    </teleport>
  </template>
</template>

<script>
import { defineAsyncComponent, reactive, ref, inject, getCurrentInstance } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'
import { useStore } from 'vuex'
import { useRoute, useRouter } from 'vue-router'

export default {
  name: 'ProcessFuncTestReportView',
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    UploadFileView: defineAsyncComponent(() => import('@/components/comm/UploadFileView.vue')),
  },
  props : {
    actionFlag: {
      type: Object,
      default: () => {
        return {}
      }
    },
    flagSaveAction: {
      type: Object,
      default: () => {
        return {}
      }
    },
    detailInfo : {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  emits:['update:actionFlag', 'update:flagSaveAction', 'update:detailInfo'],
  setup (props, context) {
    const app = getCurrentInstance()
    const tiumUrl = app.appContext.config.globalProperties.tiumUrl
    const { openAsyncAlert, closeAsyncPopup, openAsyncConfirm } = useActions(['openAsyncAlert', 'closeAsyncPopup', 'openAsyncConfirm'])
    const commonUtils = inject('commonUtils')
    const strFuncList = ref(null)
    const store = useStore()
    const noteType = store.getters.getNoteType()
    const refNoteBtnFlag = ref('M')
    const route = useRoute()
    const router = useRouter()

    const {
      selectFuncTestEpReportView,
      updateNoteRefNote
    } = useProcessCommon()

    const reportRegInfo = ref(null)

    const init = async () => {
      const payload = {
        vLabNoteCd : props.detailInfo.vLabNoteCd,
        nVersion : props.detailInfo.nVersion,
        nSeqno : props.detailInfo.nSeqno,
      }
      const result = await selectFuncTestEpReportView(payload)
      reportRegInfo.value = {...reportRegInfo.value, ...result}

      const funcList = reportRegInfo.value.funcList
      const arrFuncList = []
      if(funcList.length > 0){
        for(let i = 0; i < funcList.length; i++){
          if(commonUtils.isNotEmpty(funcList[i].vTag2Cd)){
            arrFuncList.push(funcList[i].vSubCodenm)
          }
        }
        strFuncList.value = arrFuncList.join(', ')
      }

      refNoteBtnFlag.value = commonUtils.isNotEmpty(reportRegInfo.value.verVo.vRefNote) ? 'V' : 'M'
    }

    init()

    const openEvaluatePop = (evaluateCd) => {
      const url = tiumUrl + "/supo/ev/supo_ev_evaluate_view.do?i_sEvaluateCd=" + evaluateCd
      window.open(url, "_blank" , "toolbar=no, menubar=no, location=no, scrollbars=yes, resizable=yes")
    }

    const saveRefNote = async (flag) => {
      if(flag == 'V'){
        refNoteBtnFlag.value = 'M'
        return
      }

      if(reportRegInfo.value.verVo.vRefNote == '' || reportRegInfo.value.verVo.vRefNote == undefined){
        openAsyncAlert({ message: '심사 번호를 입력해주세요.' })
        return
      }

      const message = '심사번호를 저장하시겠습니까?'
      if (!await openAsyncConfirm({ message })) {
        return
      }

      const payload = {
        vNoteType : noteType,
        vLabNoteCd : props.detailInfo.vLabNoteCd,
        nVersion : props.detailInfo.nVersion, 
        vRefNote : reportRegInfo.value.verVo.vRefNote,
      }

      const result = await updateNoteRefNote(payload)

      if(result == 'SUCC'){
        await openAsyncAlert({ message: '정상적으로 저장되었습니다.' })
        
        refNoteBtnFlag.value = 'V'
      }
    }

    const fnTestReqList = () => {
      router.replace({ query: {vLabNoteCd: route.query.vLabNoteCd }})
      setTimeout(() => {
        context.emit('update:actionFlag', 'L')
      }, 200)
    }

    return {
      closeAsyncPopup, 
      selectFuncTestEpReportView,
      reportRegInfo,
      fnTestReqList,
      commonUtils,
      strFuncList,
      openEvaluatePop,
      saveRefNote,
      noteType,
      refNoteBtnFlag
    }
  }
}
</script>