<template>
  <div class="contents-box__inner process-area">
    <table class="ui-table__th--bg-gray">
      <colgroup>
        <col style="width:14rem">
        <col style="width:auto">
        <col style="width:14rem">
        <col style="width:auto">
      </colgroup>
      <tbody v-if="resultInfo && resultInfo.noteInfo">
        <tr>
          <th>제품/원료명</th>
          <td colspan="3">
            {{resultInfo.noteInfo.vContNm}} 
            <template v-if="resultInfo.noteInfo.nContNum > 0">
              외 {{ resultInfo.noteInfo.nContNum }}건
            </template>
          </td>
        </tr>
        <tr>
          <th>내용물 코드</th>
          <td>
            {{ resultInfo.noteInfo.vContCd }} 
            <template v-if="resultInfo.noteInfo.nContNum > 0">
              외 {{ resultInfo.noteInfo.nContNum }}건
            </template>
          </td>
          <th>연구담당자</th>
          <td>{{ resultInfo.noteInfo.vUsernm }} ({{ resultInfo.noteInfo.vUserid }} / {{ resultInfo.noteInfo.vUsrDeptnm }})</td>
        </tr>
        <tr>
          <th>브랜드</th>
          <td>{{ resultInfo.noteInfo.vBrdNm }}</td>
          <th>플랜트</th>
          <td>{{ resultInfo.noteInfo.vPlantNm }}</td>
        </tr>
      </tbody>
    </table>

    <div class="divide-line"></div>

    <template v-if="showListArea()">
      <div class="version-tab__top">
        <ApTab
          mst-id="version-tab"
          :tab-list="resultInfo.verList"
          @click="fnSelectedTabEvent"
          :default-tab="selectedTab"
          tab-id-key="vVersionKey"
          tab-nm-key="vVersionTxt"
          :tab-style="['version-tab__top__inner', 'version-tab__top__lists', 'version-tab__top__list', 'version-tab__top__link']"
        >
        </ApTab>
      </div>

      <div class="mt-15">
        <div class="f-right mb-15" v-if="resultInfo.noteInfo?.vFlagAerosol === 'Y'">
          <ap-input-check
            v-model:model="isShowAerosol"
            id="isShowAerosol"
            value="Y"
            false-value=""
            label="에어로졸 처방확정"
            @click="fnGetAerosolList()"
          >
          </ap-input-check>
        </div>
        <div class="ui-table__wrap">
          <table class="ui-table text-center ui-table__td--40" v-if="isShowAerosol !== 'Y'">
            <colgroup>
              <col style="width:5%;">
              <col style="width:11%;">
              <col style="width:10%;">
              <col width="*">
              <col style="width:15%;">
              <col style="width:16%;">
              <col style="width:10%;">
              <col style="width:10%;">
              <col style="width:8%;">
            </colgroup>
            <thead>
              <tr>
                <th>
                  <ap-input-check
                    value="Y"
                    id="vContPkAll"
                    v-model:model="vContPkAll"

                    @click="fnChkContPkCdAll"
                  >
                  </ap-input-check>
                </th>
                <th>LOT</th>
                <th>내용물코드</th>
                <th>내용물명</th>
                <th>플랜트</th>
                <th>연구담당자/담당부서</th>
                <th>결재상태</th>
                <th>효력 시작일</th>
                <th>확정해제</th>
              </tr>
            </thead>
            <tbody>
              <template v-if="lotList && lotList.length > 0">
                <tr v-for="(vo, idx) in lotList" :key="'tr_' + idx">
                  <td>
                    <ap-input-check
                      :id="'arrContPkCd_' + vo.vContPkCd + '_' + vo.vLotCd"
                      v-model:model="vo.isChecked"
                      value="Y"
                      :disabled="vo.vFlagDisabled"
                      @click="fnChkContPkCd(vo)"
                    >
                    </ap-input-check>
                  </td>
                  <td>{{ vo.vLotNm }}</td>
                  <td>{{ vo.vContCd}}</td>
                  <td class="tit">
                    <div class="tit__inner">
                      <a href="#" class="tit-link" @click.prevent="goView(vo)">{{ vo.vContNm }}</a>
                    </div>
                  </td>
                  <td>[{{ vo.vPlantCd }}] {{ vo.vPlantNm }}</td>
                  <td>{{ vo.vUsernm }} / {{ vo.vDeptNm }}</td>
                  <td>{{ vo.vApprStatusnm }}</td>
                  <td>{{ commonUtils.changeStrDatePattern(vo.vEffectDtm) }}</td>
                  <td>
                    <button
                      v-if="showDecideCancelBtn(vo) && showRegBtn()"
                      type="button"
                      class="ui-button ui-button__width--70 ui-button__height--28 ui-button__radius--2 ui-button__border--blue"
                      @click="fnConfirmFormulaDecideCancel(vo)"
                    >확정 해제</button>
                  </td>
                </tr>
              </template>
              <template v-else>
                <tr>
                  <td colspan="9">
                    <div class="no-result">{{ t('common.msg.no_data') }}</div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
          <table class="ui-table text-center ui-table__td--40" v-else>
            <colgroup>
              <col style="width:5%;">
              <col style="width:11%;">
              <col style="width:15%;">
              <col width="*">
              <col style="width:15%;">
              <col style="width:16%;">
              <col style="width:8%;">
            </colgroup>
            <thead>
              <tr>
                <th>
                  <ap-input-check
                    value="Y"
                    id="vContPkAll"
                    v-model:model="vContPkAll"

                    @click="fnChkContPkCdAll"
                  >
                  </ap-input-check>
                </th>
                <th>LOT</th>
                <th>내용물코드</th>
                <th>내용물명</th>
                <th>플랜트</th>
                <th>연구담당자/담당부서</th>
                <th>확정해제</th>
              </tr>
            </thead>
            <tbody>
              <template v-if="aerosolLotList && aerosolLotList.length > 0">
                <tr v-for="(vo, idx) in aerosolLotList" :key="'tr_' + idx">
                  <td>
                    <ap-input-check
                      :id="'arrContPkCd_' + vo.vContPkCd + '_' + vo.vLotCd"
                      v-model:model="vo.isChecked"
                      value="Y"
                      :disabled="vo.vFlagDisabled"
                      @click="fnChkContPkCd(vo)"
                    >
                    </ap-input-check>
                  </td>
                  <td>{{ vo.vLotNm }}</td>
                  <td>{{ vo.vContCd}}</td>
                  <td class="tit">
                    {{ vo.vContNm }}
                  </td>
                  <td>[{{ vo.vPlantCd }}] {{ vo.vPlantNm }}</td>
                  <td>{{ vo.vUsernm }} / {{ vo.vDeptNm }}</td>
                  <td>
                    <button
                      v-if="showAerosolDecideCancelBtn(vo) && showRegBtn()"
                      type="button"
                      class="ui-button ui-button__width--70 ui-button__height--28 ui-button__radius--2 ui-button__border--blue"
                      @click="fnFormulaDecideCancel(vo, 'Y')"
                    >확정 해제</button>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>

      <div class="page-bottom" v-if="isShowAerosol !== 'Y'">
        <div class="page-bottom__inner"
          v-for="vo in resultInfo.verList"
          :key="vo.nVersion"
        >
          <div class="ui-buttons ui-buttons__right" v-if="selectedTab === vo.vVersionKey && !vo.isDisabled">
            <button type="button" class="ui-button ui-button__bg--skyblue" v-if="showRegBtn()" @click="fnFormulaDecide()">처방확정</button>
          </div>
        </div>
      </div>
      <div class="page-bottom" v-else>
        <div class="page-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--skyblue" v-if="showAerosolDecideBtn() && showRegBtn()" @click="fnAerosolFormulaDecide()">처방확정</button>
          </div>
        </div>
      </div>
    </template>
    <ProcessPrescribeConfirmReg
      v-if="flagOpenGate02 === 'R' && gate02CheckParam"
      v-model:flag-open-gate02="flagOpenGate02"
      :check-params="gate02CheckParam"
      @callbackFunc="fnFormulaDecideInfo"
    >
    </ProcessPrescribeConfirmReg>
    <ProcessPrescribeConfirmView
      v-if="flagOpenGate02 === 'V' && gate02CheckParam"
      v-model:flag-open-gate02="flagOpenGate02"
      :check-params="gate02CheckParam"
    >
    </ProcessPrescribeConfirmView>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, inject, onMounted } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useRoute } from 'vue-router'
import { useStore } from 'vuex'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'

export default {
  name: 'ProcessPrescribeConfirmList',
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    ProcessPrescribeConfirmReg: defineAsyncComponent(() => import('@/components/process/ProcessPrescribeConfirmReg.vue')),
    ProcessPrescribeConfirmView: defineAsyncComponent(() => import('@/components/process/ProcessPrescribeConfirmView.vue')),
  },
  emits: ['callbackFunc'],
  setup (props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const route = useRoute()
    const store = useStore()
    const myInfo = store.getters.getMyInfo()
    const { openAsyncConfirm, openAsyncAlert } = useActions(['openAsyncConfirm', 'openAsyncAlert'])
    const resultInfo = ref({})
    const selectedTab = ref(null)
    const lotList = ref([])
    const vContPkAll = ref('N')
    const isShowAerosol = ref('')
    const aerosolLotList = ref([])

    const vLabNoteCd = route.query.vLabNoteCd || ''
    
    const gate02CheckParam = ref(null)
    const flagOpenGate02 = ref('N')

    const {
      noteType,
      selectAerosolDecideList,
      selectLabNoteFormulaDecideList,
      saveAerosolFormulaDecide,
    } = useProcessCommon()

    const {
      updateDecideCancel,
    } = useLabCommon()

    const fnFormulaDecide = () => {
      const nVersion = lotList.value[0].nVersion
      const checkLot = lotList.value.filter(v => v.isChecked === 'Y')

      if (checkLot.length === 0) {
        openAsyncAlert({ message: '대상을 선택해 주세요.' })
        return 
      }

      const contList = resultInfo.value.contList
      let decidedFlag = false
      checkLot.some(lot => {
        if (contList.filter(cont => cont.vContPkCd === lot.vContPkCd && cont.vFlagExistsDecide === 'Y').length > 0) {
          decidedFlag = true
          return true
        }
      })

      if (decidedFlag) {
        openAsyncAlert({ message: '이미 확정된 LOT이 있습니다.' })
        return
      }

      const arrLotCd = checkLot.map(item => commonUtils.isNotEmpty(item.vLotCd) ? item.vLotCd : '').filter( v => v !== '')
      const arrContCd = checkLot.map(item => commonUtils.isNotEmpty(item.vContCd) ? item.vContCd : '').filter( v => v !== '')
      const arrContPkCd = checkLot.map(item => commonUtils.isNotEmpty(item.vContPkCd) ? item.vContPkCd : '').filter( v => v !== '')
      const vPqcGate1ResCd = checkLot[0].vG1PqcResCd
      gate02CheckParam.value = {
        vNoteType: noteType,
        vLabNoteCd,
        arrContPkCd,
        arrContCd,
        arrLotCd,
        nVersion,
        vPqcGate1ResCd,
        lotList: checkLot,
      }

      flagOpenGate02.value = 'R'
    }

    const fnConfirmFormulaDecideCancel = async (item) => {
      let message = '<span class="txt_blue f-weight-700">[확정해제]시 Pilot 승인 단계로 돌아가며<br>'
                  + 'Lot 추가 시-Pilot 승인/전성분 승인,<br>'
                  + '기존 Lot (Pilot 승인) 사용 시-전성분 승인을 재수행해야 합니다.</span><br>'
                  + '<span class="txt_red f-weight-700">SCM등 유관부서와 논의 후 진행하시기 바랍니다.</span><br><br>'
                  + '확정해제 하시겠습니까?'
      
      if (await openAsyncConfirm({ message })) {
        fnFormulaDecideCancel(item, 'N')
      }
    }

    const fnFormulaDecideCancel = async (item, vFlagAerosol) => {
      const payload = {
        vNoteType: noteType,
        vLabNoteCd,
        vContPkCd: item.vContPkCd,
        vContCd: item.vContCd,
        vContNm: item.vContNm,
        nVersion: item.nVersion,
        vLotCd: item.vLotCd,
        vLotNm: item.vLotNm,
        vDeptCd: item.vDeptCd,
        vFlagAerosol,
      }

      const result = await updateDecideCancel(payload)
      if (result && result === 'SUCC') {
        await openAsyncAlert({ message: '확정해제 완료하였습니다.'})
        fnFormulaDecideInfo()
        context.emit('callbackFunc')
      }
    }

    const goView = (item) => {
      if (commonUtils.isEmpty(item.vApprCd)) {
        return
      }

      gate02CheckParam.value = {
        vNoteType: noteType,
        vApprCd: item.vApprCd,
        nVersion: item.nVersion,
      }

      flagOpenGate02.value = 'V'
    }

    const showRegBtn = () => {
      let isVisible = false

      if ((resultInfo.value.noteInfo && resultInfo.value.noteInfo.vUserid === myInfo.loginId) || commonUtils.checkAuth('S000000')) {
        isVisible = true
      }

      return isVisible
    }

    const showDecideCancelBtn = (item) => {
      let isVisible = false
      
      if (item.vFlagDecide === 'Y' && commonUtils.isNotEmpty(item.vApprStatus) && item.vApprStatus === 'APS010') {
        isVisible = true
      }
      return isVisible
    }

    const showAerosolDecideCancelBtn = (item) => {
      let isVisible = false

      if (item.vFlagDecide === 'Y') {
        isVisible = true
      }
      return isVisible
    }

    const fnChkContPkCdAll = (value) => {
      const targetList = isShowAerosol.value !== 'Y' ? lotList.value : aerosolLotList.value
      if (value === 'Y') {
        targetList.forEach(item => {
          if (!item.vFlagDisabled) {
            item.isChecked = 'Y'
            if (document.querySelector('#arrContPkCd_' + item.vContPkCd + '_' + item.vLotCd)) {
              document.querySelector('#arrContPkCd_' + item.vContPkCd + '_' + item.vLotCd).checked = true
            }
          }
        })
      } else {
        targetList.forEach(item => {
          item.isChecked = ''
          if (document.querySelector('#arrContPkCd_' + item.vContPkCd + '_' + item.vLotCd)) {
            document.querySelector('#arrContPkCd_' + item.vContPkCd + '_' + item.vLotCd).checked = false
          }
        })
      }
    }

    const fnChkContPkCd = (cont) => {
      const targetList = isShowAerosol.value !== 'Y' ? lotList.value : aerosolLotList.value
      const checkList = targetList.filter(lot => lot.vContCd === cont.vContCd && lot.isChecked === 'Y')

      if (checkList && checkList.length > 1) {
        openAsyncAlert({ message : '동일 내용물 LOT는 1개만 선택 가능합니다.' })
        cont.isChecked = ''
        if (document.querySelector('#arrContPkCd_' + cont.vContPkCd + '_' + cont.vLotCd)) {
          document.querySelector('#arrContPkCd_' + cont.vContPkCd + '_' + cont.vLotCd).checked = false
        }

        return
      }

      if (lotList.value.filter(item => item.isChecked === 'Y').length === lotList.value.length) {
        vContPkAll.value = 'Y'
      } else {
        vContPkAll.value = 'N'
      }
    }

    const fnSelectedTabEvent = async (item) => {
      if (!item) {
        item = resultInfo.value.verList.filter(ver => ver.vVersionKey === selectedTab.value)[0]
      }
  
      selectedTab.value = item.vVersionKey
      if (isShowAerosol.value !== 'Y') {
        if (resultInfo.value.list && resultInfo.value.list.length > 0) {
          const contList = resultInfo.value.contList
          if (contList && contList.length > 0) {
            contList.forEach(cont => {
              resultInfo.value.list.forEach(lot => {
                if (cont.vContCd === lot.vContCd && cont.vFlagExistsDecide === 'Y') {
                  lot.vFlagDisabled = true
                }
              })
            })
  
            const apprList = resultInfo.value.list.map(
              lot => commonUtils.isNotEmpty(lot.vApprCd) && commonUtils.isNotEmpty(lot.vApprStatus) && lot.vApprStatus !== 'APS020' ? lot.vContCd : ''
            ).filter(cont => cont !== '')
  
            resultInfo.value.list.forEach(lot => {
              if (apprList && apprList.length > 0 && apprList.indexOf(lot.vContCd) > -1) {
                lot.vFlagDisabled = true
              }
  
              if (commonUtils.isNotEmpty(lot.vApprCd) && commonUtils.isNotEmpty(lot.vApprStatus) && lot.vApprStatus !== 'APS020') {
                lot.vFlagDisabled = true
              }
            })
            
            const verLotList = resultInfo.value.list.filter(lot => lot.nVersion === item.nVersion)
            lotList.value = verLotList
  
            if (lotList.value.length === lotList.value.filter(lot => lot.vFlagDisabled).length) {
              item.isDisabled = true
            }
          }
        }
      } else {
        await fnGetAerosolList()
      }

      vContPkAll.value = 'N'
      fnChkContPkCdAll('N')

      gate02CheckParam.value = null
      flagOpenGate02.value = 'N'
    }

    const fnFormulaDecideInfo = async (defaultVer) => {
      const result = await selectLabNoteFormulaDecideList({ vLabNoteCd })

      if (result) {
        resultInfo.value = { ...result }

        if (resultInfo.value.verList && resultInfo.value.verList.length > 0) {
          const noteInfo = resultInfo.value.noteInfo

          const formulaVer = route.query.nFormulaVer
          if (formulaVer) {
            defaultVer = formulaVer
          } else if (!defaultVer) {
            defaultVer = noteInfo.nMaxVersion
          }

          if (noteInfo) {
            const defaultTabInfo = resultInfo.value.verList.filter(ver => ver.nVersion === Number(defaultVer))[0]
            fnSelectedTabEvent(defaultTabInfo)

            if (noteInfo.vFlagAerosol === 'Y' && route.query.vFlagAerosol === 'Y') {
              isShowAerosol.value = 'Y'
              fnGetAerosolList()
            }
          }
        }
      }
    }

    const showListArea = () => {
      let isVisible = false

      if (flagOpenGate02.value !== 'V') {
        isVisible = true
      }

      return isVisible
    }

    const fnGetAerosolList = async () => {
      const result = await selectAerosolDecideList({ vLabNoteCd })

      if (result && result.length > 0) {
        const decideList = result.map(
          lot => lot.vFlagDecide === 'Y' ? lot.vContCd : ''
        ).filter(cont => cont !== '')

        result.forEach(lot => {
          if (decideList && decideList.length > 0 && decideList.indexOf(lot.vContCd) > -1) {
            lot.vFlagDisabled = true
          }
        })

        aerosolLotList.value = result.filter(ver => ver.vVersionKey === selectedTab.value)
        const lotCd = route.query.vFormulaLotCd
        if (lotCd && aerosolLotList.value && aerosolLotList.value.length > 0) {
          aerosolLotList.value.some(lot => {
            if (lot.vLotCd === lotCd) {
              lot.isChecked = 'Y'
              if (document.querySelector('#arrContPkCd_' + lot.vContPkCd + '_' + lot.vLotCd)) {
                document.querySelector('#arrContPkCd_' + lot.vContPkCd + '_' + lot.vLotCd).checked = false
              }
              return true
            }
          })
        }
      }
    }

    const showAerosolDecideBtn = () => {
      let isVisible = true

      if (aerosolLotList.value && aerosolLotList.value.length > 0) {
        const disabledList = aerosolLotList.value.filter(lot => lot.vFlagDisabled === 'Y')

        if (disabledList && aerosolLotList.value.length === disabledList.length) {
          isVisible = false
        }
      }

      return isVisible
    }

    const fnAerosolFormulaDecide = async () => {
      const checkLot = aerosolLotList.value.filter(v => v.isChecked === 'Y')

      if (checkLot.length === 0) {
        openAsyncAlert({ message: '대상을 선택해 주세요.' })
        return 
      }

      const payload = {
        vLabNoteCd,
        lotList: checkLot
      }

      const result = await saveAerosolFormulaDecide(payload)

      if (result) {
        await openAsyncAlert({ message: '확정 완료하였습니다.'})
        fnGetAerosolList()
      }
    }

    const init = async () => {
      const vApprCd = route.query.vApprCd
      if (vApprCd) {
        const nVersion = route.query.nVersion
        await fnFormulaDecideInfo(nVersion)
  
        gate02CheckParam.value = {
          vNoteType: noteType,
          vApprCd
        }
  
        flagOpenGate02.value = 'V'
      } else {
        fnFormulaDecideInfo()
      }
    }
    
    init()


    return {
      t,
      commonUtils,
      resultInfo,
      noteType,
      isShowAerosol,
      aerosolLotList,
      gate02CheckParam,
      flagOpenGate02,
      selectedTab,
      lotList,
      fnSelectedTabEvent,
      fnFormulaDecideInfo,
      fnFormulaDecide,
      fnConfirmFormulaDecideCancel,
      fnFormulaDecideCancel,
      showRegBtn,
      showDecideCancelBtn,
      showAerosolDecideCancelBtn,
      goView,
      fnChkContPkCdAll,
      fnChkContPkCd,
      fnGetAerosolList,
      fnAerosolFormulaDecide,
      showAerosolDecideBtn,
      showListArea,
      vContPkAll,
    }
  }
}
</script>