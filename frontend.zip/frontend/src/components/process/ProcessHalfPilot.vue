<template>
  <ProcessHalfPilotList
    v-if="vActionFlag === 'L'"
    v-model:vActionFlag="vActionFlag"
    v-model:detail-info="detailInfo"
  >
  </ProcessHalfPilotList>
  <ProcessHalfPilotRegister
    v-if="vActionFlag === 'R'"
    v-model:vActionFlag="vActionFlag"
    @callbackFunc="setProgressInfo"
  >
  </ProcessHalfPilotRegister>
  <ProcessHalfPilotView
    v-if="vActionFlag === 'V'"
    v-model:vActionFlag="vActionFlag"
    v-model:detail-info="detailInfo"
  >
  </ProcessHalfPilotView>

</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'
import { useRoute } from 'vue-router'

export default {
  name: 'ProcessHalfPilot',
  components: {
    ProcessHalfPilotList: defineAsyncComponent(() => import('@/components/process/ProcessHalfPilotList.vue')),
    ProcessHalfPilotRegister: defineAsyncComponent(() => import('@/components/process/ProcessHalfPilotRegister.vue')),
    ProcessHalfPilotView: defineAsyncComponent(() => import('@/components/process/ProcessHalfPilotView.vue')),
  },
  setup (props, context) {
    const route = useRoute()
    const vActionFlag = ref('L')
    const detailInfo = ref({})
    const commonUtils = inject('commonUtils')

    const setProgressInfo = () => {
      context.emit('callbackFunc')
    }

    const init = () => {
      const version = route.query.nFormulaVer
      const lotCd = route.query.vFormulaLotCd

      if (commonUtils.isNotEmpty(version) && commonUtils.isNotEmpty(lotCd)) {
        vActionFlag.value = 'R'
      }
    }

    init()

    return {
      vActionFlag,
      detailInfo,
      setProgressInfo
    }
  }
}
</script>