<template>
  <div class="contents-box__inner">
    <div class="mb-15 mt-15">
      <button type="button" class="f-right ui-button ui-button__bg--gray" @click="goList()">목록</button>
    </div>
    <div class="ui-table__wrap">
      <table class="ui-table text-center ui-table__td--40">
        <tbody>
          <tr class="tr-contents">
            <td class="inside-td inside-td__p30">
              <div class="inside-td__item">
                <div class="inside-td__item--title">BOM 정보</div>
                <div class="inside-td__table--wrap">
                  <div class="code-contcd__wrap">
                    <ul class="ui-list code-contcd__list" v-if="info.lotList && info.lotList.length > 0">
                      <li class="code-contcd__item"
                        v-for="(vo, index) in info.lotList"
                        :key="'contcd_' + index"
                      >
                        <button
                          type="button"
                          class="code-contcd__button code-contcd__button--code"
                          :class="selectLotCd === vo.vLotCd ? 'is-click' : ''"
                          @click="fnLotBomList(vo)"
                        >
                          {{ vo.vContCd }}
                        </button>
                      </li>
                    </ul>
                  </div>
                  <table
                    class="ui-table__reset inside-td__table inside-td__table--borderR-none mt-20"
                    v-if="info.bomList && info.bomList.length > 0"
                  >
                    <colgroup>
                      <col style="width:15%"> 
                      <col style="width:20%"> 
                      <col style="width:auto"> 
                      <col style="width:10%"> 
                    </colgroup>
                    <thead>
                      <tr>
                        <th>NO</th>
                        <th>원료코드</th>
                        <th>원료명</th>
                        <th>
                          <span class="txt_gray f-weight-700 f-size-12">{{ info.bomList[0].vVersionTxt}} - {{ info.bomList[0].vLotNm}}</span><br>
                          함량
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-for="(vo, idx) in info.bomList" :key="'bom_' + idx">
                        <td>{{ idx + 1 }}</td>
                        <td>
                          <template v-if="commonUtils.isEmpty(vo.vMateCd) && vo.vMateDbTypeCd === 'SUP'">
                            {{ vo.vMateTempCd }}
                          </template>
                          <template v-else>
                            {{ vo.vMateCd }}
                          </template>
                        </td>
                        <td class="t-left">
                          <MateName
                            :mate-info="vo"
                          >
                          </MateName>
                        </td>
                        <td class="t-right">{{ vo.nRate }}</td>
                      </tr>
                      <tr class="inside-td__table--total">
                        <td class="inside-td__total--text">합계</td>
                        <td></td>
                        <td></td>
                        <td class="inside-td__total--num t-right">{{ info.bomList[0].nRateSum }}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              <!-- 자가체크 -->
              <ProcessPQCGateCheckInfo
                v-if="info.pqcList"
                :pqc-list="info.pqcList"
                :note-info="info.noteInfo"
                :version-info="info.versionPqcInfo"
                :tr-map="info.trMap"
              >
              </ProcessPQCGateCheckInfo>

              <div class="inside-td__item" v-if="info.pqcVO">
                <div class="inside-td__item--title">준수율</div>
                <div class="inside-td__item--wrap">
                  <table class="ui-table__reset inside-td__table">
                    <colgroup>
                      <col style="width:21rem"> 
                      <col style="width:auto"> 
                    </colgroup>
                    <tbody>
                      <tr>
                        <th>준수율</th>
                        <td class="t-left">
                          {{ info.pqcVO.nObeyPer }} %
                        </td>
                      </tr>
                      <tr>
                        <th>연구원 의견</th>
                        <td class="t-left" v-html="commonUtils.removeHTMLChangeBr(info.pqcVO.vComment)"></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              <div class="inside-td__item" v-if="info.shelfLifeList && info.shelfLifeList.length > 0">
                <div class="inside-td__item--title">SHELF LIFE</div>
                <div class="inside-td__item--wrap">
                  <table class="ui-table__reset inside-td__table">
                    <colgroup>
                      <col style="width:21rem"> 
                      <col style="width:auto"> 
                    </colgroup>
                    <tbody>
                      <tr>
                        <th>사용기한</th>
                        <td class="t-left">
                          <template
                            v-for="(vo, idx) in info.shelfLifeList"
                            :key="'shelf_life_' + idx"
                          >
                            {{ vo.vContCd }} ({{ vo.vShelfLife }}M)<br>
                          </template>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <div
    v-if="info.pqcVO"
    class="contents-box__inner contents-box__inner--border min-height__unset"
  >
    <ApprovalView 
      :appr-cd="info.pqcVO.vApprCd"
      :appr-class="'LAB001_' + detailInfo.vNoteType"
      ref="appr"
      v-model:appr-mst-info="apprMstInfo"
      v-model:appr-user-list="apprUserList"
      @callbackFunc="fnApprProc"
    >
    </ApprovalView>
  </div>
  <div
    v-if="info.pqcVO"
    class="contents-box__inner contents-box__inner--border min-height__unset"
  >
    <ReferenceView
      :record-id="info.pqcVO.vApprCd"
    >
    </ReferenceView>
  </div>

  <div class="page-bottom">
    <div class="page-bottom__inner">
      <div class="ui-buttons ui-buttons__left">
        <button type="button" class="ui-button ui-button__bg--blue" v-if="info?.flagFreePass === 'Y'" @click="fnBomSend()">BOM SAP 전송</button>
      </div>
      <div class="ui-buttons ui-buttons__right">
        <button type="button" class="ui-button ui-button__border--gray" v-if="showOpinionPopBtn()" @click="fnViewApprOpinion()">의견보기</button>
        <template v-if="showApprovalBtn('USR010')">
          <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnAppr('ACCEPT')">승인</button>
          <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnAppr('REJECT')">반려</button>
        </template>
        <template v-if="showApprovalBtn('USR020')">
          <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnMutual('ACCEPT')">합의</button>
          <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnMutual('REJECT')">거부</button>
        </template>
        <button type="button" class="ui-button ui-button__bg--gray" @click="goList()">목록</button>
      </div>
    </div>
  </div>
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @selectFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'
import { useRouter } from 'vue-router'
import { useStore } from 'vuex'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useHalfProcessCommon } from '@/compositions/labcommon/useHalfProcessCommon'
import { useApproval } from '@/compositions/approval/useApproval'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'ProcessHalfPilotView',
  props: {
    vActionFlag: {
      type: String,
      default: 'V'
    },
    detailInfo: {
      type: Object,
      default: () => {
        return {
          vLabNoteCd: '',
          vContPkCd: '',
          nVersion: '',
          vLotCd: '',
          vApprCd: '',
          vFlagApprBom: '',
          vNoteType: '',
        }
      }
    }
  },
  components: {
    ApprovalView: defineAsyncComponent(() => import('@/components/comm/ApprovalView.vue')),
    ReferenceView: defineAsyncComponent(() => import('@/components/comm/ReferenceView.vue')),
    MateName: defineAsyncComponent(() => import('@/components/labcommon/MateName.vue')),
    ProcessPQCGateCheckInfo: defineAsyncComponent(() => import('@/components/process/ProcessPQCGateCheckInfo.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    OpinionViewPop: defineAsyncComponent(() => import('@/components/approval/popup/OpinionViewPop.vue')),
  },
  emits: ['update:vActionFlag'],
  setup (props, context) {
    const commonUtils = inject('commonUtils')
    const store = useStore()
    const router = useRouter()
    const myInfo = store.getters.getMyInfo()
    const info = ref({})
    const appr = ref(null)
    const selectLotCd = ref('')
    const { openAsyncConfirm, openAsyncAlert } = useActions(['openAsyncConfirm', 'openAsyncAlert'])
    const apprMstInfo = ref(null)
    const apprUserList = ref(null)
    let apprProcStatus = ''
    let apprProcSubStatus = ''

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
    } = useLabCommon()

    const {
      selectLabNotePilotReqInfo,
      selectLabNoteBomMateRateInfo,
      noteType,
      noteTypeNm,
      sendBomFreePass,
      checkValidationPilot
    } = useHalfProcessCommon()

    const {
      updateBomApproval,
    } = useApproval()

    const fnLotBomList = async (item) => {
      if (selectLotCd.value !== item.vLotCd) {
        const payload = {
          ...props.detailInfo,
          ...{vLotCd : item.vLotCd, vContPkCd: item.vContPkCd}
        }

        const result = await selectLabNoteBomMateRateInfo(payload)

        if (result) {
          info.value.bomList = [ ...result ]
        }
      }

      selectLotCd.value = item.vLotCd
    }

    const fnBomSend = async () => {
      const lotList = info.value.lotList.filter(item => commonUtils.isNotEmpty(item.vLotCd))

      const payload = {
        lotList,
        nVersion: props.detailInfo.nVersion,
        vLabNoteCd: info.value.noteInfo.vLabNoteCd,
      }
      const validationMsg = await checkValidationPilot(payload)

      if (validationMsg === 'SUCC') {
        let message = 'BOM 승인 결재라인의 부재시 또는 긴급 상황에서만 해당 기능을 사용하셔야 합니다.<br>'
                  + '그리고 BOM 처방이 확실한 경우 (결재 시 반려 되지 않는 경우)에만 사용하셔야 합니다. <br>'
                  + 'BOM을 전송하시겠습니까?'

        if (!await openAsyncConfirm({ message })) {
          return
        }

        const result = await sendBomFreePass(payload)
        if (result && result === 'SUCC') {
          await openAsyncAlert({ message: '전송되었습니다.' })
          goList()
        }
      } else {
        openAsyncAlert({ message: validationMsg })
      }
    }

    const fnAppr = (flag) => {
      if (appr.value) {
        if (flag === 'ACCEPT') {
          apprProcStatus = 'APS010'
        } else if (flag === 'REJECT') {
          apprProcStatus = 'APS020'
        }

        appr.value.fnApprovalOpinionPop()
      }
    }

    const fnMutual = (flag) => {
      apprProcStatus = 'APS050'
      if (appr.value) {
        if (flag === 'ACCEPT') {
          apprProcSubStatus = 'AGR010'
        } else {
          apprProcSubStatus = 'AGR030'
        }

        appr.value.fnApprovalOpinionPop()
      }
    }

    const fnApprProc = async (draftOpinion) => {
      store.dispatch('setLoading', true)
      const lotCdList = info.value.lotList.map(item => commonUtils.isNotEmpty(item.vLotCd) ? item.vLotCd : '').filter( v => v !== '')
      const contPkCdList = info.value.lotList.map(item => commonUtils.isNotEmpty(item.vContPkCd) ? item.vContPkCd : '').filter( v => v !== '')

      const payload = {
        noteTypeNm,
        lotCdList,
        contPkCdList,
        nVersion: props.detailInfo.nVersion,
        vLabNoteCd: info.value.noteInfo.vLabNoteCd,
        ...apprMstInfo.value,
        ...{
          vApprStatus: apprProcStatus,
          vApprSubStatus: apprProcSubStatus,
          vApprOpinion: draftOpinion.value
        },
      }

      const result = await updateBomApproval(payload)
      if (result) {
        router.push({ path: '/approval/list' })
      } else {
        store.dispatch('setLoading', false)
      }
    }

    const fnViewApprOpinion = () => {
      popParams.value = { vApprCd: info.value.pqcVO.vApprCd }

      fnOpenPopup('OpinionViewPop')
    }

    const showApprovalBtn = (apprUserType) => {
      let isVisible = false

      if (apprMstInfo.value &&
          apprMstInfo.value.vApprStatus === 'APS030' &&
          apprUserList.value?.length > 0) {
        const curApprUser = apprUserList.value.filter(v => v.nCurApprseq === apprMstInfo.value.nCurApprseq)

        if (curApprUser && curApprUser.length > 0 &&
            (curApprUser[0].vApprUserid === myInfo.loginId || commonUtils.checkAuth('S000000')) &&
            curApprUser[0].vApprUserType === apprUserType) {
          isVisible = true
        }
      }

      return isVisible
    }

    const showOpinionPopBtn = () => {
      let isVisible = false
      const userList = apprUserList.value && apprUserList.value.length > 0 ? apprUserList.value : []
      if (apprMstInfo.value && 
            (apprMstInfo.value.vDraftUserid === myInfo.loginId ||
            userList.length > 0 && userList.filter(v => v.vApprUserid === myInfo.loginId).length > 0 ||
            commonUtils.checkAuth('S000000'))
        ) {
        isVisible = true
      }

      return isVisible
    }

    const goList = () => {
      router.replace({ query: {vLabNoteCd: info.value.noteInfo.vLabNoteCd} })
      setTimeout(() => {
        context.emit('update:vActionFlag', 'L')
      }, 200)
    }

    const init = async () => {
      const result = await selectLabNotePilotReqInfo(props.detailInfo)
      if (result) {
        if (result.lotList && result.lotList.length > 0) {
          selectLotCd.value = props.detailInfo.vLotCd

          const lotInfo = result.lotList[0]
          result.vLotNm = lotInfo.vLotNm + (result.lotList.length > 1 ? (' 외 ' + (result.lotList.length - 1) + '건') : '')
        }

        info.value = { ...result }
      }
    }

    init()

    return {
      commonUtils,
      info,
      appr,
      selectLotCd,
      noteType,
      popupContent,
      popParams,
      popSelectFunc,
      apprMstInfo,
      apprUserList,
      fnLotBomList,
      fnBomSend,
      goList,
      fnAppr,
      fnMutual,
      fnApprProc,
      fnViewApprOpinion,
      showOpinionPopBtn,
      showApprovalBtn,
    }
  }
}
</script>

<style scoped>
  .contents-box__with--tab .contents-box__inner--border { margin-top: 1rem; }
</style>