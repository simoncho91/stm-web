<template>
  <div class="contents-box__inner">
    <table class="ui-table__th--bg-gray">
      <colgroup>
        <col style="width:14rem">
        <col style="width:auto">
        <col style="width:14rem">
        <col style="width:auto">
      </colgroup>
      <tbody>
        <tr>
          <th>제품/원료명</th>
          <td colspan="3">
            {{ noteInfo.vContNm }}
            <template v-if="Number(noteInfo.nContNum) > 0">
              외 {{ noteInfo.nContNum }}건
            </template>
          </td>
        </tr>
        <tr>
          <th>내용물 코드</th>
          <td>
            {{ noteInfo.vContCd }}
            <template v-if="Number(noteInfo.nContNum) > 0">
              외 {{ noteInfo.nContNum }}건
            </template>
          </td>
          <th>연구담당자</th>
          <td>
            {{ noteInfo.vUsernm }} ({{ noteInfo.vUserid }} / {{ noteInfo.vUsrDeptnm }})
          </td>
        </tr>
        <tr>
          <th>브랜드</th>
          <td>{{ noteInfo.vBrdNm }}</td>
          <th>Plant</th>
          <td>{{ noteInfo.vPlantNm }}</td>
        </tr>
      </tbody>
    </table>

    <div class="divide-line"></div>

    <div class="version-tab__top">
      <ApTab
        mst-id="version-tab"
        :tab-list="verList"
        tab-nm-key="vVersionTxt"
        tab-id-key="vVersionKey"
        @click="getSelectedTabEvent"
        :default-tab="defaultTab"
        :tab-style="['version-tab__top__inner', 'version-tab__top__lists', 'version-tab__top__list', 'version-tab__top__link']"
      >
      </ApTab>
    </div>

    <div class="ui-table__wrap">
      <table class="ui-table text-center ui-table__td--40 ui-table__thead-multi">
        <colgroup>
          <col style="width:6rem;">
          <col style="width:15%;">
          <col style="width:auto;">
          <col style="width:15%;">
          <col style="width:15%;">
        </colgroup>
        <thead>
          <th>
            <ap-input-check
              value="Y"
              id="vContPkAll"
              v-model:value="vContPkAll"
              @click="fnContCheckAllEvent"
            >
            </ap-input-check>
          </th>
          <th>내용물코드</th>
          <th>내용물명</th>
          <th>Plant</th>
          <th>Pilot LOT</th>
        </thead>
        <tbody v-if="contList && contList.length > 0">
          <tr v-for="(vo, idx) in contList" :key="'cont_list_' + idx">
            <td>
              <ap-input-check
                  v-model:model="vo.isChecked"
                  value="Y"
                  :id="'cont_list_' + idx"
                  :disabled="!vo.lotList || vo.lotList.length === 0"
                  @click="fnContCheckEvent"
                >
                </ap-input-check>
            </td>
            <td>{{ vo.vContCd }}</td>
            <td>
              <div class="form-flex">
              <span class="form-flex__cell--5">{{ vo.vContNm }}</span>
              <p class="p_caution_red form-flex__cell--5" v-if="showDecideInfo(vo)">※ 확정된 LOT가 존재합니다.</p>
              <p class="p_caution_red form-flex__cell--5" v-if="showApprLotInfo(vo)">※ 이미 결재 중인 LOT 입니다.</p>
              </div>
            </td>
            <td>
              <ap-selectbox
                v-model:value="vo.vPlantCd"
                :options="vo.plantList"
                code-key="vPlantCd"
                code-nm-key="vPlantNm"
                input-class="ui-select__width--full"
              >
              </ap-selectbox>
            </td>
            <td>
              <ap-selectbox
                v-model:value="vo.vLotCd"
                :options="vo.lotList"
                code-key="vLotCd"
                code-nm-key="vLotNm"
                input-class="ui-select__width--full"
                :disabled="!vo.lotList || vo.lotList.length === 0"
                @change="changeLotEvent(vo)"
              >
              </ap-selectbox>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="page-bottom mb-15">
      <div class="page-bottom__inner">
        <div class="ui-buttons ui-buttons__right">
          <button type="button" class="ui-button ui-button__bg--skyblue" @click="goGate01Appr()">선택</button>
          <button type="button" class="ui-button ui-button__bg--gray" @click="goList()">목록</button>
        </div>
      </div>
    </div>

    <ProcessHalfPilotGate01Reg
      v-if="isGate01Open === 'Y'"
      :gate-01-appr-params="gate01ApprParams"
      :note-info="noteInfo"
      @go-list="goList"
    >
    </ProcessHalfPilotGate01Reg>
  </div>
</template>

<script>
import { defineAsyncComponent, reactive, toRefs, ref, inject } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useHalfProcessCommon } from '@/compositions/labcommon/useHalfProcessCommon'
import { useRoute } from 'vue-router'

export default {
  name: 'ProcessHalfPilotRegister',
  props: {
    vActionFlag: {
      type: String,
      default: 'R'
    },
  },
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    ProcessHalfPilotGate01Reg: defineAsyncComponent(() => import('@/components/process/ProcessHalfPilotGate01Reg.vue')),
  },
  emits: ['update:vActionFlag'],
  setup (props, context) {
    const route = useRoute()
    const vLabNoteCd = route.query.vLabNoteCd || ''
    const commonUtils = inject('commonUtils')
    const vContPkAll = ref('')
    const isGate01Open = ref('')
    const gate01ApprParams = ref(null)
    let selectedVer = ''
    const defaultTab = ref(null)
    const { openAsyncAlert } = useActions(['openAsyncAlert'])
    const version = route.query.nFormulaVer
    const lotCd = route.query.vFormulaLotCd

    const {
      selectLabNotePilotRegInitInfo,
      selectLabNotePilotRegVersionLotList,
      noteType,
    } = useHalfProcessCommon()

    const info = reactive({
      noteInfo: {},
      verList: [],
      contList: [],
      userList: [],
    })

    const fnContCheckEvent = () => {
      if (info.contList.filter(item => item.isChecked === 'Y').length === info.contList.length) {
        vContPkAll.value = 'Y'
        document.querySelector('#vContPkAll').checked = true
      } else {
        vContPkAll.value = ''
        document.querySelector('#vContPkAll').checked = false
      }
    }

    const fnContCheckAllEvent = (value) => {
      if (value === 'Y') {
        info.contList.forEach(item => {
          item.isChecked = 'Y'
        })
      } else {
        info.contList.forEach(item => {
          item.isChecked = 'N'
        })
      }
    }

    const getSelectedTabEvent = async (item) => {
      const payload = {
        vLabNoteCd,
        nVersion: item.nVersion
      }

      selectedVer = item.nVersion

      const result = await selectLabNotePilotRegVersionLotList(payload)
      fnContCheckAllEvent('N')
      fnContCheckEvent()
      info.contList.forEach(item => {
        item.vLotCd = ''
        if (result && result[item.vContPkCd]) {
          item.lotList = [ ...result[item.vContPkCd] ]

          if (commonUtils.isNotEmpty(version) && commonUtils.isNotEmpty(lotCd)) {
            const lotInfo = item.lotList.filter(lot => lot.vLotCd === lotCd)
            if (lotInfo.length > 0 && !showDecideInfo(item) && !showApprLotInfo(item)) {
              item.vLotCd = lotCd
              changeLotEvent(item)
              goGate01Appr()
            }
          }
        } else {
          item.lotList = []
        }
      })
    }

    const goList = () => {
      context.emit('update:vActionFlag', 'L')
    }

    const goGate01Appr = () => {
      const checkList = info.contList.filter(item => item.isChecked === 'Y')
      const paramsLotList = []
      const chkLen = checkList.length

      if (chkLen === 0) {
        openAsyncAlert({ message: '대상을 선택해 주세요.' })
        return
      }

      let isLotNull = false
      let isAppr = false
      checkList.forEach(item => {
        if (commonUtils.isEmpty(item.vLotCd)) {
          isLotNull = true
        }

        if (showApprLotInfo(item)) {
          isAppr = true
        }

        const lotInfo = {
          vCodeType: item.vCodeType,
          vContCd: item.vContCd,
          vContNm: item.vContNm,
          vContPkCd: item.vContPkCd,
          vFlagExistsDecide: item.vFlagExistsDecide,
          vFlagRepresent: item.vFlagRepresent,
          vLabNoteCd: item.vLabNoteCd,
          vLotCd: item.vLotCd,
          vLotNm: item.vLotNm,
          vPlantCd: item.vPlantCd,
          vPlantNm: item.vPlantNm,
          vSelectLotCd: item.vSelectLotCd,
          vUserid: item.vUserid
        }

        paramsLotList.push(lotInfo)
      })

      if (isLotNull) {
        openAsyncAlert({ message: 'LOT가 선택되지 않았습니다.' })
        return
      }

      if (isAppr) {
        openAsyncAlert({ message: '결재중이거나 결재된 LOT가 존재합니다.' })
        return
      }

      gate01ApprParams.value = {
        vLabNoteCd,
        lotList: paramsLotList,
        nVersion: selectedVer,
        userList: info.userList || []
      }

      setTimeout(() => {
        isGate01Open.value = 'Y'
      }, 100)
    }

    const showDecideInfo = (item) => {
      let isVisible = false
      
      if (commonUtils.isNotEmpty(item.vPlantCd)) {
        const plantInfo = item.plantList.filter(vo => vo.vPlantCd === item.vPlantCd)[0]

        if (plantInfo && plantInfo.vFlagExistsDecide === 'Y') {
          isVisible = true
        }
      } else {
        const plantInfo = item.plantList.filter(vo => vo.vFlagExistsDecide === 'Y')

        if (plantInfo && plantInfo.length > 0) {
          isVisible = true
        } 
      }

      return isVisible
    }

    const showApprLotInfo = (item) => {
      let isVisible = false

      if (commonUtils.isNotEmpty(item.vLotCd)) {
        const lotInfo = item.lotList.filter(vo => vo.vLotCd === item.vLotCd)[0]
        if (lotInfo && commonUtils.isNotEmpty(lotInfo.vApprCd)) {
          isVisible = true
        }
      }

      return isVisible  
    }

    const changeLotEvent = (item) => {
      if (commonUtils.isNotEmpty(item.vLotCd)) {
        const lotInfo = item.lotList.filter(vo => vo.vLotCd === item.vLotCd)[0]

        if (lotInfo && commonUtils.isNotEmpty(lotInfo.vApprCd)) {
          item.isChecked = 'N'
          item.vSelectLotCd = ''
          item.vLotNm = ''
        } else {
          item.isChecked = 'Y'
          item.vSelectLotCd = item.vLotCd
          item.vLotNm = lotInfo.vLotNm
        }
      }

      isGate01Open.value = 'N'

      fnContCheckEvent()
    }

    const init = async () => {
      const result = await selectLabNotePilotRegInitInfo({ vLabNoteCd })
      if (result && result.contList && result.contList.length > 0) {
        if (result.plantMap) {
          result.contList.forEach(item => {
            if (result.plantMap[item.vContPkCd]) {
              item.plantList = [ ...result.plantMap[item.vContPkCd] ]
            }
          })
        }

        if (result.lotMap) {
          result.contList.forEach(item => {
            if (result.lotMap[item.vContPkCd]) {
              item.lotList = [ ...result.lotMap[item.vContPkCd] ]
            }
          })
        }
      }

      info.noteInfo = result.noteInfo
      info.verList = result.verList
      info.contList = result.contList
      info.userList = result.userList

      if (info.verList) {
        let defaultVerInfo = null
        if (commonUtils.isNotEmpty(version) && commonUtils.isNotEmpty(lotCd)) {
          defaultVerInfo = info.verList.filter(vo => vo.nVersion === Number(version))[0]
        } else {
          defaultVerInfo = info.verList.filter(vo => vo.nVersion === info.noteInfo.nMaxVersion)[0]
        }

        if (defaultVerInfo !== null) {
          selectedVer = defaultVerInfo.nVersion
          defaultTab.value = defaultVerInfo.vVersionKey
        }

        getSelectedTabEvent(defaultVerInfo)
      }
    }

    init()

    return {
      ...toRefs(info),
      vContPkAll,
      defaultTab,
      isGate01Open,
      noteType,
      gate01ApprParams,
      getSelectedTabEvent,
      fnContCheckEvent,
      fnContCheckAllEvent,
      changeLotEvent,
      goGate01Appr,
      goList,
      showDecideInfo,
      showApprLotInfo,
    }
  }
}
</script>