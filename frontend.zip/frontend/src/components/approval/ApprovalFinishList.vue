<template>
  <div>
    <div>
      <section class="search-bar">
        <h2 class="for-a11y">검색</h2>
  
        <div class="search-bar__left">
          <div class="search-bar__row">
            <dl class="search-bar__item">
              <dt class="search-bar__key">기안일</dt>
              <dd class="search-bar__val">
                <ap-date-picker-range
                  v-model:startDt="searchParams.vDraftSearchStartDt"
                  v-model:endDt="searchParams.vDraftSearchEndDt"
                  :read-only="false"
                  :resetable="true"
                />
              </dd>
            </dl>
            <!-- <dl class="search-bar__item">
              <dt class="search-bar__key">종류</dt>
              <dd class="search-bar__val">
                <div class="ui-select-block">
                  <ap-selectbox
                    v-model:value="searchParams.vApprClass"
                    :options="codeGroupMaps['SC0021']"
                  />
                </div>
              </dd>
            </dl> -->
            <dl class="search-bar__item">
              <dt class="search-bar__key">검색</dt>
              <dd class="search-bar__val">
                <div class="search-form">
                  <div class="search-form__inner">
                    <ap-input
                      :inputClass="'ui-input__width--258'"
                      :placeholder="'제목 or 기안자'"
                      v-model:value="searchParams.vKeyword"
                      @keypressEnter="fnSearchApprovalFinishList(1)"
                    />
                    <button
                      type="button"
                      class="button-search"
                      @click="fnSearchApprovalFinishList(1)"
                    >검색</button>
                    <button
                      type="button"
                      class="ui-button ui-button__bg--lightgray font-weight__500 ml-5"
                      @click="resetSearchFilter"
                    >검색 초기화</button>
                  </div>
                </div>
              </dd>
            </dl>
          </div>
  
          <!-- <div class="search-bar__row">
            
          </div> -->
        </div>
      </section>
  
      <div class="contents-tab__body--item">
        <div class="ui-table__wrap">
          <table class="ui-table text-center ui-table__td--40">
            <colgroup>
              <!-- 2023.03.22 : mod : 수치 변경 -->
              <col style="width:9rem;">
              <col style="width:auto;">
              <col style="width:8%;">
              <col style="width:8%;">
              <col style="width:8%;">
              <col style="width:7%;">
              <col style="width:14%;">
              <col style="width:6%;">
            </colgroup>
            <thead>
              <tr>
                <th>NO</th>
                <th>제목</th>
                <th>기안자</th>
                <th>결재자</th>
                <th>기안일</th>
                <th>결재일</th>
                <th>종류</th>
                <th>결과</th>
              </tr>
            </thead>
            <tbody>
              <template v-if="list && list.length > 0">
                <tr v-for="(vo, idx) in list" :key="'tr_' + idx">
                  <td>{{ page.totalCnt - ((page.pageSize * (page.nowPageNo-1)) + idx)}}</td>
                  <td class="tit">
                    <div class="tit__inner">
                      <a
                        href="#"
                        class="tit-link"
                        @click.prevent="fnGoView(vo)"
                      >{{ vo.vDraftTitle }}</a
                      >
                    </div>
                  </td>
                  <td>{{ vo.vDraftUsernm }}</td>
                  <td>{{ vo.vApprUsernm }}</td>
                  <td>{{ commonUtils.changeStrDatePattern(vo.vDraftDtm, '.') }}</td>
                  <td>{{ commonUtils.changeStrDatePattern(vo.vApprDtm, '.') }}</td>
                  <td>{{ vo.vApprClassnm }}</td>
                  <td>
                    <span
                      :class="vo.vApprStatus === 'APS010' ? 'color-blue' : (vo.vApprStatus === 'APS020' ? 'color-red' : '')"
                      @click="fnOpenOpinionViewPopup(vo.vApprCd)"
                      style="cursor: pointer;"
                    >{{ vo.vApprStatusnm }}</span>
                  </td>
                </tr>
              </template>
              <template v-else>
                <tr>
                  <td colspan="8">
                    <div class="no-result">
                      {{ t('common.msg.no_data') }}
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
        <div class="board-bottom">
          <div class="board-bottom__inner">
            <Pagination
              :page-info="page"
              @click="fnSearchApprovalFinishList"
            />
          </div>
        </div>
      </div>
    </div>
    <teleport to="#common-modal" v-if="popupContent">
      <ap-popup>
        <component
          :is="popupContent"
          :pop-params="popParams"
        />
      </ap-popup>
    </teleport>
  </div>
</template>

<script>
import { defineAsyncComponent, inject } from 'vue'
import { useApproval } from '@/compositions/approval/useApproval'

export default {
  name: 'ApprovalFinishList',
  components: {
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    OpinionViewPop: defineAsyncComponent(() => import('@/components/approval/popup/OpinionViewPop.vue'))
  },
  setup() {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const codeGroupMaps = inject('codeGroupMaps')

    const {
      searchParams,
      page,
      list,
      popupContent,
      popParams,
      fnSearchApprovalFinishList,
      fnOpenOpinionViewPopup,
      fnGoView
    } = useApproval()

    const resetSearchFilter = () => {
      searchParams.value.vDraftSearchStartDt = ''
      searchParams.value.vDraftSearchEndDt = ''
      searchParams.value.vApprClass = ''
      searchParams.value.vKeyword = ''

      fnSearchApprovalFinishList(1)
    }

    const init = async () => {
      fnSearchApprovalFinishList(1)
    }

    init()

    return {
      t,
      commonUtils,
      codeGroupMaps,
      searchParams,
      page,
      list,
      popupContent,
      popParams,
      fnSearchApprovalFinishList,
      resetSearchFilter,
      fnOpenOpinionViewPopup,
      fnGoView
    }
  }
}
</script>
