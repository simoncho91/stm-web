<template>
  <div class="modal-content modal-content__width--640">
    <div class="modal-header">
      <div class="modal-title">의견작성</div>
      <button
        type="button"
        class="modal-close"
        @click="fnClosePopup"
      ></button>
    </div>
    <div class="modal-body">
      <div class="search-depart-table">
        <div class="search-depart-table__inner">
          <table class="ui-table__td--40">
            <colgroup>
              <col style="width:13rem">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr>
                <th>구분</th>
                <td>
                  <div class="ui-radio__list">
                    <div class="ui-radio__inner" v-if="popParams.vApprUserType === 'USR010'">
                      <ap-input-radio
                        v-model:model="vApprStatus"
                        :value="'APS010'"
                        :label="'승인'"
                        :id="'ex_radio1'"
                        name="exRadio"
                      >
                      </ap-input-radio>
                      <ap-input-radio
                        v-model:model="vApprStatus"
                        :value="'APS020'"
                        :label="'반려'"
                        :id="'ex_radio2'"
                        name="exRadio"
                      >
                      </ap-input-radio>
                    </div>
                    <div class="ui-radio__inner" v-else>
                      <ap-input-radio
                        v-model:model="vApprSubStatus"
                        v-for="code in mutualTypeList"
                        :key="code.vSubCode"
                        :value="code.vSubCode"
                        :label="code.vSubCodenm"
                        :id="'apprSub_' + code.vSubCode"
                        name="apprSubStatus"
                      >
                      </ap-input-radio>
                    </div>
                  </div>
                </td>
              </tr>
              <tr>
                <th>의견</th>
                <td>
                  <div class="ui-textarea-box ui-textarea-box__height--140">
                    <ap-text-area
                      v-model:value="vApprOpinion"
                      :is-with-byte="false"
                    ></ap-text-area>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="board-bottom">
        <div class="board-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button
              type="button"
              class="ui-button ui-button__bg--skyblue font-weight__300"
              @click="fnConfirm"
            >확인</button>
            <button
              type="button"
              class="ui-button ui-button__bg--lightgray"
              @click="fnClosePopup"
            >취소</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { inject, ref } from 'vue'
import { useApproval } from '@/compositions/approval/useApproval'
import { useCode } from '@/compositions/useCode'
import { useStore } from 'vuex'

export default {
  name: 'OpinionWritePop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  emits: ['selectFunc'],
  setup (props, context) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const store = useStore()
    const mutualTypeList = ref([])

    const {
      apprInfo,
      fnClosePopup,
      fnSearchApprovalRequiredInfo,
      updateNoteRequest,
      updateBomApproval,
      updateGate2Approval,
      updateFuncDecideName,
      updateShelfLifeCode,
      updateReportApproval,
      noteTypeNm,
    } = useApproval()

    const {
      codeGroupMaps,
      findCodeList,
    } = useCode()

    const vApprStatus = ref('')
    const vApprSubStatus = ref('')
    const vApprOpinion = ref('')

    const fnConfirm = async () => {
      const payload = {
        ...apprInfo.value,
        ... {
          vApprStatus: vApprStatus.value,
          vApprSubStatus: vApprSubStatus.value,
          vApprOpinion: vApprOpinion.value
        }
      }

      const vApprClass = apprInfo.value.vApprClass

      payload.noteTypeNm = noteTypeNm

      if (commonUtils.isNotEmpty(props.popParams.vAprvDtlUrl)) {
        const aprvDtlUrl = props.popParams.vAprvDtlUrl
        const splitUrl = aprvDtlUrl.substr(1, aprvDtlUrl.length).split('/')

        if (splitUrl && splitUrl.length > 0) {
          payload.noteTypeNm = splitUrl[0]
        }
      }

      let result = false

      if (vApprClass === 'LAB_SC_GATE0') {
        result = await updateNoteRequest(payload)
      }
      if (vApprClass.indexOf('LAB001') > -1) {
        payload.vNoteType = vApprClass.split('_')[1]
        result = await updateBomApproval(payload)
      }
      if (vApprClass.indexOf('LAB002') > -1) {
        payload.vNoteType = vApprClass.split('_')[1]
        result = await updateGate2Approval(payload)
      }
      if (vApprClass === 'LAB_PRDNM_SET') {
        result = await updateFuncDecideName(payload)
      }
      if (vApprClass === 'LAB_NOTE_SHELFLIFE') {
        result = await updateShelfLifeCode(payload)
      }
      if (vApprClass === 'REPORT'){
        result = await updateReportApproval(payload)
      }

      if (result) {
        store.dispatch('removeApprovalCount')
        context.emit('selectFunc')
        fnClosePopup()
      }
    }

    const init = async () => {
      const payload = props.popParams

      if (commonUtils.isNotEmpty(payload)) {
        fnSearchApprovalRequiredInfo(payload)
      }

      if (payload.vApprUserType === 'USR020') {
        await findCodeList(['SC0025'])
        mutualTypeList.value = commonUtils.getCodeList(codeGroupMaps, 'SC0025', 'Y')
        vApprStatus.value = 'APS050'
        vApprSubStatus.value = 'AGR010'
      }
    }

    init()

    return {
      t,
      apprInfo,
      mutualTypeList,
      fnClosePopup,
      vApprSubStatus,
      vApprStatus,
      vApprOpinion,
      fnConfirm
    }
  }
}
</script>
