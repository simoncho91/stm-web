<template>
  <div class="modal-content modal-content__width--640">
    <div class="modal-header">
      <div class="modal-title">결재의견보기</div>
      <button
        type="button"
        class="modal-close"
        @click="fnClosePopup"
      ></button>
    </div>
    <div class="modal-body">
      <div class="search-depart-table">
        <div class="search-depart-table__inner">
          <table class="ui-table__td--40">
            <colgroup>
              <col style="width:13rem">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr>
                <th>제목</th>
                <td>
                  <div class="font-weight__600 color-blue">{{ apprInfo.vDraftTitle }}</div>
                </td>
              </tr>
              <tr>
                <th>작성자</th>
                <td>{{ apprInfo.vDraftUsernm }} ({{ apprInfo.vDraftDeptnm }} {{ apprInfo.vDraftPositnm }})</td>
              </tr>
              <tr>
                <th>작성시간</th>
                <td>{{ commonUtils.changeStrDatePattern(apprInfo.vDraftDtm, '.', 'Y') }}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="search-detail-table mt-15">
        <div class="search-detail-table__inner">
          <table class="ui-table__modal">
            <tbody>
              <tr>
                <th>[결재의뢰] {{ apprInfo.vDraftUsernm }} ( {{ apprInfo.vDraftDeptnm }} {{ apprInfo.vDraftPositnm }})</th>
              </tr>
              <tr>
                <td>{{ apprInfo.vDraftOpinion }}</td>
              </tr>
              <template v-if="apprList && apprList.length > 0">
                <template v-for="(vo, idx) in apprList" >
                  <tr v-if="vo.vApprStatus !== 'APS030'" :key="'tr_th_' + idx">
                    <th>
                      <span v-if="vo.vApprStatus === 'APS020'">
                        ◎ <b>[<span style="color: red;">{{ vo.vApprStatusnm }}</span>] </b>
                      </span>
                      <span v-else-if="vo.vApprStatus === 'APS010'">
                        ◎ <b>[<span style="color: blue">{{ vo.vApprStatusnm }}</span>] </b>
                      </span>
                      <span v-else>
                        ◎ <b>[<span>{{ vo.vApprStatusnm }}</span>] </b>
                      </span>
                      <span>{{ vo.vApprUserNm }} ({{ vo.vApprDeptnm }} | {{ vo.vApprPositnm }}) {{ commonUtils.changeStrDatePattern(vo.vApprDtm, '.', 'Y') }}</span>
                    </th>
                  </tr>
                  <tr v-if="vo.vApprStatus !== 'APS030'" :key="'tr_td_' + idx">
                    <td>{{ vo.vApprOpinion }}</td>
                  </tr>
                </template>
              </template>
            </tbody>
          </table>
        </div>
      </div>
      <div class="board-bottom">
        <div class="board-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button
              type="button"
              class="ui-button ui-button__bg--skyblue font-weight__300"
              @click="fnClosePopup"
            >확인</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { inject } from 'vue'
import { useApproval } from '@/compositions/approval/useApproval'

export default {
  name: 'OpinionViewPop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  setup (props) {
    const t = inject('t')
    const commonUtils = inject('commonUtils')

    const {
      apprInfo,
      apprList,
      fnClosePopup,
      fnSearchApprovalInfo
    } = useApproval()

    const init = () => {
      const vApprCd = props.popParams.vApprCd

      if (commonUtils.isNotEmpty(vApprCd)) {
        fnSearchApprovalInfo(vApprCd)
      }
    }

    init()

    return {
      t,
      commonUtils,
      apprInfo,
      apprList,
      fnClosePopup
    }
  }
}
</script>
