<template>
  <div class="modal-content modal-content__width--640">
    <div class="modal-header">
      <div class="modal-title">의견작성</div>
      <button
        type="button"
        class="modal-close"
        @click="fnClosePopup"
      ></button>
    </div>
    <div class="modal-body">
      <div class="search-depart-table">
        <div class="search-depart-table__inner">
          <table class="ui-table__td--40">
            <colgroup>
              <col style="width:13rem">
              <col style="width:auto">
            </colgroup>
            <tbody>
              <tr>
                <th>의견</th>
                <td>
                  <div class="ui-textarea-box ui-textarea-box__height--140">
                    <ap-text-area
                      v-model:value="vDraftOpinion"
                      :is-with-byte="false"
                    ></ap-text-area>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="board-bottom">
        <div class="board-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button
              type="button"
              class="ui-button ui-button__bg--skyblue font-weight__300"
              @click="fnConfirm"
            >확인</button>
            <button
              type="button"
              class="ui-button ui-button__bg--lightgray"
              @click="closeAsyncPopup({ message: '' })"
            >취소</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref } from 'vue'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'OpinionApprReqPop',
  props: {
    popParams: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  emits: ['callbackFunc'],
  setup (props, context) {
    const { closeAsyncPopup } = useActions(['closeAsyncPopup'])
    const vDraftOpinion = ref('')

    const fnConfirm = () => {
      context.emit('callbackFunc', vDraftOpinion)
    }

    return {
      fnConfirm,
      closeAsyncPopup,
      vDraftOpinion,
    }
  }
}
</script>