import axios from '@/utils/customAxios'
import { createStore } from 'vuex'

export const store = createStore({
  state: () => ({
    isLoading: false,
    accessToken: '',
    myInfo: {},
    langCd: '',
    alertInfo: {},
    alertAsync: {},
    gnbList: [],
    routerList: [],
    subMenuList: [],
    popupInfo: {},
    popupAsync: {},
    noteType: '',
    noteTypeNm: '',
    noteInfo: null,
    noteLotList: [],
    recentNoteInfo: { // 상세 3자 탭
      'SC': [],
      'MU': [],
      'HBO': [],
      'SA': [],
    },
    recentLogList: { // left menu
      'SC': [],
      'MU': [],
      'HBO': [],
      'SA': [],
    },
    recentMatrList: { // right menu
      'SC': [],
      'MU': [],
      'HBO': [],
      'SA': [],
    },
    mstMenuid: '',
    deptList: [],
    classList: [],
    originDeptList: [],
    originClassList: [],
    dragMateInfo: {},
    mainList: [],
    alarmCount: null,
    approvalCount: null,
    scheduleList: null,
    perfUserInfo: null,
    searchMateInfo: {},
  }),
  getters: {
    getLoading: (state) => () =>{
      return state.isLoading
    },
    getPopupInfo: (state) => () => {
      return state.popupInfo
    },
    getAlertInfo: (state) => () => {
      return state.alertInfo
    },
    getAccessToken: (state) => () => {
      return state.accessToken
    },
    getMyInfo: (state) => () => {
      return state.myInfo
    },
    getLangCd: (state) => () => {
      if (state.langCd === '') {
        const langCd = localStorage.getItem('langCd')
        if (!langCd) {
          state.langCd = 'ko'
          localStorage.setItem('langCd', 'ko')
        } else {
          state.langCd = langCd
        }
      }
      return state.langCd
    },
    getGnb: (state) => () => {
      return state.gnbList
    },
    getRouter: (state) => () => {
      const routerList = state.routerList.length > 0 ? state.routerList : JSON.parse(sessionStorage.getItem('routerList'))
      return routerList && routerList.length > 0 ? routerList.filter(item => item.nLevel === 3 && item.vRouter === sessionStorage.getItem('noteTypeNm')) : []
    },
    getSubMenuList: (state) => () => {
      const subMenuList = state.subMenuList.length > 0 ? state.subMenuList : JSON.parse(sessionStorage.getItem('subMenuList'))
      return subMenuList && subMenuList.length > 0 ? subMenuList.filter(item => item.vRouter === sessionStorage.getItem('noteTypeNm')) : []
    },
    getNoteType: (state) => () => {
      return state.noteType !== '' ? state.noteType : sessionStorage.getItem('noteType')
    },
    getNoteTypeNm: (state) => () => {
      return state.noteTypeNm !== '' ? state.noteTypeNm : sessionStorage.getItem('noteTypeNm')
    },
    getNoteInfo: (state) => () => {
      return state.noteInfo
    },
    getDeptList: (state) => () => {
      return state.deptList
    },
    getClassList: (state) => () => {
      return state.classList
    },
    getOriginDeptList: (state) => () => {
      return state.originDeptList
    },
    getOriginClassList: (state) => () => {
      return state.originClassList
    },
    getRecentNoteList: (state) => (noteType) => {
      return state.recentNoteInfo[noteType].length > 0 ? state.recentNoteInfo[noteType] : JSON.parse(sessionStorage.getItem('recent'+ noteType +'NoteList'))
    },
    getRecentLogList: (state) => (noteType) => {
      return state.recentLogList[noteType].length > 0 ? state.recentLogList[noteType] : JSON.parse(sessionStorage.getItem('recent'+ noteType +'LogList'))
    },
    getRecentMatrList: (state) => (noteType) => {
      return state.recentMatrList[noteType].length > 0 ? state.recentMatrList[noteType] : JSON.parse(localStorage.getItem('recent' + noteType + 'MatrList'))
    },
    getMstMenuid: (state) => () => {
      return state.mstMenuid !== '' ? state.mstMenuid : sessionStorage.getItem('mstMenuid')
    },
    getDragMateInfo: (state) => () => {
      return state.dragMateInfo
    },
    getMainList: (state) => () => {
      return state.mainList.length > 0 ? state.mainList : JSON.parse(sessionStorage.getItem('mainList'))
    },
    getAlarmCount: (state) => () => {
      return state.alarmCount || sessionStorage.getItem('alarmCount')
    },
    getApprovalCount: (state) => () => {
      return state.approvalCount || sessionStorage.getItem('approvalCount')
    },
    getNoteScheduleList: (state) => () => {
      return state.scheduleList
    },
    getPerfUserInfo: (state) => () => {
      return state.perfUserInfo
    },
    getNoteLotList: (state) => () => {
      return state.noteLotList
    },
    getSearchMateInfo: (state) => () => {
      return state.searchMateInfo
    },
  },
  // 뮤테이션(mutations)은 스토어의 상태를 변경할 수 있는 유일한 메서드 이다.
  mutations: {
    SET_ACCESS_TOKEN (state, accessToken) {
      if (accessToken) {
        state.accessToken = accessToken
        sessionStorage.setItem('accessToken', accessToken)
      }
    },
    REMOVE_ACCESS_TOKEN (state) {
      state.accessToken = ''
      state.myInfo = {}
      state.routerList = []
      state.mainList = []
      state.alarmCount = null
      state.approvalCount = null
      sessionStorage.removeItem('accessToken')
      sessionStorage.removeItem('routerList')
      sessionStorage.removeItem('menuAuthList')
      sessionStorage.removeItem('alarmCount')
      sessionStorage.removeItem('approvalCount')
      sessionStorage.removeItem('historyUrl')

      const arrNoteType = ['SC', 'MU', 'HBO', 'SA']
      for (const noteType of arrNoteType) {
        sessionStorage.removeItem('recent' + noteType + 'NoteList')
        sessionStorage.removeItem('loadRecentListFlag' + noteType)
        sessionStorage.removeItem('recent' + noteType + 'LogList')
        sessionStorage.removeItem('searchParams' + noteType)
      }
      
      sessionStorage.removeItem('mainList')
      localStorage.removeItem('accessToken')
    },
    SET_MY_INFO (state, payload) {
      if (payload) {
        state.myInfo = payload

        if (payload.menuAuthList) {
          sessionStorage.setItem('menuAuthList', JSON.stringify(payload.menuAuthList.filter(item => item.vRouter !== 'approval')))
        }

        if (payload.mainList) {
          state.mainList = payload.mainList
          sessionStorage.setItem('mainList', JSON.stringify(payload.mainList))
        }
      }
    },
    SET_LANG_CD (state, langCd) {
      if (langCd) {
        state.langCd = langCd
        localStorage.setItem('langCd', langCd)
      }
    },
    OPEN_POPUP (state, payload) {
      const scrollTop = window.scrollY || window.document.documentElement.scrollTop
      state.popupInfo = {
        isOpen: true,
        scrollTop: scrollTop,
        ...payload
      }

      sessionStorage.setItem('scroll', scrollTop)
      window.document.querySelector('html').style.overflow = 'hidden'
    },
    CLOSE_POPUP (state, payload) {
      state.popupAsync.resolve(payload)

      window.document.querySelector('html').style.overflow = 'auto'
      setTimeout(() => {
        window.document.documentElement.scrollTo(0, sessionStorage.getItem('scroll'))
        sessionStorage.removeItem('scroll')
      }, 100)

      state.popupInfo = {
        isOpen: false
      }
      state.popupAsync.resolve = undefined
      state.popupAsync.reject = undefined
    },
    SET_POPUP (state, { resolve, reject }) {
      state.popupAsync.resolve = resolve
      state.popupAsync.reject = reject
    },
    OPEN_ALERT (state, payload) {
      const scrollTop = window.scrollY || window.document.documentElement.scrollTop
      state.alertInfo = {
        isOpen: true,
        scrollTop: scrollTop,
        ...payload
      }

      window.document.querySelector('html').style.overflow = 'hidden'
    },
    CLOSE_ALERT (state, type) {
      state.alertAsync.resolve(type === 'OK')

      window.document.querySelector('html').style.overflow = 'auto'
      window.scrollTo(0, state.alertInfo.scrollTop)

      state.alertInfo = {
        isOpen: false
      }
      state.alertAsync.resolve = undefined
      state.alertAsync.reject = undefined
    },
    SET_ALERT (state, { resolve, reject }) {
      state.alertAsync.resolve = resolve
      state.alertAsync.reject = reject
    },
    REMOVE_ALERT (state, type) {
      if (type === 'OK') {
        state.alertAsync.resolve(true)
      } else {
        state.alertAsync.resolve(false)
      }
      state.alertAsync.resolve = undefined
      state.alertAsync.reject = undefined
    },
    SET_GNB(state, payload) {
      state.gnbList = payload
    },
    SET_ROUTER(state, payload) {
      state.routerList = payload;
      sessionStorage.setItem('routerList', JSON.stringify(payload))
    },
    SET_LOADING(state, payload){
      state.isLoading = payload;
    },
    SET_NOTE_TYPE_NM(state, payload) {
      state.noteTypeNm = payload
      sessionStorage.setItem('noteTypeNm', payload)
    },
    SET_NOTE_TYPE(state, payload) {
      state.noteType = payload
      sessionStorage.setItem('noteType', payload)
    },
    SET_NOTE_INFO(state, payload) {
      state.noteInfo = payload
    },
    SET_DEPT_LIST(state, payload) {
      state.deptList = payload
    },
    SET_CLASS_LIST(state, payload) {
      state.classList = payload
    },
    SET_ORIGIN_DEPT_LIST(state, payload) {
      state.originDeptList = payload
    },
    SET_ORIGIN_CLASS_LIST(state, payload) {
      state.originClassList = payload
    },
    SET_RECENT_MATR_LIST(state, { noteType, matrKey}) {
      let matrList = JSON.parse(localStorage.getItem('recent' + noteType + 'MatrList'))
      if (matrList === undefined || matrList === null) {
        matrList = []
      }

      const recentMatrList = matrList.length > 0 ? matrList.filter(item => item !== matrKey) : []
      if (recentMatrList.length < 10) {
        recentMatrList.unshift(matrKey)
      } else {
        recentMatrList.pop()
        recentMatrList.unshift(matrKey)
      }

      state.recentMatrList[noteType] = recentMatrList
      localStorage.setItem('recent' + noteType + 'MatrList', JSON.stringify(recentMatrList))
    },
    SET_RECENT_NOTE_LIST(state, { noteType, noteInfo}) {
      let noteList = JSON.parse(sessionStorage.getItem('recent'+ noteType +'NoteList'))
      if (noteList === undefined || noteList === null) {
        noteList = []
      }

      const recentNoteList = noteList.length > 0 ? noteList.filter(item => item.vLabNoteCd !== noteInfo.vLabNoteCd) : []
      if (recentNoteList.length < 10) {
        recentNoteList.unshift(noteInfo)
      } else {
        recentNoteList.pop()
        recentNoteList.unshift(noteInfo)
      }

      state.recentNoteInfo[noteType] = recentNoteList
      sessionStorage.setItem('recent'+ noteType +'NoteList', JSON.stringify(recentNoteList))
    },
    REMOVE_RECENT_NOTE (state, {noteType, index}) {
      let noteList = JSON.parse(sessionStorage.getItem('recent'+ noteType +'NoteList'))
      if (noteList) {
        noteList.splice(index, 1)
      }

      state.recentNoteInfo[noteType] = noteList
      sessionStorage.setItem('recent'+ noteType +'NoteList', JSON.stringify(noteList))
    },
    SET_RECENT_LOG_LIST(state, { noteType, recentList }) {
      state.recentLogList[noteType] = recentList
      sessionStorage.setItem('recent' + noteType + 'LogList', JSON.stringify(recentList))
    },
    SET_SUB_MENU_LIST(state, payload) {
      state.subMenuList = payload
      sessionStorage.setItem('subMenuList', JSON.stringify(payload))
    },
    SET_MST_MENUID (state, payload) {
      state.mstMenuid = payload
      sessionStorage.setItem('mstMenuid', payload)
    },
    SET_DRAG_MATE_INFO (state, payload) {
      state.dragMateInfo = payload
    },
    SET_MAIN_LIST (state, payload) {
      state.mainList = payload
      sessionStorage.setItem('mainList', JSON.stringify(payload))
    },
    SET_ALARM_COUNT (state, payload) {
      state.alarmCount = payload
      sessionStorage.setItem('alarmCount', payload)
    },
    SET_APPROVAL_COUNT (state, payload) {
      state.approvalCount = payload
      sessionStorage.setItem('approvalCount', payload)
    },
    REMOVE_APPROVAL_COUNT (state) {
      state.approvalCount = null
      sessionStorage.removeItem('approvalCount')
    },
    SET_SCHEDULE_LIST (state, payload) {
      const progressInfo = payload.progressInfo
      const scheduleList = payload.scheduleList
      if (progressInfo && progressInfo.length > 0) {
        progressInfo.forEach(item => {
          item.scheduleList = scheduleList.filter(schd => schd.vStatusCd === item.vStatusCd)
        })
      }

      state.scheduleList = progressInfo
    },
    SET_PERF_USER_INFO (state, payload) {
      state.perfUserInfo = payload
    },
    SET_NOTE_LOT_LIST (state, payload) {
      state.noteLotList = payload
    },
    SET_SEARCH_MATE_INFO (state, payload) {
      state.searchMateInfo = payload
    },
  },
  // 액션(actions)은 비동기 처리를 포함할 수 있는 메서드이다.
  // 액션을 사용하는 일반적인 경우는 데이터 가공 또는 비동기 처리를 실시한 후, 그 결과를 뮤테이션에 전달하고 뮤테이션을 커밋하는 것이다.
  actions: {
    setLoading(context, isLoading){
      context.commit('SET_LOADING', isLoading);
    },
    setSession (context, { token, myInfo }) {
      console.log('token >>>>>>>', token)
      console.log('myInfo >>>>>>>', myInfo)
      context.commit('SET_ACCESS_TOKEN', token)
      context.commit('SET_MY_INFO', myInfo)
    },
    setMainList (context, mainList) {
      context.commit('SET_MAIN_LIST', mainList)
    },
    changeLangCd (context, langCd) {
      context.commit('SET_LANG_CD', langCd)
    },
    signin (context, payload) {
      return axios({
        method: 'post',
        url: '/api/user/signin',
        isLoading: true,
        data: payload
      })
        .then(async response => {
          const resData = response.data

          if (resData.code === 'C0000' || resData.code === 'PW_EXPIRED' || resData.code === 'PASS_EXPIRE_SEVEN_DAY') {
            const myInfo = resData.data 
            const token = myInfo.token
            delete myInfo.token

            context.commit('SET_ACCESS_TOKEN', token)
            context.commit('SET_MY_INFO', myInfo)

            if (payload.rememberMe === 'Y') {
              const remToken = resData.data.rememberMeToken
              localStorage.setItem('accessToken', remToken)
            } else {
              localStorage.removeItem('accessToken')
            }
          }

          return response
        })
        .catch(function (error) {
          console.log(error)
        })
    },
    signinByToken (context, payload) {
      return axios({
        method: 'get',
        url: '/api/user/token-check',
        headers: {
          'x-session-token': payload.sessionToken,
          'x-local-token': payload.localToken ? payload.localToken : ''
        }
      }).then(res => {
          const resData = res.data
          // T0001 : sessionToken 유효, T0002 : localToken 유효(자동로그인)
          if (resData.code === 'T0001' || resData.code === 'T0002') {
            const myInfo = resData.data
            const token = myInfo.token
            delete myInfo.token
            context.commit('SET_ACCESS_TOKEN', token)
            context.commit('SET_MY_INFO', myInfo)
          } else {
            context.commit('REMOVE_ACCESS_TOKEN')
          }
        })
    },
    signout (context) {
      const sessionToken = sessionStorage.getItem('accessToken')
      const localToken = localStorage.getItem('accessToken')
      return axios({
        method: 'get',
        url: '/api/user/signout',
        isLoading: true,
        headers: {
          'x-session-token': sessionToken,
          'x-local-token': localToken
        }
      })
        .then(async response => {
          const resData = response.data

          if (resData.code === 'C0000') {
            context.commit('REMOVE_ACCESS_TOKEN')
          }

          return response
        })
        .catch(function (error) {
          console.error(error)
        })
    },
    checkSso (context) {
      return axios({
        method: 'post',
        url: '/api/user/sso-signin',
        isLoading: true,
        data: {
          ssoYn: 'Y'
        }
      })
      .then(async res => {
        const resData = res.data
        if (resData.code === 'C0000') {
          const myInfo = resData.data 
          const token = myInfo.token
          delete myInfo.token

          context.commit('SET_ACCESS_TOKEN', token)
          context.commit('SET_MY_INFO', myInfo)
          sessionStorage.setItem('ssoToken', 'Y')
          return res
        }
      })
    },
    openAsyncPopup (context, payload) {
      context.commit('OPEN_POPUP', payload)
      return new Promise((resolve, reject) => {
        context.commit('SET_POPUP', { resolve, reject })
      })
    },
    closeAsyncPopup (context, payload) {
      context.commit('CLOSE_POPUP', payload)
    },
    openAsyncAlert (context, payload) {
      const opts = {
        ...payload,
        type: 'ALERT'
      }
      context.commit('OPEN_ALERT', opts)
      return new Promise((resolve, reject) => {
        context.commit('SET_ALERT', { resolve, reject })
      })
    },
    closeAsyncAlert (context) {
      context.commit('CLOSE_ALERT', 'OK')
    },
    openAsyncConfirm (context, payload) {
      const opts = {
        ...payload,
        type: 'CONFIRM'
      }
      context.commit('OPEN_ALERT', opts)
      return new Promise((resolve, reject) => {
        context.commit('SET_ALERT', { resolve, reject })
      })
    },
    closeAsyncConfirm (context, type) {
      context.commit('CLOSE_ALERT', type)
    },
    findGnb (context) {
      return axios({
        method: 'get',
        url: '/api/menu',
        paramsSerializer: paramsObj => {
          const params = new URLSearchParams()
          for (const key in paramsObj) {
            if (Array.isArray(paramsObj[key]) && paramsObj[key].length === 0) {
              continue
            }
            params.append(key, paramsObj[key])
          }
          return params.toString()
        }
      }).then(async response => {
        const resData = response.data
        if (resData.code === 'C0000') {
          const gnbData = resData.data 
          context.commit('SET_GNB', gnbData)
        }
        return response
      })
      .catch(function (error) {
        console.log(error)
      })
    },
    findRouter (context) {
      return axios({
        method: 'get',
        url: '/api/authority/select-router-list',
        paramsSerializer: paramsObj => {
          const params = new URLSearchParams()
          for (const key in paramsObj) {
            if (Array.isArray(paramsObj[key]) && paramsObj[key].length === 0) {
              continue
            }
            params.append(key, paramsObj[key])
          }
          return params.toString()
        }
      }).then(async response => {
        const resData = response.data
        if (resData.code === 'C0000') {
          const gnbData = resData.data 
          context.commit('SET_ROUTER', gnbData)
        }
        return response
      })
      .catch(function (error) {
        console.log(error)
      })
    },
    findRecentLogList (context, payload) {
      return axios({
        method: 'get',
        url: '/api/labcommon/select-note-recent-log-list',
        params: payload
      }).then(async response => {
        const resData = response.data
        if (resData.code === 'C0000') {
          if (resData.data) {
            context.commit('SET_RECENT_LOG_LIST', {noteType: payload.vNoteType, recentList: resData.data})
          }

          sessionStorage.setItem('loadRecentListFlag' + payload.vNoteType, 'Y')
        }
      })
    },
    insertNoteRecentLog (context, payload) {
      return axios({
        method: 'post',
        url: '/api/labcommon/save-note-recent-log',
        data: payload
      }).then(async response => {
        const resData = response.data
        if (resData.code === 'C0000') {
          if (resData.data) {
            context.commit('SET_RECENT_LOG_LIST', {noteType: payload.vNoteType, recentList: resData.data})
          }
        }
      })
    },
    deleteNoteRecentLogCont (context, payload) {
      return axios({
        method: 'post',
        url: '/api/labcommon/delete-note-recent-log-cont',
        data: payload
      }).then(async response => {
        const resData = response.data
        if (resData.code === 'C0000') {
          if (resData.data) {
            context.commit('SET_RECENT_LOG_LIST', {noteType: payload.vNoteType, recentList: resData.data})
          }
        }
      })
    },
    selectMyApprovalCount (context) {
      return axios({
        method: 'get',
        url: '/api/common/select-my-approval-count',
      })
      .then (response => {
        const resData = response.data
        if (resData.code === 'C0000') {
          if (resData.data) {
            context.commit('SET_APPROVAL_COUNT', resData.data)
          }
        }
      })
    },
    selectNoteDetailScheduleList (context, payload) {
      return axios({
        method: 'get',
        url: `/api/${payload.noteTypeNm}/process/select-note-detail-schedule-list`,
        params: {
          vLabNoteCd: payload.vLabNoteCd
        }
      })
      .then(response => {
        const resData = response.data
        if (resData.code === 'C0000') {
          if (resData.data) {
            context.commit('SET_SCHEDULE_LIST', resData.data)
          }
        }
      })
    },
    findMenuAuthList (context) {
      return axios({
        method: 'get',
        url: '/api/common/select-menu-auth-list',
      })
      .then(res => {
        const resData = res.data
        if (resData.code === 'C0000') {
          sessionStorage.setItem('menuAuthList', JSON.stringify(resData.data.filter(item => item.vRouter !== 'approval')))
          return resData.data
        }
      })
    },
    setNoteType (context, type) {
      const noteTypecd = {
        'skincare': 'SC',
        'makeup': 'MU',
        'hbd': 'HBO',
        'qdrug': 'SA'
      }
      context.commit('SET_NOTE_TYPE_NM', type)
      context.commit('SET_NOTE_TYPE', noteTypecd[type])
    },
    setNoteInfo (context, payload) {
      context.commit('SET_NOTE_INFO', payload)
    },
    setDeptList (context, payload) {
      context.commit('SET_DEPT_LIST', payload)
    },
    setClassList (context, payload) {
      context.commit('SET_CLASS_LIST', payload)
    },
    setOriginDeptList (context, payload) {
      context.commit('SET_ORIGIN_DEPT_LIST', payload)
    },
    setOriginClassList (context, payload) {
      context.commit('SET_ORIGIN_CLASS_LIST', payload)
    },
    setRecentMatrList (context, {noteType, matrKey}) {
      context.commit('SET_RECENT_MATR_LIST', {noteType, matrKey})
    },
    setRecentNoteList (context, {noteType, noteInfo}) {
      context.commit('SET_RECENT_NOTE_LIST', {noteType, noteInfo})
    },
    setSubMenuList (context, payload) {
      context.commit('SET_SUB_MENU_LIST', payload)
    },
    removeRecentNoteList (context, {noteType, index}) {
      context.commit('REMOVE_RECENT_NOTE', {noteType, index})
    },
    setMstMenuid (context, payload) {
      context.commit('SET_MST_MENUID', payload)
    },
    setDragMateInfo (context, payload) {
      context.commit('SET_DRAG_MATE_INFO', payload)
    },
    setAlarmCount (context, payload) {
      context.commit('SET_ALARM_COUNT', payload)
    },
    removeApprovalCount (context) {
      context.commit('REMOVE_APPROVAL_COUNT')
    },
    setPerfUserid (context, payload) {
      context.commit('SET_PERF_USER_INFO', payload)
    },
    setNoteLotList (context, payload) {
      context.commit('SET_NOTE_LOT_LIST', payload)
    },
    setSearchMateInfo (context, payload) {
      context.commit('SET_SEARCH_MATE_INFO', payload)
    },
  }
})