import { reactive, computed } from 'vue'
import axios from '@/utils/customAxios'

export const useCode = () => {
  const state = reactive({
    codeGroupMaps: {}
  })

  const codeGroupMaps = computed(() => state.codeGroupMaps)

  const findCodeList = async (arrMstCode) => {
    const params = {
      arrMstCode: arrMstCode
    }

    return await axios({
      url: '/api/common/select-code-list',
      method: 'get',
      params: params,
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.codeGroupMaps = { ...state.codeGroupMaps, ...resData.data }
      }
    })
  }

  return {
    codeGroupMaps,
    findCodeList
  }
}