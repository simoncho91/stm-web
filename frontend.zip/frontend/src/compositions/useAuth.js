import axios from "@/utils/customAxios";
import { reactive, toRefs, inject, getCurrentInstance } from "vue";
import { useActions } from 'vuex-composition-helpers'
import { useStore } from 'vuex'

export const useAuth = () => {
  const t = inject('t')
  const { openAsyncAlert, openAsyncConfirm, openAsyncPopup, closeAsyncPopup } = useActions(['openAsyncAlert', 'openAsyncConfirm', 'openAsyncPopup', 'closeAsyncPopup'])
  const state = reactive({
    searchParams: {
      vDraftSearchStartDt:'',
      vDraftSearchEndDt: '',
      vApprClass: '',
      vKeyword: '',
      nowPageNo: 1
    },
    page: {},
    list: [],
    apprInfo: {},
    apprList: [],
    referenceList: [],
    popupContent: null,
    popParams: {},
    popSelectFunc: null,
  })

  const store = useStore()
  const noteType = store.getters.getNoteType()
  const noteTypeNm = store.getters.getNoteTypeNm()

  const app = getCurrentInstance()
  const tiumUrl = app.appContext.config.globalProperties.tiumUrl

  const possibleApprClsArr = [
    'LAB_SC_GATE0'
    ,'LAB001_SC'
    ,'LAB001_MU'
    ,'LAB001_HBO'
    ,'LAB001_SA'
    ,'LAB002_SC'
    ,'LAB002_MU'
    ,'LAB002_HBO'
    ,'LAB002_SA'
    ,'LAB_PRDNM_SET'
    ,'LAB_NOTE_SHELFLIFE'
  ]

  // [METHOD] ===========================================================================

  const fnOpenPopup = (compNm) => {
    state.popupContent = compNm

    const payload = {}

    openAsyncPopup(payload)
      .then(res => {
      })
      .catch(err => {
        console.log(err)
      })
      .finally(() => {
        state.popupContent = null
      })
  }

  const fnClosePopup = (returnObj) => {
    closeAsyncPopup(returnObj)
  }

  const selectCmAuthTypeRegYn = (payload) => {
    return axios({
      url: '/api/authority/select-cm-auth-type-regYn',
      method: 'get',
      params: payload
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectDeptUsrGrpAllList = (payload) => {
    return axios({
      url: '/api/authority/select-dept-usr-grp-all-list',
      method: 'get',
      params: payload
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectCmAuthList = (payload) => {
    return axios({
      url: '/api/authority/select-cm-auth-list',
      method: 'get',
      params: payload
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const saveCmAuthList = (payload) => {
    return axios({
      url: '/api/authority/save-cm-auth-list',
      method: 'post',
      data: payload
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  return {
    ...toRefs(state),
    noteType,
    possibleApprClsArr,
    selectCmAuthTypeRegYn,
    fnClosePopup,
    fnOpenPopup,
    selectCmAuthList,
    selectDeptUsrGrpAllList,
    saveCmAuthList
  }
}