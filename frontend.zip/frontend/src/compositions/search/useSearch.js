import axios from "@/utils/customAxios";
import { reactive, toRefs, inject } from "vue";
import { useActions } from 'vuex-composition-helpers'
import { useStore } from 'vuex'

export const useSearch = () => {
  const t = inject('t')
  const { openAsyncAlert, openAsyncPopup, closeAsyncPopup } = useActions(['openAsyncAlert', 'openAsyncPopup', 'closeAsyncPopup'])
  const state = reactive({
    searchParams: {
      vKeyword: '',
      nowPageNo: 1
    },
    page: {},
    list: [],
    popupContent: null,
    popParams: {},
    popSelectFunc: null,
    mateRateInfoList: [],
    compareContArr: [],
    authDeptInfo: {},
    contentDetailInfo: []
  })

  const store = useStore()
  const noteTypeNm = store.getters.getNoteTypeNm()

  // [METHOD] ===========================================================================

  const fnOpenPopup = (compNm) => {
    state.popupContent = compNm

    const payload = {}

    openAsyncPopup(payload)
      .then(res => {
      })
      .catch(err => {
        console.log(err)
      })
      .finally(() => {
        state.popupContent = null
      })
  }

  const fnClosePopup = (returnObj) => {
    closeAsyncPopup(returnObj)
  }

  const fnSearchRawList = (pg) => {
    if(!pg){
      pg = 1
    }

    state.searchParams.nowPageNo = pg

    findMstSearchList(state.searchParams)
  }

  const fnSearchCounterMapList = () => {
    const vKeyword = state.searchParams.vKeyword

    if (vKeyword.length < 2) {
      openAsyncAlert({ message: '2자리 이상의 keyword를 입력해주세요.' })
      return
    }

    if (state.compareContArr.length > 0) {
      state.compareContArr = []
    }

    findCounterMapList(state.searchParams)
  }

  const fnOpenSearchDeptAuthMngPopup = () => {
    fnOpenPopup('SearchDeptAuthMngPop')
  }

  const fnOpenContDetailPopup = (payload) => {
    state.popParams = payload

    fnOpenPopup('ContDetailPop')
  }

  const fnOpenContComparePopup = (payload) => {
    if (!payload || payload.length === 0) {
      openAsyncAlert({ message: '내용물 비교는 1개 이상이여야 합니다.' })
      return
    }
    state.popParams = payload

    fnOpenPopup('ContComparePop')
  }

  const fnSearchAuthDeptInfo = () => {
    findAuthDeptInfo()
  }

  const fnSearchContentDetailInfo = (payload) => {
    findContentDetailInfo(payload)
  }

  const fnSearchMateRateInfo = (payload) => {
    if (payload) {
      findMateRateInfo(payload)
    }
  }

  // [API] ===========================================================================
  
  const findMstSearchList = (payload) => {
    return axios({
      url: `/api/${noteTypeNm}/search/select-mst-search-list`,
      method: 'get',
      isLoading: true,
      params: payload
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.page = resData.data.page
        state.list = resData.data.list
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const findCounterMapList = (payload) => {
    return axios({
      url: `/api/${noteTypeNm}/search/select-counter-map-list`,
      method: 'get',
      isLoading: true,
      params: payload
    })
    .then(async res => {
      const resData = res.data
      if (resData) {
        if (resData.code === 'C0000') {
          state.list = resData.data
        } else if (resData.code === 'fail') {
          openAsyncAlert({ message: resData.message })
          state.list = []
        }
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
        state.list = []
      }
    })
  }

  const findAuthDeptInfo = () => {
    return axios({
      url: '/api/labcommon/select-auth-dept-info',
      method: 'get'
    })
    .then(async res => {
      const resData = res.data
      if (resData && resData.code === 'C0000') {
        state.authDeptInfo = resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const insertAuthDeptInfo = (payload) => {
    return axios({
      url: '/api/labcommon/insert-auth-dept-info',
      method: 'post',
      data: {
        authDeptMap: payload
      }
    })
    .then(async res => {
      const resData = res.data
      if (resData && resData.code === 'C0000') {
        await openAsyncAlert({ message: '저장되었습니다.' })
        return true
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
        return false
      }
    })
  }

  const findContentDetailInfo = (payload) => {
    return axios({
      url: `/api/${noteTypeNm}/search/select-content-detail`,
      method: 'get',
      params: payload
    })
    .then(async res => {
      const resData = res.data
      if (resData && resData.code === 'C0000') {
        state.contentDetailInfo = resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const findMateRateInfo = (payload) => {
    return axios({
      url: `/api/${noteTypeNm}/search/select-content-compare-info`,
      method: 'post',
      data: { mateRateParamList: payload }
    })
    .then(async res => {
      const resData = res.data
      if (resData && resData.code === 'C0000') {
        state.mateRateInfoList = resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  return {
    ...toRefs(state),
    // [METHOD] ===================================
    fnSearchRawList,
    fnSearchCounterMapList,
    fnOpenSearchDeptAuthMngPopup,
    fnOpenContDetailPopup,
    fnOpenContComparePopup,
    fnClosePopup,
    fnSearchAuthDeptInfo,
    fnSearchContentDetailInfo,
    fnSearchMateRateInfo,
    // [API] ======================================
    findMstSearchList,
    findAuthDeptInfo,
    insertAuthDeptInfo,
    findContentDetailInfo,
    findMateRateInfo
  }
}