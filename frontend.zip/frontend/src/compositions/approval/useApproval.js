import axios from "@/utils/customAxios";
import { reactive, toRefs, inject, getCurrentInstance } from "vue";
import { useActions } from 'vuex-composition-helpers'
import { useStore } from 'vuex'

export const useApproval = () => {
  const t = inject('t')
  const commonUtils = inject('commonUtils')
  const { openAsyncAlert, openAsyncConfirm, openAsyncPopup, closeAsyncPopup } = useActions(['openAsyncAlert', 'openAsyncConfirm', 'openAsyncPopup', 'closeAsyncPopup'])
  const state = reactive({
    searchParams: {
      vDraftSearchStartDt:'',
      vDraftSearchEndDt: '',
      vApprClass: '',
      vKeyword: '',
      nowPageNo: 1
    },
    page: {},
    list: [],
    apprInfo: {},
    apprList: [],
    referenceList: [],
    popupContent: null,
    popParams: {},
    popSelectFunc: null,
  })

  const store = useStore()
  const noteType = store.getters.getNoteType()
  const noteTypeNm = store.getters.getNoteTypeNm()

  const app = getCurrentInstance()
  const tiumUrl = app.appContext.config.globalProperties.tiumUrl

  const possibleApprClsArr = [
    'LAB_SC_GATE0'
    ,'LAB001_SC'
    ,'LAB001_MU'
    ,'LAB001_HBO'
    ,'LAB001_SA'
    //,'LAB002_SC'
    ,'LAB002_MU'
    ,'LAB002_HBO'
    ,'LAB002_SA'
    ,'LAB_PRDNM_SET'
    // ,'LAB_NOTE_SHELFLIFE'
    ,'REPORT'
  ]

  // [METHOD] ===========================================================================

  const fnOpenPopup = (compNm) => {
    state.popupContent = compNm

    const payload = {}

    openAsyncPopup(payload)
      .then(res => {
      })
      .catch(err => {
        console.log(err)
      })
      .finally(() => {
        state.popupContent = null
      })
  }

  const fnClosePopup = (returnObj) => {
    closeAsyncPopup(returnObj)
  }

  const fnSearchApprovalList = (pg) => {
    if(!pg){
      pg = 1
    }

    state.searchParams.nowPageNo = pg

    const payload = Object.assign({}, state.searchParams)

    payload.vDraftSearchStartDt = payload.vDraftSearchStartDt.replaceAll('-', '')
    payload.vDraftSearchEndDt = payload.vDraftSearchEndDt.replaceAll('-', '')

    findApprovalList(payload)
  }

  const fnSearchApprovalFinishList = (pg) => {
    if(!pg){
      pg = 1
    }

    state.searchParams.nowPageNo = pg

    const payload = Object.assign({}, state.searchParams)

    payload.vDraftSearchStartDt = payload.vDraftSearchStartDt.replaceAll('-', '')
    payload.vDraftSearchEndDt = payload.vDraftSearchEndDt.replaceAll('-', '')

    findApprovalFinishList(payload)
  }

  const fnOpenOpinionViewPopup = (vApprCd) => {
    state.popParams = { vApprCd }

    fnOpenPopup('OpinionViewPop')
  }

  const fnOpenOpinionWritePopup = async (payload) => {
    if (payload && payload.vApprClass) {
      if (!possibleApprClsArr.includes(payload.vApprClass)
        || (payload.vApprClass == 'REPORT' && payload.vDocClass !== 'REP144')   //REPORT 인데 의약외품 신고/허가 타입이 아닌 경우
        || commonUtils.isEmpty(payload.vAprvDtlUrl)
      ) {
        if (await openAsyncConfirm({ message: '티움넷으로 이동하시겠습니까?' })) {
          window.open(`${tiumUrl}/mp/ap/mp_ap_approval_list.do`, '_blank')
        }
      } 
      else {

        state.popParams = payload
        state.popSelectFunc = fnSearchApprovalList
    
        fnOpenPopup('OpinionWritePop')
      }
    }
  }

  const fnSearchApprovalInfo = (vApprCd) => {
    if (vApprCd) {
      findApprovalInfo(vApprCd)
    }
  }

  const fnSearchApprovalRequiredInfo = ({ vApprCd, vApprUserType }) => {
    const payload = {
      vApprCd,
      vApprUserType
    }
    
    if (payload) {
      findApprovalRequiredInfo(payload)
    }
  }

  const fnGoView = ({ vApprCd, vUrl, vApprClass, vAprvDtlUrl }) => {
    if (vApprClass) {
      if (!possibleApprClsArr.includes(vApprClass)) {
        const baseUrl = `${tiumUrl}/${vUrl}`

        const form = document.createElement("form")

        form.setAttribute("method", "post")
        form.setAttribute("action", baseUrl)
        form.setAttribute("target", "_blank")

        const hiddenField1 = document.createElement("input")
        const hiddenField2 = document.createElement("input")

        hiddenField1.setAttribute("name", "i_sApprCd");
        hiddenField1.setAttribute("value", vApprCd);

        hiddenField2.setAttribute("name", "i_sApprClass")
        hiddenField2.setAttribute("value", vApprClass)

        form.appendChild(hiddenField1)
        form.appendChild(hiddenField2)

        document.body.appendChild(form)
        form.submit()

        hiddenField1.remove()
        hiddenField2.remove()

        form.remove()
      } else {
        // TODO - 결재영역이 포함된 상세 페이지로 라우팅 시켜줘야 함.
        //openAsyncAlert({ message: '실험노트 내에서 행한 결재입니다.' })
        if (commonUtils.isNotEmpty(vAprvDtlUrl)) {
          window.location.href = vAprvDtlUrl
        } else {
          openAsyncAlert({ message: '상세 이동 주소가 없습니다. 관리자에게 문의해 주시기 바랍니다.' })
        }
      }
    }
  }

  // [API] ===========================================================================

  const findApprovalList = (payload) => {
    return axios({
      url: '/api/appr/select-approval-list',
      method: 'get',
      isLoading: true,
      params: payload
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.page = resData.data.page
        state.list = resData.data.list
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const findApprovalFinishList = (payload) => {
    return axios({
      url: '/api/appr/select-approval-finish-list',
      method: 'get',
      isLoading: true,
      params: payload
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.page = resData.data.page
        state.list = resData.data.list
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const findApprovalInfo = (apprCd) => {
    return axios({
      url: '/api/appr/select-approval-info',
      method: 'get',
      params: {
        apprCd: apprCd
      }
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.apprInfo = resData.data.apprInfo
        state.apprList = resData.data.apprList
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const findReferenceList = (recordId) => {
    return axios({
      url: '/api/appr/select-reference-list',
      method: 'get',
      params: {
        recordId: recordId
      }
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.referenceList = resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const findApprovalRequiredInfo = (payload) => {
    return axios({
      url: '/api/appr/select-approval-required-info',
      method: 'get',
      params: payload
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.apprInfo = resData.data.apprInfo
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  // 내용물 등록 의뢰건 결재 처리(GATE 0)[LAB_SC_GATE0] - 제품
  // 프로세스 변경으로, 스킨케어(SC) 제품만 해당 결재 처리
  const updateNoteRequest = (payload) => {
    return axios({
      url: `/api/skincare/appr/update-note-request`,
      method: 'post',
      data: payload
    })
    .then(async res => {
      const resData = res.data
      if (resData) {
        if (resData.code ===  'fail') {
          openAsyncAlert({ message: resData.message })
          return false
        } else {
          let message = ''
  
          switch (resData.code) {
            case 'ACCEPT_END':
              message = '승인하였습니다.'
              break;
            case 'APPR_BACK':
              message = '반려하였습니다.'
              break;
            case 'APPR_SUCC':
              message = '결재하였습니다.'
              break;
            case 'MUTUAL_SUCC':
              message = '합의선 작성을 완료하였습니다.'
              break;
            default:
              break;
          }
          store.dispatch('removeApprovalCount')
          await openAsyncAlert({ message })
  
          return true
        }
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
        return false
      }
    })
  }

  // BOM 승인 결재 처리(GATE 1)[LAB001_*] - 제품, 반제품
  const updateBomApproval = (payload) => {
    return axios({
      url: `/api/${payload.noteTypeNm}/appr/update-bom-approval`,
      method: 'post',
      data: payload
    })
    .then(async res => {
      const resData = res.data
      if (resData) {
        if (resData.code ===  'fail') {
          openAsyncAlert({ message: resData.message })
          return false
        } else {
          let message = ''
  
          switch (resData.code) {
            case 'ACCEPT_END':
              message = '승인하였습니다.'
              break;
            case 'APPR_BACK':
              message = '반려하였습니다.'
              break;
            case 'APPR_SUCC':
              message = '결재하였습니다.'
              break;
            case 'MUTUAL_SUCC':
              message = '결재하였습니다.'
              break;
            default:
              break;
          }
          store.dispatch('removeApprovalCount')
          await openAsyncAlert({ message })
  
          return true
        }
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
        return false
      }
    })
  }

  // GATE2 결재 처리[LAB002_*] - 제품
  const updateGate2Approval = (payload) => {
    return axios({
      url: `/api/${payload.noteTypeNm}/appr/update-gate2-approval`,
      method: 'post',
      data: payload
    })
    .then(async res => {
      const resData = res.data
      if (resData) {
        if (resData.code ===  'fail') {
          openAsyncAlert({ message: resData.message })
          return false
        } else {
          let message = ''
  
          switch (resData.code) {
            case 'ACCEPT_END':
              message = '결재 완료 처리 되었습니다.'
              break;
            case 'APPR_BACK':
              message = '반려하였습니다.'
              break;
            case 'APPR_SUCC':
              message = '결재하였습니다.'
              break;
            case 'MUTUAL_SUCC':
              message = '결재하였습니다.'
              break;
            default:
              break;
          }
  
          store.dispatch('removeApprovalCount')
          await openAsyncAlert({ message })
  
          return true
        }
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
        return false
      }
    })
  }

  // 제품명 확정 결재 처리[LAB_PRDNM_SET] - 제품
  const updateFuncDecideName = (payload) => {
    return axios({
      url: `/api/${payload.noteTypeNm}/appr/update-func-decide-name`,
      method: 'post',
      data: payload
    })
    .then(async res => {
      const resData = res.data
      if (resData) {
        if (resData.code ===  'fail') {
          openAsyncAlert({ message: resData.message })
          return false
        } else {
          let message = ''
  
          switch (resData.code) {
            case 'ACCEPT_END':
              message = '승인하였습니다.'
              break;
            case 'APPR_BACK':
              message = '반려하였습니다.'
              break;
            case 'APPR_SUCC':
              message = '결재하였습니다.'
              break;
            case 'MUTUAL_SUCC':
              message = '결재하였습니다.'
              break;
            default:
              break;
          }
  
          store.dispatch('removeApprovalCount')
          await openAsyncAlert({ message })
  
          return true
        }
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
        return false
      }
    })
  }

  // 사용기한 관리 결재 처리[LAB_NOTE_SHELFLIFE] - 제품, 반제품
  const updateShelfLifeCode = (payload) => {
    return axios({
      url: `/api/appr/update-shelf-life-code`,
      method: 'post',
      data: payload
    })
    .then(async res => {
      const resData = res.data
      if (resData) {
        if (resData.code ===  'fail') {
          openAsyncAlert({ message: resData.message })
          return false
        } else {
          let message = ''
  
          switch (resData.code) {
            case 'ACCEPT_END':
              message = '승인하였습니다.'
              break;
            case 'APPR_BACK':
              message = '반려하였습니다.'
              break;
            case 'APPR_SUCC':
              message = '결재하였습니다.'
              break;
            case 'MUTUAL_SUCC':
              message = '결재하였습니다.'
              break;
            default:
              break;
          }
  
          store.dispatch('removeApprovalCount')
          await openAsyncAlert({ message })
  
          return true
        }
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
        return false
      }
    })
  }

  //의약외품 신고/허가 결재 처리
  const updateReportApproval = (payload) => {
    return axios({
      url: `/api/qdrug/appr/update-report-approval`,
      method: 'post',
      data: payload
    })
    .then(async res => {
      const resData = res.data
      if (resData) {
        if (resData.code ===  'fail') {
          openAsyncAlert({ message: resData.message })
          return false
        } else {
          let message = ''
  
          switch (resData.code) {
            case 'ACCEPT_END':
              message = '승인하였습니다.'
              break;
            case 'APPR_BACK':
              message = '반려하였습니다.'
              break;
            case 'APPR_SUCC':
              message = '결재하였습니다.'
              break;
            case 'MUTUAL_SUCC':
              message = '합의선 작성을 완료하였습니다.'
              break;
            default:
              break;
          }
          store.dispatch('removeApprovalCount')
          await openAsyncAlert({ message })
  
          return true
        }
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
        return false
      }
    })
  }

  return {
    ...toRefs(state),
    noteType,
    noteTypeNm,
    possibleApprClsArr,
    // [METHOD] ===================================
    fnSearchApprovalList,
    fnSearchApprovalFinishList,
    fnOpenOpinionViewPopup,
    fnOpenOpinionWritePopup,
    fnClosePopup,
    fnOpenPopup,
    fnSearchApprovalInfo,
    fnSearchApprovalRequiredInfo,
    fnGoView,
    // [API] ======================================
    findApprovalList,
    findApprovalInfo,
    findReferenceList,
    findApprovalRequiredInfo,
    updateNoteRequest,
    updateBomApproval,
    updateGate2Approval,
    updateFuncDecideName,
    updateShelfLifeCode,
    updateReportApproval
  }
}