import axios from "@/utils/customAxios";
import { reactive, toRefs, inject } from "vue";
import { useRouter } from 'vue-router'
import { useActions } from 'vuex-composition-helpers'
import { useStore } from 'vuex'

export const useNonPrdCommon = () => {
  const t = inject('t')
  const store = useStore()
  const router = useRouter()
  const noteType = store.getters.getNoteType()
  const noteTypeNm = store.getters.getNoteTypeNm()
  const { openAsyncAlert } = useActions(['openAsyncAlert'])
  const state = reactive({
    page: {},
    list: [],
  })

  // 내용물 리스트
  const selectReqList = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/request/select-req-list`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.page = resData.data.page
        state.list = resData.data.list
        return resData.data
      } else {
        state.page = {}
        state.list = []
      }
    })
  }

  // 내용물 상세정보
  const selectReqInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/request/select-nonreq-info`,
      params: payload
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else if (resData.code === 'C9999') {
        await openAsyncAlert({ message: resData.message })
        goList()
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }


  // 내용물 개요 등록 / 수정
  const saveLabNoteRequest = (payload) => {
    return axios({
      method: 'post',     
      url: `/api/${noteTypeNm}/request/save-lab-note-prd-request`,
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  // 예산코드 추가
  const insertLabNotePjtAdd = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/request/insert-lab-note-pjt-add`,
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: resData.message })
      }
    })
  }

  const selectIssueTrackerNoteInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/request/select-issue-tracker-note-info`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  // 과제 등록 / 수정
  const saveLabNoteNonprdRequest = (payload) => {
    return axios({
      method: 'post',     
      url: `/api/${noteTypeNm}/request/save-lab-request-info`,
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const goList = () => {
    router.push({ path: `/${noteTypeNm}/all-lab-note-nonprd-list` })
  }

  const goRegister = () => {
    router.push({ path: `/${noteTypeNm}/all-lab-note-nonprd-register` })
  }

  const goNonprdModify = (vLabNoteCd) => {
    const query = {
      vLabNoteCd: vLabNoteCd
    }
    
    router.push({ path: `/${noteTypeNm}/all-lab-note-nonprd-register`, query: query })
  }

  const goNonprdView = (vLabNoteCd) => {
    const query = {
      vLabNoteCd: vLabNoteCd
    }
    
    router.push({ path: `/${noteTypeNm}/all-lab-note-nonprd-view`, query: query})

  }

  return {
    ...toRefs(state),
    noteType,
    noteTypeNm,
    selectReqList,
    selectReqInfo,
    saveLabNoteRequest,
    insertLabNotePjtAdd,
    selectIssueTrackerNoteInfo,
    saveLabNoteNonprdRequest,
    goList,
    goRegister,
    goNonprdModify,
    goNonprdView,
  }
}