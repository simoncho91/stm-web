import axios from "@/utils/customAxios"
import { inject, ref } from 'vue'
import { useStore } from 'vuex'
import { useActions } from 'vuex-composition-helpers'

export const useMyboardCommon = () => {
  const t = inject('t')
  const store = useStore()
  const noteType = store.getters.getNoteType()
  const noteTypeNm = store.getters.getNoteTypeNm()
  const { openAsyncAlert } = useActions(['openAsyncAlert'])
  const scheduleInfo = ref(null)

  const selectMyNoteList = () => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/myboard/select-my-note-list`,
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectRecentNoteList = () => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/myboard/select-recent-note-list`,
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectSharedNoteList = () => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/myboard/select-shared-note-list`,
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectAssignResearcherList = () => {
    return axios({
      method: 'get',
      url: '/api/skincare/myboard/select-assign-researcher-list',
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectMyBoardAlarmList = () => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-my-board-alarm-list',
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectMyBoardApprovalList = () => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-my-board-approval-list',
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectMyBoardMemoList = () => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-my-board-memo-list',
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const saveMyBoardMemo = (payload) => {
    return axios({
      method: 'post',
      url: '/api/labcommon/save-my-board-memo',
      data: payload,
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const deleteMyBoardMemo = (payload) => {
    return axios({
      method: 'post',
      url: '/api/labcommon/delete-my-board-memo',
      data: payload,
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectScheduleList = () => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/myboard/select-schedule-list`
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        scheduleInfo.value = resData.data
      }
    })
  }

  const selectLaborCurrentStateInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/myboard/select-labor-current-state-info`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      }
    })
  }

  const selectBrandCurrentStateInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/myboard/select-brand-current-state-info`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      }
    })
  }

  const selectExaminationList = () => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/myboard/select-examination-list`,
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      }
    })
  }

  return {
    noteType,
    noteTypeNm,
    scheduleInfo,
    selectMyNoteList,
    selectRecentNoteList,
    selectSharedNoteList,
    selectAssignResearcherList,
    selectMyBoardAlarmList,
    selectMyBoardApprovalList,
    selectMyBoardMemoList,
    saveMyBoardMemo,
    deleteMyBoardMemo,
    selectScheduleList,
    selectLaborCurrentStateInfo,
    selectBrandCurrentStateInfo,
    selectExaminationList,
  }
}