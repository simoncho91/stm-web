import axios from "@/utils/customAxios";
import { reactive, toRefs, inject, ref } from "vue";
import { useRouter } from 'vue-router'
import { useStore } from 'vuex'
import { useActions } from 'vuex-composition-helpers'

export const useMaterialCommon = () => {
  const t = inject('t')
  const store = useStore()
  const router = useRouter()
  const noteTypeNm = store.getters.getNoteTypeNm()
  const { openAsyncAlert } = useActions(['openAsyncAlert', 'openAsyncPopup'])
  const state = reactive({
    page: {},
    list: [],
  })

  const selectMaterialFormulationInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/material/select-material-formulation-info`,
      params: payload,
      isLoading: true,
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else if (resData.code === 'C9999') {
        await openAsyncAlert({ message: resData.message })
        router.push({ path: `/${noteTypeNm}/my-board`})
      }
    })
  }

  const selectMaterialFormulationSum = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/material/select-material-formulation-sum`,
      data: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      }
    })
  }

  const selectMusoguList = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/material/select-musogu-list`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      }
    })
  }

  const selectLabNoteBookmarkList = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/material/select-lab-note-bookmark-list`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.page = resData.data.page
        if (resData.data) {
          state.list = resData.data.list
        } else {
          state.list = []
        }
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNoteMatePlantCheck = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/material/select-lab-note-mate-plant-check`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNoteBookmarkApplyList = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/material/select-lab-note-bookmark-apply-list`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selcetLabNoteMateRateInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/material/select-lab-note-mate-rate-info`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selcetLabNoteVersionList = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/material/select-lab-note-version-list`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNoteContInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/material/select-lab-note-cont-info`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNoteLotList = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/material/select-lab-note-lot-list`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNoteMateRateInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/material/select-lab-note-mate-rate-info`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNoteAllPlantRateAndPrice = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/material/select-lab-note-all-plant-rate-and-price`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNoteSubMateRateInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/material/select-lab-note-sub-mate-rate-info`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectQrCodeElabNoteInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/material/select-qr-code-elab-note-info`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectElabLotMemoList = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/material/select-elab-lot-memo-list`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNoteGramList = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/material/select-lab-note-gram-list`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNoteStabilityTitleAllList = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/material/select-lab-note-stability-title-all-list`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNoteDefaultIngredientData = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/material/select-lab-note-default-ingredient-data`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNoteIngredientList = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/material/select-lab-note-ingredient-list`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNoteBomLotList = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/material/select-lab-note-bom-lot-list`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectMaterialFormulationChange = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/material/select-material-formulation-change`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectSaIngrPermissionList = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/material/select-sa-ingr-permission-list`,
      data: payload,
      isLoading: true,
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const deleteLabNoteLotBookmark = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/material/delete-lab-note-bookmark`,
      data: payload,
      isLoading: true,
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const insertLabNoteCounterSAPInfo = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/material/insert-lab-note-counter-sap-info`,
      data: payload,
      isLoading: true,
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const updateLabNoteMateCheck = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/material/update-lab-note-mate-check`,
      data: payload,
      isLoading: true,
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const updateVersionView = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/material/update-version-view`,
      data: payload,
      isLoading: true,
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const updateLabNoteApplyPlant = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/material/update-lab-note-apply-plan`,
      data: payload,
      isLoading: true,
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const insertLabNoteNewVersion = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/material/insert-lab-note-new-version`,
      data: payload,
      isLoading: true,
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const updateLabNoteLotDecide = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/material/update-lab-note-lot-decide`,
      data: payload,
      isLoading: true,
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const updateLabNoteLotBookmark = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/material/update-lab-note-bookmark`,
      data: payload,
      isLoading: true,
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const updateLabNoteLotBase = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/material/update-lab-note-lot-base`,
      data: payload,
      isLoading: true,
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const insertLabNoteList = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/material/insert-lab-note-list`,
      data: payload,
      isLoading: true,
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }
  
  const insertElabLotMemo = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/material/insert-elab-lot-memo`,
      data: payload,
      isLoading: true,
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }
  
  const insertLabNoteTestResult = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/material/insert-lab-note-test-result`,
      data: payload,
      isLoading: true,
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }
  
  const insertLabNoteStabilityTitle = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/material/insert-lab-note-stability-title`,
      data: payload,
      isLoading: true,
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }
  
  const updateLabNoteToning = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/material/update-lab-note-toning`,
      data: payload,
      isLoading: true,
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }
  
  const updateLabNoteLotSendBom = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/material/update-lab-note-lot-send-bom`,
      data: payload,
      isLoading: true,
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }
  
  const updateMaterialFormulationChange = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/material/update-material-formulation-change`,
      data: payload,
      isLoading: true,
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }
  
  const updateMaterialFormulationExcel = (payload) => {
    const files = payload.files
    const formData = new FormData()
    const len = files.length

    formData.append('file', files[0])
    formData.append('vLabNoteCd', payload.vLabNoteCd)
    formData.append('vContPkCd', payload.vContPkCd)
    formData.append('nVersion', payload.nVersion)
    formData.append('vPlantCd', payload.vPlantCd)
    formData.append('vLand1', payload.vLand1)

    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/material/update-material-formulation-excel`,
      headers: {
        'Content-Type': 'multipart/form-data'
      },
      data: formData,
      isLoading: true,
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectScQrMaterialFormulationInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/skincare/material/select-material-formulation-info`,
      params: payload,
      isLoading: true,
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else if (resData.code === 'C9999') {
        await openAsyncAlert({ message: resData.message })
        router.push({ path: `/skincare/my-board`})
      }
    })
  }

  const selectMuQrMaterialFormulationInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/makeup/material/select-material-formulation-info`,
      params: payload,
      isLoading: true,
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else if (resData.code === 'C9999') {
        await openAsyncAlert({ message: resData.message })
        router.push({ path: `/makeup/my-board`})
      }
    })
  }

  const selectHbdQrMaterialFormulationInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/hbd/material/select-material-formulation-info`,
      params: payload,
      isLoading: true,
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else if (resData.code === 'C9999') {
        await openAsyncAlert({ message: resData.message })
        router.push({ path: `/hbd/my-board`})
      }
    })
  }

  const selectQdrugQrMaterialFormulationInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/qdrug/material/select-material-formulation-info`,
      params: payload,
      isLoading: true,
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else if (resData.code === 'C9999') {
        await openAsyncAlert({ message: resData.message })
        router.push({ path: `/qdrug/my-board`})
      }
    })
  }

  return {
    ...toRefs(state),
    selectMaterialFormulationInfo,
    selectMaterialFormulationSum,
    selectMusoguList,
    selectLabNoteBookmarkList,
    selectLabNoteMatePlantCheck,
    selectLabNoteBookmarkApplyList,
    selcetLabNoteMateRateInfo,
    selcetLabNoteVersionList,
    selectLabNoteContInfo,
    selectLabNoteLotList,
    selectLabNoteMateRateInfo,
    selectLabNoteAllPlantRateAndPrice,
    selectLabNoteSubMateRateInfo,
    selectQrCodeElabNoteInfo,
    selectElabLotMemoList,
    selectLabNoteGramList,
    selectLabNoteStabilityTitleAllList,
    selectLabNoteDefaultIngredientData,
    selectLabNoteIngredientList,
    selectLabNoteBomLotList,
    selectMaterialFormulationChange,
    selectSaIngrPermissionList,
    deleteLabNoteLotBookmark,
    insertLabNoteCounterSAPInfo,
    updateLabNoteMateCheck,
    updateVersionView,
    updateLabNoteApplyPlant,
    insertLabNoteNewVersion,
    updateLabNoteLotDecide,
    updateLabNoteLotBookmark,
    updateLabNoteLotBase,
    insertLabNoteList,
    insertElabLotMemo,
    insertLabNoteTestResult,
    insertLabNoteStabilityTitle,
    updateLabNoteToning,
    updateLabNoteLotSendBom,
    updateMaterialFormulationChange,
    updateMaterialFormulationExcel,
    selectScQrMaterialFormulationInfo,
    selectMuQrMaterialFormulationInfo,
    selectHbdQrMaterialFormulationInfo,
    selectQdrugQrMaterialFormulationInfo,
  }
}