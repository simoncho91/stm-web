import axios from "@/utils/customAxios";
import { reactive, toRefs, inject } from "vue";
import { useRouter } from 'vue-router'
import { useActions } from 'vuex-composition-helpers'
import { useStore } from 'vuex'

export const useTestReqBoardCommon = () => {
  const t = inject('t')
  const store = useStore()
  const router = useRouter()
  const noteType = store.getters.getNoteType()
  const noteTypeNm = store.getters.getNoteTypeNm()
  const { openAsyncAlert } = useActions(['openAsyncAlert'])
  const state = reactive({
    page: {},
    list: [],
  })

  // 내용물 리스트
  const selectTestReqBoardList = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/trboard/select-test-req-board-list`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectQrCodeLabNoteTestList = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/trboard/select-qr-code-lab-note-test-list`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  return {
    ...toRefs(state),
    selectTestReqBoardList,
    selectQrCodeLabNoteTestList,
  }
}

