import axios from "@/utils/customAxios"
import sanitizeHtml from '@/utils/sanitizeHtml'
import { reactive, toRefs, inject, getCurrentInstance } from "vue"
import { useActions } from 'vuex-composition-helpers'
import { useRouter } from 'vue-router'
import { useRoute } from 'vue-router'
import { useStore } from 'vuex'

export const useTestReqCommon = () => {
  const t = inject('t')
  const router = useRouter()
  const route = useRoute()
  const store = useStore()
  const noteType = store.getters.getNoteType()
  const noteTypeNm = store.getters.getNoteTypeNm()
  const app = getCurrentInstance();
  const tiumUrl = app.appContext.config.globalProperties.tiumUrl
  const { openAsyncAlert, openAsyncConfirm, closeAsyncPopup  } = useActions(['openAsyncAlert', 'openAsyncConfirm', 'closeAsyncPopup'])

  const state = reactive({
    params: {
      vLabNoteCd: ''
      , vContPkCd: ''
      , vLotCd: ''
      , vLot: ''
      , vContCd: ''
      , nVersion: ''
      , vPlantCd: ''
      , vMrqTypeCd: ''
      , vGateCd: ''
      , vFlagAction: ''
      , vTrMrqTypeCd: ''
      , vTrGoalCd: ''
      , vDocNo: ''
      , vProductCd: ''
    },
    page: {},
    rvo: {},
    list: [],
    contList: [],
    lotList: [],
    contPkCdList: [],
    arrContPkCd: [],
    isProcessing: false,
  })
  
  // 실험노트 정보 불러오기
    const selectTestReqDetail = (payload) => {
      return axios({
        method: 'get',
        url: `/api/${noteTypeNm}/testreq/select-prd-test-req-func-info`,
        params: payload
      })
      .then(res => {
        const resData = res.data
        if (resData.code === 'C0000') {
          return resData.data
        }
      })
    }

  // 실험노트 무소구 정보 불러오기
  const selectMusoguList = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/testreq/select-prd-test-req-muso-info`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      }
    })
  }

  // 실험노트 무소구 내용물 정보 불러오기
  const selectMusoguContensDetailList = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/testreq/select-ptr-muso-contents-info`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      }
    })
  }
  
  //시험의뢰 - 방부는 따로 작업함(insertPrdTestPreservativeInfo)
  const goSkinTestReqSave = (payload) => {
    if (state.isProcessing) {
      openAsyncAlert({ message: '시험의뢰 진행 중입니다.' })
      return
    }

    state.isProcessing = true

    return axios({
      url: `/api/${noteTypeNm}/testreq/insert-prd-test-req-info`,
      method: 'post',
      data: payload,
      isLoading: true
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'success') {

        if (resData?.data?.simpleVo) {
          state.params = { ...state.params, ...resData.data.simpleVo }
        }

        //post 방식으로 작업해야함 
        let msg = "";
				
				if (resData?.data?.vProductCd) {
					// const html = "대표 내용물 코드 : " + resData.data.vSapCd || '' + "<br/>"
          //   + "Lot : " + resData.data.vLot + "<br/>"
          //   + "의뢰번호 : <span style='color:blue;text-weight:bold;'>" + resData.data.vDocNo + "</span><br/><br/>"
					//   + "위 내용으로 정상적으로 의뢰 되었습니다."
					//   // + "<a href='#' id='btn_link' style='text-decoration:underline;'>[새창에서 의뢰 정보 확인하기]</a> <br/>"
					// msg = html
					msg = `대표 내용물 코드 : ${resData.data.vSapCd || ''}<br/>
                 Lot : ${resData.data.vLot}<br/>
                 의뢰번호 : <span style='color:blue;text-weight:bold;'>${resData.data.vDocNo}</span><br/><br/>
					       위 내용으로 정상적으로 의뢰 되었습니다.`
				}
				else {
					msg = "정상적으로 의뢰 되었습니다.";
				}
        
        const answer = await openAsyncAlert({ message:msg })
        if (!answer) {
          return
        }

        if (resData?.data?.vProductCd) {
          let urlInfo= ""
          if (resData?.data?.vLabMrqTypeCd == "MRQ010") {
            urlInfo = tiumUrl+"/zm/safe/tr/zm_safe_tr_product_v2_view.do"
          }else if(resData?.data?.vLabMrqTypeCd == "MRQ011"){			
            urlInfo = tiumUrl+"/zm/bb/tr/zm_bb_tr_product_view.do"
          }else if(resData?.data?.vLabMrqTypeCd == "MRQ050" || resData?.data?.vLabMrqTypeCd == "MRQ060"){
            urlInfo = tiumUrl+"/zm/tr/zm_tr_product_view.do"
          }else{
            urlInfo= tiumUrl+"/zm/safe/tr/zm_safe_tr_product_view.do"
          }
  
          const targetUrl = urlInfo + "?i_sProductCd=" + resData.data.vProductCd + "&i_iVersion=" + resData.data.nVersion
          //새창
          window.open(targetUrl, "_blank")
        }

        window.location.reload(true)
      } else {
        openAsyncAlert({ message: resData.message })
      }
    })
    .catch(async (error) => {
      await openAsyncAlert({ message: t('common.msg.server_err_msg') })
    })
    .finally(() => {
      state.isProcessing = false
    })
  }
  
  //시험의뢰(효능)
  const goSkinTestReqClinicSave = (payload) => {
    return axios({
      url: `/api/${noteTypeNm}/testreq/insert-prd-test-req-info`,
      method: 'post',
      data: payload,
      isLoading: true
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'success') {
        
        const answer = await openAsyncConfirm({ message:"정상적으로 효능임상 정보가 임시저장 되었습니다.<br/>효능임상 페이지에서 추가 정보를 작성해 주세요." })
        if (!answer) {
          return
        }

        const targetUrl = tiumUrl + "/ct/ct/clinical_test_discuss_renew_reg.do?i_sTempStatusCd=DISCUSS&i_sActionFlag=M&i_sTestCd=" + resData.data
        //새창
        window.open(targetUrl, "_blank")
        closeAsyncPopup({ message: '' })
      } else {
          openAsyncAlert({ message: resData.message })
          return false
      }
    })

  }

  // 실험노트 부향 정보 불러오기
  const selectPrdTestReqFlavorInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/testreq/select-prd-test-req-flavor-info`,
      params: payload
    })
    .then(async (res) => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        await openAsyncAlert({ message: resData.message })
        return false
      }
    })
    .catch(async (error) => {
      await openAsyncAlert({ message: t('common.msg.server_err_msg') })
      return false
    })
  }

  // 실험노트 안전성 정보 불러오기
  const selectPrdTestReqSafetyInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/testreq/select-prd-test-req-safety-info`,
      params: payload
    })
    .then(async (res) => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        await openAsyncAlert({ message: resData.message })
        return false
      }
    })
    .catch(async (error) => {
      await openAsyncAlert({ message: t('common.msg.server_err_msg') })
      return false
    })
  }

  // 실험노트 유해물질 정보 불러오기
  const selectPrdTestReqHarmSubInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/testreq/select-prd-test-req-harm-sub-info`,
      params: payload
    })
    .then(async (res) => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        await openAsyncAlert({ message: resData.message })
        return false
      }
    })
    .catch(async (error) => {
      await openAsyncAlert({ message: t('common.msg.server_err_msg') })
      return false
    })
  }

  // 실험노트 중국 안전성 사전검토 정보 불러오기
  const selectPrdTestReqChinaSafetyReviewInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/testreq/select-prd-test-req-china-safety-review-info`,
      params: payload
    })
    .then(async (res) => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        await openAsyncAlert({ message: resData.message })
        return false
      }
    })
    .catch(async (error) => {
      await openAsyncAlert({ message: t('common.msg.server_err_msg') })
      return false
    })
  }

  // 실험노트 방부 정보 불러오기
  const selectPrdTestReqPreservativeInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/testreq/select-prd-test-req-preservative-info`,
      params: payload
    })
    .then(async (res) => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        await openAsyncAlert({ message: resData.message })
        return false
      }
    })
    .catch(async (error) => {
      await openAsyncAlert({ message: t('common.msg.server_err_msg') })
      return false
    })
  }

  // 내용물 버젼별 LOT 리스트 조회
  const selectTestReqLotList = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/testreq/select-test-req-lot-list`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      }
    })
  }

  // Lot 별 방부 저장값 가져오기
  const selectLabNotePrsvList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/testreq/comm/select-lab-note-prsv-list',
      params: payload
    })
    .then(async (res) => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      }
    })
  } 

  //시험의뢰(방부)
  const insertPrdTestPreservativeInfo = (payload) => {
    return axios({
      url: `/api/${noteTypeNm}/testreq/insert-prd-test-preservative-info`,
      method: 'post',
      data: payload,
      isLoading: true
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: resData.message })
      }
    })
    .catch(async (error) => {
      await openAsyncAlert({ message: t('common.msg.server_err_msg') })
    })
  }

  const selectLabNotePrdMrq011MailPop = (payload) => {
    return axios({
      method : 'get',
      url: `/api/${noteTypeNm}/testreq/select-lab-note-prd-mrq011-mail-pop`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  //방부처방 메일 전송
  const sendLabNotePrdMrq011Mail = (payload) => {
    return axios({
      url: `/api/${noteTypeNm}/testreq/send-lab-note-prd-mrq011-mail`,
      method: 'post',
      data: payload,
      isLoading: true
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: resData.message })
      }
    })
    .catch(async (error) => {
      await openAsyncAlert({ message: t('common.msg.server_err_msg') })
    })
  }

  return {
    ...toRefs(state),
    goSkinTestReqSave,
    goSkinTestReqClinicSave,
    selectTestReqDetail,
    selectMusoguList,
    selectMusoguContensDetailList,
    selectPrdTestReqFlavorInfo,
    selectPrdTestReqSafetyInfo,
    selectPrdTestReqHarmSubInfo,
    selectPrdTestReqChinaSafetyReviewInfo,
    selectTestReqLotList,
    noteType,
    noteTypeNm,
    selectPrdTestReqPreservativeInfo,
    selectLabNotePrsvList,
    insertPrdTestPreservativeInfo,
    selectLabNotePrdMrq011MailPop,
    sendLabNotePrdMrq011Mail
  }
}