import axios from "@/utils/customAxios";
import { reactive, toRefs, inject, ref } from "vue";
import { useRoute } from 'vue-router'
import { useStore } from 'vuex'
import { useActions } from 'vuex-composition-helpers'

export const useProcessCommon = () => {
  const t = inject('t')
  const route = useRoute()
  const store = useStore()
  const noteType = store.getters.getNoteType()
  const noteTypeNm = store.getters.getNoteTypeNm()
  const { openAsyncAlert, openAsyncPopup, closeAsyncPopup } = useActions(['openAsyncAlert','openAsyncPopup', 'closeAsyncPopup'])
  const state = reactive({
    progressInfo: [],
    tabList: [],
    popupContent : null,
    popParams: {},
    popSelectFunc : null,
    popCloseFunc : null,
    flagCancel: '',
  })

  const funcContList = reactive({
    resVo : {
      vFlagSaveAction : '',
      vNoteType : '',
      vLabNoteCd : '',
      vStatusCd : '',
      nFdnVer : '',
      vFdnStatusCd : '',
      vFlagNameModAuth : '',
    },
    apprList : [],
    nameList : []
  })

  const apiParam = reactive({
    searchParams: {
      vNoteType : noteType,
      vLabNoteCd : route.query.vLabNoteCd || '',
      vRequestStDt : '',
      vRequestEdDt : '',
      vFinishStDt : '',
      vFinishEdDt : '',
      vApprStatus : '',
      vKeyword : '',
      nowPageNo: 1,
      vEffectStDT: '',
      vEffectEdDT: '',
      vReStDt: '',
      vReEndDt: '',
      vCoStDt: '',
      vCoEndDt: '',
    },
    page: {},
    list: [],
  })

  const selectProgressBar = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/process/select-progress-bar`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      }else{
        openAsyncAlert({ message: resData.message })
      }
    })
  }

  const selectProgressInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/process/select-progress-info`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.progressInfo = resData.data.progressInfo
        state.tabList = resData.data.tabList
        state.flagCancel = resData.data.vFlagCancel
      }else{
        openAsyncAlert({ message: resData.message })
      }
    })
  }

  const selectTimeLineList = (payload) => {
    return axios({
      method: 'get',
      url : `/api/${noteTypeNm}/process/select-timeline-list`,
      params : payload
    })
    .then(res => {
      const resData = res.data
      if(resData.code === 'C0000'){
        return resData.data
      }else{
        openAsyncAlert({ message: resData.message })
      }
    })
  }

  const fnSearchFuncDecideNameList = (pg) => {
    if(!pg){
      pg = 1
    }

    apiParam.searchParams.nowPageNo = pg
    
    const payload = Object.assign({}, apiParam.searchParams)
    payload.vRequestStDt = payload.vRequestStDt.replaceAll('.', '')
    payload.vRequestEdDt = payload.vRequestEdDt.replaceAll('.', '')
    payload.vFinishStDt = payload.vFinishStDt.replaceAll('.', '')
    payload.vFinishEdDt = payload.vFinishEdDt.replaceAll('.', '')

    selectFuncDecideNameList(payload)
  }

  const selectFuncDecideNameList = (payload) => {
    return axios({
      method : 'get',
      url : `/api/${noteTypeNm}/process/select-func-decide-name-list`,
      params : payload
    })
    .then(res => {
      const resData = res.data
      if(resData.code === 'C0000'){
        apiParam.page = resData.data.page
        apiParam.list = resData.data.list ? convertDecideNameList(resData.data.list) : null
      }else{
        openAsyncAlert({ message: resData.message })
      }
    })
  }
  
  const convertDecideNameList = (list) => {
    const rowList = ref([])
    if(list.length > 0){
      list.some(item => {
        if(rowList.value.filter(vo => vo.nFdnVer === item.nFdnVer).length > 0){
          return false
        }

        const obj = {
          nFdnVer : '',
          fdnList : []
        }

        obj.nFdnVer = item.nFdnVer
        obj.fdnList = [...list.filter(vo => vo.nFdnVer === item.nFdnVer)]

        rowList.value.push(obj);
      })

    }
    return rowList
  }

  const selectLabContList = () =>{
    return axios({
      method : 'get',
      url : `/api/${noteTypeNm}/process/select-lab-cont-list`,
      params : {vLabNoteCd : route.query.vLabNoteCd || ''}
    })
    .then(res => {
      const resData = res.data
      if(resData.code === 'C0000'){
        funcContList.resVo = resData.data.resVo
        funcContList.apprList = resData.data.apprList
        funcContList.nameList = resData.data.nameList
      }else{
        openAsyncAlert({ message: resData.message })
      }
    })
  }

  const selectLabNoteFuncDecideContName = (payload) =>{
    return axios({
      method : 'get',
      url : `/api/${noteTypeNm}/process/select-func-decide-cont-name`,
      params : payload
    })
    .then(res => {
      const resData = res.data
      if(resData.code === 'C0000'){
        funcContList.resVo = resData.data.resVo
        funcContList.apprList = resData.data.apprList
        funcContList.nameList = resData.data.savedNameList
      }else{
        openAsyncAlert({ message: resData.message })
      }
    })
  }

  const saveFuncDecideName = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/process/save-func-decide-name`,
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const fnSearchFuncTestEpReportList = (pg) => {
    if(!pg){
      pg = 1
    }

    apiParam.searchParams.nowPageNo = pg
    
    const payload = Object.assign({}, apiParam.searchParams)
    payload.vRequestStDt = payload.vRequestStDt.replaceAll('.', '')
    payload.vRequestEdDt = payload.vRequestEdDt.replaceAll('.', '')
    payload.vFinishStDt = payload.vFinishStDt.replaceAll('.', '')
    payload.vFinishEdDt = payload.vFinishEdDt.replaceAll('.', '')

    selectFuncTestEpReportList(payload)
  }

  const selectFuncTestEpReportList = (payload) => {
    return axios({
      method : 'get',
      url : `/api/${noteTypeNm}/process/select-func-test-epreport-list`,
      params : payload
    })
    .then(res => {
      const resData = res.data
      if(resData.code === 'C0000'){
        apiParam.page = resData.data.page
        apiParam.list = resData.data.list
      }else{
        openAsyncAlert({ message: resData.message })
      }
    })
  }

  const fnOpenPopup = (compNm, isScroll = true) => {
    state.popupContent = null
    state.popupContent = compNm

    const payload = { isScroll }
    
    openAsyncPopup(payload)
      .then(res => {
      })
      .catch(err => {
        console.log(err)
      })
      .finally(() => {
        state.popupContent = null
      })
  }

  const fnClosePopup = (returnObj) => {
    closeAsyncPopup(returnObj)
  }

  const selectLabNoteFuncRequestQA = (payload) => {
    return axios({
      method : 'get',
      url : `/api/${noteTypeNm}/process/select-labnote-func-request-qa`,
      params : payload
    })
    .then(res => {
      const resData = res.data
      if(resData.code === 'C0000'){
        return resData.data
      }else{
        openAsyncAlert({ message: resData.message })
      }
    })
  }

  const fnUploadSave = (payload) => {
    return axios({
      url: `/api/${noteTypeNm}/process/save-upload-func-report-file`,
      method: 'post',
      data: payload,
      isLoading: true
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        openAsyncAlert({ message: t('common.msg.save_succ') })
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectFuncTestEpReportReg = (payload) => {
    return axios({
      method : 'get',
      url : `/api/${noteTypeNm}/process/select-func-test-epreport-reg`,
      params : payload
    })
    .then(res => {
      const resData = res.data
      if(resData.code === 'C0000'){
        return resData.data
      }else{
        openAsyncAlert({ message: resData.message })
      }
    })
  }

  // 전성분 조회(조회 전 기본정보 선택)
  // 전성분 승인 리스트 에서 '등록'버튼 눌렀을 때
  // 팝업에서 필요한 데이터 가져옴
  // SkincareMaterialController - selectLabNoteDefaultIngredientData
  // 에 기존 정의되어 있는데, useSkinMaterial.js 에
  // API가 정의되어 있지 않으므로 임시로 해놓음.
  const selectLabNoteDefaultIngredientData = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/material/select-lab-note-default-ingredient-data`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      }
    })
  }

  const selectLabNoteMixCheckList = (payload) => {
    return axios({
      method : 'get',
      url : `/api/${noteTypeNm}/process/select-lab-note-mix-check`,
      params : payload
    })
    .then(res => {
      const resData = res.data
      if(resData.code === 'C0000'){
        return 'SUCC'
      }else{
        return resData.message
      }
    })
  }

  const selectGroupUserList = (payload) => {
    return axios({
      method : 'get',
      url : `/api/${noteTypeNm}/process/select-group-user-list`,
      params : payload
    })
    .then(res => {
      const resData = res.data
      if(resData.code === 'C0000'){
        return resData.data
      }else{
        openAsyncAlert({ message: resData.message })
      }
    })
  }

  const saveLabNoteSendFuncMail = (payload) => {
    return axios({
      method : 'post',
      url : `/api/${noteTypeNm}/process/save-lab-note-send-func-mail`,
      data : payload
    })
    .then(res => {
      const resData = res.data
      if(resData.code === 'C0000'){
        return 'SUCC'
      }else{
        openAsyncAlert({ message: resData.message })
      }
    })
  }

  const updateNoteRefNote = (payload) => {
    return axios({
      method : 'post',
      url : `/api/${noteTypeNm}/process/update-note-ref-note`,
      data : payload
    })
    .then(res => {
      const resData = res.data
      if(resData.code === 'C0000'){
        return 'SUCC'
      }else{
        openAsyncAlert({ message: resData.message })
      }
    })
  }

  const selectLabNoteContDecideList = (payload) => {
    return axios({
      method : 'get',
      url : `/api/${noteTypeNm}/process/select-lab-note-cont-decide-list`,
      params : payload
    })
    .then(res => {
      const resData = res.data
      if(resData.code === 'C0000'){
        return resData.data
      }else{
        openAsyncAlert({ message: resData.message })
      }
    })
  }

  const selectLabNoteGate2Reg = (payload) => {
    return axios({
      method : 'get',
      url : `/api/${noteTypeNm}/process/select-lab-note-gate2-reg`,
      params : payload
    })
    .then(res => {
      const resData = res.data
      if(resData.code === 'C0000'){
        return resData.data
      }else{
        openAsyncAlert({ message: resData.message })
      }
    })
  }

  const selectLabNotePilotList = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/process/select-lab-note-pilot-list`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        if (resData.data) {
          apiParam.list = resData.data.list
          apiParam.page = resData.data.page
        } else {
          apiParam.list = []
          apiParam.page = {}
        }
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNotePilotReqInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/process/select-lab-note-pilot-req-info`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNoteBomMateRateInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/process/select-lab-note-bom-mate-rate-info`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const saveLabNoteMassAppr = (payload) => {
    return axios({
      method : 'post',
      url : `/api/${noteTypeNm}/process/save-lab-note-mass-appr`,
      data : payload
    })
    .then(res => {
      const resData = res.data
      if(resData.code === 'C0000'){
        return 'SUCC'
      }else{
        openAsyncAlert({ message: resData.message })
      }
    })
  }

  const updateLabNoteMassPass = (payload) => {
    return axios({
      method : 'post',
      url : `/api/${noteTypeNm}/process/update-lab-note-mass-pass`,
      data : payload
    })
    .then(res => {
      const resData = res.data
      if(resData.code === 'C0000'){
        return 'SUCC'
      }else{
        openAsyncAlert({ message: resData.message })
      }
    })
  }

  const selectLabNotePilotRegInitInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/process/select-lab-note-pilot-reg-init-info`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNotePilotRegInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/process/select-lab-note-pilot-reg-info`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNotePilotRegVersionLotList = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/process/select-lab-note-pilot-reg-version-lot-list`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNoteBomSendList = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/process/select-lab-note-bom-send-list`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        apiParam.list = resData.data.list
        apiParam.page = resData.data.page
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
        apiParam.list = []
        apiParam.page = {}
      }
    })
  }

  const selectLabNoteGate2View = (payload) => {
    return axios({
      method : 'get',
      url : `/api/${noteTypeNm}/process/select-lab-note-gate2-view`,
      params : payload
    })
    .then(res => {
      const resData = res.data
      if(resData.code === 'C0000'){
        return resData.data
      }else{
        openAsyncAlert({ message: resData.message })
      }
    })
  }

  const saveLabNoteGate01 = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/process/save-lab-note-gate01`,
      data: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNoteFormulaDecideList = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/process/select-lab-note-formula-decide-list`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectIngrdCompareInfo = (payload) => {
    return axios({
      method : 'get',
      url : `/api/${noteTypeNm}/process/select-ingrd-compare-info`,
      params : payload
    })
    .then(async (res) => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        await openAsyncAlert({ message: resData.message })
        return false
      }
    })
    .catch(async (error) => {
      await openAsyncAlert({ message: t('common.msg.server_err_msg') })
      return false
    })
  }

  const selectIngrdApprovalList = (payload) => {
    return axios({
      method : 'get',
      url : `/api/${noteTypeNm}/process/select-ingrd-approval-list`,
      params : payload
    })
    .then(res => {
      const resData = res.data
      if(resData.code === 'C0000'){
        apiParam.page = resData.data.page
        apiParam.list = resData.data.list
      }else{
        let message = t('common.msg.server_err_msg')

        if (resData.message) {
          message = resData.message
        }

        openAsyncAlert({ message: message })
      }
    })
    .catch(error => {
      openAsyncAlert({ message: t('common.msg.server_err_msg') })
    })
  }

  const selectIngrdApprovalRegRequiredInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/process/select-ingrd-approval-required-info`,
      params: payload,
      isLoading: true
    })
    .then(async (res) => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        const payload = { message: resData.message }

        if (resData.code === 'exist_not_reg_matr') {
          payload.textAlign = 'left'
        }

        await openAsyncAlert(payload)
        return false
      }
    })
    .catch(async (error) => {
      await openAsyncAlert({ message: t('common.msg.server_err_msg') })
      return false
    })
  }

  const insertIngrdApproval = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/process/insert-ingrd-approval`,
      data: payload,
      isLoading: true
    })
    .then(async (res) => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        let message = t('common.msg.server_err_msg')

        if (resData.message) {
          message = resData.message
        }

        await openAsyncAlert({ message: message })
        return 'FAIL'
      }
    })
    .catch(async (error) => {
      await openAsyncAlert({ message: t('common.msg.server_err_msg') })
      return 'FAIL'
    })
  }

  const selectIngrdApprovalInfo = (payload) => {
    return axios({
      method : 'get',
      url : `/api/${noteTypeNm}/process/select-ingrd-approval-info`,
      params : payload
    })
    .then(async (res) => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        await openAsyncAlert({ message: resData.message })
        return false
      }
    })
    .catch(async (error) => {
      await openAsyncAlert({ message: t('common.msg.server_err_msg') })
      return false
    })
  }

  const insertNoteIngr = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/process/insert-note-ingr`,
      data: payload,
      isLoading: true
    })
    .then(async (res) => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        let message = t('common.msg.server_err_msg')

        if (resData.message) {
          message = resData.message
        }

        await openAsyncAlert({ message: message })
        return 'FAIL'
      }
    })
    .catch(async (error) => {
      await openAsyncAlert({ message: t('common.msg.server_err_msg') })
      return 'FAIL'
    })
  }

  const selectEvReportProdListPop = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/process/select-ev-report-prod-list-pop`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const sendBomFreePass = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/process/send-bom-free-pass`,
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data

      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectFuncTestEpReportView = (payload) => {
    return axios({
      method : 'get',
      url : `/api/${noteTypeNm}/process/select-func-test-epreport-view`,
      params : payload
    })
    .then(res => {
      const resData = res.data
      if(resData.code === 'C0000'){
        return resData.data
      }else{
        openAsyncAlert({ message: resData.message })
      }
    })
  }

  const selectGate1ApprDetailInfo = (payload) => {
    return axios({
      method : 'get',
      url: '/api/skincare/process/select-gate1-appr-detail-info',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNoteFuncDecideNameInfo = (payload) => {
    return axios({
      method : 'get',
      url: `/api/${noteTypeNm}/process/select-lab-note-func-decide-name-info`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const saveLabNoteGate02ApprovalRequest = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/process/save-lab-note-gate02-approval-request`,
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const savePrescribeConfirm = (payload) => {
    return axios({
      method: 'post',
      url: '/api/skincare/process/save-prescribe-confirm',
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectSaNoteEpReportList = (payload) => {
    return axios({
      method : 'get',
      url : `/api/${noteTypeNm}/process/select-sa-note-ep-report-list`,
      params : payload
    })
    .then(res => {
      const resData = res.data
      if(resData.code === 'C0000'){
        apiParam.page = resData.data.page
        apiParam.list = resData.data.list
      }else{
        let message = t('common.msg.server_err_msg')

        if (resData.message) {
          message = resData.message
        }

        openAsyncAlert({ message: message })
      }
    })
    .catch(error => {
      openAsyncAlert({ message: t('common.msg.server_err_msg') })
    })
  }

  const selectSaNoteEpReportReg = (payload) => {
    return axios({
      method : 'get',
      url: `/api/${noteTypeNm}/process/select-sa-note-ep-report-reg`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectSaNoteEpReportView = (payload) => {
    return axios({
      method : 'get',
      url: `/api/${noteTypeNm}/process/select-sa-note-ep-report-view`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectSaNoteContentTablePop = (payload) => {
    return axios({
      method : 'get',
      url: `/api/${noteTypeNm}/process/select-sa-note-content-table-pop`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectSaNoteContentTableExcel = (payload) => {
    return axios({
      method : 'get',
      url: `/api/${noteTypeNm}/process/select-sa-note-content-table-excel`,
      params: payload,
      responseType: 'blob'
    })
    .then(res => {
      let name = res.headers['filename']
      const contentDisposition = res.headers['content-disposition'] || ''
      if(contentDisposition){
        name = decodeURIComponent(name)
      }

      const blob = new Blob([res.data], { type: res.headers['content-type'] })
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', name)
      link.style.cssText = 'display:none'
      document.body.appendChild(link)
      link.click()
      link.remove()
      window.URL.revokeObjectURL(url)
    })
  }
  const selectSaNoteContSearchList = (payload) => {
    return axios({
      method : 'get',
      url: `/api/${noteTypeNm}/process/select-sa-note-cont-search-list`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const saveSaNoteEpReport = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/process/save-sa-note-ep-report`,
      data: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectQmsInfo = (payload) => {
    return axios({
      url: `/api/${noteTypeNm}/process/select-qms-info`,
      method: 'get',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectQmsPlantList = (payload) => {
    return axios({
      url: `/api/${noteTypeNm}/process/select-qms-plant-list`,
      method: 'get',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const checkValidationPilot = (payload) => {
    return axios({
      url: `/api/${noteTypeNm}/process/check-validation-pilot`,
      method: 'post',
      data: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNoteBomMateView = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/process/select-lab-note-bom-mate-view`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectAerosolDecideList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/hbd/process/select-aerosol-decide-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const saveAerosolFormulaDecide = (payload) => {
    return axios({
      method: 'post',
      url: '/api/hbd/process/save-aerosol-formula-decide',
      data: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectCreateMayContainRequiredInfo = (payload) => {
    return axios({
      url: `/api/${noteTypeNm}/process/select-create-may-contain-required-info`,
      method: 'post',
      data: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const insertMayContain = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/process/insert-may-contain`,
      data: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectMayContainList = (payload) => {
    return axios({
      url: `/api/${noteTypeNm}/process/select-may-contain-list`,
      method: 'get',
      isLoading: true,
      params: payload
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        apiParam.page = resData.data.page
        apiParam.list = resData.data.list
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const insertMayContainCloneSucc = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/process/insert-may-contain-clone-succ`,
      data: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  return {
    ...toRefs(state),
    ...toRefs(apiParam),
    ...toRefs(funcContList),
    selectProgressInfo,
    selectTimeLineList,
    selectFuncDecideNameList,
    fnSearchFuncDecideNameList,
    noteType,
    noteTypeNm,
    selectLabContList,
    selectProgressBar,
    saveFuncDecideName, 
    selectLabNoteFuncDecideContName,
    fnSearchFuncTestEpReportList,
    selectFuncTestEpReportList,
    fnOpenPopup,
    fnClosePopup,
    selectLabNoteFuncRequestQA,
    fnUploadSave,
    selectFuncTestEpReportReg,
    selectLabNoteDefaultIngredientData,
    selectLabNoteMixCheckList,
    selectGroupUserList,
    saveLabNoteSendFuncMail,
    updateNoteRefNote,
    selectLabNoteContDecideList,
    selectLabNoteGate2Reg,
    selectLabNotePilotList,
    selectLabNotePilotReqInfo,
    selectLabNoteBomMateRateInfo,
    saveLabNoteMassAppr,
    updateLabNoteMassPass,
    selectLabNotePilotRegInitInfo,
    selectLabNotePilotRegInfo,
    selectLabNotePilotRegVersionLotList,
    selectLabNoteBomSendList,
    selectLabNoteGate2View,
    saveLabNoteGate01,
    savePrescribeConfirm,
    selectLabNoteFormulaDecideList,
    selectIngrdCompareInfo,
    selectIngrdApprovalList,
    selectIngrdApprovalRegRequiredInfo,
    insertIngrdApproval,
    selectIngrdApprovalInfo,
    insertNoteIngr,
    selectEvReportProdListPop,
    sendBomFreePass,
    selectFuncTestEpReportView,
    selectGate1ApprDetailInfo,
    selectLabNoteFuncDecideNameInfo,
    saveLabNoteGate02ApprovalRequest,
    selectSaNoteEpReportList,
    selectSaNoteEpReportReg,
    selectSaNoteEpReportView,
    selectSaNoteContentTablePop,
    selectSaNoteContentTableExcel,
    selectSaNoteContSearchList,
    saveSaNoteEpReport,
    selectQmsInfo,
    selectQmsPlantList,
    checkValidationPilot,
    selectAerosolDecideList,
    saveAerosolFormulaDecide,
    selectLabNoteBomMateView,
    selectCreateMayContainRequiredInfo,
    insertMayContain,
    selectMayContainList,
    insertMayContainCloneSucc,
  }
}