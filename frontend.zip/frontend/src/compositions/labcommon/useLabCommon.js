import axios from "@/utils/customAxios";
import { reactive, toRefs, inject } from "vue";
import { useActions } from 'vuex-composition-helpers'
import { useRouter } from 'vue-router'
import { useStore } from 'vuex'

export const useLabCommon = () => {
  const t = inject('t')
  const store = useStore()
  const router = useRouter()
  const noteTypeNm = store.getters.getNoteTypeNm()
  const noteType = store.getters.getNoteType()
  const myInfo = store.getters.getMyInfo()
  const commonUtils = inject('commonUtils')
  const { openAsyncAlert, openAsyncPopup } = useActions(['openAsyncAlert', 'openAsyncPopup'])
  const state = reactive({
    page: {},
    list: [],
    tddProdType1List: [],
    tddProdType2List: [],
    popupContent: null,
    popParams: {},
    popSelectFunc: null,
    popCloseFunc: null,
    releaseMap: {
      'ASIA': {
        ariaNm: '아시아',
        countryList: []
      },
      'ASEAN': {
        ariaNm: '아세안',
        countryList: []
      },
      'ETC': {
        ariaNm: '기타',
        countryList: []
      }
    },
  })

  const goMyboard = () => {
    router.push({ path: `/${noteTypeNm}/my-board` })
  }

  const selectPtsProjectList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-pts-pjt-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.page = resData.data.page
        if (resData.data) {
          state.list = resData.data.list
        } else {
          state.list = []
        }
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectTddProdTypeList = (payload, listFlag) => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-tdd-prod-type-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        const resultList = resData.data

        if (resultList && resultList.length > 0) {
          if (listFlag === 'TYPE1') {
            state.tddProdType1List = resultList
          } else {
            state.tddProdType2List = resultList
          }
        }
      }
    })
  }

  const selectSearchMateList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-search-mate-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.page = resData.data.page
        if (resData.data) {
          state.list = resData.data.list
        } else {
          state.list = []
        }
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectSearchMateAutocompleteList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-search-mate-autocomplete-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectSearchMateTempList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-search-mate-temp-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.page = resData.data.page
        if (resData.data) {
          state.list = resData.data.list
        } else {
          state.list = []
        }
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectSearchMyMateList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-search-my-mate-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.page = resData.data.page
        if (resData.data) {
          state.list = resData.data.list
          return resData.data.list
        } else {
          state.list = []
        }
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectSearchProdList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-search-prod-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.page = resData.data.page
        if (resData.data) {
          state.list = resData.data.list
        } else {
          state.list = []
        }
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectEvaluationList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-evaluation-list',
      params: payload,
      paramsSerializer: paramsObj => {
        const params = new URLSearchParams()
        for (const key in paramsObj) {
          if (Array.isArray(paramsObj[key]) && paramsObj[key].length === 0) {
            continue
          }
          params.append(key, paramsObj[key])
        }
        return params.toString()
      }
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.page = resData.data.page
        if (resData.data) {
          state.list = resData.data.list
        } else {
          state.list = []
        }
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectEvaluationMaterialList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-evaluation-material-list',
      params: payload,
      paramsSerializer: paramsObj => {
        const params = new URLSearchParams()
        for (const key in paramsObj) {
          if (Array.isArray(paramsObj[key]) && paramsObj[key].length === 0) {
            continue
          }
          params.append(key, paramsObj[key])
        }
        return params.toString()
      }
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectCheckClearList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-check-clear-list',
      params: payload,
      paramsSerializer: paramsObj => {
        const params = new URLSearchParams()
        for (const key in paramsObj) {
          if (Array.isArray(paramsObj[key]) && paramsObj[key].length === 0) {
            continue
          }
          params.append(key, paramsObj[key])
        }
        return params.toString()
      }
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        const list = resData.data

        if (list && list.length > 0) {
          const arrHtml = []
          arrHtml.push('[주의]')
          if (list.lengt === 1) {
            arrHtml.push('<span style=\'font-weight: bold;\'>' + list[0].vSapCd + '</span>는 아래 기간동안 \'일시적으로 금지 해제\'된 원료입니다.')
            arrHtml.push('<span style=\'font-weight: bold;\'>일시적 금지 해제 기간 ' + list[0].vResearchSDt + '~' + list[0].vResearchEDt + '</span>')
          } else {
            list.forEach(item => {
              arrHtml.push('<span style=\'font-weight: bold;\'>해당 원료들은 아래 기간동안 \'일시적으로 금지 해제\'된 원료입니다.')
              arrHtml.push('<span style=\'font-weight: bold;\'>[' + item.vSapCd + ']' + item.vResearchSDt + '~' + item.vResearchEDt + '</span>')
            })
          }

          arrHtml.push('사용시 주의하세요.')
          return arrHtml.join('<br>')
        } else {
          return ''
        }
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const updateSAPRepeat = (payload) => {
    return axios({
      method: 'post',
      url: '/api/labcommon/update-sap-repeat',
      data: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const updateRefreshMatnr = (payload) => {
    return axios({
      method: 'post',
      url: '/api/labcommon/update-refresh-matnr',
      data: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
        return 'FAIL'
      }
    })
  }

  const selectMdlRequiredMaxList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-mdl-required-max-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const insertHal4Mate = (payload) => {
    return axios({
      method: 'post',
      url: '/api/labcommon/insert-hal4-mate',
      data: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
        return 'FAIL'
      }
    })
  }

  const selcetScmTcodeList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-scm-tcode-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectZplmt12List = (payload) => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-zplmt12-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNoteMaxMixMrqList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-lab-note-max-mix-mrq-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectOneShelfLifeContList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-one-shelf-life-cont-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabCodeRequired = (payload) => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-lab-code-required',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNoteAuthorityList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-lab-note-authority-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.page = resData.data.page
        state.list = resData.data.list
      } else {
        state.page = {}
        state.list = []
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const deleteLabNoteAuthority = (payload) => {
    return axios({
      method: 'post',
      url: '/api/labcommon/delete-lab-note-authority',
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const insertLabNoteAuthority = (payload) => {
    return axios({
      method: 'post',
      url: '/api/labcommon/insert-lab-note-authority',
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNoteShelfLifeInfo = (payload) => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-lab-note-shelf-life-info',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const updateLabNoteShelfLifeInfo = (payload) => {
    return axios({
      method: 'post',
      url: '/api/labcommon/update-lab-note-shelf-life-info',
      data: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        // success
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
        return 'fail'
      }
    })
  }

  const insertCommIssuetrack = (payload) => {
    return axios({
      method: 'post',
      url: '/api/issuecommon/insert-comm-issuetrack',
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectCommIssuetrackList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/issuecommon/select-comm-issuetrack-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectMatrMixreInfo = (payload) => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-matr-mixre-info',
      params: payload
    })
    .then(async (res) => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        await openAsyncAlert({ message: t('common.msg.server_err_msg') })
        return false
      }
    })
    .catch(async (error) => {
      await openAsyncAlert({ message: t('common.msg.server_err_msg') })
      return false
    })
  }

  const insertElabNoteLatestBomInfo = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/common/insert-elab-note-latest-bom-info`,
      data: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const updateLabNoteLotDecide = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/common/update-lab-note-lot-decide`,
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const updateDecideCancel = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/common/update-decide-cancel`,
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectOneShelfLifeContInfo = (payload) => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-one-shelf-life-cont-info',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNoteMateRateInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/common/select-lab-note-mate-rate-info`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNoteInfoCheckAuth = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/common/select-lab-note-info-check-auth`,
      params: payload
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else if (resData.code === 'C9999') {
        await openAsyncAlert({ message: resData.message })
        goMyboard()
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLotStatusList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-lot-status-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const fnOpenMateSearchPop = (keyword, flagSearchInit, popSelectFunc, defaultTab) => {
    const noteInfo = store.getters.getNoteInfo()
    const noteType = store.getters.getNoteType()
    const plantCd = noteInfo.vPlantCd
    const siteType = noteInfo.vSiteType
    const labNoteCd = noteInfo.vLabNoteCd

    if (commonUtils.isEmpty(plantCd)) {
      openAsyncAlert({ message: '플랜트를 선택해 주세요.' })
      return
    }

    state.popParams = {
      vKeyword: keyword,
      vPlantCd: plantCd,
      vSiteType: siteType,
      vFlagSearchInit: flagSearchInit,
      vLabNoteCd: labNoteCd,
      vDefaultTab: defaultTab || 'sapSearch',
      vNoteType: noteType
    }

    state.popSelectFunc = popSelectFunc
    fnOpenPopup('MateSearchPop', false)
  }

  const fnChangeNoteInfo = (noteInfo) => {
    store.dispatch('setNoteInfo', {...noteInfo})
  }

  const showAddVerBtn = (info) => {
    let isVisible = false

    if (info.verList && info.verList.length > 0) {
      const lastVerInfo = info.verList[info.verList.length - 1]

      if (lastVerInfo.vFlagModify === 'N') {
        isVisible = true
      }
    }

    return isVisible
  }

  const resetMateList = (flag, verParams, listKey) => {
    if (flag !== 'Y') {
      verParams[listKey] = []
    }
  }

  const changeCounterTypeCd = (verParams, typeCd) => {
    let arrClearKey = []
    if (typeCd === 'LNC04_01') {
      arrClearKey = ['vCounterBrdNm', 'vCounterPrdNm', 'vCounterSpInfo', 'vPrePilotDt', 'vSsrid']
    } else if (typeCd === 'LNC04_02') {
      arrClearKey = ['vCounterNmTemp', 'vCounterCd', 'vCounterContPkCd', 'vCounterInvenCd', 
                  'vCounterInvenJoinCd', 'vCounterSpInfo', 'vPrePilotDt', 'vSsrid']
    } else if (typeCd === 'LNC04_03') {
      arrClearKey = ['vCounterNmTemp', 'vCounterCd', 'vCounterContPkCd', 'vCounterInvenCd', 
                    'vCounterInvenJoinCd', 'vCounterBrdNm', 'vCounterPrdNm', 'vSsrid']
    } else if (typeCd === 'LNC04_04') {
      arrClearKey = ['vCounterNmTemp', 'vCounterCd', 'vCounterContPkCd', 'vCounterInvenCd', 
                    'vCounterInvenJoinCd', 'vCounterBrdNm', 'vCounterPrdNm', 'vCounterSpInfo', 'vPrePilotDt']
    } else {
      arrClearKey = ['vCounterNmTemp', 'vCounterCd', 'vCounterContPkCd', 'vCounterInvenCd',
                    'vCounterInvenJoinCd', 'vCounterBrdNm', 'vCounterPrdNm', 'vCounterSpInfo', 'vPrePilotDt', 'vSsrid']
    }

    arrClearKey.forEach(key => {
      verParams[key] = ''
    })
  }

  const fnOpenPopup = (compNm, isScroll = true) => {
    state.popupContent = null
    state.popupContent = compNm

    const payload = {
      isScroll
    }

    openAsyncPopup(payload)
      .then(res => {
      })
      .catch(err => {
        console.log(err)
      })
      .finally(() => {
        state.popupContent = null
      })
  }

  const fnSetRecentLog = async (item) => {
    if (commonUtils.isEmpty(item.vContCd)) {
      return
    }
    const data = {
      vNoteType: noteType,
      vLabNoteCd: item.vLabNoteCd,
      vContCd: item.vContCd,
      vContNm: item.vContNm,
      vPageType: item.vPageType
    }

    await store.dispatch('insertNoteRecentLog', data)
    store.dispatch('setRecentNoteList', { noteType, ...{ noteInfo: data}})
  }

  // 모제품 검색
  const selectSafetyContentsList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-safety-contents-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.page = resData.data.page
        if (resData.data) {
          state.list = resData.data.list
        } else {
          state.list = []
        }
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  // TDD제품유형 리스트 조회
  const selectTddProductClassList = (vPid) => {
    return axios({
      method: 'get',
      url: `/api/labcommon/select-tdd-product-class-list`,
      params: {
        vPid: vPid
      }
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        // return resData.data
        const classList = resData.data
        store.dispatch('setOriginClassList', classList)
        classList.forEach(item => {
          const children = classList.filter(vo => vo.vPid === item.vCid)

          item.children = children
        })

        store.dispatch('setClassList', classList.filter(vo => vo.nLevel === 1))
        return classList.filter(vo => vo.nLevel === 1)
      } else {
        return []
      }
    })
  }

  const selectMessageList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-message-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const insertMessage = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/common/insert-message`,
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectMat4MMstList = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/common/select-mat-4m-mst-list`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.page = resData.data.page
        if (resData.data) {
          state.list = resData.data.list
        } else {
          state.list = []
        }
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectMaterialIssueList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-material-issue-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectRecentMateList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-recent-mate-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const insertLabNoteMyMate = (payload) => {
    return axios({
      method: 'post',
      url: '/api/labcommon/insert-lab-note-my-mate',
      data: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code !== 'C0000') {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const deleteLabNoteMyMate = (payload) => {
    return axios({
      method: 'post',
      url: '/api/labcommon/delete-lab-note-my-mate',
      data: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code !== 'C0000') {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNoteMstBaseInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/common/select-lab-note-mst-basic-info`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const insertAttachFile = (payload) => {
    return axios({
      method: 'post',
      url: '/api/labcommon/insert-attach-file',
      data: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const updateLotFlagSend = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/common/update-lot-flag-send`,
      data: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code !== 'C0000') {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const updateLotFlagExposure = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/common/update-lot-flag-exposure`,
      data: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code !== 'C0000') {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectNoteMstVerList = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/common/select-note-mst-ver-list`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectSafetySapChk = (payload) => {
    return axios({
      method: 'get',
      url: `/api/labcommon/select-safety-sap-chk`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectCompleteCounterList = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/common/select-complete-counter-list`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectExhibitAddList = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/common/select-exhibit-add-list`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        if (resData.data) {
          return resData.data.list
        }
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectFuncMateList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/labcommon/select-func-mate-list',
      params: payload
    })
    .then(res => {
      const resData = res.data

      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectIssueTrackerNoteInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/request/select-issue-tracker-note-info`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const showIssueTrackBtn = (noteType, reqInfo) => {
    if (!reqInfo) {
      return
    }
    let isVisible = false

    if (commonUtils.checkAuth('S000000')) {
      isVisible = true
    }

    const noteTypeInfo = {
      'SC': ['vUserid', 'vBsmUserid', 'vBsmUseridSub1', 'vBsmUseridSub2'],
      'MU': ['vUserid'],
      'HBO': ['vUserid'],
      'SA': ['vUserid']
    }

    const checkKeyList = noteTypeInfo[noteType]

    if (checkKeyList) {
      checkKeyList.forEach(key => {
        if (reqInfo[key] === myInfo.loginId) {
          isVisible = true
        }
      })
    }

    return isVisible
  }

  return {
    noteType,
    noteTypeNm,
    ...toRefs(state),
    selectPtsProjectList,
    selectTddProdTypeList,
    selectSearchMateList,
    selectSearchMateAutocompleteList,
    selectSearchMateTempList,
    selectSearchMyMateList,
    selectSearchProdList,
    selectCheckClearList,
    selectEvaluationList,
    selectEvaluationMaterialList,
    updateSAPRepeat,
    updateRefreshMatnr,
    selectMdlRequiredMaxList,
    insertHal4Mate,
    selcetScmTcodeList,
    selectZplmt12List,
    selectLabNoteMaxMixMrqList,
    selectOneShelfLifeContList,
    selectLabCodeRequired,
    selectLabNoteAuthorityList,
    deleteLabNoteAuthority,
    insertLabNoteAuthority,
    fnOpenMateSearchPop,
    fnChangeNoteInfo,
    showAddVerBtn,
    fnOpenPopup,
    resetMateList,
    changeCounterTypeCd,
    selectLabNoteShelfLifeInfo,
    updateLabNoteShelfLifeInfo,
    insertCommIssuetrack,
    selectCommIssuetrackList,
    selectMatrMixreInfo,
    insertElabNoteLatestBomInfo,
    updateLabNoteLotDecide,
    updateDecideCancel,
    selectOneShelfLifeContInfo,
    selectLabNoteMateRateInfo,
    fnSetRecentLog,
    selectSafetyContentsList,
    selectTddProductClassList,
    selectMessageList,
    insertMessage,
    selectLabNoteInfoCheckAuth,
    selectMat4MMstList,
    selectMaterialIssueList,
    selectRecentMateList,
    insertLabNoteMyMate,
    deleteLabNoteMyMate,
    selectLabNoteMstBaseInfo,
    insertAttachFile,
    selectLotStatusList,
    updateLotFlagSend,
    updateLotFlagExposure,
    selectNoteMstVerList,
    selectSafetySapChk,
    selectCompleteCounterList,
    selectExhibitAddList,
    selectFuncMateList,
    selectIssueTrackerNoteInfo,
    showIssueTrackBtn,
  }
}

