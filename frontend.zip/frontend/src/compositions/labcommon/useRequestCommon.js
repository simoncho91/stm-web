import axios from "@/utils/customAxios";
import { inject } from "vue";
import { useActions } from 'vuex-composition-helpers'
import { useStore } from 'vuex'
import { useRouter } from 'vue-router'

export const useRequestCommon = () => {
  const t = inject('t')
  const { openAsyncAlert } = useActions(['openAsyncAlert'])
  const store = useStore()
  const noteTypeNm = store.getters.getNoteTypeNm()
  const router = useRouter()

  // 버전 정보 조회
  const selectLabNoteMstVerInfo = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/request/select-lab-note-mst-ver-info`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  // 개발 취소 저장
  const updateElabNoteCancelInfo = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/request/update-elab-note-cancel-info`,
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: '실패하였습니다. 관리자에게 문의해주시기 바랍니다.' })
        return 'FAIL'
      }
    })
  }

    // 플랜트 확장 - 내용물 플랜트 정보 리스트 조회
    const selectLabNoteContPlantInfoList = (payload) => {
      return axios({
        method: 'get',
        url: `/api/${noteTypeNm}/request/select-lab-note-cont-plant-info-list`,
        params: payload
      })
      .then(res => {
        const resData = res.data
        if (resData.code === 'C0000') {
          return resData.data
        } else {
          openAsyncAlert({ message: t('common.msg.server_err_msg') })
        }
      })
    }
  
    // 플랜트 확장처리
    const insertLabNotePlantExpansion = (payload) => {
      return axios({
        method: 'post',
        url: `/api/${noteTypeNm}/request/insert-lab-note-plant-expansion`,
        data: payload,
        isLoading: true
      })
      .then(res => {
        const resData = res.data
        if (resData.code === 'C0000') {
          return resData.data
        } else {
          openAsyncAlert({ message: t('common.msg.server_err_msg') })
        }
      })
    }
  
    // 대표 플랜트 변경 - 저장 플랜트 조회
    const selectLabNoteSavePlantList = (vLabNoteCd) => {
      return axios({
        method: 'get',
        url: `/api/${noteTypeNm}/request/select-lab-note-save-plant-list`,
        params: { vLabNoteCd }
      })
      .then(res => {
        const resData = res.data
        if (resData.code === 'C0000') {
          return resData.data
        } else {
          openAsyncAlert({ message: t('common.msg.server_err_msg') })
        }
      })
    }
  
    // 대표 플랜트 변경
    const updatePlantAndSiteType = (payload) => {
      return axios({
        method: 'post',
        url: `/api/${noteTypeNm}/request/update-plant-and-site-type`,
        data: payload,
        isLoading: true
      })
      .then(res => {
        const resData = res.data
        if (resData.code === 'C0000') {
          return 'SUCC'
        } else {
          openAsyncAlert({ message: resData.message })
        }
      })
    }

      // 변경 이력 조회
  const selectLabNoteChgLogList = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/request/select-lab-note-chg-log-list`,
      params: payload,
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  // 버전 정보 수정
  const updateLabNoteVersionInfo = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/request/update-lab-note-version-info`,
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectProductVersionHistoryList = (payload) => {
    return axios({
      method: 'get',
      url: `/api/${noteTypeNm}/request/select-product-version-history-list`,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const updateNotAddIngredientInfo = (payload) => {
    return axios({
      method: 'post',
      url: `/api/${noteTypeNm}/request/update-not-add-ingredient-info`,
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const goView = (vLabNoteCd) => {
    const query = {
      vLabNoteCd: vLabNoteCd
    }

    router.push({ path: `/${noteTypeNm}/all-lab-note-prd-view`, query: query})
  }

  const goModify = (vLabNoteCd, vCopyFlag = 'N', vFlagNonPrd = 'N') => {
    const query = {
      vLabNoteCd: vLabNoteCd
    }

    if (vCopyFlag !== 'N') {
      query.vCopyFlag = vCopyFlag
      query.vFlagNonPrd = vFlagNonPrd
    }
    
    router.push({ path: `/${noteTypeNm}/all-lab-note-prd-register`, query: query })
  }

  return {
    selectLabNoteMstVerInfo,
    updateElabNoteCancelInfo,
    selectLabNoteContPlantInfoList,
    insertLabNotePlantExpansion,
    selectLabNoteSavePlantList,
    updatePlantAndSiteType,
    selectLabNoteChgLogList,
    updateLabNoteVersionInfo,
    selectProductVersionHistoryList,
    updateNotAddIngredientInfo,
    goView,
    goModify,
  }
}