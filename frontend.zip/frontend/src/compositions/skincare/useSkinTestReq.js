import axios from "@/utils/customAxios"
import sanitizeHtml from '@/utils/sanitizeHtml'
import { reactive, toRefs, inject, getCurrentInstance } from "vue"
import { useActions } from 'vuex-composition-helpers'
import { useRouter } from 'vue-router'
import { useRoute } from 'vue-router'

export const useSkinTestReq = () => {
  const t = inject('t')
  const router = useRouter()
  const route = useRoute()
  const app = getCurrentInstance();
  const tiumUrl = app.appContext.config.globalProperties.tiumUrl
  const { openAsyncAlert, openAsyncConfirm, closeAsyncPopup  } = useActions(['openAsyncAlert', 'openAsyncConfirm', 'closeAsyncPopup'])

  const state = reactive({
    params: {
      vLabNoteCd: ''
      , vContPkCd: ''
      , vLotCd: ''
      , vLot: ''
      , vContCd: ''
      , nVersion: ''
      , vPlantCd: ''
      , vMrqTypeCd: ''
      , vGateCd: ''
      , vFlagAction: ''
      , vTrMrqTypeCd: ''
      , vTrGoalCd: ''
      , vDocNo: ''
      , vProductCd: ''
    },
    page: {},
    rvo: {},
    list: [],
    contList: [],
    lotList: [],
    contPkCdList: [],
    arrContPkCd: [],
  })
  
  // 실험노트 정보 불러오기
    const selectTestReqDetail = (payload) => {
      return axios({
        method: 'get',
        url: '/api/skincare/testreq/select-prd-test-req-func-info',
        params: payload
      })
      .then(res => {
        const resData = res.data
        if (resData.code === 'C0000') {
          return resData.data
        }
      })
    }

  // 실험노트 무소구 정보 불러오기
  const selectMusoguList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/skincare/testreq/select-prd-test-req-muso-info',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      }
    })
  }

  // 실험노트 무소구 내용물 정보 불러오기
  const selectMusoguContensDetailList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/skincare/testreq/select-ptr-muso-contents-info',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      }
    })
  }
  
  //시험의뢰
  const goSkinTestReqSave = (payload) => {
    return axios({
      url: '/api/skincare/testreq/insert-prd-test-req-info',
      method: 'post',
      data: payload,
      isLoading: true
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'success') {

        state.params = { ...state.params, ...resData.data.simpleVo}

        //post 방식으로 작업해야함 
        let msg = "";
				
				if (resData.data.vProductCd != undefined) {
					const html = "대표 내용물 코드 : " + resData.data.vSapCd + "<br/>"
            + "Lot : " + resData.data.vLot + "<br/>"
            + "의뢰번호 : <span style='color:blue;text-weight:bold;'>" + resData.data.vDocNo + "</span><br/><br/>"
					  + "위 내용으로 정상적으로 의뢰 되었습니다."
					  // + "<a href='#' id='btn_link' style='text-decoration:underline;'>[새창에서 의뢰 정보 확인하기]</a> <br/>"
					msg = html
	
				}
				else {
					msg = "정상적으로 의뢰 되었습니다.";
				}
        
        const answer = await openAsyncAlert({ message:msg })
        if (!answer) {
          return
        }

        let urlInfo= ""
        if (state.params.vTrMrqTypeCd == "MRQ010") {
          urlInfo = tiumUrl+"/zm/safe/tr/zm_safe_tr_product_v2_view.do"
        }else if(state.params.vTrMrqTypeCd == "MRQ011"){			
          urlInfo = tiumUrl+"/zm/bb/tr/zm_bb_tr_product_view.do"
        }else if(state.params.vTrMrqTypeCd == "MRQ050"){
          urlInfo = tiumUrl+"/zm/tr/zm_tr_product_view.do"
        }
        else{
          urlInfo= tiumUrl+"/zm/safe/tr/zm_safe_tr_product_view.do"
        }

        const targetUrl = urlInfo + "?i_sProductCd=" + resData.data.vProductCd + "&i_iVersion=" + resData.data.nVersion
        //새창
        window.open(targetUrl, "_blank")

        closeAsyncPopup({ message: '' })
      } else {
        openAsyncAlert({ message: resData.message })
        return false
      }
    })

  }
  
  //시험의뢰(효능)
  const goSkinTestReqClinicSave = (payload) => {
    return axios({
      url: '/api/skincare/testreq/insert-prd-test-req-info',
      method: 'post',
      data: payload,
      isLoading: true
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'success') {
        
        const answer = await openAsyncConfirm({ message:"정상적으로 효능임상 정보가 임시저장 되었습니다.<br/>효능임상 페이지에서 추가 정보를 작성해 주세요." })
        if (!answer) {
          return
        }

        const targetUrl = tiumUrl + "/ct/ct/clinical_test_discuss_renew_reg.do?i_sTempStatusCd=DISCUSS&i_sActionFlag=M&i_sTestCd=" + resData.data
        //새창
        window.open(targetUrl, "_blank")
        closeAsyncPopup({ message: '' })
      } else {
          openAsyncAlert({ message: resData.message })
          return false
      }
    })

  }

  return {
    ...toRefs(state),
    goSkinTestReqSave,
    goSkinTestReqClinicSave,
    selectTestReqDetail,
    selectMusoguList,
    selectMusoguContensDetailList,
  }
}