import axios from "@/utils/customAxios";
import { reactive, toRefs, inject } from "vue";
import { useActions } from 'vuex-composition-helpers'

export const useHbdBMRegister = () => {
  const t = inject('t')
  const { openAsyncAlert } = useActions(['openAsyncAlert'])

  // 내용물 상세정보
  const selectReqInfo = (payload) => {
    return axios({
      method: 'get',
      url: '/api/brand-manage-hbd/select-req-info',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: resData.message })
      }
    })
  }

  const updateReqPrdInfo = (payload) => {
    return axios({
      method: 'post',
      url: '/api/brand-manage-hbd/update-req-prd-info',
      data: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  return {
    selectReqInfo,
    updateReqPrdInfo,
  }
}