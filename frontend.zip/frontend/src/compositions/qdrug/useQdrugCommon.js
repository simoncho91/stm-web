import axios from "@/utils/customAxios";
import { reactive, toRefs, inject } from "vue";
import { useActions } from 'vuex-composition-helpers'

export const useQdrugCommon = () => {
  const t = inject('t')
  const { openAsyncAlert } = useActions(['openAsyncAlert'])
  const state = reactive({
    page: {},
    list: []
  })

  const selectLabNoteQdrugCounterList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/qdrug/common/select-lab-note-counter-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectLabNoteQdrugInventoryList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/qdrug/common/select-lab-note-inventory-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectQdrugLabNoteMatePlantCheckList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/qdrug/common/select-lab-note-mate-plant-check-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const insertQdrugCounterSapSync = (payload) => {
    return axios({
      method: 'post',
      url: '/api/qdrug/common/insert-counter-sap-sync',
      data: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        openAsyncAlert({ message: 'Sync success.' })
      } else if (resData.code === 'NO_ESSENTIAL_DATA') {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      } else if (resData.code === 'WRONG_CONTCD') {
        openAsyncAlert({ message: '올바른 내용물 코드가 아닙니다.' })
      } else if (resData.code === 'ALREADY_CONTCD') {
        openAsyncAlert({ message: '이미 실험노트에 존재합니다.' })
      } else if (resData.code === 'NOT_EXIST_CONTCD') {
        openAsyncAlert({ message: '존재하지 않는 코드입니다.' })
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  return {
    ...toRefs(state),
    selectLabNoteQdrugCounterList,
    selectLabNoteQdrugInventoryList,
    selectQdrugLabNoteMatePlantCheckList,
    insertQdrugCounterSapSync,
  }
}