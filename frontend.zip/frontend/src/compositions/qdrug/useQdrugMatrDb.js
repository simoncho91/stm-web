import axios from "@/utils/customAxios";
import { reactive, toRefs, inject } from "vue";
import { useRouter } from 'vue-router'
import { useActions } from 'vuex-composition-helpers'

export const useQdrugMatrDb = () => {
  const t = inject('t')
  const router = useRouter()
  const { openAsyncAlert } = useActions(['openAsyncAlert'])
  const state = reactive({
    page: {},
    list: [],
  })

  // 원료 DB 리스트
  const selectReqList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/qdrug/matrdb/select-qdrug-matr-db-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.page = resData.data.page
        state.list = resData.data.list
        return resData.data
      } else {
        state.page = {}
        state.list = []
      }
    })
  }

  // 원료코드 검색 리스트
  const selectSearchProdList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/qdrug/matrdb/select-qdrug-matr-db-search-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.page = resData.data.page
        state.list = resData.data.list
        return resData.data
      } else {
        state.page = {}
        state.list = []
      }
    })
  }

  // 원료코드 상세정보
  const selectReqInfo = (payload) => {
    return axios({
      method: 'get',
      url: '/api/qdrug/matrdb/select-qdrug-matr-db-info',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectQdrugMatrDbListExcel = (payload) => {
    return axios({
      method : 'get',
      url: `/api/qdrug/matrdb/select-qdrug-matr-db-list_excel`,
      params: payload,
      responseType: 'blob'
    })
    .then(res => {
      let name = res.headers['filename']
      const contentDisposition = res.headers['content-disposition'] || ''
      if(contentDisposition){
        name = decodeURIComponent(name)
      }

      const blob = new Blob([res.data])
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', name)
      link.style.cssText = 'display:none'
      document.body.appendChild(link)
      link.click()
      link.remove()
    })
  }

  const saveMatrDb = (payload) => {
    return axios({
      method: 'post',
      url: '/api/qdrug/matrdb/insert-qdrug-matr-db-info',
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
        return 'FAIL'
      }
    })
  }

  const deleteMatrDb = (payload) => {
    return axios({
      method: 'post',
      url: '/api/qdrug/matrdb/delete-qdrug-matr-db-info',
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {       
        return 'SUCC'
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
        return 'FAIL'
      }
    })
  }


  const goList = () => {
    router.push({ path: '/qdrug/qdrug-note-matr-db-list' })
  }

  const goRegister = () => {
    router.push({ path: '/qdrug/qdrug-note-matr-db-register' })
  }

  const goView = (vMatrCd) => {

    const query = {
      vMatrCd: vMatrCd
    }

    router.push({ path: '/qdrug/qdrug-note-matr-db-register', query: query})
  }

  return {
    ...toRefs(state),
    selectReqList,
    selectReqInfo,
    selectSearchProdList,
    selectQdrugMatrDbListExcel,
    saveMatrDb,
    deleteMatrDb,
    goList,
    goRegister,
    goView,
  }
}