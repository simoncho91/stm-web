import axios from "@/utils/customAxios";
import { reactive, toRefs, inject } from "vue";
import { useRouter } from 'vue-router'
import { useStore } from 'vuex'
import { useActions } from 'vuex-composition-helpers'

export const useQdrugRequest = () => {
  const t = inject('t')
  const router = useRouter()
  const store = useStore()
  const { openAsyncAlert } = useActions(['openAsyncAlert'])
  const state = reactive({
    page: {},
    list: [],
  })

  // 내용물 리스트
  const selectReqList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/qdrug/request/select-req-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.page = resData.data.page
        state.list = resData.data.list
        return resData.data
      } else {
        state.page = {}
        state.list = []
      }
    })
  }

  // 내용물 상세정보
  const selectReqInfo = (payload) => {
    return axios({
      method: 'get',
      url: '/api/qdrug/request/select-req-info',
      params: payload
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else if (resData.code === 'C9999') {
        const noteType = store.getters.getNoteType()

        const data = {
          vNoteType: noteType,
          vLabNoteCd: payload.vLabNoteCd,
        }

        store.dispatch('deleteNoteRecentLogCont', data)
        store.dispatch('removeRecentNoteList', { noteType, index: 0 })
        await openAsyncAlert({ message: resData.message })
        goList()
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  // 개발 재개
  const updateElabNoteRestart = (payload) => {
    return axios({
      method: 'post',
      url: '/api/qdrug/request/update-elab-note-restart',
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: '실패하였습니다. 관리자에게 문의해주시기 바랍니다.' })
        return 'FAIL'
      }
    })
  }

  const saveLabNoteRequest = (payload) => {
    return axios({
      method: 'post',
      url: '/api/qdrug/request/save-lab-note-prd-request',
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectEvaluateLimitedDtm = (payload) => {
    return axios({
      method: 'get',
      url: '/api/qdrug/request/select-evaluate-limited-dtm',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectAcceptQsList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/qdrug/request/select-accept-qs-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.page = resData.data.page
        state.list = resData.data.list
      } else {
        state.page = {}
        state.list = []
      }
    })
  }

  const selectPermissionNoMateList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/qdrug/request/select-permission-mate-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectReleaseCompleteInfo = (payload) => {
    return axios({
      method: 'get',
      url: '/api/qdrug/request/select-release-complete-info',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const saveReleaseCompleteInfo = (payload) => {
    return axios({
      method: 'post',
      url: '/api/qdrug/request/save-release-complete-info',
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectIssueTrackerNoteInfo = (payload) => {
    return axios({
      method: 'get',
      url: '/api/qdrug/request/select-issue-tracker-note-info',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const goList = () => {
    router.push({ path: '/qdrug/all-lab-note-prd-list' })
  }

  const goRegister = () => {
    router.push({ path: '/qdrug/all-lab-note-prd-register' })
  }

  const goModify = (vLabNoteCd, vCopyFlag = 'N') => {
    const query = {
      vLabNoteCd: vLabNoteCd
    }

    if (vCopyFlag !== 'N') {
      query.vCopyFlag = vCopyFlag
    }
    
    router.push({ path: '/qdrug/all-lab-note-prd-register', query: query })
  }

  const goView = (vLabNoteCd) => {
    const query = {
      vLabNoteCd: vLabNoteCd
    }

    router.push({ path: '/qdrug/all-lab-note-prd-view', query: query})
  }

  return {
    ...toRefs(state),
    selectReqList,
    selectReqInfo,
    updateElabNoteRestart,
    saveLabNoteRequest,
    selectEvaluateLimitedDtm,
    selectAcceptQsList,
    selectPermissionNoMateList,
    selectReleaseCompleteInfo,
    saveReleaseCompleteInfo,
    selectIssueTrackerNoteInfo,
    goList,
    goRegister,
    goModify,
    goView,
  }
}