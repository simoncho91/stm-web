import { reactive, inject, toRefs } from 'vue'
import axios from '@/utils/customAxios'
import { useActions } from 'vuex-composition-helpers'

export const useUploadFile = () => {
  const t = inject('t')
  const { openAsyncAlert } = useActions(['openAsyncAlert'])

  const state = reactive({
    filesMap: {}
  })

  const saveCommAttachTemp = async (evt, uploadCd, items) => {
    const files = evt.target.files

    if (files === undefined || files.length === 0) {
      return
    }

    const formData = new FormData()
    const len = files.length

    for (let i = 0; i < len; i++) {
      formData.append("files", files[i])
    }

    return axios({
      url: '/api/file/upload-temp',
      method: 'post',
      headers: {
        'Content-Type': 'multipart/form-data'
      },
      data: formData,
      isLoading: true
    })
    .then(res => {
      const resData = res.data

      if (resData.code === 'C0000') {
        resData.data.forEach(dto => {
          const item = {
            ...dto,
            vNewYn: 'Y',
            vUploadid: uploadCd
          }
          items.push(item)
        })

        evt.target.value = ''
        return resData
      } else {
        openAsyncAlert({ message: resData.message ? resData.message : t('common.msg.server_err_msg') })
        evt.target.value = ''
      }
    })
  }

  const findCommAttachList = (payload) => {
    return axios({
      url: '/api/file',
      method: 'get',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        return []
      }
    })
  }

  const downloadFile = (fileInfo) => {
    return axios({
      url: '/api/file/download',
      method: 'get',
      isLoading: true,
      params: {
        nSeqno: fileInfo.nSeqno,
        vAttType: fileInfo.vAttType,
        vAttachid: fileInfo.vAttachid,
      },
      responseType: 'blob'
    })
    .then(res => {
      let name = fileInfo.vAttachnm

      if (!name) {
        name = res.headers['filename']

        const contentDisposition = res.headers['content-disposition'] || ''

        if (contentDisposition) {
          name = decodeURIComponent(escape(name))
        } else {
          name = filename
        }
      }

      const blob = new Blob([res.data])
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', name)
      link.style.cssText = 'display:none'
      document.body.appendChild(link)
      link.click()
      link.remove()
    })
  }

  /*
  const findCommAttachList = (payload) => {
    return axios({
      url: '/api/file',
      method: 'get',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.filesMap[payload.uploadCd] = resData.data
      }
    })
  }
  */

  return {
    ...toRefs(state),
    saveCommAttachTemp,
    findCommAttachList,
    downloadFile
  }
}