import axios from "@/utils/customAxios";
import { reactive, toRefs, inject } from "vue";
import { useRouter } from 'vue-router'
import { useStore } from 'vuex'
import { useActions } from 'vuex-composition-helpers'

export const useMakeupRequest = () => {
  const t = inject('t')
  const router = useRouter()
  const store = useStore()
  const { openAsyncAlert } = useActions(['openAsyncAlert'])
  const state = reactive({
    page: {},
    list: [],
  })


  // 내용물 리스트
  const selectReqList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/makeup/request/select-req-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.page = resData.data.page
        state.list = resData.data.list
        return resData.data
      } else {
        state.page = {}
        state.list = []
      }
    })
  }

  // 내용물 상세정보
  const selectReqInfo = (payload) => {
    return axios({
      method: 'get',
      url: '/api/makeup/request/select-req-info',
      params: payload
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else if (resData.code === 'C9999') {
        const noteType = store.getters.getNoteType()

        const data = {
          vNoteType: noteType,
          vLabNoteCd: payload.vLabNoteCd,
        }

        store.dispatch('deleteNoteRecentLogCont', data)
        store.dispatch('removeRecentNoteList', { noteType, index: 0 })
        await openAsyncAlert({ message: resData.message })
        goList()
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  // 개발 재개
  const updateElabNoteRestart = (payload) => {
    return axios({
      method: 'post',
      url: '/api/makeup/request/update-elab-note-restart',
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: '실패하였습니다. 관리자에게 문의해주시기 바랍니다.' })
        return 'FAIL'
      }
    })
  }

  // 내용물 개요 등록 / 수정
  const saveLabNoteRequest = (payload) => {
    return axios({
      method: 'post',
      url: '/api/makeup/request/save-lab-note-prd-request',
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  // 내용물 개발 취소, 재개
  const updateMakeupContFlagDevelopment = (payload) => {
    return axios({
      method: 'post',
      url: '/api/makeup/request/update-cont-flag-development',
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectMakeupLabNoteVerLaunchCompleteContList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/makeup/request/select-lab-note-ver-launch-complete-cont-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const saveMakeupLaunchComplete = (payload) => {
    return axios({
      method: 'post',
      url: '/api/makeup/request/save-launch-complete',
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectIssueTrackerNoteInfo = (payload) => {
    return axios({
      method: 'get',
      url: '/api/makeup/request/select-issue-tracker-note-info',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const sendMarketerShareMail = (payload) => {
    return axios({
      method: 'post',
      url: '/api/makeup/request/send-marketer-share-mail',
      data: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectMayContainMatrDbList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/makeup/request/select-may-contain-matr-db-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.page = resData.data.page
        state.list = resData.data.list
        return resData.data
      } else {
        state.page = {}
        state.list = []
      }
    })
  }

  const selectMayContainMatrDbListExcel = (payload) => {
    return axios({
      method : 'get',
      url: `/api/makeup/request/select-may-contain-matr-db-list-excel`,
      params: payload,
      responseType: 'blob'
    })
    .then(res => {
      let name = res.headers['filename']
      const contentDisposition = res.headers['content-disposition'] || ''
      if(contentDisposition){
        name = decodeURIComponent(name)
      }

      const blob = new Blob([res.data])
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', name)
      link.style.cssText = 'display:none'
      document.body.appendChild(link)
      link.click()
      link.remove()
    })
  }

  const selectMayContainMatrDbInfo = (payload) => {
    return axios({
      method: 'get',
      url: '/api/makeup/request/select-may-contain-matr-db-info',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const saveMayContainMatrDbInfo = (payload) => {
    return axios({
      method: 'post',
      url: '/api/makeup/request/save-may-contain-matr-db-info',
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const deleteMayContainMatrDbInfo = (payload) => {
    return axios({
      method: 'post',
      url: '/api/makeup/request/delete-may-contain-matr-db-info',
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectMatrDbSearchList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/makeup/request/select-matr-db-search-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.page = resData.data.page
        state.list = resData.data.list
        return resData.data
      } else {
        state.page = {}
        state.list = []
      }
    })
  }

  const goList = () => {
    router.push({ path: '/makeup/all-lab-note-prd-list' })
  }

  const goMayContainList = () => {
    router.push({ path: '/makeup/may-contain-matr-db-list' })
  }

  const goRegister = () => {
    router.push({ path: '/makeup/all-lab-note-prd-register' })
  }

  const goMayContainRegister = (vConcd) => {
    const query = {
      vConcd: vConcd
    }

    router.push({ path: '/makeup/may-contain-matr-db-register', query: query })
  }

  const goModify = (vLabNoteCd, vCopyFlag = 'N') => {
    const query = {
      vLabNoteCd: vLabNoteCd
    }

    if (vCopyFlag !== 'N') {
      query.vCopyFlag = vCopyFlag
    }
    
    router.push({ path: '/makeup/all-lab-note-prd-register', query: query })
  }

  const goView = (vLabNoteCd) => {
    const query = {
      vLabNoteCd: vLabNoteCd
    }

    router.push({ path: '/makeup/all-lab-note-prd-view', query: query})
  }

  return {
    ...toRefs(state),
    selectReqList,
    selectReqInfo,
    updateElabNoteRestart,
    saveLabNoteRequest,
    updateMakeupContFlagDevelopment,
    selectMakeupLabNoteVerLaunchCompleteContList,
    saveMakeupLaunchComplete,
    selectIssueTrackerNoteInfo,
    sendMarketerShareMail,
    selectMayContainMatrDbList,
    selectMayContainMatrDbListExcel,
    selectMayContainMatrDbInfo,
    saveMayContainMatrDbInfo,
    deleteMayContainMatrDbInfo,
    selectMatrDbSearchList,
    goList,
    goMayContainList,
    goRegister,
    goMayContainRegister,
    goModify,
    goView,
  }
}