import axios from "@/utils/customAxios";
import { reactive, toRefs, inject } from "vue";
import { useActions } from 'vuex-composition-helpers'

export const useMakeupBMRegister = () => {
  const t = inject('t')
  const { openAsyncAlert } = useActions(['openAsyncAlert'])

  // 내용물 상세정보
  const selectReqInfo = (payload) => {
    return axios({
      method: 'get',
      url: '/api/brand-manage-makeup/select-req-info',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: resData.message })
      }
    })
  }

  const selectLabNoteMstVerInfo = (payload) => {
    return axios({
      method: 'get',
      url: '/api/brand-manage-makeup/select-lab-note-mst-ver-info',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const updateReqPrdInfo = (payload) => {
    return axios({
      method: 'post',
      url: '/api/brand-manage-makeup/update-req-prd-info',
      data: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return 'SUCC'
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  return {
    selectReqInfo,
    selectLabNoteMstVerInfo,
    updateReqPrdInfo,
  }
}