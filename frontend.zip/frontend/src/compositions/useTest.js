import axios from "@/utils/customAxios";
import { reactive, toRefs, inject } from "vue";
import { useActions } from 'vuex-composition-helpers'

export const useTest = () => {
  const t = inject('t')
  const { openAsyncAlert } = useActions(['openAsyncAlert'])

  const fnApprSave = (payload) => {
    return axios({
      url: '/api/test/appr-save',
      method: 'post',
      data: payload,
      isLoading: true
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        openAsyncAlert({ message: t('common.msg.save_succ') })
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const fnApprProcessSave = (payload) => {
    return axios({
      url: '/api/test/appr-process-save',
      method: 'post',
      data: payload,
      isLoading: true
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        openAsyncAlert({ message: t('common.msg.save_succ') })
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const fnReferenceSave = (payload) => {
    return axios({
      url: '/api/test/reference-save',
      method: 'post',
      data: payload,
      isLoading: true
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        openAsyncAlert({ message: t('common.msg.save_succ') })
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const fnUploadSave = (payload) => {
    return axios({
      url: '/api/test/upload-test',
      method: 'post',
      data: payload,
      isLoading: true
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        openAsyncAlert({ message: t('common.msg.save_succ') })
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  return {
    fnApprSave,
    fnApprProcessSave,
    fnReferenceSave,
    fnUploadSave
  }
}