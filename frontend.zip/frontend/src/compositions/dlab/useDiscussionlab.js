import axios from "@/utils/customAxios"
import { useStore } from 'vuex'
import { reactive, toRefs, inject } from "vue"
import { useActions } from 'vuex-composition-helpers'
import { useRouter } from 'vue-router'

export const useDiscussionlab = () => {
  const t = inject('t')
  const store = useStore()
  const noteType = store.getters.getNoteType()
  const noteTypeNm = store.getters.getNoteTypeNm()
  const router = useRouter()
  const { openAsyncAlert } = useActions(['openAsyncAlert'])
  
  const state = reactive({
    searchParams: {
      vKeyword: '',
      nowPageNo: 1
    },
    params: {
      vTitle: ''
      , vContents: ''
      , vAddTagInfo:''
      , vRecordid:''
      , files: []
    },
    comParams: {
      vContents: ''
      , vMstRecordid: ''
      , vSubRecordid: ''
    },
    page: {},
    list: [],
    answerList: [],
    tagList: [],
    commentList: [],
  })

  //등록화면 이동
  const goReg = () => {
    router.push({ path: `/${noteTypeNm}/discussionlab-reg` })
  }
  
  //목록화면 이동
  const goList = () => {
    router.push({ path: `/${noteTypeNm}/discussionlab-list` })
  }

  //수정화면 이동
  const goModify = (vRecordid) => {
    const query = {
      vRecordid: vRecordid
      , vFlagModYn: 'Y'
    }
    router.push({ path: `/${noteTypeNm}/discussionlab-reg`, query: query})
  }

  //상세화면 이동
  const goView = (vRecordid) => {
    const query = {
      vRecordid: vRecordid
    }
    router.push({ path: `/${noteTypeNm}/discussionlab-info`, query: query})
  }

  //목록 검색
  const fnSearchRawList = (pg) => {
    if(!pg){
      pg = 1
    }

    state.searchParams.nowPageNo = pg
    selectReqList(state.searchParams)
  }

  //저장 된 정보 불러오기(목록)
  const selectReqList = (payload) => {
    payload.vNoteType = noteType
    return axios({
      url: '/api/labnote/dlab/select-discussionlab-list',
      method: 'get',
      isLoading: true,
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.page = resData.data.page
        state.list = resData.data.list
        return resData.data
      }
    })
  }

  // 상세보기(질문,답변,댓글)
  const selectReqDetail = (payload) => {
    return axios({
      url: '/api/labnote/dlab/select-discussionlab-info',
      method: 'get',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        // state.params = resData.data
        // state.params.content = sanitizeHtml(state.params.content)      

        // state.params.tagList = resData.data.tagList
        // state.mstVo = resData.data.mstVo
        state.params = { ...state.params, ...resData.data.mstVo }
        state.answerList = resData.data.answerList
        state.tagList = resData.data.tagList
        
      } else {
        alert(resData.message)
      }
      return res
    })
  }

  //질문 저장
  const goSave = (payload) => {
    payload.vNoteType = noteType
    return axios({
      url: '/api/labnote/dlab/insert-discussionlab-info',
      method: 'post',
      data: payload,
      isLoading: true
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        await openAsyncAlert({ message: "정상적으로 저장 되었습니다." })
        router.push({ path: '/skincare/discussionlab-list' })
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })

  }

  //질문 수정
  const goUpdate = (payload) => {
    return axios({
      url: '/api/labnote/dlab/update-discussionlab-info',
      method: 'post',
      data: payload,
      isLoading: true
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        await openAsyncAlert({ message: "정상적으로 저장 되었습니다." })
        router.push({ path: '/skincare/discussionlab-info', query: { vRecordid: state.params.vRecordid } })
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  //질문 삭제
  const goDel = (payload) => {
    return axios({
      url: '/api/labnote/dlab/delete-discussionlab-info',
      method: 'post',
      data: payload,
      isLoading: true
    })
    .then(async res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        await openAsyncAlert({ message: "정상적으로 처리 되었습니다." })
        router.push({ path: `/${noteTypeNm}/discussionlab-list` })
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  //질문 답변 
  const goAnswerReg = (payload) => {
    return axios({
      url: '/api/labnote/dlab/insert-discussionlab-answer',
      method: 'post',
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        openAsyncAlert({ message: "정상적으로 처리 되었습니다." })
        // 질문 정보 불러
        selectReqDetail({ vRecordid: state.params.vRecordid })
        // router.push({ path: '/skincare/discussionlab-info', query: { vRecordid: state.params.vRecordid } })
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  //질문 답변 
  const goAnswerMod = (payload) => {
    return axios({
      url: '/api/labnote/dlab/update-discussionlab-answer',
      method: 'post',
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        openAsyncAlert({ message: "정상적으로 처리 되었습니다." })
        // 질문 정보 불러
        selectReqDetail({ vRecordid: state.params.vRecordid })
        // router.push({ path: '/skincare/discussionlab-info', query: { vRecordid: state.params.vRecordid } })
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  //질문 답변 삭제
  const goAnswerDel = (payload) => {
    return axios({
      url: '/api/labnote/dlab/delete-discussionlab-answer',
      method: 'post',
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        openAsyncAlert({ message: "정상적으로 처리 되었습니다." })
        selectReqDetail({ vRecordid: state.params.vRecordid })
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  //질문 댓글
  const goAnswerCommentReg = (payload) => {
    return axios({
      url: '/api/labnote/dlab/insert-discussionlab-comment',
      method: 'post',
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        openAsyncAlert({ message: "정상적으로 처리 되었습니다." })
        selectReqDetail({ vRecordid: state.params.vRecordid })
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  //질문 댓글 삭제
  const goAnswerCommentDel = (payload) => {
    return axios({
      url: '/api/labnote/dlab/delete-discussionlab-comment',
      method: 'post',
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        openAsyncAlert({ message: "정상적으로 처리 되었습니다." })
        selectReqDetail({ vRecordid: state.params.vRecordid })
        // selectAnswerCommentList({vSubRecordid: state.comParams.vSubRecordid})
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  // 답변 댓글 목록 가져오기
  const selectAnswerCommentList = (payload) => {
    return axios({
      url: '/api/labnote/dlab/select-disc-detail-comment-list',
      method: 'get',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.commentList = resData.data.list

      } else {
        alert(resData.message)
      }
      return res
    })
  }

  return {
    ...toRefs(state),
    selectReqList,
    goSave,
    goUpdate,
    goList,
    goModify,
    goView,
    goReg,
    goDel,
    goAnswerReg,
    goAnswerMod,
    goAnswerDel,
    goAnswerCommentReg,
    goAnswerCommentDel,
    fnSearchRawList,
    selectReqDetail,
    selectAnswerCommentList,
  }
}