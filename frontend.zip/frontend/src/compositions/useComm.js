import { reactive, toRefs, inject } from 'vue'
import axios from '@/utils/customAxios'
import { useActions } from 'vuex-composition-helpers'
import { useStore } from 'vuex'

export const useComm = () => {
  const t = inject('t')
  const store = useStore()
  const { openAsyncAlert } = useActions(['openAsyncAlert'])
  const state = reactive({
    page: {},
    list: [],
    orgAllList: [],
    userList: [],
    mainList: [
      { nSeq: 0, vMenuid: 'NS', vView: 'Y' },
      { nSeq: 1, vMenuid: 'EM', vView: 'Y' },
    ],
    alarmList: [],
    checkNsFlag: true,
    checkEmFlag: true,
  })

  const findOrgAllList = (keyword) => {
    return axios({
      method: 'get',
      url: '/api/common/select-org-all-list',
      params: {
        keyword: keyword
      }
    })
    .then(res => {
      const resData = res.data
      if (resData.data) {
        state.orgAllList = resData.data
      } else {
        state.orgAllList = []
      }
    })
  }

  const findSigmaDeptTreeList = (udeptcd) => {
    return axios({
      method: 'get',
      url: '/api/common/select-dept-tree-list',
      params: {
        vUdeptcd: udeptcd
      }
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        const deptList = resData.data
        store.dispatch('setOriginDeptList', deptList)
        deptList.forEach(item => {
          const children = deptList.filter(vo => vo.vSigmaUdeptcd === item.vSigmaDeptcd)

          item.children = children
        })

        store.dispatch('setDeptList', deptList.filter(vo => vo.nLevel === 1))
        return deptList.filter(vo => vo.nLevel === 1)
      } else {
        return []
      }
    })
  }

  const selectCommUserList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/common/select-comm-user-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.page = resData.data.page
        if (resData.data) {
          state.list = resData.data.list
        } else {
          state.list = []
        }
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectCommUserDesignationList = (payload) => {
    return axios({
      method: 'get',
      url: '/api/common/select-comm-user-designation-list',
      params: payload
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        state.page = resData.data.page
        if (resData.data) {
          state.list = resData.data.list
        } else {
          state.list = []
        }
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectUserList = (keyword) => {
    return axios({
      method: 'get',
      url: '/api/common/select-user-list',
      params: {
        keyword: keyword
      }
    })
    .then(res => {
      const resData = res.data
      if (resData.data) {
        state.userList = resData.data
      } else {
        state.userList = []
      }
    })
  }

  const selectDeptLeader = () => {
    return axios({
      method: 'get',
      url: '/api/common/select-dept-leader'
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectTopList = () => {
    const vNoteType = store.getters.getNoteType()
    return axios({
      method: 'get',
      url: '/api/setcommon/select-top-banner-setting-list',
      params: { vNoteType }
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        if (resData.data.mainList && resData.data.mainList.length > 0) {
          state.mainList = resData.data.mainList
        }
        state.alarmList = resData.data.alarmList
        
        return resData.data
      }
    })
  }

  const insertTopBannerSettingAlarm = (payload) => {
    return axios({
      method: 'post',
      url: '/api/setcommon/insert-top-banner-setting-alarm',
      data: { alarmList: payload },
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        //저장 완료
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const insertTopBannerSettingMain = (payload) => {
    return axios({
      method: 'post',
      url: '/api/setcommon/insert-top-banner-setting-main',
      data: { mainList: payload },
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        store.dispatch('setMainList', payload)
      } else {
        openAsyncAlert({ message: resData.message })
      }
    })
  }

  const selectAlarmCheckCount = () => {
    return axios({
      method: 'get',
      url: '/api/common/select-alarm-check-count'
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        store.dispatch('setAlarmCount', resData.data)
      } else {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectAlarmList = () => {
    return axios({
      method: 'get',
      url: '/api/common/select-alarm-list',
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      }
    })
  }

  const updateAlarmCheckFlag = () => {
    return axios({
      method: 'post',
      url: '/api/common/update-alarm-check-flag',
    })
    .then(res => {
      const resData = res.data
      if (resData.code !== 'C0000') {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  const selectQrReaderCheckInfo = () => {
    return axios({
      method: 'get',
      url: '/api/qr/code/select-qr-reader-check-info',
    })
    .then(res => {
      const resData = res.data
      if (resData.code === 'C0000') {
        return resData.data
      }
    })
  }

  const updateQrReaderCheck = (payload) => {
    return axios({
      method: 'post',
      url: '/api/qr/code/update-qr-reader-check',
      data: payload,
      isLoading: true
    })
    .then(res => {
      const resData = res.data
      if (resData.code !== 'C0000') {
        openAsyncAlert({ message: t('common.msg.server_err_msg') })
      }
    })
  }

  return {
    ...toRefs(state),
    findOrgAllList,
    findSigmaDeptTreeList,
    selectCommUserList,
    selectCommUserDesignationList,
    selectUserList,
    selectDeptLeader,
    selectTopList,
    insertTopBannerSettingAlarm,
    insertTopBannerSettingMain,
    selectAlarmCheckCount,
    selectAlarmList,
    updateAlarmCheckFlag,
    selectQrReaderCheckInfo,
    updateQrReaderCheck,
  }
}