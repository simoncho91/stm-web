<template>
  <div v-show="reqInfo">
    <div class="page-tab">
      <div class="page-tab__inner">
        <HistoryTab
          v-if="reqInfo && commonUtils.isNotEmpty(reqInfo.vContCd)"
          :v-lab-note-cd="vLabNoteCd"
          url-link="/skincare/all-lab-note-{pageType}-view?vLabNoteCd="
          @go-list="goList()"
        >
        </HistoryTab>

        <div class="page-tab__contents">
          <ap-breadcrumb
            nav-title="내용물 개요"
            :path-list="pathList"
          >
          </ap-breadcrumb>

          <div class="page-tab__item">
            <AllLabNoteSkincareBasicInfoView></AllLabNoteSkincareBasicInfoView>
          </div>
        </div>
      </div>
    </div>

    <div class="contents-core">
      <div class="contents-cell__wrap">
        <div class="contents-cell">
          <div class="contents-box contents-box__full">
            <div class="contents-box__inner min-height__unset">
              <AllLabNoteSkincareResearcherInfoView></AllLabNoteSkincareResearcherInfoView>
            </div>
          </div>

          <div class="contents-box contents-box__full">
            <div class="contents-box__inner min-height__unset">
              <AllLabNoteSkincareMarketingInfoView></AllLabNoteSkincareMarketingInfoView>
            </div>
          </div>

          <div class="contents-box contents-box__full">
            <div class="contents-box__inner min-height__unset">
              <div class="arrordion-item is-active">
                <div class="arrordion-header">
                  <div class="arrordion-title">제품 정보</div>
                  <button type="button" class="ui-button__accordion"></button>
                </div>
                <div class="arrordion-body">
                  <div class="detail-tab ap_contents_tab" v-if="reqInfo && reqInfo.verList">
                    <div class="ver_tab_area">
                      <ApTab
                        v-if="reqInfo.verList.length > 0"
                        mst-id="productVersion"
                        :tab-list="reqInfo.verList"
                        tab-id-key="vVersionKey"
                        tab-nm-key="vVersionTxt"
                        :tab-style="['detail-tab__inner', 'ui-list detail-tab__lists', 'detail-tab__list', 'detail-tab__link']"
                        :default-tab="reqInfo.verList[reqInfo.verList.length - 1].vVersionKey"
                        @click="fnProductVersionTabEvent"
                      >
                      </ApTab>
                      <button
                        v-if="showAddVerBtn(reqInfo) && showModifyBtn()"
                        type="button"
                        class="detail-tab__button--plus add_btn"
                        :class="addVerFlag === 'Y' ? 'active' : ''"
                        @click="fnAddVersion()"
                      >
                      </button>
                    </div>
                    <template v-if="addVerFlag !== 'Y'">
                      <div class="contents-tab__body"
                        v-for="(item, index) in reqInfo.verList"
                        :key="'version_area_' + index"
                        :id="item.vVersionKey"
                      >
                        <AllLabNoteSkincareProductInfoView
                          v-if="item.versionInfo"
                          :version-info="item.versionInfo"
                        >
                        </AllLabNoteSkincareProductInfoView>
                      </div>
                    </template>
                    <template v-else>
                      <AllLabNoteSkincareProductInfoRegister
                        ref="product"
                      >
                      </AllLabNoteSkincareProductInfoRegister>
                      <div class="page-bottom">
                        <div class="ui-buttons ui-buttons__right">
                          <button type="button" class="ui-button ui-button__height--28 ui-button__bg--blue" v-if="addVerFlag === 'Y'" @click="fnNewVersionSave()">버전 추가 저장</button>
                        </div>
                      </div>
                    </template>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="contents-box contents-box__full">
            <div class="contents-box__inner min-height__unset" v-if="showApprArea()">
              <ApprovalRegister
                :appr-cd="reqInfo.vGate0ApprCd"
                :default-list="reqInfo.apprList"
                appr-class="LAB_SC_GATE0"
                ref="appr"
                @callbackFunc="fnApprRequest"
                :is-auto-focus="true"
              >
              </ApprovalRegister>
            </div>
            <div class="contents-box__inner min-height__unset" v-else-if="reqInfo && commonUtils.isNotEmpty(reqInfo.vGate0ApprCd)">
              <ApprovalView
                :appr-cd="reqInfo.vGate0ApprCd"
                appr-class="LAB_SC_GATE0"
                ref="appr"
                v-model:appr-mst-info="apprMstInfo"
                v-model:appr-user-list="apprUserList"
                @callbackFunc="fnApprProc"
              >
              </ApprovalView>
              <div class="ui-buttons ui-buttons__right mt-15">
                <button type="button" class="ui-button ui-button__height--28 ui-button__bg--blue" v-if="showOpinionPopBtn()" @click="fnViewApprOpinion()">의견보기</button>
              </div>
            </div>
          </div>
        </div>

        <div class="contents-box contents-box__full contents-box__with--tab">
          <AllLabNoteSkincareEtcInfoView></AllLabNoteSkincareEtcInfoView>
        </div>

        <div class="page-bottom" v-if="!showApprovalBtn('USR010') && !showApprovalBtn('USR020')">
          <div class="page-bottom__inner form-flex-between">
            <div class="ui-buttons ui-buttons__left">
              <button type="button" class="ui-button ui-button__bg--blue" v-if="showCompleteBtn()" @click="fnReleaseCompletePop()">출시 완료</button>
              <button type="button" class="ui-button ui-button__bg--lightgray" v-if="showDevelopCancelBtn()" @click="fnDevelopCancelPop()">개발취소</button>
              <button type="button" class="ui-button ui-button__bg--lightgray" v-if="showDevelopRestartBtn()" @click="fnDevelopRestart()">개발재개</button>
              <template v-if="showBsmBtn()">
                <button type="button" class="ui-button ui-button__border--gray" @click="fnPlantExtendPop()">플랜트 확장</button>
              </template>
              <button type="button" class="ui-button ui-button__border--gray" @click="fnNoteInfoChangeLogPop()">변경이력보기</button>
            </div>
            <div class="ui-buttons ui-buttons__right">
              <template v-if="showBsmBtn()">
                <button type="button" class="ui-button ui-button__bg--blue" @click="fnNoteAuthPop()">노트 공유하기</button>
              </template>
              <button type="button" class="ui-button ui-button__bg--skyblue" v-if="showApprArea()" @click="fnAppr('REQ')">결재올리기</button>
              <button type="button" class="ui-button ui-button__bg--skyblue" v-if="showModifyBtn()" @click="goModify(reqInfo.vLabNoteCd)">수정</button>
              <button type="button" class="ui-button ui-button__border--gray" @click="goList()">목록</button>
            </div>
          </div>
        </div>
        <div class="page-bottom" v-else>
          <div class="page-bottom__inner">
            <div class="ui-buttons ui-buttons__right">
              <template v-if="showApprovalBtn('USR010')">
                <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnAppr('ACCEPT')">승인</button>
                <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnAppr('REJECT')">반려</button>
              </template>
              <template v-if="showApprovalBtn('USR020')">
                <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnMutual('ACCEPT')">합의</button>
                <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnMutual('REJECT')">거부</button>
              </template>
              <button type="button" class="ui-button ui-button__border--gray" @click="goList()">목록</button>
            </div>
          </div>
        </div>
      </div>
      <button type="button" class="button-caution" v-if="showIssueTrackBtn('SC', reqInfo)" @click="fnIssueTrackPop()"></button>
    </div>
  </div>
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @selectFunc="popSelectFunc"
        @callbackFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, ref, computed, provide, inject } from 'vue'
import { useRoute } from 'vue-router'
import { useStore } from 'vuex'
import { useSkinRequest } from '@/compositions/skincare/useSkinRequest'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useRequestCommon } from '@/compositions/labcommon/useRequestCommon'
import { useApproval } from '@/compositions/approval/useApproval'
import { useActions } from 'vuex-composition-helpers'
import uiUtils from '@/utils/uiUtils'

import AllLabNoteSkincareBasicInfoView from '@/components/skincare/AllLabNoteSkincareBasicInfoView.vue'
import AllLabNoteSkincareProductInfoView from '@/components/skincare/AllLabNoteSkincareProductInfoView.vue'
import AllLabNoteSkincareMarketingInfoView from '@/components/skincare/AllLabNoteSkincareMarketingInfoView.vue'
import AllLabNoteSkincareResearcherInfoView from '@/components/skincare/AllLabNoteSkincareResearcherInfoView.vue'
export default {
  name: 'AllLabNoteView',
  components: {
    AllLabNoteSkincareBasicInfoView,
    AllLabNoteSkincareProductInfoView,
    AllLabNoteSkincareMarketingInfoView,
    AllLabNoteSkincareResearcherInfoView,
    AllLabNoteSkincareProductInfoRegister: defineAsyncComponent(() => import('@/components/skincare/AllLabNoteSkincareProductInfoRegister.vue')),
    AllLabNoteSkincareEtcInfoView: defineAsyncComponent(() => import('@/components/skincare/AllLabNoteSkincareEtcInfoView.vue')),
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    HistoryTab: defineAsyncComponent(() => import('@/components/labcommon/HistoryTab.vue')),
    OpinionViewPop: defineAsyncComponent(() => import('@/components/approval/popup/OpinionViewPop.vue')),
    DevelopCancelPop: defineAsyncComponent(() => import('@/components/labcommon/popup/DevelopCancelPop.vue')),
    PlantExtendPop: defineAsyncComponent(() => import('@/components/labcommon/popup/PlantExtendPop.vue')),
    NoteInfoChangeLogPop: defineAsyncComponent(() => import('@/components/labcommon/popup/NoteInfoChangeLogPop.vue')),
    LabNoteAuthorityPop: defineAsyncComponent(() => import('@/components/labcommon/popup/LabNoteAuthorityPop.vue')),
    IssueTrackerPop: defineAsyncComponent(() => import('@/components/labcommon/popup/IssueTrackerPop.vue')),
    ApprovalRegister: defineAsyncComponent(() => import('@/components/comm/ApprovalRegister.vue')),
    ApprovalView: defineAsyncComponent(() => import('@/components/comm/ApprovalView.vue')),
    ReleaseCompletePop: defineAsyncComponent(() => import('@/components/skincare/popup/ReleaseCompletePop.vue')),
  },
  mounted () {
    uiUtils.accordionEvent()
  },
  unmounted () {
    uiUtils.accordionEvent()
  },
  setup () {
    const commonUtils = inject('commonUtils')
    const { openAsyncConfirm, openAsyncAlert } = useActions(['openAsyncConfirm', 'openAsyncAlert'])
    const store = useStore()
    const route = useRoute()
    const pathList = [
      { path: '/skincare/all-lab-note-prd-list', pathNm: 'ALL LAB NOTES' },
      { path: '/skincare/all-lab-note-prd-view', pathNm: '내용물 개요' }
    ]

    const reqInfo = ref(null)
    const product = ref(null)
    const appr = ref(null)
    const addVerFlag = ref('')
    const noteType = store.getters.getNoteType()
    const myInfo = store.getters.getMyInfo()
    const vLabNoteCd = route.query.vLabNoteCd
    const recentNoteList = computed(() => store.getters.getRecentNoteList(noteType))
    const apprMstInfo = ref(null)
    const apprUserList = ref(null)
    let apprProcStatus = ''
    let apprProcSubStatus = ''

    const {
      selectReqInfo,
      goModify,
      goList,
      updateElabNoteRestart,
      saveLabNoteRequest,
      saveLabNoteGate0ApprRequest,
      selectIssueTrackerNoteInfo,
    } = useSkinRequest()

    const {
      selectLabNoteMstVerInfo,
    } = useRequestCommon()

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      fnChangeNoteInfo,
      showAddVerBtn,
      fnSetRecentLog,
      showIssueTrackBtn,
    } = useLabCommon()

    const {
      updateNoteRequest,
    } = useApproval()

    const fnDevelopCancelPop = () => {
      popParams.value = {
        vLabNoteCd,
        vContCd: reqInfo.value.vContCd || '',
        vContNm: reqInfo.value.vContNm || '',
        vNotePageType: 'prd',
      }

      popSelectFunc.value = init

      fnOpenPopup('DevelopCancelPop', false)
    }

    const fnDevelopRestart = async () => {
      if (await openAsyncConfirm({ message: '해당 실험노트 개발을 다시 시작하시겠습니까?'})) {
        const result = await updateElabNoteRestart({ vLabNoteCd })

        if (result === 'SUCC') {
          await openAsyncAlert({ message: '개발 재개되었습니다.' })
          init(vLabNoteCd)
        }
      }
    }

    const fnProductVersionTabEvent = async (obj) => {
      addVerFlag.value = ''

      if (!obj.versionInfo) {
        const payload = {
          vLabNoteCd: obj.vLabNoteCd,
          nVersion: obj.nVersion
        }

        const resultData = await selectLabNoteMstVerInfo(payload)

        const funcMateList = resultData.funcMateList

        if (funcMateList && funcMateList.length > 0) {
          resultData.funcMateList = funcMateList.forEach(item => {
            if (item.vFlagRequired === 'Y') {
              item.vFlagTo100 = ''
            }
          })
        }

        obj.versionInfo = resultData
      }
    }

    const fnAddVersion = () => {
      addVerFlag.value = 'Y'

      const tabWrap = document.querySelector('#productVersion')
      const isActive = tabWrap.querySelector('.ap_li_tab_item.is-active')
      if (isActive) {
        isActive.classList.remove('is-active')
      }
    }

    const fnApprRequest = async (draftOpinion) => {
      if (!await openAsyncConfirm({ message: '결재 의뢰 하시겠습니까?' })) {
        return
      }

      if (appr.value) {
        const payload = {
          vLabNoteCd: reqInfo.value.vLabNoteCd,
          vApprTypeCd: 'PQC_GATE0',
          apprReqInfo: {
            apprInfo: appr.value.apprInfo,
            apprList: appr.value.apprList
          }
        }

        payload.apprReqInfo.apprInfo.vDraftOpinion = draftOpinion

        const result = await saveLabNoteGate0ApprRequest(payload)

        if (result && result === 'SUCC') {
          await openAsyncAlert({ message: '결재 승인 요청되었습니다.' })
          goList()
        }
      }
    }

    const fnApprProc = async (draftOpinion) => {
      store.dispatch('setLoading', true)
      const payload = {
        ...apprMstInfo.value,
        ...{
          vApprStatus: apprProcStatus,
          vApprSubStatus: apprProcSubStatus,
          vApprOpinion: draftOpinion.value
        }
      }

      const result = await updateNoteRequest(payload)
      if (result) {
        window.location.reload(true)
      } else{
        store.dispatch('setLoading', false)
      }

    }

    const fnAppr = (flag) => {
      if (appr.value) {
        if (flag === 'ACCEPT') {
          apprProcStatus = 'APS010'
        } else if (flag === 'REJECT') {
          apprProcStatus = 'APS020'
        }

        appr.value.fnApprovalOpinionPop()
      }
    }

    const fnMutual = (flag) => {
      apprProcStatus = 'APS050'
      if (appr.value) {
        if (flag === 'ACCEPT') {
          apprProcSubStatus = 'AGR010'
        } else {
          apprProcSubStatus = 'AGR030'
        }

        appr.value.fnApprovalOpinionPop()
      }
    }

    const fnNewVersionSave = async () => {
      const productChkKey = ['vCounterNmTemp', 'vCounterBrdNm', 'vCounterSpInfo', 'vPrePilotDt',
                              'vSsrid', 'vCounterNote', 'vFlagNewItem']
      if (!product.value.fnValidateAll(productChkKey)) {
        openAsyncAlert({ message: '필수 입력사항을 확인해 주세요.' })
        return
      }

      reqInfo.value.vFlagNewVer = 'Y'
      reqInfo.value.versionInfo = { ...product.value.verParams }
      reqInfo.value.vStatusCd = 'LNC06_04'
      reqInfo.value.flagAction = 'M'

      //버전 추가 저장 시 기능성 허가 필드도 업데이트 되도록 값 셋팅
      let productVerParams = {}
      let flagFuncTest = ''

      if (product.value) {
        if (product.value.verParams) {
          productVerParams = product.value.verParams
          const funcList = productVerParams.funcList

          funcList.some(item => {
            if (commonUtils.isNotEmpty(item.vTag2Cd)) {
              flagFuncTest = 'Y'
              return true
            }
          })
        } else if (product.value[0].verParams) {
          productVerParams = product.value[0].verParams
          const funcList = productVerParams.funcList

          funcList.some(item => {
            if (commonUtils.isNotEmpty(item.vTag2Cd)) {
              flagFuncTest = 'Y'
              return true
            }
          })
        }
      }

      reqInfo.value.vFlagFuncTest = flagFuncTest 
      
      const vLabNoteCd = await saveLabNoteRequest(reqInfo.value)
      if (vLabNoteCd) {
        await openAsyncAlert({ message: '저장 되었습니다.'})
        addVerFlag.value = ''
        init(vLabNoteCd)
      }
    }

    const fnViewApprOpinion = () => {
      popParams.value = { vApprCd: reqInfo.value.vGate0ApprCd }

      fnOpenPopup('OpinionViewPop')
    }

    const fnPlantExtendPop = () => {
      popParams.value = {
        vLabNoteCd: reqInfo.value.vLabNoteCd,
        vCodeType: reqInfo.value.vCodeType,
        vContNm: reqInfo.value.vContNm,
        vNoteType: noteType,
        vBrdCd: reqInfo.value.vBrdCd,
      }

      fnOpenPopup('PlantExtendPop')
    }

    const fnNoteInfoChangeLogPop = () => {
      popParams.value = {
        vLabNoteCd: reqInfo.value.vLabNoteCd,
        vNoteType: noteType,
      }

      fnOpenPopup('NoteInfoChangeLogPop', false)
    }

    const fnNoteAuthPop = () => {
      popParams.value = {
        vLabNoteCd: reqInfo.value.vLabNoteCd,
        vContCd: reqInfo.value.vContCd,
        vContNm: reqInfo.value.vContNm,
        vPageType: 'prd',
      }

      fnOpenPopup('LabNoteAuthorityPop')
    }

    const fnReleaseCompletePop = () => {
      popParams.value = {
        vLabNoteCd: reqInfo.value.vLabNoteCd,
        vCodeType: 'HAL3'
      }

      fnOpenPopup('ReleaseCompletePop')
    }

    const fnIssueTrackPop = async () => {
      const noteInfo = await selectIssueTrackerNoteInfo({ vLabNoteCd: reqInfo.value.vLabNoteCd })
      popParams.value = {
        vLabNoteCd: reqInfo.value.vLabNoteCd,
        noteInfo: noteInfo,
        vNoteType: noteType
      }

      fnOpenPopup('IssueTrackerPop', false)
    }

    const showApprArea = () => {
      let isVisible = false

      if (reqInfo.value && reqInfo.value.vIsLabNoteAdmin === 'Y' &&
          (reqInfo.value.vStatusCd === 'LNC06_04' || reqInfo.value.vStatusCd === 'LNC06_06')) {
        isVisible = true
      }

      return isVisible
    }

    const showModifyBtn = () => {
      let isVisible = false

      if (reqInfo.value && reqInfo.value.vIsLabNoteAdmin === 'Y' && reqInfo.value.vIsLabNoteStatus === 'Y') {
        isVisible = true
      }

      return isVisible
    }

    const showDevelopCancelBtn = () => {
      let isVisible = false

      if (reqInfo.value && reqInfo.value.vIsLabNoteAdmin === 'Y' &&
          (reqInfo.value.vStatusCd !== 'LNC06_50' && reqInfo.value.vStatusCd !== 'LNC06_41')) {
        isVisible = true
      }

      return isVisible
    }

    const showDevelopRestartBtn = () => {
      let isVisible = false

      if (reqInfo.value && reqInfo.value.vStatusCd === 'LNC06_41') {
        isVisible = true
      }

      return isVisible
    }

    const showOpinionPopBtn = () => {
      let isVisible = false

      if (reqInfo.value && reqInfo.value.vIsLabNoteAdmin === 'Y' && commonUtils.isNotEmpty(reqInfo.value.vGate0ApprCd)) {
        isVisible = true
      }

      return isVisible
    }

    const showCompleteBtn = () => {
      let isVisible = false

      if (reqInfo.value && reqInfo.value.vFlagAllDecide === 'Y' &&
        (myInfo.loginId === reqInfo.value.vUserid || commonUtils.checkAuth('S000000'))) {
          isVisible = true
      }

      return isVisible
    }

    const showBsmBtn = () => {
      let isVisible = false

      if (reqInfo.value && (reqInfo.value.vUserid === myInfo.loginId
                            || reqInfo.value.vBsmUserid === myInfo.loginId
                            || reqInfo.value.vBsmUseridSub1 === myInfo.loginId
                            || reqInfo.value.vBsmUseridSub2 === myInfo.loginId
                            || commonUtils.checkAuth('S000000'))
      ) {
        isVisible = true
      }

      return isVisible
    }

    const showApprovalBtn = (apprUserType) => {
      let isVisible = false

      if (apprMstInfo.value &&
          apprMstInfo.value.vApprStatus === 'APS030' &&
          reqInfo.value &&
          reqInfo.value.vStatusCd === 'LNC06_05' &&
          apprUserList.value?.length > 0) {
        const curApprUser = apprUserList.value.filter(v => v.nCurApprseq === apprMstInfo.value.nCurApprseq)

        if (curApprUser && curApprUser.length > 0 &&
            (curApprUser[0].vApprUserid === myInfo.loginId || commonUtils.checkAuth('S000000')) &&
            curApprUser[0].vApprUserType === apprUserType) {
          isVisible = true
        }
      }

      return isVisible
    }

    const init = async (vLabNoteCd = route.query.vLabNoteCd) => {
      reqInfo.value = await selectReqInfo({ vLabNoteCd: vLabNoteCd, vPageFlag: 'VIEW' })
      let recentInfo = null
      if (recentNoteList.value && recentNoteList.value.length > 0) {
        recentInfo = recentNoteList.value.filter(item => item.vLabNoteCd === reqInfo.value.vLabNoteCd)[0]
      }

      if (!recentInfo && reqInfo.value && commonUtils.isNotEmpty(reqInfo.value.vContCd)) {
        const data = {
          vNoteType: noteType,
          vLabNoteCd: reqInfo.value.vLabNoteCd,
          vContCd: reqInfo.value.vContCd,
          vContNm: reqInfo.value.vContNm,
          vPageType: 'prd'
        }
        await fnSetRecentLog(data)
      }

      if (reqInfo.value.verList && reqInfo.value.verList.length > 0) {
        reqInfo.value.verList.some((item) => {
          if (Number(item.nVersion) === Number(reqInfo.value.versionInfo.nVersion)) {
            item.versionInfo = reqInfo.value.versionInfo
            return true
          }
        })
      }

      fnChangeNoteInfo(reqInfo.value)
    }

    init()
    provide('reqInfo', reqInfo)

    return {
      commonUtils,
      pathList,
      addVerFlag,
      reqInfo,
      vLabNoteCd,
      product,
      appr,
      popupContent,
      popParams,
      popSelectFunc,
      fnDevelopCancelPop,
      fnPlantExtendPop,
      fnNoteInfoChangeLogPop,
      fnNoteAuthPop,
      fnIssueTrackPop,
      fnDevelopRestart,
      fnReleaseCompletePop,
      goModify,
      init,
      goList,
      fnProductVersionTabEvent,
      fnAppr,
      fnMutual,
      fnApprRequest,
      fnApprProc,
      fnNewVersionSave,
      fnAddVersion,
      showAddVerBtn,
      showApprArea,
      showModifyBtn,
      showDevelopCancelBtn,
      showDevelopRestartBtn,
      showOpinionPopBtn,
      showCompleteBtn,
      showBsmBtn,
      fnViewApprOpinion,
      apprMstInfo,
      apprUserList,
      showApprovalBtn,
      showIssueTrackBtn,
    }
  }
}
</script>