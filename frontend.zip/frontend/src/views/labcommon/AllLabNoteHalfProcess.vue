<template>
  <div class="contents-core">
    <div class="contents-cell__wrap">
      <div class="contents-cell flex-none">
        <div class="contents-box">
          <div class="contents-box__inner p-0 min-height__unset">
            <HistoryTab
              :v-lab-note-cd="vLabNoteCd"
              :url-link="'/'+ noteTypeNm +'/all-lab-note-{pageType}-process?vLabNoteCd='"
              @go-list="goList()"
            >
            </HistoryTab>
            <ap-breadcrumb
              nav-title="프로세스"
              :path-list="pathList"
              :flag-inside="true"
            >
            </ap-breadcrumb>
            <NoteProcessBar
              v-if="progressInfo && progressInfo.length > 0"
              :progress-info="progressInfo"
              :is-big="true"
              :is-show="false"
              :is-cancel="flagCancel == 'Y' ? true : false"
              :is-half="true"
            >
            </NoteProcessBar>
          </div>
        </div>
      </div>

      <div class="contents-cell" id="labNoteProcess">
        <div class="contents-box contents-box__full contents-box__with--tab">
          <ApTab
            mst-id="process-tab"
            :tab-list="tabList"
            @click="getSelectedTabEvent"
            :default-tab="settingVal.vTabId"
            :tab-style="['contents-box__tab--inner', 'contents-box__tab--list', 'contents-box__tab--item', 'contents-box__tab--link']"
          >
          </ApTab>
          <div class="contents-tab__body" id="confirm">
            <ProcessHalfPrescribeConfirm
              v-if="settingVal.vTabId === 'confirm'"
              @callbackFunc="setProgressBar"
            >
            </ProcessHalfPrescribeConfirm>
          </div>
          <div class="contents-tab__body" id="pilot">
            <ProcessHalfPilot
            v-if="settingVal.vTabId === 'pilot'"
            >
            </ProcessHalfPilot>
          </div>
          <div class="contents-tab__body" id="bom">
            <ProcessHalfBOM
              v-if="settingVal.vTabId === 'bom'"
            >
            </ProcessHalfBOM>
          </div>
          <div class="contents-tab__body" id="timeLine">
            <ProcessHalfTimeLine
              v-if="settingVal.vTabId === 'timeLine' && progressInfo"
              :progress-info="progressInfo"
            >
            </ProcessHalfTimeLine>
          </div>
          
        </div>

      </div>

    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, computed, onMounted, ref, provide, inject, reactive } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useRoute, useRouter } from 'vue-router'
import { useStore } from 'vuex'
import { useHalfProcessCommon } from '@/compositions/labcommon/useHalfProcessCommon'

import uiUtils from '@/utils/uiUtils'
export default {
  name: 'AllLabNoteProcess',
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    HistoryTab: defineAsyncComponent(() => import('@/components/labcommon/HistoryTab.vue')),
    ProcessHalfTimeLine: defineAsyncComponent(() => import('@/components/process/ProcessHalfTimeLine.vue')),
    ProcessHalfBOM: defineAsyncComponent(() => import('@/components/process/ProcessHalfBOM.vue')),
    ProcessHalfPilot: defineAsyncComponent(() => import('@/components/process/ProcessHalfPilot.vue')),
    ProcessHalfPrescribeConfirm: defineAsyncComponent(() => import('@/components/process/ProcessHalfPrescribeConfirm.vue')),
    NoteProcessBar: defineAsyncComponent(() => import('@/components/labcommon/NoteProcessBar.vue')),
  },
  setup () {
    const progInfo = ref(null)
    const route = useRoute()
    const router = useRouter()
    const store = useStore()
    const vLabNoteCd = route.query.vLabNoteCd || ''
    const noteType = store.getters.getNoteType()
    const noteTypeNm = store.getters.getNoteTypeNm()
    const recentNoteList = computed(() => store.getters.getRecentNoteList(noteType))
    
    const settingVal = reactive({
        vTabId : '',
        vProgWidth : ''
      })

    const {
      selectProgressInfo,
      progressInfo, 
      tabList,
      flagCancel
    } = useHalfProcessCommon()

    const pathList = [
      { path: `/${noteTypeNm}/all-lab-note-half-list`, pathNm: '4 CODE NOTES' },
      { path: `/${noteTypeNm}/all-lab-note-half-process`, pathNm: '프로세스' }
    ]

    const getSelectedTabEvent = (item) => {
      router.replace({ query: {vLabNoteCd: route.query.vLabNoteCd }})
      setTimeout(() => {
        settingVal.vTabId = item.tabId
      }, 200)
    }

    const setProgressInfo = async () => {
      await selectProgressInfo({vLabNoteCd : vLabNoteCd})
      const vTabId = route.query.vTabId
      if (!vTabId) {
        for (const prog of progressInfo.value){
          if(prog.vCurrStatMark === "is-active"){
            settingVal.vTabId = prog.vTabId
            break;
          }
        }
      } else {
        settingVal.vTabId = vTabId
      }
    }

    const setProgressBar = () => {
      selectProgressInfo({vLabNoteCd : vLabNoteCd})
    }

    const goList = () => {
      router.push({ path: `/${noteTypeNm}/all-lab-note-half-list` })
    }

    const init = () => {
      setProgressInfo()
    }
    
    init()

    return {
      noteType,
      noteTypeNm,
      pathList,
      tabList,
      getSelectedTabEvent,
      setProgressInfo,
      setProgressBar,
      progInfo,
      progressInfo,
      settingVal,
      recentNoteList,
      vLabNoteCd,
      flagCancel,
      goList,
    }
  }
}
</script>