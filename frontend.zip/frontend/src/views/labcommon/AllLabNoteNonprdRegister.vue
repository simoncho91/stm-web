<template>
  <div>
    <ap-breadcrumb
      nav-title="Project notes"
      :path-list="pathList"
    >
    </ap-breadcrumb>
  
    <div class="contents-core">
      <div class="contents-cell__wrap">
        
        <!-- 내용물 개요 -->
        <div class="contents-cell flex-none">
          <div class="contents-box contents-box__full">
            <div class="contents-box__inner min-height__unset">
              
              <div class="arrordion-item is-active">
                <div class="arrordion-header">
                  <div class="arrordion-title">과제 (비제품)</div>
                </div>
                <div class="arrordion-body">
                  <div class="basic-info__table">
                    <table class="ui-table__contents">
                      <colgroup>
                        <col style="width:17rem">
                        <col style="width:auto">
                        <col style="width:17rem">
                        <col style="width:auto">
                      </colgroup>
                      <tbody>
                        <tr>
                          <th>과제구분<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
                          <td>
                            <div class="search-form" id="error_wrap_vLabTypeCd">
                              <div class="search-form__inner">
                                <ap-selectbox
                                  v-model:value="regParams.vLabTypeCd"
                                  input-class="ui-select__width--120"
                                  :options="labTypeCdList"
                                  @change="fnValidate('vLabTypeCd')"
                                >
                                </ap-selectbox>
                                <template v-if="regParams.vLabTypeCd === 'LNC07_18'">
                                  <ap-input
                                    v-model:value="regParams.v4mHisNum"
                                    input-class="ui-input__width--170"
                                    style="margin-left: 5px;"
                                    @keypress-enter="fnMat4MMstSearchPop"
                                  >
                                  </ap-input>
                                  <button
                                    type="button"
                                    class="button-search"
                                    @click="fnMat4MMstSearchPop"
                                  >검색</button>
                                </template>
                              </div>
                              <span class="error-msg" id="error_msg_vLabTypeCd"></span>
                            </div>
                          </td>
                          <th>보안구분<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
                          <td>
                            <div class="ui-radio__list" id="error_wrap_vFlagSecurity">
                              <div class="ui-radio__inner">
                                <ap-input-radio
                                  v-model:model="regParams.vFlagSecurity"
                                  :value="'N'"
                                  label="일반"
                                  id="'vFlagSecurity_N"
                                  name="flagSecurity"
                                  @click="fnValidate('vFlagSecurity')"
                                ></ap-input-radio>
                                <ap-input-radio
                                  v-model:model="regParams.vFlagSecurity"
                                  :value="'Y'"
                                  label="보안 (나만 보기)"
                                  id="'vFlagSecurity_Y"
                                  name="flagSecurity"
                                  @click="fnValidate('vFlagSecurity')"
                                ></ap-input-radio>
                              </div>
                              <span class="error-msg" id="error_msg_vFlagSecurity"></span>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <th>예산코드<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
                          <td>
                            <div class="search-form" id="error_wrap_pjtList">
                              <div class="search-form__inner">
                                <ap-input
                                  v-model:value="searchParams.ptsProjectKeyword"
                                  input-class="ui-input__width--340"
                                  placeholder="검색어를 입력하세요."
                                >
                                </ap-input>
                                <button
                                  type="button"
                                  class="button-search"
                                  @click="fnSearchPtsProjectPop"
                                >검색</button>
                              </div>
                              <span class="error-msg" id="error_msg_pjtList"></span>
                            </div>
                          </td>
                        </tr>
                        <tr v-if="regParams?.pjtList?.length > 0">
                          <th></th>
                          <td colspan="3">
                            <div class="search-result-table">
                              <table class="ui-table__reset ui-table__search-result text-center">
                                <colgroup>
                                  <col style="width:15%">
                                  <col style="width:15%">
                                  <col style="width:15%">
                                  <col style="width:auto">
                                  <col style="width:10rem">
                                </colgroup>
                                <thead>
                                  <tr>
                                    <th>예산코드</th>
                                    <th>과제유형</th>
                                    <th>과제성격</th>
                                    <th>과제명</th>
                                    <th></th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr v-for="(vo, index) in regParams.pjtList" :key="'pjt_' + index">
                                    <td>{{ vo.vRpmsCd }}</td>
                                    <td>{{ vo.vPjtType2Nm }}</td>
                                    <td>{{ vo.vPjtTag }}</td>
                                    <td>{{ vo.vPjtNm }}</td>
                                    <td>
                                      <button
                                        type="button"
                                        class="ui-button ui-button__width--40 ui-button__height--23 ui-button__border--blue ui-button__radius--2"
                                        @click="removePtsProject(index)"
                                      >삭제</button>
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <th>과제명<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
                          <td colspan="3">
                            <div id="error_wrap_vContNm">
                              <ap-input
                                v-model:value="regParams.vContNm"
                                input-class="ui-input__width--full"
                                @input="fnValidate('vContNm')"
                              >
                              </ap-input>
                              <span class="error-msg" id="error_msg_vContNm"></span>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <th>고객베네핏</th>
                          <td>
                            <ap-input
                              v-model:value="regParams.vBenefit"
                              input-class="ui-input__width--90"
                            >
                            </ap-input>  
                          </td>
                          <th>제형특징</th>
                          <td>
                            <ap-input
                              v-model:value="regParams.vShapeFeature"
                              input-class="ui-input__width--full"
                            >
                            </ap-input>   
                          </td>
                        </tr>
                        <tr>
                          <th>연구 담당자<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
                          <td>
                            <div class="search-form" id="error_wrap_vUserid">
                              <div class="search-form__inner">
                                <ap-input
                                  v-model:value="regParams.vUsernm"
                                  input-class="ui-input__width--340"
                                  placeholder="검색어를 입력하세요."
                                  :readonly="true"
                                  @click="fnUserSearchPop"
                                >
                                </ap-input>
                                <button type="button" class="button-search" @click="fnUserSearchPop">검색</button>
                              </div>
                              <span class="error-msg" id="error_msg_vUserid"></span>
                            </div>
                          </td>
                          <th>담당부서</th>
                          <td>
                            <DeptTree v-model:deptcd="regParams.vDeptCd" udeptcd="10011" v-model:deptnm="regParams.vDeptNm"/>
                          </td>
                        </tr>
                        <tr>
                          <th>비고</th>
                          <td colspan="3">
                            <div class="ui-textarea-box" id="error_wrap_vNote">
                              <ap-text-area
                                v-model:value="regParams.vNote"
                                :is-with-byte="true"
                                :maxlength="2000"
                                id="vNote"
                              ></ap-text-area>
                              <span class="error-msg" id="error_msg_vNote"></span>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <th>첨부파일</th>
                          <td colspan="3">
                            <UploadFileRegister
                              :uploadid="fileUploadId[noteType]"
                              :parent-info="uploadParams"
                            >
                            </UploadFileRegister>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!--// 과제 (비제품) -->


        <div class="page-bottom">
          <div class="page-bottom__inner">
            <div class="ui-buttons ui-buttons__right">
              <button
                v-if="fnShowTempSaveButton()"
                type="button"
                class="ui-button ui-button__border--blue"
                @click="fnTempSave"
              >임시저장</button>
              <button
                type="button"
                class="ui-button ui-button__bg--skyblue"
                @click="fnSave"
                >저장</button>
                <button
                v-if="fnShowModifyCancelButton()"
                type="button"
                class="ui-button ui-button__border--blue"
                @click="fnModifyCancel"
              >수정취소</button>
              <button
                type="button"
                class="ui-button ui-button__bg--lightgray"
                @click="goList"
              >목록</button>
            </div>
          </div>
        </div>

      </div>
    </div>
    <teleport to="#common-modal" v-if="popupContent">
      <ap-popup>
        <component
          :is="popupContent"
          :pop-params="popParams"
          @selectFunc="popSelectFunc"
        />
      </ap-popup>
    </teleport>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, inject, reactive, onMounted, onUnmounted } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useRoute } from 'vue-router'
import { useStore } from 'vuex'
import { useCode } from '@/compositions/useCode'
import { useNonPrdCommon } from '@/compositions/labcommon/useNonPrdCommon'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'

export default {
  name: 'AllLabNoteNonprdRegister',
  components: {
    UploadFileRegister: defineAsyncComponent(() => import('@/components/comm/UploadFileRegister.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    PtsProjectSearchPop: defineAsyncComponent(() => import('@/components/labcommon/popup/PtsProjectSearchPop.vue')),
    DeptTree: defineAsyncComponent(() => import('@/components/comm/DeptTree.vue')),
    UserSearchPop: defineAsyncComponent(() => import('@/components/comm/popup/UserSearchPop.vue')),
    Mat4MMstSearchPop: defineAsyncComponent(() => import('@/components/labcommon/popup/Mat4MMstSearchPop.vue')),
  },
  setup () {
    const commonUtils = inject('commonUtils')

    const vFlagAction = ref('NONPRD_R')

    const { openAsyncAlert, openAsyncConfirm } = useActions(['openAsyncAlert', 'openAsyncConfirm'])

    const store = useStore()
    const route = useRoute()

    const searchParams = reactive({
      ptsProjectKeyword: ''
    })

    // const regParams = ref({
    //   // 과제구분
    //   vLabTypeCd: '',
    //   // 과제구분 - 4M변경정보 인 경우, 4M이력번호
    //   v4mHisNum: '',
    //   // 보안구분
    //   vFlagSecurity: '',
    //   // 예산코드
    //   pjtList: [],
    //   // 과제명
    //   vContNm: '',
    //   // 고객베네핏
    //   vBenefit: '',
    //   // 제형특징
    //   vShapeFeature: '',
    //   // 연구 담당자,
    //   vUserid: '',
    //   vUsernm: '',
    //   // 담당부서,
    //   vDeptCd: '',
    //   vDeptNm: '',
    //   // 비고
    //   vNote: '',
    // })
    const regParams = ref({})

    const noteType = store.getters.getNoteType()
    const noteTypeNm = store.getters.getNoteTypeNm()

    const pathList = [
      { path: `/${noteTypeNm}/all-lab-note-nonprd-register`, pathNm: 'Project notes' }
    ]

    const fileUploadId = {
      'SC': 'LAB_NOTE_ATT01',
      'MU': 'MAKEUP_NOTE_ATT01',
      'HBO': 'HBO_NOTE_ATT01',
      'SA': 'SA_NOTE_ATT01',
    }

    const uploadParams = reactive({
      vRecordid: '',
      items: []
    })

    const labTypeCdList = ref([])

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const {
      selectReqInfo,
      saveLabNoteNonprdRequest,
      goList,
      goNonprdView,
    } = useNonPrdCommon()

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      fnChangeNoteInfo,
    } = useLabCommon()

    const fnShowTempSaveButton = () => {
      return  vFlagAction.value === 'NONPRD_R' || regParams.value.vStatusCd === 'LNC06_01'
    }
    
    const fnShowModifyCancelButton = () => {
      return vFlagAction.value === 'NONPRD_M'
    }

    const fnModifyCancel = async () => {
      if (!await openAsyncConfirm({ message: '수정을 취소하고 상세 페이지로 이동하시겠습니까?' })) {
        return
      }

      goNonprdView(route.query.vLabNoteCd)
    }

    const fnValidateAll = (arrChkKey) => {
      let isOk = true
      // commonUtils.hideErrorMessageAll(arrChkKey)
      commonUtils.hideErrorMessageAll(['vLabTypeCd', 'vFlagSecurity', 'pjtList', 'vContNm', 'vUserid', 'vNote'])

      arrChkKey.forEach(key => {
        if (!fnValidate(key)) {
          isOk = false
        }
      })

      return isOk
    }

    const fnValidate = (key) => {
      let isOk = true
      let errorMsg = '필수 입력 사항입니다.'
      commonUtils.hideErrorMessage(key)

      if (key === 'pjtList') {
        if (regParams.value?.pjtList?.length === 0) {
          isOk = false
        }
      } else if (key === 'vNote') {
        if (!commonUtils.checkByte(regParams.value.vNote, 2000)) {
          isOk = false
          errorMsg = t('common.msg.byte_msg2', { byteSize: commonUtils.setNumberComma(2000) })
        }
      } else if (commonUtils.isEmpty(regParams.value[key])) {
        isOk = false
      }

      if (!isOk) {
        commonUtils.showErrorMessage(key, errorMsg)
      }

      return isOk
    }

    const fnSaveValidate = (chkObject) => {
      let isOk = true
      if (chkObject.basicChkKey && !fnValidateAll(chkObject.basicChkKey)) {
        isOk = false
      }

      return isOk
    }

    // 임시저장
    const fnTempSave = async () => {
      const basicChkKey = ['vLabTypeCd', 'vFlagSecurity', 'vContNm']

      const chkObject = {
        basicChkKey: basicChkKey
      }

      if (!fnSaveValidate(chkObject)) {
        await openAsyncAlert({ message: '필수 입력사항을 확인해 주세요.' })
        window.scrollTo(0, 0)
        return
      }

      regParams.value.vStatusCd = 'LNC06_01'
      regParams.value.vFlagAction = vFlagAction.value
      regParams.value.fileList = uploadParams.items
      regParams.value.vUploadCd = fileUploadId[noteType]

      const vLabNoteCd = await saveLabNoteNonprdRequest(regParams.value)

      if (vLabNoteCd) {
        await openAsyncAlert({ message: '저장 되었습니다.'})
        goNonprdView(vLabNoteCd)
      }
    }

    // 저장
    const fnSave = async () => {
      const basicChkKey = ['vLabTypeCd', 'vFlagSecurity', 'pjtList', 'vContNm', 'vUserid', 'vNote']

      const chkObject = {
        basicChkKey: basicChkKey,
      }

      if (!fnSaveValidate(chkObject)) {
        await openAsyncAlert({ message: '필수 입력사항을 확인해 주세요.' })
        window.scrollTo(0, 0)
        return
      }

      regParams.value.vStatusCd = 'LNC06_21'
      regParams.value.vFlagAction = vFlagAction.value
      regParams.value.fileList = uploadParams.items
      regParams.value.vUploadCd = fileUploadId[noteType]

      const vLabNoteCd = await saveLabNoteNonprdRequest(regParams.value)

      if (vLabNoteCd) {
        await openAsyncAlert({ message: '저장 되었습니다.'})
        goNonprdView(vLabNoteCd)
      }
    }

    // 연구 담당자 팝업
    const fnUserSearchPop = () => {
      popParams.value.searchFlag = 'LAB'
      popParams.value.vDeptCd = '10011'

      popSelectFunc.value = getUserSearchInfo
      fnOpenPopup('UserSearchPop')
    }

    // 연구 담당자 세팅
    const getUserSearchInfo = (item) => {
      const labor = item.vLabor

      if (commonUtils.isNotEmpty(labor)) {
        regParams.value.vUsernm = item.vUsernm
        regParams.value.vUserid = item.vUserid
        regParams.value.vDeptCd = item.vSigmaDeptcd

        const noteInfo = store.getters.getNoteInfo()
        const newInfo = { ...noteInfo, ...{ vUserid: item.vUserid, vDeptCd: item.vSigmaDeptcd } }

        fnChangeNoteInfo(newInfo)
      } else {
        openAsyncAlert({ message: 'SAP 연구원코드가 존재하지 않습니다.<br>다른 연구원을 지정해주시기 바랍니다.' })
        regParams.value.vUsernm = ''
        regParams.value.vUserid = ''
        regParams.value.vDeptCd = '10011'
      }

      fnValidate('vUserid')
    }

    // 4M 원료 검색 팝업
    const fnMat4MMstSearchPop = () => {
      popParams.value = {
        vKeyword: regParams.value.v4mHisNum,
        vSearchType: 'lab_note',
        vLabDeptCd: regParams.value.vDeptCd,
        vLabNoteCd: regParams.value.vLabNoteCd
      }

      popSelectFunc.value = get4MMatSearchInfo
      fnOpenPopup('Mat4MMstSearchPop')
    }

    // 4M 넘버 세팅
    const get4MMatSearchInfo = (item) => {
      if (item) {
        regParams.value.v4mHisNum = item.v4mHisNum
        regParams.value.v4mMatCd = item.vMatCd
      }
    }
    

    // 예산 코드팝업
    const fnSearchPtsProjectPop = () => {
      popParams.value = {
        vKeyword: searchParams.ptsProjectKeyword
      }

      popSelectFunc.value = getPtsProject
      fnOpenPopup('PtsProjectSearchPop', false)
    }

    // 예산 코드 세팅
    const getPtsProject = (selectList) => {
      if (regParams.value.pjtList.length > 0) {
        selectList.forEach(item => {
          if (regParams.value.pjtList.filter(vo => vo.vPjtCd === item.vPjtCd).length === 0) {
            regParams.value.pjtList.push({ ...item })
          }
        })
      } else {
        regParams.value.pjtList.push(...selectList)
      }

      fnValidate('pjtList')
    }

    // 예산 코드 삭제
    const removePtsProject = (index) => {
      regParams.value.pjtList.splice(index, 1)
      fnValidate('pjtList')
    }

    const init = async () => {
      await findCodeList(['LNC07'])
      // labTypeCdList.value = codeGroupMaps.value['LNC07'].filter(code => code.vBuffer1 === 'NONPRD')
      labTypeCdList.value = commonUtils.getCodeList(codeGroupMaps, 'LNC07', 'NONPRD', null, null)

      const vLabNoteCd = route.query.vLabNoteCd || ''

      if (vLabNoteCd) {
        const result = await selectReqInfo({ vLabNoteCd: vLabNoteCd})
  
        regParams.value = {...regParams.value, ...result}
  
        if (commonUtils.isNotEmpty(regParams.value.vLabNoteCd)) {
          vFlagAction.value = 'NONPRD_M'
          uploadParams.vRecordid = regParams.value.vLabNoteCd
        }
  
        if (regParams.value.verList && regParams.value.verList.length > 0) {
          regParams.value.verList.some((item) => {
            if (Number(item.nVersion) === Number(regParams.value.versionInfo.nVersion)) {
              item.versionInfo = regParams.value.versionInfo
              return true
            }
          })
        }

        if (!regParams.value?.pjtList) {
          regParams.value.pjtList = []
        }

        if (!regParams.value?.vDeptCd) {
          regParams.value.vDeptCd = '10011'
        }
      } else {
        regParams.value = {
          vLabNoteCd: '',
          // 과제구분
          vLabTypeCd: '',
          // 과제구분 - 4M변경정보 인 경우, 4M이력번호
          v4mHisNum: '',
          v4mMatCd: '',
          // 보안구분
          vFlagSecurity: '',
          // 예산코드
          pjtList: [],
          // 과제명
          vContNm: '',
          // 고객베네핏
          vBenefit: '',
          // 제형특징
          vShapeFeature: '',
          // 연구 담당자,
          vUserid: '',
          vUsernm: '',
          // 담당부서,
          vDeptCd: '10011',
          vDeptNm: '',
          // 비고
          vNote: '',
        }
      }

      fnChangeNoteInfo(regParams.value)
    }

    init()

    // onMounted(() => {
    //   uiUtils.accordionEvent()
    // })

    // onUnmounted(() => {
    //   uiUtils.accordionEvent()
    // })

    return {
      commonUtils,
      pathList,
      goList,
      vFlagAction,
      fnTempSave,
      fnSave,
      searchParams,
      regParams,
      fileUploadId,
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      noteType,
      fnShowTempSaveButton,
      fnShowModifyCancelButton,
      fnModifyCancel,
      labTypeCdList,
      uploadParams,
      fnUserSearchPop,
      fnMat4MMstSearchPop,
      fnSearchPtsProjectPop,
      removePtsProject,
      fnValidate,
    }
  }
}
</script>