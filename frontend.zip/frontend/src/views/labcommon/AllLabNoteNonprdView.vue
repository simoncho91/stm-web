<template>
  <div v-show="reqInfo">
    <div class="page-tab">
      <div class="page-tab__inner">
        <HistoryTab
          v-if="reqInfo && commonUtils.isNotEmpty(reqInfo.vContCd)"
          :v-lab-note-cd="vLabNoteCd"
          :url-link="'/' + noteTypeNm + '/all-lab-note-{pageType}-view?vLabNoteCd='"
          @go-list="goList()"
        >
        </HistoryTab>

        <div class="page-tab__contents">
          <ap-breadcrumb nav-title="내용물 개요" :path-list="pathList">
          </ap-breadcrumb>

          <div class="page-tab__item">
            <AllLabNoteNonprdBasicInfoView></AllLabNoteNonprdBasicInfoView>
          </div>
        </div>
        <template v-if="showCodeGenerateBtn()">
          <div style="margin-top: 2rem;"></div>
          <div class="compare-contents__inner p-0 m-0">
            <div class="compare-contents__button">
              <button
                type="button"
                class="ui-button ui-button__border--blue"
                @click="fnCodeGenerationPop"
              >
                파일럿 코드 채번
              </button>
            </div>
          </div>
        </template>
        <template v-if="showProductizationBtn()">
          <div style="margin-top: 2rem;"></div>
          <div class="compare-contents__inner p-0 m-0">
            <div class="compare-contents__button">
              <button
                type="button"
                class="ui-button ui-button__border--blue"
                @click="goCopy(vLabNoteCd)"
              >
                제품화
              </button>
            </div>
          </div>
        </template>
      </div>
    </div>
    <div class="contents-core mt-2">
      <div class="contents-cell__wrap">
        <template v-if="noteType === 'SC' && reqInfo?.vStatusCd !== 'LNC06_01'">
          <div class="contents-cell">
            <div class="contents-box contents-box__full" id="Product">
              <div class="contents-box__inner height_auto">
                <div class="contents-tab">
                  <div class="contents-tab__inner">
                    <div class="contents-tab__header">
                      <ul class="ui-list contents-tab__lists">
                        <li :class="['contents-tab__list', nowTab === 'INVENTORY' ? 'is-active' : '']">
                          <a href="#" class="contents-tab__link" @click.prevent="fnClickTab('INVENTORY')"
                            >참여 인벤토리 (<span>{{ reqInfo?.inventoryList?.length ?? 0 }}</span>)
                          </a>
                        </li>
                        <li :class="['contents-tab__list', nowTab === 'COUNTER' ? 'is-active' : '']">
                          <a href="#" class="contents-tab__link" @click.prevent="fnClickTab('COUNTER')"
                            >해당 과제를 카운터로 사용한 내용물 (<span>{{ reqInfo?.conterList?.length ?? 0 }}</span>)
                          </a>
                        </li>
                      </ul>
                      <button type="button" class="tab-header__button"></button>
                    </div>
                    <div class="contents-tab__body">
                      <div class="contents-tab__body--p25">
                        <div class="sub-contents__item mb-2" v-if="nowTab === 'INVENTORY'">
                          <div class="note-table mt-5">
                            <div class="note-table__inner">
                              <table
                                class="ui-table ui-table__td--40 text-center"
                              >
                                <colgroup>
                                  <col style="width: 15%" />
                                  <col style="width: 15%" />
                                  <col style="width: 15%" />
                                  <col style="width: auto" />
                                </colgroup>
                                <thead>
                                  <tr>
                                    <th>VER</th>
                                    <th>LOT</th>
                                    <th>SP포트</th>
                                    <th>전시회명</th>
                                    <th>인벤토리명</th>
                                    <th>첨부파일</th>
                                    <th>채택여부</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <template v-if="reqInfo?.inventoryList?.length > 0">
                                    <tr v-for="(ivo, idx) in reqInfo.inventoryList" :key="`tr_ivtr_${idx}`">
                                      <td>{{ commonUtils.isNotEmpty(ivo.vVersionNm) ? ivo.vVersionNm : `Ver #${ivo.nVersion <= 9 ? `0${ivo.nVersion}` : ivo.nVersion}` }}</td>
                                      <td>{{ ivo.vLotNm }}</td>
                                      <td><a href="#" class="tit-link" @click.prevent="fnGoSpPopList(ivo.vInvenJoinPjtCd)">{{ ivo.vInvenJoinPjtCd }}</a></td>
                                      <td><a href="#" class="tit-link" @click.prevent="fnGoExhibitionView(ivo.vExhibitionCd)">{{ ivo.vExhibitionNm }}</a></td>
                                      <td><a href="#" class="tit-link" @click.prevent="fnGoInvenDetailPop(ivo.vInvenJoinCd, ivo.vLabNoteCd)">{{ ivo.vSubmitInvenNm }}</a></td>
                                      <td>
                                        <template v-if="ivo.nFileCnt > 0">
                                          <button class="lot-detail__button lot-detail__button-file" @click="fnFileListPop(ivo.vInvenJoinCd)">
                                          </button>
                                        </template>
                                      </td>
                                      <template v-if="commonUtils.isNotEmpty(ivo.vSelectionYn)">
                                        <td>{{ ivo.vSelectionYn === 'Y' ? '선정' : '미선정' }}</td>
                                      </template>
                                      <template v-else>
                                        <td>{{ commonUtils.isNotEmpty(ivo.vExhibitionCd) ? '제출' : '미제출' }}</td>
                                      </template>
                                    </tr>
                                  </template>
                                  <template v-else>
                                    <tr>
                                      <td colspan="7">
                                        <div class="no-result">
                                          {{ t('common.msg.no_data') }}
                                        </div>
                                      </td>
                                    </tr>
                                  </template>
                                </tbody>
                              </table>
                            </div>
                          </div>
                        </div>
                        <div class="sub-contents__item mb-2" v-if="nowTab === 'COUNTER'">
                          <div class="note-table mt-5">
                            <div class="note-table__inner">
                              <table
                                class="ui-table ui-table__td--40 text-center"
                              >
                                <colgroup>
                                  <col style="width: 25%" />
                                  <col style="width: 25%" />
                                  <col style="width: auto" />
                                </colgroup>
                                <thead>
                                  <tr>
                                    <th>실험노트 구분</th>
                                    <th>내용물코드</th>
                                    <th>내용물명 / 과제명</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <template v-if="reqInfo?.conterList?.length > 0">
                                    <tr v-for="(cvo, idx) in reqInfo.conterList" :key="`tr_ctr_${idx}`">
                                      <td>{{ cvo.vLabTypeNm }}</td>
                                      <td>{{ cvo.vContCd }}</td>
                                      <td>{{ cvo.vContNm }}</td>
                                    </tr>
                                  </template>
                                  <template v-else>
                                    <tr>
                                      <td colspan="3">
                                        <div class="no-result">
                                          {{ t('common.msg.no_data') }}
                                        </div>
                                      </td>
                                    </tr>
                                  </template>
                                </tbody>
                              </table>
                            </div>
                          </div>
                        </div>
                        <div class="compare-contents__inner p-0 m-0">
                          <div class="compare-contents__button">
                            <button
                              type="button"
                              class="ui-button ui-button__border--blue"
                              @click="fnOpenTiumInventoryRegPage"
                            >
                              인벤토리 등록
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </template>
        <div class="page-bottom">
          <div class="page-bottom__inner jc-sb">
            <div class="ui-buttons ui-buttons">
            </div>
            <div class="ui-buttons ui-buttons__right">
              <button v-if="showNoteAuthBtn()" type="button" class="ui-button ui-button__bg--blue" @click="fnNoteAuthPop()">노트 공유하기</button>
              <button type="button" class="ui-button ui-button__bg--skyblue" v-if="showModifyBtn()" @click="goNonprdModify(vLabNoteCd)">수정</button>
              <button type="button" class="ui-button ui-button__border--gray" @click="goList()">목록</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <teleport to="#common-modal" v-if="popupContent">
      <ap-popup>
        <component
          :is="popupContent"
          :pop-params="popParams"
          @selectFunc="popSelectFunc"
          @closeFunc="popCloseFunc"
        />
      </ap-popup>
    </teleport>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, computed, provide, inject, getCurrentInstance } from 'vue'
import { useRoute } from 'vue-router'
import { useStore } from 'vuex'
import { useRequestCommon } from '@/compositions/labcommon/useRequestCommon'
import { useNonPrdCommon } from '@/compositions/labcommon/useNonPrdCommon'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useActions } from 'vuex-composition-helpers'
import uiUtils from '@/utils/uiUtils'

import AllLabNoteNonprdBasicInfoView from '@/components/labcommon/AllLabNoteNonprdBasicInfoView.vue'
export default {
  name: 'AllLabNoteNonprdView',
  components: {
    AllLabNoteNonprdBasicInfoView,
    UploadFileView: defineAsyncComponent(() => import('@/components/comm/UploadFileView.vue')),
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    HistoryTab: defineAsyncComponent(() => import('@/components/labcommon/HistoryTab.vue')),
    LabNoteAuthorityPop: defineAsyncComponent(() => import('@/components/labcommon/popup/LabNoteAuthorityPop.vue')),
    CodeGenerationPop: defineAsyncComponent(() => import('@/components/labcommon/popup/CodeGenerationPop.vue')),
    ExhibitAddListNotePop: defineAsyncComponent(() => import('@/components/comm/popup/ExhibitAddListNotePop.vue')),
    UploadFileListPop: defineAsyncComponent(() => import('@/components/comm/popup/UploadFileListPop.vue')),
  },
  mounted() {
    uiUtils.accordionEvent()
  },
  unmounted() {
    uiUtils.accordionEvent()
  },
  setup() {
    const app = getCurrentInstance();
    const tiumUrl = app.appContext.config.globalProperties.tiumUrl

    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const { openAsyncConfirm, openAsyncAlert } = useActions(['openAsyncConfirm', 'openAsyncAlert'])
    const store = useStore()
    const route = useRoute()

    const reqInfo = ref(null)
    const product = ref(null)
    const appr = ref(null)
    const addVerFlag = ref('')
    const noteType = store.getters.getNoteType()
    const noteTypeNm = store.getters.getNoteTypeNm()
    const myInfo = store.getters.getMyInfo()
    const vLabNoteCd = route.query.vLabNoteCd
    const recentNoteList = computed(() => store.getters.getRecentNoteList(noteType))
    const apprMstInfo = ref(null)
    const apprUserList = ref(null)

    const nowTab = ref('INVENTORY')

    const pathList = [
      { path: `/${noteTypeNm}/all-lab-note-nonprd-list`, pathNm: 'Project notes' },
      { path: `/${noteTypeNm}/all-lab-note-nonprd-view`, pathNm: '내용물 개요' },
    ]

    const {
      goModify,
    } = useRequestCommon()

    const {
      selectReqInfo,
      goNonprdModify,
      goList,
    } = useNonPrdCommon()

    const {
      popupContent,
      popParams,
      popSelectFunc,
      popCloseFunc,
      fnOpenPopup,
      fnChangeNoteInfo,
      fnSetRecentLog,
    } = useLabCommon()

    const fnNoteAuthPop = () => {
      popParams.value = {
        vLabNoteCd: reqInfo.value.vLabNoteCd,
        vContCd: reqInfo.value.vContCd,
        vContNm: reqInfo.value.vContNm,
        vPageType: 'nonprd',
      }

      fnOpenPopup('LabNoteAuthorityPop')
    }

    const fnCodeGenerationPop = () => {
      popParams.value = {
        vLabNoteCd: reqInfo.value.vLabNoteCd,
      }
      popCloseFunc.value = refreshView

      fnOpenPopup('CodeGenerationPop')
    }

    const refreshView = () => {
      window.scrollTo(0, 0)
      init()
    }

    const showModifyBtn = () => {
      let isVisible = false

      if (reqInfo.value && (reqInfo.value.vUserid === myInfo.loginId || reqInfo.value.vIsLabNoteAdmin === 'Y')) {
        isVisible = true
      }

      return isVisible
    }

    const showNoteAuthBtn = () => {
      let isVisible = false

      if (reqInfo.value && reqInfo.value.vStatusCd !== 'LNC06_01' && (reqInfo.value.vUserid === myInfo.loginId || reqInfo.value.vIsLabNoteAdmin === 'Y')) {
        isVisible = true
      }

      return isVisible
    }

    const showCodeGenerateBtn = () => {
      let isVisible = false

      if (reqInfo.value && (reqInfo.value.vStatusCd !== 'LNC06_01' && reqInfo.value.vFlagExistMatnr !== 'Y')) {
        isVisible = true
      }

      return isVisible
    }
    
    const showProductizationBtn = () => {
      let isVisible = false

      if (noteType !== 'SC' && reqInfo.value && (reqInfo.value.vStatusCd !== 'LNC06_01' && reqInfo.value.vFlagExistMatnr === 'Y' && commonUtils.isNotEmpty(reqInfo.value.vContCd))) {
        isVisible = true
      }

      return isVisible
    }

    const fnClickTab = (flag = 'INVENTORY') => {
      nowTab.value = flag
    }

    const fnOpenTiumInventoryRegPage = async () => {
      if (!await openAsyncConfirm({ message: '인벤토리 등록 페이지로 이동하시겠습니까?' })) {
        return
      }

      // 인벤토리 등록 페이지
      const targetUrl = `${tiumUrl}/elab/exhibit/sc_exhibit_add_inven_reg.do`

      //새창
      window.open(targetUrl, '_blank')
    }

    const fnGoSpPopList = (vSpCode) => {
      if (vSpCode) {
        popParams.value = {
          vSpCode: vSpCode,
        }

        fnOpenPopup('ExhibitAddListNotePop')
      }
    }

    const fnGoExhibitionView = (exhCd) => {
      if (exhCd) {
        const baseUrl = `${tiumUrl}/elab/exhibit/${noteType.toLowerCase()}_exhibit_add_view.do?i_sExhibitionCd=${exhCd}&i_sNoteType=${noteType}&i_sTypeInvenExhibition=exhibition`

        window.open(baseUrl, '_blank')
      }
    }

    const fnGoInvenDetailPop = (invenCd, noteCd) => {
      if (invenCd && noteCd) {
        const baseUrl = `${tiumUrl}/elab/exhibit/lab_exhibit_add_inven_view.do?i_sInvenJoinCd=${invenCd}&i_sLabNoteCd=${noteCd}&i_sNoteType=${noteType}`

        window.open(baseUrl, '_blank')
      }
    }

    const fnFileListPop = (invenJoinCd) => {
      popParams.value = {
        uploadid: 'INV001',
        recordid: invenJoinCd,
      }

      fnOpenPopup('UploadFileListPop')
    }

    const goCopy = (vLabNoteCd) => {
      goModify(vLabNoteCd, 'Y', 'Y')
    }

    const init = async (vLabNoteCd = route.query.vLabNoteCd) => {
      reqInfo.value = await selectReqInfo({
        vLabNoteCd: vLabNoteCd,
        vPageFlag: 'VIEW',
      })

      if (!reqInfo.value) {
        return
      }

      let recentInfo = null

      if (recentNoteList.value && recentNoteList.value.length > 0) {
        recentInfo = recentNoteList.value.filter((item) => item.vLabNoteCd === reqInfo.value.vLabNoteCd)[0]
      }

      if (!recentInfo && reqInfo.value && commonUtils.isNotEmpty(reqInfo.value.vContCd)) {
        const data = {
          vNoteType: noteType,
          vLabNoteCd: reqInfo.value.vLabNoteCd,
          vContCd: reqInfo.value.vContCd,
          vContNm: reqInfo.value.vContNm,
          vPageType: 'nonprd'
        }
        await fnSetRecentLog(data)
      }

      fnChangeNoteInfo(reqInfo.value)
    }

    init()
    provide('reqInfo', reqInfo)

    return {
      t,
      commonUtils,
      pathList,
      addVerFlag,
      reqInfo,
      vLabNoteCd,
      product,
      appr,
      popupContent,
      popParams,
      popSelectFunc,
      popCloseFunc,
      fnNoteAuthPop,
      fnCodeGenerationPop,
      goNonprdModify,
      init,
      goList,
      showModifyBtn,
      showNoteAuthBtn,
      showCodeGenerateBtn,
      showProductizationBtn,
      apprMstInfo,
      apprUserList,
      noteType,
      noteTypeNm,
      nowTab,
      fnClickTab,
      fnOpenTiumInventoryRegPage,
      fnGoSpPopList,
      fnGoExhibitionView,
      fnGoInvenDetailPop,
      fnFileListPop,
      goCopy,
    }
  },
}
</script>
