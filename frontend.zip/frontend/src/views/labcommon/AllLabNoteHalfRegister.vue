<template>
  <div>
    <ap-breadcrumb
      nav-title="Project notes"
      :path-list="pathList"
    >
    </ap-breadcrumb>
  
    <div class="contents-core">
      <div class="contents-cell__wrap">
        
        <!-- 내용물 개요 -->
        <div class="contents-cell flex-none">
          <div class="contents-box contents-box__full">
            <div class="contents-box__inner min-height__unset">
              
              <div class="arrordion-item is-active">
                <div class="arrordion-header">
                  <div class="arrordion-title">반제품 개발의뢰</div>
                </div>
                <div class="arrordion-body">
                  <div class="basic-info__table">
                    <table class="ui-table__contents">
                      <colgroup>
                        <col style="width:17rem">
                        <col style="width:auto">
                        <col style="width:17rem">
                        <col style="width:auto">
                      </colgroup>
                      <tbody>
                        <tr>
                          <th>예산코드<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
                          <td>
                            <div class="search-form" id="error_wrap_pjtList">
                              <div class="search-form__inner">
                                <ap-input
                                  v-model:value="searchParams.ptsProjectKeyword"
                                  input-class="ui-input__width--340"
                                  placeholder="검색어를 입력하세요."
                                >
                                </ap-input>
                                <button
                                  type="button"
                                  class="button-search"
                                  @click="fnSearchPtsProjectPop"
                                >검색</button>
                              </div>
                              <span class="error-msg" id="error_msg_pjtList"></span>
                            </div>
                          </td>
                        </tr>
                        <tr v-if="regParams?.pjtList?.length > 0">
                          <th></th>
                          <td colspan="3">
                            <div class="search-result-table">
                              <table class="ui-table__reset ui-table__search-result text-center">
                                <colgroup>
                                  <col style="width:15%">
                                  <col style="width:15%">
                                  <col style="width:15%">
                                  <col style="width:auto">
                                  <col style="width:10rem">
                                </colgroup>
                                <thead>
                                  <tr>
                                    <th>예산코드</th>
                                    <th>과제유형</th>
                                    <th>과제성격</th>
                                    <th>과제명</th>
                                    <th></th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr v-for="(vo, index) in regParams.pjtList" :key="'pjt_' + index">
                                    <td>{{ vo.vRpmsCd }}</td>
                                    <td>{{ vo.vPjtType2Nm }}</td>
                                    <td>{{ vo.vPjtTag }}</td>
                                    <td>{{ vo.vPjtNm }}</td>
                                    <td>
                                      <button
                                        type="button"
                                        class="ui-button ui-button__width--40 ui-button__height--23 ui-button__border--blue ui-button__radius--2"
                                        @click="removePtsProject(index)"
                                      >삭제</button>
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <th>브랜드<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
                          <td>
                            <div class="form-flex">
                              <div class="ui-select-box form-flex__cell--5" id="error_wrap_vBrdCd" v-if="vFlagAction === 'HAL4_R' || regParams.vStatusCd === 'LNC06_01'">
                                <ap-selectbox
                                  v-model:value="regParams.vBrdCd"
                                  :input-class="['ui-select__width--full']"
                                  :options="codeGroupMaps['LAB_NOTE_BRAND']"
                                  @change="fnValidate('vBrdCd')"
                                >
                                </ap-selectbox>
                                <span class="error-msg" id="error_msg_vBrdCd"></span>
                              </div>
                              <div class="form-flex__cell--5" v-else>
                                <span class="span_plant">{{ regParams.vBrdNm }}</span>
                              </div>
                            </div>
                          </td>
                          <th>플랜트<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
                          <td>
                            <div class="form-flex" :class="vFlagAction === 'HAL4_R' || regParams.vStatusCd === 'LNC06_01' ? 'form-flex-error' : ''">
                              <div class="ui-select-box ui-form-box__width--200 form-flex__cell--5" id="error_wrap_vPlantCd" v-if="vFlagAction === 'HAL4_R' || regParams.vStatusCd === 'LNC06_01'">
                                <ap-selectbox
                                  v-model:value="regParams.vPlantCd"
                                  input-class="ui-select__width--full"
                                  :options="codeGroupMaps['LAB_NOTE_PLANT']"
                                  @change="fnValidate('vPlantCd');"
                                >
                                </ap-selectbox>
                                <span class="error-msg" id="error_msg_vPlantCd"></span>
                              </div>
                              <div class="form-flex__cell--5" v-else>
                                <span class="span_plant">{{ regParams.vPlantNm }}</span>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <th>반제품명<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
                          <td colspan="3">
                            <div id="error_wrap_vContNm">
                              <ap-input
                                v-model:value="regParams.vContNm"
                                input-class="ui-input__width--full"
                                @input="fnValidate('vContNm')"
                              >
                              </ap-input>
                              <span class="error-msg" id="error_msg_vContNm"></span>
                            </div>
                          </td>
                        </tr>
                        <tr v-if="noteType == 'MU'">
                          <th>제품유형<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
                          <td>
                            <div class="form-flex form-flex-error">
                              <div
                                class="ui-select-box form-flex__cell--5"
                                :class="'ui-form-box__width--' + ((regParams.vProdType2Cd !== '' && Number(regParams?.vProdType2Cd?.replace('MTR02_', '')) > 90) ? '150' : '200')"
                                id="error_wrap_vProdType1Cd"
                              >
                                <ap-selectbox
                                  v-model:value="regParams.vProdType1Cd"
                                  input-class="ui-select__width--full"
                                  :options="codeGroupMaps['MTR01'] ? 
                                            codeGroupMaps['MTR01'].filter(item => item.vBuffer1 === 'MU') : []"
                                  @change="fnValidate('vProdType1Cd');changeProdType1Cd(regParams.vProdType1Cd);"
                                >
                                </ap-selectbox>
                                <span class="error-msg" id="error_msg_vProdType1Cd"></span>
                              </div>
                              <div
                                class="ui-select-box form-flex__cell--5"
                                :class="'ui-form-box__width--' + ((regParams.vProdType2Cd !== '' && Number(regParams?.vProdType2Cd?.replace('MTR02_', '')) > 90) ? '150' : '200')"
                                id="error_wrap_vProdType2Cd"
                              >
                                <ap-selectbox
                                  v-model:value="regParams.vProdType2Cd"
                                  input-class="ui-select__width--full"
                                  :options="regParams.vProdType1Cd !== '' && codeGroupMaps['MTR02'] ?  codeGroupMaps['MTR02'].filter(item => item.vBuffer1 === regParams.vProdType1Cd) : []"
                                  @change="fnValidate('vProdType2Cd');changeProdType2Cd(regParams.vProdType2Cd);"
                                >
                                </ap-selectbox>
                                <span class="error-msg" id="error_msg_vProdType2Cd"></span>
                              </div>
                              <div
                                v-if="regParams.vProdType2Cd !== '' && Number(regParams?.vProdType2Cd?.replace('MTR02_', '')) > 90"
                                class="ui-select-box ui-form-box__width--150 form-flex__cell--5"
                              >
                                <ap-input
                                  v-model:value="regParams.vProdTypeNote"
                                  :maxlength="200"
                                >
                                </ap-input>
                              </div>
                            </div>
                          </td>
                          <th>자재그룹<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
                          <td>
                            <div class="form-flex form-flex-error" v-if="commonUtils.isNotEmpty(regParams.vProdType2Cd)">
                              <div 
                                class="ui-select-box ui-form-box__width--200 form-flex__cell--5"
                                id="error_wrap_vMaterialGroupCd"
                                v-if="mgList.length > 1"
                              >
                                <ap-selectbox
                                  v-model:value="regParams.vMaterialGroupCd"
                                  input-class="ui-select__width--full"
                                  :options="mgList"
                                  @change="fnValidate('vMaterialGroupCd');"
                                >
                                </ap-selectbox>
                                <span class="error-msg" id="error_msg_vMaterialGroupCd"></span>
                              </div>
                              <div v-else-if="mgList.length === 1">
                                <span>
                                  {{ mgList[0].vSubCodenm }}
                                </span>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <th>연구 담당자<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
                          <td>
                            <div class="search-form" id="error_wrap_vUserid">
                              <div class="search-form__inner">
                                <ap-input
                                  v-model:value="regParams.vUsernm"
                                  input-class="ui-input__width--340"
                                  placeholder="검색어를 입력하세요."
                                  :readonly="true"
                                  @click="fnUserSearchPop"
                                >
                                </ap-input>
                                <button type="button" class="button-search" @click="fnUserSearchPop">검색</button>
                              </div>
                              <span class="error-msg" id="error_msg_vUserid"></span>
                            </div>
                          </td>
                          <th>담당부서</th>
                          <td>
                            <DeptTree v-model:deptcd="regParams.vDeptCd" udeptcd="10011" v-model:deptnm="regParams.vDeptNm"/>
                          </td>
                        </tr>
                        <tr>
                          <th>비고</th>
                          <td colspan="3">
                            <div class="ui-textarea-box" id="error_wrap_vNote">
                              <ap-text-area
                                v-model:value="regParams.vNote"
                                :is-with-byte="true"
                                :maxlength="2000"
                                id="vNote"
                              ></ap-text-area>
                              <span class="error-msg" id="error_msg_vNote"></span>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <th>첨부파일</th>
                          <td colspan="3">
                            <UploadFileRegister
                              uploadid="HAL4_NOTE_ATT01"
                              :parent-info="uploadParams"
                            >
                            </UploadFileRegister>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div class="page-bottom">
          <div class="page-bottom__inner">
            <div class="ui-buttons ui-buttons__right">
              <button
                v-if="fnShowTempSaveButton()"
                type="button"
                class="ui-button ui-button__border--blue"
                @click="fnTempSave"
              >임시저장</button>
              <button
                type="button"
                class="ui-button ui-button__bg--skyblue"
                @click="fnSave"
                >저장</button>
                <button
                v-if="fnShowModifyCancelButton()"
                type="button"
                class="ui-button ui-button__border--blue"
                @click="fnModifyCancel"
              >수정취소</button>
              <button
                type="button"
                class="ui-button ui-button__bg--lightgray"
                @click="goList"
              >목록</button>
            </div>
          </div>
        </div>

      </div>
    </div>
    <teleport to="#common-modal" v-if="popupContent">
      <ap-popup>
        <component
          :is="popupContent"
          :pop-params="popParams"
          @selectFunc="popSelectFunc"
        />
      </ap-popup>
    </teleport>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, inject, reactive, watch} from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useRoute } from 'vue-router'
import { useStore } from 'vuex'
import { useCode } from '@/compositions/useCode'
import { useHalfPrdCommon } from '@/compositions/labcommon/useHalfPrdCommon'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'

export default {
  name: 'AllLabNoteHalfRegister',
  components: {
    UploadFileRegister: defineAsyncComponent(() => import('@/components/comm/UploadFileRegister.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    PtsProjectSearchPop: defineAsyncComponent(() => import('@/components/labcommon/popup/PtsProjectSearchPop.vue')),
    DeptTree: defineAsyncComponent(() => import('@/components/comm/DeptTree.vue')),
    UserSearchPop: defineAsyncComponent(() => import('@/components/comm/popup/UserSearchPop.vue')),
    Mat4MMstSearchPop: defineAsyncComponent(() => import('@/components/labcommon/popup/Mat4MMstSearchPop.vue')),
  },
  setup () {
    const commonUtils = inject('commonUtils')

    const vFlagAction = ref('HAL4_R')
    
    const { openAsyncAlert, openAsyncConfirm } = useActions(['openAsyncAlert', 'openAsyncConfirm'])
    
    const store = useStore()
    const route = useRoute()
    
    const myInfo = store.getters.getMyInfo()
    const searchParams = reactive({
      ptsProjectKeyword: ''
    })

    const regParams = ref({})

    const noteType = store.getters.getNoteType()
    const noteTypeNm = store.getters.getNoteTypeNm()

    const mgList = ref([])

    const pathList = [
      { path: `/${noteTypeNm}/all-lab-note-half-register`, pathNm: '4 CODE NOTES' }
    ]

    const uploadParams = reactive({
      vRecordid: '',
      items: []
    })

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const {
      selectReqInfo,
      saveLabNoteRequest,
      goList,
      goView,
    } = useHalfPrdCommon()

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      fnChangeNoteInfo,
    } = useLabCommon()

    const fnShowTempSaveButton = () => {
      return  vFlagAction.value === 'HAL4_R' || regParams.value.vStatusCd === 'LNC06_01'
    }
    
    const fnShowModifyCancelButton = () => {
      return vFlagAction.value === 'HAL4_M'
    }

    const fnModifyCancel = async () => {
      if (!await openAsyncConfirm({ message: '수정을 취소하고 상세 페이지로 이동하시겠습니까?' })) {
        return
      }

      goView(route.query.vLabNoteCd)
    }

    const fnValidateAll = (arrChkKey) => {
      let isOk = true
      
      commonUtils.hideErrorMessageAll(['pjtList', 'vContNm', 'vBrdCd', 'vPlantCd', 'vUserid', 'vDeptCd', 'vNote'])

      arrChkKey.forEach(key => {
        if (!fnValidate(key)) {
          isOk = false
        }
      })

      return isOk
    }

    const fnValidate = (key) => {
      let isOk = true
      let errorMsg = '필수 입력 사항입니다.'
      commonUtils.hideErrorMessage(key)

      if (key === 'pjtList') {
        if (regParams.value?.pjtList?.length === 0) {
          isOk = false
        }
      } else if (key === 'vNote') {
        if (!commonUtils.checkByte(regParams.value.vNote, 2000)) {
          isOk = false
          errorMsg = t('common.msg.byte_msg2', { byteSize: commonUtils.setNumberComma(2000) })
        }
      } else if (commonUtils.isEmpty(regParams.value[key])) {
        isOk = false
      }

      if (!isOk) {
        commonUtils.showErrorMessage(key, errorMsg)
      }

      return isOk
    }

    const fnSaveValidate = (chkObject) => {
      let isOk = true
      if (chkObject.basicChkKey && !fnValidateAll(chkObject.basicChkKey)) {
        isOk = false
      }

      return isOk
    }

    // 임시저장
    const fnTempSave = async () => {
      const basicChkKey = ['vContNm']

      const chkObject = {
        basicChkKey: basicChkKey
      }

      if (!fnSaveValidate(chkObject)) {
        await openAsyncAlert({ message: '필수 입력사항을 확인해 주세요.' })
        window.scrollTo(0, 0)
        return
      }

      regParams.value.vStatusCd = 'LNC06_01'
      regParams.value.vFlagAction = vFlagAction.value
      regParams.value.fileList = uploadParams.items
      regParams.value.vUploadCd = 'HAL4_NOTE_ATT01'

      const vLabNoteCd = await saveLabNoteRequest(regParams.value)

      if (vLabNoteCd) {
        await openAsyncAlert({ message: '저장 되었습니다.'})
        goView(vLabNoteCd)
      }
    }

    // 저장
    const fnSave = async () => {
      const basicChkKey = ['pjtList', 'vContNm', 'vBrdCd', 'vPlantCd', 'vUserid', 'vDeptCd', 'vNote']

      const chkObject = {
        basicChkKey: basicChkKey,
      }

      if (!fnSaveValidate(chkObject)) {
        await openAsyncAlert({ message: '필수 입력사항을 확인해 주세요.' })
        window.scrollTo(0, 0)
        return
      }

      if(regParams.value.vStatusCd == undefined || regParams.value.vStatusCd == "LNC06_01"){
        if (!await openAsyncConfirm({ message: '저장 후 4자코드가 생성됩니다.</br>저장하시겠습니까?' })) {
          return
        }
      }

      regParams.value.vStatusCd = 'LNC06_21'
      regParams.value.vFlagAction = vFlagAction.value
      regParams.value.fileList = uploadParams.items
      regParams.value.vUploadCd = 'HAL4_NOTE_ATT01'

      const vLabNoteCd = await saveLabNoteRequest(regParams.value)

      if (vLabNoteCd) {
        await openAsyncAlert({ message: '저장 되었습니다.'})
        goView(vLabNoteCd)
      }
    }

    // 연구 담당자 팝업
    const fnUserSearchPop = () => {
      popParams.value.searchFlag = 'LAB'
      popParams.value.vDeptCd = '10011'

      popSelectFunc.value = getUserSearchInfo
      fnOpenPopup('UserSearchPop')
    }

    // 연구 담당자 세팅
    const getUserSearchInfo = (item) => {
      const labor = item.vLabor

      if (commonUtils.isNotEmpty(labor)) {
        regParams.value.vUsernm = item.vUsernm
        regParams.value.vUserid = item.vUserid
        regParams.value.vDeptCd = item.vSigmaDeptcd

        const noteInfo = store.getters.getNoteInfo()
        const newInfo = { ...noteInfo, ...{ vUserid: item.vUserid, vDeptCd: item.vSigmaDeptcd } }

        fnChangeNoteInfo(newInfo)
      } else {
        openAsyncAlert({ message: 'SAP 연구원코드가 존재하지 않습니다.<br>다른 연구원을 지정해주시기 바랍니다.' })
        regParams.value.vUsernm = ''
        regParams.value.vUserid = ''
        regParams.value.vDeptCd = '10011'
      }

      fnValidate('vUserid')
    }

    // 예산 코드팝업
    const fnSearchPtsProjectPop = () => {
      popParams.value = {
        vKeyword: searchParams.ptsProjectKeyword
      }

      popSelectFunc.value = getPtsProject
      fnOpenPopup('PtsProjectSearchPop', false)
    }

    // 예산 코드 세팅
    const getPtsProject = (selectList) => {
      if (regParams.value.pjtList.length > 0) {
        selectList.forEach(item => {
          if (regParams.value.pjtList.filter(vo => vo.vPjtCd === item.vPjtCd).length === 0) {
            regParams.value.pjtList.push({ ...item })
          }
        })
      } else {
        regParams.value.pjtList.push(...selectList)
      }

      fnValidate('pjtList')
    }

    // 예산 코드 삭제
    const removePtsProject = (index) => {
      regParams.value.pjtList.splice(index, 1)
      fnValidate('pjtList')
    }

    const changePlantCd = (selectCode) => {
      const noteInfo = store.getters.getNoteInfo()
      const newInfo = { ...noteInfo, ...{vPlantCd: selectCode} }
      setSiteType()
      fnChangeNoteInfo(newInfo)
    }

    const changeSiteType = (selectCode) => {
      const noteInfo = store.getters.getNoteInfo()
      const newInfo = { ...noteInfo, ...{vSiteType: selectCode} }
      fnChangeNoteInfo(newInfo)
    }

    const setSiteType = () => {
      const siteOption = codeGroupMaps.value['MA_PLANT'].filter(item => item.vBuffer1 === (commonUtils.isEmpty(regParams.value.vPlantCd) ? 'CN20' : regParams.value.vPlantCd))
      regParams.value.vSiteType = siteOption.length === 1 ? siteOption[0].vSubCode : ''
    }

    const changeProdType1Cd = (selectCode) => {
      regParams.value.vProdType2Cd = ''
      const noteInfo = store.getters.getNoteInfo()
      const newInfo = { ...noteInfo, ...{vProdType1Cd: selectCode} }
      fnChangeNoteInfo(newInfo)
    }

    const setMgList = (selectCode) => {
      const prodTypeInfo = codeGroupMaps.value['MTR02'].filter(vo => vo.vSubCode === selectCode)

      if (prodTypeInfo) {
        const buffer2 = prodTypeInfo[0].vBuffer2
        //자재그룹코드 [LNC24]
        if (buffer2 !== 'ALL') {
          mgList.value = [ ...codeGroupMaps.value['LNC24'].filter(item => buffer2.indexOf(item.vSubCode) > -1) ]
        } else {
          mgList.value = [ ...codeGroupMaps.value['LNC24']]
        }
      }
    }

    const changeProdType2Cd = (selectCode) => {
      setMgList(selectCode)

      regParams.value.vMaterialGroupCd = ''
      if(mgList.value.length === 1){
        regParams.value.vMaterialGroupCd = mgList.value[0].vSubCode
        regParams.value.vMaterialGroupNm = mgList.value[0].vSubCodenm
      }

      const noteInfo = store.getters.getNoteInfo()
      const newInfo = { ...noteInfo, ...{vProdType2Cd: selectCode} }
      fnChangeNoteInfo(newInfo)
    }

    const init = async () => {

      const arrMstCode = [
        'LAB_NOTE_BRAND', 'LAB_NOTE_PLANT', 'MA_PLANT', 'MTR01', 'MTR02', 'LNC24'
      ]
      await findCodeList(arrMstCode)
      
      codeGroupMaps.value['LNC24'].forEach(item => {
        item.vSubCodenm = '[' + item.vSubCode + '] ' + item.vSubCodenm
      })

      const vLabNoteCd = route.query.vLabNoteCd || ''

      if (vLabNoteCd) {
        const result = await selectReqInfo({ vLabNoteCd: vLabNoteCd})
  
        regParams.value = {...regParams.value, ...result}
  
        if (commonUtils.isNotEmpty(regParams.value.vLabNoteCd)) {
          vFlagAction.value = 'HAL4_M'
          uploadParams.vRecordid = regParams.value.vLabNoteCd
        }

        if (!regParams.value?.pjtList) {
          regParams.value.pjtList = []
        }

        if (!regParams.value?.vDeptCd) {
          regParams.value.vDeptCd = '10011'
        }

        if (commonUtils.isNotEmpty(regParams.value.vProdType2Cd)) {
          setMgList(regParams.value.vProdType2Cd)
        }
      } else {
        regParams.value = {
          vLabNoteCd: '',
          //반제품일때
          vLabTypeCd: 'LNC07_02',
          // 예산코드
          pjtList: [],
          //브랜드
          vBrdCd: '',
          //플랜트
          vPlantCd: '',
          // 반제품명
          vContNm: '',
          // 반제품코드
          vContCd: '',
          //제품유형
          vProdType1Cd: '',
          vProdType2Cd: '',
          vProdTypeNote: '',
          // 연구 담당자,
          vUserid: '',
          vUsernm: '',
          // 담당부서,
          vDeptCd: '10011',
          vDeptNm: '',
          // 비고
          vNote: '',
        }
      }

      fnChangeNoteInfo(regParams.value)
    }

    init()

    // onMounted(() => {
    //   uiUtils.accordionEvent()
    // })

    // onUnmounted(() => {
    //   uiUtils.accordionEvent()
    // })

    return {
      commonUtils,
      pathList,
      goList,
      vFlagAction,
      fnTempSave,
      fnSave,
      searchParams,
      regParams,
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      noteType,
      myInfo,
      codeGroupMaps,
      mgList,
      changeProdType1Cd,
      changeProdType2Cd,
      changePlantCd,
      changeSiteType,
      fnShowTempSaveButton,
      fnShowModifyCancelButton,
      fnModifyCancel,
      uploadParams,
      fnUserSearchPop,
      fnSearchPtsProjectPop,
      removePtsProject,
      fnValidate,
    }
  }
}
</script>