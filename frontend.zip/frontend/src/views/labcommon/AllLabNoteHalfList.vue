<template>
  <ap-breadcrumb nav-title="4 code notes" :path-list="pathList">
  </ap-breadcrumb>

  <div class="contents-core">
    <div class="contents-cell__wrap">
      <div class="contents-cell">
        <div class="contents-box contents-box__full">
          <div class="contents-box__inner">
            <AllLabNoteListSearch @onSearch="onSearch" :search-params="searchParams" pageType="half"/>

            <div class="total-page form-flex-between">
              <div class="form-flex">
                <template v-if="page && page.totalPageCnt">
                  <div class="total-page__case">총<span class="total-page__num">{{ commonUtils.setNumberComma(page.totalCnt) }}</span>건</div>
                  <div class="total-page__page">총 <span class="total-page__num">{{ commonUtils.setNumberComma(page.totalPageCnt) }}</span>페이지</div>
                </template>
              </div>
              <div class="ui-buttons ui-buttons__right">
                <button type="button" class="ui-button ui-button__bg--skyblue" @click="goRegister()">등록</button>
              </div>
            </div>

            <AllLabNoteHalfListTable
              @onPaging="onPaging"
              @onSorting="onSorting"
              :result-list="list"
              :result-page="page"
            />
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--//.contents-core -->
</template>

<script>
import { ref, inject } from 'vue'
import { useStore } from 'vuex'
import { useHalfPrdCommon } from '@/compositions/labcommon/useHalfPrdCommon'

import AllLabNoteListSearch from '@/components/labcommon/AllLabNoteListSearch.vue'
import AllLabNoteHalfListTable from '@/components/labcommon/AllLabNoteHalfListTable.vue'
export default {
  name: 'AllLabNoteList',
  components: {
    AllLabNoteListSearch,
    AllLabNoteHalfListTable,
  },
  setup() {
    const store = useStore()
    const commonUtils = inject('commonUtils')
    const searchParams = ref({
      vListType: 'HAL4',
      vBrdAllYn: '',
      brdCdList: [],
      vStatusAllYn: '',
      statusCdList: [],
      vDeptCd: '',
      vFlagMyLabNote: '',
      vKeyword: '',
      nowPageNo: 1,
      vSortCol: '',
      vSortDir: '',
    })

    const noteTypeNm = store.getters.getNoteTypeNm()
    const pathList = [
      { path: `/${noteTypeNm}/all-lab-note-half-list`, pathNm: '4 CODE NOTES' },
    ]

    const {
      noteType,
      page,
      list,
      selectReqList,
      goRegister,
    } = useHalfPrdCommon()

    const init = async () => {
      const sessionParam = JSON.parse(sessionStorage.getItem('searchParams_half_' + noteType))

      if (sessionParam) {
        searchParams.value = { ...sessionParam, ...{ nowPageNo: searchParams.value.nowPageNo, vListType: 'HAL4' } }
      }

      const result = await selectReqList(searchParams.value)

      if (result) {
        searchParams.value = { ...searchParams.value, ...{vFlagMyLabNote: result.vFlagMyLabNote }}
      }
    }

    const onSearch = async (param) => {
      searchParams.value = { ...param, nowPageNo: 1 }
      await init()
    }

    const onPaging = (pg) => {
      searchParams.value = { ...searchParams.value, nowPageNo: pg }
      init()
    }

    const onSorting = (sortInfo) => {
      searchParams.value = { ...searchParams.value, ...sortInfo }
      onSearch(searchParams.value)
    }

    init()

    return {
      commonUtils,
      pathList,
      list,
      page,
      searchParams,
      onSearch,
      onPaging,
      onSorting,
      goRegister,
    }
  },
}
</script>
