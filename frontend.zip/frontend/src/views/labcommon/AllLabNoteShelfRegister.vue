<template>
  <div>
    <ap-breadcrumb nav-title="내용물 개요" :path-list="pathList">
    </ap-breadcrumb>

    <div class="contents-core">
      <div class="contents-cell__wrap">
        <div class="contents-cell flex-none">
          <div class="contents-box contents-box__full">
            <div class="contents-box__inner min-height__unset">
              <div class="arrordion-item is-active">
                <div class="arrordion-header">
                  <div class="arrordion-title">기본정보</div>
                </div>
                <div class="arrordion-body">
                  <div class="basic-info__table">
                    <table class="ui-table__reset ui-table__ver ui-table__td--40 text-center">
                      <colgroup>
                        <col style="width:17rem">
                        <col style="width:auto">
                        <col style="width:17rem">
                        <col style="width:auto">
                      </colgroup>
                      <tbody>
                        <tr>
                          <th>등록자</th>
                          <td>{{ myInfo.userNm }}</td>
                          <th>등록일시</th>
                          <td>{{ commonUtils.changeStrDatePattern(commonUtils.parseDateToStr(new Date())) }}</td>
                        </tr>
                        <tr>
                          <th>상태</th>
                          <td>{{ map.vStatusCdNm || '-' }}</td>
                          <th>구분<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
                          <td>
                            <div class="form-flex">
                              <div
                                id="error_wrap_vNoteType"
                                class="ui-select-box ui-form-box__width--200  form-flex__cell--5"
                              >
                                <ap-selectbox
                                  :input-class="'ui-select__width--full'"
                                  v-model:value="map.vNoteType"
                                  :options="codeGroupMaps['LNC25']"
                                  @change="fnValidate('vNoteType')"
                                />
                                <span class="error-msg" id="error_msg_vNoteType"></span>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <th>문서종류</th>
                          <td>
                            <ap-input-radio
                              v-model:model="map.vDocKind"
                              :value="map.vDocKind"
                              :label="map.vDocKindNm"
                              :id="'ex_radio'"
                              name="exRadio"
                            >
                            </ap-input-radio>
                          </td>
                        </tr>
                        <tr>
                          <th>변경사유<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
                          <td colspan="3">
                            <div
                              id="error_wrap_vChangeReason"
                              class="ui-textarea-box ui-textarea-box__height--100"
                            >
                            <ap-text-area :is-with-byte="false" v-model:value="map.vChangeReason" @input="fnValidate('vChangeReason');"></ap-text-area>
                              <span class="error-msg" id="error_msg_vChangeReason"></span>
                            </div>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              <div class="mt-30">

                <div class="arrordion-item is-active">
                  <div class="arrordion-header">
                    <div class="arrordion-title">내용물 정보</div>
                  </div>
                  <div class="arrordion-body">
                    <div class="note-table mt-15">
                      <div class="note-table__inner">
                        <table class="ui-table ui-table__td--40 text-center">
                          <colgroup>
                            <col style="width:12%">
                            <col style="width:auto">
                            <col style="width:15%">
                            <col style="width:10%">
                            <col style="width:20%">
                          </colgroup>
                          <thead>
                            <tr>
                              <th>내용물코드</th>
                              <th>내용물 명</th>
                              <th>플랜트</th>
                              <th>사용기한</th>
                              <th>변경 사용기한</th>
                            </tr>
                          </thead>
                          <tbody>
                            <template v-if="list?.length > 0">
                              <tr v-for="(vo, idx) in list" :key="'tr_' + idx">
                                <td>{{ vo.vContCd }}</td>
                                <td>{{ vo.vMaktx }}</td>
                                <td>
                                  {{ vo.vPlantNm }}
                                  <template v-if="finalSubPlantList?.filter(o => o.vContCd === vo.vContCd).length > 0">
                                    <div v-for="(rvo, idx2) in finalSubPlantList.filter(o => o.vContCd === vo.vContCd)" :key="'fsp_' + idx2">
                                      {{ rvo.vPlantNm }}
                                    </div>
                                  </template>
                                </td>
                                <td>{{ vo.vOriginShelfLife }}</td>
                                <td>
                                  <ap-selectbox
                                    :input-class="'ui-select__width--110'"
                                    v-model:value="vo.vShelfLife"
                                    :options="codeGroupMaps['SHELF_LIFE_CODE']"
                                    :default-blank="{ blank: false }"
                                  />
                                  <div
                                    v-show="vo.vShelfLife === 'ETC'"
                                    style="text-align: center;"
                                    class="mt-5"
                                    :id="`error_wrap_vEtcLife_${idx}`"
                                  >
                                    <ap-input
                                      input-class="ui-input__width--110"
                                      :is-number="true"
                                      v-model:value="vo.vEtcLife"
                                      @input="fnValidateEtcLife(idx)"
                                    ></ap-input>
                                    <span class="error-msg" :id="`error_msg_vEtcLife_${idx}`"></span>
                                  </div>
                                </td>
                              </tr>
                            </template>
                            <template v-else>
                              <tr>
                                <td colspan="5">
                                  <div class="no-result">
                                    {{ t('common.msg.no_data') }}
                                  </div>
                                </td>
                              </tr>
                            </template>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="mt-30">
                <ReferenceRegister
                  ref="refComp"
                  record-id=""
                  :default-list="refDefaultList"
                >
                </ReferenceRegister>
              </div>

              <div class="mt-30">
                <ApprovalRegister
                  appr-cd=""
                  appr-class="LAB_NOTE_SHELFLIFE"
                  ref="appr"
                  :default-list="apprDefaultList"
                >
                </ApprovalRegister>
              </div>

            </div>
          </div>
        </div>
        <div class="page-bottom">
          <div class="page-bottom__inner">
            <div class="ui-buttons ui-buttons__right">
              <button
                type="button"
                class="ui-button ui-button__bg--skyblue"
                @click="fnApprovalRequest()"
              >결재의뢰</button>
              <button
                type="button"
                class="ui-button ui-button__border--gray"
                @click="historyBack()"
              >뒤로가기</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'
import { useCode } from '@/compositions/useCode'
import { useComm } from '@/compositions/useComm'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useRoute, useRouter } from 'vue-router'
import { useStore } from 'vuex'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'AllLabNoteShelfRegister',
  components: {
    ApprovalRegister: defineAsyncComponent(() => import('@/components/comm/ApprovalRegister.vue')),
    ReferenceRegister: defineAsyncComponent(() => import('@/components/comm/ReferenceRegister.vue'))
  },
  setup(context) {
    const { openAsyncAlert, openAsyncConfirm } = useActions(['openAsyncAlert', 'openAsyncConfirm'])
    const t = inject('t')
    const commonUtils = inject('commonUtils')

    const route = useRoute()
    const router = useRouter()
    const store = useStore()

    const query = route.query
    const myInfo = store.getters.getMyInfo()
    const noteTypeNm = store.getters.getNoteTypeNm()

    const pathList = [
      { path: `/${noteTypeNm}/all-lab-note-prd-list`, pathNm: 'ALL LAB NOTE' },
      { path: `/${noteTypeNm}/all-lab-note-prd-view`, pathNm: '내용물 개요' }
    ]

    const appr = ref(null)
    const refComp = ref(null)

    const map = ref({
      vStatusCdNm: '',
      vNoteType: '',
      vDocKind: '',
      vDocKindNm: '',
      vChangeReason: ''
    })
    const list = ref([])
    const finalSubPlantList = ref([])

    const apprDefaultList = ref([])    
    const refDefaultList = ref([])  
    
    const refList = {
      '1110': [
        {
          vFlagRec: 'REF010',
          vFlagRecNm: '참조부서',
          vRefCd: '75192',
          vRefNm: 'SC QC팀'
        },
        {
          vFlagRec: 'REF010',
          vFlagRecNm: '참조부서',
          vRefCd: '75193',
          vRefNm: 'MU QC팀'
        }
      ],
      '1111': [{
        vFlagRec: 'REF010',
        vFlagRecNm: '참조부서',
        vRefCd: '20078',
        vRefNm: '데일리뷰티 QC팀'
      }],
      '1510': [{
        vFlagRec: 'REF010',
        vFlagRecNm: '참조부서',
        vRefCd: '38000005',
        vRefNm: '품질보증팀'
      }],
      'default': [{
        vFlagRec: 'REF010',
        vFlagRecNm: '참조부서',
        vRefCd: '20412',
        vRefNm: '분석 Lab'
      }]
    }

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const {
      selectDeptLeader
    } = useComm()

    const {
      selectLabNoteShelfLifeInfo,
      updateLabNoteShelfLifeInfo
    } = useLabCommon()

    const fnValidateAll = (arrChkKey) => {
      let isOk = true
      commonUtils.hideErrorMessageAll(arrChkKey)

      arrChkKey.forEach(key => {
        if (!fnValidate(key)) {
          isOk = false
        }
      })

      if (list.value?.length > 0) {
        for (let idx = 0; idx < list.value.length; idx++) {
          const vo = list.value[idx]

          if (vo.vShelfLife === 'ETC' && !fnValidateEtcLife(idx)) {
            isOk = false
            break
          }
        }
      }

      return isOk
    }

    const fnValidateEtcLife = (idx) => {
      commonUtils.hideErrorMessage(`vEtcLife_${idx}`)

      let isOk = true
      let errorMsg = '필수 입력 사항입니다.'

      if (commonUtils.isEmpty(list.value[idx].vEtcLife)) {
        isOk = false
      }

      if (!isOk) {
        commonUtils.showErrorMessage(`vEtcLife_${idx}`, errorMsg)
      }

      return isOk
    }

    const fnValidate = (key) => {
      commonUtils.hideErrorMessage(key)

      let isOk = true
      let errorMsg = '필수 입력 사항입니다.'

      if (commonUtils.isEmpty(map.value[key])) {
        isOk = false
      }

      if (!isOk) {
        commonUtils.showErrorMessage(key, errorMsg)
      }

      return isOk
    }

    const historyBack = () => {
      if(query.vCodeType == 'HAL4'){
        router.push({ path: `/${noteTypeNm}/all-lab-note-half-view`, query: { vLabNoteCd: query.vLabNoteCd }})
      }else{
        router.push({ path: `/${noteTypeNm}/all-lab-note-prd-view`, query: { vLabNoteCd: query.vLabNoteCd }})
      }
    }

    const fnApprovalRequest = async () => {
      if (!await openAsyncConfirm({ message: '결재 하시겠습니까?' })) {
        return
      }

      if (!fnValidateAll(['vNoteType', 'vChangeReason'])) {
        openAsyncAlert({ message: '필수 값을 확인해 주세요.' })
        return
      }

      if (list.value?.length === 0) {
        openAsyncAlert({ message: '하나이상의 내용물코드가 필요합니다.' })
        return
      }

      let payload = {
        vContFlag: 'SAVE',
        vSaveStatus: 'SLS070'
      }

      payload = {
        ...payload,
        ...map.value,
        contInfoList: [ ...list.value ],
        referenceList: refComp.value.referenceList,
        apprParams: {
          apprInfo: appr.value.apprInfo,
          apprList: appr.value.apprList
        }
      }

      const result = await updateLabNoteShelfLifeInfo(payload)

      if (result?.data === 'success') {
        await openAsyncAlert({ message: '결재 요청되었습니다.' })
        historyBack()
      }
    }

    const addContEvent = () => {
      const obj = {
        vContCd: '',
        vContType: '',
        vDocKind: '',
        vFlagSubPlant: '',
        vMaktx: '',
        vNoteType: '',
        vOriginShelfLife: '',
        vPlantCd: '',
        vShelfLife: '6',
        vStatusCd: '',
        vUsernm: '',
      }

      list.value.push(obj)
    }

    const delContEvent = (idx) => {
      list.value.splice(idx, 1)

      if (list.value.length === 0) {
        addContEvent()
      }
    }

    const init = async () => {
      if (query?.vContCd || query?.contCdList) {
        await findCodeList(['LNC25', 'SHELF_LIFE_CODE'])
        codeGroupMaps.value['LNC25'] = codeGroupMaps.value['LNC25'].filter(vo => vo.vSubCode !== 'BF')

        const resData1 = await selectLabNoteShelfLifeInfo(query)
        // map.value = resData1.map
        map.value = { ...map.value, ...resData1.map }
        list.value = resData1.list
        if (list.value?.length > 0) {
          list.value.forEach(vo => {
            const shelfLifeCode = codeGroupMaps.value['SHELF_LIFE_CODE'].filter(v => v.vSubCode === vo.vShelfLife)
            vo.vOriginShelfLife = vo.vShelfLife
            vo.vShelfLife = shelfLifeCode && shelfLifeCode.length > 0 ? shelfLifeCode[0].vSubCode : '6'
          })
        }

        finalSubPlantList.value = resData1.finalSubPlantList

        // [s] 참조처 디폴트 리스트 생성
        const plantCdList = [...new Set([
          ...list.value.map(vo => vo.vPlantCd),
          ...finalSubPlantList.value.map(vo => vo.vPlantCd)
        ])]

        if (plantCdList?.length > 0) {
          plantCdList.forEach(plantCd => {
            if (refList[plantCd]) {
              refDefaultList.value = [
                ...refDefaultList.value,
                ...refList[plantCd]
              ]
            }
          })
        }

        refDefaultList.value = [
          ...refDefaultList.value,
          ...refList['default']
        ]
        // [e] 참조처 디폴트 리스트 생성
        
        // [s] 결재선 디폴트 리스트 생성(현재 사용자의 부서장)
        const resData2 = await selectDeptLeader()

        const tempList = []

        if (resData2?.length > 0) {
          resData2.forEach(vo => {
            if (vo) {
              tempList.push({
                vApprDeptnm: vo.vSigmaDeptnm,
                // vApprDutynm: item.dutyNm,
                vApprPhoneno: vo.vPhoneNO,
                vApprPositnm: vo.vPositnm,
                vApprUserNm: vo.vUsernm,
                vApprUserType: 'USR010',
                vApprUserid: vo.vUserid
              })
            }
          })
        }

        apprDefaultList.value = tempList
        // [e] 결재선 디폴트 리스트 생성(현재 사용자의 부서장)
      }
    }

    init()

    return {
      t,
      commonUtils,
      codeGroupMaps,
      pathList,
      myInfo,
      map,
      list,
      finalSubPlantList,
      query,
      fnValidateEtcLife,
      fnValidate,
      fnApprovalRequest,
      apprDefaultList,
      refDefaultList,
      historyBack,
      appr,
      refComp,
      addContEvent,
      delContEvent,
    }
  }
}
</script>
