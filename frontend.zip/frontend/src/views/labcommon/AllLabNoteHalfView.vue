<template>
  <div class="page-tab" v-show="reqInfo">
    <div class="page-tab__inner">
      <HistoryTab
        v-if="reqInfo && commonUtils.isNotEmpty(reqInfo.vContCd)"
        :v-lab-note-cd="vLabNoteCd"
        :url-link="'/'+ noteTypeNm +'/all-lab-note-{pageType}-view?vLabNoteCd='"
        @go-list="goList()"
      >
      </HistoryTab>

      <div class="page-tab__contents">
        <ap-breadcrumb
          nav-title="내용물 개요"
          :path-list="pathList"
        >
        </ap-breadcrumb>

        <div class="page-tab__item">
          <AllLabNoteHalfBasicInfoView></AllLabNoteHalfBasicInfoView>
        </div>
      </div>
    </div>
  </div>

  <div class="contents-core">
    <div class="contents-cell__wrap">

      <div class="page-bottom">
        <div class="page-bottom__inner form-flex-between">
          <div class="ui-buttons ui-buttons__left">
                <button v-if="showStatusBtn()" type="button" class="ui-button ui-button__border--gray" @click="fnPlantExtendPop()">플랜트 확장</button>
          </div>
          <div class="ui-buttons ui-buttons__right">
            <button v-if="showStatusBtn()" type="button" class="ui-button ui-button__bg--blue" @click="fnNoteAuthPop()">노트 공유하기</button>
            <button type="button" class="ui-button ui-button__bg--skyblue" @click="goModify(reqInfo.vLabNoteCd)">수정</button>
            <button type="button" class="ui-button ui-button__border--gray" @click="goList()">목록</button>
          </div>
        </div>
      </div>
    </div>
  </div>
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @selectFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, ref, computed, provide, inject } from 'vue'
import { useRoute } from 'vue-router'
import { useStore } from 'vuex'
import { useHalfPrdCommon } from '@/compositions/labcommon/useHalfPrdCommon'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useActions } from 'vuex-composition-helpers'
import uiUtils from '@/utils/uiUtils'

import AllLabNoteHalfBasicInfoView from '@/components/labcommon/AllLabNoteHalfBasicInfoView.vue'
export default {
  name: 'AllLabNoteHalfView',
  components: {
    AllLabNoteHalfBasicInfoView,
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    HistoryTab: defineAsyncComponent(() => import('@/components/labcommon/HistoryTab.vue')),
    PlantExtendPop: defineAsyncComponent(() => import('@/components/labcommon/popup/PlantExtendPop.vue')),
    LabNoteAuthorityPop: defineAsyncComponent(() => import('@/components/labcommon/popup/LabNoteAuthorityPop.vue')),
  },
  mounted () {
    uiUtils.accordionEvent()
  },
  unmounted () {
    uiUtils.accordionEvent()
  },
  setup () {
    const commonUtils = inject('commonUtils')
    const { openAsyncConfirm, openAsyncAlert } = useActions(['openAsyncConfirm', 'openAsyncAlert'])
    const store = useStore()
    const route = useRoute()
    
    const reqInfo = ref(null)
    const product = ref(null)
    const appr = ref(null)
    const addVerFlag = ref('')
    const noteType = store.getters.getNoteType()
    const noteTypeNm = store.getters.getNoteTypeNm()
    const myInfo = store.getters.getMyInfo()
    const vLabNoteCd = route.query.vLabNoteCd
    const recentNoteList = computed(() => store.getters.getRecentNoteList(noteType))
    const apprMstInfo = ref(null)
    const apprUserList = ref(null)

    const pathList = [
      { path: `/${noteTypeNm}/all-lab-note-half-list`, pathNm: '4 CODE NOTES' },
      { path: `/${noteTypeNm}/all-lab-note-half-view`, pathNm: '내용물 개요' }
    ]
    
    const {
      selectReqInfo,
      goModify,
      goList,
    } = useHalfPrdCommon()

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      fnChangeNoteInfo,
      fnSetRecentLog,
    } = useLabCommon()

    const fnPlantExtendPop = () => {
      popParams.value = {
        vLabNoteCd: reqInfo.value.vLabNoteCd,
        vCodeType: reqInfo.value.vCodeType,
        vContNm: reqInfo.value.vContNm,
        vNoteType: noteType,
        vBrdCd: reqInfo.value.vBrdCd,
      }

      fnOpenPopup('PlantExtendPop')
    }

    const fnNoteAuthPop = () => {
      popParams.value = {
        vLabNoteCd: reqInfo.value.vLabNoteCd,
        vContCd: reqInfo.value.vContCd,
        vContNm: reqInfo.value.vContNm,
        vPageType: 'half',
      }

      fnOpenPopup('LabNoteAuthorityPop')
    }

    const showModifyBtn = () => {
      let isVisible = false

      if (reqInfo.value && reqInfo.value.vIsLabNoteAdmin === 'Y' && reqInfo.value.vIsLabNoteStatus === 'Y') {
        isVisible = true
      }

      return isVisible
    }
    
    const init = async (vLabNoteCd = route.query.vLabNoteCd) => {
      reqInfo.value = await selectReqInfo({ vLabNoteCd: vLabNoteCd, vPageFlag: 'VIEW' })

      if (!reqInfo.value) {
        return
      }

      let recentInfo = null
      if (recentNoteList.value && recentNoteList.value.length > 0) {
        recentInfo = recentNoteList.value.filter(item => item.vLabNoteCd === reqInfo.value.vLabNoteCd)[0]
      }

      if (!recentInfo && reqInfo.value && commonUtils.isNotEmpty(reqInfo.value.vContCd)) {
        const data = {
          vNoteType: noteType,
          vLabNoteCd: reqInfo.value.vLabNoteCd,
          vContCd: reqInfo.value.vContCd,
          vContNm: reqInfo.value.vContNm,
          vPageType: 'half'
        }
        await fnSetRecentLog(data)
      }
      
      fnChangeNoteInfo(reqInfo.value)
    }
    
    const showStatusBtn = () => {
      let isVisible = false

      if (reqInfo?.value?.vStatusCd != 'LNC06_01')
      {
        isVisible = true
      }

      return isVisible
    }
    
    init()
    provide('reqInfo', reqInfo)

    return {
      commonUtils,
      pathList,
      addVerFlag,
      reqInfo,
      noteTypeNm,
      vLabNoteCd,
      product,
      appr,
      popupContent,
      popParams,
      popSelectFunc,
      fnPlantExtendPop,
      fnNoteAuthPop,
      goModify,
      init,
      goList,
      showModifyBtn,
      showStatusBtn,
      apprMstInfo,
      apprUserList,
    }
  }
}
</script>
