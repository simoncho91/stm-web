<template>
  <div>
    <div class="contents-core">
      <div class="contents-cell__wrap">
        <div class="contents-cell">
          <template v-for="vo in mainList" :key="vo.vMenuid">
            <template v-if="vo.vView === 'Y'">
              <component :is="'MyBoard' + vo.vMenuid"></component>
            </template>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { computed, ref, inject, defineAsyncComponent, watch } from 'vue'
import { useStore } from 'vuex'

export default {
  name: 'MyBoard',
  components: {
    MyBoardEM: defineAsyncComponent(() => import('@/components/labcommon/MyBoardEM.vue')),
    MyBoardNS: defineAsyncComponent(() => import('@/components/labcommon/MyBoardNS.vue')),
  },
  setup () {
    const commonUtils = inject('commonUtils')
    const store = useStore()
    const storedMainList = computed(() => store.getters.getMainList())
    const mainList = ref([])
    const init = () => {
      if (commonUtils.isEmpty(storedMainList.value)) {
        const defaultList = [
          { nSeq: 0, vMenuid: 'NS', vView: 'Y' },
          { nSeq: 1, vMenuid: 'EM', vView: 'Y' },
        ]
        mainList.value = [...defaultList]
      } else {
        mainList.value = [...storedMainList.value]
      }
    }

    init()

    watch(() => storedMainList.value, (newVal, oldVal) => {
      if (newVal !== oldVal && commonUtils.isNotEmpty(newVal)) {
        mainList.value = [...newVal]
      } else if (commonUtils.isEmpty(newVal)) {
        const defaultList = [
          { nSeq: 0, vMenuid: 'NS', vView: 'Y' },
          { nSeq: 1, vMenuid: 'EM', vView: 'Y' },
        ]
        mainList.value = [...defaultList]
      }
    })
    
    return {
      mainList,
    }
  }
}
</script>