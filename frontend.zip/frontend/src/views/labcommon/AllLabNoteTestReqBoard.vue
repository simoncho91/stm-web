<template>

    <div class="contents-core" v-show="isShow">
      <div class="contents-cell__wrap">
        <div class="contents-cell">
          <div class="contents-box contents-box__full">
            <div class="contents-box__inner p-0">
            
            <div class="page-tab">
              <div class="page-tab__inner">

                <HistoryTab
                  :v-lab-note-cd="vLabNoteCd"
                  :url-link="'/'+ noteTypeNm +'/all-lab-note-test-req-board?vLabNoteCd='"
                  @go-list="goList()"
                >
                </HistoryTab>

                <div class="code-spray__wrap" v-if="testReq.contList.length > 1 ">
                  <ul class="ui-list code-spray__list">
                    <li class="code-spray__item" style="width:7.8rem;" v-for="(cvo, index) in testReq.contList" :key="index">
                      <button 
                        class="code-spray__button code-spray__button--code" 
                        :class="cvo.vContCd === searchParams.vContCd ? 'is-click' : ''"
                        @click="fnContClick(cvo.vContPkCd,cvo.vContCd)">
                        <span class="code-spray__button__num">{{cvo.vContCd}}</span>
                        <span class="code-spray__button__approx">{{ cvo.vTctnBynmNm?.substring(0, 6) }}</span>
                      </button>
                    </li>
                  </ul>
                </div>

                <div class="page-tab__contents">
                  <div class="nav">
                    <div class="nav__inner">
                      <div class="nav-title">시험의뢰</div>
                    </div>
                  </div>

                  <div class="page-tab__item">
                    <div class="page-tab__item--inner">
                      <div class="request-status mt-15">
                        <div class="request-status__inner">
                          <div class="sub-contents__item">
                            <div class="sub-contents__title d-flex align-center">
                              <template v-if="testReq.contList.length > 1">
                                <template v-for="(vo, index) in testReq.contList" :key="index">
                                  <template v-if="vo.vContCd === searchParams.vContCd">
                                    {{ vo.vContNm }}
                                  </template>
                                </template>
                              </template>
                              <template v-else>
                                {{testReq.noteInfo.vContNm}}
                              </template>
                              <button type="button" class="ui-button ui-button__height--28 ui-button__bg--skyblue ml-auto" @click="fnQrCreate">QR코드 생성</button>
                            </div>

                            <div class="request-status__table" v-if="isShow">
                              <div class="request-status__table--inner">
                                <div class="ui-table__request-wrap ui-table__request--variable" v-if="testReq.noData != 'N'">
                                  <table class="ui-table text-center ui-table__request" v-if="testReq.resultMap" style="width:100%">
                                    <colgroup>
                                      <col style="width:240px">
                                      <template v-for="(vo, index) in testReq.verLotList" :key="index">
                                        <col style="width:120px">
                                      </template>
                                      <col :style="'width:'+(899-(120*(testReq.verLotList.length-1)))+'px'">
                                    </colgroup>
                                    <thead>
                                      <tr>
                                        <th>TEST NAME </th>
                                        <template v-for="(vo, index) in testReq.verLotList" :key="index">
                                          <th v-if="vo.vClinicalTestYn == 'N'">Ver. {{Number(vo.nLabNoteVer) < 10 ? '0' + vo.nLabNoteVer : vo.nLabNoteVer }} / {{vo.vLotNm}}</th>
                                          <th v-else>Ver. {{Number(vo.nLabNoteVer) < 10 ? '0' + vo.nLabNoteVer : vo.nLabNoteVer }}</th>
                                        </template>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      <tr>
                                        <td class="request-status__title--td">
                                          <div class="request-status__title">
                                            <i class="request-status__icon request-status__icon01"></i>
                                            <div class="request-status__text">부향 시험 의뢰</div>
                                          </div>
                                        </td>
                                        <!-- 버전,로트 개수만큼 생성 -->
                                        <td v-for="(vLvo, idx) in testReq.verLotList" :key="idx">
                                          <!-- 해당 시험법만 생성 되도록 -->
                                          <div class="request-status__badge--wrap request-status__badge--useSwiper" v-if="testReq.resultMap['MRQ060']">
                                            <div class="request-status__badge--slide">
                                              <!-- 툴팁 생성 부분 -->
                                              <div class="ui-tooltip-wrap ui-tooltip__parent">
                                                <div class="ui-tooltip-item">
                                                  <template v-for="(vo, index) in testReq.resultMap['MRQ060']" :key="index">
                                                    <template v-if="vLvo.nLabNoteVer == vo.nLabNoteVer && vLvo.vLotNm == vo.vLotNm">
                                                      <span
                                                        class="ui-tooltip ui-tooltip__top"
                                                        :class="vo.tooltipActive === 'Y' ? 'is-active' : ''"
                                                      >
                                                        <span class="ui-tooltip__inner" v-html="commonUtils.removeHTMLChangeBr(vo.vTrResMrq060Txt)"></span>
                                                      </span>
                                                    </template>
                                                  </template>
                                                </div>
                                              </div>
                                              <!-- 툴팁 생성 부분 -->

                                              <template v-for="(fvo, index) in testReq.resultMap['MRQ060']" :key="index">
                                                <template v-if="vLvo.nLabNoteVer == fvo.nLabNoteVer && vLvo.vLotNm == fvo.vLotNm">
                                                  <!-- nRowOrderNum == 1, 한번 만 생성되어야함 -->
                                                  <swiper 
                                                    :modules="modules"
                                                    :slide-per-view="1"
                                                    navigation
                                                    :pagination="{ dynamicBullets:true, dynamicMainBullets:5 }"
                                                    v-if="fvo.nRowOrderNum == 1"
                                                  >
                                                  <!-- nRowOrderNum == 1, 한번 만 생성되어야함 -->

                                                    <template v-for="(vo, index) in testReq.resultMap['MRQ060']" :key="index">
                                                      <template v-if="vLvo.nLabNoteVer == vo.nLabNoteVer && vLvo.vLotNm == vo.vLotNm">
                                                        <!-- 해당 시험의뢰,버전,로트의 시험 횟수 -->
                                                        <swiper-slide>
                                                          <div :class="['request-status__badge', 'request-status__badge--' + vo.vTrResMrq060Color ]">
                                                            <div
                                                              :class="['request-status__badge--text', vo.vLabGateCd == 'GATE_2' ? 'request-status__badge--ptag' : '', 'ui-tooltip-inslide']"
                                                              @mouseover="fnShowTooltip(vo, 'vTrResMrq060Txt')"
                                                              @mouseout="fnHideTooltip(vo)"
                                                            >
                                                              <template v-if="vo.vTrResMrq060Color === 'green'">
                                                                요청
                                                              </template>
                                                              <template v-else-if="vo.vTrResMrq060Color === 'blue'">
                                                                합격
                                                              </template>
                                                              <template v-else-if="vo.vTrResMrq060Color === 'red'">
                                                                불합격
                                                              </template>
                                                              <template v-else>
                                                                
                                                              </template>
                                                            </div>
                                                            <div class="d-flex align-center" style="padding-right: 20px;">
                                                              <div class="ui-checkbox-block p-0 mr-5">
                                                                <ap-input-check
                                                                  value="Y"
                                                                  false-value=""
                                                                  :id="'qr_check_yn_MRQ060_' + index"
                                                                  label=""
                                                                  inputClass="qr_check_yn"                                                                 
                                                                  @click="fnQrCheck('MRQ060',vo.vProductCd,vo.nVersion)"
                                                                >
                                                                </ap-input-check>
                                                              </div>
                                                              <div class="request-status__badge--date" @click="goTestReqView('MRQ060',vo.vProductCd,vo.nVersion)">{{ commonUtils.changeStrDatePattern2(vo.vLabReqDtm) }}</div>
                                                            </div>
                                                          </div>
                                                        </swiper-slide>
                                                      <!-- 해당 시험의뢰,버전,로트의 시험 횟수 -->
                                                      </template>
                                                    </template>

                                                  </swiper>
                                                </template>
                                              </template>

                                            </div>
                                          </div>
                                        </td>
                                        <td></td>
                                      </tr>
                                      <tr>
                                        <td class="request-status__title--td">
                                          <div class="request-status__title">
                                            <i class="request-status__icon request-status__icon02"></i>
                                            <div class="request-status__text">안전성 시험 의뢰</div>
                                          </div>
                                        </td>
                                        <!-- 버전,로트 개수만큼 생성 -->
                                        <td v-for="(vLvo, idx) in testReq.verLotList" :key="idx">
                                          <!-- 해당 시험법만 생성 되도록 -->
                                          <div class="request-status__badge--wrap request-status__badge--useSwiper" v-if="testReq.resultMap['MRQ010']">
                                            <div class="request-status__badge--slide">
                                              <!-- 툴팁 생성 부분 -->
                                              <div class="ui-tooltip-wrap ui-tooltip__parent">
                                                <div class="ui-tooltip-item">
                                                  <template v-for="(vo, index) in testReq.resultMap['MRQ010']" :key="index">
                                                    <template v-if="vLvo.nLabNoteVer == vo.nLabNoteVer && vLvo.vLotNm == vo.vLotNm">
                                                      <span
                                                        class="ui-tooltip ui-tooltip__top"
                                                        :class="vo.tooltipActive === 'Y' ? 'is-active' : ''"
                                                      >
                                                        <span class="ui-tooltip__inner" v-html="commonUtils.removeHTMLChangeBr(vo.vTrResMrq010Txt)"></span>
                                                      </span>
                                                    </template>
                                                  </template>
                                                </div>
                                              </div>
                                              <!-- 툴팁 생성 부분 -->

                                              <template v-for="(fvo, index) in testReq.resultMap['MRQ010']" :key="index">
                                                <template v-if="vLvo.nLabNoteVer == fvo.nLabNoteVer && vLvo.vLotNm == fvo.vLotNm">
                                                  <!-- nRowOrderNum == 1, 한번 만 생성되어야함 -->
                                                  <swiper 
                                                    :modules="modules"
                                                    :slide-per-view="1"
                                                    navigation
                                                    :pagination="{ dynamicBullets:true, dynamicMainBullets:5 }"
                                                    v-if="fvo.nRowOrderNum == 1"
                                                  >
                                                  <!-- nRowOrderNum == 1, 한번 만 생성되어야함 -->

                                                    <template v-for="(vo, index) in testReq.resultMap['MRQ010']" :key="index">
                                                      <template v-if="vLvo.nLabNoteVer == vo.nLabNoteVer && vLvo.vLotNm == vo.vLotNm">
                                                        <!-- 해당 시험의뢰,버전,로트의 시험 횟수 -->
                                                        <swiper-slide>
                                                          <div :class="['request-status__badge', 'request-status__badge--' + vo.vTrResMrq010Color ]">
                                                            <div
                                                              :class="['request-status__badge--text', vo.vLabGateCd == 'GATE_2' ? 'request-status__badge--ptag' : '', 'ui-tooltip-inslide']"
                                                              @mouseover="fnShowTooltip(vo, 'vTrResMrq010Txt')"
                                                              @mouseout="fnHideTooltip(vo)"
                                                            >
                                                              <template v-if="vo.vTrResMrq010Color === 'green'">
                                                                요청
                                                              </template>
                                                              <template v-else-if="vo.vTrResMrq010Color === 'blue'">
                                                                합격
                                                              </template>
                                                              <template v-else-if="vo.vTrResMrq010Color === 'red'">
                                                                불합격
                                                              </template>
                                                              <template v-else>
                                                                
                                                              </template>
                                                            </div>
                                                            <div class="d-flex align-center" style="padding-right: 20px;">
                                                              <div class="ui-checkbox-block p-0 mr-5">
                                                                <ap-input-check
                                                                  value="Y"
                                                                  false-value=""
                                                                  :id="'qr_check_yn_MRQ010_' + index"
                                                                  label=""
                                                                  inputClass="qr_check_yn"
                                                                  :disabled="vo.vStatusCd != 'PDS010' ? false : true"
                                                                  @click="fnQrCheck('MRQ010',vo.vProductCd,vo.nVersion)"
                                                                >
                                                                </ap-input-check>
                                                              </div>
                                                              <div class="request-status__badge--date" @click="goTestReqView('MRQ010',vo.vProductCd,vo.nVersion)">{{ commonUtils.changeStrDatePattern2(vo.vLabReqDtm) }}</div>
                                                            </div>
                                                          </div>
                                                        </swiper-slide>
                                                      <!-- 해당 시험의뢰,버전,로트의 시험 횟수 -->
                                                      </template>
                                                    </template>

                                                  </swiper>
                                                </template>
                                              </template>

                                            </div>
                                          </div>
                                        </td>
                                        <td></td>
                                      </tr>
                                      <tr>
                                        <td class="request-status__title--td">
                                          <div class="request-status__title">
                                            <i class="request-status__icon request-status__icon03"></i>
                                            <div class="request-status__text">방부 시험 의뢰</div>
                                          </div>
                                        </td>
                                        <!-- 버전,로트 개수만큼 생성 -->
                                        <td v-for="(vLvo, idx) in testReq.verLotList" :key="idx">
                                          <!-- 해당 시험법만 생성 되도록 -->
                                          <div class="request-status__badge--wrap request-status__badge--useSwiper" v-if="testReq.resultMap['MRQ011']">
                                            <div class="request-status__badge--slide">
                                              <!-- 툴팁 생성 부분 -->
                                              <div class="ui-tooltip-wrap ui-tooltip__parent">
                                                <div class="ui-tooltip-item">
                                                  <template v-for="(vo, index) in testReq.resultMap['MRQ011']" :key="index">
                                                    <template v-if="vLvo.nLabNoteVer == vo.nLabNoteVer && vLvo.vLotNm == vo.vLotNm">
                                                      <span
                                                        class="ui-tooltip ui-tooltip__top"
                                                        :class="vo.tooltipActive === 'Y' ? 'is-active' : ''"
                                                      >
                                                        <span class="ui-tooltip__inner" v-html="commonUtils.removeHTMLChangeBr(vo.vTrResMrq011Txt)"></span>
                                                      </span>
                                                    </template>
                                                  </template>
                                                </div>
                                              </div>
                                              <!-- 툴팁 생성 부분 -->

                                              <template v-for="(fvo, index) in testReq.resultMap['MRQ011']" :key="index">
                                                <template v-if="vLvo.nLabNoteVer == fvo.nLabNoteVer && vLvo.vLotNm == fvo.vLotNm">
                                                  <!-- nRowOrderNum == 1, 한번 만 생성되어야함 -->
                                                  <swiper 
                                                    :modules="modules"
                                                    :slide-per-view="1"
                                                    navigation
                                                    :pagination="{ dynamicBullets:true, dynamicMainBullets:5 }"
                                                    v-if="fvo.nRowOrderNum == 1"
                                                  >
                                                  <!-- nRowOrderNum == 1, 한번 만 생성되어야함 -->

                                                    <template v-for="(vo, index) in testReq.resultMap['MRQ011']" :key="index">
                                                      <template v-if="vLvo.nLabNoteVer == vo.nLabNoteVer && vLvo.vLotNm == vo.vLotNm">
                                                        <!-- 해당 시험의뢰,버전,로트의 시험 횟수 -->
                                                        <swiper-slide>
                                                          <div :class="['request-status__badge', 'request-status__badge--' + vo.vTrResMrq011Color ]">
                                                            <div
                                                              :class="['request-status__badge--text', vo.vLabGateCd == 'GATE_2' ? 'request-status__badge--ptag' : '', 'ui-tooltip-inslide']"
                                                              @mouseover="fnShowTooltip(vo, 'vTrResMrq011Txt')"
                                                              @mouseout="fnHideTooltip(vo)"
                                                            >
                                                              <template v-if="vo.vTrResMrq011Color === 'green'">
                                                                요청
                                                              </template>
                                                              <template v-else-if="vo.vTrResMrq011Color === 'blue'">
                                                                합격
                                                              </template>
                                                              <template v-else-if="vo.vTrResMrq011Color === 'red'">
                                                                불합격
                                                              </template>
                                                              <template v-else>
                                                                
                                                              </template>
                                                            </div>
                                                            <div class="d-flex align-center" style="padding-right: 20px;">
                                                              <div class="ui-checkbox-block p-0 mr-5">
                                                                <ap-input-check
                                                                  value="Y"
                                                                  false-value=""
                                                                  :id="'qr_check_yn_MRQ011_' + index"
                                                                  label=""
                                                                  inputClass="qr_check_yn"
                                                                  :disabled="vo.vStatusCd != 'PDS010' ? false : true"
                                                                  @click="fnQrCheck('MRQ011',vo.vProductCd,vo.nVersion)"
                                                                >
                                                                </ap-input-check>
                                                              </div>
                                                              <div class="request-status__badge--date" @click="goTestReqView('MRQ011',vo.vProductCd,vo.nVersion)">{{ commonUtils.changeStrDatePattern2(vo.vLabReqDtm) }}</div>
                                                            </div>
                                                          </div>
                                                        </swiper-slide>
                                                      <!-- 해당 시험의뢰,버전,로트의 시험 횟수 -->
                                                      </template>
                                                    </template>

                                                  </swiper>
                                                </template>
                                              </template>

                                            </div>
                                          </div>
                                        </td>
                                        <td></td>
                                      </tr>
                                      <tr>
                                        <td class="request-status__title--td">
                                          <div class="request-status__title">
                                            <i class="request-status__icon request-status__icon04"></i>
                                            <div class="request-status__text">기능성 시험 의뢰</div>
                                          </div>
                                        </td>
                                        <!-- 버전,로트 개수만큼 생성 -->
                                        <td v-for="(vLvo, idx) in testReq.verLotList" :key="idx">
                                          <!-- 해당 시험법만 생성 되도록 -->
                                          <div class="request-status__badge--wrap request-status__badge--useSwiper" v-if="testReq.resultMap['MRQ040_FUNC']">
                                            <div class="request-status__badge--slide">
                                              <!-- 툴팁 생성 부분 -->
                                              <div class="ui-tooltip-wrap ui-tooltip__parent">
                                                <div class="ui-tooltip-item">
                                                  <template v-for="(vo, index) in testReq.resultMap['MRQ040_FUNC']" :key="index">
                                                    <template v-if="vLvo.nLabNoteVer == vo.nLabNoteVer && vLvo.vLotNm == vo.vLotNm">
                                                      <span
                                                        class="ui-tooltip ui-tooltip__top"
                                                        :class="vo.tooltipActive === 'Y' ? 'is-active' : ''"
                                                      >
                                                        <span class="ui-tooltip__inner" v-html="commonUtils.removeHTMLChangeBr(vo.vTrResMrq040FuncTxt)"></span>
                                                      </span>
                                                    </template>
                                                  </template>
                                                </div>
                                              </div>
                                              <!-- 툴팁 생성 부분 -->

                                              <template v-for="(fvo, index) in testReq.resultMap['MRQ040_FUNC']" :key="index">
                                                <template v-if="vLvo.nLabNoteVer == fvo.nLabNoteVer && vLvo.vLotNm == fvo.vLotNm">
                                                  <!-- nRowOrderNum == 1, 한번 만 생성되어야함 -->
                                                  <swiper 
                                                    :modules="modules"
                                                    :slide-per-view="1"
                                                    navigation
                                                    :pagination="{ dynamicBullets:true, dynamicMainBullets:5 }"
                                                    v-if="fvo.nRowOrderNum == 1"
                                                  >
                                                  <!-- nRowOrderNum == 1, 한번 만 생성되어야함 -->

                                                    <template v-for="(vo, index) in testReq.resultMap['MRQ040_FUNC']" :key="index">
                                                      <template v-if="vLvo.nLabNoteVer == vo.nLabNoteVer && vLvo.vLotNm == vo.vLotNm">
                                                        <!-- 해당 시험의뢰,버전,로트의 시험 횟수 -->
                                                        <swiper-slide>
                                                          <div :class="['request-status__badge', 'request-status__badge--' + vo.vTrResMrq040FuncColor ]">
                                                            <div
                                                              :class="['request-status__badge--text', vo.vLabGateCd == 'GATE_2' ? 'request-status__badge--ptag' : '', 'ui-tooltip-inslide']"
                                                              @mouseover="fnShowTooltip(vo, 'vTrResMrq040FuncTxt')"
                                                              @mouseout="fnHideTooltip(vo)"
                                                            >
                                                              <template v-if="vo.vTrResMrq040FuncColor === 'green'">
                                                                요청
                                                              </template>
                                                              <template v-else-if="vo.vTrResMrq040FuncColor === 'blue'">
                                                                합격
                                                              </template>
                                                              <template v-else-if="vo.vTrResMrq040FuncColor === 'red'">
                                                                불합격
                                                              </template>
                                                              <template v-else>
                                                                
                                                              </template>
                                                            </div>
                                                            <div class="d-flex align-center" style="padding-right: 20px;">
                                                              <div class="ui-checkbox-block p-0 mr-5">
                                                                <ap-input-check
                                                                  value="Y"
                                                                  false-value=""
                                                                  :id="'qr_check_yn_MRQ040_FUNC_' + index"
                                                                  label=""
                                                                  inputClass="qr_check_yn"
                                                                  @click="fnQrCheck('MRQ040_FUNC',vo.vProductCd,vo.nVersion)"
                                                                >
                                                                </ap-input-check>
                                                              </div>
                                                              <div class="request-status__badge--date" @click="goTestReqView('MRQ040_FUNC',vo.vProductCd,vo.nVersion)">{{ commonUtils.changeStrDatePattern2(vo.vLabReqDtm) }}</div>
                                                            </div>
                                                          </div>
                                                        </swiper-slide>
                                                      <!-- 해당 시험의뢰,버전,로트의 시험 횟수 -->
                                                      </template>
                                                    </template>

                                                  </swiper>
                                                </template>
                                              </template>

                                            </div>
                                          </div>
                                        </td>
                                        <td></td>
                                      </tr>
                                      <tr>
                                        <td class="request-status__title--td">
                                          <div class="request-status__title">
                                            <i class="request-status__icon request-status__icon08"></i>
                                            <div class="request-status__text">유해물질 시험의뢰</div>
                                          </div>
                                        </td>
                                        <!-- 버전,로트 개수만큼 생성 -->
                                        <td v-for="(vLvo, idx) in testReq.verLotList" :key="idx">
                                          <!-- 해당 시험법만 생성 되도록 -->
                                          <div class="request-status__badge--wrap request-status__badge--useSwiper" v-if="testReq.resultMap['MRQ040_HARM']">
                                            <div class="request-status__badge--slide">
                                              <!-- 툴팁 생성 부분 -->
                                              <div class="ui-tooltip-wrap ui-tooltip__parent">
                                                <div class="ui-tooltip-item">
                                                  <template v-for="(vo, index) in testReq.resultMap['MRQ040_HARM']" :key="index">
                                                    <template v-if="vLvo.nLabNoteVer == vo.nLabNoteVer && vLvo.vLotNm == vo.vLotNm">
                                                      <span
                                                        class="ui-tooltip ui-tooltip__top"
                                                        :class="vo.tooltipActive === 'Y' ? 'is-active' : ''"
                                                      >
                                                        <span class="ui-tooltip__inner" v-html="commonUtils.removeHTMLChangeBr(vo.vTrResMrq040HarmTxt)"></span>
                                                      </span>
                                                    </template>
                                                  </template>
                                                </div>
                                              </div>
                                              <!-- 툴팁 생성 부분 -->

                                              <template v-for="(fvo, index) in testReq.resultMap['MRQ040_HARM']" :key="index">
                                                <template v-if="vLvo.nLabNoteVer == fvo.nLabNoteVer && vLvo.vLotNm == fvo.vLotNm">
                                                  <!-- nRowOrderNum == 1, 한번 만 생성되어야함 -->
                                                  <swiper 
                                                    :modules="modules"
                                                    :slide-per-view="1"
                                                    navigation
                                                    :pagination="{ dynamicBullets:true, dynamicMainBullets:5 }"
                                                    v-if="fvo.nRowOrderNum == 1"
                                                  >
                                                  <!-- nRowOrderNum == 1, 한번 만 생성되어야함 -->

                                                    <template v-for="(vo, index) in testReq.resultMap['MRQ040_HARM']" :key="index">
                                                      <template v-if="vLvo.nLabNoteVer == vo.nLabNoteVer && vLvo.vLotNm == vo.vLotNm">
                                                        <!-- 해당 시험의뢰,버전,로트의 시험 횟수 -->
                                                        <swiper-slide>
                                                          <div :class="['request-status__badge', 'request-status__badge--' + vo.vTrResMrq040HarmColor ]">
                                                            <div
                                                              :class="['request-status__badge--text', vo.vLabGateCd == 'GATE_2' ? 'request-status__badge--ptag' : '', 'ui-tooltip-inslide']"
                                                              @mouseover="fnShowTooltip(vo, 'vTrResMrq040HarmTxt')"
                                                              @mouseout="fnHideTooltip(vo)"
                                                            >
                                                              <template v-if="vo.vTrResMrq040HarmColor === 'green'">
                                                                요청
                                                              </template>
                                                              <template v-else-if="vo.vTrResMrq040HarmColor === 'blue'">
                                                                합격
                                                              </template>
                                                              <template v-else-if="vo.vTrResMrq040HarmColor === 'red'">
                                                                불합격
                                                              </template>
                                                              <template v-else>
                                                                
                                                              </template>
                                                            </div>
                                                            <div class="d-flex align-center" style="padding-right: 20px;">
                                                              <div class="ui-checkbox-block p-0 mr-5">
                                                                <ap-input-check
                                                                  value="Y"
                                                                  false-value=""
                                                                  :id="'qr_check_yn_MRQ040_HARM_' + index"
                                                                  label=""
                                                                  inputClass="qr_check_yn"
                                                                  @click="fnQrCheck('MRQ040_HARM',vo.vProductCd,vo.nVersion)"
                                                                >
                                                                </ap-input-check>
                                                              </div>
                                                              <div class="request-status__badge--date" @click="goTestReqView('MRQ040_HARM',vo.vProductCd,vo.nVersion)">{{ commonUtils.changeStrDatePattern2(vo.vLabReqDtm) }}</div>
                                                            </div>
                                                          </div>
                                                        </swiper-slide>
                                                      <!-- 해당 시험의뢰,버전,로트의 시험 횟수 -->
                                                      </template>
                                                    </template>

                                                  </swiper>
                                                </template>
                                              </template>

                                            </div>
                                          </div>
                                        </td>
                                        <td></td>
                                      </tr>
                                      <tr>
                                        <td class="request-status__title--td">
                                          <div class="request-status__title">
                                            <i class="request-status__icon request-status__icon05"></i>
                                            <div class="request-status__text">효능/임상 시험 의뢰</div>
                                          </div>
                                        </td>
                                        <!-- 버전,로트 개수만큼 생성 -->
                                        <td v-for="(vLvo, idx) in testReq.verLotList" :key="idx">
                                          <!-- 해당 시험법만 생성 되도록 -->
                                          <div class="request-status__badge--wrap request-status__badge--useSwiper" v-if="testReq.resultMap['CLINICAL']">
                                            <div class="request-status__badge--slide">
                                              <!-- 툴팁 생성 부분 -->
                                              <div class="ui-tooltip-wrap ui-tooltip__parent">
                                                <div class="ui-tooltip-item">
                                                  <template v-for="(vo, index) in testReq.resultMap['CLINICAL']" :key="index">
                                                    <template v-if="vLvo.nLabNoteVer == vo.nLabNoteVer && vLvo.vLotNm == vo.vLotNm">
                                                      <span
                                                        class="ui-tooltip ui-tooltip__top"
                                                        :class="vo.tooltipActive === 'Y' ? 'is-active' : ''"
                                                      >
                                                        <span class="ui-tooltip__inner" v-html="commonUtils.removeHTMLChangeBr(vo.vTrResClinicalTxt)"></span>
                                                      </span>
                                                    </template>
                                                  </template>
                                                </div>
                                              </div>
                                              <!-- 툴팁 생성 부분 -->

                                              <template v-for="(fvo, index) in testReq.resultMap['CLINICAL']" :key="index">
                                                <template v-if="vLvo.nLabNoteVer == fvo.nLabNoteVer && vLvo.vLotNm == fvo.vLotNm">
                                                  <!-- nRowOrderNum == 1, 한번 만 생성되어야함 -->
                                                  <swiper 
                                                    :modules="modules"
                                                    :slide-per-view="1"
                                                    navigation
                                                    :pagination="{ dynamicBullets:true, dynamicMainBullets:5 }"
                                                    v-if="fvo.nRowOrderNum == 1"
                                                  >
                                                  <!-- nRowOrderNum == 1, 한번 만 생성되어야함 -->

                                                    <template v-for="(vo, index) in testReq.resultMap['CLINICAL']" :key="index">
                                                      <template v-if="vLvo.nLabNoteVer == vo.nLabNoteVer && vLvo.vLotNm == vo.vLotNm">
                                                        <!-- 해당 시험의뢰,버전,로트의 시험 횟수 -->
                                                        <swiper-slide>
                                                          <div :class="['request-status__badge', 'request-status__badge--' + vo.vTrResClinicalColor ]">
                                                            <div
                                                              :class="['request-status__badge--text', vo.vLabGateCd == 'GATE_2' ? 'request-status__badge--ptag' : '', 'ui-tooltip-inslide']"
                                                              @mouseover="fnShowTooltip(vo, 'vTrResClinicalTxt')"
                                                              @mouseout="fnHideTooltip(vo)"
                                                            >
                                                              <template v-if="vo.vTrResClinicalColor === 'green'">
                                                                요청
                                                              </template>
                                                              <template v-else-if="vo.vTrResClinicalColor === 'blue'">
                                                                합격
                                                              </template>
                                                              <template v-else-if="vo.vTrResClinicalColor === 'red'">
                                                                불합격
                                                              </template>
                                                              <template v-else>
                                                                
                                                              </template>
                                                            </div>
                                                            <div class="d-flex align-center" style="padding-right: 20px;">
                                                              <div class="ui-checkbox-block p-0 mr-5">
                                                                <ap-input-check
                                                                  value="Y"
                                                                  false-value=""
                                                                  :id="'qr_check_yn_CLINICAL_' + index"
                                                                  label=""
                                                                  inputClass="qr_check_yn"
                                                                  @click="fnQrCheck('CLINICAL',vo.vProductCd,vo.nVersion)"
                                                                >
                                                                </ap-input-check>
                                                              </div>
                                                              <div class="request-status__badge--date" @click="goTestReqView('CLINICAL',vo.vProductCd,vo.nVersion)">{{ commonUtils.changeStrDatePattern2(vo.vLabReqDtm) }}</div>
                                                            </div>
                                                          </div>
                                                        </swiper-slide>
                                                      <!-- 해당 시험의뢰,버전,로트의 시험 횟수 -->
                                                      </template>
                                                    </template>

                                                  </swiper>
                                                </template>
                                              </template>

                                            </div>
                                          </div>
                                        </td>
                                        <td></td>
                                      </tr>
                                      <tr>
                                        <td class="request-status__title--td">
                                          <div class="request-status__title">
                                            <i class="request-status__icon request-status__icon06"></i>
                                            <div class="request-status__text">무소구 시험 의뢰</div>
                                          </div>
                                        </td>
                                        <!-- 버전,로트 개수만큼 생성 -->
                                        <td v-for="(vLvo, idx) in testReq.verLotList" :key="idx">
                                          <!-- 해당 시험법만 생성 되도록 -->
                                          <div class="request-status__badge--wrap request-status__badge--useSwiper" v-if="testReq.resultMap['MRQ050']">
                                            <div class="request-status__badge--slide">
                                              <!-- 툴팁 생성 부분 -->
                                              <div class="ui-tooltip-wrap ui-tooltip__parent">
                                                <div class="ui-tooltip-item">
                                                  <template v-for="(vo, index) in testReq.resultMap['MRQ050']" :key="index">
                                                    <template v-if="vLvo.nLabNoteVer == vo.nLabNoteVer && vLvo.vLotNm == vo.vLotNm">
                                                      <span
                                                        class="ui-tooltip ui-tooltip__top"
                                                        :class="vo.tooltipActive === 'Y' ? 'is-active' : ''"
                                                      >
                                                        <span class="ui-tooltip__inner" v-html="commonUtils.removeHTMLChangeBr(vo.vTrResMrq050Txt)"></span>
                                                      </span>
                                                    </template>
                                                  </template>
                                                </div>
                                              </div>
                                              <!-- 툴팁 생성 부분 -->

                                              <template v-for="(fvo, index) in testReq.resultMap['MRQ050']" :key="index">
                                                <template v-if="vLvo.nLabNoteVer == fvo.nLabNoteVer && vLvo.vLotNm == fvo.vLotNm">
                                                  <!-- nRowOrderNum == 1, 한번 만 생성되어야함 -->
                                                  <swiper 
                                                    :modules="modules"
                                                    :slide-per-view="1"
                                                    navigation
                                                    :pagination="{ dynamicBullets:true, dynamicMainBullets:5 }"
                                                    v-if="fvo.nRowOrderNum == 1"
                                                  >
                                                  <!-- nRowOrderNum == 1, 한번 만 생성되어야함 -->

                                                    <template v-for="(vo, index) in testReq.resultMap['MRQ050']" :key="index">
                                                      <template v-if="vLvo.nLabNoteVer == vo.nLabNoteVer && vLvo.vLotNm == vo.vLotNm">
                                                        <!-- 해당 시험의뢰,버전,로트의 시험 횟수 -->
                                                        <swiper-slide>
                                                          <div :class="['request-status__badge', 'request-status__badge--' + vo.vTrResMrq050Color ]">
                                                            <div
                                                              :class="['request-status__badge--text', vo.vLabGateCd == 'GATE_2' ? 'request-status__badge--ptag' : '', 'ui-tooltip-inslide']"
                                                              @mouseover="fnShowTooltip(vo, 'vTrResMrq050Txt')"
                                                              @mouseout="fnHideTooltip(vo)"
                                                            >
                                                              <template v-if="vo.vTrResMrq050Color === 'green'">
                                                                요청
                                                              </template>
                                                              <template v-else-if="vo.vTrResMrq050Color === 'blue'">
                                                                합격
                                                              </template>
                                                              <template v-else-if="vo.vTrResMrq050Color === 'red'">
                                                                불합격
                                                              </template>
                                                              <template v-else>
                                                                
                                                              </template>
                                                            </div>
                                                            <div class="d-flex align-center" style="padding-right: 20px;">
                                                              <div class="ui-checkbox-block p-0 mr-5">
                                                                <ap-input-check
                                                                  value="Y"
                                                                  false-value=""
                                                                  :id="'qr_check_yn_MRQ050_' + index"
                                                                  label=""
                                                                  inputClass="qr_check_yn"
                                                                  @click="fnQrCheck('MRQ050',vo.vProductCd,vo.nVersion)"
                                                                >
                                                                </ap-input-check>
                                                              </div>
                                                              <div class="request-status__badge--date" @click="goTestReqView('MRQ050',vo.vProductCd,vo.nVersion)">{{ commonUtils.changeStrDatePattern2(vo.vLabReqDtm) }}</div>
                                                            </div>
                                                          </div>
                                                        </swiper-slide>
                                                      <!-- 해당 시험의뢰,버전,로트의 시험 횟수 -->
                                                      </template>
                                                    </template>

                                                  </swiper>
                                                </template>
                                              </template>

                                            </div>
                                          </div>
                                        </td>
                                        <td></td>
                                      </tr>
                                      <tr>
                                        <td class="request-status__title--td">
                                          <div class="request-status__title">
                                            <i class="request-status__icon request-status__icon07"></i>
                                            <div class="request-status__text">중국안전성 사전검토</div>
                                          </div>
                                        </td>
                                        <!-- 버전,로트 개수만큼 생성 -->
                                        <td v-for="(vLvo, idx) in testReq.verLotList" :key="idx">
                                          <!-- 해당 시험법만 생성 되도록 -->
                                          <div class="request-status__badge--wrap request-status__badge--useSwiper" v-if="testReq.resultMap['MRQ070']">
                                            <div class="request-status__badge--slide">
                                              <!-- 툴팁 생성 부분 -->
                                              <div class="ui-tooltip-wrap ui-tooltip__parent">
                                                <div class="ui-tooltip-item">
                                                  <template v-for="(vo, index) in testReq.resultMap['MRQ070']" :key="index">
                                                    <template v-if="vLvo.nLabNoteVer == vo.nLabNoteVer && vLvo.vLotNm == vo.vLotNm">
                                                      <span
                                                        class="ui-tooltip ui-tooltip__top"
                                                        :class="vo.tooltipActive === 'Y' ? 'is-active' : ''"
                                                      >
                                                        <span class="ui-tooltip__inner" v-html="commonUtils.removeHTMLChangeBr(vo.vTrResMrq070Txt)"></span>
                                                      </span>
                                                    </template>
                                                  </template>
                                                </div>
                                              </div>
                                              <!-- 툴팁 생성 부분 -->

                                              <template v-for="(fvo, index) in testReq.resultMap['MRQ070']" :key="index">
                                                <template v-if="vLvo.nLabNoteVer == fvo.nLabNoteVer && vLvo.vLotNm == fvo.vLotNm">
                                                  <!-- nRowOrderNum == 1, 한번 만 생성되어야함 -->
                                                  <swiper 
                                                    :modules="modules"
                                                    :slide-per-view="1"
                                                    navigation
                                                    :pagination="{ dynamicBullets:true, dynamicMainBullets:5 }"
                                                    v-if="fvo.nRowOrderNum == 1"
                                                  >
                                                  <!-- nRowOrderNum == 1, 한번 만 생성되어야함 -->

                                                    <template v-for="(vo, index) in testReq.resultMap['MRQ070']" :key="index">
                                                      <template v-if="vLvo.nLabNoteVer == vo.nLabNoteVer && vLvo.vLotNm == vo.vLotNm">
                                                        <!-- 해당 시험의뢰,버전,로트의 시험 횟수 -->
                                                        <swiper-slide>
                                                          <div :class="['request-status__badge', 'request-status__badge--' + vo.vTrResMrq070Color ]">
                                                            <div
                                                              :class="['request-status__badge--text', vo.vLabGateCd == 'GATE_2' ? 'request-status__badge--ptag' : '', 'ui-tooltip-inslide']"
                                                              @mouseover="fnShowTooltip(vo, 'vTrResMrq070Txt')"
                                                              @mouseout="fnHideTooltip(vo)"
                                                            >
                                                              <template v-if="vo.vTrResMrq070Color === 'green'">
                                                                요청
                                                              </template>
                                                              <template v-else-if="vo.vTrResMrq070Color === 'blue'">
                                                                합격
                                                              </template>
                                                              <template v-else-if="vo.vTrResMrq070Color === 'red'">
                                                                불합격
                                                              </template>
                                                              <template v-else>
                                                                
                                                              </template>
                                                            </div>
                                                            <div class="d-flex align-center" style="padding-right: 20px;">
                                                              <div class="ui-checkbox-block p-0 mr-5">
                                                                <ap-input-check
                                                                  value="Y"
                                                                  false-value=""
                                                                  :id="'qr_check_yn_MRQ070_' + index"
                                                                  label=""
                                                                  inputClass="qr_check_yn"
                                                                  @click="fnQrCheck('MRQ070',vo.vProductCd,vo.nVersion)"
                                                                >
                                                                </ap-input-check>
                                                              </div>
                                                              <div class="request-status__badge--date" @click="goTestReqView('MRQ070',vo.vProductCd,vo.nVersion)">{{ commonUtils.changeStrDatePattern2(vo.vRegDtm) }}</div>
                                                            </div>
                                                          </div>
                                                        </swiper-slide>
                                                      <!-- 해당 시험의뢰,버전,로트의 시험 횟수 -->
                                                      </template>
                                                    </template>

                                                  </swiper>
                                                </template>
                                              </template>

                                            </div>
                                          </div>
                                        </td>
                                        <td></td>
                                      </tr>

                                    </tbody>
                                  </table>
                                </div>

                                <div class="ui-table__request-wrap ui-table__request--variable ui-table__request--nodata" v-else>
                                  <table class="ui-table text-center ui-table__request">
                                    <colgroup>
                                      <col style="width:240px">
                                      <col style="width:auto">
                                    </colgroup>
                                    <thead>
                                      <tr>
                                        <th scope="row" class="ui-table__request--nodata__tabTitle">TEST NAME</th>
                                        <th scope="row" class="ui-table__request--nodata__th"></th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      <tr>
                                        <td>
                                          <div class="request-status__title">
                                            <i class="request-status__icon request-status__icon01"></i>
                                            <div class="request-status__text">부향 시험 의뢰</div>
                                          </div>
                                        </td>
                                        <td rowspan="8">
                                          <div class="request-status--nodata__txt">
                                            등록된 시험의뢰가 없습니다.
                                          </div>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td class="request-status__title--td">
                                          <div class="request-status__title">
                                            <i class="request-status__icon request-status__icon02"></i>
                                            <div class="request-status__text">안전성 시험 의뢰</div>
                                          </div>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td class="request-status__title--td">
                                          <div class="request-status__title">
                                            <i class="request-status__icon request-status__icon03"></i>
                                            <div class="request-status__text">방부 시험 의뢰</div>
                                          </div>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td class="request-status__title--td">
                                          <div class="request-status__title">
                                            <i class="request-status__icon request-status__icon04"></i>
                                            <div class="request-status__text">기능성 시험 의뢰</div>
                                          </div>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td class="request-status__title--td">
                                          <div class="request-status__title">
                                            <i class="request-status__icon request-status__icon08"></i>
                                            <div class="request-status__text">유해물질 시험의뢰</div>
                                          </div>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td class="request-status__title--td">
                                          <div class="request-status__title">
                                            <i class="request-status__icon request-status__icon05"></i>
                                            <div class="request-status__text">효능/임상 시험 의뢰</div>
                                          </div>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td class="request-status__title--td">
                                          <div class="request-status__title">
                                            <i class="request-status__icon request-status__icon06"></i>
                                            <div class="request-status__text">무소구 시험 의뢰</div>
                                          </div>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td class="request-status__title--td">
                                          <div class="request-status__title">
                                            <i class="request-status__icon request-status__icon07"></i>
                                            <div class="request-status__text">중국안전성 사전검토</div>
                                          </div>
                                        </td>
                                      </tr>
                                    </tbody>
                                  </table>
                                </div>
                              </div>
                            </div>

                          </div>
                        </div>
                      </div>


                    </div>
                  </div>

                </div>

              </div>
            </div>

          </div>
        </div>
        
      </div>

      <div class="contents-cell">

      </div>
    </div>
    <teleport to="#common-modal" v-if="popupContent">
      <ap-popup>
        <component
        :is="popupContent"
        :pop-params="popParams"
        @selectFunc="popSelectFunc"
        />
      </ap-popup>
    </teleport>
    
    <button type="button" class="button-caution" 
      v-if="!commonUtils.isEmpty(testReq?.noteInfo)
          && testReq?.noteInfo?.vLabTypeCd === 'LNC07_01'
          && showIssueTrackBtn(noteType, testReq.noteInfo)" 
      @click="fnIssueTrackPop()"
    >
    </button> 
  </div>
</template>

<script>
import { defineAsyncComponent, getCurrentInstance, reactive, ref, computed, inject } from 'vue'
import { Navigation, Pagination, Scrollbar, A11y } from 'swiper'
import { Swiper, SwiperSlide } from 'swiper/vue'
import { useStore } from 'vuex'
import { useRoute, useRouter } from 'vue-router'
import { useActions } from 'vuex-composition-helpers'
import { useTestReqBoardCommon } from '@/compositions/labcommon/useTestReqBoardCommon'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'

import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';

export default {
  name: 'AllLabNoteTestReqBoard',
  components: {
    Swiper,
    SwiperSlide,
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    LabNoteTestQrCodePop: defineAsyncComponent(() => import('@/components/labcommon/popup/LabNoteTestQrCodePop.vue')),
    HistoryTab: defineAsyncComponent(() => import('@/components/labcommon/HistoryTab.vue')),
    IssueTrackerPop: defineAsyncComponent(() => import('@/components/labcommon/popup/IssueTrackerPop.vue')),
  },
  setup() {
    const app = getCurrentInstance();
    const tiumUrl = app.appContext.config.globalProperties.tiumUrl
    const store = useStore()
    const route = useRoute()
    const router = useRouter()
    const isShow = ref(false)
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert } = useActions(['openAsyncAlert'])
    const searchParams = ref({
      vLabNoteCd: '',
      nVersion: '',
      vContPkCd: '',
      vContCd: '',
    })

    const testReq = reactive({
      noteInfo: {},
      contList: [],
      verLotList: [],
      list: [],
      qrCheckList: [],
      arrQrCheckInfo: [],
      noData: 'N',
    })
    
    const vLabNoteCd = route.query.vLabNoteCd || ''
    const noteType = store.getters.getNoteType()
    const noteTypeNm = store.getters.getNoteTypeNm()
    const recentNoteList = computed(() => store.getters.getRecentNoteList(noteType))
    const pathList = ref([])
    const pageType = ref(null)
    const vQrCheckYn = ''
    const myInfo = store.getters.getMyInfo()

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      fnChangeNoteInfo,
      selectLabNoteInfoCheckAuth,
      selectIssueTrackerNoteInfo,
      showIssueTrackBtn,
    } = useLabCommon()

    const goTestReqView = (target, tProductCd, tVersion) => {
    //링크이동
      let tUrl = ""

      if(target == "CLINICAL"){
        //효능임상 의뢰 링크
        tUrl = tiumUrl + "/ct/ct/clinical_test_discuss_renew_view.do?i_sTempStatusCd=DISCUSS&i_sTestCd=" + tProductCd
        //새창
        window.open(tUrl, "_blank") ;

      }else if(target == "MRQ010"){
        //안전성 시험의뢰 링크
        tUrl = tiumUrl + "/zm/safe/tr/zm_safe_tr_product_v2_view.do?i_sUproductCd=" + tProductCd + "&i_iVersion=" + tVersion + "&i_sTestReqCd=MRQ010"
        //새창
        window.open(tUrl, "_blank") ;

      }else if(target == "MRQ011"){
        //방부 시험의뢰 링크
        tUrl = tiumUrl + "/zm/bb/tr/zm_bb_tr_product_view.do?i_sProductCd=" + tProductCd + "&i_iVersion=" + tVersion
        //새창
        window.open(tUrl, "_blank") ;

      }else if(target == "MRQ070"){
        //중국 사전안전성 링크
        tUrl = tiumUrl + "/china_zm/china_safe/ev/china_zm_safe_ev_view.do?i_sRecordId=" + tProductCd + "&i_sViewYn=N"
        //새창
        window.open(tUrl, "_blank") ;

      }else{
        //나머지 시험의뢰 링크
        tUrl = tiumUrl + "/zm/tr/zm_tr_product_view.do?i_sProductCd=" + tProductCd + "&i_iVersion=" + tVersion
        //새창
        window.open(tUrl, "_blank") ;

      }

    }

    const fnContClick = async (contPkCd,contCd) => {
      searchParams.value.vContCd = contCd

      const result = await selectTestReqBoardList({vLabNoteCd: vLabNoteCd, vContPkCd:contPkCd, vContCd:contCd})
      testReq.list = result.list
      testReq.noteInfo = result.noteInfo
      testReq.contList = result.contList

      if(result.verLotList.length > 0 || result.verLotList != ''){
        testReq.verLotList = result.verLotList
        testReq.noData =  'Y'
      }else{
        testReq.noData =  'N'
      }
      testReq.resultMap = result.resultMap

      searchParams.value.vContCd = contCd

      testReq.qrCheckList = []
      document.querySelectorAll('.qr_check_yn')
        .forEach(el => el.checked = false);
      
    }

    const fnQrCreate = () => {
      
      if(testReq.qrCheckList.length < 1){
        openAsyncAlert({ message: '선택된 항목이 존재하지 않습니다. <br/> 항목 선택 후 QR코드 생성을 진행해 주세요.' })
        return
      }
      
      const checklen = testReq.qrCheckList.length
      
      let arrQrCheckTmp = ''
      for(let i = 0; i < checklen; i++){
        arrQrCheckTmp = arrQrCheckTmp + testReq.qrCheckList[i].vProductCd + ',' + testReq.qrCheckList[i].nVersion
        if(i != checklen-1){
          arrQrCheckTmp = arrQrCheckTmp + '/'
        }
      }
      
      popParams.value = {
        arrQrCheckInfo: arrQrCheckTmp,
        vLabNoteCd: route.query.vLabNoteCd
      }

      popSelectFunc.value = ''
      fnOpenPopup('LabNoteTestQrCodePop')
    }

    const getSelectedTabEvent = (item) => {
      router.replace({ query: {vLabNoteCd: route.query.vLabNoteCd }})
      setTimeout(() => {
        settingVal.vTabId = item.tabId
      }, 200)
    }

    const fnShowTooltip = (item, txtKey) => {
      if (commonUtils.isNotEmpty(item[txtKey])) {
        item.tooltipActive = 'Y'
      }
    }

    const fnHideTooltip = (item) => {
      item.tooltipActive = 'N'
    }

    const fnQrCheck = (type, prdcd, version) => {

      
      const chkList = testReq.qrCheckList.filter(vo => vo.vType === type && vo.vProductCd === prdcd && vo.nVersion === version)
      if(chkList.length == 0){
        testReq.qrCheckList.push({vType:type, vProductCd:prdcd, nVersion:version})
      }else{
        let targetIdx = testReq.qrCheckList.findIndex(vo => vo.vType === type && vo.vProductCd === prdcd && vo.nVersion === version)
        testReq.qrCheckList.splice(targetIdx, 1)
      }

    }

    const {
      selectTestReqBoardList,
    } = useTestReqBoardCommon()

    const goList = () => {
      const path = `/${noteTypeNm}/all-lab-note-${pageType.value}-list`

      router.push({ path })
    }

    const init = async () => {
      const noteInfo = await selectLabNoteInfoCheckAuth({ vLabNoteCd: route.query.vLabNoteCd })

      if (!noteInfo) {
        return
      }

      fnChangeNoteInfo(noteInfo)

      const result = await selectTestReqBoardList({vLabNoteCd: vLabNoteCd, vContPkCd:'', vContCd:''})

      const defaultMap = {
        'MRQ060': [],
        'MRQ010': [],
        'MRQ011': [],
        'MRQ040_FUNC': [],
        'CLINICAL': [],
        'MRQ050': [],
        'MRQ070': [],
        'MRQ040_HARM': [],
      }

      testReq.list = result.list
      testReq.noteInfo = result.noteInfo
      testReq.contList = result.contList
      
      if(result.verLotList.length > 0 || result.verLotList != ''){
        testReq.verLotList = result.verLotList
        testReq.noData =  'Y'
      }else{
        testReq.noData =  'N'
      }

      testReq.resultMap = { ...defaultMap, ...result.resultMap }
      pageType.value = testReq.noteInfo.vLabTypeCd === 'LNC07_01' ? 'prd' : (testReq.noteInfo.vLabTypeCd === 'LNC07_02' ? 'half' : 'nonprd')
      pathList.value = [
        { path: `/${noteTypeNm}/all-lab-note-${pageType.value}-list`, pathNm: 'ALL LAB NOTE' },
        { path: `/${noteTypeNm}/all-lab-note-test-req-board`, pathNm: 'TEST' }
      ]

      searchParams.value.vContCd = testReq.noteInfo.vContCd
      isShow.value = true
    }

    init()

    const fnIssueTrackPop = async () => {
      const result = await selectIssueTrackerNoteInfo({ vLabNoteCd: vLabNoteCd })
      popParams.value = {
        vLabNoteCd: vLabNoteCd,
        noteInfo: result,
        vNoteType: noteType
      }

      fnOpenPopup('IssueTrackerPop', false)
    }

    return {
      commonUtils,
      pathList,
      vLabNoteCd,
      recentNoteList,
      searchParams,
      selectTestReqBoardList,
      testReq,
      noteType,
      noteTypeNm,
      isShow,
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      getSelectedTabEvent,
      fnShowTooltip,
      fnHideTooltip,
      goTestReqView,
      goList,
      fnContClick,
      fnQrCreate,
      modules: [Navigation, Pagination, Scrollbar, A11y],
      vQrCheckYn,  
      fnQrCheck,
      showIssueTrackBtn,
      fnIssueTrackPop,
      myInfo
    }
  },
}
</script>

<style scoped>
.ui-checkbox-block { padding : 0;} 

.request-status__badge--date {
  cursor: pointer;
  text-decoration: underline;
}
</style>