<template>
  <div class="contents-core" v-show="isShow">
    <div class="contents-cell__wrap">
      <div class="contents-cell flex-none">
        <div class="contents-box">
          <div class="contents-box__inner p-0 min-height__unset">
            <HistoryTab
              v-if="noteInfo?.vContCd"
              :v-lab-note-cd="vLabNoteCd"
              :url-link="'/'+ noteTypeNm +'/all-lab-note-{pageType}-process?vLabNoteCd='"
              @go-list="goList()"
            >
            </HistoryTab>
            <ap-breadcrumb
              nav-title="프로세스"
              :path-list="pathList"
              :flag-inside="true"
            >
            </ap-breadcrumb>
            <NoteProcessBar
              v-if="progressInfo && progressInfo.length > 0"
              :progress-info="progressInfo"
              :is-big="true"
              :is-show="false"
              :is-cancel="flagCancel == 'Y' ? true : false"
            >
            </NoteProcessBar>
          </div>
        </div>
      </div>

      <div class="contents-cell" id="labNoteProcess">
        <div class="contents-box contents-box__full contents-box__with--tab">
          <ApTab
            mst-id="process-tab"
            :tab-list="tabList"
            @click="getSelectedTabEvent"
            :default-tab="settingVal.vTabId"
            :tab-style="['contents-box__tab--inner', 'contents-box__tab--list', 'contents-box__tab--item', 'contents-box__tab--link']"
          >
          </ApTab>
          <div class="contents-tab__body h-100" id="complete" v-if="settingVal.vTabId === 'complete'">
            <ProcessDevelopComplete></ProcessDevelopComplete>
          </div>
          <div class="contents-tab__body h-100" id="ingredient" v-if="settingVal.vTabId === 'ingredient'">
            <ProcessIngredientApprove></ProcessIngredientApprove>
          </div>
          <div class="contents-tab__body h-100" id="confirm" v-if="settingVal.vTabId === 'confirm'">
            <ProcessPrescribeConfirm
              @callbackFunc="setProgressBar"
            >
            </ProcessPrescribeConfirm>
          </div>
          <div class="contents-tab__body h-100" id="pilot" v-if="settingVal.vTabId === 'pilot'">
            <ProcessPilot></ProcessPilot>
          </div>
          <div class="contents-tab__body h-100" id="bom" v-if="settingVal.vTabId === 'bom'">
            <ProcessBOM></ProcessBOM>
          </div>
          <div class="contents-tab__body h-100" id="timeLine" v-if="settingVal.vTabId === 'timeLine' && progressInfo">
            <ProcessTimeLine
              :progress-info="progressInfo"
            >
            </ProcessTimeLine>
          </div>
          <div class="contents-tab__body h-100" id="funcComplete" v-if="settingVal.vTabId === 'funcComplete'">
            <ProcessFuncPermission></ProcessFuncPermission>
          </div>
          <div class="contents-tab__body h-100" id="reportPermission" v-if="settingVal.vTabId === 'reportPermission'">
            <ProcessQdrugReportPermission></ProcessQdrugReportPermission>
          </div>
          <div class="contents-tab__body h-100" id="qmsOpen" v-if="settingVal.vTabId === 'qmsOpen'">
            <ProcessQMS></ProcessQMS>
          </div>
        </div>

      </div>

    </div>
    <button type="button" class="button-caution" v-if="showIssueTrackBtn(noteType, noteInfo)" @click="fnIssueTrackPop()"></button>
  </div>

  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, computed, ref, inject, reactive } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useStore } from 'vuex'
import { useProcessCommon } from '@/compositions/labcommon/useProcessCommon'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'

export default {
  name: 'AllLabNoteProcess',
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    HistoryTab: defineAsyncComponent(() => import('@/components/labcommon/HistoryTab.vue')),
    ProcessTimeLine: defineAsyncComponent(() => import('@/components/process/ProcessTimeLine.vue')),
    ProcessBOM: defineAsyncComponent(() => import('@/components/process/ProcessBOM.vue')),
    ProcessPilot: defineAsyncComponent(() => import('@/components/process/ProcessPilot.vue')),
    ProcessPrescribeConfirm: defineAsyncComponent(() => import('@/components/process/ProcessPrescribeConfirm.vue')),
    ProcessFuncPermission: defineAsyncComponent(() => import('@/components/process/ProcessFuncPermission.vue')),
    ProcessIngredientApprove: defineAsyncComponent(() => import('@/components/process/ProcessIngredientApprove.vue')),
    ProcessDevelopComplete: defineAsyncComponent(() => import('@/components/process/ProcessDevelopComplete.vue')),
    NoteProcessBar: defineAsyncComponent(() => import('@/components/labcommon/NoteProcessBar.vue')),
    ProcessQdrugReportPermission: defineAsyncComponent(() => import('@/components/process/ProcessQdrugReportPermission.vue')),
    ProcessQMS: defineAsyncComponent(() => import('@/components/process/ProcessQMS.vue')),
    IssueTrackerPop: defineAsyncComponent(() => import('@/components/labcommon/popup/IssueTrackerPop.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
  },
  setup () {
    const isShow = ref(false)
    const progInfo = ref(null)
    const route = useRoute()
    const router = useRouter()
    const store = useStore()
    const vLabNoteCd = route.query.vLabNoteCd || ''
    const noteType = store.getters.getNoteType()
    const noteTypeNm = store.getters.getNoteTypeNm()
    const recentNoteList = computed(() => store.getters.getRecentNoteList(noteType))
    const noteInfo = ref(null)
    const myInfo = store.getters.getMyInfo()
    const commonUtils = inject('commonUtils')
    
    const settingVal = reactive({
        vTabId : '',
        vProgWidth : ''
      })

    const {
      selectProgressInfo,
      progressInfo, 
      tabList,
      flagCancel,
      fnOpenPopup,
      popupContent,
      popParams
    } = useProcessCommon()

    const {
      selectLabNoteInfoCheckAuth,
      fnChangeNoteInfo,
      selectIssueTrackerNoteInfo,
      showIssueTrackBtn,
    } = useLabCommon()

    const pathList = [
      { path: `/${noteTypeNm}/all-lab-note-prd-list`, pathNm: 'ALL LAB NOTE' },
      { path: `/${noteTypeNm}/all-lab-note-prd-process`, pathNm: '프로세스' }
    ]

    const getSelectedTabEvent = (item) => {
      router.replace({ query: {vLabNoteCd: route.query.vLabNoteCd }})
      setTimeout(() => {
        settingVal.vTabId = item.tabId
      }, 200)
    }

    const setProgressInfo = async () => {
      await selectProgressInfo({vLabNoteCd : vLabNoteCd})
      const vTabId = route.query.vTabId
      if (!vTabId) {
        for (const prog of progressInfo.value){
          if(prog.vCurrStatMark === "is-active"){
            settingVal.vTabId = prog.vTabId
            break;
          }
        }
      } else {
        settingVal.vTabId = vTabId
      }
    }

    const setProgressBar = () => {
      selectProgressInfo({vLabNoteCd : vLabNoteCd})
    }

    const goList = () => {
      router.push({ path: `/${noteTypeNm}/all-lab-note-prd-list` })
    }

    const init = async () => {
      noteInfo.value = await selectLabNoteInfoCheckAuth({ vLabNoteCd: route.query.vLabNoteCd })

      if (!noteInfo.value) {
        return
      }

      fnChangeNoteInfo(noteInfo.value)
      setProgressInfo()

      isShow.value = true
    }
    
    init()

    const fnIssueTrackPop = async () => {
      
      const result = await selectIssueTrackerNoteInfo({ vLabNoteCd: noteInfo.value.vLabNoteCd })
      popParams.value = {
        vLabNoteCd: noteInfo.value.vLabNoteCd,
        noteInfo: result,
        vNoteType: noteType
      }

      fnOpenPopup('IssueTrackerPop', false)
    }

    return {
      noteInfo,
      isShow,
      noteType,
      noteTypeNm,
      pathList,
      tabList,
      getSelectedTabEvent,
      setProgressInfo,
      setProgressBar,
      progInfo,
      progressInfo,
      settingVal,
      recentNoteList,
      vLabNoteCd,
      flagCancel,
      goList,
      showIssueTrackBtn,
      fnIssueTrackPop,
      myInfo,
      popupContent,
      popParams
    }
  }
}
</script>