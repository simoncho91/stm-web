<template>
  <ap-breadcrumb nav-title="의약외품 원료 DB" :path-list="pathList">
  </ap-breadcrumb>

  <div class="contents-core">
    <div class="contents-cell__wrap">
      <div class="contents-cell">
        <div class="contents-box contents-box__full">
          <div class="contents-box__inner">
            <!-- <AllLabNoteListSearch @onSearch="onSearch" :search-params="searchParams"/> -->
            <div class="board-top">
            <div class="search-form">
              <div class="search-form__inner">
                <div class="search-bar__row">
                  <dl class="search-bar__item">
                    <dt class="search-bar__key search-bar__width--90">검색</dt>
                    <dd class="search-bar__val">
                      <div class="search-form">
                        <div class="search-form__inner">
                          <ap-input
                            :inputClass="'ui-input ui-input__width--450'"
                            :placeholder="'원료코드 or 원료명'"
                            v-model:value="searchParams.vKeyword"
                            @keypressEnter="fnSearchRawList(1)"
                          />
                          <button
                            type="button"
                            class="button-search"
                            @click="fnSearchRawList(1)"
                          >
                            검색
                          </button>
                        </div>
                      </div>
                    </dd>
                  </dl>
                </div>
              </div>
            </div>
            </div>

            <div class="total-page form-flex-between">
              <div class="form-flex">
                <template v-if="page && page.totalPageCnt">
                  <div class="total-page__case">총<span class="total-page__num">{{ commonUtils.setNumberComma(page.totalCnt) }}</span>건</div>
                  <div class="total-page__page">총 <span class="total-page__num">{{ commonUtils.setNumberComma(page.totalPageCnt) }}</span>페이지</div>
                </template>
              </div>
              <div class="ui-buttons ui-buttons__right">
                <button type="button" class="ui-button ui-button__border--blue" @click="fnExcel()">엑셀</button>
                <button type="button" class="ui-button ui-button__bg--skyblue" @click="goRegister()">등록</button>
              </div>
            </div>

            <QdrugNoteMatrDbListTable
              @onPaging="onPaging"
              :result-list="list"
              :result-page="page"
            />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, inject } from 'vue'
import { useQdrugMatrDb } from '@/compositions/qdrug/useQdrugMatrDb'

import QdrugNoteMatrDbListTable from '@/components/qdrug/QdrugNoteMatrDbListTable.vue'

export default {
  name: 'QdrugNoteMatrDbList',
  components: {
    QdrugNoteMatrDbListTable,
  },
  setup() {
    const commonUtils = inject('commonUtils')
    const searchParams = ref({
      vKeyword: '',
      vFlagExcel: 'N',
      nowPageNo: 1,
    })

    const pathList = [
      { path: '/qdrug/qdrug-note-matr-db-list', pathNm: '원료 DB' },
    ]

    const {
      page,
      list,
      selectReqList,
      goRegister,
      selectQdrugMatrDbListExcel,
    } = useQdrugMatrDb()

    const init = async () => {
      const sessionParam = JSON.parse(sessionStorage.getItem('searchParamsSA'))

      if (sessionParam) {
        searchParams.value = { ...sessionParam, ...{ nowPageNo: searchParams.value.nowPageNo } }
      }

      const result = await selectReqList(searchParams.value)

      if (result) {
        searchParams.value = { ...searchParams.value }
      }
    }

    const onSearch = async (param) => {
      searchParams.value = { ...param, nowPageNo: 1 }
      await init()
    }

    const onPaging = (pg) => {
      searchParams.value = { ...searchParams.value, nowPageNo: pg }
      init()
    }

    const fnSearchRawList = (pg) => {
      searchParams.value = { ...searchParams.value, nowPageNo: pg }
      selectReqList(searchParams.value)
    }

    const fnExcel = () => {
      selectQdrugMatrDbListExcel({vFlagExcel: 'Y'})
    }

    init()

    return {
      commonUtils,
      pathList,
      list,
      page,
      searchParams,
      onSearch,
      onPaging,
      goRegister,
      fnSearchRawList,
      fnExcel,
      selectQdrugMatrDbListExcel,
    }
  }
}
</script>