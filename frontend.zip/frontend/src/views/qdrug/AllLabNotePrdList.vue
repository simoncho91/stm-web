<template>
  <ap-breadcrumb nav-title="All lab notes" :path-list="pathList">
  </ap-breadcrumb>

  <div class="contents-core">
    <div class="contents-cell__wrap">
      <div class="contents-cell">
        <div class="contents-box contents-box__full">
          <div class="contents-box__inner">
            <AllLabNoteListSearch @onSearch="onSearch" :search-params="searchParams" pageType="prd"/>

            <div class="total-page form-flex-between">
              <div class="form-flex">
                <template v-if="page && page.totalPageCnt">
                  <div class="total-page__case">총<span class="total-page__num">{{ commonUtils.setNumberComma(page.totalCnt) }}</span>건</div>
                  <div class="total-page__page">총 <span class="total-page__num">{{ commonUtils.setNumberComma(page.totalPageCnt) }}</span>페이지</div>
                </template>
              </div>
              <div class="ui-buttons ui-buttons__right">
                <button type="button" class="ui-button ui-button__bg--skyblue" v-if="!commonUtils.checkAuth('S000333')" @click="goRegister()">등록</button>
              </div>
            </div>

            <AllLabNoteListTable
              @onPaging="onPaging"
              :result-list="list"
              :result-page="page"
            />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, inject } from 'vue'
import { useQdrugRequest } from '@/compositions/qdrug/useQdrugRequest'

import AllLabNoteListSearch from '@/components/labcommon/AllLabNoteListSearch.vue'
import AllLabNoteListTable from '@/components/qdrug/AllLabNoteListTable.vue'

export default {
  name: 'AllLabNoteList',
  components: {
    AllLabNoteListSearch,
    AllLabNoteListTable,
  },
  setup() {
    const commonUtils = inject('commonUtils')
    const searchParams = ref({
      vListType: 'HAL3',
      vBrdAllYn: '',
      brdCdList: [],
      vStatusAllYn: '',
      statusCdList: [],
      vDeptCd: '',
      vFlagMyLabNote: '',
      vKeyword: '',
      nowPageNo: 1,
    })

    const pathList = [
      { path: '/qdrug/all-lab-note-list', pathNm: 'ALL LAB NOTES' },
    ]

    const {
      page,
      list,
      selectReqList,
      goRegister,
    } = useQdrugRequest()

    const init = async () => {
      const searchParamsDashboard = JSON.parse(sessionStorage.getItem('searchParamsDashboardSA'))
      if (searchParamsDashboard) {
        await selectReqList({ ...searchParamsDashboard, ...{ nowPageNo: searchParams.value.nowPageNo, vListType: 'HAL3' }})
      } else {
        const sessionParam = JSON.parse(sessionStorage.getItem('searchParams_prd_SA'))
  
        if (sessionParam) {
          searchParams.value = { ...sessionParam, ...{ nowPageNo: searchParams.value.nowPageNo } }
        }
  
        const result = await selectReqList(searchParams.value)
  
        if (result) {
          searchParams.value = { ...searchParams.value, ...{vFlagMyLabNote: result.vFlagMyLabNote }}
        }
      }
    }

    const onSearch = async (param) => {
      searchParams.value = { ...param, nowPageNo: 1 }
      await init()
    }

    const onPaging = (pg) => {
      searchParams.value = { ...searchParams.value, nowPageNo: pg }
      init()
    }

    init()

    return {
      commonUtils,
      pathList,
      list,
      page,
      searchParams,
      onSearch,
      onPaging,
      goRegister,
    }
  }
}
</script>