<template>
  <div v-show="reqInfo">
    <div class="page-tab">
      <div class="page-tab__inner">
        <HistoryTab
          v-if="reqInfo && commonUtils.isNotEmpty(reqInfo.vContCd)"
          :v-lab-note-cd="vLabNoteCd"
          url-link="/qdrug/all-lab-note-{pageType}-view?vLabNoteCd="
          @go-list="goList()"
        >
        </HistoryTab>

        <div class="page-tab__contents">
          <ap-breadcrumb
            nav-title="내용물 개요"
            :path-list="pathList"
          >
          </ap-breadcrumb>

          <div class="page-tab__item">
            <AllLabNoteQdrugBasicInfoView></AllLabNoteQdrugBasicInfoView>
          </div>
        </div>
      </div>
    </div>

    <div class="contents-core">
      <div class="contents-cell__wrap">
        <div class="contents-cell">
          <div class="contents-box contents-box__full">
            <div class="contents-box__inner min-height__unset">
              <AllLabNoteQdrugResearcherInfoView></AllLabNoteQdrugResearcherInfoView>
            </div>
          </div>

          <div class="contents-box contents-box__full">
            <div class="contents-box__inner min-height__unset">
              <AllLabNoteQdrugMarketingInfoView></AllLabNoteQdrugMarketingInfoView>
            </div>
          </div>

          <div class="contents-box contents-box__full">
            <div class="contents-box__inner min-height__unset">
              <div class="arrordion-item is-active">
                <div class="arrordion-header">
                  <div class="arrordion-title">제품 정보</div>
                  <button type="button" class="ui-button__accordion"></button>
                </div>
                <div class="arrordion-body">
                  <div class="detail-tab ap_contents_tab" v-if="reqInfo && reqInfo.verList">
                    <div class="ver_tab_area">
                      <ApTab
                        v-if="reqInfo.verList.length > 0"
                        mst-id="productVersion"
                        :tab-list="reqInfo.verList"
                        tab-id-key="vVersionKey"
                        tab-nm-key="vVersionTxt"
                        :tab-style="['detail-tab__inner', 'ui-list detail-tab__lists', 'detail-tab__list', 'detail-tab__link']"
                        :default-tab="reqInfo.verList[reqInfo.verList.length - 1].vVersionKey"
                        @click="fnProductVersionTabEvent"
                      >
                      </ApTab>
                      <button
                        v-if="showAddVerBtn(reqInfo) && showModifyBtn()"
                        type="button"
                        class="detail-tab__button--plus add_btn"
                        :class="addVerFlag === 'Y' ? 'active' : ''"
                        @click="fnAddVersion()"
                      >
                      </button>
                    </div>
                    <template v-if="addVerFlag !== 'Y'">
                      <div class="contents-tab__body"
                        v-for="(item, index) in reqInfo.verList"
                        :key="'version_area_' + index"
                        :id="item.vVersionKey"
                      >
                        <AllLabNoteQdrugProductInfoView
                          v-if="item.versionInfo"
                          :version-info="item.versionInfo"
                        >
                        </AllLabNoteQdrugProductInfoView>
                      </div>
                    </template>
                    <template v-else>
                      <AllLabNoteQdrugProductInfoRegister
                        ref="product"
                      >
                      </AllLabNoteQdrugProductInfoRegister>
                      <div class="page-bottom">
                        <div class="ui-buttons ui-buttons__right">
                          <button type="button" class="ui-button ui-button__height--28 ui-button__bg--blue" v-if="addVerFlag === 'Y'" @click="fnNewVersionSave()">버전 추가 저장</button>
                        </div>
                      </div>
                    </template>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="contents-box contents-box__full contents-box__with--tab">
          <AllLabNoteQdrugEtcInfoView></AllLabNoteQdrugEtcInfoView>
        </div>

        <div class="page-bottom">
          <div class="page-bottom__inner form-flex-between">
            <div class="ui-buttons ui-buttons__left">
              <button type="button" class="ui-button ui-button__bg--blue" v-if="showCompleteBtn()" @click="fnReleaseCompletePop()">출시 완료</button>
              <button type="button" class="ui-button ui-button__bg--lightgray" v-if="showDevelopCancelBtn()" @click="fnDevelopCancelPop()">개발취소</button>
              <button type="button" class="ui-button ui-button__bg--lightgray" v-if="showDevelopRestartBtn()" @click="fnDevelopRestart()">개발재개</button>
              <template v-if="showMasterAuthBtn()">
                <button type="button" class="ui-button ui-button__border--gray" @click="fnPlantExtendPop()">플랜트 확장</button>
              </template>
              <button type="button" class="ui-button ui-button__border--gray" @click="fnNoteInfoChangeLogPop()">변경이력보기</button>
            </div>
            <div class="ui-buttons ui-buttons__right">
              <template v-if="showMasterAuthBtn()">
                <button type="button" class="ui-button ui-button__bg--blue" @click="fnNoteAuthPop()">노트 공유하기</button>
              </template>
              <button type="button" class="ui-button ui-button__bg--skyblue" v-if="showModifyBtn()" @click="goModify(reqInfo.vLabNoteCd)">수정</button>
              <button type="button" class="ui-button ui-button__border--gray" @click="goList()">목록</button>
            </div>
          </div>
        </div>
      </div>
      <button type="button" class="button-caution" v-if="showIssueTrackBtn('SA', reqInfo)" @click="fnIssueTrackPop()"></button>
    </div>
  </div>
  <teleport to="#common-modal" v-if="popupContent">
    <ap-popup>
      <component
        :is="popupContent"
        :pop-params="popParams"
        @selectFunc="popSelectFunc"
        @callbackFunc="popSelectFunc"
      />
    </ap-popup>
  </teleport>
</template>

<script>
import { defineAsyncComponent, ref, computed, provide, inject } from 'vue'
import { useRoute } from 'vue-router'
import { useStore } from 'vuex'
import { useQdrugRequest } from '@/compositions/qdrug/useQdrugRequest'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useRequestCommon } from '@/compositions/labcommon/useRequestCommon'
import { useActions } from 'vuex-composition-helpers'
import uiUtils from '@/utils/uiUtils'

import AllLabNoteQdrugBasicInfoView from '@/components/qdrug/AllLabNoteQdrugBasicInfoView.vue'
import AllLabNoteQdrugResearcherInfoView from '@/components/qdrug/AllLabNoteQdrugResearcherInfoView.vue'
import AllLabNoteQdrugMarketingInfoView from '@/components/qdrug/AllLabNoteQdrugMarketingInfoView.vue'
import AllLabNoteQdrugProductInfoView from '@/components/qdrug/AllLabNoteQdrugProductInfoView.vue'
import AllLabNoteQdrugProductInfoRegister from '@/components/qdrug/AllLabNoteQdrugProductInfoRegister.vue'
import AllLabNoteQdrugEtcInfoView from '@/components/qdrug/AllLabNoteQdrugEtcInfoView.vue'

export default {
  name: 'AllLabNoteView',
  components: {
    AllLabNoteQdrugBasicInfoView,
    AllLabNoteQdrugResearcherInfoView,
    AllLabNoteQdrugMarketingInfoView,
    AllLabNoteQdrugProductInfoView,
    AllLabNoteQdrugProductInfoRegister,
    AllLabNoteQdrugEtcInfoView,
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    HistoryTab: defineAsyncComponent(() => import('@/components/labcommon/HistoryTab.vue')),
    DevelopCancelPop: defineAsyncComponent(() => import('@/components/labcommon/popup/DevelopCancelPop.vue')),
    PlantExtendPop: defineAsyncComponent(() => import('@/components/labcommon/popup/PlantExtendPop.vue')),
    NoteInfoChangeLogPop: defineAsyncComponent(() => import('@/components/labcommon/popup/NoteInfoChangeLogPop.vue')),
    LabNoteAuthorityPop: defineAsyncComponent(() => import('@/components/labcommon/popup/LabNoteAuthorityPop.vue')),
    ReleaseCompletePop: defineAsyncComponent(() => import('@/components/qdrug/popup/ReleaseCompletePop.vue')),
    IssueTrackerPop: defineAsyncComponent(() => import('@/components/labcommon/popup/IssueTrackerPop.vue')),
  },
  mounted () {
    uiUtils.accordionEvent()
  },
  unmounted () {
    uiUtils.accordionEvent()
  },
  setup () {
    const commonUtils = inject('commonUtils')
    const { openAsyncConfirm, openAsyncAlert } = useActions(['openAsyncConfirm', 'openAsyncAlert'])
    const store = useStore()
    const route = useRoute()
    const pathList = [
      { path: '/qdrug/all-lab-note-prd-list', pathNm: 'ALL LAB NOTES' },
      { path: '/qdrug/all-lab-note-prd-view', pathNm: '내용물 개요' }
    ]

    const reqInfo = ref(null)
    const product = ref(null)
    const appr = ref(null)
    const addVerFlag = ref('')
    const noteType = store.getters.getNoteType()
    const myInfo = store.getters.getMyInfo()
    const vLabNoteCd = route.query.vLabNoteCd || ''
    const recentNoteList = computed(() => store.getters.getRecentNoteList(noteType))

    const {
      selectReqInfo,
      goModify,
      goList,
      updateElabNoteRestart,
      selectIssueTrackerNoteInfo,
      saveLabNoteRequest,
    } = useQdrugRequest()

    const {
      selectLabNoteMstVerInfo,
    } = useRequestCommon()

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      fnChangeNoteInfo,
      showAddVerBtn,
      fnSetRecentLog,
      showIssueTrackBtn,
    } = useLabCommon()

    const fnDevelopCancelPop = () => {
      popParams.value = {
        vLabNoteCd,
        vContCd: reqInfo.value.vContCd || '',
        vContNm: reqInfo.value.vContNm || '',
        vNotePageType: 'prd',
      }

      popSelectFunc.value = init

      fnOpenPopup('DevelopCancelPop', false)
    }

    const fnDevelopRestart = async () => {
      if (await openAsyncConfirm({ message: '해당 실험노트 개발을 다시 시작하시겠습니까?'})) {
        const result = await updateElabNoteRestart({ vLabNoteCd })

        if (result === 'SUCC') {
          await openAsyncAlert({ message: '개발 재개되었습니다.' })
          init(vLabNoteCd)
        }
      }
    }

    const fnProductVersionTabEvent = async (obj) => {
      addVerFlag.value = ''

      if (!obj.versionInfo) {
        const payload = {
          vLabNoteCd: obj.vLabNoteCd,
          nVersion: obj.nVersion
        }

        const resultData = await selectLabNoteMstVerInfo(payload)

        const funcMateList = resultData.funcMateList

        if (funcMateList && funcMateList.length > 0) {
          resultData.funcMateList = funcMateList.forEach(item => {
            if (item.vFlagRequired === 'Y') {
              item.vFlagTo100 = ''
            }
          })
        }

        obj.versionInfo = resultData
      }
    }

    const goTabDetail = (item) => {
      window.location.href = '/qdrug/all-lab-note-prd-view?vLabNoteCd=' + item.vLabNoteCd
    }

    const fnDeleteTab = (index, item) => {
      store.dispatch('removeRecentNoteList', { noteType, index})

      if (recentNoteList.value.length === 0) {
        goList()
      } else if (item.vLabNoteCd === reqInfo.value.vLabNoteCd) {
        goTabDetail(recentNoteList.value[0])
      }
    }

    const fnNewVersionSave = async () => {
      const productChkKey = ['vCounterNmTemp', 'vCounterBrdNm', 'vCounterPrdNm', 'vCounterSpInfo', 
                            'vPrePilotDt', 'vCounterNote', 'vFlagNewItem',
                            'vEfficacyEffect', 'vCapacityUsage', 'vUseCautionNote']

      if (!product.value.fnValidateAll(productChkKey)) {
        openAsyncAlert({ message: '필수 입력사항을 확인해 주세요.' })
        return
      }

      reqInfo.value.vFlagNewVer = 'Y'
      reqInfo.value.versionInfo = { ...product.value.verParams }
      reqInfo.value.vStatusCd = 'LNC06_21'
      reqInfo.value.flagAction = 'M'

      const vLabNoteCd = await saveLabNoteRequest(reqInfo.value)
      if (vLabNoteCd) {
        await openAsyncAlert({ message: '저장 되었습니다.'})
        addVerFlag.value = ''
        init(vLabNoteCd)
      }
    }

    const fnAddVersion = () => {
      addVerFlag.value = 'Y'

      const tabWrap = document.querySelector('#productVersion')
      const isActive = tabWrap.querySelector('.ap_li_tab_item.is-active')
      if (isActive) {
        isActive.classList.remove('is-active')
      }
    }

    const fnPlantExtendPop = () => {
      popParams.value = {
        vLabNoteCd: reqInfo.value.vLabNoteCd,
        vCodeType: reqInfo.value.vCodeType,
        vContNm: reqInfo.value.vContNm,
        vNoteType: noteType,
        vBrdCd: reqInfo.value.vBrdCd,
      }

      fnOpenPopup('PlantExtendPop')
    }

    const fnNoteInfoChangeLogPop = () => {
      popParams.value = {
        vLabNoteCd: reqInfo.value.vLabNoteCd,
        vNoteType: noteType,
      }

      fnOpenPopup('NoteInfoChangeLogPop', false)
    }

    const fnNoteAuthPop = () => {
      popParams.value = {
        vLabNoteCd: reqInfo.value.vLabNoteCd,
        vContCd: reqInfo.value.vContCd,
        vContNm: reqInfo.value.vContNm,
        vPageType: 'prd',
      }

      fnOpenPopup('LabNoteAuthorityPop')
    }

    const fnReleaseCompletePop = () => {
      popParams.value = {
        vLabNoteCd: reqInfo.value.vLabNoteCd,
        vCodeType: 'HAL3'
      }

      fnOpenPopup('ReleaseCompletePop')
    }

    const fnIssueTrackPop = async () => {
      const noteInfo = await selectIssueTrackerNoteInfo({ vLabNoteCd: reqInfo.value.vLabNoteCd })
      popParams.value = {
        vLabNoteCd: reqInfo.value.vLabNoteCd,
        noteInfo: noteInfo,
        vNoteType: noteType
      }

      fnOpenPopup('IssueTrackerPop', false)
    }

    const showCompleteBtn = () => {
      let isVisible = false

      if (reqInfo.value && reqInfo.value.vFlagAllDecide === 'Y' &&
        (myInfo.loginId === reqInfo.value.vUserid || commonUtils.checkAuth('S000000'))) {
          isVisible = true
      }

      return isVisible
    }

    const showDevelopCancelBtn = () => {
      let isVisible = false

      if (reqInfo.value && 
          (reqInfo.value.vSlUserid === myInfo.loginId || reqInfo.value.vUserid === myInfo.loginId || commonUtils.checkAuth('S000000')) &&
          (reqInfo.value.vStatusCd !== 'LNC06_50' && reqInfo.value.vStatusCd !== 'LNC06_41')) {
        isVisible = true
      }

      return isVisible
    }

    const showDevelopRestartBtn = () => {
      let isVisible = false

      if (reqInfo.value &&
          (reqInfo.value.vSlUserid === myInfo.loginId || reqInfo.value.vUserid === myInfo.loginId || commonUtils.checkAuth('S000000')) &&
          reqInfo.value.vStatusCd === 'LNC06_41') {
        isVisible = true
      }

      return isVisible
    }

    const showMasterAuthBtn = () => {
      let isVisible = false

      if (reqInfo.value && myInfo.loginId === reqInfo.value.vUserid || commonUtils.checkAuth('S000000')) {
        isVisible = true
      }

      return isVisible
    }

    const showModifyBtn = () => {
      let isVisible = false

      if (reqInfo.value && 
            reqInfo.value.vStatusCd !== 'LNC06_50' &&
            (myInfo.loginId === reqInfo.value.vUserid || commonUtils.checkAuth('S000000'))) {
        isVisible = true
      }

      return isVisible
    }

    const init = async (vLabNoteCd = route.query.vLabNoteCd) => {
      reqInfo.value = await selectReqInfo({ vLabNoteCd: vLabNoteCd, vPageFlag: 'VIEW' })
      let recentInfo = null
      if (recentNoteList.value && recentNoteList.value.length > 0) {
        recentInfo = recentNoteList.value.filter(item => item.vLabNoteCd === reqInfo.value.vLabNoteCd)[0]
      }

      if (!recentInfo && reqInfo.value && commonUtils.isNotEmpty(reqInfo.value.vContCd)) {
        const data = {
          vNoteType: noteType,
          vLabNoteCd: reqInfo.value.vLabNoteCd,
          vContCd: reqInfo.value.vContCd,
          vContNm: reqInfo.value.vContNm,
          vPageType: 'prd'
        }
        await fnSetRecentLog(data)
      }

      if (reqInfo.value.verList && reqInfo.value.verList.length > 0) {
        reqInfo.value.verList.some((item) => {
          if (Number(item.nVersion) === Number(reqInfo.value.versionInfo.nVersion)) {
            item.versionInfo = reqInfo.value.versionInfo
            return true
          }
        })
      }

      fnChangeNoteInfo(reqInfo.value)
    }

    init()
    provide('reqInfo', reqInfo)

    return {
      commonUtils,
      pathList,
      addVerFlag,
      recentNoteList,
      reqInfo,
      product,
      appr,
      myInfo,
      popupContent,
      popParams,
      popSelectFunc,
      fnDevelopCancelPop,
      fnPlantExtendPop,
      fnNoteInfoChangeLogPop,
      fnNoteAuthPop,
      fnDevelopRestart,
      fnReleaseCompletePop,
      fnIssueTrackPop,
      goModify,
      goList,
      fnProductVersionTabEvent,
      fnNewVersionSave,
      goTabDetail,
      fnAddVersion,
      fnDeleteTab,
      showAddVerBtn,
      showCompleteBtn,
      showDevelopCancelBtn,
      showDevelopRestartBtn,
      showMasterAuthBtn,
      showModifyBtn,
      showIssueTrackBtn,
      vLabNoteCd,
    }
  }
}
</script>