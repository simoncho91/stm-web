<template>
  <ap-breadcrumb nav-title="의약외품 원료 DB" :path-list="pathList">
  </ap-breadcrumb>

  <div class="contents-core">
    <div class="contents-cell__wrap">

      <div class="contents-cell">
        <div class="contents-box contents-box__full">
          <div class="contents-box__inner">
            <div class="arrordion-item is-active">
              <div class="arrordion-header">
                <div class="arrordion-title">원료 DB 등록</div>
              </div>
              <div class="arrordion-body">
                <div class="text-exp text-exp__red">* 한글허가명은 한글 허가명과 규격을 각자 분리하여 기재 하여 주시기 바랍니다.</div>
                  <div class="basic-info__table researcher-information-table">
                    <table class="ui-table__contents">
                      <colgroup>
                        <col style="width:17rem">
                        <col style="width:auto">
                        <col style="width:17rem">
                        <col style="width:auto">
                      </colgroup>
                      <tbody>
                        <tr>
                          <th>원료코드<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
                          <td>
                            <div class="search-form" id="error_wrap_vMatrCd">
                              <div class="search-form__inner">
                                <ap-input
                                  v-model:value="payload.vMatrCd"
                                  input-class="ui-input__width--340"
                                  placeholder="검색어를 입력하세요."
                                  :readonly="true"
                                  @click="fnMatrSearchPop"
                                >
                                </ap-input>
                                <button type="button" class="ui-button ui-button__bg--lightgray ml-5" @click="fnMatrDel">삭제</button>
                              </div>
                              <span class="error-msg" id="error_msg_vMatrCd"></span>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <th>원료명<span class="ui-require"><span class="for-a11y">(필수)</span></span></th>
                          <td colspan="3">
                            <div class="form-flex">
                              <div class="search-form flex" id="error_wrap_vMatrNm">
                                <ap-input
                                  v-model:value="payload.vMatrNm"
                                  input-class="ui-input ui-input__width--full"
                                  :maxlength="100"
                                >
                                </ap-input>
                                <span class="error-msg" id="error_msg_vMatrNm"></span>
                              </div>
                            </div>
                          </td>
                        </tr>
                        
                        <template v-for="(vo, idx) in payload.permissionList" :key="'permiss_' + idx">
                        <tr>
                          <th>
                            <div class="charge-bms__th">
                              <div class="">한글허가명</div>
                              <div class="charge-bms__button">
                                <button v-if="idx == 0" type="button" :class="'ui-button__plus'" @click="addContentEvent"></button>
                                <button v-else type="button" :class="'ui-button__minus'" @click="delContentEvent(idx)"></button>
                              </div>
                            </div>
                          </th>
                          <td>
                            <div class="form-flex">
                              <div class="search-form ui-form-box__width--340 ui-form-box__max-width--230">
                                <ap-input
                                  v-model:value="vo.vPermissionKr"
                                  input-class="ui-input ui-input__width--full"
                                  :maxlength="1000"
                                  @click="fnPermissKr(idx)"
                                >
                                </ap-input>
                              </div>
                            </div>
                          </td>
                          <th>규격</th>
                          <td>
                            <div class="form-flex">
                              <div class="ui-select-box ui-form-box__width--230  form-flex__cell--5">
                                <ap-selectbox
                                  v-model:value="vo.vStandardCode"
                                  input-class="ui-select__width--full"
                                  :options="codeGroupMaps['SA_PERMISSION_STAND']"
                                />
                              </div>
                              <div class="ui-form-box__width--340 ui-form-box__max-width--230">
                              <ap-input
                                v-if="vo.vStandardCode == 'PS13'"
                                v-model:value="vo.vStandard"
                                input-class="ui-input__width--340 ml-5"
                                :maxlength="1000"
                              >
                              </ap-input>
                              </div>
                            </div>
                          </td>
                        </tr>
                        </template>

                        <tr>
                          <th>배합목적1</th>
                          <td>
                            <div class="form-flex">
                              <div class="ui-select-box ui-form-box__width--230  form-flex__cell--5">
                                <ap-selectbox
                                  v-model:value="payload.vCmbCode1"
                                  input-class="ui-select__width--full"
                                  :options="codeGroupMaps['SA_MATR_CMB']"
                                />
                              </div>
                            </div>
                          </td>
                          <th>배합목적2</th>
                          <td>
                            <div class="form-flex">
                              <div class="ui-select-box ui-form-box__width--230  form-flex__cell--5">
                                <ap-selectbox
                                  v-model:value="payload.vCmbCode2"
                                  input-class="ui-select__width--full"
                                  :options="codeGroupMaps['SA_MATR_CMB']"
                                />
                              </div>
                            </div>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
        </div>
      </div>

      <div class="page-bottom">
        <div class="page-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnSave">저장</button>
            <button type="button" class="ui-button ui-button__border--blue" v-if="vFlagAction === 'M'" @click="fnDel">삭제</button>
            <button type="button" class="ui-button ui-button__border--gray" @click="goList()">목록</button>
          </div>
        </div>
      </div>

    </div>
    
    <teleport to="#common-modal" v-if="popupContent">
      <ap-popup>
        <component :is="popupContent" :pop-params="popParams" @selectFunc="popSelectFunc" />
      </ap-popup>
    </teleport>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'
import { useRoute } from 'vue-router'
import { useCode } from '@/compositions/useCode'
import { useActions } from 'vuex-composition-helpers'
import { useQdrugMatrDb } from '@/compositions/qdrug/useQdrugMatrDb'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'

export default {
  name: 'QdrugNoteMatrDbRegister',
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),    
    QdrugNoteMatrSearchPop: defineAsyncComponent(() => import('@/components/qdrug/popup/QdrugNoteMatrSearchPop.vue')),
  },
  setup() {
    const { openAsyncConfirm, openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncConfirm', 'openAsyncAlert', 'closeAsyncPopup'])
    const commonUtils = inject('commonUtils')
    const route = useRoute()
    const vMatrCd = route.query.vMatrCd || ''
    const vFlagAction = ref('')

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const pathList = [
      { path: '/qdrug/qdrug-note-matr-db-list', pathNm: '원료 DB' },
    ]
    
    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
    } = useLabCommon()
    
    const {
      page,
      list,
      selectReqInfo,
      saveMatrDb,
      deleteMatrDb,
      goList,
    } = useQdrugMatrDb()

    const payload = ref({
      //원료코드
      vMatrCd: '',
      //원료명
      vMatrNm: '',

      //배합목적1
      vCmbCode1: '',
      //배합목적2
      vCmbCode2: '',

      //한글허가명
      permissionList: [],
    })

    
    const fnMatrSearchPop = () => {
      // 원료코드 팝업
      popSelectFunc.value = getMatrSearchInfo     
      fnOpenPopup('QdrugNoteMatrSearchPop')
    }

    // 원료코드 및 원료명 세팅
    const getMatrSearchInfo = (item) => {
      const matrCd = item.vMatrCd
      
      if (commonUtils.isNotEmpty(matrCd)) {
        payload.value.vMatrCd = item.vMatrCd
        payload.value.vMatrNm = item.vMatrNm

        payload.value.permissionList = []
        addContentEvent()

        if(commonUtils.isNotEmpty(item.vPermissionKr)){
          payload.value.permissionList[0].vPermissionKr = item.vPermissionKr
        }

        vFlagAction.value = 'R'
      }

    }

    const init = async () => {

      if(vMatrCd != '' && vMatrCd != null){
        const result = await selectReqInfo({ vMatrCd: vMatrCd})  
        payload.value = {...payload.value, ...result}
        vFlagAction.value = 'M'
      }else{
        vFlagAction.value = 'R'
      }
      
      //	SA_MATR_CMB	배합목적1 코드 
      //	SA_PERMISSION_STAND	규격 코드
      findCodeList(['SA_MATR_CMB','SA_PERMISSION_STAND'])
      
      if (!payload.value.permissionList && payload.value.permissionList.length === 0) {
          addContentEvent()
      }else{
          const perLen = payload.value.permissionList
          if(perLen == '' || perLen == undefined){
              payload.value.permissionList = []
              addContentEvent()
          }
      }

    }

    const addContentEvent = () => {
      const obj = {
        vPermissionKr: '',
        vStandard: '',
        vStandardCode: '',
      }

      payload.value.permissionList.push({ ...obj })
    }

    const delContentEvent = (idx) => {
      payload.value.permissionList.splice(idx,1)
    }

    const fnMatrDel = () => {
      payload.value.vMatrCd =  ''
      payload.value.vMatrNm =  ''
      payload.value.permissionList = []
      vFlagAction.value = 'R'
      addContentEvent()
    }

    const fnSaveValidate = (chkObject) => {
      let isOk = true
      if (chkObject.basicChkKey && !fnValidateAll(chkObject.basicChkKey)) {
        isOk = false
      }

      return isOk
    }

    const fnSave = async () =>{

      const basicChkKey = ['vMatrCd', 'vMatrNm']

      const chkObject = {
        basicChkKey: basicChkKey
      }

      if (!fnSaveValidate(chkObject)) {
        await openAsyncAlert({ message: '원료코드와 원료명은 필수값 입니다.' })
        window.scrollTo(0, 0)
        return
      }

      if (!await openAsyncConfirm({ message : "저장 하시겠습니까?" })) {
        return
      }

      const result = await saveMatrDb(payload.value)  

      if(result == "SUCC"){
        await openAsyncAlert({ message: "저장되었습니다." })
        goList()
      }
    }

    const fnDel = async () =>{

      if (!await openAsyncConfirm({ message : "삭제하시겠습니까?" })) {
        return
      }
      
      const result = await deleteMatrDb({ vMatrCd: vMatrCd})  
      
      if(result == "SUCC"){
        await openAsyncAlert({ message: "삭제되었습니다." })
        goList()
      }
    }

    const fnValidateAll = (arrChkKey) => {
      let isOk = true
      
      commonUtils.hideErrorMessageAll(['vMatrCd', 'vMatrNm'])

      arrChkKey.forEach(key => {
        if (!fnValidate(key)) {
          isOk = false
        }
      })

      return isOk
    }

    const fnValidate = (key) => {
      let isOk = true
      let errorMsg = '필수 입력 사항입니다.'
      commonUtils.hideErrorMessage(key)

      if (commonUtils.isEmpty(payload.value[key])) {
        isOk = false
      }

      if (!isOk) {
        commonUtils.showErrorMessage(key, errorMsg)
      }

      return isOk
    }

    const fnPermissKr = (idx) => {
      if(payload.value.permissionList[idx].vPermissionKr != null || payload.value.permissionList[idx].vPermissionKr != undefined ){
        payload.value.permissionList[idx].vPermissionKr = payload.value.permissionList[idx].vPermissionKr.trim()
      }
    }

    init()

    return {
      commonUtils,
      codeGroupMaps,
      pathList,
      list,
      page,
      payload,
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      fnMatrSearchPop,
      addContentEvent,
      delContentEvent,
      vMatrCd,
      selectReqInfo,
      fnMatrDel,
      saveMatrDb,
      deleteMatrDb,
      fnSave,
      fnDel,
      goList,
      fnPermissKr,
      vFlagAction,
    }
  }
}
</script>