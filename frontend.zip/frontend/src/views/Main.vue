<template>
  <div class="admin-main">
      <div class="admin-main__inner">
        <div class="admin-main__left">
          <div class="admin-main__box--wrap" v-if="showCardArea">
            <template v-for="(vo, idx) in menuAuthList" :key="'main_' + idx">
              <div class="admin-main__box" v-if="vo.vRouter !== 'approval'">
                <div class="admin-main__box">
                  <a href="#" :class="'admin-main__link admin-main__' + vo.vRouter" @click.prevent="goNotePage(vo)">
                    {{ vo.vMenunm }}
                  </a>
                </div>
              </div>
            </template>
          </div>
        </div>
        <div class="admin-main__right"></div>
      </div>
  </div>
</template>

<script>
import { ref } from 'vue'
import { useStore } from 'vuex'
import { useRoute, useRouter } from 'vue-router'
import { dynamicRouterInit } from '@/router/dynamicRouter'

export default {
  name: "mainPage",
  setup() {
    const store = useStore()
    const router = useRouter()
    const route = useRoute()
    const menuAuthList = ref([])
    const showCardArea = ref(false)

    const goNotePage = (obj) => {
      store.dispatch('setNoteType', obj.vRouter)

      router.push({ path: obj.vPageid })
    }

    const goLoginPage = () => {
      const historyUrl = window.location.href
        if (historyUrl.indexOf('/login') === -1) {
          sessionStorage.setItem('historyUrl', historyUrl)
        }
        window.location.href = '/login'
    }

    const fnSsoLogin = async () => {
      await store.dispatch('checkSso').then(async res => {
        if (!res) {
          goLoginPage()
        } else {
          const resData = res.data
          if (resData.code === 'C0000') {
            await dynamicRouterInit()
          } else if (resData.code === 'SSO_FIRST_ACCESS') {
            store.dispatch('checkSso').then(async res2 => {
              const resData2 = res2.data
              if (resData2.code === 'C0000') {
                await dynamicRouterInit()
                store.dispatch('setSession', { token: resData.token, myInfo: resData })
              } else {
                goLoginPage()
              }
            })
          } else {
            goLoginPage()
          }
        }
      })
    }

    const init = async () => {
      const nowMyInfo = store.getters.getMyInfo()
      const authAnyone = route.meta.authAnyone !== undefined && route.meta.authAnyone
      if (!authAnyone && (nowMyInfo === undefined || nowMyInfo.loginId === undefined) && import.meta.env.VITE_SERVER_MODE === 'PRD') {
        await fnSsoLogin()
      }
      const historyUrl = sessionStorage.getItem('historyUrl')
      let historyRouter = ''

      if (historyUrl) {
        historyRouter = historyUrl.replace('http://', '').replace('https://', '').split('/')
      }

      if (historyUrl && historyUrl.indexOf('/login') === -1 &&
          historyUrl.indexOf('/main') === -1 &&
          ( historyRouter.length === 3 && historyRouter[1] !== '')) {
        if (historyRouter.length > 2 && 'skincare|makeup|hbd|qdrug'.indexOf(historyRouter[1]) > -1) {
          store.dispatch('setNoteType', historyRouter[1])
        }

        if (route.query.redirect !== 'N') {
          window.location.href = historyUrl
          sessionStorage.removeItem('historyUrl')
          return
        }
      }

      menuAuthList.value = JSON.parse(sessionStorage.getItem('menuAuthList')) || []
      if (!menuAuthList.value || menuAuthList.value.length === 0) {
        menuAuthList.value = await store.dispatch('findMenuAuthList')
      }

      if (menuAuthList.value && menuAuthList.value.length > 0) {
        if (menuAuthList.value.length == 1) {
          goNotePage(menuAuthList.value[0])
        }
      }
      showCardArea.value = true
    }

    init()

    return {
      router,
      showCardArea,
      menuAuthList,
      goNotePage
    }
  }
};
</script>