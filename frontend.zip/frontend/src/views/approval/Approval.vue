<template>
  <div class="contents-core">
    <div class="contents-cell__wrap">
      <div class="contents-cell">
        <div class="contents-box contents-box__full">
          <div class="contents-box__inner">
            <div class="contents-tab ap_contents_tab">
              <div class="contents-tab__inner">
                <ApTab
                  mst-id="tab_example"
                  :tab-list="tabList"
                  :default-tab="'apprTab01'"
                  @click="fnChangeTab"
                />
                <div class="contents-tab__body" id="apprTab01">
                  <ApprovalList
                    v-if="nowTabId === 'apprTab01'"
                  />
                </div>
                <div class="contents-tab__body" id="apprTab02">
                  <ApprovalFinishList
                    v-if="nowTabId === 'apprTab02'"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, provide } from 'vue'
import { useCode } from '@/compositions/useCode'

export default {
  name: 'Approval',
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    ApprovalList: defineAsyncComponent(() => import('@/components/approval/ApprovalList.vue')),
    ApprovalFinishList: defineAsyncComponent(() => import('@/components/approval/ApprovalFinishList.vue'))
  },
  setup() {
    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const nowTabId = ref('apprTab01')

    // temp
    const tabList = [
      { tabId: 'apprTab01', tabNm: '결재함'}, 
      { tabId: 'apprTab02', tabNm: '결재완료'},
    ]

    const fnChangeTab = (item) => {
      if (item && item.tabId) nowTabId.value = item.tabId
    }

    const init = async () => {
      await findCodeList(['SC0021'])
    }

    init()

    provide('codeGroupMaps', codeGroupMaps)

    return {
      nowTabId,
      tabList,
      fnChangeTab
    }
  }
}
</script>
