<template>
  <div v-show="reqInfo">
    <div class="page-tab multi-cont-view-page">
      <div class="page-tab__inner">
        <HistoryTab
          v-if="reqInfo && commonUtils.isNotEmpty(reqInfo.vContCd)"
          :v-lab-note-cd="vLabNoteCd"
          url-link="/makeup/all-lab-note-{pageType}-view?vLabNoteCd="
          @go-list="goList()"
        >
        </HistoryTab>

        <div class="page-tab__contents multi-cont-view-contents">
          <ap-breadcrumb
            nav-title="내용물 개요"
            :path-list="pathList"
          >
          </ap-breadcrumb>

          <div class="page-tab__item">
            <AllLabNoteMakeupBasicInfoView></AllLabNoteMakeupBasicInfoView>
          </div>
        </div>
      </div>
    </div>

    <div class="contents-core">
      <div class="contents-cell__wrap">
        <div class="contents-cell">
          <div class="contents-box contents-box__full">
            <div class="contents-box__inner min-height__unset border-top-radius__unset">
              <MakeupContInfoView></MakeupContInfoView>
            </div>
          </div>

          <div class="contents-box contents-box__full">
            <div class="contents-box__inner min-height__unset">
              <AllLabNoteMakeupResearcherInfoView></AllLabNoteMakeupResearcherInfoView>
            </div>
          </div>

          <div class="contents-box contents-box__full">
            <div class="contents-box__inner min-height__unset">
              <AllLabNoteMakeupMarketingInfoView></AllLabNoteMakeupMarketingInfoView>
            </div>
          </div>

          <div class="contents-box contents-box__full">
            <div class="contents-box__inner min-height__unset">
              <div class="arrordion-item is-active">
                <div class="arrordion-header">
                  <div class="arrordion-title">제품 정보</div>
                  <p class="p_caution ml-10">* 향료 정보를 제외한 Product 정보는 마케터에게 노출되지 않습니다.</p>
                  <button type="button" class="ui-button__accordion"></button>
                </div>
                <div class="arrordion-body">
                  <div class="detail-tab ap_contents_tab" v-if="reqInfo && reqInfo.verList">
                    <div class="ver_tab_area">
                      <ApTab
                        v-if="reqInfo.verList.length > 0"
                        mst-id="productVersion"
                        :tab-list="reqInfo.verList"
                        tab-id-key="vVersionKey"
                        tab-nm-key="vVersionTxt"
                        :tab-style="['detail-tab__inner', 'ui-list detail-tab__lists', 'detail-tab__list', 'detail-tab__link']"
                        :default-tab="reqInfo.verList[reqInfo.verList.length - 1].vVersionKey"
                        @click="fnProductVersionTabEvent"
                      >
                      </ApTab>
                      <button
                        v-if="showAddVerBtn(reqInfo) && showModifyBtn()"
                        type="button"
                        class="detail-tab__button--plus add_btn"
                        :class="addVerFlag === 'Y' ? 'active' : ''"
                        @click="fnAddVersion()"
                      >
                      </button>
                    </div>
                    <template v-if="addVerFlag !== 'Y'">
                      <div class="contents-tab__body"
                        v-for="(item, index) in reqInfo.verList"
                        :key="'version_area_' + index"
                        :id="item.vVersionKey"
                      >
                        <AllLabNoteMakeupProductInfoView
                          v-if="item.versionInfo"
                          :version-info="item.versionInfo"
                        >
                        </AllLabNoteMakeupProductInfoView>
                      </div>
                    </template>
                    <template v-else>
                      <AllLabNoteMakeupProductInfoRegister
                        ref="product"
                      >
                      </AllLabNoteMakeupProductInfoRegister>
                      <div class="page-bottom">
                        <div class="ui-buttons ui-buttons__right">
                          <button type="button" class="ui-button ui-button__height--28 ui-button__bg--blue" v-if="addVerFlag === 'Y'" @click="fnNewVersionSave()">버전 추가 저장</button>
                        </div>
                      </div>
                    </template>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="contents-box contents-box__full contents-box__with--tab">
          <AllLabNoteMakeupEtcInfoView></AllLabNoteMakeupEtcInfoView>
        </div>

        <div class="page-bottom">
          <div class="page-bottom__inner form-flex-between">
            <div class="ui-buttons ui-buttons__left">
              <button type="button" class="ui-button ui-button__bg--blue" v-if="showCompleteBtn()" @click="fnLaunchCompletePop()">출시 완료</button>
              <button type="button" class="ui-button ui-button__bg--lightgray" v-if="showDevelopCancelBtn()" @click="fnDevelopCancelPop()">개발취소</button>
              <button type="button" class="ui-button ui-button__bg--lightgray" v-if="showDevelopRestartBtn()" @click="fnDevelopRestart()">개발재개</button>
              <template v-if="showMasterAuthBtn()">
                <button type="button" class="ui-button ui-button__border--gray" @click="fnPlantExtendPop()">플랜트 확장</button>
              </template>
              <button type="button" class="ui-button ui-button__border--gray" @click="fnNoteInfoChangeLogPop()">변경이력보기</button>
            </div>
            <div class="ui-buttons ui-buttons__right">
              <template v-if="showMasterAuthBtn()">
                <button type="button" class="ui-button ui-button__bg--blue" @click="fnNoteAuthPop()">노트 공유하기</button>
              </template>
              <button type="button" class="ui-button ui-button__bg--blue" @click="fnMarketerShareMail()">마케터 공유하기</button>
              <button type="button" class="ui-button ui-button__bg--skyblue" v-if="showModifyBtn()" @click="goModify(reqInfo.vLabNoteCd)">수정</button>
              <button type="button" class="ui-button ui-button__border--gray" @click="goList()">목록</button>
            </div>
          </div>
        </div>
      </div>
      <button type="button" class="button-caution" v-if="showIssueTrackBtn('MU', reqInfo)" @click="fnIssueTrackPop()"></button>
    </div>
    <teleport to="#common-modal" v-if="popupContent">
      <ap-popup>
        <component
          :is="popupContent"
          :pop-params="popParams"
          @selectFunc="popSelectFunc"
          @callbackFunc="popSelectFunc"
        />
      </ap-popup>
    </teleport>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, computed, provide, inject } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useStore } from 'vuex'
import { useMakeupRequest } from '@/compositions/makeup/useMakeupRequest'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useRequestCommon } from '@/compositions/labcommon/useRequestCommon'
import { useActions } from 'vuex-composition-helpers'
import uiUtils from '@/utils/uiUtils'
import AllLabNoteMakeupBasicInfoView from '@/components/makeup/AllLabNoteMakeupBasicInfoView.vue'
import AllLabNoteMakeupResearcherInfoView from '@/components/makeup/AllLabNoteMakeupResearcherInfoView.vue'
import AllLabNoteMakeupMarketingInfoView from '@/components/makeup/AllLabNoteMakeupMarketingInfoView.vue'
export default {
  name: 'AllLabNoteView',
  components: {
    AllLabNoteMakeupBasicInfoView,
    AllLabNoteMakeupResearcherInfoView,
    AllLabNoteMakeupMarketingInfoView,
    AllLabNoteMakeupProductInfoView: defineAsyncComponent(() => import('@/components/makeup/AllLabNoteMakeupProductInfoView.vue')),
    AllLabNoteMakeupProductInfoRegister: defineAsyncComponent(() => import('@/components/makeup/AllLabNoteMakeupProductInfoRegister.vue')),
    AllLabNoteMakeupEtcInfoView: defineAsyncComponent(() => import('@/components/makeup/AllLabNoteMakeupEtcInfoView.vue')),
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    HistoryTab: defineAsyncComponent(() => import('@/components/labcommon/HistoryTab.vue')),
    MakeupContInfoView: defineAsyncComponent(() => import('@/components/makeup/MakeupContInfoView.vue')),
    DevelopCancelPop: defineAsyncComponent(() => import('@/components/labcommon/popup/DevelopCancelPop.vue')),
    PlantExtendPop: defineAsyncComponent(() => import('@/components/labcommon/popup/PlantExtendPop.vue')),
    NoteInfoChangeLogPop: defineAsyncComponent(() => import('@/components/labcommon/popup/NoteInfoChangeLogPop.vue')),
    LabNoteAuthorityPop: defineAsyncComponent(() => import('@/components/labcommon/popup/LabNoteAuthorityPop.vue')),
    LaunchCompletePop: defineAsyncComponent(() => import('@/components/labcommon/popup/LaunchCompletePop.vue')),
    IssueTrackerPop: defineAsyncComponent(() => import('@/components/labcommon/popup/IssueTrackerPop.vue')),
    OpinionApprReqPop: defineAsyncComponent(() => import('@/components/approval/popup/OpinionApprReqPop.vue')),
  },
  mounted () {
    uiUtils.accordionEvent()
  },
  unmounted () {
    uiUtils.accordionEvent()
  },
  setup () {
    const commonUtils = inject('commonUtils')
    const { openAsyncConfirm, openAsyncAlert, closeAsyncPopup } = useActions(['openAsyncConfirm', 'openAsyncAlert', 'closeAsyncPopup'])
    const store = useStore()
    const router = useRouter()
    const route = useRoute()
    const pathList = [
      { path: '/makeup/all-lab-note-prd-list', pathNm: 'ALL LAB NOTES' },
      { path: '/makeup/all-lab-note-prd-view', pathNm: '내용물 개요' }
    ]

    const reqInfo = ref(null)
    const product = ref(null)
    const appr = ref(null)
    const addVerFlag = ref('')
    const noteType = store.getters.getNoteType()
    const myInfo = store.getters.getMyInfo()
    const vLabNoteCd = route.query.vLabNoteCd || ''
    const recentNoteList = computed(() => store.getters.getRecentNoteList(noteType))

    const {
      selectReqInfo,
      goModify,
      goList,
      saveLabNoteRequest,
      updateElabNoteRestart,
      selectIssueTrackerNoteInfo,
      sendMarketerShareMail,
    } = useMakeupRequest()

    const {
      selectLabNoteMstVerInfo,
    } = useRequestCommon()

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      fnChangeNoteInfo,
      showAddVerBtn,
      fnSetRecentLog,
      showIssueTrackBtn,
    } = useLabCommon()

    const fnDevelopCancelPop = () => {
      popParams.value = {
        vLabNoteCd,
        vContCd: reqInfo.value.vContCd || '',
        vContNm: reqInfo.value.vContNm || '',
        vNotePageType: 'prd',
      }

      popSelectFunc.value = init

      fnOpenPopup('DevelopCancelPop', false)
    }

    const fnDevelopRestart = async () => {
      if (await openAsyncConfirm({ message: '해당 실험노트 개발을 다시 시작하시겠습니까?'})) {
        const result = await updateElabNoteRestart({ vLabNoteCd })

        if (result === 'SUCC') {
          await openAsyncAlert({ message: '개발 재개되었습니다.' })
          init(vLabNoteCd)
        }
      }
    }

    const fnProductVersionTabEvent = async (obj) => {
      addVerFlag.value = ''

      const payload = {
        vLabNoteCd: obj.vLabNoteCd,
        nVersion: obj.nVersion
      }

      const resultData = await selectLabNoteMstVerInfo(payload)

      console.log(resultData)

      const funcMateList = resultData.funcMateList

      if (funcMateList && funcMateList.length > 0) {
        resultData.funcMateList = funcMateList.forEach(item => {
          if (item.vFlagRequired === 'Y') {
            item.vFlagTo100 = ''
          }
        })
      }

      obj.versionInfo = resultData
    }

    const goTabDetail = (item) => {
      window.location.href = '/makeup/all-lab-note-prd-view?vLabNoteCd=' + item.vLabNoteCd
    }

    const fnDeleteTab = (index, item) => {
      store.dispatch('removeRecentNoteList', { noteType, index})

      if (recentNoteList.value.length === 0) {
        goList()
      } else if (item.vLabNoteCd === reqInfo.value.vLabNoteCd) {
        goTabDetail(recentNoteList.value[0])
      }
    }

    const fnAddVersion = () => {
      addVerFlag.value = 'Y'

      const tabWrap = document.querySelector('#productVersion')
      const isActive = tabWrap.querySelector('.ap_li_tab_item.is-active')
      if (isActive) {
        isActive.classList.remove('is-active')
      }
    }

    const fnNewVersionSave = async () => {
      const productChkKey = ['vCounterNmTemp', 'vCounterBrdNm', 'vCounterSpInfo',
                            'vPrePilotDt', 'vCounterNote', 'vFlagNewItem']

      if (!product.value.fnValidateAll(productChkKey)) {
        openAsyncAlert({ message: '필수 입력사항을 확인해 주세요.' })
        return
      }

      reqInfo.value.vFlagNewVer = 'Y'
      reqInfo.value.versionInfo = { ...product.value.verParams }
      reqInfo.value.vStatusCd = 'LNC06_21'
      reqInfo.value.flagAction = 'M'

      //버전 추가 저장 시 기능성 허가 필드도 업데이트 되도록 값 셋팅
      let productVerParams = {}
      let flagFuncTest = ''

      if (product.value) {
        if (product.value.verParams) {
          productVerParams = product.value.verParams
          const funcList = productVerParams.funcList

          funcList.some(item => {
            if (commonUtils.isNotEmpty(item.vTag2Cd)) {
              flagFuncTest = 'Y'
              return true
            }
          })
        } else if (product.value[0].verParams) {
          productVerParams = product.value[0].verParams
          const funcList = productVerParams.funcList

          funcList.some(item => {
            if (commonUtils.isNotEmpty(item.vTag2Cd)) {
              flagFuncTest = 'Y'
              return true
            }
          })
        }
      }

      reqInfo.value.vFlagFuncTest = flagFuncTest 
      
      const vLabNoteCd = await saveLabNoteRequest(reqInfo.value)
      if (vLabNoteCd) {
        await openAsyncAlert({ message: '저장 되었습니다.'})
        window.location.reload(true)
      }
    }

    const fnPlantExtendPop = () => {
      popParams.value = {
        vLabNoteCd: reqInfo.value.vLabNoteCd,
        vCodeType: reqInfo.value.vCodeType,
        vContNm: reqInfo.value.vContNm,
        vNoteType: noteType,
        vBrdCd: reqInfo.value.vBrdCd,
      }

      fnOpenPopup('PlantExtendPop')
    }

    const fnNoteInfoChangeLogPop = () => {
      popParams.value = {
        vLabNoteCd: reqInfo.value.vLabNoteCd,
        vNoteType: noteType,
      }

      fnOpenPopup('NoteInfoChangeLogPop', false)
    }

    const fnNoteAuthPop = () => {
      popParams.value = {
        vLabNoteCd: reqInfo.value.vLabNoteCd,
        vContCd: reqInfo.value.vContCd,
        vContNm: reqInfo.value.vContNm,
        vPageType: 'prd',
      }

      fnOpenPopup('LabNoteAuthorityPop')
    }

    const fnLaunchCompletePop = () => {
      popParams.value = {
        vLabNoteCd: reqInfo.value.vLabNoteCd,
        vFlagCompleteModify: 'N'
      }

      fnOpenPopup('LaunchCompletePop')
    }

    const fnIssueTrackPop = async () => {
      const noteInfo = await selectIssueTrackerNoteInfo({ vLabNoteCd: reqInfo.value.vLabNoteCd })
      popParams.value = {
        vLabNoteCd: reqInfo.value.vLabNoteCd,
        noteInfo: noteInfo,
        vNoteType: noteType
      }

      fnOpenPopup('IssueTrackerPop', false)
    }

    const showDevelopCancelBtn = () => {
      let isVisible = false

      if (reqInfo.value && 
          (reqInfo.value.vSlUserid === myInfo.loginId || reqInfo.value.vUserid === myInfo.loginId || commonUtils.checkAuth('S000000')) &&
          (reqInfo.value.vStatusCd !== 'LNC06_50' && reqInfo.value.vStatusCd !== 'LNC06_41')) {
        isVisible = true
      }

      return isVisible
    }

    const showDevelopRestartBtn = () => {
      let isVisible = false

      if (reqInfo.value &&
          (reqInfo.value.vSlUserid === myInfo.loginId || reqInfo.value.vUserid === myInfo.loginId || commonUtils.checkAuth('S000000')) &&
          reqInfo.value.vStatusCd === 'LNC06_41') {
        isVisible = true
      }

      return isVisible
    }

    const showModifyBtn = () => {
      let isVisible = false

      if (reqInfo.value && 
            reqInfo.value.vStatusCd !== 'LNC06_50' &&
            (myInfo.loginId === reqInfo.value.vUserid || commonUtils.checkAuth('S000000')) &&
            reqInfo.value.vFlagMassAppr !== 'Y') {
        isVisible = true
      }

      return isVisible
    }

    const showMasterAuthBtn = () => {
      let isVisible = false

      if (reqInfo.value && myInfo.loginId === reqInfo.value.vUserid || commonUtils.checkAuth('S000000')) {
        isVisible = true
      }

      return isVisible
    }

    const showCompleteBtn = () => {
      let isVisible = false

      if (reqInfo.value && 
          reqInfo.value.vStatusCd !== 'LNC06_50' &&
          (reqInfo.value.vSlUserid === myInfo.loginId || reqInfo.value.vUserid === myInfo.loginId || commonUtils.checkAuth('S000000')) &&
          (reqInfo.value.vFlagAllDecide === 'Y' || reqInfo.value.vFlagMassAppr === 'Y')) {
        isVisible = true
      }

      return isVisible
    }

    /*
    const showIssueTrackBtn = () => {
      let isVisible = false

      if (reqInfo.value && (reqInfo.value.vUserid === myInfo.loginId || commonUtils.checkAuth('S000000'))) {
        isVisible = true
      }

      return isVisible
    }
    */

    const fnSendMarketerShareMail = async (vOpinion) => {
      const payload = {
        vLabNoteCd: reqInfo.value.vLabNoteCd,
        vOpinion: vOpinion.value,
      }

      closeAsyncPopup({message: ''})

      const result = await sendMarketerShareMail(payload)
      if (result && result === 'SUCC') {
        openAsyncAlert({ message: '메일이 발송되었습니다.' })
      }
    }

    const fnMarketerShareMail = async () => {
      if (reqInfo.value && commonUtils.isEmpty(reqInfo.value.vBrdUserid)) {
        openAsyncAlert({ message: '브랜드 담당 PM 등록 후 메일 발송이 가능합니다.' })
        return
      }

      if (!await openAsyncConfirm({ message: '브랜드 담당 PM에게 공유 메일을 발송하시겠습니까? '})) {
        return
      }

      popSelectFunc.value = fnSendMarketerShareMail
      fnOpenPopup('OpinionApprReqPop')
    }

    const init = async (vLabNoteCd = route.query.vLabNoteCd) => {
      if (commonUtils.checkAuth('S000333')) {
        router.push({ path: '/makeup/all-lab-note-brand-manager-view', query: { vLabNoteCd }})
        return
      }
      reqInfo.value = await selectReqInfo({ vLabNoteCd: vLabNoteCd, vPageFlag: 'VIEW' })
      let recentInfo = null
      if (recentNoteList.value && recentNoteList.value.length > 0) {
        recentInfo = recentNoteList.value.filter(item => item.vLabNoteCd === reqInfo.value.vLabNoteCd)[0]
      }

      if (!recentInfo && reqInfo.value && commonUtils.isNotEmpty(reqInfo.value.vContCd)) {
          const data = {
            vNoteType: noteType,
            vLabNoteCd: reqInfo.value.vLabNoteCd,
            vContCd: reqInfo.value.vContCd,
            vContNm: reqInfo.value.vContNm,
            vTctnBynmNm: reqInfo.value.vTctnBynmNm,
            vPageType: 'prd'
          }
          await fnSetRecentLog(data)
        }

      if (reqInfo.value.verList && reqInfo.value.verList.length > 0) {
        reqInfo.value.verList.some((item) => {
          if (Number(item.nVersion) === Number(reqInfo.value.versionInfo.nVersion)) {
            item.versionInfo = reqInfo.value.versionInfo
            return true
          }
        })
      }

      fnChangeNoteInfo(reqInfo.value)
    }

    init()
    provide('reqInfo', reqInfo)

    return {
      commonUtils,
      pathList,
      addVerFlag,
      recentNoteList,
      reqInfo,
      product,
      appr,
      popupContent,
      popParams,
      popSelectFunc,
      fnDevelopCancelPop,
      fnDevelopRestart,
      fnProductVersionTabEvent,
      fnNewVersionSave,
      goTabDetail,
      fnDeleteTab,
      fnAddVersion,
      fnPlantExtendPop,
      fnNoteInfoChangeLogPop,
      fnNoteAuthPop,
      fnLaunchCompletePop,
      fnIssueTrackPop,
      goList,
      goModify,
      showAddVerBtn,
      showCompleteBtn,
      showDevelopCancelBtn,
      showDevelopRestartBtn,
      showModifyBtn,
      showMasterAuthBtn,
      showIssueTrackBtn,
      fnMarketerShareMail,
      vLabNoteCd,
    }
  }
}
</script>