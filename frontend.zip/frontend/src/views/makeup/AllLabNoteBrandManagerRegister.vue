<template>
  <div class="contents-core">
    <div class="contents-cell__wrap">
      <!-- 내용물 개요 -->
      <div class="contents-cell flex-none">
        <div class="contents-box contents-box__full">
          <div class="contents-box__inner min-height__unset">
            <AllLabNoteBrandManagerBasicInfoRegister
              ref="basic"
            >
            </AllLabNoteBrandManagerBasicInfoRegister>
          </div>
        </div>
      </div>

      <!-- 마케팅 정보 -->
      <div class="contents-cell flex-none">
        <div class="contents-box contents-box__full">
          <div class="contents-box__inner min-height__unset">
            <AllLabNoteBrandManagerMarketingInfoRegister
              ref="marketing"
            >
            </AllLabNoteBrandManagerMarketingInfoRegister>
          </div>
        </div>
      </div>

      <!-- 제품 정보 -->
      <div class="contents-cell flex-none">
        <div class="contents-box contents-box__full">
          <div class="contents-box__inner min-height__unset">
            <div class="arrordion-item is-active">
              <div class="arrordion-header">
                <div class="arrordion-title">제품 정보</div>
                <button type="button" class="ui-button__accordion"></button>
              </div>
              <div class="arrordion-body">
                <div class="detail-tab ap_contents_tab">
                  <div class="ver_tab_area" v-if="reqInfo && reqInfo.verList && reqInfo.verList.length > 0">
                    <ApTab
                      mst-id="productVersion"
                      :tab-list="reqInfo.verList"
                      tab-id-key="vVersionKey"
                      tab-nm-key="vVersionTxt"
                      :tab-style="['detail-tab__inner', 'ui-list detail-tab__lists', 'detail-tab__list', 'detail-tab__link']"
                      :default-tab="reqInfo.verList[reqInfo.verList.length - 1].vVersionKey"
                      @click="fnProductVersionTabEvent"
                    >
                    </ApTab>
                  </div>
                  <template v-if="reqInfo && reqInfo.verList && reqInfo.verList.length > 0">
                    <div class="contents-tab__body"
                      v-for="(item, index) in reqInfo.verList"
                      :key="'version_area_' + index"
                      :id="item.vVersionKey"
                    >
                      <AllLabNoteBrandManagerProductInfoView
                        v-if="item.versionInfo"
                        :version-info="item.versionInfo"
                      >
                      </AllLabNoteBrandManagerProductInfoView>
                    </div>
                  </template>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="page-bottom">
        <div class="page-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--skyblue" v-if="showModifyBtn()" @click="fnSave()">수정</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, onMounted, ref, provide, inject, onUnmounted } from 'vue'
import { useMakeupBMRegister } from '@/compositions/makeup/useMakeupBMRegister'
import { useActions } from 'vuex-composition-helpers'
import { useRoute } from 'vue-router'
import uiUtils from '@/utils/uiUtils'

import AllLabNoteBrandManagerBasicInfoRegister from '@/components/makeup/AllLabNoteBrandManagerBasicInfoRegister.vue'
import AllLabNoteBrandManagerMarketingInfoRegister from '@/components/makeup/AllLabNoteBrandManagerMarketingInfoRegister.vue'

export default {
  name: 'AllLabNoteBrandManagerRegister',
  components: {
    AllLabNoteBrandManagerBasicInfoRegister,
    AllLabNoteBrandManagerMarketingInfoRegister,
    AllLabNoteBrandManagerProductInfoView: defineAsyncComponent(() => import('@/components/makeup/AllLabNoteBrandManagerProductInfoView.vue')),
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
  },
  setup () {
    const commonUtils = inject('commonUtils')
    const basic = ref(null)
    const product = ref(null)
    const marketing = ref(null)
    const route = useRoute()
    const reqInfo = ref({})
    const regParams = ref({})
    const { openAsyncAlert } = useActions(['openAsyncAlert'])

    const {
      selectReqInfo,
      selectLabNoteMstVerInfo,
      updateReqPrdInfo,
    } = useMakeupBMRegister()

    const fnProductVersionTabEvent = async (obj) => {
      if (!obj.versionInfo) {
        const payload = {
          vLabNoteCd: obj.vLabNoteCd,
          nVersion: obj.nVersion
        }
        const resultData = await selectLabNoteMstVerInfo(payload)

        obj.versionInfo = resultData
      }
    }

    const setRegisterParams = () => {
      const mstTagList = []
      const tuserList = marketing.value.regParams.tuserList
      const releaseASIAList = basic.value.releaseMap['ASIA'].countryList
      const releaseASEANList = basic.value.releaseMap['ASEAN'].countryList
      const releaseETCList = basic.value.releaseMap['ETC'].countryList

      const arrList = [tuserList, releaseASIAList, releaseASEANList, releaseETCList]

      for (const list of arrList) {
        if (list && list.length > 0) {
          for (const item of list) {
            if (commonUtils.isNotEmpty(item.vTag2Cd)) {
              mstTagList.push({ ...item })
            }
          }
        }
      }

      const lnc02List = mstTagList.filter(item => item.vMstCode === 'LNC02' && commonUtils.isNotEmpty(item.vTag2Cd))

      // [START] 양산일정 구하기
      const releaseDtList = []
      let vMassProdDt = ''
      if (lnc02List && lnc02List.length > 0) {
        lnc02List.forEach(item => {
          releaseDtList.push(Number(item.vTagBuffer1))
        })

        vMassProdDt = Math.min(...releaseDtList)
      }
      // [END] 양산일정 구하기

      const basicParams = basic.value.regParams
      const marketingParams = marketing.value.regParams

      regParams.value = {
        ...basicParams,
        ...marketingParams,
        mstTagList: mstTagList,
        vMassProdDt: String(vMassProdDt),
      }
    }

    const fnSave = async () => {
      const basicChkKey = ['vBrdCd', 'contList', 'vProdType1Cd', 'vProdType2Cd',
                            'releaseInfoASIA', 'releaseInfoASEAN', 'releaseInfoETC', 'vFlagNew', 'vPartCd']

      if (!basic.value.fnValidateAll(basicChkKey)) {
        await openAsyncAlert({ message: '필수 입력사항을 확인해 주세요.' })
        window.scrollTo(0, 0)
        return
      }

      setRegisterParams()
      const result = await updateReqPrdInfo(regParams.value)
      if (result === 'SUCC') {
        openAsyncAlert({ message: '수정되었습니다.' })
      }
    }

    const showModifyBtn = () => {
      let isVisible = false
      const arrStatusCd = ['LNC06_01', 'LNC06_02', 'LNC06_03', 'LNC06_04', 'LNC06_05', 'LNC06_06', 'LNC06_21', 'LNC06_22']
      if (reqInfo.value && arrStatusCd.indexOf(reqInfo.value.vStatusCd) > -1) {
        isVisible = true
      }

      return isVisible
    }

    const init = async () => {
      const vLabNoteCd = route.query.vLabNoteCd
      const result = await selectReqInfo({ vLabNoteCd })

      reqInfo.value = {...reqInfo.value, ...result}

      if (reqInfo.value.verList && reqInfo.value.verList.length > 0) {
        reqInfo.value.verList.some((item) => {
          if (Number(item.nVersion) === Number(reqInfo.value.versionInfo.nVersion)) {
            item.versionInfo = reqInfo.value.versionInfo
            return true
          }
        })
      }
    }

    init()
    provide('reqInfo', reqInfo)

    onMounted(() => {
      uiUtils.accordionEvent()
    })

    onUnmounted(() => {
      uiUtils.accordionEvent()
    })

    return {
      basic,
      product,
      marketing,
      reqInfo,
      fnSave,
      fnProductVersionTabEvent,
      showModifyBtn,
    }
  }
}
</script>

<style scoped>
  .ui-layout .contents-cell {
    width: inherit;
    margin: inherit;
  }

  .page-bottom {
    width: calc(100% - 1.4rem);
    margin: 0.7rem;
    box-sizing: border-box;
  }

  .page-bottom__inner {
    margin-top: inherit;
    margin-bottom: 1.4rem;
  }
</style>