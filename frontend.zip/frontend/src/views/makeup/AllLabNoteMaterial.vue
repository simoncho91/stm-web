<template>
  <div class="contents-core">
    <div class="contents-cell__wrap">
      <div class="contents-cell">
        <div class="contents-box contents-box__full">
          <div class="contents-box__inner p-0">
            <div class="page-tab m-0">
              <div class="page-tab__inner">
                <HistoryTab :v-lab-note-cd="reqInfo?.rvo?.vLabNoteCd"
                  url-link="/makeup/all-lab-note-{pageType}-material?vLabNoteCd="
                  :vIsMaterial="reqInfo?.contList?.length > 1 ? true : false" @go-list="goList()"
                  @onShowContList="onShowContList">
                </HistoryTab>

                <div class="page-tab__contents page-tab__contents--material">
                  <AllLabNoteMaterialCont @onContClick="onContClick"
                    :style="materialArrow.show ? '' : 'display: none;'" />

                  <div class="nav-comb">
                    <div class="nav-comb__inner">

                      <div class="nav">
                        <div class="nav__inner">
                          <div class="nav-title">원료배합</div>
                        </div>
                      </div>

                      <AllLabNoteMaterialTop @onTabClick="onTabClick" @onAddMateAndGrp="onAddMateAndGrp" />

                    </div>
                  </div>

                  <div class="page-tab__item">
                    <div class="page-tab__item--inner">
                      <div class="sub-contents__item">
                        <!-- 2023.04.07 : add : .sub-contents__title--material 추가 -->
                        <div class="sub-contents__title--flex sub-contents__title--material">
                          <div class="sub-contents__title">{{ reqInfo?.contVO?.vContNm }}</div>
                          <div v-if="reqInfo?.contVO?.vFlagRepresent === 'Y' && reqInfo?.verVO?.vCounterContPkCd"
                            class="sub-contents__title" style="margin-top: 5px;">
                            [{{ reqInfo?.verVO?.vCounterContCd }}] {{ reqInfo?.verVO.vCounterContNm }}
                          </div>
                        </div>

                        <AllLabNoteMaterialTable @onTabClick="onTabClick" @onVerNmChange="onVerNmChange"
                          @onLotClick="onLotClick" @onChangeRateList="onChangeRateList"
                          @onChangeMateList="onChangeMateList" @onAddMateAndGrp="onAddMateAndGrp"
                          @onIsChange="onIsChange" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <button type="button" class="button-caution"
            v-if="!commonUtils.isEmpty(reqInfo?.rvo) && reqInfo?.rvo?.vLabTypeCd === 'LNC07_01' && showIssueTrackBtn('MU', reqInfo.rvo)"
            @click="fnIssueTrackPop()">
          </button>
        </div>
      </div>
      <!-- end :: .contents-cell -->

      <AllLabNoteMaterialBottom @onPlantPrice="onTabClick" @onMaterialSave="onMaterialSave" @go-list="goList()" />

    </div>

    <teleport to="#common-modal" v-if="popupContent">
      <ap-popup>
        <component :is="popupContent" :pop-params="popParams" @selectFunc="popSelectFunc" />
      </ap-popup>
    </teleport>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, provide, inject, reactive } from 'vue'
import { onBeforeRouteLeave, useRoute, useRouter } from 'vue-router'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useMaterialCommon } from '@/compositions/labcommon/useMaterialCommon'
import { useCode } from '@/compositions/useCode'
import { useActions } from 'vuex-composition-helpers'
import { useStore } from 'vuex'
import mixmatUtils from '@/utils/mixmatUtils'

import AllLabNoteMaterialBottom from '@/components/labcommon/AllLabNoteMaterialBottom.vue'
import AllLabNoteMaterialCont from '@/components/labcommon/AllLabNoteMaterialCont.vue'
import AllLabNoteMaterialTable from '@/components/labcommon/AllLabNoteMaterialTable.vue'
import AllLabNoteMaterialTop from '@/components/labcommon/AllLabNoteMaterialTop.vue'
import HistoryTab from '@/components/labcommon/HistoryTab.vue'

export default {
  name: 'AllLabNoteMaterial',
  components: {
    AllLabNoteMaterialBottom,
    AllLabNoteMaterialCont,
    AllLabNoteMaterialTable,
    AllLabNoteMaterialTop,
    HistoryTab,
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    IssueTrackerPop: defineAsyncComponent(() => import('@/components/labcommon/popup/IssueTrackerPop.vue')),
  },
  setup() {
    const reqInfo = ref(null)
    const commonUtils = inject('commonUtils')
    const { openAsyncAlert, openAsyncConfirm } = useActions(['openAsyncAlert', 'openAsyncConfirm'])
    const route = useRoute()
    const router = useRouter()
    const store = useStore()
    const myInfo = store.getters.getMyInfo()
    const noteType = store.getters.getNoteType()
    const noteInfo = store.getters.getNoteInfo()

    const materialArrow = reactive({
      show: true,
    })

    const {
      fnSetRecentLog,
      fnChangeNoteInfo,
      selectIssueTrackerNoteInfo,
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
      showIssueTrackBtn,
    } = useLabCommon()

    const {
      selectMaterialFormulationInfo,
      selectElabLotMemoList,
      insertLabNoteList,
      selectMuQrMaterialFormulationInfo,
    } = useMaterialCommon()

    const {
      codeGroupMaps,
      findCodeList
    } = useCode()

    const init = async (nVersion = 0, vContPkCd = '') => {
      if (!codeGroupMaps.value?.MTI00) {
        findCodeList(['MTI00'])
      }

      const vLabNoteCd = route.query.vLabNoteCd
      const vFlagQrCode = route.query.vFlagQrCode || ''
      const vDivQrCode = route.query.vDivQrCode || ''
      const vQrCode = route.query.vQrCode || ''
      const vFlagRecentNotes = route.query.vFlagRecentNotes || 'Y'

      if (!vLabNoteCd && vFlagQrCode !== 'Y') {
        openAsyncAlert({ message: '잘못된 접근입니다.' })
        router.push({ path: '/makeup/my-board' })
        return
      }

      const params = {
        vLabNoteCd,
        nVersion,
        vContPkCd,
        vFlagQrCode,
        vDivQrCode,
        vQrCode,
      }
      if (vFlagQrCode == "Y") {
        reqInfo.value = await selectMuQrMaterialFormulationInfo(params)
      } else {
        reqInfo.value = await selectMaterialFormulationInfo(params)
      }

      if (reqInfo.value.constructor !== Object) {
        openAsyncAlert({ message: reqInfo.value })
        router.push({ path: '/makeup/my-board' })
        return
      }

      if (!noteInfo) {
        fnChangeNoteInfo(reqInfo.value.rvo)
      }

      reqInfo.value.contVO.vNoteType = noteType
      reqInfo.value.contVO.vPageType = reqInfo.value.rvo.vLabTypePrdCd === 'HAL4' ? 'half' : reqInfo.value.rvo.vLabTypePrdCd.toLowerCase()

      if (vFlagRecentNotes === 'Y' && reqInfo.value.contVO.vFlagRepresent === 'Y') {
        const data = {
          vNoteType: noteType,
          vLabNoteCd: reqInfo.value.contVO.vLabNoteCd,
          vContCd: reqInfo.value.contVO.vContCd,
          vContNm: reqInfo.value.contVO.vContNm,
          vPageType: reqInfo.value.contVO.vPageType,
        }
        fnSetRecentLog(data)
      }

      reqInfo.value.isChange = false
      reqInfo.value.testCdList = commonUtils.getCodeList(codeGroupMaps, 'MTI00', null, null, null)

      let newRateList = [...reqInfo.value.rateList]
      reqInfo.value.mateList.filter(mate => mate.vMatePkCd).map(mate => {
        reqInfo.value.lotList.map(lot => {
          if (lot.rateList.filter(rate => rate.vMatePkCd === mate.vMatePkCd).length === 0) {
            newRateList.push({
              vMatePkCd: mate.vMatePkCd,
              vLotCd: lot.vLotCd,
              vKey: lot.vLotCd + '_' + mate.vMatePkCd,
              vFlagRateRest: 'N',
            })
          }
        })
      })
      reqInfo.value.rateList = newRateList

      const grpHideList = reqInfo.value.mateList.filter(mate => mate.vRecType === 'GRP' && mate.vFlagGrpHide === 'Y')
      reqInfo.value.mateList = reqInfo.value.mateList.map(mate => {
        return {
          ...mate,
          vFlagMateHide: mate.vFlagMateHide === 'Y' ? 'Y' : grpHideList.filter(o => o.vGrpCd === mate.vGrpCd).length > 0 ? 'Y' : 'N',
          mateIssue: mixmatUtils.getMateTag(
            mate,
            reqInfo.value.contVO.vLand1,
            reqInfo.value.mstSetVO.find(set => set.vColumnSetCd === 'COLUMN08')?.vFlagHide,
            noteType,
          ),
          vFlagColorMate: mixmatUtils.getCheckToningMate(mate) ? 'Y' : mate.vFlagColorMate,
        }
      })

      if (reqInfo.value.mateList.length < 15) {
        const tmpMateList = []
        const copyLen = reqInfo.value.mateList.length
        for (let i = 0; i < 15 - copyLen; i++) {
          tmpMateList.push({
            vMatePkCd: 'tmp_mate_pk_cd_' + (copyLen + i + 1),
          })
        }

        reqInfo.value.mateList = [
          ...reqInfo.value.mateList,
          ...tmpMateList,
        ]
      }

      let activeBFIndex = -1
      let defaultLotIndex = 0

      reqInfo.value.lotList.map((lot, lotIndex) => {
        if (lot.rateList.filter(rate => rate.nRate && rate.nRate >= 0).length > 0) {
          defaultLotIndex = lotIndex
        }
      })

      reqInfo.value.lotList = reqInfo.value.lotList.map((lot, lotIndex) => {
        const vIsLotSelect = lotIndex === defaultLotIndex ? true : false
        if (vIsLotSelect) {
          activeBFIndex = lotIndex - 1
        }

        const newRateList = [...lot.rateList]
        reqInfo.value.rateList.filter(rate => rate.vLotCd === lot.vLotCd).map(rate => {
          if (newRateList.filter(_rate => _rate.vLotCd === rate.vLotCd && _rate.vMatePkCd === rate.vMatePkCd).length === 0) {
            newRateList.push(rate)
          }
        })

        return {
          ...lot,
          vIsLotSelect,
          activeYn: vIsLotSelect ? 'Y' : 'N',
          openYn: vIsLotSelect && lot.vLotCd.indexOf('tmp_lot_') < 0 ? 'Y' : 'N',
          borderClass: null,
          grams: mixmatUtils.getGrams(lot),
          sumPrice: reqInfo.value.matePriceList.find(sum => sum.vLotCd === lot.vLotCd)?.nMatePriceSum || 0,
          rateList: newRateList,
          nLotCircle: mixmatUtils.getLotCircle(lot.vTumnTsntLotStCd),
        }
      })

      if (reqInfo.value.lotList.length > 0 && reqInfo.value.lotList.length < 6) {
        const tmpLotList = []
        const copyLen = reqInfo.value.lotList.length
        const copyObj = reqInfo.value.lotList[0]
        for (let i = 0; i < 6 - copyLen; i++) {
          const nSort = (i + 1) + copyLen
          tmpLotList.push({
            ...copyObj,
            vLabNoteCd: reqInfo.value.contVO.vLabNoteCd,
            vContPkCd: reqInfo.value.contVO.vContPkCd,
            nVersion: reqInfo.value.verVO.nVersion,
            vLotCd: 'tmp_lot_' + nSort,
            vLotNm: 'Lot #0' + nSort,
            nSort,
            vLotMemo: null,
            vFlagComplete: 'N',
            nGram1: null,
            nGram2: null,
            nGram3: null,
            nGram4: null,
            nGram5: null,
            nGram6: null,
            nGram7: null,
            nGram8: null,
            nGram9: null,
            nGram10: null,
            vIsLotSelect: false,
            activeYn: 'N',
            openYn: 'N',
            grams: [{
              vLotCd: 'tmp_lot_' + nSort,
              nGram: null,
              gramSeq: 'tmp_lot_' + nSort,
            }],
            sumPrice: 0,
            rateList: [
              ...copyObj.rateList.map(rate => {
                return {
                  ...rate,
                  vLotCd: 'tmp_lot_' + nSort,
                  vKey: 'tmp_lot_' + nSort + '_' + (rate.vMatePkCd || 'SUM'),
                  nRate: null,
                  nMateGram1: null,
                  nMateGram2: null,
                  nMateGram3: null,
                  nMateGram4: null,
                  nMateGram5: null,
                  nMateGram6: null,
                  nMateGram7: null,
                  nMateGram8: null,
                  nMateGram9: null,
                  nMateGram10: null,
                  vFlagRateRest: 'N',
                  vHal4LotCd: null,
                  vHal4LotNm: null,
                  vHal4VersionNm: null,
                  vHal4VersionTxt: null,
                  vMateDbLotInfoTxt: null,
                }
              })
            ],
          })
        }

        reqInfo.value.lotList = [
          ...reqInfo.value.lotList,
          ...tmpLotList,
        ]
      }

      reqInfo.value.lotList.map(async lot => {
        if (lot.openYn === 'Y') {
          const response = await selectElabLotMemoList({ vLotCd: lot.vLotCd })
          lot.sideList = response.map(side => {
            return {
              ...side,
              isClick: side.vFlagSave === 'Y',
            }
          })
        }
      })

      if (activeBFIndex > -1) {
        for (let i = activeBFIndex; i >= 0; i--) {
          if (reqInfo.value.lotList[i].vFlagExposure === 'Y') {
            activeBFIndex = i
            break;
          }
        }
        reqInfo.value.lotList[activeBFIndex].borderClass = 'border-right__blue'
      }

      reqInfo.value.columnsForzenLeft = mixmatUtils.getColums(
        reqInfo.value.mstSetVO.filter((col) => col.vColumn && col.vFlagHide === 'N'),
        reqInfo.value.contVO.vFlagRepresent === 'N'
      )
      reqInfo.value.rowsForzen = mixmatUtils.getFooterRows(
        reqInfo.value.mstSetVO.filter((col) => !col.vColumn || col.vColumnSetCd === 'COLUMN05' || col.vColumnSetCd === 'COLUMN06'))
    }

    const onTabClick = async (o = -1) => {
      // if (!await changeValidation()) {
      //   init(o)
      // }
      onContClick(o, reqInfo.value.contVO.vContPkCd)
    }

    const onContClick = async (nVersion, vContPkCd) => {
      if (!await changeValidation()) {
        init(nVersion, vContPkCd)
      }
    }

    const onVerNmChange = (o) => {
      reqInfo.value.verList = o
    }

    const onAddMateAndGrp = (o, isPaste = false, isDrag = false) => {
      let newMateList = []
      let newMateListLen = 0
      let grpCnt = 0

      if (isPaste) {
        const { gridVars } = mixmatUtils.opts
        const { cellData } = gridVars.focusCell
        let rowIndex = cellData?.rowIndex
        const pasteMateList = []

        newMateList = [...reqInfo.value.mateList]
        newMateListLen = newMateList.length

        let dragIdx = 0
        if (isDrag) {
          rowIndex = null

          for (let i = 0; i < gridVars.materials.length; i++) {
            const mate = gridVars.materials[i]
            if (!mate.nMateNum) {
              dragIdx = i
              break
            }
          }
        }

        newMateList.map((nMate, mIdx) => {
          if ((isDrag && mIdx === dragIdx) || mIdx === rowIndex) {
            o.map((mate, idx) => {
              if (mate.vRecType === 'GRP') {
                grpCnt++
              }

              const mateLen = (newMateListLen + idx + 1) - grpCnt

              pasteMateList.push({
                ...mate,
                vMatePkCd: mate.vRecType !== 'GRP' ? 'add_mate_pk_cd_' + mateLen : null,
                vOriMatePkCd: mate.vMatePkCd,
                vLabNoteCd: reqInfo.value.contVO.vLabNoteCd,
                vContPkCd: reqInfo.value.contVO.vContPkCd,
                nVersion: reqInfo.value.verVO.nVersion,
                mateIssue: mixmatUtils.getMateTag(
                  mate,
                  reqInfo.value.contVO.vLand1,
                  reqInfo.value.mstSetVO.find(set => set.vColumnSetCd === 'COLUMN08')?.vFlagHide,
                  noteType,
                ),
                vFlagColorMate: mixmatUtils.getCheckToningMate(mate) ? 'Y' : mate.vFlagColorMate,
              })
            })
          }

          pasteMateList.push(nMate)
        })

        newMateList = pasteMateList
      }
      else {
        newMateList = [...reqInfo.value.mateList.filter(mate => mate.vRecType === 'GRP' || mate.vMatePkCd.indexOf('tmp_mate_pk_cd') < 0)]
        newMateListLen = newMateList.length

        newMateList = [
          ...newMateList,
          ...o.map((mate, idx) => {
            if (mate.vRecType === 'GRP') {
              grpCnt++
            }

            const mateLen = (newMateListLen + idx + 1) - grpCnt

            return {
              ...mate,
              vMatePkCd: mate.vRecType !== 'GRP' ? 'add_mate_pk_cd_' + mateLen : null,
              vOriMatePkCd: mate.vMatePkCd,
              vLabNoteCd: reqInfo.value.contVO.vLabNoteCd,
              vContPkCd: reqInfo.value.contVO.vContPkCd,
              nVersion: reqInfo.value.verVO.nVersion,
              mateIssue: mixmatUtils.getMateTag(
                mate,
                reqInfo.value.contVO.vLand1,
                reqInfo.value.mstSetVO.find(set => set.vColumnSetCd === 'COLUMN08')?.vFlagHide,
                noteType,
              ),
              vFlagColorMate: mixmatUtils.getCheckToningMate(mate) ? 'Y' : mate.vFlagColorMate,
            }
          }),
        ]
      }

      if (newMateList.length < 15) {
        const copyLen = newMateList.length
        for (let i = 0; i < 15 - copyLen; i++) {
          newMateList.push({
            vMatePkCd: 'tmp_mate_pk_cd_' + (i + 1),
          })
        }
      }

      let newRateList = []
      const newLotList = reqInfo.value.lotList.map((lot) => {
        newRateList = o.filter(mate => mate.vRecType !== 'GRP').map((mate, idx) => {
          const vMatePkCd = 'add_mate_pk_cd_' + (newMateListLen + idx + 1)
          return {
            vMatePkCd,
            vLotCd: lot.vLotCd,
            vKey: lot.vLotCd + '_' + vMatePkCd,
            nRate: mate.nRate,
            vFlagSave: 'Y',
          }
        })

        const copyRateList = newRateList.map(rate => {
          return {
            ...rate,
            nRate: null,
            vFlagSave: 'N',
            nMateGram1: null,
            nMateGram2: null,
            nMateGram3: null,
            nMateGram4: null,
            nMateGram5: null,
            nMateGram6: null,
            nMateGram7: null,
            nMateGram8: null,
            nMateGram9: null,
            nMateGram10: null,
          }
        })

        if (lot.vIsLotSelect) {
          onChangeRateList([...lot.rateList, ...newRateList])
        }

        return {
          ...lot,
          rateList: lot.vIsLotSelect ? [...lot.rateList, ...newRateList] : [...lot.rateList, ...copyRateList],
        }
      })

      reqInfo.value = {
        ...reqInfo.value,
        mateList: newMateList,
        lotList: newLotList,
      }
    }

    const onLotClick = (mateList, lotList) => {
      reqInfo.value = {
        ...reqInfo.value,
        mateList,
        lotList,
      }
    }

    const onChangeRateList = (o, isCopy = true) => {
      let copyList = []
      if (isCopy) {
        copyList = reqInfo.value.rateList
          .filter(rate => rate.vKey.indexOf('_SUM') < 0 && rate.vLotCd !== o?.[0]?.vLotCd)
          .map(rate => {
            return rate
          })
      }

      reqInfo.value = {
        ...reqInfo.value,
        rateList: [
          ...copyList,
          ...o,
        ],
      }
    }

    const onChangeMateList = (mateList, delMatePkCdList = [], delGrpCdList = []) => {
      reqInfo.value = {
        ...reqInfo.value,
        mateList,
        delMatePkCdList: getInitListData(reqInfo.value.delMatePkCdList, delMatePkCdList.filter(
          del => del.indexOf('tmp_mate_pk_cd_') < 0 && del.indexOf('add_mate_pk_cd_') < 0)),
        delGrpCdList: getInitListData(reqInfo.value.delGrpCdList, delGrpCdList.filter(del => del.indexOf('temp_grp_') < 0)),
      }
    }

    const getInitListData = (o1, o2) => {
      if (!o1 && !o2) {
        return []
      }
      else if (!o1) {
        return [...o2]
      }
      else if (!o2) {
        return [...o1]
      }
      else {
        return [...o1, ...o2]
      }
    }

    const onMaterialSave = async () => {
      const vLabNoteCd = reqInfo.value.contVO.vLabNoteCd
      const vContPkCd = reqInfo.value.contVO.vContPkCd
      const nVersion = reqInfo.value.verVO.nVersion
      const vPlantCd = reqInfo.value.contVO.vPlantCd
      const vLand1 = reqInfo.value.contVO.vLand1
      const vStatusCd = reqInfo.value.rvo.vStatusCd
      const vSiteType = reqInfo.value.rvo.vSiteType
      const vContCd = reqInfo.value.contVO.vContCd || ''
      const vContNm = reqInfo.value.contVO.vContNm
      const vMoveUrl = `/makeup/all-lab-note-${reqInfo.value.contVO.vPageType}-material?vLabNoteCd=${vLabNoteCd}`
      const delGrpCdList = reqInfo.value.delGrpCdList
      const delMatePkCdList = reqInfo.value.delMatePkCdList
      const copyMateList = [...reqInfo.value.mateList]
      const copyLotList = [...reqInfo.value.lotList]

      const groupList = []
      const mateList = []

      copyMateList.map((mate, index) => {
        if (mate.vRecType === 'GRP') {
          groupList.push({
            ...mate,
            vLabNoteCd,
            vContPkCd,
            nVersion,
            nSort: index + 1
          })
        }
        else if (mate.vRecType !== 'GRP' && mate.vMatePkCd.indexOf('tmp_mate_pk_cd_') < 0 && !mate.vParentMatePkCd) {
          mateList.push({
            ...mate,
            nSort: index + 1
          })
        }
      })

      const lotList = copyLotList.map(lot => {
        lot.vLabNoteCd = vLabNoteCd
        lot.vContPkCd = vContPkCd
        lot.nVersion = nVersion

        if (!lot.nGramOpenNum || lot.nGramOpenNum === 0) {
          lot.nGramOpenNum = (lot.grams?.length || 1)
        }

        lot.gramList = [
          ...lot.grams.map((gram, gIdx) => {
            return {
              ...gram,
              vGramCd: gram.gramSeq.indexOf('tmp_gram_') > -1 ? (gram.nGram > 0 ? null : gram.gramSeq) : gram.gramSeq,
              nGram: gram.nGram || null,
              nSort: gIdx + 1,
            }
          })
        ]
        lot.rateList = lot.rateList.filter(rate => rate.vKey.indexOf('_SUM') < 0 && !rate.vParentMatePkCd)
        return lot
      })

      await insertLabNoteList({
        vLabNoteCd,
        vContPkCd,
        nVersion,
        vPlantCd,
        vLand1,
        vStatusCd,
        vSiteType,
        vContCd,
        vContNm,
        vMoveUrl,
        delGrpCdList,
        groupList,
        delMatePkCdList,
        mateList,
        lotList,
        versionDTO: {
          vContPkCd,
          nVersion,
          vFlagPriceHide: reqInfo.value.verVO.vFlagPriceHide || 'N',
          vFlagMaxmixHide: reqInfo.value.verVO.vFlagMaxmixHide || 'N',
          vFlagReqHide: reqInfo.value.verVO.vFlagReqHide || 'N',
          vFlagExistHide: reqInfo.value.verVO.vFlagExistHide || 'N',
          vFlagInpMethod: reqInfo.value.verVO.vFlagInpMethod || 'Y',
          vCounterCd: reqInfo.value.verVO.vCounterCd || null,
          vCounterContPkCd: reqInfo.value.verVO.vCounterContPkCd || null,
          vVersionNm: reqInfo.value.verList.find(ver => ver.nVersion === nVersion).vVersionTxt,
        },
      })

      reqInfo.value.isChange = false

      onContClick(nVersion, vContPkCd)
    }

    const onIsChange = () => {
      reqInfo.value.isChange = true
    }

    const goList = () => {
      router.push({ path: `/makeup/all-lab-note-${reqInfo.value.contVO.vPageType}-list` })
    }

    const onShowContList = (o) => {
      materialArrow.show = o
    }

    init(-1)
    provide('reqInfo', reqInfo)

    onBeforeRouteLeave(async (to, from) => {
      await changeValidation()
    })

    const changeValidation = async () => {
      if (!reqInfo.value) {
        return
      }

      if (reqInfo.value.isChange && mixmatUtils.getBtnShow('CHANGE_SAVE', null, reqInfo.value)) {
        const answer = await openAsyncConfirm({
          message: '변경 내용이 있습니다.<br/>저장하지 않고 진행시 변경된 내용이 저장되지 않습니다.<br/><br/>저장 하시겠습니까?',
          confirmOk: '저장 후 이동',
          confirmCancel: '그냥 이동',
        })

        if (answer) {
          reqInfo.value.isChange = false
          await onMaterialSave()
          return true
        }
      }

      return false
    }

    const fnIssueTrackPop = async () => {

      const result = await selectIssueTrackerNoteInfo({ vLabNoteCd: reqInfo.value.rvo.vLabNoteCd })
      popParams.value = {
        vLabNoteCd: reqInfo.value.rvo.vLabNoteCd,
        noteInfo: result,
        vNoteType: noteType
      }

      fnOpenPopup('IssueTrackerPop', false)
    }

    return {
      commonUtils,
      reqInfo,
      materialArrow,
      onTabClick,
      onContClick,
      onVerNmChange,
      onAddMateAndGrp,
      onLotClick,
      onChangeRateList,
      onChangeMateList,
      onMaterialSave,
      onIsChange,
      goList,
      onShowContList,
      showIssueTrackBtn,
      fnIssueTrackPop,
      popupContent,
      popParams,
      popSelectFunc,
    }
  },
}
</script>
