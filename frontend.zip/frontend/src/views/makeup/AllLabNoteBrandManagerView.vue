<template>
  <div>
    <div class="page-tab multi-cont-view-page">
      <div class="page-tab__inner">
        <HistoryTab
          v-if="reqInfo && commonUtils.isNotEmpty(reqInfo.vContCd)"
          :v-lab-note-cd="vLabNoteCd"
          url-link="/makeup/all-lab-note-{pageType}-view?vLabNoteCd="
          @go-list="goList()"
        >
        </HistoryTab>

        <div class="page-tab__contents multi-cont-view-contents">
          <ap-breadcrumb
            nav-title="내용물 개요"
            :path-list="pathList"
          >
          </ap-breadcrumb>

          <div class="page-tab__item">
            <AllLabNoteBrandManagerBasicInfoView></AllLabNoteBrandManagerBasicInfoView>
          </div>
        </div>
      </div>
    </div>

    <div class="contents-core">
      <div class="contents-cell__wrap">
        <div class="contents-cell">
          <div class="contents-box contents-box__full">
            <div class="contents-box__inner min-height__unset border-top-radius__unset">
              <MakeupContInfoView></MakeupContInfoView>
            </div>
          </div>

          <div class="contents-box contents-box__full">
            <div class="contents-box__inner min-height__unset">
              <AllLabNoteBrandManagerMarketingInfoView></AllLabNoteBrandManagerMarketingInfoView>
            </div>
          </div>

          <div class="contents-box contents-box__full">
            <div class="contents-box__inner min-height__unset">
              <div class="arrordion-item is-active">
                <div class="arrordion-header">
                  <div class="arrordion-title">제품 정보</div>
                  <button type="button" class="ui-button__accordion"></button>
                </div>
                <div class="arrordion-body">
                  <div class="detail-tab ap_contents_tab">
                    <div class="ver_tab_area" v-if="reqInfo && reqInfo.verList && reqInfo.verList.length > 0">
                      <ApTab
                        mst-id="productVersion"
                        :tab-list="reqInfo.verList"
                        tab-id-key="vVersionKey"
                        tab-nm-key="vVersionTxt"
                        :tab-style="['detail-tab__inner', 'ui-list detail-tab__lists', 'detail-tab__list', 'detail-tab__link']"
                        :default-tab="reqInfo.verList[reqInfo.verList.length - 1].vVersionKey"
                        @click="fnProductVersionTabEvent"
                      >
                      </ApTab>
                    </div>
                    <template v-if="reqInfo && reqInfo.verList && reqInfo.verList.length > 0">
                      <div class="contents-tab__body"
                        v-for="(item, index) in reqInfo.verList"
                        :key="'version_area_' + index"
                        :id="item.vVersionKey"
                      >
                        <AllLabNoteBrandManagerProductInfoView
                          v-if="item.versionInfo"
                          :version-info="item.versionInfo"
                        >
                        </AllLabNoteBrandManagerProductInfoView>
                      </div>
                    </template>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="page-bottom">
        <div class="page-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--skyblue" v-if="showModifyBtn()" @click="goModify()">수정</button>
            <button type="button" class="ui-button ui-button__border--gray" @click="goList()">목록</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, onMounted, onUnmounted, ref, provide, inject } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useMakeupBMRegister } from '@/compositions/makeup/useMakeupBMRegister'
import { useMakeupRequest } from '@/compositions/makeup/useMakeupRequest'
import uiUtils from '@/utils/uiUtils'
import AllLabNoteBrandManagerBasicInfoView from '@/components/makeup/AllLabNoteBrandManagerBasicInfoView.vue'
import AllLabNoteBrandManagerMarketingInfoView from '@/components/makeup/AllLabNoteBrandManagerMarketingInfoView.vue'
import MakeupContInfoView from '@/components/makeup/MakeupContInfoView.vue'
export default {
  name: 'AllLabNoteBrandManagerView',
  components: {
    AllLabNoteBrandManagerBasicInfoView,
    AllLabNoteBrandManagerMarketingInfoView,
    MakeupContInfoView,
    AllLabNoteBrandManagerProductInfoView: defineAsyncComponent(() => import('@/components/makeup/AllLabNoteBrandManagerProductInfoView.vue')),
    HistoryTab: defineAsyncComponent(() => import('@/components/labcommon/HistoryTab.vue')),
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
  },
  setup () {
    const reqInfo = ref({})
    const router = useRouter()
    const route = useRoute()
    const commonUtils = inject('commonUtils')

    const {
      selectReqInfo,
    } = useMakeupBMRegister()

    const {
      goList,
    } = useMakeupRequest()

    const showModifyBtn = () => {
      let isVisible = false
      const arrStatusCd = ['LNC06_01', 'LNC06_21', 'LNC06_22']
      if (reqInfo.value && arrStatusCd.indexOf(reqInfo.value.vStatusCd) > -1) {
        isVisible = true
      }

      return isVisible
    }

    const goModify = () => {
      router.push({ path: '/makeup/all-lab-note-brand-manager-register', query: {vLabNoteCd: route.query.vLabNoteCd} })
    }

    const init = async () => {
      const vLabNoteCd = route.query.vLabNoteCd
      const result = await selectReqInfo({ vLabNoteCd })

      reqInfo.value = {...reqInfo.value, ...result}

      if (reqInfo.value.verList && reqInfo.value.verList.length > 0) {
        reqInfo.value.verList.some((item) => {
          if (Number(item.nVersion) === Number(reqInfo.value.versionInfo.nVersion)) {
            item.versionInfo = reqInfo.value.versionInfo
            return true
          }
        })
      }
    }

    init()
    provide('reqInfo', reqInfo)

    onMounted(() => {
      uiUtils.accordionEvent()
    })

    onUnmounted(() => {
      uiUtils.accordionEvent()
    })

    return {
      commonUtils,
      reqInfo,
      showModifyBtn,
      goModify,
      goList,
    }
  }
}

</script>