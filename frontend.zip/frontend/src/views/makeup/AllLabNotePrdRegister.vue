<template>
  <ap-breadcrumb
    nav-title="All lab notes"
    :path-list="pathList"
  >
  </ap-breadcrumb>

  <div class="contents-core">
    <div class="contents-cell__wrap">
      <!-- 내용물 개요 -->
      <div class="contents-cell flex-none">
        <div class="contents-box contents-box__full">
          <div class="contents-box__inner min-height__unset">
            <AllLabNoteMakeupBasicInfoRegister
              ref="basic"
              :flag-action="flagAction"
            >
            </AllLabNoteMakeupBasicInfoRegister>
          </div>
        </div>
      </div>

      <!-- 연구원 정보 -->
      <div class="contents-cell flex-none">
        <div class="contents-box contents-box__full">
          <div class="contents-box__inner min-height__unset">
            <AllLabNoteMakeupResearcherInfoRegister
              ref="researcher"
              :flag-action="flagAction"
            >
            </AllLabNoteMakeupResearcherInfoRegister>
          </div>
        </div>
      </div>

      <!-- 마케팅 정보 -->
      <div class="contents-cell flex-none">
        <div class="contents-box contents-box__full">
          <div class="contents-box__inner min-height__unset">
            <AllLabNoteMakeupMarketingInfoRegister
              ref="marketing"
            >
            </AllLabNoteMakeupMarketingInfoRegister>
          </div>
        </div>
      </div>

      <!-- 제품 정보 -->
      <div class="contents-cell flex-none">
        <div class="contents-box contents-box__full">
          <div class="contents-box__inner min-height__unset">
            <div class="arrordion-item is-active">
              <div class="arrordion-header">
                <div class="arrordion-title">제품 정보</div>
                <button type="button" class="ui-button__accordion"></button>
              </div>
              <div class="arrordion-body">
                <div class="detail-tab ap_contents_tab">
                  <div class="ver_tab_area" v-if="reqInfo && reqInfo.verList && reqInfo.verList.length > 0">
                    <ApTab
                      mst-id="productVersion"
                      :tab-list="reqInfo.verList"
                      tab-id-key="vVersionKey"
                      tab-nm-key="vVersionTxt"
                      :tab-style="['detail-tab__inner', 'ui-list detail-tab__lists', 'detail-tab__list', 'detail-tab__link']"
                      :default-tab="reqInfo.verList[reqInfo.verList.length - 1].vVersionKey"
                      @click="fnProductVersionTabEvent"
                    >
                    </ApTab>
                    <button
                      v-if="showAddVerBtn(reqInfo)"
                      type="button"
                      class="detail-tab__button--plus add_btn"
                      :class="addVerFlag === 'Y' ? 'active' : ''"
                      @click="fnAddVersion()"
                    >
                    </button>
                  </div>
                  <template v-if="reqInfo && reqInfo.verList && reqInfo.verList.length > 0 && addVerFlag !== 'Y'">
                    <div class="contents-tab__body"
                      v-for="(item, index) in reqInfo.verList"
                      :key="'version_area_' + index"
                      :id="item.vVersionKey"
                    >
                      <template v-if="currentVersion === Number(item.nVersion)">
                        <AllLabNoteMakeupProductInfoView
                          v-if="item.vFlagModify === 'N' && item.versionInfo"
                          :version-info="item.versionInfo"
                        >
                        </AllLabNoteMakeupProductInfoView>
                        <AllLabNoteMakeupProductInfoRegister
                          v-if="item.vFlagModify === 'Y'"
                          ref="product"
                          :version-info="item.versionInfo"
                        >
                        </AllLabNoteMakeupProductInfoRegister>
                      </template>
                    </div>
                  </template>
                  <template v-else>
                    <AllLabNoteMakeupProductInfoRegister
                      ref="product"
                    >
                    </AllLabNoteMakeupProductInfoRegister>
                  </template>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="page-bottom">
        <div class="page-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button type="button" class="ui-button ui-button__border--blue" v-if="addVerFlag === 'Y'" @click="fnSave('Y')">버전 추가 저장</button>
            <button type="button" class="ui-button ui-button__border--blue" v-if="commonUtils.isEmpty(reqInfo.vStatusCd) || reqInfo.vStatusCd === 'LNC06_01'" @click="fnTempSave()">임시저장</button>
            <button type="button" class="ui-button ui-button__bg--skyblue" v-if="addVerFlag !== 'Y'" @click="fnSave('N')">
              {{ commonUtils.isEmpty(reqInfo.vStatusCd) || reqInfo.vStatusCd === 'LNC06_01' ? '개발시작' : '수정' }}
            </button>
            <button type="button" class="ui-button ui-button__border--gray" @click="goList()">목록</button>
          </div>
        </div>
      </div>

    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, onMounted, ref, provide, inject, onUnmounted } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useRoute } from 'vue-router'
import { useStore } from 'vuex'
import { useMakeupRequest } from '@/compositions/makeup/useMakeupRequest'
import { useRequestCommon } from '@/compositions/labcommon/useRequestCommon'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import uiUtils from '@/utils/uiUtils'
import AllLabNoteMakeupBasicInfoRegister from '@/components/makeup/AllLabNoteMakeupBasicInfoRegister.vue'
import AllLabNoteMakeupResearcherInfoRegister from '@/components/makeup/AllLabNoteMakeupResearcherInfoRegister.vue'
import AllLabNoteMakeupMarketingInfoRegister from '@/components/makeup/AllLabNoteMakeupMarketingInfoRegister.vue'
import AllLabNoteMakeupProductInfoRegister from '@/components/makeup/AllLabNoteMakeupProductInfoRegister.vue'
import AllLabNoteMakeupProductInfoView from '@/components/makeup/AllLabNoteMakeupProductInfoView.vue'

export default {
  name: 'AllLabNoteRegister',
  components: {
    AllLabNoteMakeupBasicInfoRegister,
    AllLabNoteMakeupResearcherInfoRegister,
    AllLabNoteMakeupMarketingInfoRegister,
    AllLabNoteMakeupProductInfoRegister,
    AllLabNoteMakeupProductInfoView,
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
  },
  setup () {
    const commonUtils = inject('commonUtils')
    const basic = ref(null)
    const product = ref(null)
    const marketing = ref(null)
    const researcher = ref(null)
    const reqInfo = ref({
      vFlagNotAdd: 'N',
      vNotAddNote: '',
    })
    const flagAction = ref('R')
    const addVerFlag = ref('')
    const { openAsyncAlert } = useActions(['openAsyncAlert'])
    const route = useRoute()
    const store = useStore()
    const regParams = ref({})
    const currentVersion = ref(null)

    const pathList = [
      { path: '/makeup/all-lab-note-prd-register', pathNm: 'ALL LAB NOTES' }
    ]

    const {
      selectReqInfo,
      saveLabNoteRequest,
      goList,
      goView,
    } = useMakeupRequest()

    const {
      selectLabNoteMstVerInfo,
    } = useRequestCommon()

    const {
      showAddVerBtn,
    } = useLabCommon()

    const fnProductVersionTabEvent = async (obj) => {
      addVerFlag.value = ''
      currentVersion.value = Number(obj.nVersion)
      if (!obj.versionInfo) {
        const payload = {
          vLabNoteCd: obj.vLabNoteCd,
          nVersion: obj.nVersion
        }
        const resultData = await selectLabNoteMstVerInfo(payload)
        const funcMateList = resultData.funcMateList

        if (funcMateList && funcMateList.length > 0) {
          funcMateList.forEach(item => {
            if (item.vFlagRequired === 'Y') {
              item.vFlagTo100 = ''
            }
          })
        }

        obj.versionInfo = resultData
      }
    }

    const fnAddVersion = () => {
      addVerFlag.value = 'Y'

      const tabWrap = document.querySelector('#productVersion')
      const isActive = tabWrap.querySelector('.ap_li_tab_item.is-active')
      if (isActive) {
        isActive.classList.remove('is-active')
      }
    }

    const setRegisterParams = () => {
      const mstTagList = []
      const mti01List = marketing.value.regParams.mti01List
      const effectList = marketing.value.regParams.effectList
      const tuserList = marketing.value.regParams.tuserList
      const reqEtcList = marketing.value.regParams.reqEtcList
      const mtr04List = marketing.value.notAdd.mtr04List
      const mtr05List = marketing.value.notAdd.mtr05List
      const mtr06List = marketing.value.notAdd.mtr06List
      const releaseASIAList = basic.value.releaseMap['ASIA'].countryList
      const releaseASEANList = basic.value.releaseMap['ASEAN'].countryList
      const releaseETCList = basic.value.releaseMap['ETC'].countryList

      const arrList = [mti01List, effectList, tuserList, reqEtcList, 
                      releaseASIAList, releaseASEANList, releaseETCList]

      if (marketing.value.regParams.vFlagNotAdd === 'Y') {
        arrList.push(mtr04List)
        arrList.push(mtr05List)
        arrList.push(mtr06List)
      } else {
        marketing.value.regParams.vNotAddNote = ''
      }

      for (const list of arrList) {
        if (list && list.length > 0) {
          for (const item of list) {
            if (commonUtils.isNotEmpty(item.vTag2Cd)) {
              mstTagList.push({ ...item })
            }
          }
        }
      }

      const lnc02List = mstTagList.filter(item => item.vMstCode === 'LNC02' && commonUtils.isNotEmpty(item.vTag2Cd))

      // [START] 양산일정 구하기
      const releaseDtList = []
      let vMassProdDt = ''
      if (lnc02List && lnc02List.length > 0) {
        lnc02List.forEach(item => {
          releaseDtList.push(Number(item.vTagBuffer1))
        })

        vMassProdDt = Math.min(...releaseDtList)
      }
      // [END] 양산일정 구하기

      const basicParams = basic.value.regParams
      const fileList = basic.value.uploadParams.items

      const marketingParams = marketing.value.regParams
      const researcherParams = researcher.value.regParams
      let productVerParams = null
      let flagFuncTest = ''

      if (product.value) {
        if (product.value.verParams) {
          productVerParams = product.value.verParams
          const funcList = productVerParams.funcList

          funcList.some(item => {
            if (commonUtils.isNotEmpty(item.vTag2Cd)) {
              flagFuncTest = 'Y'
              return true
            }
          })
        } else if (product.value[0] && product.value[0].verParams) {
          productVerParams = product.value[0].verParams
          const funcList = productVerParams.funcList

          funcList.some(item => {
            if (commonUtils.isNotEmpty(item.vTag2Cd)) {
              flagFuncTest = 'Y'
              return true
            }
          })
        }
      }

      if (basicParams && basicParams.contList?.length > 0) {
        const representInfo = basicParams.contList.filter(cont => cont.vFlagRepresent === 'Y')
        if (representInfo) {
          basicParams.vContNm = representInfo[0].vContNm
        }
      }

      const vFlagNonPrd = route.query.vFlagNonPrd

      regParams.value = { ...basicParams,
                        ...marketingParams,
                        ...researcherParams,
                        flagAction: flagAction.value,
                        fileList: fileList,
                        mstTagList: mstTagList,
                        vFlagFuncTest: flagFuncTest,
                        vMassProdDt: String(vMassProdDt),
                        }
      if (productVerParams !== null) {
        regParams.value.versionInfo = productVerParams
      }

      if (vFlagNonPrd === 'Y') {
        regParams.value.vNonprdNoteCd = route.query.vLabNoteCd
      }
    }

    const fnSaveValidate = (chkObject) => {
      let isOk = true
      if (chkObject.basicChkKey && !basic.value.fnValidateAll(chkObject.basicChkKey)) {
        isOk = false
      }

      if (chkObject.productChkKey && commonUtils.isNotEmpty(product.value)) {
        if (!Array.isArray(product.value) && !product.value.fnValidateAll(chkObject.productChkKey)) {
          isOk = false
        } else if (Array.isArray(product.value) && !product.value[0].fnValidateAll(chkObject.productChkKey)) {
          isOk = false
        }
      }

      if (chkObject.marketingChkKey && !marketing.value.fnValidateAll(chkObject.marketingChkKey)) {
        isOk = false
      }

      if (chkObject.researcherChkKey && !researcher.value.fnValidateAll(chkObject.researcherChkKey)) {
        isOk = false
      }

      return isOk
    }

    const fnTempSave = async () => {
      const basicChkKey = ['vBrdCd', 'vPlantCd', 'contList', 'vNote']
      const productChkKey = ['vCounterNote']
      const marketingChkKey = ['vNotAddNote']

      const chkObject = {
        basicChkKey: basicChkKey,
        productChkKey: productChkKey,
        marketingChkKey: marketingChkKey,
      }

      if (!fnSaveValidate(chkObject)) {
        await openAsyncAlert({ message: '필수 입력사항을 확인해 주세요.' })
        window.scrollTo(0, 0)
        return
      }

      setRegisterParams()
      regParams.value.vStatusCd = 'LNC06_01'
      const vLabNoteCd = await saveLabNoteRequest(regParams.value)

      if (vLabNoteCd) {
        await openAsyncAlert({ message: '저장 되었습니다.'})
        goView(vLabNoteCd)
      }
    }

    const fnSave = async (newVerFlag) => {
      const basicChkKey = ['vBrdCd', 'vPlantCd', 'contList', 'pjtList', 'vFlagNew', 'vProdType1Cd', 
                          'vProdType2Cd', 'vTddProdType1Cd', 'vTddProdType2Cd', 'vPartCd',
                          'releaseInfoASIA', 'releaseInfoASEAN', 'releaseInfoETC', 'vNote']
      const productChkKey = ['vCounterNmTemp', 'vCounterBrdNm', 'vCounterPrdNm', 
                          'vCounterSpInfo', 'vPrePilotDt', 'vCounterNote', 'vFlagNewItem']
      const marketingChkKey = ['vNotAddNote']
      const researcherChkKey = ['vSlUserid', 'vBrdUserid', 'vPerfUserid', 'vUserid']

      const chkObject = {
        basicChkKey: basicChkKey,
        productChkKey: productChkKey,
        marketingChkKey: marketingChkKey,
        researcherChkKey: researcherChkKey
      }

      if (!fnSaveValidate(chkObject)) {
        await openAsyncAlert({ message: '필수 입력사항을 확인해 주세요.' })
        window.scrollTo(0, 0)
        return
      }

      setRegisterParams()

      if (newVerFlag === 'Y') {
        regParams.value.vFlagNewVer = 'Y'
      }

      regParams.value.vStatusCd = 'LNC06_21'
      const vLabNoteCd = await saveLabNoteRequest(regParams.value)

      if (vLabNoteCd) {
        await openAsyncAlert({ message: '저장 되었습니다.'})
        goView(vLabNoteCd)
      }
    }

    const init = async () => {
      store.dispatch('setPerfUserid', '')
      const vLabNoteCd = route.query.vLabNoteCd || ''
      const vCopyFlag = route.query.vCopyFlag || ''
      const result = await selectReqInfo({ vLabNoteCd: vLabNoteCd })

      if (result) {
        if (result.contList && result.contList.length > 0) {
          result.contList.forEach((item, idx) => {
            if (commonUtils.isNotEmpty(item.vHal4ContPkCd)) {
              item.vFlagExistsHal4 = 'Y'
            }

            if (vCopyFlag === 'Y') {
              item.vPrdCd = ''
              item.vContCd = ''
              item.vContPkCd = ''
              item.vFlagRepresent = idx === 0 ? 'Y' : 'N'
              item.vHal4ContPkCd = ''
              item.vHal4LabNoteCd = ''
            }
          })
        }

        if (vCopyFlag === 'Y') {
          result.vLabNoteCd = ''
          result.vStatusCd = ''
          result.vContCd = ''
          result.vContNm = ''
          result.verList = null
          
          if (result.contList) {
            result.contList = result.contList.map((cont) => {
              return cont = {
                ...cont,
                vHal4ContCd: '',
                vHal4ContNm: '',
                vHal4ContPkCd: '',
                vHal4LabNoteCd: '',
                vFlagExistsHal4: ''
              }
            })
            result.contList = [ ...result.contList.filter(item => item.vFlagCancel !== 'Y') ]
          }

          if (result.versionInfo) {
            const newMateList = result.versionInfo.newMateList || []
            const perfMateList = result.versionInfo.perfMateList || []
            const funcMateList = result.versionInfo.funcMateList || []
            const requMateList = result.versionInfo.requMateList || []

            newMateList.forEach(item => {
              item = { ...item, ...{ vFlagMateNew: 'Y'} }
            })

            perfMateList.forEach(item => {
              item = { ...item, ...{ vFlagMateNew: 'Y'} }
            })

            funcMateList.forEach(item => {
              item = { ...item, ...{ vFlagMateNew: 'Y'} }
            })

            requMateList.forEach(item => {
              item = { ...item, ...{ vFlagMateNew: 'Y'} }
            })
          }
        }

        reqInfo.value = {...reqInfo.value, ...result}
        if (commonUtils.isNotEmpty(reqInfo.value.vLabNoteCd)) {
          flagAction.value = 'M'
        }

        if (reqInfo.value.verList && reqInfo.value.verList.length > 0) {
          reqInfo.value.verList.some((item) => {
            if (Number(item.nVersion) === Number(reqInfo.value.versionInfo.nVersion)) {
              item.versionInfo = reqInfo.value.versionInfo
              currentVersion.value = Number(reqInfo.value.versionInfo.nVersion)
              return true
            }
          })
        }
      }
    }

    init()
    provide('reqInfo', reqInfo)

    onMounted(() => {
      uiUtils.accordionEvent()
    })

    onUnmounted(() => {
      uiUtils.accordionEvent()
    })

    return {
      commonUtils,
      currentVersion,
      basic,
      product,
      marketing,
      researcher,
      addVerFlag,
      flagAction,
      pathList,
      showAddVerBtn,
      reqInfo,
      fnProductVersionTabEvent,
      fnAddVersion,
      fnTempSave,
      fnSave,
      goList,
    }
  }
}
</script>