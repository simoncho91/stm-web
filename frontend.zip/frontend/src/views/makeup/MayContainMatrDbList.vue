<template>
  <div>
    <ap-breadcrumb nav-title="May Contain 원료 DB" :path-list="pathList">
    </ap-breadcrumb>
  
    <div class="contents-core">
      <div class="contents-cell__wrap">
        <div class="contents-cell">
          <div class="contents-box contents-box__full">
            <div class="contents-box__inner">
              <div class="board-top">
                <div class="search-form">
                  <div class="search-form__inner">
                    <div class="search-bar__row">
                      <dl class="search-bar__item">
                        <dt class="search-bar__key search-bar__width--90">검색</dt>
                        <dd class="search-bar__val">
                          <div class="search-form">
                            <div class="search-form__inner">
                              <ap-input
                                :is-number="false"
                                v-model:value="searchParams.vKeyword"
                                :inputClass="'ui-input__width--450'"
                                :placeholder="'성분코드 or 성분표시명(국문) or 성분표시명(영문)'"
                                @keypress-enter="fnSearch(1)"
                              >
                              </ap-input>
                              <button
                                type="button"
                                class="button-search"
                                @click="fnSearch(1)"
                              >검색</button>
                              <button
                                type="button"
                                class="ui-button ui-button__bg--lightgray font-weight__500 ml-5"
                                @click="resetSearchFilter"
                              >검색 초기화</button>
                            </div>
                          </div>
                        </dd>
                      </dl>
                    </div>
                  </div>
                </div>
                <div class="total-page">
                  <template v-if="page && page.totalPageCnt">
                    <div class="total-page__case">총<span class="total-page__num">{{ commonUtils.setNumberComma(page.totalCnt) }}</span>건</div>
                    <div class="total-page__page">총 <span class="total-page__num">{{ commonUtils.setNumberComma(page.totalPageCnt) }}</span>페이지</div>
                  </template>
                </div>
                <div class="ui-buttons__left-right">
                  <div class="ui-buttons">
                    <button
                      type="button"
                      class="ui-button ui-button__bg--lightgray"
                      @click="fnDelete"
                    >삭제</button>
                  </div>
                  <div class="ui-buttons ui-buttons__right">
                    <button
                      type="button"
                      class="ui-button ui-button__border--blue"
                      @click="fnExcel"
                    >엑셀</button>
                    <button
                      type="button"
                      class="ui-button ui-button__bg--skyblue"
                      @click="goRegister()"
                    >등록</button>
                  </div>
                </div>
              </div>
              <div class="ui-table__wrap">
                <table class="ui-table text-center ui-table__td--40">
                  <colgroup>
                    <col style="width:6rem;">
                    <col style="width:6rem;">
                    <col style="width:13rem;">
                    <col style="width:21%;">
                    <col style="width:auto;">
                    <col style="width:13rem;">
                    <col style="width:13rem;">
                    <col style="width:13rem;">
                  </colgroup>
                  <thead>
                    <tr>
                      <th>
                        <ap-input-check
                          v-model:model="chkAll"
                          :value="'Y'"
                          :false-value="'N'"
                          :id="'ex_check_all'"
                          @click="fnCheckAll"
                        >
                        </ap-input-check>
                      </th>
                      <th>NO.</th>
                      <th>성분코드</th>
                      <th>성분표시명(국문)</th>
                      <th>성분표시명(영문)</th>
                      <th>CI NUMBER</th>
                      <th>등록자</th>
                      <th>등록일</th>
                    </tr>
                  </thead>
                  <tbody>
                    <template v-if="list?.length > 0">
                      <tr v-for="(vo, idx) in list" :key="`tr_${idx}`">
                        <td>
                          <ap-input-check
                            v-model:model="concdList"
                            :value="vo.vConcd"
                            :id="`ex_check_${idx}`"
                            @click="fnAddDeleteTarget($event)"
                          >
                          </ap-input-check>
                        </td>
                        <td>{{ vo.nNum }}</td>
                        <td>{{ vo.vConcd }}</td>
                        <td class="tit">
                          <div class="tit__inner">
                            <a href="#" class="tit-link" @click.prevent="goRegister(vo.vConcd)">{{ vo.vConnameKo }}</a>
                          </div>
                        </td>
                        <td class="tit">
                          <div class="tit__inner">
                            <a href="#" class="tit-link" @click.prevent="goRegister(vo.vConcd)">{{ vo.vConnameEn }}</a>
                          </div>
                        </td>
                        <td>{{ vo.vCiNumber }}</td>
                        <td>{{ vo.vRegUsernm }}</td>
                        <td>{{ commonUtils.changeStrDatePattern(vo.vRegDtm) }}</td>
                      </tr>
                    </template>
                    <template v-else>
                      <tr>
                        <td colspan="8">
                          <div class="no-result">
                            {{ t('common.msg.no_data') }}
                          </div>
                        </td>
                      </tr>
                    </template>
                  </tbody>
                </table>
              </div>
              <div class="board-bottom ">
                <div class="board-bottom__inner board-bottom__with--form">
                  <div>
                    <div class="ui-select-block">
                      <ap-selectbox
                        v-model:value="searchParams.pageSize"
                        :options="pageList"
                        @change="selectChange"
                        :default-blank="{ blank: false }"
                      >
                      </ap-selectbox>
                    </div>
                  </div>
                  <Pagination 
                    :page-info="page"
                    @click="fnSearch">
                  </Pagination>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useRouter } from 'vue-router'
import { useMakeupRequest } from '@/compositions/makeup/useMakeupRequest'

export default {
  name: 'MayContainMatrDbList',
  components: {
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
  },
  setup() {
    const t = inject('t')
    const commonUtils = inject('commonUtils')

    const { openAsyncConfirm, openAsyncAlert } = useActions(['openAsyncConfirm', 'openAsyncAlert'])

    const router = useRouter()

    const {
      page,
      list,
      selectMayContainMatrDbList,
      selectMayContainMatrDbListExcel,
      deleteMayContainMatrDbInfo,
      goMayContainRegister,
    } = useMakeupRequest()

    const searchParams = ref({
      vKeyword: '',
      nowPageNo: 1,
      pageSize: 10,
    })

    const pageList = [
      {
        vSubCode: '10',
        vSubCodenm: 10
      },
      {
        vSubCode: '20',
        vSubCodenm: 20
      },
      {
        vSubCode: '40',
        vSubCodenm: 40
      },
      {
        vSubCode: '80',
        vSubCodenm: 80
      },
      {
        vSubCode: '160',
        vSubCodenm: 160
      },
    ]

    const pathList = [
      { path: '/makeup/may-contain-matr-db-list', pathNm: '원료 DB' },
    ]

    const concdList = ref([])
    const chkAll = ref('N')

    const selectChange = (value) => {
      searchParams.value.pageSize = value

      fnSearch(1)
    }

    const fnSearch = (pg) => {
      if (!pg) {
        searchParams.value.nowPageNo = 1
      }

      searchParams.value.nowPageNo = pg

      chkAll.value = 'N'
      concdList.value = []

      selectMayContainMatrDbList(searchParams.value)
    }

    const fnExcel = () => {
      selectMayContainMatrDbListExcel(searchParams.value)
    }

    const resetSearchFilter = () => {
      searchParams.value.vKeyword = ''
      searchParams.value.nowPageNo = 1

      chkAll.value = 'N'
      concdList.value = []

      selectMayContainMatrDbList(searchParams.value)
    }

    const goRegister = (vConcd) => {
      goMayContainRegister(vConcd)
    }

    const fnCheckAll = (value) => {
      if (list.value && list.value.length > 0) {
        if (value === 'Y') {
          concdList.value = list.value.map(vo => vo.vConcd)
        } else {
          concdList.value = []
        }
      }
    }

    const fnAddDeleteTarget = (value) => {
      const targetList = concdList.value

      if (value) {
        // 삭제 대상 체크했을 때
        if (targetList.length === list.value.length) {
          chkAll.value = 'Y'
        }
      } else {
        // 삭제 대상 체크 해제했을 때
        chkAll.value = 'N'
      }
    }

    const fnDelete = async () => {
      if (concdList.value.length === 0) {
        openAsyncAlert({ message: '삭제 할 성분코드를 체크를 해주세요.' })
        return
      }

      if (!await openAsyncConfirm({ message: '선택 한 성분을 삭제하시겠습니까?.' })) {
        return
      }

      const result = await deleteMayContainMatrDbInfo({ concdList: concdList.value })

      if (result) {
        await openAsyncAlert({ message: '삭제 되었습니다.' })
        // window.location.reload(true)
        init()
      }
    }

    const init = () => {
      fnSearch(1)
    }

    init()

    return {
      t,
      commonUtils,
      page,
      list,
      pageList,
      selectChange,
      fnSearch,
      fnExcel,
      resetSearchFilter,
      goRegister,
      concdList,
      chkAll,
      fnCheckAll,
      fnAddDeleteTarget,
      fnDelete,
      searchParams,
      pathList,
    }
  }
}
</script>
