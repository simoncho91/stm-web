<template>
  <div>
    <ap-breadcrumb nav-title="May Contain 원료 DB 등록" :path-list="pathList">
    </ap-breadcrumb>

    <div class="contents-core">
      <div class="contents-cell__wrap">
        <div class="contents-cell">
          <div class="contents-box contents-box__full">
            <div class="contents-box__inner">
              <div class="arrordion-item is-active">
                <div class="arrordion-header">
                  <div class="arrordion-title">May Contain 원료 DB 등록</div>
                  <button type="button" class="ui-button__accordion"></button>
                </div>
                <div class="arrordion-body">
                  <div class="basic-info__table researcher-information-table">
                    <table class="ui-table__contents">
                      <colgroup>
                        <col style="width:17rem">
                        <col style="width:auto">
                        <col style="width:17rem">
                        <col style="width:auto">
                      </colgroup>
                      <tbody>
                        <tr>
                          <th>성분코드</th>
                          <td>
                            <div class="form-flex">
                              <div class="search-form ui-form-box__width--340 ui-form-box__max-width--230">
                                <ap-input :is-number="false" v-model:value="resData.vConcd" :inputClass="'ui-input__width--full'" :readonly="true"></ap-input>
                              </div>
                              <template v-if="vFlagAction === 'R'">
                                <button type="button" class="ui-button ui-button__bg--skyblue ml-5" @click="fnMatrDbSearchPop">검색</button>
                                <button type="button" class="ui-button ui-button__bg--lightgray ml-5" @click="fnDelMatrDbSearchInfo">삭제</button>
                              </template>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <th>성분명(영문)</th>
                          <td>{{ resData.vConnameEn }}</td>
                          <th>성분명(국문)</th>
                          <td>{{ resData.vConnameKo }}</td>
                        </tr>
                        <tr>
                          <th>성분명(영문)</th>
                          <td>
                            <div class="form-flex">
                              <div class="search-form ui-form-box__width--340 ui-form-box__max-width--230">
                                <ap-input :is-number="false" v-model:value="resData.vConnmEn" :inputClass="'ui-input__width--full'"></ap-input>
                              </div>
                            </div>
                          </td>
                          <th>성분명(국문)</th>
                          <td>
                            <div class="form-flex">
                              <div class="search-form ui-form-box__width--340 ui-form-box__max-width--230">
                                <ap-input :is-number="false" v-model:value="resData.vConnmKo" :inputClass="'ui-input__width--full'"></ap-input>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <th>Ci Number</th>
                          <td>
                            <div class="form-flex">
                              <div class="search-form ui-form-box__width--340 ui-form-box__max-width--230">
                                <ap-input :is-number="false" v-model:value="resData.vCiNumber" :inputClass="'ui-input__width--full'"></ap-input>
                              </div>
                            </div>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="page-bottom">
          <div class="page-bottom__inner">
            <div class="ui-buttons ui-buttons__right">
              <button type="button" class="ui-button ui-button__bg--skyblue" v-if="vFlagAction === 'M'" @click="fnSave">수정</button>
              <button type="button" class="ui-button ui-button__border--blue" v-if="vFlagAction === 'R'" @click="fnSave">저장</button>
              <button type="button" class="ui-button ui-button__border--gray" @click="goMayContainList">목록</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <teleport to="#common-modal" v-if="popupContent">
      <ap-popup>
        <component
          :is="popupContent"
          :pop-params="popParams"
          @selectFunc="popSelectFunc"
        />
      </ap-popup>
    </teleport>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, inject } from 'vue'
import { useActions } from 'vuex-composition-helpers'
import { useRoute } from 'vue-router'
import { useLabCommon } from '@/compositions/labcommon/useLabCommon'
import { useMakeupRequest } from '@/compositions/makeup/useMakeupRequest'

export default {
  name: 'MayContainMatrDbRegister',
  components: {
    ApPopup: defineAsyncComponent(() => import('@/components/comm/ApPopup.vue')),
    MatrDbSearchPop: defineAsyncComponent(() => import('@/components/makeup/popup/MatrDbSearchPop.vue')),
  },
  setup() {
    const t = inject('t')
    const commonUtils = inject('commonUtils')

    const { openAsyncConfirm, openAsyncAlert } = useActions(['openAsyncConfirm', 'openAsyncAlert'])

    const route = useRoute()

    const vConcd = route.query.vConcd || ''

    const vFlagAction = ref('R')

    const resData = ref({
      vConcd: '',
      vConnameEn: '',
      vConnameKo: '',
      vConnmEn: '',
      vConnmKo: '',
      vCiNumber: '',
    })

    const {
      selectMayContainMatrDbInfo,
      saveMayContainMatrDbInfo,
      goMayContainList,
    } = useMakeupRequest()

    const {
      popupContent,
      popParams,
      popSelectFunc,
      fnOpenPopup,
    } = useLabCommon()

    const pathList = [
      { path: '/makeup/may-contain-matr-db-list', pathNm: '원료 DB' },
    ]

    const fnMatrDbSearchPop = () => {
      popParams.value = {
        vKeyword: resData.value.vConcd || '',
      }

      popSelectFunc.value = getMatrDbSearchInfo
      fnOpenPopup('MatrDbSearchPop')
    }

    const getMatrDbSearchInfo = (vo) => {
      resData.value.vConcd = vo.vConcd
      resData.value.vConnameEn = vo.vConnameEn
      resData.value.vConnameKo = vo.vConnameKo
      resData.value.vConnmEn = vo.vConnmEn
      resData.value.vConnmKo = vo.vConnmKo
      resData.value.vCiNumber = vo.vCiNumber
    }

    const fnDelMatrDbSearchInfo = () => {
      resData.value.vConcd = ''
      resData.value.vConnameEn = ''
      resData.value.vConnameKo = ''
      resData.value.vConnmEn = ''
      resData.value.vConnmKo = ''
      resData.value.vCiNumber = ''
    }

    const fnSave = async () => {
      if (commonUtils.isEmpty(resData.value.vConcd)) {
        openAsyncAlert({ message: '성분코드를 입력해 주세요.' })
        return
      }

      let message = ''

      if (vFlagAction.value === 'M') {
        message = '해당 성분을 수정하시겠습니까?'
      } else {
        message = '선택 한 성분을 등록하시겠습니까?'
      }

      if (!await openAsyncConfirm({ message: message })) {
        return
      }

      const payload = {
        ...resData.value,
        vFlagAction: vFlagAction.value
      }

      const result = await saveMayContainMatrDbInfo(payload)

      if (result) {
        await openAsyncAlert({ message: '저장 되었습니다.' })
        goMayContainList()
      }
    }

    const init = async () => {
      if (vConcd) {
        vFlagAction.value = 'M'
        resData.value = await selectMayContainMatrDbInfo({ vConcd: vConcd })
      }
    }

    init()

    return {
      t,
      commonUtils,
      fnSave,
      resData,
      goMayContainList,
      fnMatrDbSearchPop,
      fnDelMatrDbSearchInfo,
      vFlagAction,
      popupContent,
      popParams,
      popSelectFunc,
      pathList,
    }
  }
}
</script>
