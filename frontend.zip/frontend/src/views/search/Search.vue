<template>
  <ap-breadcrumb nav-title="Search" :path-list="pathList">
  </ap-breadcrumb>
  <div class="contents-core">
    <div class="contents-cell__wrap">
      <div class="contents-cell">
        <div class="contents-box contents-box__full">
          <div class="contents-box__inner">
            <div class="contents-tab ap_contents_tab">
              <div class="contents-tab__inner">
                <ApTab
                  mst-id="tab_example"
                  :tab-list="tabList"
                  :default-tab="'searchTab01'"
                  @click="fnChangeTab"
                />
                <div class="contents-tab__body" id="searchTab01">
                  <RawSearchList
                    v-if="nowTabId === 'searchTab01'"
                  />
                </div>
                <div class="contents-tab__body" id="searchTab02">
                  <CounterMapList
                    v-if="nowTabId === 'searchTab02'"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, ref, computed } from 'vue'
import { useStore } from 'vuex'

export default {
  name: 'SearchList',
  components: {
    ApTab: defineAsyncComponent(() => import('@/components/comm/ApTab.vue')),
    RawSearchList: defineAsyncComponent(() => import('@/components/search/RawSearchList.vue')),
    CounterMapList: defineAsyncComponent(() => import('@/components/search/CounterMapList.vue'))
  },
  setup() {
    const nowTabId = ref('searchTab01')
    const store = useStore()
    const noteTypeNm = computed(() => store.getters.getNoteTypeNm())
    const pathList = [
      { path: '/' + noteTypeNm.value + '/search/list', pathNm: 'SEARCH' },
    ]

    // temp
    const tabList = [
      { tabId: 'searchTab01', tabNm: '원료 검색'}, 
      { tabId: 'searchTab02', tabNm: '카운터 맵'},
    ]

    const fnChangeTab = (item) => {
      if (item && item.tabId) nowTabId.value = item.tabId
    }

    return {
      nowTabId,
      tabList,
      pathList,
      fnChangeTab,
    }
  }
}
</script>
