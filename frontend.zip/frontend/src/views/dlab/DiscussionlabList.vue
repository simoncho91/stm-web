<template>
  <div>
    <ap-breadcrumb nav-title="Discussion lab" :path-list="pathList">
    </ap-breadcrumb>
  
    <div class="contents-core">
      <div class="contents-cell__wrap">
        <div class="contents-cell">
          <div class="contents-box contents-box__full">
            <div class="contents-box__inner">
              <div class="board-top">
                <div class="search-form search-form__right">
                  <div class="search-form__inner">
                    <div class="total">
                        <span>{{ page.totalCnt }}</span>
                        <p>Discussion</p>
                    </div>
                    <div class="search-form__cell">
                      <button
                        type="button"
                        class="ui-button ui-button__border--blue ui-button__icon--right ui-button__icon--plus ui-button__icon--plus-blue"
                        @click="goReg"
                      >
                        Ask Question
                      </button>
                    </div>
                    <div class="search-form__cell">
                      <ap-input
                        v-model:value="searchParams.vKeyword"
                        inputClass="ui-input ui-input__width--263"
                        placeholder="검색어를 입력 해주세요."
                        @keypressEnter="fnSearchRawList(1)"
                      >
                      </ap-input>
                      <button type="button" class="button-search" @click="fnSearchRawList(1)">
                        검색
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div class="Answers-table top-blue">
                <div class="note-table__inner">
                  <table class="ui-table ui-table__td--40 text-center">
                    <colgroup>
                        <col style="width:132px">
                        <col>
                    </colgroup>
                    <tbody>
                      <template v-if="list?.length > 0">
                        <tr v-for="(vo, index) in list" :key="`tr_${index}`">
                            <th>
                                <div class="num">Answers <p>{{vo.nAnswerCount}}</p></div>
                                <div class="num">Views <p>{{vo.nViewCount}}</p></div>
                            </th>
                            <td>
                                <div class="tit"  @click="goView(vo.vRecordid)">
                                  {{ vo.vTitle }}
                                </div>
                                <div class="cont" >
                                  <div v-html="commonUtils.removeHTMLTag(commonUtils.removeHTMLChangeBr(vo.vContents))"></div>
                                </div>
                                <template v-if="vo?.tagList?.length > 0">
                                  <div class="tag">
                                    <p v-for="(tvo, index2) in vo.tagList" :key="`p_${index}_${index2}`"># {{ tvo.vTagTxt }}</p>
                                  </div>
                                </template>
                            </td>
                        </tr>
                      </template>
                    </tbody>
                  </table>
                </div>
              </div>
              <div class="board-bottom">
                <div class="board-bottom__inner">
                  <Pagination
                   :page-info="page"
                   @click="fnSearchRawList"
                  />
                </div>
              </div>
  
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, inject, computed } from 'vue'
import { useStore } from 'vuex'
import { useDiscussionlab } from '@/compositions/dlab/useDiscussionlab'

export default {
  name: 'DiscussionlabList',
  components: {
    Pagination: defineAsyncComponent(() => import('@/components/comm/Pagination.vue')),
  },
  setup() {
    const store = useStore()
    const noteTypeNm = computed(() => store.getters.getNoteTypeNm())
    const t = inject('t')
    const commonUtils = inject('commonUtils')
    const pathList = [
      { path: '/' + noteTypeNm.value +'/discussionlab-list', pathNm: 'DISCUSSION LAB' },
    ]
    
    const { 
      searchParams
      , page
      , list
      , fnSearchRawList
      , goView
      , goReg
    } = useDiscussionlab()

    const init = async () => {
      fnSearchRawList(1)
    }

    init()

    return {
      t
      , commonUtils
      , searchParams
      , page
      , list
      , pathList
      , fnSearchRawList
      , goView
      , goReg
    }
  }
}
</script>

<style scoped>
  .tit { cursor: pointer;}
</style>