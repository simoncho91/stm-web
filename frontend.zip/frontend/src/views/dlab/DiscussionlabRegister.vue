<template>
  <div>
    <ap-breadcrumb nav-title="Discussion lab" :path-list="pathList">
    </ap-breadcrumb>
  
    <div class="contents-core">
      <div class="contents-cell__wrap">
        <div class="contents-cell">
          <div class="contents-box contents-box__full">
            <div class="contents-box__inner">
              <div class="question-title">질문하기</div>
              <div class="question-view">
                <div class="sub-contents__item">
                  <dl class="sub-contents__dd">
                    <dt class="sub-contents__dt">TITLE</dt>
                    <dd class="sub-contents__dd">
                      <div id="error_wrap_vTitle">
                        <div>
                          <ap-input
                            input-class="ui-input ui-input__width--full"
                            v-model:value="params.vTitle"
                            placeholder="제목을 입력해 주세요."
                            @input="fnValidate('vTitle')"
                          >
                          </ap-input>
                        </div>
                        <span class="error-msg" id="error_msg_vTitle"></span>
                      </div>
                    </dd>
                  </dl>
                  <dl class="sub-contents__dd">
                    <dt class="sub-contents__dt">CONTENTS</dt>
                    <dd class="sub-contents__dd">
                      <div id="error_wrap_vContents">
                        <div class="product-box__gray">
                          <jodit-editor v-model="params.vContents" :height="'400px'" :uploadCd="uploadParams.uploadCd" @input="fnValidate('vContents')"></jodit-editor>
                        </div>
                        <span class="error-msg" id="error_msg_vContents"></span>
                      </div>
                    </dd>
                  </dl>
                  <dl class="sub-contents__dd">
                    <dt class="sub-contents__dt">TAGS</dt>
                    <dd class="sub-contents__dd">
                      <!-- 2023.04.06 : mod : 레이아웃 수정 -->
                      <div class="search-form">
                        <div class="search-form__inner">
                          <ap-input
                            input-class="ui-input ui-input__width--full"
                            @keyup.enter="fnAddTag()"
                            v-model:value="params.vAddTagInfo"
                            placeholder="태그를 입력해 주세요. (최대 10개)"
                          >
                          </ap-input>
                          <button type="button" class="button-search" @click="fnAddTag()">추가</button>
                        </div>
                      </div>
                      <!--// 2023.04.06 : mod : 레이아웃 수정 -->
                    </dd>
                    <dd class="sub-contents__dd">
                      <div class="tag">
                        <template v-if="tagList">
                          <p v-for="(vo, index) in tagList" :key="`tagtxt_${index}`">
                            #{{ vo.vTagTxt }}<button type="button" class="tag__button--delete" @click="fnDelTag(index)"></button>
                          </p>
                        </template> 
                      </div>
                    </dd>
                  </dl>
                </div>
              </div>
              <!-- 2023.04.06 : 위치 이동 -->
              <div class="page-bottom">
                <div class="page-bottom__inner">
                  <div class="ui-buttons ui-buttons__right">
                    <button type="button" class="ui-button ui-button__bg--skyblue" @click="fnSave">저장</button>
                    <button type="button" class="ui-button ui-button__border--gray" @click="goList">목록</button>
                  </div>
                </div>
              </div>
              <!--// 2023.04.06 : 위치 이동 -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { computed, reactive, defineAsyncComponent, provide, ref, inject } from 'vue'
import { useRoute } from 'vue-router'
import { useStore } from 'vuex'
import { useDiscussionlab } from '@/compositions/dlab/useDiscussionlab'
import { useActions } from 'vuex-composition-helpers'

export default {
  name: 'DiscussionlabRegister',
  components: {
    JoditEditor: defineAsyncComponent(() => import('@/components/comm/JoditEditor.vue')),
  },
  setup () {
    const commonUtils = inject('commonUtils')
    const store = useStore()
    const noteTypeNm = computed(() => store.getters.getNoteTypeNm())
    const pathList = [
      { path: '/' + noteTypeNm.value +'/discussionlab-list', pathNm: 'DISCUSSION LAB' },
      { path: '/' + noteTypeNm.value +'/discussionlab-reg', pathNm: '등록' },
    ]
    
    const route = useRoute()
    const key = route.query.vRecordid
    const targetKey = ref('1')

    const { openAsyncConfirm, openAsyncAlert } = useActions(['openAsyncConfirm', 'openAsyncAlert'])
    
    const {
       goList
       , goSave 
       , goUpdate
       , selectReqDetail
       , params
       , tagList
    } = useDiscussionlab()

    const modifyYn = computed(() => {
      //수정여부
      if (route.query.vFlagModYn === 'Y') {
        return 'Y'
      }
      return 'N'
    })

    const init = async () => {
      if(modifyYn.value === "Y"){
        selectReqDetail({ vRecordid: key })
      }
    }

    init()

    const uploadParams = reactive({
      //업로드 관련
      targetKey: ''
      , uploadCd: 'DISCUS01'
      , items: []
    })
    
    provide('upload-DISCUS01', uploadParams)

    const fnAddTag = () =>{
      //태그 추가
      if(params.value.vAddTagInfo === ""){
          openAsyncAlert({ message: '태그를 입력해주세요.' })
          return
      }else{
          if( tagList.value.length <= 9 ){
              tagList.value.push({ vTagTxt:params.value.vAddTagInfo })
          }else{
            openAsyncAlert({ message: '최대 10개까지 입력 가능합니다.' })
            return
          }
      }
      
      params.value.vAddTagInfo = ""
    }

    const fnDelTag = (index) =>{
      //태그 삭제
      tagList.value.splice(index,1)
    }

    const fnValidate = (key) => {
      let isOk = true
      let errorMsg = '필수 입력 사항입니다.'
      commonUtils.hideErrorMessage(key)

      if (key === 'vTitle') {
        if (commonUtils.isEmpty(params.value.vTitle)) {
          isOk = false
        } else {
          if (!commonUtils.checkByte(params.value.vTitle, 1500)) {
            isOk = false
            errorMsg = t('common.msg.byte_msg2', { byteSize: commonUtils.setNumberComma(1500) })
          }
        }
      } else if (key === 'vContents') {
        if (commonUtils.isEmpty(params.value.vContents)) {
          isOk = false
        } else {
          if (!commonUtils.checkByte(params.value.vContents, 3500)) {
            isOk = false
            errorMsg = t('common.msg.byte_msg2', { byteSize: commonUtils.setNumberComma(3500) })
          }
        }
      }

      if (!isOk) {
        commonUtils.showErrorMessage(key, errorMsg)
      }

      return isOk
    }

    const fnValidateAll = (arrChkKey) => {
      let isOk = true
      commonUtils.hideErrorMessageAll(['vTitle', 'vContents'])

      arrChkKey.forEach(key => {
        if (!fnValidate(key)) {
          isOk = false
        }
      })

      return isOk
    }

    const fnSaveValidate = (chkObject) => {
      let isOk = true
      if (!fnValidateAll(chkObject)) {
        isOk = false
      }

      return isOk
    }

    const fnSave = async () =>{
      const chkObject = ['vTitle', 'vContents']

      if (!fnSaveValidate(chkObject)) {
        await openAsyncAlert({ message: '필수 입력사항을 확인해 주세요.' })
        window.scrollTo(0, 0)
        return
      }

      if (!await openAsyncConfirm({ message: `게시글을 ${modifyYn.value === 'Y' ? '수정' : '저장'}하시겠습니까?` })) {
        return
      }

      params.value.files = uploadParams.items
      params.value.tagList = tagList.value
      
      if(modifyYn.value === 'Y'){
        //수정
        goUpdate(params.value)
      }else{
        //저장
        goSave(params.value)
      }
    }
    
    return {
      tagList
      , uploadParams
      , fnAddTag
      , fnDelTag
      , params
      , targetKey
      , goList
      , goSave
      , goUpdate
      , fnSave
      , pathList
      , fnValidate
    }
  }
}
</script>
