<template>
  <div>
    <ap-breadcrumb nav-title="Discussion lab" :path-list="pathList">
    </ap-breadcrumb>

    <div class="contents-core">
      <div class="contents-cell__wrap">
        <div class="contents-cell">
          <div class="contents-box contents-box__full">
            <div class="contents-box__inner p-0">
              <div class="view-content">
                <div class="discussion view-title">{{ params.vTitle }}</div>
                <div class="question-view underline">
                  <div class="top">
                    <div class="data">
                      <div class="num">
                        Answers
                        <p>{{ answerList?.length ?? 0 }}</p>
                      </div>
                      <div class="num">
                        Views
                        <p>{{ params?.nViewCount ?? 0 }}</p>
                      </div>
                    </div>
                    <div class="info">
                      <div class="name">{{ params.vRegUsernm }}</div>
                      <span class="date">{{ commonUtils.changeStrDatePattern(params.vRegDtm) }}</span>
                    </div>
                  </div>

                  <div class="cont">
                    <p class="text" style="font-size:14px;font-weight: 400;line-height: 2.4rem;" v-html="commonUtils.removeHTMLChangeBr(params.vContents)"></p>
                    <template v-if="tagList?.length > 0">
                      <div class="tag">
                        <p v-for="(tvo, idx) in tagList" :key="`p_tag_${idx}`"># {{ tvo.vTagTxt }}</p>
                      </div>
                    </template>
                  </div>
                </div>
                <div class="question-answers">
                  <div class="title">Answers <span class="count">{{ answerList?.length ?? 0 }}</span></div>
                  <template v-if="answerList?.length > 0">
                    <div v-for="(avo, idx) in answerList" :key="`div_answer_${idx}`">
                      <div class="reply-wrap">
                        <div class="cont">
                          <div v-html="commonUtils.removeHTMLChangeBr(avo.vContents)"></div>
                        </div>
                        <div class="bottomInfo">
                          <div class="btnWrap">
                            <button type="button" class="ui-button ui-button__radius--2 ui-button__border--gray" v-if="!avo.vAnswerModAreaDispFlag || avo.vAnswerModAreaDispFlag === 'N'" @click="fnOpenComentArea(avo)">댓글작성</button>
                            <template v-if="commonUtils.checkAuth('S000000') || myInfo.loginId === avo.vRegUserid">
                              <button type="button" class="ui-button ui-button__radius--2 ui-button__border--gray" v-if="!avo.vAnswerModAreaDispFlag || avo.vAnswerModAreaDispFlag === 'N'" @click="fnOpenAnswerModArea(avo)">수정</button>
                              <button type="button" class="ui-button ui-button__radius--2 ui-button__border--gray" v-if="avo.vAnswerModAreaDispFlag === 'Y'" @click="fnOpenAnswerModArea(avo)">수정취소</button>
                              <button type="button" class="ui-button ui-button__radius--2 ui-button__border--gray" v-if="!avo.vAnswerModAreaDispFlag || avo.vAnswerModAreaDispFlag === 'N'" @click="fnAnswerDel(avo)">삭제</button>
                            </template>
                          </div>
                          <div class="info">
                            <span class="date">{{ commonUtils.changeStrDatePattern(avo.vRegDtm) }}</span>
                          </div>
                        </div>
                      </div>
                      <template v-if="avo.vAnswerModAreaDispFlag === 'Y'">
                        <div class="regist">
                          <div class="reply-form">
                            <div class="reply-form__inner">
                              <div class="textWrap">
                                <div class="ui-textarea-box fixWidth">
                                  <ap-text-area
                                    :is-with-byte="false"
                                    v-model:value="vContentsMod" 
                                    ref="answerArea"
                                    placeholder="답변을 입력해 주세요."
                                  >
                                  </ap-text-area>
                                </div>
                                <button type="button" class="button-reply skyblue" @click="fnAnswerMod(avo)">수정</button>
                                <button type="button" class="button-reply skyblue" @click="fnOpenAnswerModArea(avo)">취소</button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </template>
                      <!-- [s] 댓글 리스트 -->
                      <template v-if="avo?.commentList?.length > 0">
                        <div
                          v-for="(cvo, idx2) in avo.commentList"
                          :key="`div_cmt_${idx2}`"
                          class="comment-wrap"
                        >
                          <div class="search-form">
                            <div class="search-form__inner">
                              <div class="textWrap">
                                <div
                                  class="ui-textarea-box fixWidth"
                                  style="border: none;line-height: 20px;background-color: #f7fafe;"
                                  v-html="commonUtils.removeHTMLChangeBr(cvo.vComments)"
                                ></div>
                              </div>
                            </div>
                          </div>
                          <div class="bottomInfo">
                            <div class="btnWrap">
                              <template v-if="commonUtils.checkAuth('S000000') || myInfo.loginId === avo.vRegUserid">
                                <!-- <button type="button" class="ui-button ui-button__radius--2 ui-button__border--gray" >수정</button> -->
                                <button type="button" class="ui-button ui-button__radius--2 ui-button__border--gray" @click="fnAnswerCommentDel(cvo.vSubRecordid, cvo.vCmntRecordid)">삭제</button>
                              </template>
                            </div>
                            <div class="info">
                              <span class="date">{{ commonUtils.changeStrDatePattern(avo.vRegDtm) }}</span>
                            </div>
                          </div>
                        </div>
                      </template>
                      <!-- [e] 댓글 리스트 -->
                      <div class="comment-wrap" v-if="avo.vCommentAreaDispFlag === 'Y'">
                        <div class="search-form">
                          <div class="search-form__inner">
                            <div class="textWrap">
                              <div class="ui-textarea-box fixWidth">
                                <ap-text-area
                                  :is-with-byte="false"
                                  v-model:value="avo.vComments" 
                                  ref="answerArea"
                                  placeholder="댓글을 입력해 주세요."
                                  :rows="2"
                                >
                                </ap-text-area>
                              </div>
                              <button type="button" class="button-search skyblue" @click="fnCommentReg(avo)">등록</button>
                              <button type="button" class="button-search skyblue" @click="fnOpenComentArea(avo)">취소</button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </template>
                </div>
              </div>

              <div class="regist">
                <div class="title">나의답변</div>
                <div class="reply-form">
                  <div class="reply-form__inner">
                    <div class="textWrap">
                      <div class="ui-textarea-box fixWidth">
                        <ap-text-area
                          :is-with-byte="false"
                          v-model:value="comParams.vContents" 
                          ref="answerArea"
                          placeholder="답변을 입력해 주세요."
                        >
                        </ap-text-area>
                      </div>
                      <button type="button" class="button-reply skyblue" @click="fnAnswerReg(params.vRecordid, answerArea)">등록</button>
                    </div>
                  </div>
                </div>

                <div class="page-bottom">
                  <div class="page-bottom__inner">
                    <div class="ui-buttons ui-buttons__right">
                      <template v-if="commonUtils.checkAuth('S000000') || myInfo.loginId === params.vRegUserid">
                        <button type="button" class="ui-button ui-button__bg--skyblue" @click="goModify(params.vRecordid)">수정</button>
                        <button type="button" class="ui-button ui-button__bg--lightgray" @click="fnDel">삭제</button>
                      </template>
                      <button type="button" class="ui-button ui-button__border--gray" @click="goList">목록</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { inject, ref, computed } from 'vue'
import { useRoute } from 'vue-router'
import { useStore } from 'vuex'
import { useActions } from 'vuex-composition-helpers'
import { useDiscussionlab } from '@/compositions/dlab/useDiscussionlab'

export default {
  name: 'DiscussionlabView',
  components: {},
  setup() {
    const store = useStore()
    const noteTypeNm = computed(() => store.getters.getNoteTypeNm())
    const myInfo = store.getters.getMyInfo()
    const pathList = [
      {
        path: '/' + noteTypeNm.value + '/discussionlab-list',
        pathNm: 'DISCUSSION LAB',
      },
      { path: '/' + noteTypeNm.value + '/discussionlab-info', pathNm: '상세' },
    ]
    const t = inject('t')
    const route = useRoute()
    const key = route.query.vRecordid
    let isHide = false

    const { openAsyncConfirm, openAsyncAlert } = useActions([
      'openAsyncConfirm',
      'openAsyncAlert',
    ])
    const commonUtils = inject('commonUtils')
    const answerArea = ref(null)

    const vContentsMod = ref('')

    const {
      list,
      selectReqDetail,
      params,
      comParams,
      tagList,
      answerList,
      // commentList,
      goList,
      goModify,
      goDel,
      goAnswerReg,
      goAnswerMod,
      goAnswerDel,
      goAnswerCommentDel,
      // selectAnswerCommentList,
      goAnswerCommentReg,
    } = useDiscussionlab()

    const init = async () => {
      selectReqDetail({ vRecordid: key })
    }

    init()

    //질문 삭제
    const fnDel = async () => {
      if (!await openAsyncConfirm({ message: '해당 게시글을 삭제하시겠습니까?'})) {
        return
      }

      goDel({
        vRecordid: params.value.vRecordid,
        answerList: answerList.value,
        tagList: tagList.value 
      })
    }

    //답변 등록
    const fnAnswerReg = async (key, answerArea) => {
      if (commonUtils.isEmpty(comParams.value.vContents)) {
        openAsyncAlert({ message: '답변을 입력해 주세요.' })
        return
      }

      if (!commonUtils.checkByte(answerArea.value, 3000)) {
        // 내용이 3000 Byte를 초과할 수 없습니다.
        await openAsyncAlert({
          message: t('common.msg.byte_msg2', { byteSize: 3000 }),
        })
        return
      }

      if (!(await openAsyncConfirm({ message: '답변을 등록하시겠습니까?' }))) {
        return
      }

      comParams.value.vMstRecordid = key
      comParams.value.vContents = commonUtils.convertEnterToHtml(
        comParams.value.vContents
      )

      goAnswerReg(comParams.value)

      //초기화
      comParams.value.vContents = ''
      answerArea.init()
    }

    const fnOpenAnswerModArea = (vo) => {
      if (answerList.value?.length > 1) {
        const otherAnswerModArea = answerList.value.filter(avo => avo.vSubRecordid !== vo.vSubRecordid)

        otherAnswerModArea.forEach(element => {
          element.vAnswerModAreaDispFlag = 'N'
        })
      }

      // vContentsMod.value = vo.vContents
      vContentsMod.value = commonUtils.replaceNewLineForTxt(vo.vContents)

      if (!vo.vAnswerModAreaDispFlag || vo.vAnswerModAreaDispFlag === 'N') {
        vo.vAnswerModAreaDispFlag = 'Y'
      } else {
        vo.vAnswerModAreaDispFlag = 'N'
      }
    }

    const fnAnswerMod = async (vo) => {
      if (commonUtils.isEmpty(vContentsMod.value)) {
        openAsyncAlert({ message: '답변을 입력해 주세요.' })
        return
      }

      if (!commonUtils.checkByte(vContentsMod.value, 3000)) {
        // 내용이 3000 Byte를 초과할 수 없습니다.
        await openAsyncAlert({
          message: t('common.msg.byte_msg2', { byteSize: 3000 }),
        })
        return
      }

      if (!await openAsyncConfirm({ message: '답변을 수정하시겠습니까?' })) {
        return
      }

      const payload = {
        vContents: vContentsMod.value,
        vMstRecordid: vo.vMstRecordid,
        vSubRecordid: vo.vSubRecordid,
      }

      goAnswerMod(payload)

      vo.vAnswerModAreaDispFlag = 'N'
    }

    //답변 삭제
    const fnAnswerDel = async (vo) => {
      if (!(await openAsyncConfirm({ message: '답변을 삭제하시겠습니까?' }))) {
        return
      }
      goAnswerDel({ ...vo })
    }

    //댓글 불러오기
    // const fnAnswerReq = (key, commCnt) => {
    //   if (commCnt <= 0) {
    //     openAsyncAlert({ message: '불러올 답변이 없습니다.' })
    //     return
    //   }
    //   comParams.value.vSubRecordid = key
    //   selectAnswerCommentList({ vSubRecordid: key })
    // }

    //댓글 삭제
    const fnAnswerCommentDel = async (subKey, key) => {
      if (!(await openAsyncConfirm({ message: '댓글을 삭제하시겠습니까?' }))) {
        return
      }

      goAnswerCommentDel({ vSubRecordid: subKey, vCmntRecordid: key })
    }

    const fnOpenComentArea = (vo) => {
      if (answerList.value?.length > 1) {
        const otherCommentArea = answerList.value.filter(avo => avo.vSubRecordid !== vo.vSubRecordid)

        otherCommentArea.forEach(element => {
          element.vCommentAreaDispFlag = 'N'
          element.vComments = ''
        })
      }

      vo.vComments = ''

      if (!vo.vCommentAreaDispFlag || vo.vCommentAreaDispFlag === 'N') {
        vo.vCommentAreaDispFlag = 'Y'
      } else {
        vo.vCommentAreaDispFlag = 'N'
      }
    }

    const fnCommentReg = (vo) => {
      if (commonUtils.isEmpty(vo.vComments)) {
        openAsyncAlert({ message: '댓글을 입력해 주세요.' })
        return
      }

      if (!commonUtils.checkByte(vo.vComments, 3000)) {
        const errorMsg = t('common.msg.byte_msg2', { byteSize: commonUtils.setNumberComma(3000) })

        openAsyncAlert({ message: errorMsg })   
        return     
      }

      goAnswerCommentReg(vo)
    }

    return {
      pathList,
      t,
      commonUtils,
      selectReqDetail,
      params,
      comParams,
      tagList,
      answerList,
      // commentList,
      list,
      goList,
      goModify,
      answerArea,
      key,
      goDel,
      fnDel,
      fnAnswerReg,
      fnAnswerDel,
      goAnswerReg,
      goAnswerDel,
      // fnAnswerReq,
      fnAnswerCommentDel,
      goAnswerCommentDel,
      isHide,
      myInfo,
      fnOpenComentArea,
      fnCommentReg,
      fnOpenAnswerModArea,
      fnAnswerMod,
      vContentsMod,
    }
  },
}
</script>

<style scoped>
.question-answers .comment-wrap .btnWrap {
  margin-top: 1.8rem;
}
.question-answers .comment-wrap .btnWrap button {
  height: 2.5rem;
  font-size: 1.2rem;
  color: #454545;
  line-height: 2.5rem;
}
.question-answers .comment-wrap .btnWrap button + button {
  margin-left: 0.5rem;
}
.question-answers .comment-wrap .bottomInfo {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: justify;
      -ms-flex-pack: justify;
          justify-content: space-between;
  -webkit-box-align: end;
      -ms-flex-align: end;
          align-items: flex-end;
}
.question-answers .comment-wrap .bottomInfo .info {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
}
.question-answers .comment-wrap .bottomInfo .info .name {
  font-size: 1.3rem;
  color: #000;
}
.question-answers .comment-wrap .bottomInfo .info .date {
  margin-left: 0.9rem;
  font-size: 1.3rem;
  color: #a6acb1;
}
.ui-textarea-box {
  padding: 1.3rem 0.9rem 0.9rem 0.9rem;
  border: 1px solid #cdd2d6;
  border-radius: 0.6rem;
  /* background: #ffffff; */
  -webkit-transition: all 0.2;
  transition: all 0.2;
}
</style>
