<template>
  <div class="page-tab multi-cont-view-page">
    <div class="page-tab__inner">
      <HistoryTab
        v-if="reqInfo && commonUtils.isNotEmpty(reqInfo.vContCd)"
        :v-lab-note-cd="vLabNoteCd"
        url-link="/hbd/all-lab-note-{pageType}-view?vLabNoteCd="
        @go-list="goList()"
      >
      </HistoryTab>

      <div class="page-tab__contents multi-cont-view-contents">
        <ap-breadcrumb
          nav-title="내용물 개요"
          :path-list="pathList"
        >
        </ap-breadcrumb>

        <div class="page-tab__item">
          <AllLabNoteBrandManagerBasicInfoView></AllLabNoteBrandManagerBasicInfoView>
        </div>
      </div>
    </div>

    <div class="contents-core">
      <div class="contents-cell__wrap">
        <div class="contents-cell">
          <div class="contents-box contents-box__full">
            <div class="contents-box__inner min-height__unset border-top-radius__unset">
              <HbdContInfoView></HbdContInfoView>
            </div>
          </div>

          <div class="contents-box contents-box__full">
            <div class="contents-box__inner min-height__unset">
              <AllLabNoteBrandManagerMarketingInfoView></AllLabNoteBrandManagerMarketingInfoView>
            </div>
          </div>
        </div>
      </div>

      <div class="page-bottom">
        <div class="page-bottom__inner">
          <div class="ui-buttons ui-buttons__right">
            <button type="button" class="ui-button ui-button__bg--skyblue" v-if="showModifyBtn()" @click="goModify()">수정</button>
            <button type="button" class="ui-button ui-button__border--gray" @click="goList()">목록</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineAsyncComponent, onMounted, onUnmounted, ref, provide, inject } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useHbdBMRegister } from '@/compositions/hbd/useHbdBMRegister'
import { useHbdRequest } from '@/compositions/hbd/useHbdRequest'

import uiUtils from '@/utils/uiUtils'
import AllLabNoteBrandManagerBasicInfoView from '@/components/hbd/AllLabNoteBrandManagerBasicInfoView.vue'
import AllLabNoteBrandManagerMarketingInfoView from '@/components/hbd/AllLabNoteBrandManagerMarketingInfoView.vue'
import HbdContInfoView from '@/components/hbd/HbdContInfoView.vue'

export default {
  name: 'AllLabNoteBrandManagerView',
  components: {
    AllLabNoteBrandManagerBasicInfoView,
    AllLabNoteBrandManagerMarketingInfoView,
    HbdContInfoView,
    HistoryTab: defineAsyncComponent(() => import('@/components/labcommon/HistoryTab.vue')),
  },
  setup () {
    const reqInfo = ref({})
    const router = useRouter()
    const route = useRoute()
    const commonUtils = inject('commonUtils')

    const {
      selectReqInfo,
    } = useHbdBMRegister()

    const {
      goList,
    } = useHbdRequest()

    const showModifyBtn = () => {
      let isVisible = false
      const arrStatusCd = ['LNC06_01', 'LNC06_21', 'LNC06_22']
      if (reqInfo.value && arrStatusCd.indexOf(reqInfo.value.vStatusCd) > -1) {
        isVisible = true
      }

      return isVisible
    }

    const goModify = () => {
      router.push({ path: '/hbd/all-lab-note-brand-manager-register', query: {vLabNoteCd: route.query.vLabNoteCd} })
    }

    const init = async () => {
      const vLabNoteCd = route.query.vLabNoteCd
      const result = await selectReqInfo({ vLabNoteCd })

      reqInfo.value = {...reqInfo.value, ...result}
    }

    init()
    provide('reqInfo', reqInfo)

    onMounted(() => {
      uiUtils.accordionEvent()
    })

    onUnmounted(() => {
      uiUtils.accordionEvent()
    })

    return {
      commonUtils,
      reqInfo,
      showModifyBtn,
      goModify,
      goList,
    }
  }
}
</script>