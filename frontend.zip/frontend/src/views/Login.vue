<template>
  <div class="login">
    <div class="login__inner">
      <div class="login-box">
        <div class="login-logo"><span class="for-a11y">my BEAKER LOGIN</span></div>
        <div class="login-text">사번 / 패스워드를 입력해 주세요</div>
        <div class="login-input">
          <div class="cell-col">
            <div class="ui-form form-input">
              <input type="text" class="ui-input ui-input__login" v-model="loginParams.loginId" placeholder="사번" autocomplete="false"/>
            </div>
          </div>
          <div class="cell-col">
            <div class="ui-form form-input">
              <input type="password" class="ui-input ui-input__login" v-model="loginParams.loginPwTemp" placeholder="Password" autocomplete="false" @keyup.enter="fnLogin()"/>
            </div>
          </div>

          <div class="save-id">
            <input type="checkbox" id="switch" true-value="Y" false-value="" v-model="loginChkFlag">
            <label for="switch" class="switch_label">
                <span class="onf_btn"></span>
            </label>
            <span class="save-id__text">아이디 저장</span>
          </div>

          <div class="login-button__wrap">
              <button type="button" class="login-button" @click="fnLogin()">로그인</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { sha512 } from 'js-sha512'
import { reactive, inject, ref } from "vue"
import { useStore } from 'vuex'
import { useRouter } from 'vue-router'
import { useCookies } from 'vue3-cookies'
import { useActions } from 'vuex-composition-helpers'
import { dynamicRouterInit } from '@/router/dynamicRouter'

export default {
  name: 'LoginPage',
  setup() {
    const t = inject('t')
    const store = useStore()
    const router = useRouter()
    const { cookies } = useCookies()
    const { openAsyncConfirm, openAsyncAlert } = useActions(['openAsyncConfirm', 'openAsyncAlert'])

    const loginParams = reactive({
      loginId: '',
      loginPwTemp: '',
      loginPw: ''
    })

    const loginChkFlag = ref('')

    const goFirstPage = (resData) => {
      if (loginChkFlag.value === 'Y') {
        cookies.set('saveLoginId', loginParams.loginId.trim(), '365d')
      } else {
        cookies.remove('saveLoginId')
      }

      const resultData = resData.data
      if (resultData.menuAuthList) {
        const menuAuthList = resultData.menuAuthList.filter(item => item.vRouter !== 'approval')
  
        if (menuAuthList && menuAuthList.length > 0) {
          router.push({ path: '/main' })
        } else {
          openAsyncAlert({ message: '마이비커 접속 권한이 없습니다.<br/>최초 로그인 시 연구인프라운영 Lab 박주열님에게<br/>접속 목적을 기입하여 메일 전달 바랍니다.<br/>jypark83@amorepacific.com'})
        }
      } else {
        const historyUrl = sessionStorage.getItem('historyUrl')
        if (!historyUrl) {
          openAsyncAlert({ message: '잘못된 접근입니다. 관리자에게 문의해주시기 바랍니다.'})
        } else {
          if (historyUrl.indexOf('brand-manager') > -1) {
            window.location.href = historyUrl
            sessionStorage.removeItem('historyUrl')
          }
        }
      }
    }

    const fnLogin = async (dupleYn = 'N') => {
      if (loginParams.loginId === '' || loginParams.loginPwTemp === '') {
        openAsyncAlert({ message: '아이디/비밀번호를 확인해 주세요.' })
        return
      }

      const params = {
        loginId: loginParams.loginId.trim(),
        loginPw: sha512(loginParams.loginPwTemp),
        loginDupleYn : dupleYn
      }

      store.dispatch('signin', params).then(async res => {
        const resData = res.data
        if (resData.code === 'C0000') {
          sessionStorage.removeItem('error401')
          //router.push({ path: '/main' })
          await dynamicRouterInit()
          goFirstPage(resData)
        } else if (resData.code === 'PW_EXPIRED' || resData.code === 'LOGIN_EXTERNAL') {
          openAsyncAlert({ message: resData.message })
        } else if (resData.code === 'PASS_FAIL') {
          const pwFailCnt = resData.data ? resData.data.pwFailCnt : 0
          //openAsyncAlert({ message: `아이디/비밀번호가 ${pwFailCnt}회 틀렸습니다.` })
          openAsyncAlert({ message: '아이디/비밀번호를 확인해 주세요.' })
        } else if (resData.code === 'NOT_FOUND') {
          openAsyncAlert({ message: '아이디/비밀번호를 확인해 주세요.' })
        } else if (resData.code === 'PASS_EXPIRE_SEVEN_DAY') {
          await openAsyncAlert({ message: resData.message })
          await dynamicRouterInit()
          goFirstPage(resData)
        } else if (resData.code === 'PASS_FAIL_LIMIT') {
          openAsyncAlert({ message: t('common.msg.pass_fail_limit_msg') + '<br>' + t('common.msg.pass_fail_limit_msg2') + '<br>' + t('common.msg.pass_fail_limit_msg3') })
        } else if (resData.code === 'USER_DUPLE') {
          if (await openAsyncConfirm({ message : '동일한 아이디로 로그인 된 이력이 존재합니다. 접속 하시겠습니까?' })) {
            fnLogin('Y')
          }
        } else {
          openAsyncAlert({ message: resData.message })
        }
      })
    }

    const init = async () => {
      const cookieId = cookies.get('saveLoginId')

      if (cookieId) {
        loginParams.loginId = cookieId
        loginChkFlag.value = 'Y'
      }
    }

    init()

    return {
      loginParams,
      fnLogin,
      loginChkFlag
    }
  }
}
</script>