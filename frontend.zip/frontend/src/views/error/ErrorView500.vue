<template>
  <div class="error-page__inner">
    <div class="error-text">
        <div class="error-text__code">500</div>
        <div class="error-text__text">페이지가 작동하지 않습니다.</div>
        <div class="error-text__detail">
          현재 요청을처리할 수 없습니다.
        </div>
    </div>
    <div class="error-img ">
      <img src="@/assets/images/etc/img-404.png" alt="">
    </div>
  </div>
</template>

<script>
export default {
  name: 'ErrorView500',
  setup () {
    return {}
  }
}
</script>