const common = {
  label: {
    approval: {}
  },
  msg: {}
}

common.label.approval.appr_line_designation = '결재선 지정'

export default common