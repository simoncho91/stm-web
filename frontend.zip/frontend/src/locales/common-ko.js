const common = {
  label: {
    approval: {},
    reference: {}
  },
  msg: {}
}
common.label.alert_ok = '확인'
common.label.confirm_ok = '확인'
common.label.confirm_cancel = '취소'
common.label.approval.appr_line_designation = '결재선 지정'
common.label.approval.appr_user_type01 = '결재자'
common.label.approval.appr_user_type02 = '합의자'
common.label.reference.reference_designation = '참조 지정'
common.label.search = '검색하기'
common.label.select = '선택'
common.label.download = '다운로드'

common.msg.server_err_msg = '작업중 오류가 발생하였습니다.'
common.msg.appr_msg01 = '최종결재자와 합의 하실 수 없습니다.'
common.msg.search_msg = '검색어를 입력하세요.'
common.msg.no_data = '조회 내용이 없습니다.'
common.msg.no_auth = '권한이 없습니다.'
common.msg.save_succ = '저장되었습니다.'
common.msg.already_select = '이미 선택하셨습니다.'
common.msg.upload_count_msg = "해당 첨부파일은 {count}개 이상 업로드하실 수 없습니다."
common.msg.byte_msg2 = "내용이 {byteSize} Byte를 초과할 수 없습니다."

common.msg.pass_fail_limit_msg = '비밀번호가 5회 잘못 입력되어 마이비커 계정이 잠김상태로 변경됩니다.<br>마이비커 비밀번호는 AP-ON과 동일합니다.<br>계정 잠김은 유지보수 담당자에게 메일로 발송해주세요.'
common.msg.pass_fail_limit_msg2 = '메일 발송 후 유선상(메신저, 전화)으로 연락해주시면 빠르게 처리 될 수 있습니다.<br>AP-ON 비밀번호 변경 시 자동으로 계정잠김은 해제되며<br>AP-ON 비밀번호를 다시 알아내신 경우에는 계정잠김해제 요청만 해주시면 됩니다.'
common.msg.pass_fail_limit_msg3 = '유지보수 담당자<br>남석현(AC912716 / 아이시프트 / SHNAM@AMOREPACIFIC.COM)<br>이강현(AC913916 / 아이시프트 / FOOLISHLK@AMOREPACIFIC.COM)'

export default common