import mainEn from './main-en'
import mainKo from './main-ko'
import commonEn from './common-en'
import commonKo from './common-ko'

const ko = {
  main: mainKo,
  common: commonKo
}

const en = {
  main: mainEn,
  common: commonEn
}

const messages = {
  ko,
  en
}

export default messages