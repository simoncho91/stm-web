import router from '@/router'
import { store } from '../store/index.js'

const gridRouter = (routerList) => {
  const routerMap = []
  const list = routerList
  //기존 @ shymbol은 롤업 제한 때문에 먹지 않는 상황
  //동적 ../ 주소는 빌드 할때 무슨 이유에서인지 정상 작동하지 않아
  //vite 기능 중 views 폴더안에 존재하는 모든 모듈 가져오는 glob 기능 사용 => vue 가져오기
  const vues = import.meta.glob('../views/**/*.vue')
  const subMenuList = []
  for(let i=0; i<list.length; i++) {
    routerMap.push(
      {
        path: `/${list[i].vRouter}`,
        name: `${list[i].vMenuid}_${list[i].vMenunm}`,
        redirect: `${list[i].vPageid}`,
        component: () => import('@/components/layout/LayoutMstPage.vue'),
        children: [],
        meta : { title: `${list[i].vMenunm}`, menuid: `${list[i].vMenuid}`}
      }
    )

    const subList = list[i].subList
    if(subList){
      subList.forEach(obj=>{
        if (obj.vLeftMenuYn === 'Y') {
          subMenuList.push(obj)
        }

        routerMap[(routerMap.length-1)].children.push({
          path: `${obj.vPageid}`,
          name: `${obj.vPageid}`,
          component: vues[`../views/${obj.vPageUrl}.vue`],
          meta : {title: `${obj.vMenunm}`, layout: `${obj.vLeftMenuYn === 'Y' ? 'detail' : ''}`, menuid: `${obj.vMenuid}`}
        })
      })
    }
  }
  routerMap.forEach(obj => {
    if(router.hasRoute(obj.name)){
      router.removeRoute(obj.name)
    }
    router.addRoute(obj)
  })

  store.dispatch('setSubMenuList', subMenuList)
}

const setDefault = async () => {
  const loginId = store.getters.getMyInfo().loginId

  if (loginId) {
    let routerList = JSON.parse(sessionStorage.getItem('routerList'))
    if (routerList && routerList.length > 0) {
      gridRouter(routerList)
    } else {
      await store.dispatch('findRouter').then(async resData => {
        if (resData.data.code === 'C0000') {
          gridRouter(resData.data.data)
        }
      })
    }
  }
}

export const dynamicRouterInit = async () => {
  await setDefault()
}