import { nextTick } from 'vue'
import { createRouter, createWebHistory } from "vue-router"
import { store } from '../store/index.js'

/*
 webpackChunkName : component import 파일 생성 시 이름 지정
 webpackPrefetch: true 무거운 compoent들을 미리 호출하여 웹 캐시에 저장하는 속성
*/

import Main from '@/views/Main.vue'

const routes = [
  {
    path: '/:pathMatch(.*)*',
    redirect: "/error/404"
  },
  {
    path: "/error",
    name: "error",
    component: () => import('@/components/layout/LayoutBlank.vue'),
    meta: {
      layout: 'error',
      authAnyone: true,
      title: ''
    },    
    children: [
      {
        path: "404",
        name: "error-404",
        component: () => import('@/views/error/ErrorView404.vue')
      },
      {
        path: "500",
        name: "error-500",
        component: () => import('@/views/error/ErrorView500.vue')
      }      
    ]
  },
  {
    path: '/',
    name: 'home',
    component: Main,
    meta: {
      title: '메인',
      layout: 'blank'
    }
  },
  {
    path: '/main',
    name: 'main',
    component: Main,
    meta: {
      title: '메인',
      layout: 'blank'
    }
  },
  {
    path: '/login',
    name: 'login',
    component: () => import('@/views/Login.vue'),
    meta: {
      authAnyone: true,
      title: '로그인',
      layout: 'blank'
    }
  },
  {
    path: '/makeup/all-lab-note-brand-manager-register',
    name: 'AllLabNoteMakeupBrandManagerRegister',
    component: () => import('@/views/makeup/AllLabNoteBrandManagerRegister.vue'),
    meta: {
      title: '내용물 개요',
    }
  },
  {
    path: '/makeup/all-lab-note-brand-manager-view',
    name: 'AllLabNoteMakeupBrandManagerView',
    component: () => import('@/views/makeup/AllLabNoteBrandManagerView.vue'),
    meta: {
      title: '내용물 개요',
      layout: 'detail',
    }
  },
  {
    path: '/hbd/all-lab-note-brand-manager-register',
    name: 'AllLabNoteHbdBrandManagerRegister',
    component: () => import('@/views/hbd/AllLabNoteBrandManagerRegister.vue'),
    meta: {
      title: '내용물 개요',
    }
  },
  {
    path: '/hbd/all-lab-note-brand-manager-view',
    name: 'AllLabNoteHbdBrandManagerView',
    component: () => import('@/views/hbd/AllLabNoteBrandManagerView.vue'),
    meta: {
      title: '내용물 개요',
      layout: 'detail',
    }
  },
  // {
  //   path: '/ComponentPage',
  //   name: 'ComponentPage',
  //   component: () => import('@/views/test/ComponentPage.vue'),
  //   meta: {
  //     title: 'test'
  //   }
  // },
  // {
  //   path: '/PopupPage',
  //   name: 'PopupPage',
  //   component: () => import('@/views/test/PopupPage.vue'),
  //   meta: {
  //     title: '팝업 목록'
  //   }
  // },
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach((to,from) => {
  //에러 페이지에 왔는데 로그인이 안되어 있는 상태이면
  //로그인 페이지로 보낸다.
  if(to.fullPath.indexOf('error') > -1){
    const historyUrl = window.location.href
    if (historyUrl.indexOf('/login') === -1) {
      sessionStorage.setItem('historyUrl', historyUrl)
    }
    const myInfo = store.getters.getMyInfo()
    if(!myInfo.loginId){
     router.push({ path: '/login' })
    }
  }
  const title = to.meta.title === undefined ? '' : 'MY BEAKER > ' + to.meta.title;
  nextTick(() => {
    document.title = title;
  });  
})

router.onError((error) => {
  console.log('router error 발생', error)
})
export default router