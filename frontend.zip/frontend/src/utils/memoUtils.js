
const memoUtils = {
  left: 0,
  top: 0,
  clickElem: null,
  bodyRect: null,
  opts: undefined,
  init: (opts) => {
    memoUtils.opts = opts
  },
  addEvents: () => {
    memoUtils.addEventContextMenu()
  },
  addEventContextMenu: () => {
    const {
      memoWrap,
      contextMenuWrap,
    } = memoUtils.opts

    contextMenuWrap.value.addEventListener('contextmenu', (e) => {
      e.preventDefault()
    })

    memoWrap.value.addEventListener('contextmenu', (e) => {
      e.preventDefault()
    })
  },
  mouseDownEvent: (e) => {
    if (e.which === 3) {
      const {
        memoWrap,
        contextMenu,
      } = memoUtils.opts

      const memoArea = memoUtils.getMemoArea(e.target)
      if (!memoArea) {
        return
      }

      const rect = memoWrap.value.getBoundingClientRect()

      const memoElem = Array.from(document.querySelectorAll('.myboard-memo__item'))
      const index = memoElem.indexOf(memoArea)
      //contextMenu.isShow = true
      contextMenu.contextMenuStyle.left = e.x - rect.left - 10 + 'px'
      contextMenu.contextMenuStyle.top = e.y - rect.top + 'px'
      contextMenu.index = index
      contextMenu.isShow = true
    }
  },
  getMemoArea: (target) => {
    if (!target) {
      return undefined
    }

    if (target.tagName === 'DIV' && (
      target.classList.contains('myboard-memo__item')
    )) {
      return target.querySelectorAll('div.myboard-memo__item')[0]
    } else {
      return memoUtils.findParentElement(target, 'DIV', 'myboard-memo__item')
    }
  },
  hasClass: (target, clsName) => {
    const pattern = new RegExp('(^| )' + clsName + '( |$)')
    if (target && pattern.test(target.className) && pattern.test(target.className) !== undefined) {
      return true
    } else {
      return false
    }
  },
  onClick: (e) => {
    const {
      contextMenu,
    } = memoUtils.opts

    if (contextMenu.isShow) {
      contextMenu.isShow = false
    }
  },
  findParentElement: ($target, tagName, className) => {
    if (memoUtils.isElementTarget($target, tagName, className)) {
      return $target
    }

    let $findElem
    let $elem = $target
    let isLoop = true
    let cnt = 0
    while (isLoop) {
      $elem = $elem.parentElement

      if ($elem && $elem.tagName === 'BODY') {
        isLoop = false
      } else if (memoUtils.isElementTarget($elem, tagName, className)) {
        $findElem = $elem
        isLoop = false
      } else {
        cnt++
        if (cnt > 100) {
          isLoop = false
        }
      }
    }
    return $findElem
  },
  isElementTarget: ($target, tagName, className) => {
    if (tagName && className) {
      if (
        $target && $target.tagName === tagName.toUpperCase() &&
        memoUtils.hasClass($target, className)
      ) {
        return true
      }
    } else if (tagName) {
      if ($target.tagName === tagName.toUpperCase()) {
        return true
      }
    } else if (className) {
      if (memoUtils.hasClass($target, className)) {
        return true
      }
    }
    return false
  },
}

export default memoUtils