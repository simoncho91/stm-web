
export default {
  headerItemClickEvent () {
    const headerMenuLink = document.querySelectorAll('.header-menu__link')
    for (let i = 0; i < headerMenuLink.length; i++) {
      headerMenuLink[i].addEventListener('click', (e) => {
        const headerMenuItem = Array.from(document.querySelectorAll('.header-menu__item'))
        const isActive = document.querySelector('.header-menu__item.is-active')

        if (isActive) {
          const itemIdx = headerMenuItem.indexOf(isActive)
          if (i !== itemIdx) {
            isActive.classList.remove('is-active')
          }
        }

        const parent = e.target.parentElement
        parent.classList.toggle('is-active')
      })
    }
  },
  leftMenuOpenEvent () {
    const leftMenuButton = document.querySelector('.left-menu__button')
    const leftMenu = document.querySelector('.left-menu')

    if (leftMenuButton) {
      leftMenuButton.addEventListener('click', () => {
        leftMenu.classList.toggle('is-open')

        if (leftMenu.classList.value.indexOf('is-open') > -1) {
          document.querySelector('#recent-filter-area').classList.add('filter-open')
        } else {
          document.querySelector('#recent-filter-area').classList.remove('filter-open')
        }
      })
    }

    const btnFilterShow = document.querySelector('.button-filter__show')
    if (btnFilterShow) {
      btnFilterShow.addEventListener('click', () => {
        document.querySelector('.is-filter').classList.toggle('is-filter__open')
        document.querySelector('.filter-lists').classList.toggle('filter-open')
      })
    }
  },
  tabInit (mstId) {
    const tabMst = document.querySelector('#' + mstId)
    const currentActive = tabMst.querySelector('.ap_li_tab_item.is-active')

    if (!currentActive) {
      return
    }

    const tabWrap = tabMst.closest('.ap_contents_tab')

    if (tabWrap) {
      const body = tabWrap.querySelectorAll('.contents-tab__body')

      for (let i = 0; i < body.length; i++) {
        body[i].style.display = 'none'
      }

      const tabContentArea = document.querySelector('#' + currentActive.getAttribute('for'))
      if (tabContentArea) {
        tabContentArea.style.display = 'block'
      }
    }
  },
  tabEvent (mstId) {
    const tabMst = document.querySelector('#' + mstId)
    const tabList = tabMst.querySelectorAll('.ap_li_tab_item')
    const tabListItem = Array.from(tabMst.querySelectorAll('.ap_li_tab_item'))
    for (let i = 0; i < tabList.length; i++) {
      if(tabList[i].classList.contains('slot')) {
        continue
      }

      tabList[i].addEventListener('click', (e) => {
        const isActive = tabMst.querySelector('.ap_li_tab_item.is-active')
        if (isActive) {
          const itemIdx = tabListItem.indexOf(isActive)

          if (i !== itemIdx) {
            isActive.classList.remove('is-active')
            
            const contentArea = document.querySelector('#' + isActive.getAttribute('for'))

            if (contentArea) {
              contentArea.style.display = 'none'
            }
          }
        }

        const parent = e.target.parentElement
        parent.classList.add('is-active')

        const clickTabContent = document.querySelector('#' + parent.getAttribute('for'))
        if (clickTabContent) {
          clickTabContent.style.display = 'block'
        }
      })
    }
  },
  accordionEvent () {
    const accorBtn = document.querySelectorAll('.ui-button__accordion')

    for (let i = 0; i < accorBtn.length; i++) {
      accorBtn[i].addEventListener('click', (e) => {
        const accorItem = e.target.parentElement.closest('.arrordion-item')
        accorItem.classList.toggle('is-active')
      })
    }
  }
}