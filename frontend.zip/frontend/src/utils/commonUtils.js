import { useStore } from 'vuex'
import sanitizeHtml from '@/utils/sanitizeHtml'
import Big from 'big.js'

export default {
  /**
   * 권한 체크
   * 시스템 관리자(SGG000001)는 모든 권한 부여(Default)
   * @param {*} groupStr - 허용되는 그룹(Multi 작성 시, '|'로 구분), ex) 'SGG000003', 'SGG000005|SGG000007'
   * @returns
   */
  checkAuth (groupStr) {
    if (!groupStr && typeof groupStr !== 'string') return false

    groupStr = `${!this.isEmpty(groupStr) ? '|' : ''}${groupStr ?? ''}`

    const store = useStore()
    const myInfo = store.getters.getMyInfo()

    if (myInfo === undefined || myInfo.groups === undefined || myInfo.groups.length === 0) {
      return false
    }

    const auth = myInfo.groups.some(group => groupStr.indexOf(group) > -1)

    return auth
  },
  isEmpty (val) {
    if (val === null || val === undefined) {
      return true
    }

    if (typeof val === 'string') {
      if (val.trim() === '') {
        return true
      } else {
        return false
      }
    } else if (typeof val === 'object') {
      if (Object.keys(val).length === 0) {
        return true
      } else {
        return false
      }
    } else if (typeof val === 'number') {
      if (val === null) {
        return true
      } else {
        return false
      }
    }
    return true
  },
  isNotEmpty (val) {
    return !this.isEmpty(val)
  },
  capitalize (str) {
    if (this.isEmpty(str)) {
      return ''
    }

    return str.charAt(0).toUpperCase() + str.slice(1)
  },
  convertDt (dt) {
    if (dt === undefined) {
      return ''
    }
    return dt.substring(0, 10)
  },
  // 20230323 => Date()
  parseDate (str) {
    if (str.length < 8) {
      return null
    }

    const year = str.substr(0, 4)
    const month = str.substr(4, 2)
    const day = str.substr(6, 2)

    return new Date(year, Number(month) - 1, day)
  },
  parseDateToStr (dt) {
    if (dt === null || dt === undefined) {
      return ''
    }

    const y = dt.getFullYear()
    const m = dt.getMonth() + 1
    const d = dt.getDate()

    return '' + y +  (m > 9 ? m : '0' + m) + (d > 9 ? d : '0' + d)
  },
  // 2022-04-28 => Date()
  convertStrToDate (str, schar = '.') {
    if (str === null || str === undefined) {
      return null
    }
    
    let arr = str.split(schar)
    if(str.indexOf(schar) < 0) {
      str = this.changeStrDatePattern(str)
      arr = str.split(schar)
    }
    else if (arr.length < 3) {
      return null
    }

    return new Date(parseInt(arr[0], 10), parseInt(arr[1], 10) -1, parseInt(arr[2], 10))
  },
  // 2022-04-28 16:00 => Date()
  convertStrToDateTime (str, schar = '.') {
    if (!str) {
      return null
    }
    const arr = str.split(' ')
    if (arr.length < 2) {
      return null
    }
    const dateArr = arr[0].split(schar)
    if (dateArr.length < 3) {
      return null
    }
    const timeArr = arr[1].split(':')
    if (timeArr.length < 2) {
      return null
    }

    return new Date(parseInt(dateArr[0], 10), parseInt(dateArr[1], 10) -1, parseInt(dateArr[2], 10), parseInt(timeArr[0], 10), parseInt(timeArr[1], 10))
  },
  // 현재 날짜 가져오기 (YYYY-MM-DD)
  getToday () {
    let today = new Date()
    let year = today.getFullYear() //연도
    let month = ('0' + (today.getMonth() + 1)).slice(-2) //월
    let date = ('0' + today.getDate()).slice(-2) //날짜

    return year + '-' + month + '-' + date
  },
  // Date() => 2022-04-28
  convertDateToStr (dt, sChar = '') {
    if (dt === null || dt === undefined) {
      return ''
    }
    const y = dt.getFullYear()
    const m = dt.getMonth() + 1
    const d = dt.getDate()

    return y + sChar + (m > 9 ? m : '0' + m) + sChar + (d > 9 ? d : '0' + d)
  },
  // Date() => 2022-04-28 16:00
  convertDateTimeToStr (dt, sChar = '') {
    if (!dt) {
      return ''
    }
    const y = dt.getFullYear()
    const m = dt.getMonth() + 1
    const d = dt.getDate()
    const hours = dt.getHours()
    const minutes = dt.getMinutes()

    return `${y}${sChar}${m > 9 ? m : '0' + m}${sChar}${d > 9 ? d : '0' + d} ${hours > 9 ? hours : '0' + hours}:${minutes > 9 ? minutes : '0' + minutes}`
  },
  calcDday (strStDt, strEnDt) {
    if (this.isEmpty(strStDt) || this.isEmpty(strEnDt)) {
      return
    }

    const stYear = strStDt.substring(0, 4)
    const stMonth = strStDt.substring(4, 6)
    const stDay = strStDt.substring(6, 8)

    const enYear = strEnDt.substring(0, 4)
    const enMonth = strEnDt.substring(4, 6)
    const enDay = strEnDt.substring(6, 8)

    const stDate = new Date(stYear + '-' + stMonth + '-' + stDay)
    const enDate = new Date(enYear + '-' + enMonth + '-' + enDay)

    const betweenMs = enDate.getTime() - stDate.getTime()
    const calcDay = betweenMs / (1000 * 60 * 60 * 24)
    const betweenDay = Math.sign(calcDay) === -1 ? ('+' + Math.abs(calcDay)) : ('-' + Math.abs(calcDay))
    return betweenDay
  },
  getAddDay (strDate, addDay, char = '.') {
    let date = null

    if (this.isEmpty(strDate)) {
      date = new Date()
    } else {
      const year = strDate.substring(0, 4)
      const month = strDate.substring(4, 6)
      const day = strDate.substring(6, 8)
      date = new Date(Number(year), Number(month) - 1, Number(day))
    }

    let returnDate = new Date(date.setDate(date.getDate() + addDay))

    const year = returnDate.getFullYear()
    let month = returnDate.getMonth() + 1
    month = month < 10 ? '0' + month : month

    let day = returnDate.getDate()
    day = day < 10 ? '0' + day : day

    return year + char + month + char + day
  },
  /**
   * 에디터 설정 파일
   * @returns
   */
  getEditorConfig () {
    const store = useStore()
    const accessToken = store.getters.getAccessToken()
    return {
      uploader: {
        url: '/upload/images',
        format: 'json',
        insertImageAsBase64URI: false,
        headers: {
          'authorization': accessToken
        },
        data: {},
        error: (e) => {
          console.log('Editor Error', e)
        },
        isSuccess: (resp) => {
          //console.log('isSuccess :', resp)
          return resp.success
        },
        getMessage: (resp) => {
          return resp.data.message
        }
      }
    }
  },
  historyBack() {
    window.history.back();
  },
  compNumFormat (number) {
    if(!number || isNaN(number)){
      return ''
    }

    if(typeof(number) !== 'string'){
      number = number.toString()
    }

    if(number.length === 10){
      return number.replace(/(\d{3})(\d{2})(\d{5})/, "$1-$2-$3")
    }
    return number
  },
  phoneFormat (number) {
    if(!number || isNaN(number)){
      return ''
    }

    if(typeof(number) !== 'string'){
      number = number.toString()
    }

    if(number.length === 10){
      return number.replace(/(\d{3})(\d{3})(\d{4})/, "$1-$2-$3")
    } else if(number.length > 10){
      return number.replace(/(\d{3})(\d{4})(\d{4})/, "$1-$2-$3")
    }
    return number
  },
  resetValue(obj, arrKey) {
    if (arrKey === undefined || arrKey.length === 0) {
      return
    }

    for (const key of arrKey) {
      obj[key] = ''
    }
  },
  isNumber (e) {
    e = e ? e : window.event
    const charCode = (e.which) ? e.which : e.keyCode
    if ((charCode > 31 && (charCode < 48 || charCode > 57)) && charCode !== 46) {
      e.preventDefault()
    } else {
      return true
    }
  },
  getOnlyNumber (str) {
    if (!str) {
      return ''
    }

    return str.replace(/[^0-9]/g, '')
  },
  maskingContent (str) {
    let originStr = str
		let maskingStr

		if(originStr === '' || originStr === undefined){
			return ''
		}
    maskingStr = originStr.replace(/(?<=.{0})./gi, "*")

    return maskingStr
  },
  protectionInfo () {
    document.onselectstart = function (e) {
      return false;
    }
    document.addEventListener("keyup", function (e) {
      const keyCode = e.keyCode ? e.keyCode : e.which;
      if (keyCode == 44) {
        var inpFld = document.createElement("input");
        inpFld.setAttribute("value", ".");
        inpFld.setAttribute("width", "0");
        inpFld.style.height = "0px";
        inpFld.style.width = "0px";
        inpFld.style.border = "0px";
        document.body.appendChild(inpFld);
        inpFld.select();
        document.execCommand("copy");
        inpFld.remove(inpFld);
      }
    });
  },
  noProtectionInfo () {
    document.onselectstart = function (e) {
      return true;
    }
    document.removeEventListener("keyup", function (e) {});
  },
  compareObject (obj1, obj2, excludeKeys) {
    const diffKeys = []

    if (!obj1 || !obj2 || (obj1.constructor !== obj2.constructor)) {
      diffKeys.push('ERROR_CONSTRUCTOR')
      return diffKeys
    }

    const keyLists = Object.keys(obj1)
    const len = keyLists.length
    let key

    for (let i = 0; i < len; i++) {
      key = keyLists[i]
      if (this.isDiffObject(obj1, obj2, key, excludeKeys, '')) {
        diffKeys.push(key)
      }
    }

    return diffKeys
  },
  // 변경 체크 제외 key 인지 체크
  isExcludeKeys (key, excludeKeys, parentKey) {
    const defExcludeKeys = ['regUserCd', 'regDtm', 'updUserCd', 'updDtm']
    const f1 = defExcludeKeys.find(k => k === key)
    if (f1) {
      return true
    }
    if (excludeKeys === null || excludeKeys === undefined) {
      return false
    }

    if (parentKey === null || parentKey === undefined) {
      parentKey = ''
    }

    const f2 = excludeKeys.find(k => {
      if (k.indexOf('.') > -1) {
        return k === parentKey + '.' + key
      } else {
        return k === key
      }
    })

    if (f2) {
      return true
    } else {
      return false
    }
  },
  isDiffObject (obj1, obj2, key, excludeKeys, parentKey) {
    if (this.isExcludeKeys(key, excludeKeys, parentKey)) {
      return false
    }

    if ((obj1[key] === null || obj1[key] === undefined || obj1[key] === '') && (obj2[key] === null || obj2[key] === undefined)) {
      return false
    }
    if ((obj1[key] !== null && obj1[key] !== undefined) && (obj2[key] === null || obj2[key] === undefined)) {
      return true
    }
    if ((obj1[key] === null || obj1[key] === undefined) && (obj2[key] !== null && obj2[key] !== undefined)) {
      return true
    }

    if (excludeKeys === null || excludeKeys === undefined) {
      excludeKeys = []
    }
    if (parentKey === null || parentKey === undefined) {
      parentKey = ''
    }

    const o1 = obj1[key]
    const o2 = obj2[key]
    const t1 = typeof o1
    const t2 = typeof o2

    if (t1 !== t2) {
      return true
    }

    if (t1 === 'object') {
      if (o1.constructor === Object && o2.constructor !== Object) {
        return true
      } else if (o1.constructor === Array && o2.constructor !== Array) {
        return true
      }

      if (o1.constructor === Object && o2.constructor === Object) {
        const keyLists = Object.keys(o1)
        const len = keyLists.length
        const tempParentKey = parentKey === '' ? key : parentKey + '.' + key
        const tempExcludeKeys = excludeKeys.filter(k => k.indexOf(tempParentKey + '.') === 0)

        for (let i = 0; i < len; i++) {
          if (this.isDiffObject(o1, o2, keyLists[i], tempExcludeKeys, tempParentKey)) {
            return true
          }
        }
      } else if (o1.constructor === Array && o2.constructor === Array) {
        const len1 = o1.length
        const len2 = o2.length

        if (len1 !== len2) {
          return true
        }

        const tempParentKey = parentKey === '' ? key : parentKey + '.' + key
        const tempExcludeKeys = excludeKeys.filter(k => k.indexOf(tempParentKey + '.') === 0)

        for (let i = 0; i < len1; i++) {
          if (o1[i].constructor === Object) {
            const keyLists = Object.keys(o1[i])
            const len = keyLists.length
            for (let j = 0; j < len; j++) {
              if (this.isDiffObject(o1[i], o2[i], keyLists[j], tempExcludeKeys, tempParentKey)) {
                return true
              }
            }
          } else {
            if (o1[i] !== o2[i]) {
              return true
            }
          }
        }
      } else if (o1 !== o2) {
        return true
      }
    } else if (o1 !== o2) {
      return true
    }
    return false
  },
  checkByte (byteString, maxLength) {
    if (!byteString) {
      return true
    }

    if (!maxLength || typeof byteString !== 'string' || typeof maxLength !== 'number') {
      return false
    }

    const byteLength = ((s, b,i,c) => {
      for(b=i=0;c=s.charCodeAt(i++);b+=c>>11?3:c>>7?2:1);
      return b
    })(byteString)

    return byteLength > maxLength ? false : true
  },
  calcByte (val) {
    let tcount = 0
    let tmpStr = String(val)
    let onechar = ''
    let k = ''
    const len = tmpStr.length

    for (k = 0; k < len; k++) {
      onechar = tmpStr.charAt(k)
      if (escape(onechar).length > 4) {
        tcount += 3
      } else {
        tcount += 1
      }
    }

    return tcount
  },
  setNumberComma (val) {
    return String(val).replace(/\B(?=(\d{3})+(?!\d))/g, ',')
  },
  convertEnterToHtml (val) {
    if (!val) return ''

    return val.replace(/(\n|\r\n)/g,'<br/>')
  },
  changeStrDatePattern (strDt, sChar = '.', timeFlag = 'N') {
    if (!strDt) {
      return ''
    }

    const strLen = strDt.length

    if (strLen >= 14) {
      const year = strDt.substring(0, 4)
      const month = strDt.substring(4, 6)
      const day = strDt.substring(6, 8)
      const hour = strDt.substring(8, 10)
      const minute = strDt.substring(10, 12)
      const second = strDt.substring(12, 14)

      if (timeFlag === 'Y') {
        return year + sChar + month + sChar + day + ' ' + hour + ':' + minute + ':' + second
      } else {
        return year + sChar + month + sChar + day
      }
    } else if (strLen >= 8) {
      const year = strDt.substring(0, 4)
      const month = strDt.substring(4, 6)
      const day = strDt.substring(6, 8)

      return year + sChar + month + sChar + day
    } else if (strLen >= 6) {
      const year = strDt.substring(0, 4)
      const month = strDt.substring(4, 6)

      return year + sChar + month
    } else {
      return strDt
    }
  },
  changeStrDatePattern2 (strDt, sChar = '.', timeFlag = 'N') {
    if (!strDt) {
      return ''
    }

    const strLen = strDt.length

    if (strLen >= 14) {
      const year = strDt.substring(2, 4)
      const month = strDt.substring(4, 6)
      const day = strDt.substring(6, 8)
      const hour = strDt.substring(8, 10)
      const minute = strDt.substring(10, 12)
      const second = strDt.substring(12, 14)

      if (timeFlag === 'Y') {
        return year + sChar + month + sChar + day + ' ' + hour + ':' + minute + ':' + second
      } else {
        return year + sChar + month + sChar + day
      }
    } else if (strLen >= 8) {
      const year = strDt.substring(0, 4)
      const month = strDt.substring(4, 6)
      const day = strDt.substring(6, 8)

      return year + sChar + month + sChar + day
    } else if (strLen >= 6) {
      const year = strDt.substring(0, 4)
      const month = strDt.substring(4, 6)

      return year + sChar + month
    } else {
      return strDt
    }
  },
  changeStrDateForKorean (strDt, dayYn = 'Y') {
    if (!strDt) {
      return ''
    }
    
    if (strDt.length < 8) {
      return ''
    }

    const weekday = ['일요일', '월요일', '화요일', '수요일', '목요일', '금요일', '토요일']

    const convertDt = this.changeStrDatePattern(strDt, '-')
    const date = new Date(convertDt)
    const n = date.getDay();

    const year = strDt.substring(0, 4)
    const month = strDt.substring(4, 6)
    const day = strDt.substring(6, 8)

    let result = ''
    if (dayYn === 'Y') {
      result = year + '년 ' + month + '월 ' + day + "일"
    } else {
      result = year + '년 ' + month + '월 ' + day + "일 " + weekday[n]
    }

    return result
  },
  changeStrTmForKorean (strTm) {
    if (!strTm) {
      return ''
    }

    if (strTm.length < 4) {
      return ''
    }

    strTm = strTm.substring(0, 4)

    const calcTime = Number(strTm) - 1200
    const calcTimeResult = Math.sign(calcTime)
    if (calcTimeResult === -1) {
      return '오전 ' + strTm.substring(0, 2)+ ':' + strTm.substring(2, 4)
    } else if (calcTimeResult === 1) {
      const time = String(calcTime).length === 3 ? '0' + String(calcTime) : calcTime
      return '오후 ' + time.substring(0, 2)+ ':' + strTm.substring(2, 4)
    } else {
      return '오후 ' + strTm.substring(0, 2)+ ':' + strTm.substring(2, 4)
    }
  },
  hideErrorMessage (key) {
    const parent = document.querySelector('#error_wrap_' + key)
    if (parent) {
      parent.classList.remove('error')
      parent.querySelector('#error_msg_' + key).innerHTML = ''
    }
  },
  showErrorMessage (key, message = '필수 입력 사항입니다.') {
    const parent = document.querySelector('#error_wrap_' + key)
    if (parent) {
      parent.classList.add('error')
      parent.querySelector('#error_msg_' + key).innerHTML = message
    }
  },
  hideErrorMessageAll (arrKey) {
    if (!Array.isArray(arrKey) || arrKey.length === 0) {
      return
    }

    for (const key of arrKey) {
      this.hideErrorMessage(key)
    }
  },
  checkPostPosition (word, arrPostPosition) {
    const charCode = word.charCodeAt(word.length - 1)

    const consonantCode = (charCode - 44032) % 28
    if (consonantCode === 0) {
      return `${word}` + arrPostPosition[1]
    }

    return `${word}` + arrPostPosition[0]
  },
  // 소수점 자리수 표기
  getDecimalPointFormat (number, numFix = '6') {
    if (!number) {
      return 0
    }

    if (number.constructor === Big) {
      number = number.toNumber()
    }

    const dotStr = number.toString().split('.')
    if (!dotStr || dotStr.length <= 1) {
      return dotStr ? dotStr[0] : number
    }

    const int = dotStr[0]
    const decimal = dotStr[1].slice(0, numFix)
    return parseFloat(`${int}.${decimal}`)
  },
  removeHTMLTag (P) {
    return sanitizeHtml(P).replace(/<(\/)?([a-zA-Z]*)(\s[a-zA-Z]*=[^>]*)?(\s)*(\/)?>/g,"");
  },
  removeHTMLChangeBr (str) {
    if (!str) {
      return ''
    }

    return sanitizeHtml(str).replace(/(?:\r\n|\r|\\r|\n|\\n)/g, '<br />')
  },
  removeXSS (P) {
    return sanitizeHtml(P)
  },
  replaceNewLineForTxt (str) {
    if (!str) {
      return ''
    }

    return str.replace(/<br \/>|<br\/>/gi, '\n')
  },
  // useCode.js 의 Computed codeGroupMaps 결과값 Filter 하여 데이터 추출
  getCodeList (codeGroupMaps, vMstCode, vBuffer1, vBuffer2, vBuffer3) {
    if(!vMstCode) {
      return '';
    }

    return codeGroupMaps.value[vMstCode].filter((code) =>
      vBuffer1
        ? this.isNotEmpty(code.vBuffer1) && code.vBuffer1.indexOf(vBuffer1) > -1
        : 1 === 1 && vBuffer2
        ? this.isNotEmpty(code.vBuffer2) && code.vBuffer2.indexOf(vBuffer2) > -1
        : 1 === 1 && vBuffer3
        ? this.isNotEmpty(code.vBuffer3) && code.vBuffer3.indexOf(vBuffer3) > -1
        : 1 === 1
    )
  },
  getByteSize (size) {
    const byteUnits = ["KB", "MB", "GB", "TB"];
  
    for (let i = 0; i < byteUnits.length; i++) {
      size = Math.floor(size / 1024);
  
      if (size < 1024) return size.toFixed(1) + byteUnits[i];
    }
  }
}