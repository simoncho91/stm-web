import { nextTick } from 'vue'
import Big from 'big.js'

/* eslint-disable */
const mixmatUtils = {
  opts: undefined,
  init: (opts) => {
    mixmatUtils.opts = opts
  },
  getRateVo: (vLotCd, vMatePkCd) => {
    const { gridVars } = mixmatUtils.opts

    if (!gridVars.ratesMap) {
      gridVars.ratesMap = {}
    }
    let rateVo = gridVars.ratesMap[`${vLotCd}_${vMatePkCd}`]

    if (!rateVo) {
      let newRateVo = {
        vLotCd,
        vMatePkCd,
      }
      gridVars.ratesMap[`${vLotCd}_${vMatePkCd}`] = newRateVo
      return newRateVo
    }
    return rateVo
  },
  getRateAutoVo: (vLotCd) => {
    const { gridVars } = mixmatUtils.opts
    if (!gridVars.ratesMap) {
      return undefined
    }

    let rateVo

    for (let mateVo of gridVars.materials) {
      rateVo = mixmatUtils.getRateVo(vLotCd, mateVo.vMatePkCd)

      if (rateVo.flagAuto === 'Y') {
        return rateVo
      }
    }

    return undefined
  },
  getGridCell: ($target) => {
    if (!$target) {
      return undefined
    }

    if (
      $target.tagName === 'TD' &&
      mixmatUtils.hasClass($target, 'anypjt-grid-td')
    ) {
      return $target.querySelectorAll('div.anypjt-grid-cell')[0]
    }
    return mixmatUtils.findParentElement($target, 'DIV', 'anypjt-grid-cell')
  },
  isGridCell: ($target) => {
    if (!$target) {
      return false
    }

    let $cell

    if (
      $target.tagName === 'TD' &&
      mixmatUtils.hasClass($target, 'anypjt-grid-td')
    ) {
      $cell = $target.querySelectorAll('div.anypjt-grid-cell')[0]
    } else {
      $cell = mixmatUtils.findParentElement($target, 'DIV', 'anypjt-grid-cell')
    }

    if ($cell) {
      return true
    } else {
      return false
    }
  },
  hasClass: (target, clsName) => {
    const pattern = new RegExp('(^| )' + clsName + '( |$)')
    if (target && pattern.test(target.className)) {
      return true
    } else {
      return false
    }
  },
  addClass: (target, clsName) => {
    if (!target || mixmatUtils.hasClass(target, clsName)) {
      return
    }

    target.classList.add(clsName)
  },
  removeClass: (target, clsName) => {
    if (!target || !mixmatUtils.hasClass(target, clsName)) {
      return
    }

    target.classList.remove(clsName)
  },
  addEvents: () => {
    const {
      scrollPostion,
      refDivHeaderCenter,
      refTableBodyLeft,
      refTableBodyCenter,
      refDivBodyScrollX,
      refDivBodyScrollY,
      refContextMenuWrap,
    } = mixmatUtils.opts

    // Y scroll 이동시
    if (refDivBodyScrollY.value) {
      // refDivBodyScrollY.value.addEventListener('scroll', (e) => {
      //   scrollPostion.top = e.target.scrollTop
      // })
    }

    // X scroll 이동시
    if (refDivBodyScrollX.value) {
      refDivBodyScrollX.value.addEventListener('scroll', (e) => {
        scrollPostion.left = e.target.scrollLeft
      })
    }

    if (refTableBodyLeft.value) {
      refTableBodyLeft.value.addEventListener('selectstart', (e) => {
        e.preventDefault()
      })
    }

    if (refTableBodyCenter.value) {
      refTableBodyCenter.value.addEventListener('selectstart', (e) => {
        e.preventDefault()
      })
    }

    if (refTableBodyLeft.value) {
      // refTableBodyLeft.value.addEventListener('wheel', (e) => {
      //   e.preventDefault()
      //   refDivBodyScrollY.value.scrollTop += e.deltaY
      // })
    }

    if (refTableBodyCenter.value) {
      // refTableBodyCenter.value.addEventListener('wheel', (e) => {
      //   // Lot 시험 결과 스크롤
      //   if (mixmatUtils.hasClass(e.target, 'lot-test-result-box')) {
      //     return
      //   }
      //   const $div = mixmatUtils.findParentElement(
      //     e.target,
      //     'DIV',
      //     'lot-test-result-box'
      //   )
      //   if ($div) {
      //     return
      //   }
      //   if (e.target) e.preventDefault()
      //   refDivBodyScrollY.value.scrollTop += e.deltaY
      // })
    }

    if (refContextMenuWrap.value) {
      refContextMenuWrap.value.addEventListener('contextmenu', (e) => {
        e.preventDefault()
      })
    }

    if (refDivHeaderCenter.value) {
      refDivHeaderCenter.value.addEventListener('contextmenu', (e) => {
        mixmatUtils.contextMenuHeader(e)
      })
    }

    mixmatUtils.addEventSelectCell() // grid cell 선택 event
  },
  // grid cell 선택 event
  addEventSelectCell: () => {
    const { refDivBodyLeft, refDivBodyCenter } = mixmatUtils.opts

    refDivBodyLeft.value.addEventListener('mousedown', (e) => {
      if (e.which === 1) {
        mixmatUtils.cellEventMousedown(e)
      } else if (e.which === 3) {
        const $cell = mixmatUtils.getGridCell(e.target)
        if ($cell) {
          mixmatUtils.setFocusCell($cell)
          mixmatUtils.setStartEndCell($cell, 'START')
          mixmatUtils.setMultipleSelectCell()
          mixmatUtils.onClick(e)
        }
      }
    })

    refDivBodyLeft.value.addEventListener('dblclick', (e) => {
      mixmatUtils.cellEventDblclick(e)
    })

    refDivBodyCenter.value.addEventListener('mousedown', (e) => {
      if (e.which === 1) {
        mixmatUtils.cellEventMousedown(e)
      } else if (e.which === 3) {
        const $cell = mixmatUtils.getGridCell(e.target)
        if ($cell) {
          mixmatUtils.setFocusCell($cell)
          mixmatUtils.setStartEndCell($cell, 'START')
          mixmatUtils.setMultipleSelectCell()
          mixmatUtils.onClick(e)
        }
      }
    })

    // if (refDivBodyLeft.value) {
    //   refDivBodyLeft.value.addEventListener('contextmenu', (e) => {
    //     mixmatUtils.contextMenuCell(e)
    //   })
    // }

    // if (refDivBodyCenter.value) {
    //   refDivBodyCenter.value.addEventListener('contextmenu', (e) => {
    //     mixmatUtils.contextMenuCell(e)
    //   })
    // }

    refDivBodyCenter.value.addEventListener('dblclick', (e) => {
      mixmatUtils.cellEventDblclick(e)
    })

    refDivBodyLeft.value.addEventListener('mouseup', (e) => {
      if (e.which === 1) {
        mixmatUtils.cellEventMouseup(e)
      }
    })

    refDivBodyCenter.value.addEventListener('mouseup', (e) => {
      if (e.which === 1) {
        mixmatUtils.cellEventMouseup(e)
      }
    })

    refDivBodyLeft.value.addEventListener('mouseover', (e) => {
      mixmatUtils.cellEventMouseover(e)
    })

    refDivBodyCenter.value.addEventListener('mouseover', (e) => {
      mixmatUtils.cellEventMouseover(e)
    })
  },
  cellEventDblclick: (e) => {
    const { gridVars } = mixmatUtils.opts
    const { cellData } = gridVars.focusCell

    if (!cellData) {
      return
    }

    // const { refGridFocus, gridVars } = mixmatUtils.opts
    const currLot = gridVars.lots.find((lot) => lot.vLotCd === cellData.vLotCd)
    const activeYn =
      cellData.columnId === 'vMateCd' ? 'Y' : currLot?.activeYn || 'N'
    const vFlagRateRest = currLot?.rateList?.find(
      (rate) => rate.vMatePkCd === cellData.vMatePkCd
    )?.vFlagRateRest
    const vParentMatePkCd =
      gridVars.materials.find((mate) => mate.vMatePkCd === cellData.vMatePkCd)
        ?.vParentMatePkCd || null
    const vFlagComplete = currLot?.vFlagComplete || 'N'
    const vFlagDisabled = gridVars.reqInfo.otherVO.vFlagDisabled || 'N'

    if (
      !mixmatUtils.isGridCell(e.target) ||
      cellData.columnId === 'gram' ||
      activeYn === 'N' ||
      vFlagRateRest === 'Y' ||
      vParentMatePkCd ||
      vFlagComplete === 'Y' ||
      vFlagDisabled === 'Y'
    ) {
      return
    }

    cellData.vChkLotCd = cellData.vLotCd
    cellData.vChkMatePkCd = cellData.vMatePkCd

    const $cell = mixmatUtils.getGridCell(e.target)
    mixmatUtils.setFocusCell($cell)
    mixmatUtils.clearMultipleSelectCell()
    mixmatUtils.fnInputMode({ type: 'SHOW' })
  },
  contextMenuHeader: (e) => {
    e.preventDefault()
    const { gridVars, refDivGridWrap } = mixmatUtils.opts

    const rect = refDivGridWrap.value.getBoundingClientRect()

    gridVars.isShowMenuCell = false
    gridVars.isShowMenuHeader = true
    gridVars.contextMenuHeaderStyle.left = e.x - rect.left - 10 + 'px'
    gridVars.contextMenuHeaderStyle.top = e.y - rect.top + 'px'
  },
  contextMenuCell: (e) => {
    e.preventDefault()
    const { gridVars, refDivGridWrap } = mixmatUtils.opts
    const $cell = mixmatUtils.getGridCell(e.target)

    if (!$cell) {
      return
    }

    const rect = refDivGridWrap.value.getBoundingClientRect()

    mixmatUtils.setFocusCell($cell)
    mixmatUtils.clearMultipleSelectCell()

    gridVars.isShowMenuCell = true
    gridVars.isShowMenuHeader = false
    gridVars.contextMenuCellStyle.left = e.x - rect.left - 10 + 'px'
    gridVars.contextMenuCellStyle.top = e.y - rect.top + 'px'
  },
  cellEventMousedown: (e) => {
    const { refGridFocus, gridVars } = mixmatUtils.opts
    if (!mixmatUtils.isGridCell(e.target)) {
      return
    }
    const $cell = mixmatUtils.getGridCell(e.target)
    gridVars.isMouseDown = true

    if (gridVars.mousePrevTarget === $cell) {
      return
    }

    if (gridVars.isFocusCell && e.shiftKey) {
      gridVars.mousePrevTarget = $cell

      // refGridFocus.value.focus()
      mixmatUtils.setStartEndCell($cell, 'END')
      mixmatUtils.setMultipleSelectCell()
    } else {
      gridVars.mousePrevTarget = $cell

      // refGridFocus.value.focus()
      mixmatUtils.setFocusCell($cell)
      mixmatUtils.setStartEndCell($cell, 'START')
      mixmatUtils.setMultipleSelectCell()
    }
  },
  cellEventMouseup: (e) => {
    const { gridVars } = mixmatUtils.opts
    gridVars.isMouseDown = false
    gridVars.mousePrevTarget = undefined

    /*
    if (mixmatUtils.isGridCell(e.target)) {
      // console.log('mouseup : ', gridVars.isMouseDown, e)
    }
    */
  },
  cellEventMouseover: (e) => {
    const { gridVars } = mixmatUtils.opts

    if (!gridVars.isMouseDown) {
      return
    }

    if (gridVars.mousePrevTarget === e.target) {
      return
    }

    if (!mixmatUtils.isGridCell(e.target)) {
      return
    }

    const $cdll = mixmatUtils.getGridCell(e.target)

    gridVars.mousePrevTarget = $cdll
    mixmatUtils.setStartEndCell($cdll, 'END')
    mixmatUtils.setMultipleSelectCell()
  },
  setStartEndCell: ($cell, type) => {
    const opts = mixmatUtils.opts
    const cellIndex = mixmatUtils.getCellIndex($cell)

    if (type === 'START') {
      opts.gridVars.startCell = cellIndex
      opts.gridVars.endCell = cellIndex
    } else if (type === 'END') {
      opts.gridVars.endCell = cellIndex
    }
  },
  setFocusCell: ($cell) => {
    const {
      refDivBodyCenter,
      refDivBodyScrollX,
      refDivBodyScrollY,
      scrollPostion,
      gridVars,
    } = mixmatUtils.opts
    const cellIndex = mixmatUtils.getCellIndex($cell)
    const cellData = {
      ...$cell.dataset,
      rowIndex: parseInt($cell.dataset.rowIndex, 10),
    }

    const bfCellData = gridVars.focusCell.cellData
    if (bfCellData && bfCellData.vChkLotCd && bfCellData.vChkMatePkCd) {
      cellData.vChkLotCd = bfCellData.vChkLotCd
      cellData.vChkMatePkCd = bfCellData.vChkMatePkCd
    }

    mixmatUtils.clearFocusCell()
    mixmatUtils.addClass($cell, 'anypjt-grid-cell-focus')

    gridVars.isFocusCell = true
    gridVars.startCell = cellIndex
    gridVars.focusCell = {
      ...cellIndex,
      $td: $cell.parentElement,
      $cell: $cell,
      cellData: cellData,
    }

    const w = refDivBodyCenter.value.offsetWidth
    const h = refDivBodyCenter.value.offsetHeight
    const $td = $cell.parentElement
    const x1 = $td.offsetLeft - scrollPostion.left
    const y1 = $td.offsetTop - scrollPostion.top
    const x2 = $td.offsetLeft + $td.offsetWidth - scrollPostion.left
    const y2 = $td.offsetTop + $td.offsetHeight - scrollPostion.top

    if (y1 < 0) {
      refDivBodyScrollY.value.scrollTop += y1
    } else if (y2 > h) {
      refDivBodyScrollY.value.scrollTop += y2 - h
    }

    if (cellIndex.tableId === 'tableBodyLeft') {
      return
    }

    if (x1 < 0) {
      refDivBodyScrollX.value.scrollLeft += x1
    } else if (x2 > w) {
      refDivBodyScrollX.value.scrollLeft += x2 - w
    }

    if (gridVars.info.contVO.vNoteType === 'MU') {
      gridVars.materials = gridVars.materials.map((mate) => {
        return {
          ...mate,
          vIsArrow:
            mate.vMatePkCd === cellData.vMatePkCd && !mate.vParentMatePkCd
              ? true
              : false,
          vArrowLotCd: cellData.vLotCd,
        }
      })
      gridVars.info.mateList = gridVars.materials
    }
  },
  clearFocusCell: () => {
    const opts = mixmatUtils.opts
    const { refTableBodyLeft, refTableBodyCenter } = opts

    const $arrLeftCell = refTableBodyLeft.value.querySelectorAll(
      '.anypjt-grid-cell-focus'
    )

    const $arrCenterCell = refTableBodyCenter.value.querySelectorAll(
      '.anypjt-grid-cell-focus'
    )

    let len = $arrLeftCell.length
    for (let i = 0; i < len; i++) {
      mixmatUtils.removeClass($arrLeftCell[i], 'anypjt-grid-cell-focus')
    }

    len = $arrCenterCell.length
    for (let i = 0; i < len; i++) {
      mixmatUtils.removeClass($arrCenterCell[i], 'anypjt-grid-cell-focus')
    }

    opts.gridVars.isFocusCell = false
    opts.gridVars.focusCell = {}
  },
  setMultipleSelectCell: () => {
    mixmatUtils.clearMultipleSelectCell()
    const {
      refTableBodyLeft,
      refTableBodyCenter,
      refDivBodyLeftSelectLayer,
      refDivBodyCenterSelectLayer,
      gridVars,
    } = mixmatUtils.opts
    const startCell = gridVars.startCell
    const endCell = gridVars.endCell

    let isLeftLayer = false
    let isCenterLayer = false
    let lx1, lx2, ly1, ly2
    let cx1, cx2, cy1, cy2

    if (startCell.tableId != endCell.tableId) {
      isLeftLayer = true
      isCenterLayer = true

      if (startCell.tableId === 'tableBodyLeft') {
        lx1 = startCell.elemCellIdx
        lx2 = 8
        cx1 = 0
        cx2 = endCell.elemCellIdx
      } else {
        lx1 = endCell.elemCellIdx
        lx2 = 8
        cx1 = 0
        cx2 = startCell.elemCellIdx
      }

      if (startCell.elemRowIdx <= endCell.elemRowIdx) {
        ly1 = startCell.elemRowIdx
        ly2 = endCell.elemRowIdx
        cy1 = startCell.elemRowIdx
        cy2 = endCell.elemRowIdx
      } else {
        ly1 = endCell.elemRowIdx
        ly2 = startCell.elemRowIdx
        cy1 = endCell.elemRowIdx
        cy2 = startCell.elemRowIdx
      }
    } else if (startCell.tableId === 'tableBodyLeft') {
      isLeftLayer = true

      if (startCell.elemCellIdx <= endCell.elemCellIdx) {
        lx1 = startCell.elemCellIdx
        lx2 = endCell.elemCellIdx
      } else {
        lx1 = endCell.elemCellIdx
        lx2 = startCell.elemCellIdx
      }
      if (startCell.elemRowIdx <= endCell.elemRowIdx) {
        ly1 = startCell.elemRowIdx
        ly2 = endCell.elemRowIdx
      } else {
        ly1 = endCell.elemRowIdx
        ly2 = startCell.elemRowIdx
      }
    } else {
      isCenterLayer = true

      if (startCell.elemCellIdx <= endCell.elemCellIdx) {
        cx1 = startCell.elemCellIdx
        cx2 = endCell.elemCellIdx
      } else {
        cx1 = endCell.elemCellIdx
        cx2 = startCell.elemCellIdx
      }
      if (startCell.elemRowIdx <= endCell.elemRowIdx) {
        cy1 = startCell.elemRowIdx
        cy2 = endCell.elemRowIdx
      } else {
        cy1 = endCell.elemRowIdx
        cy2 = startCell.elemRowIdx
      }
    }

    gridVars.isMultipleSelect = true

    if (isLeftLayer) {
      let $arrTd, i, j
      const $arrTr =
        refTableBodyLeft.value.querySelectorAll('tr.anypjt-grid-tr')
      const $std =
        $arrTr[ly1].dataset.vRecType === 'GRP'
          ? undefined
          : $arrTr[ly1].querySelectorAll('td.anypjt-grid-td')[lx1]
      const $etd =
        $arrTr[ly2].dataset.vRecType === 'GRP'
          ? undefined
          : $arrTr[ly2].querySelectorAll('td.anypjt-grid-td')[lx2]

      if ($std !== undefined && $etd !== undefined) {
        for (i = ly1; i <= ly2; i++) {
          if ($arrTr[i].dataset.vRecType === 'GRP') {
            continue
          }
          $arrTd = $arrTr[i].querySelectorAll('td.anypjt-grid-td')
          for (j = lx1; j <= lx2; j++) {
            mixmatUtils.addClass($arrTd[j], 'anypjt-grid-cell-select')
          }
        }

        const width = $etd.offsetLeft - $std.offsetLeft + $etd.offsetWidth
        const height = $etd.offsetTop - $std.offsetTop + $etd.offsetHeight

        refDivBodyLeftSelectLayer.value.style.display = 'block'
        refDivBodyLeftSelectLayer.value.style.width = width + 'px'
        refDivBodyLeftSelectLayer.value.style.height = height + 'px'
        refDivBodyLeftSelectLayer.value.style.left = $std.offsetLeft + 'px'
        refDivBodyLeftSelectLayer.value.style.top = $std.offsetTop + 'px'
      }
    }

    if (isCenterLayer) {
      let $arrTd, i, j
      const $arrTr =
        refTableBodyCenter.value.querySelectorAll('tr.anypjt-grid-tr')
      const $std = $arrTr[cy1].querySelectorAll('td.anypjt-grid-td')[cx1]
      const $etd = $arrTr[cy2].querySelectorAll('td.anypjt-grid-td')[cx2]

      for (i = cy1; i <= cy2; i++) {
        $arrTd = $arrTr[i].querySelectorAll('td.anypjt-grid-td')
        for (j = cx1; j <= cx2; j++) {
          mixmatUtils.addClass($arrTd[j], 'anypjt-grid-cell-select')
        }
      }

      const width = $etd.offsetLeft - $std.offsetLeft + $etd.offsetWidth
      const height = $etd.offsetTop - $std.offsetTop + $etd.offsetHeight

      refDivBodyCenterSelectLayer.value.style.display = 'block'
      refDivBodyCenterSelectLayer.value.style.width = width + 'px'
      refDivBodyCenterSelectLayer.value.style.height = height + 'px'
      refDivBodyCenterSelectLayer.value.style.left = $std.offsetLeft + 'px'
      refDivBodyCenterSelectLayer.value.style.top = $std.offsetTop + 'px'
    }
  },
  // cell 선택 초기화
  clearMultipleSelectCell: () => {
    const {
      refTableBodyLeft,
      refTableBodyCenter,
      refDivBodyLeftSelectLayer,
      refDivBodyCenterSelectLayer,
      gridVars,
    } = mixmatUtils.opts

    const $arrLeftTd = refTableBodyLeft.value.querySelectorAll(
      'td.anypjt-grid-cell-select'
    )
    const $arrCenterTd = refTableBodyCenter.value.querySelectorAll(
      'td.anypjt-grid-cell-select'
    )

    let len = $arrLeftTd.length
    for (let i = 0; i < len; i++) {
      mixmatUtils.removeClass($arrLeftTd[i], 'anypjt-grid-cell-select')
    }

    len = $arrCenterTd.length
    for (let i = 0; i < len; i++) {
      mixmatUtils.removeClass($arrCenterTd[i], 'anypjt-grid-cell-select')
    }

    gridVars.isMultipleSelect = false
    refDivBodyLeftSelectLayer.value.style.display = 'none'
    refDivBodyCenterSelectLayer.value.style.display = 'none'
  },
  getCellIndex: ($cell) => {
    const opts = mixmatUtils.opts
    const { refTableBodyLeft, refTableBodyCenter } = opts

    // div => td => tr => tbody => table
    const $table = $cell.parentElement.parentElement.parentElement.parentElement
    const $tr = $cell.parentElement.parentElement
    const $td = $cell.parentElement
    const tableId = $table.getAttribute('id')

    const $arrTr =
      tableId === 'tableBodyLeft'
        ? refTableBodyLeft.value.querySelectorAll('tr.anypjt-grid-tr')
        : refTableBodyCenter.value.querySelectorAll('tr.anypjt-grid-tr')
    const $arrTd = $tr.querySelectorAll('td.anypjt-grid-td')

    const trLen = $arrTr.length
    const tdLen = $arrTd.length
    let elemRowIdx = -1
    let elemCellIdx = -1
    let i = 0

    for (i = 0; i < trLen; i++) {
      if ($arrTr[i] === $tr) {
        elemRowIdx = i
        break
      }
    }

    for (i = 0; i < tdLen; i++) {
      if ($arrTd[i] === $td) {
        elemCellIdx = i
        break
      }
    }

    return {
      elemRowIdx,
      elemCellIdx,
      tableId,
    }
  },
  // row 추가
  addRow: async () => {
    const { gridVars } = mixmatUtils.opts
    const { elemRowIdx, cellData } = gridVars.focusCell

    if (!gridVars.materials) {
      console.error('addRow - Materials is null')
      return
    } else if (elemRowIdx === undefined && elemRowIdx < 0) {
      console.error('addRow - elemRowIdx is null')
      return
    } else if (gridVars.addMatIdx > 1000) {
      alert('임시 원료저장번호를 모두 사용 하였습니다. 저장후 진행해 주세요.')
      return
    }

    gridVars.materials.splice(cellData.rowIndex + 1, 0, {
      vMatePkCd: ++gridVars.addMateIdx,
    })
  },
  // row 삭제
  removeRow: () => {
    const { gridVars } = mixmatUtils.opts
    const { tableId, elemRowIdx, elemCellIdx, cellData } = gridVars.focusCell

    if (!gridVars.materials) {
      console.error('addRow - Materials is null')
      return
    } else if (elemRowIdx === undefined && elemRowIdx < 0) {
      console.error('addRow - elemRowIdx is null')
      return
    }

    const rowIndex = parseInt(cellData.rowIndex, 10) // 데이터의 index

    gridVars.materials.splice(rowIndex, 1)

    nextTick(() => {
      // 선택 cell 변경
      const $arrTr = mixmatUtils.findElementsTr(tableId)
      const $arrTd = mixmatUtils.findElementsTd($arrTr[elemRowIdx])

      mixmatUtils.setFocusCell(mixmatUtils.findElementCell($arrTd[elemCellIdx]))
      mixmatUtils.clearMultipleSelectCell()
    })
  },
  hideRow: () => {
    const { gridVars } = mixmatUtils.opts
    const { elemRowIdx, cellData } = gridVars.focusCell

    if (!gridVars.materials) {
      console.error('addRow - Materials is null')
      return
    } else if (elemRowIdx === undefined && elemRowIdx < 0) {
      console.error('addRow - elemRowIdx is null')
      return
    }

    const mateVo = gridVars.materials[cellData.rowIndex]

    if (mateVo.vRecType === 'GRP') {
      mateVo.vFlagGrpHide = 'Y'

      for (let vo of gridVars.materials) {
        if (vo.vRecType === 'MATE' && vo.vGrpCd === mateVo.vGrpCd) {
          vo.vFlagGrpHide = 'Y'
        }
      }
    } else {
      mateVo.vFlagMateHide = 'Y'
    }
  },
  createGroup: () => {},
  upRow: () => {
    const { gridVars } = mixmatUtils.opts
    const { cellData } = gridVars.focusCell
    const mateVo = gridVars.materials[cellData.rowIndex]

    if (
      gridVars.reqInfo.otherVO.vFlagDisabled === 'Y' ||
      mateVo.vParentMatePkCd
    ) {
      return
    }

    if (!gridVars.materials) {
      console.error('addRow - Materials is null')
      return
    }

    if (gridVars.rowSelect.isSelect) {
      mixmatUtils.upRowMultiple()
    } else {
      mixmatUtils.upRowSingle()
    }

    let len = 0
    gridVars.materials = gridVars.materials.map((mate) => {
      return (mate = {
        ...mate,
        nMateNum: mate.vRecType !== 'GRP' ? ++len : null,
      })
    })

    gridVars.reqInfo.mateList = gridVars.materials
    gridVars.info.mateList = gridVars.materials
  },
  upRowSingle: () => {
    const { gridVars } = mixmatUtils.opts
    const { tableId, elemRowIdx, elemCellIdx, cellData } = gridVars.focusCell

    if (elemRowIdx === undefined && elemRowIdx < 0) {
      console.error('addRow - elemRowIdx is null')
      return
    }

    if (elemRowIdx === 0) {
      return
    }

    const rowIndex = cellData.rowIndex
    const mateVo = gridVars.materials[cellData.rowIndex]
    const upIdx = mixmatUtils.getChangeUpIndex(mateVo, rowIndex)

    if (upIdx >= 0) {
      const selectIdx = mixmatUtils.changeUpDown(rowIndex, upIdx)

      nextTick(() => {
        // 선택 cell 변경
        const $tr = mixmatUtils.findElementTrOfDataRowIndex(tableId, selectIdx)
        const $arrTd = mixmatUtils.findElementsTd($tr)

        mixmatUtils.setFocusCell(
          mixmatUtils.findElementCell($arrTd[elemCellIdx])
        )
        mixmatUtils.clearMultipleSelectCell()
      })
    }
  },
  upRowMultiple: () => {
    const { gridVars } = mixmatUtils.opts
    const materials = gridVars.materials
    const len = materials.length
    let isFindFirst = false
    let idx = -1
    let vGrpCd
    let mateVo
    let isJoinGrp = false

    for (let i = 0; i < len; i++) {
      mateVo = materials[i]
      if (mateVo.rowSelectYn !== 'Y') {
        continue
      }

      if (mateVo.vGrpCd) {
        if (mateVo.vGrpCd === vGrpCd) {
          continue
        }
      }

      if (!isFindFirst) {
        if (i > 0) {
          const bfMateVo = materials[i - 1]
          isJoinGrp =
            bfMateVo.vGrpCd && mateVo.vRecType === 'MATE' && !mateVo.vGrpCd
              ? true
              : false
        }
        isFindFirst = true
        idx = mixmatUtils.getChangeUpIndex(mateVo, i)

        if (idx === -1) {
          return
        }
      }

      idx = mixmatUtils.changeUpDown(i, idx)

      if (mateVo.vRecType === 'GRP') {
        vGrpCd = mateVo.vGrpCd
        idx += materials.filter((vo) => vo.vGrpCd === vGrpCd).length
      } else {
        vGrpCd = null
        if (!isJoinGrp) {
          idx++
        }
      }
    }
  },
  getChangeUpIndex: (mateVo, rowIndex) => {
    const { gridVars } = mixmatUtils.opts

    if (rowIndex === 0) {
      return 0
    }

    let isFolder = mateVo.vRecType === 'GRP'
    let upIdx = rowIndex - 1
    let upMateVo
    let isLoop = true

    while (isLoop) {
      upMateVo = gridVars.materials[upIdx]
      if (isFolder && upMateVo.vRecType !== 'GRP' && upMateVo.vGrpCd) {
        upIdx--
      } else if (
        upMateVo.vFlagGrpHide !== 'Y' &&
        upMateVo.vFlagMateHide !== 'Y'
      ) {
        isLoop = false
      } else {
        upIdx--
      }
      if (upIdx <= -1) {
        upMateVo = undefined
        isLoop = false
      }
    }

    if (upMateVo) {
      return upIdx
    } else {
      return -1
    }
  },
  downRow: () => {
    const { gridVars } = mixmatUtils.opts
    const { cellData } = gridVars.focusCell
    const mateVo = gridVars.materials[cellData.rowIndex]

    if (
      gridVars.reqInfo.otherVO.vFlagDisabled === 'Y' ||
      mateVo.vParentMatePkCd
    ) {
      return
    }

    if (!gridVars.materials) {
      console.error('addRow - Materials is null')
      return
    }

    if (gridVars.rowSelect.isSelect) {
      mixmatUtils.downRowMultiple()
    } else {
      mixmatUtils.downRowSingle()
    }

    let len = 0
    gridVars.materials = gridVars.materials.map((mate) => {
      return (mate = {
        ...mate,
        nMateNum: mate.vRecType !== 'GRP' ? ++len : null,
      })
    })

    gridVars.reqInfo.mateList = gridVars.materials
  },
  downRowSingle: () => {
    const { gridVars } = mixmatUtils.opts
    const { tableId, elemRowIdx, elemCellIdx, cellData } = gridVars.focusCell

    if (elemRowIdx === undefined && elemRowIdx < 0) {
      console.error('addRow - elemRowIdx is null')
      return
    }

    const rowIndex = cellData.rowIndex
    let maxIdx = gridVars.materials.length - 1

    if (rowIndex === maxIdx) {
      return
    }

    const mateVo = gridVars.materials[rowIndex]
    const downIdx = mixmatUtils.getChangeDownIndex(mateVo, rowIndex)

    if (downIdx >= 0) {
      const selectIdx = mixmatUtils.changeUpDown(rowIndex, downIdx)

      nextTick(() => {
        // 선택 cell 변경
        const $tr = mixmatUtils.findElementTrOfDataRowIndex(tableId, selectIdx)
        const $arrTd = mixmatUtils.findElementsTd($tr)

        mixmatUtils.setFocusCell(
          mixmatUtils.findElementCell($arrTd[elemCellIdx])
        )
        mixmatUtils.clearMultipleSelectCell()
      })
    }
  },
  downRowMultiple: () => {
    const { gridVars } = mixmatUtils.opts
    const materials = gridVars.materials
    const len = materials.length
    let isFindFirst = false
    let idx = -1
    let mateVo
    let groupMap = {}

    const selected = materials.filter((mate) => mate.rowSelectYn === 'Y')
    if (
      selected.filter((mate) => mate.vRecType === 'GRP').length > 0 &&
      selected.filter((mate) => mate.vRecType === 'MATE').length > 0
    ) {
      return
    }

    for (let i = len - 1; i >= 0; i--) {
      mateVo = materials[i]
      if (mateVo.rowSelectYn !== 'Y') {
        continue
      }

      if (mateVo.vRecType !== 'GRP' && mateVo.vGrpCd) {
        if (!groupMap[mateVo.vGrpCd]) {
          groupMap[mateVo.vGrpCd] =
            materials.filter(
              (vo) =>
                vo.vGrpCd === mateVo.vGrpCd &&
                vo.vRecType === 'GRP' &&
                vo.rowSelectYn === 'Y'
            ).length > 0
              ? 'Y'
              : 'N'
        }
        if (groupMap[mateVo.vGrpCd] === 'Y') {
          continue
        }

        if (isFindFirst) {
          mateVo.vGrpCd = null
        }
      }

      if (!isFindFirst) {
        isFindFirst = true
        idx = mixmatUtils.getChangeDownIndex(mateVo, i)

        if (idx === -1) {
          return
        }
      }

      if (mateVo.vRecType === 'GRP') {
        // idx -= materials.filter((vo) => vo.vGrpCd === mateVo.vGrpCd).length - 1
      }
      idx = mixmatUtils.changeUpDown(i, idx)

      // if (mateVo.vRecType === 'GRP') {
      //   idx -= materials.filter((vo) => vo.vGrpCd === vGrpCd).length
      // } else {
      idx--
      // }
    }
  },
  getChangeDownIndex: (mateVo, rowIndex) => {
    const { gridVars } = mixmatUtils.opts

    let maxIdx = gridVars.materials.length - 1
    let isFolder = mateVo.vRecType === 'GRP'
    let downIdx = rowIndex + 1
    let downMateVo
    let isLoop = true

    if (downIdx > maxIdx) {
      return maxIdx
    }

    if (isFolder) {
      const folderRowLen = gridVars.materials.filter(
        (vo) => vo.vGrpCd === mateVo.vGrpCd
      ).length
      maxIdx -= folderRowLen - 1
    }

    while (isLoop) {
      downMateVo = gridVars.materials[downIdx]
      if (isFolder && mateVo.vGrpCd === downMateVo.vGrpCd) {
        isLoop = false
      } else if (isFolder && downMateVo.vGrpCd) {
        downIdx++
      } else if (
        downMateVo.vFlagGrpHide !== 'Y' &&
        downMateVo.vFlagMateHide !== 'Y'
      ) {
        isLoop = false
      } else {
        downIdx++
      }
      if (downIdx > maxIdx) {
        downMateVo = undefined
        isLoop = false
      }
    }

    if (downMateVo) {
      return downIdx
    } else {
      return -1
    }
  },
  changeUpDown: (nowIndex, changeIndex) => {
    if (nowIndex === changeIndex) {
      return nowIndex
    }
    const { gridVars } = mixmatUtils.opts
    const nowVo = gridVars.materials[nowIndex]
    const chgVo = gridVars.materials[changeIndex]
    const isFolder = nowVo.vRecType === 'GRP'

    // UP
    if (nowIndex > changeIndex) {
      if (isFolder) {
        const mateList = gridVars.materials.filter(
          (vo) => vo.vGrpCd === nowVo.vGrpCd
        )
        const mateLen = mateList.length

        for (let i = 0; i < mateLen; i++) {
          gridVars.materials.splice(nowIndex + i, 1)
          gridVars.materials.splice(changeIndex + i, 0, mateList[i])
        }
      } else {
        if (!nowVo.vGrpCd && chgVo.vGrpCd) {
          nowVo.vGrpCd = chgVo.vGrpCd
          return nowIndex
          // 그룹안에 있는데 바로 위가 그룹이면 그룹에서 나온다.
        } else if (nowVo.vGrpCd && chgVo.vRecType === 'GRP') {
          nowVo.vGrpCd = null
        }

        gridVars.materials.splice(nowIndex, 1)
        gridVars.materials.splice(changeIndex, 0, nowVo)
      }
      // DOWN
    } else {
      if (isFolder) {
        const mateList = gridVars.materials.filter(
          (vo) => vo.vGrpCd === nowVo.vGrpCd
        )
        const mateLen = mateList.length

        if (nowVo.vGrpCd === chgVo.vGrpCd) {
          const nextVo = gridVars.materials[nowIndex + mateLen]
          if (nextVo.vRecType === 'GRP') {
            const addLen = gridVars.materials.filter(
              (vo) => vo.vGrpCd === nextVo.vGrpCd
            ).length
            changeIndex += addLen - 1
          }
        }

        for (let i = mateLen - 1; i >= 0; i--) {
          gridVars.materials.splice(changeIndex + 1 + i, 0, mateList[i])
          gridVars.materials.splice(nowIndex + i, 1)
        }
      } else {
        if (nowVo.vGrpCd && !chgVo.vGrpCd) {
          nowVo.vGrpCd = null
          return nowIndex
        } else if (nowVo.vGrpCd && chgVo.vRecType === 'GRP') {
          nowVo.vGrpCd = null
          return nowIndex
        } else if (!nowVo.vGrpCd && chgVo.vRecType === 'GRP') {
          nowVo.vGrpCd = chgVo.vGrpCd
        } else {
          if (!nowVo.vGrpCd && chgVo.vGrpCd) {
            nowVo.vGrpCd = chgVo.vGrpCd
          }
        }

        gridVars.materials.splice(changeIndex + 1, 0, nowVo)
        gridVars.materials.splice(nowIndex, 1)
      }
    }
    return changeIndex
  },
  fnLotActive: (lotVo) => {
    const { gridVars } = mixmatUtils.opts
    const activeLotVo = gridVars.lots.find((vo) => vo.activeYn === 'Y')

    if (activeLotVo) {
      if (activeLotVo.vLotCd === lotVo.vLotCd) {
        return
      }
      activeLotVo.activeYn = 'N'
    }
    lotVo.activeYn = 'Y'

    mixmatUtils.clearFocusCell()
    mixmatUtils.clearMultipleSelectCell()
  },
  fnSearchRowMate: (e, rowIndex) => {
    mixmatUtils.fnInputMode({
      type: 'SHOW',
    })
  },
  // 등록/수정 모드
  fnInputMode: ({ type, val }) => {
    const { gridVars, refDivBodyLeftInput, refDivBodyCenterInput } =
      mixmatUtils.opts
    const { tableId, cellData, $td } = gridVars.focusCell

    if (!cellData || !cellData.columnId) {
      return
    }

    if (tableId === 'tableBodyLeft') {
      if (type === 'SHOW' || type === 'SHOW_N_VALUE') {
        const mateVo = gridVars.materials[cellData.rowIndex]
        let val = ''
        let columnId = ''
        if (mateVo.vRecType === 'GRP' && cellData.columnId === 'vMateCd') {
          columnId = 'GRP'
          val = mateVo.vGrpNm || ''
        } else if (cellData.columnId === 'vMateCd') {
          columnId = 'MATE'
          val = mateVo.vMateCd || mateVo.vMateTempCd || ''
        } else if (cellData.columnId === 'vMateNm' && mateVo.vMateCd) {
          columnId = 'MATE'
          val = mateVo.vMateCd || ''
        } else if (cellData.columnId === 'vMateNm') {
          columnId = 'MATE_NM'
          val = mateVo.vMateNm || ''
        } else {
          return
        }

        gridVars.inputMode.show = true
        gridVars.inputMode.tableId = tableId
        gridVars.inputMode.columnId = columnId

        refDivBodyLeftInput.value.style.minWidth = '200px'
        refDivBodyLeftInput.value.style.width = $td.offsetWidth + 'px'
        refDivBodyLeftInput.value.style.left = $td.offsetLeft + 'px'
        refDivBodyLeftInput.value.style.top = $td.offsetTop + 'px'

        nextTick(() => {
          const $input = refDivBodyLeftInput.value.querySelector('input')
          $input.dataset.rowIndex = cellData.rowIndex
          $input.dataset.value = val
          $input.value = val
          $input.focus()
          $input.select()
        })
      } else if (type === 'CANCEL') {
        const $input = refDivBodyLeftInput.value.querySelector('input')
        const $p = refDivBodyLeftInput.value.querySelector('p')

        gridVars.inputMode.show = false
        gridVars.inputMode.tableId = ''
        gridVars.inputMode.columnId = ''
        $input.value = ''
        $p.innerText = ''
        mixmatUtils.removeClass(refDivBodyLeftInput.value, 'inp-error')
      }
    } else if (tableId === 'tableBodyCenter') {
      if (type === 'SHOW' || type === 'SHOW_N_VALUE') {
        if (cellData.flagAuto === 'Y') {
          return
        }
        gridVars.inputMode.show = true
        gridVars.inputMode.tableId = tableId
        gridVars.inputMode.columnId = cellData.columnId

        refDivBodyCenterInput.value.style.left = $td.offsetLeft + 'px'
        refDivBodyCenterInput.value.style.top = $td.offsetTop + 'px'

        const rateVo = mixmatUtils.getRateVo(
          cellData.vLotCd,
          cellData.vMatePkCd
        )

        let chgValue = ''

        if (type === 'SHOW_N_VALUE') {
          chgValue = val
        } else if (cellData.columnId === 'rate') {
          chgValue = rateVo.nRate || ''
        } else if (cellData.columnId === 'gram') {
          chgValue = rateVo['gram_' + cellData.gramSeq] || ''
        }

        nextTick(() => {
          const $input = refDivBodyCenterInput.value.querySelector('input')
          $input.value = chgValue
          $input.focus()
          $input.select()
        })
      } else if (type === 'CANCEL') {
        const $input = refDivBodyCenterInput.value.querySelector('input')
        const $p = refDivBodyCenterInput.value.querySelector('p')

        gridVars.inputMode.show = false
        gridVars.inputMode.tableId = ''
        gridVars.inputMode.columnId = ''
        $input.value = ''
        $p.innerText = ''
        mixmatUtils.removeClass(refDivBodyCenterInput.value, 'inp-error')
      }
    }
  },
  fnInputValueChange: (e, isFocusOut = false) => {
    const { gridVars } = mixmatUtils.opts

    if (gridVars.inputMode.tableId === 'tableBodyLeft') {
      mixmatUtils.fnInputMateChange(e)
    } else if (gridVars.inputMode.tableId === 'tableBodyCenter') {
      mixmatUtils.fnInputRateGramChange(e, isFocusOut)
    }
  },
  fnInputMateChange: (e) => {
    const { gridVars, refDivBodyLeftInput } = mixmatUtils.opts
    const { cellData } = gridVars.focusCell

    const mateVo = gridVars.materials[cellData.rowIndex]
    const $input = refDivBodyLeftInput.value.querySelector('input')
    const $p = refDivBodyLeftInput.value.querySelector('p')
    let val = $input.value

    if (cellData.columnId === 'vMateCd' && mateVo.vRecType === 'GRP') {
      if (val === '') {
        $p.innerText = '그룹명을 입력해 주세요.'
        e.preventDefault()
        return
      }
      mateVo.vGrpNm = val
    }

    gridVars.inputMode.show = false
    gridVars.inputMode.tableId = ''
    gridVars.inputMode.columnId = ''
    $input.value = ''
    $p.innerText = ''
    mixmatUtils.removeClass(refDivBodyLeftInput.value, 'inp-error')
  },
  // 값 변경
  fnInputRateGramChange: (e, isFocusOut = false) => {
    const { gridVars, refDivBodyCenterInput } = mixmatUtils.opts
    const { cellData } = gridVars.focusCell

    const $input = refDivBodyCenterInput.value.querySelector('input')
    const $p = refDivBodyCenterInput.value.querySelector('p')
    let val = $input.value

    if (isFocusOut) {
      cellData.vLotCd = cellData.vChkLotCd
      cellData.vMatePkCd = cellData.vChkMatePkCd
    }

    // 원료배합
    if (cellData.columnId === 'rate') {
      if (val) {
        if (!/^((\.\d+)|(\d+(\.\d+)?))$/.test(val)) {
          mixmatUtils.addClass(refDivBodyCenterInput.value, 'inp-error')
          $p.innerText =
            '함량 비율 값을 확인해 주요. 정수|실수 만 입력 가능합니다.'
          e.preventDefault()
          return
        }

        if (val > 100) {
          val = '100'
        } else if (!/^(\d{1,3})([.]\d{0,6}?)?$/.test(val)) {
          const splitVal = val.split('.')
          val = splitVal[0] + '.' + splitVal[1].substr(0, 6)
        }

        if (val.startsWith('.')) {
          val = '0' + val
        } else if (val.endsWith('.')) {
          val = val + '0'
        }
      }
    } else if (cellData.columnId === 'gram') {
      if (!/^((\d+))$/.test(val)) {
        mixmatUtils.addClass(refDivBodyCenterInput.value, 'inp-error')
        $p.innerText = '그랍 값을 확인해 주요. 정수로만 입력 가능합니다.'
        e.preventDefault()
        return
      }
    }

    const lotVo = gridVars.lots.find((vo) => vo.vLotCd === cellData.vLotCd)

    if (!lotVo) {
      console.error(gridVars.lots)
      console.error(
        'fnCalcLotChange - lotVo is not found (lotVo : ',
        lotVo,
        ', columnId : ',
        columnId,
        ')'
      )
      return
    }
    const rateVo = mixmatUtils.getRateVo(cellData.vLotCd, cellData.vMatePkCd)
    let rate = 0
    let gram = 0

    if (cellData.columnId === 'rate' || isFocusOut) {
      if (val) {
        rate = new Big(val)
      }
    } else if (cellData.columnId === 'gram') {
      const maxGram = new Big(cellData.maxGram)
      gram = new Big(val)
      rate = gram.times(100).div(maxGram).round(4)
    }
    // TODO 값 변경 이력

    rateVo.nRate = rate ? rate.toNumber() : null
    const lotRateVO = lotVo.rateList.find(
      (_rate) => _rate.vMatePkCd === cellData.vMatePkCd
    )
    if (lotRateVO) {
      lotRateVO.nRate = rateVo.nRate
      lotRateVO.vFlagSave = 'Y'
    }

    // if (lotVo.grams) {
    //   for (let gramVo of lotVo.grams) {
    //     if (gramVo.nGram) {
    //       if (
    //         cellData.columnId === 'gram' &&
    //         cellData.gramSeq === gramVo.gramSeq
    //       ) {
    //         rateVo['gram_' + gramVo.gramSeq] = gram
    //       } else {
    //         rateVo['gram_' + gramVo.gramSeq] = rate
    //           .times(gramVo.nGram)
    //           .div(100)
    //           .toNumber()
    //       }
    //     }
    //   }
    // }

    // mixmatUtils.fnCalcLotChange(lotVo)

    gridVars.inputMode.show = false
    gridVars.inputMode.tableId = ''
    gridVars.inputMode.columnId = ''
    $input.value = ''
    $p.innerText = ''
    mixmatUtils.removeClass(refDivBodyCenterInput.value, 'inp-error')
  },
  fnAutoYnChange: ({ vLotCd, vMatePkCd }) => {
    const { gridVars } = mixmatUtils.opts
    const lotVo = gridVars.lots.find((vo) => vo.vLotCd === vLotCd)
    const nowRateVo = mixmatUtils.getRateVo(vLotCd, vMatePkCd)

    if (nowRateVo.flagAuto === 'Y') {
      return
    }

    nowRateVo.flagAuto = 'Y'

    let rateVo

    for (let mateVo of gridVars.materials) {
      if ('' + mateVo.vMatePkCd === vMatePkCd) {
        continue
      }

      rateVo = mixmatUtils.getRateVo(vLotCd, mateVo.vMatePkCd)

      if (rateVo.flagAuto === 'Y') {
        rateVo.flagAuto = 'N'
      }
    }

    mixmatUtils.fnCalcLotChange(lotVo)
  },
  onPaste: (e) => {
    if (!mixmatUtils.canSelfCopyAndPaste(e)) {
      return
    }
    const opts = mixmatUtils.opts

    if (!opts.gridVars.isFocusCell) {
      return
    }
    const refTableBodyCenter = opts.refTableBodyCenter
    const refTableBodyLeft = opts.refTableBodyLeft

    const $focusCell =
      refTableBodyCenter.value.querySelectorAll('.anypjt-grid-cell-focus')[0] ||
      refTableBodyLeft.value.querySelectorAll('.anypjt-grid-cell-focus')[0]

    const { tableId, elemRowIdx, elemCellIdx } =
      mixmatUtils.getCellIndex($focusCell)

    navigator.clipboard
      .readText()
      .then((text) => {
        const rows = text.split('\n')
        const rowLen = rows.length
        let pasteVal = ''
        let failVal = ''

        for (let i = 0; i < rowLen; i++) {
          const cell = rows[i].split('\t')
          const cellLen = cell.length

          if (tableId === 'tableBodyLeft') {
            if (
              cellLen > 0 &&
              cell[0] &&
              Number(cell[0]) &&
              cell[0].trim().replace(/ /g, '').length === 7 &&
              (cell[0].startsWith('4') || cell[0].startsWith('6'))
            ) {
              if (pasteVal) {
                pasteVal += ','
              }

              pasteVal += cell[0]
            } else {
              if (failVal) {
                failVal += ','
              }

              failVal += cell[0]
            }
          } else if (tableId === 'tableBodyCenter') {
            if (pasteVal) {
              pasteVal += ','
            }

            pasteVal += cell[0]
          }
        }

        if (pasteVal && pasteVal.length !== 2) {
          opts.pasteInfo.tableId = tableId
          opts.pasteInfo.pasteVal = pasteVal
        }
        opts.pasteInfo.failVal = failVal
      })
      .catch((err) => {
        console.error('Failed to read clipboard contents: ', err)
      })
  },
  onCopy: (e) => {
    if (!mixmatUtils.canSelfCopyAndPaste(e)) {
      return
    }

    const opts = mixmatUtils.opts
    const refTableBodyCenter = opts.refTableBodyCenter
    const refTableBodyLeft = opts.refTableBodyLeft

    if (!opts.gridVars.isMultipleSelect) {
      return
    }

    const $focusCell =
      refTableBodyCenter.value.querySelectorAll('.anypjt-grid-cell-focus')[0] ||
      refTableBodyLeft.value.querySelectorAll('.anypjt-grid-cell-focus')[0]

    const { tableId, elemRowIdx, elemCellIdx } =
      mixmatUtils.getCellIndex($focusCell)

    const startCell = opts.gridVars.startCell
    const endCell = opts.gridVars.endCell
    let x1, x2, y1, y2

    if (startCell.elemCellIdx <= endCell.elemCellIdx) {
      x1 = startCell.elemCellIdx
      x2 = endCell.elemCellIdx
    } else {
      x1 = endCell.elemCellIdx
      x2 = startCell.elemCellIdx
    }
    if (startCell.elemRowIdx <= endCell.elemRowIdx) {
      y1 = startCell.elemRowIdx
      y2 = endCell.elemRowIdx
    } else {
      y1 = endCell.elemRowIdx
      y2 = startCell.elemRowIdx
    }

    const arrCopyText = []

    let $arrTd, i, j, arrRowCopyText
    const $arrTr =
      tableId === 'tableBodyLeft'
        ? refTableBodyLeft.value.querySelectorAll('tr.anypjt-grid-tr')
        : refTableBodyCenter.value.querySelectorAll('tr.anypjt-grid-tr')

    for (i = y1; i <= y2; i++) {
      arrRowCopyText = []
      $arrTd = $arrTr[i].querySelectorAll('td.anypjt-grid-td')
      for (j = x1; j <= x2; j++) {
        mixmatUtils.addClass($arrTd[j], 'anypjt-grid-cell-select')
        let copyText = $arrTd[j].querySelectorAll('div.anypjt-grid-cell')[0]
          .innerText

        if (
          copyText.indexOf('[▲]') > -1 ||
          copyText.indexOf('[▼]') > -1 ||
          copyText.indexOf('[상세]') > -1
        ) {
          copyText = copyText
            .replace('[▲]', '')
            .replace('[▼]', '')
            .replace('[상세]', '')
            .trim()
        }

        arrRowCopyText.push(copyText)
      }
      arrCopyText.push(arrRowCopyText.join('\t'))
    }

    window.navigator.clipboard.writeText(arrCopyText.join('\n')).then(() => {
      // alert('복사되었습니다')
    })
  },
  onKeydown: (e) => {
    const { gridVars } = mixmatUtils.opts
    const { cellData } = gridVars.focusCell

    if (e.key === 'Escape') {
      if (gridVars.isShowMenuCell) {
        gridVars.isShowMenuCell = false
      }

      if (gridVars.isShowMenuHeader) {
        gridVars.isShowMenuHeader = false
      }

      if (gridVars.isShowMateMemo) {
        gridVars.isShowMateMemo = false
      }

      if (gridVars.rowSelect.isSelect) {
        mixmatUtils.fnClearRowSelect()
      }

      // rate / gram 입력/수정 상ㅐ
      if (gridVars.inputMode.show) {
        mixmatUtils.fnInputMode({ type: 'CANCEL' })
      } else if (gridVars.isFocusCell) {
        mixmatUtils.clearFocusCell()
        mixmatUtils.clearMultipleSelectCell()
      }

      return
    }

    if (e.key === 'Escape' && gridVars.isShowMenuCell) {
      gridVars.isShowMenuCell = false
      return
    } else if (gridVars.rowSelect.isSelect) {
      if (e.altKey && e.key === 'ArrowUp') {
        e.preventDefault()
        mixmatUtils.upRow()
      } else if (e.altKey && e.key === 'ArrowDown') {
        e.preventDefault()
        mixmatUtils.downRow()
      }
      return
    } else if (!gridVars.isFocusCell) {
      // console.log('onKeydown', e)
      return
    }

    if (
      !gridVars.inputMode.show &&
      !gridVars.isShowMateMemo &&
      !e.altKey &&
      (e.key === 'ArrowUp' ||
        e.key === 'ArrowDown' ||
        e.key === 'ArrowLeft' ||
        e.key === 'ArrowRight' ||
        e.key === 'Tab' ||
        e.key === 'Enter')
    ) {
      mixmatUtils.onKeydownArrow(e) // 방향키 클릭시 처리
      return
    }

    if (e.key === 'Escape') {
      if (gridVars.inputMode.show) {
        mixmatUtils.fnInputMode({ type: 'CANCEL' })
        return
      } else if (gridVars.isFocusCell) {
        mixmatUtils.clearFocusCell()
        mixmatUtils.clearMultipleSelectCell()
        return
      }
      // F2
    }
    //  else if (e.key === 'F2') {
    //   if (!gridVars.inputMode.show) {
    //     mixmatUtils.fnInputMode({ type: 'SHOW' })
    //     return
    //   }
    //   // Ctrl + I
    // }
    else if (e.ctrlKey && (e.key === 'I' || e.key === 'i')) {
      if (gridVars.isFocusCell) {
        mixmatUtils.addRow()
        return
      }
      // Ctrl + D
    } else if (e.ctrlKey && (e.key === 'D' || e.key === 'd')) {
      if (gridVars.isFocusCell) {
        mixmatUtils.removeRow()
        return
      }
      // Ctrl + H
    } else if (e.ctrlKey && (e.key === 'H' || e.key === 'h')) {
      if (gridVars.isFocusCell) {
        mixmatUtils.hideRow()
        return
      }
      // Ctrl + G
    } else if (e.ctrlKey && (e.key === 'G' || e.key === 'g')) {
      if (gridVars.isFocusCell) {
        mixmatUtils.createGroup()
        return
      }
      // Alt + ArrowUp
    } else if (e.altKey && e.key === 'ArrowUp') {
      if (gridVars.isFocusCell) {
        e.preventDefault()
        mixmatUtils.upRow()
        return
      }
      // Alt + ArrowDown
    } else if (e.altKey && e.key === 'ArrowDown') {
      if (gridVars.isFocusCell) {
        e.preventDefault()
        mixmatUtils.downRow()
        return
      }
      // 숫자입력
    } else if (
      e.key === '0' ||
      e.key === '1' ||
      e.key === '2' ||
      e.key === '3' ||
      e.key === '4' ||
      e.key === '5' ||
      e.key === '6' ||
      e.key === '7' ||
      e.key === '8' ||
      e.key === '9' ||
      e.key === '.'
    ) {
      const currLot = gridVars.lots.find(
        (lot) => lot.vLotCd === cellData.vLotCd
      )
      const activeYn = currLot?.activeYn || 'N'
      const vFlagRateRest =
        currLot?.rateList?.find((rate) => rate.vMatePkCd === cellData.vMatePkCd)
          ?.vFlagRateRest || 'N'
      const vParentMatePkCd =
        gridVars.materials.find((mate) => mate.vMatePkCd === cellData.vMatePkCd)
          ?.vParentMatePkCd || null
      const vFlagComplete = currLot?.vFlagComplete || 'N'
      const vFlagDisabled = gridVars.reqInfo.otherVO.vFlagDisabled || 'N'

      if (
        !gridVars.inputMode.show &&
        cellData.columnId !== 'gram' &&
        ((cellData.vLotCd && activeYn === 'Y') ||
          cellData.columnId === 'vMateCd') &&
        vFlagRateRest === 'N' &&
        !vParentMatePkCd &&
        vFlagComplete === 'N' &&
        vFlagDisabled === 'N'
      ) {
        gridVars.rowAddMatePkCd = null
        if (cellData.isRowAdd) {
          gridVars.rowAddMatePkCd = cellData.vMatePkCd
        }

        cellData.vChkLotCd = cellData.vLotCd
        cellData.vChkMatePkCd = cellData.vMatePkCd

        const val = e.key === '.' ? '0.' : e.key
        mixmatUtils.fnInputMode({ type: 'SHOW_N_VALUE', val: val })
        return
      }
    }

    /*
    if (!gridVars.inputMode.show) {
      // console.log('onKeydown', gridVars.inputMode.show, e)
    }
    */
  },
  onClick: (e) => {
    const { gridVars } = mixmatUtils.opts

    const $target = e.target

    if (gridVars.isShowMenuCell) {
      gridVars.isShowMenuCell = false
      return
    } else if (gridVars.inputMode.show) {
      if (mixmatUtils.hasClass($target, 'apg-input-mode')) {
        return
      }

      mixmatUtils.fnInputMode({ type: 'CANCEL' })
      return
    }
  },
  // 방향키 클릭시 처리
  onKeydownArrow: (e) => {
    e.preventDefault()
    const { gridVars } = mixmatUtils.opts

    const focusCell = gridVars.focusCell
    let $arrTr = mixmatUtils.findElementsTr(focusCell.tableId)
    let trLen = $arrTr.length
    let tableId = focusCell.tableId
    let changeelemRowIdx = focusCell.elemRowIdx
    let changeelemCellIdx = focusCell.elemCellIdx

    if (e.key === 'ArrowUp') {
      if (focusCell.elemRowIdx === 0) {
        return
      }
      changeelemRowIdx--
    } else if (e.key === 'ArrowDown' || e.key === 'Enter') {
      if (focusCell.elemRowIdx === trLen - 1) {
        return
      }
      changeelemRowIdx++
    }

    let $arrTd = mixmatUtils.findElementsTd($arrTr[changeelemRowIdx])
    let tdLen = $arrTd.length

    if (e.key === 'ArrowLeft') {
      if (
        focusCell.tableId === 'tableBodyLeft' &&
        focusCell.elemCellIdx === 1
      ) {
        return
      } else if (focusCell.elemCellIdx === 0) {
        tableId = 'tableBodyLeft'
        changeelemCellIdx = gridVars.columnsForzenLeft.length - 1
      } else {
        changeelemCellIdx--
      }
    } else if (e.key === 'ArrowRight' || e.key === 'Tab') {
      if (
        focusCell.tableId === 'tableBodyCenter' &&
        focusCell.elemCellIdx === tdLen - 1
      ) {
        return
      } else if (focusCell.elemCellIdx === tdLen - 1) {
        tableId = 'tableBodyCenter'
        changeelemCellIdx = 0
      } else {
        changeelemCellIdx++
      }
    }

    if (tableId != focusCell.tableId) {
      $arrTr = mixmatUtils.findElementsTr(tableId)
      $arrTd = mixmatUtils.findElementsTd($arrTr[changeelemRowIdx])
    }

    if ($arrTd.length <= changeelemCellIdx) {
      changeelemCellIdx = 1
    }

    mixmatUtils.setFocusCell(
      mixmatUtils.findElementCell($arrTd[changeelemCellIdx])
    )
    mixmatUtils.clearMultipleSelectCell()
  },
  onTrMouseover: (e, rowIndex) => {
    const $tr1 = mixmatUtils.opts.refTableBodyCenter.value.querySelectorAll(
      `tr.anypjt-grid-tr.anypjt-grid-tr-ridx-${rowIndex}`
    )[0]
    const $tr2 = mixmatUtils.opts.refTableBodyLeft.value.querySelectorAll(
      `tr.anypjt-grid-tr.anypjt-grid-tr-ridx-${rowIndex}`
    )[0]

    mixmatUtils.addClass($tr1, 'apg-tr-mouseover')
    mixmatUtils.addClass($tr2, 'apg-tr-mouseover')
  },
  onTrMouseout: (e, rowIndex) => {
    const $tr1 = mixmatUtils.opts.refTableBodyCenter.value.querySelectorAll(
      `tr.anypjt-grid-tr.anypjt-grid-tr-ridx-${rowIndex}`
    )[0]
    const $tr2 = mixmatUtils.opts.refTableBodyLeft.value.querySelectorAll(
      `tr.anypjt-grid-tr.anypjt-grid-tr-ridx-${rowIndex}`
    )[0]

    mixmatUtils.removeClass($tr1, 'apg-tr-mouseover')
    mixmatUtils.removeClass($tr2, 'apg-tr-mouseover')
  },
  onLotMemoMouseover: (e) => {
    const $wrap = mixmatUtils.findParentElement(
      e.target,
      'DIV',
      'apg-lot-top-memo-wrap'
    )
    mixmatUtils.addClass($wrap, 'active')
  },
  onLotMemoMouseout: (e) => {
    const $wrap = mixmatUtils.findParentElement(
      e.target,
      'DIV',
      'apg-lot-top-memo-wrap'
    )
    mixmatUtils.removeClass($wrap, 'active')
  },
  canSelfCopyAndPaste: (e) => {
    if (e.target.tagName === 'INPUT') {
      return false
    }
    return true
  },
  findElementTrOfDataRowIndex: (tableId, rowIndex) => {
    let $tr = undefined
    if (tableId === 'tableBodyCenter') {
      $tr = mixmatUtils.opts.refTableBodyCenter.value.querySelectorAll(
        `tr.anypjt-grid-tr.anypjt-grid-tr-ridx-${rowIndex}`
      )[0]
    } else if (tableId === 'tableBodyLeft') {
      $tr = mixmatUtils.opts.refTableBodyLeft.value.querySelectorAll(
        `tr.anypjt-grid-tr.anypjt-grid-tr-ridx-${rowIndex}`
      )[0]
    }
    return $tr
  },
  findElementsTr: (tableId) => {
    let $arrTr = undefined

    if (tableId === 'tableBodyCenter') {
      $arrTr =
        mixmatUtils.opts.refTableBodyCenter.value.querySelectorAll(
          'tr.anypjt-grid-tr'
        )
    } else if (tableId === 'tableBodyLeft') {
      $arrTr =
        mixmatUtils.opts.refTableBodyLeft.value.querySelectorAll(
          'tr.anypjt-grid-tr'
        )
    }
    return $arrTr
  },
  findElementsTd: ($tr) => {
    return $tr.querySelectorAll('td.anypjt-grid-td')
  },
  findElementCell: ($td) => {
    return $td.querySelectorAll('div.anypjt-grid-cell')[0]
  },
  findParentElement: ($target, tagName, className) => {
    if (mixmatUtils.isElementTarget($target, tagName, className)) {
      return $target
    }

    let $findElem
    let $elem = $target
    let isLoop = true
    let cnt = 0

    while (isLoop) {
      $elem = $elem.parentElement

      if ($elem.tagName === 'BODY') {
        isLoop = false
      } else if (mixmatUtils.isElementTarget($elem, tagName, className)) {
        $findElem = $elem
        isLoop = false
      } else {
        cnt++
        if (cnt > 100) {
          isLoop = false
        }
      }
    }
    return $findElem
  },
  isElementTarget: ($target, tagName, className) => {
    if (tagName && className) {
      if (
        $target.tagName === tagName.toUpperCase() &&
        mixmatUtils.hasClass($target, className)
      ) {
        return true
      }
    } else if (tagName) {
      if ($target.tagName === tagName.toUpperCase()) {
        return true
      }
    } else if (className) {
      if (mixmatUtils.hasClass($target, className)) {
        return true
      }
    }
    return false
  },
  getLotHeaderStyle: (lotVo, type) => {
    let width = 100
    if (type === 'LOT') {
      if (lotVo.openYn === 'Y') {
        width = 100 + 80 + 200
      } else {
        width = 100 + 80
      }
    } else if (type === 'RATE') {
      width = 100
    } else if (type === 'GRAM') {
      width = 80
    } else if (type === 'ETC') {
      width = 200
    }
    return {
      width: width + 'px',
    }
  },
  fnToggleRowSelect: (e, rowIndex) => {
    const { gridVars } = mixmatUtils.opts
    const rowSelect = gridVars.rowSelect
    const materials = gridVars.materials
    const len = materials.length

    if (!rowSelect.isSelect) {
      rowSelect.isSelect = true
      rowSelect.startIndex = rowIndex
      materials[rowIndex].rowSelectYn = 'Y'
    } else {
      if (e.shiftKey) {
        const sidx =
          rowSelect.startIndex <= rowIndex ? rowSelect.startIndex : rowIndex
        const eidx =
          rowSelect.startIndex <= rowIndex ? rowIndex : rowSelect.startIndex

        for (let i = 0; i < len; i++) {
          if (sidx <= i && eidx >= i) {
            materials[i].rowSelectYn = 'Y'
          } else {
            materials[i].rowSelectYn = 'N'
          }
        }

        return 'SHIFT'
        // } else if (e.altKey) {
      } else {
        if (materials[rowIndex].rowSelectYn === 'Y') {
          materials[rowIndex].rowSelectYn = 'N'
        } else {
          materials[rowIndex].rowSelectYn = 'Y'
        }
        const selectCount = materials.filter(
          (vo) => vo.rowSelectYn === 'Y'
        ).length
        if (selectCount === 0) {
          rowSelect.isSelect = false
          rowSelect.startIndex = -1
        }

        return 'ALT'
      }
      // else {
      //   rowSelect.startIndex = rowIndex
      //   for (let i = 0; i < len; i++) {
      //     if (rowIndex === i) {
      //       if (materials[rowIndex].rowSelectYn === 'Y') {
      //         materials[i].rowSelectYn = 'N'
      //       } else {
      //         materials[i].rowSelectYn = 'Y'
      //       }
      //     } else {
      //       materials[i].rowSelectYn = 'N'
      //     }
      //   }
      // }
    }

    return null
  },
  fnClearRowSelect: () => {
    const { gridVars } = mixmatUtils.opts
    const rowSelect = gridVars.rowSelect
    const materials = gridVars.materials

    rowSelect.isSelect = false
    rowSelect.startIndex = -1

    for (let mateVo of materials) {
      if (mateVo.rowSelectYn === 'Y') {
        mateVo.rowSelectYn = 'N'
      }
    }
  },
  fnToggleLotExpand: (lotVo) => {
    if (lotVo.openYn === 'Y') {
      lotVo.openYn = 'N'
    } else {
      lotVo.openYn = 'Y'
    }

    const { gridVars } = mixmatUtils.opts

    if (gridVars.isMultipleSelect) {
      mixmatUtils.clearMultipleSelectCell()
    }
  },
  fnCalcLotChange: (lotVo) => {
    const { gridVars } = mixmatUtils.opts
    const rateAutoVo = mixmatUtils.getRateAutoVo(lotVo.vLotCd)
    const maxRate = new Big(100)
    // const maxGram = new Big(lotVo.maxGram)

    if (rateAutoVo) {
      let rate = new Big(0)
      let rateVo

      for (let mateVo of gridVars.materials) {
        rateVo = mixmatUtils.getRateVo(lotVo.vLotCd, mateVo.vMatePkCd)

        if (rateVo.flagAuto != 'Y') {
          rate = rate.plus(rateVo.nRate || 0)
        }
      }

      const restRate = maxRate.minus(rate)

      rateAutoVo.nRate = restRate

      if (lotVo.grams) {
        for (let gramVo of lotVo.grams) {
          rateAutoVo['gram_' + gramVo.gramSeq] = restRate
            .times(gramVo.nGram)
            .div(100)
        }
      }
    }
  },
  fnMateMemoPopup: (e, rowIndex) => {
    const { gridVars, refDivGridWrap, refLayerMateMemoWrap } = mixmatUtils.opts
    // const $arrTr = mixmatUtils.findElementsTr('tableBodyLeft')
    // const $tr = mixmatUtils.findParentElement(e.target, 'TR', 'anypjt-grid-tr')
    const $td = mixmatUtils.findParentElement(e.target, 'TD', 'anypjt-grid-td')
    // const trLen = $arrTr.length
    // let isAfter = true

    // if (trLen > 10) {
    //   let cnt = 0
    //   for (let i = trLen - 1; i >= 0; i--) {
    //     if ($arrTr[i] === $tr) {
    //       isAfter = false
    //       break
    //     }
    //     cnt++
    //     if (cnt > 3) {
    //       break
    //     }
    //   }
    // }

    const memo = gridVars.materials[rowIndex].vRamaMemoTxt || ''
    document.getElementById('txt-mate-memo').value = memo
    document.getElementById('p-mate-memo').innerHTML = memo
    if (memo) {
      document.getElementById('p-mate-memo').style.display = ''
      document.getElementById('txt-mate-memo').style.display = 'none'
    } else {
      document.getElementById('p-mate-memo').style.display = 'none'
      document.getElementById('txt-mate-memo').style.display = ''
    }

    gridVars.isShowMateMemo = true
    refLayerMateMemoWrap.value.dataset.rowIndex = rowIndex
    refLayerMateMemoWrap.value.style.left = $td.offsetLeft + 183 + 'px'
    refLayerMateMemoWrap.value.style.top = $td.offsetTop + 'px'

    // if (isAfter) {
    //   refLayerMateMemoWrap.value.style.top =
    //     $td.offsetTop + $td.offsetHeight + 'px'
    // } else {
    //   refLayerMateMemoWrap.value.style.top =
    //     $td.offsetTop - refLayerMateMemoWrap.value.offsetHeight + 'px'
    // }
  },
  fnMateMemoApply: () => {
    const { gridVars, refLayerMateMemoWrap } = mixmatUtils.opts
    const materials = gridVars.materials
    let rowIndex = refLayerMateMemoWrap.value.dataset.rowIndex

    try {
      rowIndex = parseInt(rowIndex, 10)
    } catch (e) {
      rowIndex = -1
    }
    if (rowIndex === -1) {
      return
    }

    const memo = document.getElementById('txt-mate-memo').value
    const pmemo = document.getElementById('p-mate-memo').innerText
    if (
      memo == pmemo &&
      document.getElementById('txt-mate-memo').style.display === 'none'
    ) {
      document.getElementById('p-mate-memo').style.display = 'none'
      document.getElementById('txt-mate-memo').style.display = ''
    } else {
      materials[rowIndex].vRamaMemoTxt = memo
      gridVars.isShowMateMemo = false

      gridVars.reqInfo.mateList = materials
      gridVars.info.mateList = materials
    }
  },
  fnToggleGroupOpen: (e, rowIndex) => {
    const { gridVars } = mixmatUtils.opts
    const { gridheight } = mixmatUtils.opts
    const materials = gridVars.materials
    const mateLen = materials.length
    const groupVo = materials[rowIndex]
    const vFlagGrpHide = groupVo.vFlagGrpHide === 'Y' ? 'N' : 'Y'
    let mateVo

    for (let i = rowIndex; i < mateLen; i++) {
      mateVo = materials[i]
      if (groupVo.vGrpCd === mateVo.vGrpCd) {
        mateVo.vFlagGrpHide = vFlagGrpHide
        // mateVo.vFlagMateHide = vFlagGrpHide
      } else {
        break
      }
    }

    gridVars.reqInfo.mateList = materials
    gridVars.info.mateList = materials

    gridheight.body = mixmatUtils.getGridHeight()
  },
  getGridHeight: () => {
    const { gridVars } = mixmatUtils.opts
    const materials = gridVars.materials
    return (
      materials.filter(
        (mate) => mate.vFlagMateHide !== 'Y' || mate.vRecType === 'GRP'
      ).length *
        4 -
      materials.filter((mate) => mate.vRecType === 'GRP').length
    )
  },
  textChangeBr: (text) => {
    if (!text) {
      return ''
    }
    return text.replaceAll('\n', '<br/>')
  },
  onFocusClear: () => {
    mixmatUtils.fnInputMode({ type: 'CANCEL' })
    mixmatUtils.clearFocusCell()
    mixmatUtils.clearMultipleSelectCell()
  },
  getMateTag: (mate, vLand1, vFlagHide, noteType) => {
    const mateIssue = []

    if (vFlagHide === 'Y') {
      return mateIssue
    }

    if (mate.vMateBanInfo === 'P') {
      mateIssue.push({
        issueNm: '금지',
        className: 'material-tag__ban',
      })
    }
    if (mate.vMateBanInfo === 'R') {
      mateIssue.push({
        issueNm: '비활성',
        className: 'material-tag__disabled',
      })
    }
    if (mate.vFlagGlbBanMate === 'Y') {
      mateIssue.push({
        issueNm: 'G 금지',
        className: 'material-tag__Gban',
      })
    }
    if (mate.vFlagGlbLimitMate === 'Y') {
      mateIssue.push({
        issueNm: 'G 제한',
        className: 'material-tag__Glimit',
      })
    }
    if (mate.vMateMaxMix && mate.vMateMaxMix !== '100') {
      mateIssue.push({
        issueNm: '배합한도',
        className: 'material-tag__ban color-gray',
      })
    }
    if (mate.vFlagTcodeMate === 'Y') {
      mateIssue.push({
        issueNm: '문제이력',
        className: 'material-tag__blue',
      })
    }
    if (mate.vFlagMrq030Mate === 'Y') {
      mateIssue.push({
        issueNm: '연구용B',
        className: 'material-tag__labB',
      })
    }
    if (mate.vFlagFreeBanMate === 'Y') {
      mateIssue.push({
        issueNm: '무소구 금지',
        className: 'material-tag__noMusogu',
      })
    }
    if (mate.vFlagFuncMate === 'Y') {
      mateIssue.push({
        issueNm: '기능성',
        className: 'material-tag__function',
      })
    }
    if (
      mate.vFlagColorMate === 'Y' ||
      (noteType === 'MU' && mixmatUtils.getCheckToningMate(mate))
    ) {
      mateIssue.push({
        issueNm: '조색',
        className: 'material-tag__toning',
      })
    }
    if (mate.vFlagMainIngredientMate === 'Y') {
      mateIssue.push({
        issueNm: '주성분',
        className: 'material-tag__blue',
      })
    }
    if (mate.vFlagNotIngrYn === 'Y' && vLand1 === 'UN') {
      mateIssue.push({
        issueNm: '구성성분 없음',
        className: 'material-tag__gray material-tag__noIng',
      })
    }
    if (mate.vFlagCancel === 'Y') {
      mateIssue.push({
        issueNm: '일시해제',
        className: 'material-tag__blue',
      })
    }

    return mateIssue
  },
  getGrams: (lot) => {
    const grams = []
    if (lot.vGramCd1) {
      grams.push({
        vLotCd: lot.vLotCd,
        nGram: lot.nGram1,
        gramSeq: lot.vGramCd1,
      })
    }
    if (lot.vGramCd2) {
      grams.push({
        vLotCd: lot.vLotCd,
        nGram: lot.nGram2,
        gramSeq: lot.vGramCd2,
      })
    }
    if (lot.vGramCd3) {
      grams.push({
        vLotCd: lot.vLotCd,
        nGram: lot.nGram3,
        gramSeq: lot.vGramCd3,
      })
    }
    if (lot.vGramCd4) {
      grams.push({
        vLotCd: lot.vLotCd,
        nGram: lot.nGram4,
        gramSeq: lot.vGramCd4,
      })
    }
    if (lot.vGramCd5) {
      grams.push({
        vLotCd: lot.vLotCd,
        nGram: lot.nGram5,
        gramSeq: lot.vGramCd5,
      })
    }
    if (lot.vGramCd6) {
      grams.push({
        vLotCd: lot.vLotCd,
        nGram: lot.nGram6,
        gramSeq: lot.vGramCd6,
      })
    }
    if (lot.vGramCd7) {
      grams.push({
        vLotCd: lot.vLotCd,
        nGram: lot.nGram7,
        gramSeq: lot.vGramCd7,
      })
    }
    if (lot.vGramCd8) {
      grams.push({
        vLotCd: lot.vLotCd,
        nGram: lot.nGram8,
        gramSeq: lot.vGramCd8,
      })
    }
    if (lot.vGramCd9) {
      grams.push({
        vLotCd: lot.vLotCd,
        nGram: lot.nGram9,
        gramSeq: lot.vGramCd9,
      })
    }
    if (lot.vGramCd10) {
      grams.push({
        vLotCd: lot.vLotCd,
        nGram: lot.nGram10,
        gramSeq: lot.vGramCd10,
      })
    }

    if (grams.length === 0) {
      grams.push({
        vLotCd: lot.vLotCd,
        nGram: null,
        gramSeq: 'tmp_gram_' + lot.vLotCd + '_' + 1,
      })
    }

    return grams
  },
  getColums: (o = [], isBaseRate = false) => {
    const columnData = o.map((col, idx) => {
      return {
        code: col.vColumn,
        header:
          col.vColumn !== 'nBiodRsltVl'
            ? col.vColumnSetCdnm
            : '생분해도<br/>지수',
        width: 57,
        classHeader:
          idx + 1 === o.length && !isBaseRate ? 'border-right__deepgray' : '',
      }
    })

    if (isBaseRate) {
      columnData.push({
        code: 'nBaseRate',
        header: '베이스함량',
        width: 57,
        classHeader: 'border-right__deepgray',
      })
    }

    const defaultColumn = [
      {
        code: 'rowNum',
        header: 'NO',
        width: 30, //30
        classHeader: 'th-no',
      },
      {
        code: 'vMateCd',
        header: 'CODE',
        width: 140, //77
        classHeader: 'th-code',
      },
      {
        code: 'vMateNm',
        header: 'NAME',
        width: 370, //353
        classHeader: 'th-name',
      },
    ]

    return [...defaultColumn, ...columnData]
  },
  getFooterRows: (o) => {
    return {
      musogu:
        o.find((row) => row.vColumnSetCd === 'COLUMN09')?.vFlagHide || 'Y',
      priceSum:
        o.find((row) => row.vColumnSetCd === 'COLUMN10')?.vFlagHide || 'Y',
      noi: o.find((row) => row.vColumnSetCd === 'COLUMN05')?.vFlagHide || 'Y',
      biodegradability:
        o.find((row) => row.vColumnSetCd === 'COLUMN06')?.vFlagHide || 'Y',
    }
  },
  getBtnShow: (t, lotVo, o, noteType = '') => {
    if (t === 'BOM') {
      if (
        lotVo.vLotCd.indexOf('tmp_lot_') < 0 &&
        (!lotVo.vTumnTsntLotStCd || lotVo.vTumnTsntLotStCd === 'LOT_01') &&
        o.contVO.vFlagExistsDecide !== 'Y' &&
        o.contVO.vCodeType !== 'AEROSOL' &&
        o.contVO.vPageType !== 'nonprd' &&
        o.rvo.vStatusCd !== 'LNC06_50' &&
        noteType === 'SC'
      ) {
        // BOM 임시전송 여부랑 관계 없이 전송가능하게 해제
        // if (o.rvo.vStatusCd !== 'LNC06_22') {
        //   if (lotVo.vFlagExistsBom !== 'Y' && lotVo.vFlagComplete === 'Y') {
        //     return true
        //   }
        // } else {
        //   return true
        // }
        return true
      }
    } else if (t === 'PILOT') {
      if (
        lotVo.vLotCd.indexOf('tmp_lot_') < 0 &&
        (!lotVo.vTumnTsntLotStCd || lotVo.vTumnTsntLotStCd === 'LOT_01') &&
        o.contVO.vCodeType !== 'AEROSOL' &&
        o.contVO.vPageType !== 'nonprd' &&
        o.rvo.vStatusCd !== 'LNC06_50'
      ) {
        if (o.rvo.vStatusCd !== 'LNC06_22') {
          if (
            // 파일럿 항상 등록가능하게 해제
            // !lotVo.nPilotTestSeqno &&
            // lotVo.vFlagComplete === 'Y' &&
            o.rvo.vStatusCd !== 'LNC06_30' &&
            o.rvo.vStatusCd !== 'LNC06_26' &&
            o.rvo.vStatusCd !== 'LNC06_40' &&
            o.rvo.vStatusCd !== 'LNC06_51'
          ) {
            return true
          }
        } else {
          return true
        }
      }
    } else if (t === 'DECIDE') {
      if (
        lotVo.vLotCd.indexOf('tmp_lot_') < 0 &&
        (o.contVO.vCodeType === 'AEROSOL' ||
          (lotVo.vFlagBomReq === 'Y' && lotVo.vTumnTsntLotStCd === 'LOT_02')) &&
        o.contVO.vFlagExistsDecide !== 'Y' &&
        o.rvo.vStatusCd !== 'LNC06_41'
      ) {
        if (o.rvo.vStatusCd !== 'LNC06_22') {
          if (lotVo.vFlagComplete === 'Y' && o.rvo.vStatusCd !== 'LNC06_27') {
            return true
          }
        } else {
          return true
        }
      }
    } else if (t === 'INGREDIENT' || t === 'CANCEL' || t === 'ORDER_BY') {
      if (
        lotVo.vLotCd.indexOf('tmp_lot_') < 0 &&
        lotVo.vFlagDecide === 'Y' &&
        o.rvo.vStatusCd !== 'LNC06_50'
      ) {
        if (t === 'INGREDIENT') {
          if (
            lotVo.vTumnTsntLotStCd === 'LOT_03' &&
            o.rvo.vStatusCd === 'LNC06_30' &&
            o.contVO.vCodeType !== 'AEROSOL' &&
            o.contVO.vPageType === 'prd'
          ) {
            return true
          }
        } else if (t === 'CANCEL') {
          if (
            (lotVo.vTumnTsntLotStCd === 'LOT_03' ||
              lotVo.vTumnTsntLotStCd === 'LOT_04') &&
            o.rvo.vStatusCd !== 'LNC06_51'
          ) {
            return true
          }
        } else {
          if (
            o.contVO.vCodeType !== 'AEROSOL' &&
            o.rvo.vStatusCd !== 'LNC06_51'
          ) {
            return true
          }
        }
      }
    } else if (t === 'RELEASE') {
      if (
        lotVo.vLotCd.indexOf('tmp_lot_') < 0 &&
        lotVo.vFlagDecide === 'Y' &&
        lotVo.vTumnTsntLotStCd === 'LOT_05' &&
        o.rvo.vStatusCd === 'LNC06_51'
      ) {
        return true
      }
    } else if (t === 'CHANGE_SAVE') {
      if (
        o.contVO.vFlagExistsDecide !== 'Y' &&
        // o.rvo.vStatusCd !== 'LNC06_26' &&
        // o.rvo.vStatusCd !== 'LNC06_30' &&
        // o.rvo.vStatusCd !== 'LNC06_40' &&
        o.rvo.vStatusCd !== 'LNC06_41' &&
        o.rvo.vStatusCd !== 'LNC06_50' &&
        o.rvo.vStatusCd !== 'LNC06_51'
      ) {
        return true
      }
    } else if (t === 'CHECK_INGREDIENT') {
      if (o.rvo.vStatusCd !== 'LNC06_41' && o.rvo.vStatusCd !== 'LNC06_50') {
        return true
      }
    }

    return false
  },
  getLotCircle: (o) => {
    if (!o) {
      return null
    }

    return o.substr(o.length - 1)
  },
  getLotBottomLine: (o) => {
    const { gridVars } = mixmatUtils.opts

    if (o === 'sumData') {
      return gridVars.rowsForzen.musogu === 'Y' &&
        gridVars.rowsForzen.priceSum === 'Y' &&
        gridVars.rowsForzen.noi === 'Y' &&
        gridVars.rowsForzen.biodegradability === 'Y'
        ? 'border-bottom__blue'
        : ''
    } else if (o === 'musogu') {
      return gridVars.rowsForzen.priceSum === 'Y' &&
        gridVars.rowsForzen.noi === 'Y' &&
        gridVars.rowsForzen.biodegradability === 'Y'
        ? 'border-bottom__blue'
        : ''
    } else if (o === 'priceSum') {
      return gridVars.rowsForzen.noi === 'Y' &&
        gridVars.rowsForzen.biodegradability === 'Y'
        ? 'border-bottom__blue'
        : ''
    } else if (o === 'noi') {
      return gridVars.rowsForzen.biodegradability === 'Y'
        ? 'border-bottom__blue'
        : ''
    }
  },
  getCheckToningMate: (o) => {
    return (
      o.vMateCd?.startsWith('4') || o.vMateTempCd?.startsWith('4')
      // ||      o.vHal4MateCd?.startsWith('4')
    )
  },
}
/* eslint-enable */

export default mixmatUtils
