<template>
  <component :is="resolveLayout" v-cloak>
    <router-view></router-view>
  </component>
  <spinner-layout :loading="store.getters.getLoading()"></spinner-layout>
</template>

<script>
import { computed, defineAsyncComponent, provide, readonly, watch, reactive } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useI18n } from 'vue-i18n'
import { useStore } from 'vuex'
import commonUtils from '@/utils/commonUtils'
import { useActions } from 'vuex-composition-helpers'

export default {
  components: {
    LayoutBlank: defineAsyncComponent(() => import('@/components/layout/LayoutBlank.vue')),
    LayoutError: defineAsyncComponent(() => import('@/components/layout/LayoutError.vue')),
    LayoutContentType: defineAsyncComponent(() => import('@/components/layout/LayoutContentType.vue')),
    LayoutDetail: defineAsyncComponent(() => import('@/components/layout/LayoutDetail.vue')),
    SpinnerLayout: defineAsyncComponent(() => import('@/components/comm/Spinner.vue')),
  },
  setup () {

    const { t } = useI18n()
    const route = useRoute()
    const router = useRouter()
    const store = useStore()
    const myInfo = store.getters.getMyInfo()
    const { openAsyncAlert } = useActions(['openAsyncAlert'])

    provide('t', readonly(t))
    provide('commonUtils', readonly(commonUtils))

    const resolveLayout = computed(() => {
      if (route.name === null || route.name === undefined) {
        return null
      }

      store.dispatch('setMstMenuid', route.meta.menuid)

      if (route.meta.layout === 'blank') {
        return 'layout-blank'
      } else if (route.meta.layout === 'error') {
        return 'layout-error'
      } else if (route.meta.layout === 'detail') {
        return 'layout-detail'
      }

      return 'layout-content-type'
    })

    const routeInfo = computed(() => {
      if (route.name === null || route.name === undefined) {
        return null
      }
      return {
        name: route.name,
        meta: route.meta || {}
      }
    })

    // 1시간 미사용시 로그아웃
    const logoutTimer = reactive({
      count: 0,
      showWarning: undefined,
      doLogout: undefined
    })

    const setLogoutTimers = (eventName) => {
      if (logoutTimer.showWarning !== undefined) {
        clearTimeout(logoutTimer.showWarning)
        clearTimeout(logoutTimer.doLogout)
        logoutTimer.showWarning = undefined
        logoutTimer.doLogout = undefined
      }

      logoutTimer.showWarning = setTimeout(() => {
        openAsyncAlert({ message: t('10분후 장시간 미사용으로 인해 <br/>로그아웃 처리 됩니다.') })
      }, 1000 * 60 * 50)

      logoutTimer.doLogout = setTimeout(() => {
        store.dispatch('signout').then(async res => {
          const resData = res.data
          if (resData.code === 'C0000') {
            await openAsyncAlert({ message: t('장시간 미사용으로 인해 <br/>로그아웃 처리 되었습니다.') })
            router.push({ path: '/login' })
          }
        })
      }, 1000 * 60 * 60)
    }

    const goLoginPage = () => {
      const historyUrl = window.location.href
        if (historyUrl.indexOf('/login') === -1) {
          sessionStorage.setItem('historyUrl', historyUrl)
        }
        window.location.href = '/login'
    }

    // 로그인 여부 체크
    watch(() => routeInfo.value, (newVal, oldVal) => {
      if (newVal === null || newVal === undefined) {
        return
      }

      if (myInfo !== undefined && myInfo.userCd !== undefined) {
        return
      }

      const nowMyInfo = store.getters.getMyInfo()
      const authAnyone = newVal.meta.authAnyone !== undefined && newVal.meta.authAnyone
      if (!authAnyone && (nowMyInfo === undefined || nowMyInfo.loginId === undefined)) {
        
        if (import.meta.env.VITE_SERVER_MODE !== 'PRD') {
          goLoginPage()
        }
      }

      const noteType = store.getters.getNoteType()

      if (nowMyInfo && nowMyInfo.loginId !== undefined && nowMyInfo.loginId != null && nowMyInfo.loginId !== '' && noteType) {
        const loadRecentListFlag = sessionStorage.getItem('loadRecentListFlag' + noteType)
        if (!loadRecentListFlag || loadRecentListFlag !== 'Y') {
          if (commonUtils.isNotEmpty(noteType) && 'SC|MU|HBO|SA'.indexOf(noteType) > -1) {
            store.dispatch('findRecentLogList', { vNoteType: noteType })
          }
        }
      }
      
      //그냥 다시 로그아웃 ->라우터 이동 한 다음에 다시 작동 시킬때 필요.
      if(Object.keys(nowMyInfo).length > 0){
        ['mousedown', 'scroll', 'keypress', 'load'].forEach((eventName) => {
          window.addEventListener(eventName, () => {
            setLogoutTimers(eventName)
          })
        })        
        setLogoutTimers('init')
      }else{
        ['mousedown', 'scroll', 'keypress', 'load'].forEach((eventName) => {
          window.removeEventListener(eventName, () => {})
        })
      }
    }, { immediate: true })

    //처음이나 새로 고침 했을 때 작동
    if(Object.keys(myInfo).length > 0){
      ['mousedown', 'scroll', 'keypress', 'load'].forEach((eventName) => {
        window.addEventListener(eventName, () => {
          setLogoutTimers(eventName)
        })
      })
      setLogoutTimers('init')
    }else{
      ['mousedown', 'scroll', 'keypress', 'load'].forEach((eventName) => {
        window.removeEventListener(eventName, () => {})
      })        
    }

    return {
      store,
      resolveLayout
    }
  }
}
</script>

<style lang="scss">

</style>
