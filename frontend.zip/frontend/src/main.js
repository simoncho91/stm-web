import { createApp, defineAsyncComponent } from 'vue'
import { createI18n } from 'vue-i18n'
import { store } from './store/index.js'
import App from './App.vue'
import router from './router'
import messages from './locales/index.js'
import LoadScript from 'vue-plugin-load-script'
import './assets/css/mybeaker.css'
// import { SetupCalendar, Calendar, DatePicker } from 'v-calendar'
import { Calendar, DatePicker } from 'v-calendar'
import 'v-calendar/dist/style.css'
// import VueExcelEditor from 'vue3-excel-editor' //엑셀 에디터
import { dynamicRouterInit } from '@/router/dynamicRouter'
import Treeselect from 'vue3-treeselect'
import 'vue3-treeselect/dist/vue3-treeselect.css'
import Draggable from "vuedraggable"
import '@imengyu/vue3-context-menu/lib/vue3-context-menu.css'
import { ContextMenu, ContextMenuItem } from '@imengyu/vue3-context-menu'
import ApQrCode from 'vue-qrcode'


//[S]tab sesstionStorage 공유
if (!sessionStorage.length) {
  localStorage.setItem('getSessionStorage', Date.now());
  localStorage.setItem('sessionStorage', JSON.stringify(sessionStorage));
}

window.addEventListener('storage', function(event) {
  if (event.key == 'getSessionStorage') {
    localStorage.setItem('sessionStorage', JSON.stringify(sessionStorage));
    localStorage.removeItem('sessionStorage');
  } else {
    const data = JSON.parse(event.newValue);
    for (let key in data) {
      if(key !== 'ssoToken'){
        sessionStorage.setItem(key, data[key])
      }
    }

    const sessionToken = sessionStorage.getItem('accessToken') || ''
    if(sessionToken){
      store.dispatch('signinByToken', { sessionToken: sessionToken, localToken : '' }).then(() => {
        //로그인 페이지로 들어왔을때 main으로 보내버리는 로직 추가
        if(window.location.pathname.indexOf('login') > -1){
          router.push({ path: '/main' })
        }
      })
    }
  }
})
//[E]tab sesstionStorage 공유   

const init = () => {
  const sessionToken = sessionStorage.getItem('accessToken') || ''
  const localToken = localStorage.getItem('accessToken') || ''
  if (sessionToken) {
    return store.dispatch('signinByToken', { sessionToken: sessionToken, localToken : '' })
  } else if (localToken) {
    return store.dispatch('signinByToken', { localToken: localToken })
  }
  return Promise.resolve()
}

//window.addEventListener('storage') 이벤트 발생 시간과 init 쪽에 gap 이 존재하여
//setTimeout 줌, tab 새로 추가해서 호출할 경우 잠깐의 화면 번쩍임이 존재할 수 있다.
setTimeout(() => {
  init().then(() => {
    const i18n = createI18n({
      legacy: false,
      locale: store.getters['getLangCd'](),
      fallbackLocale: 'ko',
      warnHtmlMessage: false,
      messages
    })

    dynamicRouterInit()
    
    const app = createApp(App)
    app.use(store)
    app.use(router)
    app.use(i18n)
    app.use(LoadScript)
    // app.use(VueExcelEditor)
    app.use(ContextMenu)
    // app.use(SetupCalendar, {})

    app.config.globalProperties.tiumUrl = import.meta.env.VITE_TIUM_URL
    app.config.globalProperties.serverMode = import.meta.env.VITE_SERVER_MODE
  
    //component에 담아서 공통으로 자주 사용할 부분은 이곳에 정의
    app.component('Calendar', Calendar)
    app.component('DatePicker', DatePicker)
    app.component('ApDatePickerRange', defineAsyncComponent(() => import('@/components/comm/ApDatePickerRange.vue')))
    app.component('ApDatePicker', defineAsyncComponent(() => import('@/components/comm/ApDatePicker.vue')))
    app.component('ApMonthPicker', defineAsyncComponent(() => import('@/components/comm/ApMonthPicker.vue')))
    app.component('ApYearPicker', defineAsyncComponent(() => import('@/components/comm/ApYearPicker.vue')))
    app.component('ApAlert', defineAsyncComponent(() => import('@/components/comm/ApAlert.vue')))
    app.component('ApInput', defineAsyncComponent(() => import('@/components/comm/ApInput.vue')))
    app.component('ApInputCheck', defineAsyncComponent(() => import('@/components/comm/ApInputCheck.vue')))
    app.component('ApInputRadio', defineAsyncComponent(() => import('@/components/comm/ApInputRadio.vue')))
    app.component('ApSelectbox', defineAsyncComponent(() => import('@/components/comm/ApSelectbox.vue')))
    app.component('ApTextArea', defineAsyncComponent(() => import('@/components/comm/ApTextArea.vue')))
    app.component('ApChoosebox', defineAsyncComponent(() => import('@/components/comm/ApChoosebox.vue')))
    app.component('ApBreadcrumb', defineAsyncComponent(() => import('@/components/comm/ApBreadcrumb.vue')))
    app.component('TreeSelect', Treeselect)
    app.component('Draggable', Draggable)
    app.component('ContextMenu', ContextMenu)
    app.component('ContextMenuItem', ContextMenuItem)
    app.component('ApQrCode', ApQrCode)
    app.mount('#app')
  })
}, 300);