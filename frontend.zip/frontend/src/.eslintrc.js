module.exports = {
  extends: [
    'plugin:vue/vue3-essential',
    'prettier'
  ],
  rules: {
    'vue/no-unused-vars': 'error',
    'vue/no-multiple-template-root': 0,
    'vue/multi-word-component-names': [
      'error', {
        'ignores': ['Calendar', 'Draggable']
      }
    ]
  }
}