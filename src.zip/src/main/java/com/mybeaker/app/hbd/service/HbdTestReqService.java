package com.mybeaker.app.hbd.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.mybeaker.app.common.form.MailForm;
import com.mybeaker.app.common.model.AlarmRegDTO;
import com.mybeaker.app.common.model.CodeDTO;
import com.mybeaker.app.common.model.GroupUserInfoDTO;
import com.mybeaker.app.common.model.MailDTO;
import com.mybeaker.app.common.model.OrganizationDTO;
import com.mybeaker.app.common.model.ResultDTO;
import com.mybeaker.app.common.service.CommonService;
import com.mybeaker.app.hbd.mapper.HbdTestReqMapper;
import com.mybeaker.app.hbd.model.HbdNoteInfoDTO;
import com.mybeaker.app.hbd.model.HbdNoteMstVerTagVO;
import com.mybeaker.app.hbd.model.HbdTestReqResDTO;
import com.mybeaker.app.labnote.model.ChinaSafetyMsgVO;
import com.mybeaker.app.labnote.model.ChinaSafetyMstVO;
import com.mybeaker.app.labnote.model.CpsrTesterUserVO;
import com.mybeaker.app.labnote.model.ElabNoteLastTrInfoDTO;
import com.mybeaker.app.labnote.model.EssentialTestAddVO;
import com.mybeaker.app.labnote.model.InsertSupTrPrdInfoDTO;
import com.mybeaker.app.labnote.model.LabNoteMusoguTemp2DTO;
import com.mybeaker.app.labnote.model.LabNoteMusoguTempDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessPqcCheckApprReqDTO;
import com.mybeaker.app.labnote.model.LabNoteSupTrPrdInfoDTO;
import com.mybeaker.app.labnote.model.LabNoteTestReqContVO;
import com.mybeaker.app.labnote.model.LabNoteTestReqDTO;
import com.mybeaker.app.labnote.model.LabNoteTestReqLotVO;
import com.mybeaker.app.labnote.model.LabNoteTestReqRegDTO;
import com.mybeaker.app.labnote.model.LabNoteTestReqTagListVO;
import com.mybeaker.app.labnote.model.LabNoteTestSavePrsvReqDTO;
import com.mybeaker.app.labnote.model.LabNoteValidateDTO;
import com.mybeaker.app.labnote.model.LabNoteVersionDTO;
import com.mybeaker.app.labnote.model.LotStatusRegDTO;
import com.mybeaker.app.labnote.model.MusoguInfoVO;
import com.mybeaker.app.labnote.model.MusoguRateVO;
import com.mybeaker.app.labnote.model.MusoguReqDTO;
import com.mybeaker.app.labnote.model.MusoguTagVO;
import com.mybeaker.app.labnote.model.ProdSignResDTO;
import com.mybeaker.app.labnote.model.SupTrComponentVO;
import com.mybeaker.app.labnote.model.SupTrProdMarkDTO;
import com.mybeaker.app.labnote.model.SupTrProductSameVO;
import com.mybeaker.app.labnote.model.SupTrProductSimpleInfoVO;
import com.mybeaker.app.labnote.model.TddProductClassVO;
import com.mybeaker.app.labnote.model.TestReqCounterDTO;
import com.mybeaker.app.labnote.model.TestReqCounterMrq011DTO;
import com.mybeaker.app.labnote.model.VersionListVO;
import com.mybeaker.app.labnote.model.Zplm013MosAjaxVO;
import com.mybeaker.app.labnote.service.LabNoteCommonService;
import com.mybeaker.app.model.Const;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.testreq.mapper.TestReqCommonMapper;
import com.mybeaker.app.testreq.model.TestRequestMrq011MailDTO;
import com.mybeaker.app.testreq.model.TestRequestMrq011MailReqDTO;
import com.mybeaker.app.testreq.model.TestRequestMrq011MailResDTO;
import com.mybeaker.app.testreq.service.TestReqCommonService;
import com.mybeaker.app.utils.CommonUtil;
import com.mybeaker.app.utils.ConvertUtil;
import com.mybeaker.app.utils.MailUtil;
import com.mybeaker.app.utils.SessionUtil;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class HbdTestReqService {

	private final HbdTestReqMapper hbdTestReqMapper;

	private final TestReqCommonService testReqCommonService;

	private final TestReqCommonMapper testReqCommonMapper;

	private final HbdCommonService hbdCommonService;

	private final SessionUtil sessionUtil;

	private final LabNoteCommonService labNoteCommonService;

	private final CommonService commonService;

	//시험의뢰 기능성
	public ResponseVO selectPrdTestReqFuncInfo(LabNoteTestReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();
		List<LabNoteTestReqLotVO> lotList = null;

		if(StringUtils.isEmpty(reqDTO.getVLabNoteCd()) || reqDTO.getNVersion()<1) {
			responseVO.setOk("필수 입력값이 없습니다");
			return responseVO;
		}

		HbdNoteInfoDTO noteVo = hbdCommonService.selectLabNoteInfo(reqDTO.getVLabNoteCd());

		if(ObjectUtils.isEmpty(noteVo)) {
			responseVO.setOk("해당 실험노트를 찾을수 없습니다.");
			return responseVO;
		}

		String mrqTypeCd = reqDTO.getVMrqTypeCd();
		String trMrqTypeCd = "";
		String trGoalCd = "";

		//  기능성
		if (mrqTypeCd.indexOf("MRQ040_FUNC") > -1) {
			trMrqTypeCd = "MRQ040";
			trGoalCd = "TMG010";
		}
		// 유해물질
		else if (mrqTypeCd.indexOf("MRQ040_HARM") > -1) {
			trMrqTypeCd = "MRQ040";
			trGoalCd = "TMG030";
		}
		else {
			trMrqTypeCd = mrqTypeCd;
			trGoalCd = "";
		}

		reqDTO.setVTrMrqTypeCd(trMrqTypeCd);
		reqDTO.setVTrGoalCd(trGoalCd);

		//MU,HBO 개발 취소 된 내용물 제외 >> CONT.V_FLAG_CANCEL ='N'
		List<LabNoteTestReqContVO> contList = hbdTestReqMapper.selectTestReqContList(reqDTO.getVLabNoteCd(), reqDTO.getVPlantCd());

//		int contSize = contList == null ? 0 : contList.size();
//
//		if (contSize > 0) {
//
//			reqDTO.setVLanguage(sessionUtil.getLocalLanguage());
//			lotList = hbdTestReqMapper.selectTestReqLotList(reqDTO);
//		}

		if (!ObjectUtils.isEmpty(contList)) {

			reqDTO.setVLanguage(sessionUtil.getLocalLanguage());
			lotList = hbdTestReqMapper.selectTestReqLotList(reqDTO);

			if (!ObjectUtils.isEmpty(lotList)) {
				final List<LabNoteTestReqLotVO> copiedList = lotList.stream().collect(Collectors.toList());

				contList.stream().forEach(cvo -> {
					cvo.setSubList(copiedList.stream().filter(lvo -> lvo.getVContPkCd().equals(cvo.getVContPkCd())).collect(Collectors.toList()));
				});
			}
		}

		//안전성 및 방부 시험의뢰 인 경우,버전정보도 가져오기
		//lotList를 가지고 올때는 contPkCd가 있으면 안되기 때문에 팝업창OPEN시 파라미터를
		//i_sOtherContPkCd로 이름을 바꿔서 보내고 여기서 재정의해서 사용 후 다시 리셋시킨다

		// 해당 시험의뢰 마지막 버전
		reqDTO.setVFlagAllLast("N");
		ElabNoteLastTrInfoDTO lastTrVo = testReqCommonMapper.selectElabLastTrInfo(reqDTO.getVLabNoteCd(), reqDTO.getVFlagAllLast(), reqDTO.getVFlagUseGate(), reqDTO.getVMrqTypeCd(), reqDTO.getVGateCd());

		// 전체 마지막 버전
		reqDTO.setVFlagAllLast("Y");
		ElabNoteLastTrInfoDTO allLastTrVo = testReqCommonMapper.selectElabLastTrInfo(reqDTO.getVLabNoteCd(), reqDTO.getVFlagAllLast(), reqDTO.getVFlagUseGate(), reqDTO.getVMrqTypeCd(), reqDTO.getVGateCd());
		//방부시험의뢰가 아닐경우
		// 전체 다 입력 받는건 전체 기준으로 마지막 정보를 가져옴
		if (allLastTrVo != null) {
			if (lastTrVo == null) {
				lastTrVo = new ElabNoteLastTrInfoDTO();
			}
			lastTrVo.setVDosageFormCd(allLastTrVo.getVDosageFormCd());
		}

		String vFlagZmBbNote = "Y";

		responseVO.setOk(HbdTestReqResDTO.builder()
				.noteVo(noteVo)
				.contList(contList)
				.lotList(lotList)
				.lastTrVo(lastTrVo)
				.vFlagZmBbNote(vFlagZmBbNote)
				.vTrMrqTypeCd(trMrqTypeCd)
				.vTrGoalCd(trGoalCd)
				.build());
		return responseVO;

	}

	//시험의뢰 무소구
	public ResponseVO selectPrdTestReqMusoInfo(LabNoteTestReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();
		List<LabNoteTestReqLotVO> lotList = null;

		if(StringUtils.isEmpty(reqDTO.getVLabNoteCd()) || reqDTO.getNVersion()<1) {
			responseVO.setOk("필수 입력값이 없습니다");
			return responseVO;
		}

		HbdNoteInfoDTO noteVo = hbdCommonService.selectLabNoteInfo(reqDTO.getVLabNoteCd());

		if(ObjectUtils.isEmpty(noteVo)) {
			responseVO.setOk("해당 실험노트를 찾을수 없습니다.");
			return responseVO;
		}

		String mrqTypeCd = reqDTO.getVMrqTypeCd();
		String trMrqTypeCd = "";
		String trGoalCd = "";

		//  기능성
		if (mrqTypeCd.indexOf("MRQ040_FUNC") > -1) {
			trMrqTypeCd = "MRQ040";
			trGoalCd = "TMG010";
		}
		// 유해물질
		else if (mrqTypeCd.indexOf("MRQ040_HARM") > -1) {
			trMrqTypeCd = "MRQ040";
			trGoalCd = "TMG030";
		}
		else {
			trMrqTypeCd = mrqTypeCd;
			trGoalCd = "";
		}

		reqDTO.setVTrMrqTypeCd(trMrqTypeCd);
		reqDTO.setVTrGoalCd(trGoalCd);

		List<LabNoteTestReqContVO> contList = hbdTestReqMapper.selectTestReqContList(reqDTO.getVLabNoteCd(), reqDTO.getVPlantCd());

//		int contSize = contList == null ? 0 : contList.size();
//
//		if (contSize > 0) {
//
//			reqDTO.setVLanguage(sessionUtil.getLocalLanguage());
//			lotList = hbdTestReqMapper.selectTestReqLotList(reqDTO);
//		}
		if (!ObjectUtils.isEmpty(contList)) {

			reqDTO.setVLanguage(sessionUtil.getLocalLanguage());
			lotList = hbdTestReqMapper.selectTestReqLotList(reqDTO);

			if (!ObjectUtils.isEmpty(lotList)) {
				final List<LabNoteTestReqLotVO> copiedList = lotList.stream().collect(Collectors.toList());

				contList.stream().forEach(cvo -> {
					cvo.setSubList(copiedList.stream().filter(lvo -> lvo.getVContPkCd().equals(cvo.getVContPkCd())).collect(Collectors.toList()));
				});
			}
		}

		String getListType = "CHOOSE";

		List<MusoguTagVO> mtr03List = hbdCommonService.selectLabNoteTagList(MusoguReqDTO.builder()
				.vLabNoteCd(reqDTO.getVLabNoteCd())
				.language(sessionUtil.getLangCd())
				.vTempTag1Cd("MTR03")
				.vGetListType(getListType)
				.build()); // 해당 게시글 프리소구 공통

		List<MusoguTagVO> mtr04List = hbdCommonService.selectLabNoteTagList(MusoguReqDTO.builder()
				.vLabNoteCd(reqDTO.getVLabNoteCd())
				.language(sessionUtil.getLangCd())
				.vTempTag1Cd("MTR04")
				.vGetListType(getListType)
				.build()); // 해당 게시글 프리소구 공통

		List<MusoguTagVO> mtr05List = hbdCommonService.selectLabNoteTagList(MusoguReqDTO.builder()
				.vLabNoteCd(reqDTO.getVLabNoteCd())
				.language(sessionUtil.getLangCd())
				.vTempTag1Cd("MTR05")
				.vGetListType(getListType)
				.build()); // 해당 게시글 프리소구 특화

		List<MusoguTagVO> mtr06List = hbdCommonService.selectLabNoteTagList(MusoguReqDTO.builder()
				.vLabNoteCd(reqDTO.getVLabNoteCd())
				.language(sessionUtil.getLangCd())
				.vTempTag1Cd("MTR06")
				.vGetListType(getListType)
				.build()); // 해당 게시글 프리소구 제한

		//안전성 및 방부 시험의뢰 인 경우,버전정보도 가져오기
		//lotList를 가지고 올때는 contPkCd가 있으면 안되기 때문에 팝업창OPEN시 파라미터를
		//i_sOtherContPkCd로 이름을 바꿔서 보내고 여기서 재정의해서 사용 후 다시 리셋시킨다

		// 해당 시험의뢰 마지막 버전
		reqDTO.setVFlagAllLast("N");
		ElabNoteLastTrInfoDTO lastTrVo = testReqCommonMapper.selectElabLastTrInfo(reqDTO.getVLabNoteCd(), reqDTO.getVFlagAllLast(), reqDTO.getVFlagUseGate(), reqDTO.getVMrqTypeCd(), reqDTO.getVGateCd());

		// 전체 마지막 버전
		reqDTO.setVFlagAllLast("Y");
		ElabNoteLastTrInfoDTO allLastTrVo = testReqCommonMapper.selectElabLastTrInfo(reqDTO.getVLabNoteCd(), reqDTO.getVFlagAllLast(), reqDTO.getVFlagUseGate(), reqDTO.getVMrqTypeCd(), reqDTO.getVGateCd());

		//방부시험의뢰가 아닐경우
		// 전체 다 입력 받는건 전체 기준으로 마지막 정보를 가져옴
		if (allLastTrVo != null) {
			if (lastTrVo == null) {
				lastTrVo = new ElabNoteLastTrInfoDTO();
			}
			lastTrVo.setVDosageFormCd(allLastTrVo.getVDosageFormCd());
		}

		String vFlagZmBbNote = "Y";

		responseVO.setOk(HbdTestReqResDTO.builder()
				.noteVo(noteVo)
				.contList(contList)
				.lotList(lotList)
				.mtr03List(mtr03List)
				.mtr04List(mtr04List)
				.mtr05List(mtr05List)
				.mtr06List(mtr06List)
				.lastTrVo(lastTrVo)
				.vFlagZmBbNote(vFlagZmBbNote)
				.vTrMrqTypeCd(trMrqTypeCd)
				.vTrGoalCd(trGoalCd)
				.build());
		return responseVO;

	}

	//시험의뢰 무소구 내용물정보 불러오기
	public ResponseVO selectPtrMusoContentsInfo(MusoguReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		reqDTO.setLanguage(sessionUtil.getLangCd());

		//**임시**  makeup Common으로 변경 예정 => TODO : 확인 필요
		MusoguInfoVO rvo = hbdTestReqMapper.selectMusoguInfo(reqDTO);

		List<CodeDTO> list = testReqCommonMapper.selectMusoguList(rvo);// 무소구 가능항목 (분모)
		List<MusoguRateVO> musoguYnList = this.selectMusoguRate(reqDTO, list); // 함량 구하기

		String getListType = "CHOOSE";

		List<MusoguTagVO> mtr03List = hbdCommonService.selectLabNoteTagList(MusoguReqDTO.builder()
				.vLabNoteCd(reqDTO.getVLabNoteCd())
				.language(sessionUtil.getLangCd())
				.vTempTag1Cd("MTR03")
				.vGetListType(getListType)
				.build()); // 해당 게시글 프리소구 공통

		List<MusoguTagVO> mtr04List = hbdCommonService.selectLabNoteTagList(MusoguReqDTO.builder()
				.vLabNoteCd(reqDTO.getVLabNoteCd())
				.language(sessionUtil.getLangCd())
				.vTempTag1Cd("MTR04")
				.vGetListType(getListType)
				.build()); // 해당 게시글 프리소구 공통

		List<MusoguTagVO> mtr05List = hbdCommonService.selectLabNoteTagList(MusoguReqDTO.builder()
				.vLabNoteCd(reqDTO.getVLabNoteCd())
				.language(sessionUtil.getLangCd())
				.vTempTag1Cd("MTR05")
				.vGetListType(getListType)
				.build()); // 해당 게시글 프리소구 특화

		List<MusoguTagVO> mtr06List = hbdCommonService.selectLabNoteTagList(MusoguReqDTO.builder()
				.vLabNoteCd(reqDTO.getVLabNoteCd())
				.language(sessionUtil.getLangCd())
				.vTempTag1Cd("MTR06")
				.vGetListType(getListType)
				.build()); // 해당 게시글 프리소구 제한

		responseVO.setOk(HbdTestReqResDTO.builder()
				.rvo(rvo)
				.list(list)
				.musoguYnList(musoguYnList)
				.mtr03List(mtr03List)
				.mtr04List(mtr04List)
				.mtr05List(mtr05List)
				.mtr06List(mtr06List)
				.build());
		return responseVO;

	}

	private List<MusoguRateVO> selectMusoguRate(MusoguReqDTO reqDTO, List<CodeDTO> list) {
		// NWLEE 무소구 4자 확인 Flag 추가
		List<MusoguRateVO> resList = hbdTestReqMapper.selectMusoguRate(reqDTO);

		if(!resList.isEmpty()) {
			for(MusoguRateVO rateVO : resList) {
				boolean flag = false;

				rateVO.setVFlagRequest("N");

				String mateCd = rateVO.getVMateCd();
				String divMateCd = "";

				if(StringUtils.isEmpty(mateCd)) {
					divMateCd = "temp";
				}
				else {
					divMateCd = mateCd.substring(0, 1);
				}

				if("4".equals(divMateCd)) {
					rateVO.setVFlagRequest("Y");

					for(MusoguRateVO tmpVO : resList) {
						String mateCdTmp = tmpVO.getVMateCd();
						String hal4Cd = tmpVO.getVHal4Cd();

						if(mateCd.equals(hal4Cd) && !mateCd.equals(mateCdTmp)) {
							flag = true;
							break;
						}
					}
				}

				if(flag) {
					rateVO.setVFlagRequest("N");
				}
			}

			int count = 0;
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode0()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode1()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode2()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode3()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode4()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode5()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode6()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode7()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode8()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode9()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode10()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode11()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode12()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode13()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode14()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode15()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode16()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode17()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode18()))
					.count() > 0 ? "bg-red" : null);
		}

		return resList;
	}

	@Transactional
	public ResponseVO insertPrdTestReqInfo (LabNoteTestReqRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();
		ResultDTO resultVo = new ResultDTO();

		List<CodeDTO> labTestTypeList = commonService.selectCodeListMap(Arrays.asList("LAB_TEST_TYPE")).get("LAB_TEST_TYPE");

		if("SAVE_TEST_REQ".equals(regDTO.getVFlagAction())) {

			if("MRQ010".equals(regDTO.getVTrMrqTypeCd())) {
				//안전성 저장
				resultVo = this.insertSaveSafetyTestReq(regDTO);
			}

			if("MRQ040".equals(regDTO.getVTrMrqTypeCd())) {
				if ("MRQ040_HARM".equals(regDTO.getVMrqTypeCd())) {
					//기능성 저장
					resultVo = this.insertSaveHarmSubTestReq(regDTO);
				} else {
					//기능성 저장
					resultVo = this.insertSaveFuncTestReq(regDTO);
				}
			}

			if("MRQ050".equals(regDTO.getVTrMrqTypeCd())) {
				//무소구 저장
				resultVo = this.insertSaveMusoguTestReq(regDTO);
			}

			if("MRQ060".equals(regDTO.getVTrMrqTypeCd())) {
				//부향 저장
				resultVo = this.insertSaveFlavorTestReq(regDTO);
			}

			if("MRQ070".equals(regDTO.getVTrMrqTypeCd())) {
				//부향 저장
				resultVo = this.insertSaveChinaSafetyReviewTestReq(regDTO);
			}

			if("success".equals(resultVo.getStatus())) {
				// etw 2023.07.13
				// 시험의뢰 > 중국 안전성 사전검토는
				// SUP_TR_PRODUCT 테이블에 데이터가 쌓이지 않는다고 함.
				// 그러므로 하기 쿼리는 중국 안전성 사전검토를 제외한 시험의뢰만 호출
				if (!"MRQ070".equals(regDTO.getVTrMrqTypeCd())) {
					SupTrProductSimpleInfoVO simpleVo = testReqCommonMapper.selectSupTrProductSimpleInfo(regDTO.getVTrPrdCd());
					resultVo.setObject(simpleVo);
				}

				List<LabNoteTestReqContVO> contList = regDTO.getContList();

				if (!ObjectUtils.isEmpty(contList)) {
					for (LabNoteTestReqContVO cvo : contList) {

						// 시험의뢰가 발생하면 해당 LOT 잠김 처리( 기존은 실험결과 등록 시 잠김 처리 to-be : 시험의뢰 발생 시 )
						// vFlagComplete가 값이 N일때만 아래 부분 적용
						hbdCommonService.updateLabNoteLotComplete(cvo.getVLotCd());
					}

					LabNoteTestReqContVO repCont = contList.stream()
							.filter(cvo -> cvo.getVContPkCd().equals(regDTO.getVRepContPkCd()))
							.findFirst()
							.get();

					StringBuilder contNmSb = new StringBuilder().append(repCont.getVContNm());

					if (contList.size() > 1) {
						contNmSb.append(String.format(" 외 %d건", contList.size() - 1));
					}

					commonService.sendAlarm(AlarmRegDTO.builder()
							.vLabNoteCd(regDTO.getVLabNoteCd())
							.vStatusCd("AL_NOTE2")
							.vAlrTypeCd("AL_NOTE2_06")
							.typeList(Arrays.asList(Const.SCHEDULE, Const.TIMELINE))
							.vContCd(repCont.getVContCd())
							.vContNm(contNmSb.toString())
							.nVerNo(repCont.getNVersion() < 10 ? "0" + repCont.getNVersion() : Integer.toString(repCont.getNVersion()))
							.vLotNm(repCont.getVLotNm())
							.vExamNm(labTestTypeList.stream().filter(vo -> vo.getVSubCode().equals("MRQ040".equals(regDTO.getVTrMrqTypeCd()) ? regDTO.getVMrqTypeCd() : regDTO.getVTrMrqTypeCd())).findFirst().get().getVSubCodenm())
							.vNoteType("HBO")
							.build());

					//right > status 탭 히스토리 쌓기
					commonService.insertLotStatusHistory(LotStatusRegDTO.builder()
							.vLabNoteCd(regDTO.getVLabNoteCd())
							.nVersion(repCont.getNVersion())
							.vContPkCd(repCont.getVContPkCd())
							.vLotCd(repCont.getVLotCd())
							.vLabStatusCd("MRQ040".equals(regDTO.getVTrMrqTypeCd()) ? regDTO.getVMrqTypeCd() : regDTO.getVTrMrqTypeCd())
							.build());
				} else {

					// 시험의뢰가 발생하면 해당 LOT 잠김 처리( 기존은 실험결과 등록 시 잠김 처리 to-be : 시험의뢰 발생 시 )
					// vFlagComplete가 값이 N일때만 아래 부분 적용
					hbdCommonService.updateLabNoteLotComplete(regDTO.getVLotCd());

					commonService.sendAlarm(AlarmRegDTO.builder()
							   .vLabNoteCd(regDTO.getVLabNoteCd())
							   .vStatusCd("AL_NOTE2")
						       .vAlrTypeCd("AL_NOTE2_06")
						       .typeList(Arrays.asList(Const.SCHEDULE, Const.TIMELINE))
						       .vContCd(regDTO.getVContcd())
						       .vContNm(regDTO.getVContNm())
						       .nVerNo(regDTO.getNVersion() < 10 ? "0" + regDTO.getNVersion() : Integer.toString(regDTO.getNVersion()))
						       .vLotNm(regDTO.getVLotNm())
						       .vExamNm(labTestTypeList.stream().filter(vo -> vo.getVSubCode().equals("MRQ040".equals(regDTO.getVTrMrqTypeCd()) ? regDTO.getVMrqTypeCd() : regDTO.getVTrMrqTypeCd())).findFirst().get().getVSubCodenm())
						       .vNoteType("HBO")
						       .build());

					//right > status 탭 히스토리 쌓기
					commonService.insertLotStatusHistory(LotStatusRegDTO.builder()
							.vLabNoteCd(regDTO.getVLabNoteCd())
							.nVersion(regDTO.getNVersion())
							.vContPkCd(regDTO.getVContPkCd())
							.vLotCd(regDTO.getVRepLotCd())
							.vLabStatusCd("MRQ040".equals(regDTO.getVTrMrqTypeCd()) ? regDTO.getVMrqTypeCd() : regDTO.getVTrMrqTypeCd())
							.build());
				}
			}

		}else if("SAVE_CLINICAL_TEST_REQ".equals(regDTO.getVFlagAction())) {

			//효능임상 저장
			resultVo = this.insertSaveClinicalTestReq(regDTO);
			if("success".equals(resultVo.getStatus())) {
				resultVo.setObject(regDTO.getVTestCd());

				List<LabNoteTestReqContVO> contList = regDTO.getContList();

				if (!ObjectUtils.isEmpty(contList)) {
					LabNoteTestReqContVO repCont = contList.get(0);

					StringBuilder contNmSb = new StringBuilder().append(repCont.getVContNm());

					if (contList.size() > 1) {
						contNmSb.append(String.format(" 외 %d건", contList.size() - 1));
					}

					commonService.sendAlarm(AlarmRegDTO.builder()
							.vLabNoteCd(regDTO.getVLabNoteCd())
							.vStatusCd("AL_NOTE2")
							.vAlrTypeCd("AL_NOTE2_06")
							.typeList(Arrays.asList(Const.SCHEDULE, Const.TIMELINE))
							.vContCd(repCont.getVContCd())
							.vContNm(contNmSb.toString())
							.nVerNo(regDTO.getNVersion() < 10 ? "0" + regDTO.getNVersion() : Integer.toString(regDTO.getNVersion()))
							.vExamNm(labTestTypeList.stream().filter(vo -> "CLINICAL".equals(vo.getVSubCode())).findFirst().get().getVSubCodenm())
							.vNoteType("HBO")
							.build());

					//right > status 탭 히스토리 쌓기
					commonService.insertLotStatusHistory(LotStatusRegDTO.builder()
							.vLabNoteCd(regDTO.getVLabNoteCd())
							.nVersion(regDTO.getNVersion())
							.vContPkCd(repCont.getVContPkCd())
							.vLabStatusCd("CLINICAL")
							.build());
				}
			}

		}else {
			resultVo.setStatus(Const.FAIL);
			resultVo.setMessage("필수 인자값이 없습니다.");

		}

		responseVO.setOkWithCode(resultVo.getStatus(), resultVo.getMessage(), resultVo.getObject());
		return responseVO;
	}

	public ResultDTO insertSaveFuncTestReq (LabNoteTestReqRegDTO regDTO) {
		ResultDTO resultMap = new ResultDTO();
		regDTO.setVLanguage(sessionUtil.getLocalLanguage());

		if(StringUtils.isEmpty(regDTO.getVLabNoteCd() )
				|| StringUtils.isEmpty(regDTO.getVContPkCd())
				|| StringUtils.isEmpty(regDTO.getVLotCd())
				) {

			resultMap.setStatus(Const.FAIL);
			resultMap.setMessage("해당 시험노트 내용을 찾을수 없습니다.");
			return resultMap;
		}

		HbdNoteInfoDTO noteVo = hbdCommonService.selectLabNoteInfo(regDTO.getVLabNoteCd());

		if(ObjectUtils.isEmpty(noteVo)) {
			resultMap.setStatus(Const.FAIL);
			resultMap.setMessage("해당 시험노트 내용을 찾을수 없습니다.");
			return resultMap;
		}

		regDTO.setVLand1("UN");
		LabNoteValidateDTO valiVo = hbdTestReqMapper.selectLabNoteValidateInfo(regDTO);

		StringBuffer sb = new StringBuffer();
		boolean isSum100 = true;

		if(ObjectUtils.isEmpty(valiVo)) {
			isSum100 = false;

			sb.append(regDTO.getVContcd());
			sb.append(" : Lot 정보 오류");
		}else if (valiVo.getNSumRate() != 100d) {
			isSum100 = false;

			sb.append(regDTO.getVContcd());
			sb.append(" : 함량 100이 아님");
		}

		if (!isSum100) {
			sb.append("<br/>위 사유로 시험의뢰가 불가능 합니다.");

			resultMap.setStatus(Const.FAIL);
			resultMap.setMessage(sb.toString());
			return resultMap;
		}

		//기능성,무소구 시험 의뢰 시 대표로 선택 된 정보만 사용(다건X)

		LabNoteSupTrPrdInfoDTO trVo = testReqCommonMapper.selectLabNoteSupTrProductInfo(regDTO);

//		 라인제품 복수개 의뢰 or 부향의뢰시는 버전업이 아닌 새로 생성
		if (trVo != null && trVo.getNLineContCnt() == 0 && !"MRQ060".equals(regDTO.getVTrMrqTypeCd())) {
			regDTO.setVTrPrdCd(trVo.getVProductCd());
		}

		InsertSupTrPrdInfoDTO trTempVo = hbdTestReqMapper.selectInsertSupTrProductInfo(regDTO.getVLabNoteCd(), regDTO.getVRepContPkCd(), regDTO.getVLotCd());

		if(ObjectUtils.isEmpty(trTempVo)) {
			resultMap.setStatus(Const.FAIL);
			resultMap.setMessage("해당 시험노트 내용을 찾을수 없습니다.");
			return resultMap;
		}

		regDTO.setVRepContCd(regDTO.getVContcd());
		regDTO.setVTrCompleteReqDt(CommonUtil.getOnlyNumber(regDTO.getVTrCompleteReqDt()));
		regDTO.setVRepLotCd(regDTO.getVLotCd());

		regDTO.setVTrPrdNm(trTempVo.getVProductNm());
		regDTO.setVTrPrdEngNm(trTempVo.getVProductEngNm());
		regDTO.setVTrSapCd(trTempVo.getVSapCd());
		regDTO.setVUserid(trTempVo.getVUserId());
		regDTO.setVDeptCd(trTempVo.getVDeptCd());
		regDTO.setVAmoreProdYn(trTempVo.getVAmoreProdYn());
		regDTO.setVInnerPlant(trTempVo.getVInnerPlant());
		regDTO.setVMakerNm(trTempVo.getVMakerNm());
		regDTO.setVLot(trTempVo.getVLot());
		regDTO.setVTypeCd(trTempVo.getVTypeCd());
		regDTO.setVTypeCd2(trTempVo.getVTypeCd2());
		regDTO.setVTddProdType1Cd(noteVo.getVTddProdType1Cd());
		regDTO.setVTddProdType2Cd(noteVo.getVTddProdType2Cd());

		if(!"MRQ011".equals(regDTO.getVTrMrqTypeCd())) {
			regDTO.setVCont1Cd(trTempVo.getVCont1Cd());
			regDTO.setVCont2Cd(trTempVo.getVCont2Cd());
		}

		regDTO.setVRpmsCd(trTempVo.getVRpmsCd());
		regDTO.setVBrdCd(trTempVo.getVBrdCd());
		regDTO.setVMeetingDt(trTempVo.getVMeetingDt());
		regDTO.setVWerks(trTempVo.getVWerks());
		regDTO.setVFlagReleaseAsia(trTempVo.getVFlagReleaseAsia());
		regDTO.setVFlagReleaseAsean(trTempVo.getVFlagReleaseAsean());
		regDTO.setVFlagReleaseEtc(trTempVo.getVFlagReleaseEtc());
		regDTO.setVPartCd(trTempVo.getVPartCd());

		regDTO.setVRegUserid(sessionUtil.getLoginId());
		regDTO.setVUpdateUserid(sessionUtil.getLoginId());

		if (!StringUtils.isEmpty(regDTO.getVTrPilotDt())) {
			regDTO.setVTrPilotDt(regDTO.getVTrPilotDt());
		}
		else {
			regDTO.setVTrPilotDt(trTempVo.getVPilotDt());
		}

		int rcvUsrLen = 0;

		List<GroupUserInfoDTO> rcvUsrList = null;

		if(StringUtils.isNotEmpty(noteVo.getVDeptCd())) {
			rcvUsrList = testReqCommonMapper.selectPrsvRcvMailUserList(noteVo.getVDeptCd());
			rcvUsrLen = rcvUsrList == null ? 0 : rcvUsrList.size();
		}

		if(rcvUsrLen == 0) {
			rcvUsrList = commonService.selectGroupUserList("S000292");
		}

		rcvUsrLen = rcvUsrList == null ? 0 : rcvUsrList.size();

		if(rcvUsrLen > 0) {
			regDTO.setVPrescUserid(rcvUsrList.get(0).getVUserid());
		}

		if(!("TMT_2").equals( regDTO.getVTrTestTypeCd())){
			regDTO.setVCreateNo("");
		}

		//중국사전안전평가일때는 안전성시험의뢰에 남기지 않는다.
		if(!"MRQ070".equals(regDTO.getVTrMrqTypeCd())){
			if (StringUtils.isEmpty(regDTO.getVTrPrdCd())) {
				regDTO.setNTrVersion(1);
				testReqCommonMapper.insertSupTrProduct(regDTO);// v_feature (ver2  부터는 사유 입력)
				hbdTestReqMapper.insertSupTrReleaseCountry(regDTO);
			} else {
				regDTO.setNTrVersion(trVo.getNVersion() + 1);
				testReqCommonMapper.insertSupTrProductVer(regDTO);
				testReqCommonMapper.updateSupTrProduct(regDTO);// v_feature (ver2  부터는 사유 입력)
				hbdTestReqMapper.insertSupTrReleaseCountry(regDTO);
			}
		}

		String mrqTypeCd = regDTO.getVMrqTypeCd();
		if (mrqTypeCd.indexOf("MRQ040_FUNC") > -1) {
			testReqCommonMapper.insertLabNoteToMrqTestReqFunc(regDTO);
		}else if(mrqTypeCd.indexOf("MRQ050") > -1) {
			testReqCommonMapper.insertLabNoteToMrqTestReqMusogu(regDTO);
		}else if(mrqTypeCd.indexOf("MRQ060") > -1) {
			testReqCommonMapper.insertLabNoteToMrqTestReqFlavor(regDTO);
		}

		hbdTestReqMapper.updateLabNoteMstFlagTestReq(regDTO.getVLabNoteCd(), regDTO.getVRegUserid());

		testReqCommonService.updateLabNoteProductTestRequest(regDTO);

		if (!"".equals(regDTO.getVTrComment().trim())) {
			testReqCommonMapper.insertMrqMessage(regDTO);
		}

		resultMap.setStatus(Const.SUCC);
		resultMap.setMessage("success");
		return resultMap;
	}

	public ResultDTO insertSaveMusoguTestReq (LabNoteTestReqRegDTO regDTO) {
		ResultDTO resultMap = new ResultDTO();
		regDTO.setVLanguage(sessionUtil.getLocalLanguage());

		if(StringUtils.isEmpty(regDTO.getVLabNoteCd() )
				|| StringUtils.isEmpty(regDTO.getVContPkCd())
				|| StringUtils.isEmpty(regDTO.getVLotCd())
				) {

			resultMap.setStatus(Const.FAIL);
			resultMap.setMessage("해당 시험노트 내용을 찾을수 없습니다.");
			return resultMap;
		}

		HbdNoteInfoDTO noteVo = hbdCommonService.selectLabNoteInfo(regDTO.getVLabNoteCd());

		if(ObjectUtils.isEmpty(noteVo)) {
			resultMap.setStatus(Const.FAIL);
			resultMap.setMessage("해당 시험노트 내용을 찾을수 없습니다.");
			return resultMap;
		}

		regDTO.setVLand1("UN");
		LabNoteValidateDTO valiVo = hbdTestReqMapper.selectLabNoteValidateInfo(regDTO);

		StringBuffer sb = new StringBuffer();
		boolean isSum100 = true;

		if(ObjectUtils.isEmpty(valiVo)) {
			isSum100 = false;

			sb.append(regDTO.getVContcd());
			sb.append(" : Lot 정보 오류");
		}else if (valiVo.getNSumRate() != 100d) {
			isSum100 = false;

			sb.append(regDTO.getVContcd());
			sb.append(" : 함량 100이 아님");
		}

		if (!isSum100) {
			sb.append("<br/>위 사유로 시험의뢰가 불가능 합니다.");

			resultMap.setStatus(Const.FAIL);
			resultMap.setMessage(sb.toString());
			return resultMap;
		}

		//기능성,무소구 시험 의뢰 시 대표로 선택 된 정보만 사용(다건X)

		LabNoteSupTrPrdInfoDTO trVo = testReqCommonMapper.selectLabNoteSupTrProductInfo(regDTO);

//		 라인제품 복수개 의뢰 or 부향의뢰시는 버전업이 아닌 새로 생성
		if (trVo != null && trVo.getNLineContCnt() == 0 && !"MRQ060".equals(regDTO.getVTrMrqTypeCd())) {
			regDTO.setVTrPrdCd(trVo.getVProductCd());
		}

		InsertSupTrPrdInfoDTO trTempVo = hbdTestReqMapper.selectInsertSupTrProductInfo(regDTO.getVLabNoteCd(), regDTO.getVRepContPkCd(), regDTO.getVLotCd());

		if(ObjectUtils.isEmpty(trTempVo)) {
			resultMap.setStatus(Const.FAIL);
			resultMap.setMessage("해당 시험노트 내용을 찾을수 없습니다.");
			return resultMap;
		}

		regDTO.setVTestReqTable(regDTO.getVTrMrqTypeCd());
		regDTO.setVRepContCd(regDTO.getVContcd());
		regDTO.setVTrCompleteReqDt(CommonUtil.getOnlyNumber(regDTO.getVTrCompleteReqDt()));
		regDTO.setVRepLotCd(regDTO.getVLotCd());

		regDTO.setVTrPrdNm(trTempVo.getVProductNm());
		regDTO.setVTrPrdEngNm(trTempVo.getVProductEngNm());
		regDTO.setVTrSapCd(trTempVo.getVSapCd());
		regDTO.setVUserid(trTempVo.getVUserId());
		regDTO.setVDeptCd(trTempVo.getVDeptCd());
		regDTO.setVAmoreProdYn(trTempVo.getVAmoreProdYn());
		regDTO.setVInnerPlant(trTempVo.getVInnerPlant());
		regDTO.setVMakerNm(trTempVo.getVMakerNm());
		regDTO.setVLot(trTempVo.getVLot());
		regDTO.setVTypeCd(trTempVo.getVTypeCd());
		regDTO.setVTypeCd2(trTempVo.getVTypeCd2());
		regDTO.setVTddProdType1Cd(noteVo.getVTddProdType1Cd());
		regDTO.setVTddProdType2Cd(noteVo.getVTddProdType2Cd());

		if(!"MRQ011".equals(regDTO.getVTrMrqTypeCd())) {
			regDTO.setVCont1Cd(trTempVo.getVCont1Cd());
			regDTO.setVCont2Cd(trTempVo.getVCont2Cd());
		}

		regDTO.setVRpmsCd(trTempVo.getVRpmsCd());
		regDTO.setVBrdCd(trTempVo.getVBrdCd());
		regDTO.setVMeetingDt(trTempVo.getVMeetingDt());
		regDTO.setVWerks(trTempVo.getVWerks());
		regDTO.setVFlagReleaseAsia(trTempVo.getVFlagReleaseAsia());
		regDTO.setVFlagReleaseAsean(trTempVo.getVFlagReleaseAsean());
		regDTO.setVFlagReleaseEtc(trTempVo.getVFlagReleaseEtc());
		regDTO.setVPartCd(trTempVo.getVPartCd());

		regDTO.setVRegUserid(sessionUtil.getLoginId());
		regDTO.setVUpdateUserid(sessionUtil.getLoginId());

		if (!StringUtils.isEmpty(regDTO.getVTrPilotDt())) {
			regDTO.setVTrPilotDt(regDTO.getVTrPilotDt());
		}
		else {
			regDTO.setVTrPilotDt(trTempVo.getVPilotDt());
		}

		int rcvUsrLen = 0;

		List<GroupUserInfoDTO> rcvUsrList = null;

		if(StringUtils.isNotEmpty(noteVo.getVDeptCd())) {
			rcvUsrList = testReqCommonMapper.selectPrsvRcvMailUserList(noteVo.getVDeptCd());
			rcvUsrLen = rcvUsrList == null ? 0 : rcvUsrList.size();
		}

		if(rcvUsrLen == 0) {
			rcvUsrList = commonService.selectGroupUserList("S000292");
		}

		rcvUsrLen = rcvUsrList == null ? 0 : rcvUsrList.size();

		if(rcvUsrLen > 0) {
			regDTO.setVPrescUserid(rcvUsrList.get(0).getVUserid());
		}

		if(!("TMT_2").equals( regDTO.getVTrTestTypeCd())){
			regDTO.setVCreateNo("");
		}

		//중국사전안전평가일때는 안전성시험의뢰에 남기지 않는다.
		if(!"MRQ070".equals(regDTO.getVTrMrqTypeCd())){
			if (StringUtils.isEmpty(regDTO.getVTrPrdCd())) {
				regDTO.setNTrVersion(1);
				testReqCommonMapper.insertSupTrProduct(regDTO);// v_feature (ver2  부터는 사유 입력)
				hbdTestReqMapper.insertSupTrReleaseCountry(regDTO);
			} else {
				regDTO.setNTrVersion(trVo.getNVersion() + 1);
				testReqCommonMapper.insertSupTrProductVer(regDTO);
				testReqCommonMapper.updateSupTrProduct(regDTO);// v_feature (ver2  부터는 사유 입력)
				hbdTestReqMapper.insertSupTrReleaseCountry(regDTO);
			}
		}

		String mrqTypeCd = regDTO.getVMrqTypeCd();
		if (mrqTypeCd.indexOf("MRQ040_FUNC") > -1) {
			testReqCommonMapper.insertLabNoteToMrqTestReqFunc(regDTO);
		}else if(mrqTypeCd.indexOf("MRQ050") > -1) {

			//무소구/AP Promise 접수 담당자 고정 그룹(S000117)
			regDTO.setVGroupId("S000117");

			LabNoteMusoguTempDTO tempMap = new LabNoteMusoguTempDTO();

			tempMap.setVLabNoteCd(regDTO.getVLabNoteCd());
			tempMap.setNVersion(regDTO.getNVersion());
			tempMap.setVGetListType("CHOOSE");
			tempMap.setVLanguage(sessionUtil.getLocalLanguage());

			StringBuffer sReqDiv = new StringBuffer();

			if ("Y".equals(noteVo.getVFlagApPromise())){

				sReqDiv.append("TDV01");
				String sAppromise ="";

				// AP Promise 관리 성분 출력 시작
				tempMap.setVTempTag1Cd("MTR03");

				sAppromise = this.getAppromiseORNotAddItem(tempMap);

				regDTO.setVAppromise(sAppromise);
				regDTO.setVApPromiseTxt(noteVo.getVApPromiseNote());
			}

			if ("Y".equals(noteVo.getVFlagNotAdd())){

				sReqDiv.append("TDV02");

				String sMtr04 ="";
				String sMtr05 ="";
				String sMtr06 ="";

				// 무소구 공통항목(MTR04) 성분 출력 시작
				tempMap.setVTempTag1Cd("MTR04");
				sMtr04 = this.getAppromiseORNotAddItem(tempMap);
				regDTO.setVMtr04(sMtr04);

				// 무소구 특화항목(MTR05) 성분 출력
				tempMap.setVTempTag1Cd("MTR05");
				sMtr05 = this.getAppromiseORNotAddItem(tempMap);
				regDTO.setVMtr05(sMtr05);

				// 무소구 제한항목(MTR06) 성분 출력
				tempMap.setVTempTag1Cd("MTR06");
				sMtr06 = this.getAppromiseORNotAddItem(tempMap);
				regDTO.setVMtr06(sMtr06);
				regDTO.setVMusoTxt(noteVo.getVNotAddNote());

			}

			if(StringUtils.isNotEmpty(sReqDiv.toString())) {
				regDTO.setVReqDiv(sReqDiv.toString());
			}

			testReqCommonMapper.insertLabNoteToMrqTestReqMusogu(regDTO);// 무소구의뢰 저장
			hbdTestReqMapper.insertLabNoteToMrqMateTestReqMusogu(regDTO);// 무소구의뢰 처방 저장
			hbdTestReqMapper.insertSupTrMrq050MtrList(regDTO);// 무소구의뢰 항목 저장

			// 원료배합 무소구 화면 적용
			// 4자원료 하위 6자원료 저장
			LabNoteMusoguTemp2DTO tempReqVo = new LabNoteMusoguTemp2DTO();

			tempReqVo.setNVersion(regDTO.getNTrVersion());
			tempReqVo.setVTrPrdCd(regDTO.getVTrPrdCd());
			tempReqVo.setVRegUserid(regDTO.getVRegUserid());
			tempReqVo.setVUpdateUserid(regDTO.getVUpdateUserid());
			tempReqVo.setVRepLotCd(regDTO.getVRepLotCd());
			tempReqVo.setVPlantCd(regDTO.getVPlantCd());
			tempReqVo.setVMatTypeNm("");
			tempReqVo.setVInci("");
			tempReqVo.setVMuso("");

			hbdTestReqMapper.insertMrq050_HAL4CD(tempReqVo);
			// 원료배합 무소구 화면 적용

		}

		hbdTestReqMapper.updateLabNoteMstFlagTestReq(regDTO.getVLabNoteCd(), regDTO.getVRegUserid());

		testReqCommonService.updateLabNoteProductTestRequest(regDTO);

		if (!"".equals(regDTO.getVTrComment().trim())) {
			testReqCommonMapper.insertMrqMessage(regDTO);
		}

		resultMap.setStatus(Const.SUCC);
		resultMap.setMessage("success");
		return resultMap;
	}

	@Transactional
	public ResultDTO insertSaveClinicalTestReq (LabNoteTestReqRegDTO regDTO) {
		ResultDTO resultMap = new ResultDTO();

		if(StringUtils.isEmpty(regDTO.getVLabNoteCd()) || regDTO.getArrContPkCd().length == 0)
		{
			resultMap.setStatus(Const.FAIL);
			resultMap.setMessage("해당 시험노트 내용을 찾을수 없습니다.");
			return resultMap;
		}

		HbdNoteInfoDTO noteVo = hbdCommonService.selectLabNoteInfo(regDTO.getVLabNoteCd());

		if(ObjectUtils.isEmpty(noteVo)) {
			resultMap.setStatus(Const.FAIL);
			resultMap.setMessage("해당 시험노트 내용을 찾을수 없습니다.");
			return resultMap;
		}

		regDTO.setVDeptCd1(noteVo.getVDeptCd());

		LabNoteProcessPqcCheckApprReqDTO titleDTO = ConvertUtil.convert(regDTO, LabNoteProcessPqcCheckApprReqDTO.class);
		titleDTO.setArrContPkCd(regDTO.getArrContPkCd());

		regDTO.setVTitle(hbdCommonService.selectElabApprTitleNm(titleDTO));
		regDTO.setVRequestTeamcd(noteVo.getVDeptCd());
		regDTO.setVRequestid(sessionUtil.getLoginId());
		regDTO.setVTestRequestDocno(this.getClinicalRequestDocNo(regDTO.getVDeptCd()));//기존 deptCd 넣어주는곳이 없음

		regDTO.setVRegUserid(sessionUtil.getLoginId());
		regDTO.setVUpdateUserid(sessionUtil.getLoginId());
		testReqCommonMapper.insertClinicalTest(regDTO);	//생성 된 v_test_cd 리턴해서 효능임상 페이지 키로 가져감 ,regDTO

		hbdTestReqMapper.updateLabNoteMstFlagTestReq(regDTO.getVLabNoteCd(), regDTO.getVRegUserid());

		resultMap.setStatus(Const.SUCC);
		resultMap.setMessage("success");
		return resultMap;
	}

	public String getClinicalRequestDocNo(String vDeptCd) {
		return testReqCommonMapper.selectClinicalRequestDocNo(vDeptCd);
	}

	private String getAppromiseORNotAddItem(LabNoteMusoguTempDTO tempMap) {
		StringBuffer returnStr = new StringBuffer();

		List <LabNoteTestReqTagListVO> tempList = hbdTestReqMapper.selectLabNoteTagList(tempMap);

		if (tempList != null) {

			int listSize = tempList.size();

			for (int j = 0; j < listSize; j++) {

				if (j > 0) {
					returnStr.append(",");
				}

				returnStr.append(tempList.get(j).getVSubCode());
			}
		}
		return returnStr.toString();
	}

	//시험의뢰 부향
	public ResponseVO selectPrdTestReqFlavorInfo(LabNoteTestReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();
		List<LabNoteTestReqLotVO> lotList = null;

		if(StringUtils.isEmpty(reqDTO.getVLabNoteCd()) || reqDTO.getNVersion()<1) {
			responseVO.setOk("필수 입력값이 없습니다");
			return responseVO;
		}

		HbdNoteInfoDTO noteVo = hbdCommonService.selectLabNoteInfo(reqDTO.getVLabNoteCd());

		if(ObjectUtils.isEmpty(noteVo)) {
			responseVO.setOk("해당 실험노트를 찾을수 없습니다.");
			return responseVO;
		}

		String mrqTypeCd = reqDTO.getVMrqTypeCd();
		String trMrqTypeCd = mrqTypeCd;
		String trGoalCd = "";

		reqDTO.setVTrMrqTypeCd(trMrqTypeCd);
		reqDTO.setVTrGoalCd(trGoalCd);

		//MU,HBO 개발 취소 된 내용물 제외 >> CONT.V_FLAG_CANCEL ='N'
		List<LabNoteTestReqContVO> contList = hbdTestReqMapper.selectTestReqContList(reqDTO.getVLabNoteCd(), reqDTO.getVPlantCd());

		if (!ObjectUtils.isEmpty(contList)) {

			reqDTO.setVLanguage(sessionUtil.getLocalLanguage());
			lotList = hbdTestReqMapper.selectTestReqLotList(reqDTO);

			if (!ObjectUtils.isEmpty(lotList)) {
				final List<LabNoteTestReqLotVO> copiedList = lotList.stream().collect(Collectors.toList());

				contList.stream().forEach(cvo -> {
					cvo.setSubList(copiedList.stream().filter(lvo -> lvo.getVContPkCd().equals(cvo.getVContPkCd())).collect(Collectors.toList()));
				});
			}
		}

		//안전성 및 방부 시험의뢰 인 경우,버전정보도 가져오기
		//lotList를 가지고 올때는 contPkCd가 있으면 안되기 때문에 팝업창OPEN시 파라미터를
		//i_sOtherContPkCd로 이름을 바꿔서 보내고 여기서 재정의해서 사용 후 다시 리셋시킨다

		// 해당 시험의뢰 마지막 버전
		reqDTO.setVFlagAllLast("N");
		ElabNoteLastTrInfoDTO lastTrVo = testReqCommonMapper.selectElabLastTrInfo(reqDTO.getVLabNoteCd(), reqDTO.getVFlagAllLast(), reqDTO.getVFlagUseGate(), reqDTO.getVMrqTypeCd(), reqDTO.getVGateCd());

		// 전체 마지막 버전
		reqDTO.setVFlagAllLast("Y");
		ElabNoteLastTrInfoDTO allLastTrVo = testReqCommonMapper.selectElabLastTrInfo(reqDTO.getVLabNoteCd(), reqDTO.getVFlagAllLast(), reqDTO.getVFlagUseGate(), reqDTO.getVMrqTypeCd(), reqDTO.getVGateCd());
		//방부시험의뢰가 아닐경우
		// 전체 다 입력 받는건 전체 기준으로 마지막 정보를 가져옴
		if (allLastTrVo != null) {
			if (lastTrVo == null) {
				lastTrVo = new ElabNoteLastTrInfoDTO();
			}
			lastTrVo.setVDosageFormCd(allLastTrVo.getVDosageFormCd());
		}

		String vFlagZmBbNote = "Y";

		responseVO.setOk(HbdTestReqResDTO.builder()
											 .noteVo(noteVo)
											 .contList(contList)
											 .lotList(lotList)
											 .lastTrVo(lastTrVo)
											 .vFlagZmBbNote(vFlagZmBbNote)
											 .vTrMrqTypeCd(trMrqTypeCd)
											 .vTrGoalCd(trGoalCd)
											 .build());
		return responseVO;

	}

	//시험의뢰 안전성
	public ResponseVO selectPrdTestReqSafetyInfo(LabNoteTestReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();
		List<LabNoteTestReqLotVO> lotList = null;

		if(StringUtils.isEmpty(reqDTO.getVLabNoteCd()) || reqDTO.getNVersion()<1) {
			responseVO.setOk("필수 입력값이 없습니다");
			return responseVO;
		}

		HbdNoteInfoDTO noteVo = hbdCommonService.selectLabNoteInfo(reqDTO.getVLabNoteCd());

		if(ObjectUtils.isEmpty(noteVo)) {
			responseVO.setOk("해당 실험노트를 찾을수 없습니다.");
			return responseVO;
		}

		String mrqTypeCd = reqDTO.getVMrqTypeCd();
		String trMrqTypeCd = mrqTypeCd;
		String trGoalCd = "";

		reqDTO.setVTrMrqTypeCd(trMrqTypeCd);
		reqDTO.setVTrGoalCd(trGoalCd);

		//MU,HBO 개발 취소 된 내용물 제외 >> CONT.V_FLAG_CANCEL ='N'
		List<LabNoteTestReqContVO> contList = hbdTestReqMapper.selectTestReqContList(reqDTO.getVLabNoteCd(), reqDTO.getVPlantCd());

		if (!ObjectUtils.isEmpty(contList)) {

			reqDTO.setVLanguage(sessionUtil.getLocalLanguage());
			lotList = hbdTestReqMapper.selectTestReqLotList(reqDTO);

			if (!ObjectUtils.isEmpty(lotList)) {
				final List<LabNoteTestReqLotVO> copiedList = lotList.stream().collect(Collectors.toList());

				contList.stream().forEach(cvo -> {
					cvo.setSubList(copiedList.stream().filter(lvo -> lvo.getVContPkCd().equals(cvo.getVContPkCd())).collect(Collectors.toList()));
				});
			}
		}

		//안전성 및 방부 시험의뢰 인 경우,버전정보도 가져오기
		//lotList를 가지고 올때는 contPkCd가 있으면 안되기 때문에 팝업창OPEN시 파라미터를
		//i_sOtherContPkCd로 이름을 바꿔서 보내고 여기서 재정의해서 사용 후 다시 리셋시킨다

		//버전정보 가져오기
		List<VersionListVO> verList = hbdCommonService.selectLabNoteVersionList(reqDTO.getVOtherContPkCd());

		List<MusoguTagVO> mtr01List = hbdCommonService.selectLabNoteTagList(MusoguReqDTO.builder()
																							 .vLabNoteCd(reqDTO.getVLabNoteCd())
																							 .language(sessionUtil.getLangCd())
																							 .vTempTag1Cd("MTI01")
																							 .build());

		// 해당 시험의뢰 마지막 버전
		reqDTO.setVFlagAllLast("N");
		ElabNoteLastTrInfoDTO lastTrVo = testReqCommonMapper.selectElabLastTrInfo(reqDTO.getVLabNoteCd(), reqDTO.getVFlagAllLast(), reqDTO.getVFlagUseGate(), reqDTO.getVMrqTypeCd(), reqDTO.getVGateCd());

		// 전체 마지막 버전
		reqDTO.setVFlagAllLast("Y");
		ElabNoteLastTrInfoDTO allLastTrVo = testReqCommonMapper.selectElabLastTrInfo(reqDTO.getVLabNoteCd(), reqDTO.getVFlagAllLast(), reqDTO.getVFlagUseGate(), reqDTO.getVMrqTypeCd(), reqDTO.getVGateCd());
		//방부시험의뢰가 아닐경우
		// 전체 다 입력 받는건 전체 기준으로 마지막 정보를 가져옴
		if (allLastTrVo != null) {
			if (lastTrVo == null) {
				lastTrVo = new ElabNoteLastTrInfoDTO();
			}
			lastTrVo.setVDosageFormCd(allLastTrVo.getVDosageFormCd());
		}

		String vFlagZmBbNote = "Y";

		responseVO.setOk(HbdTestReqResDTO.builder()
											 .noteVo(noteVo)
											 .contList(contList)
											 .lotList(lotList)
											 .lastTrVo(lastTrVo)
											 .vFlagZmBbNote(vFlagZmBbNote)
											 .vTrMrqTypeCd(trMrqTypeCd)
											 .vTrGoalCd(trGoalCd)
											 .verList(verList)
											 .mtr01List(mtr01List)
											 .vFlagMultiple("Y")
											 .build());
		return responseVO;

	}

	//시험의뢰 유해물질
	public ResponseVO selectPrdTestReqHarmSubInfo(LabNoteTestReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();
		List<LabNoteTestReqLotVO> lotList = null;

		if(StringUtils.isEmpty(reqDTO.getVLabNoteCd()) || reqDTO.getNVersion()<1) {
			responseVO.setOk("필수 입력값이 없습니다");
			return responseVO;
		}

		HbdNoteInfoDTO noteVo = hbdCommonService.selectLabNoteInfo(reqDTO.getVLabNoteCd());

		if(ObjectUtils.isEmpty(noteVo)) {
			responseVO.setOk("해당 실험노트를 찾을수 없습니다.");
			return responseVO;
		}

		String mrqTypeCd = reqDTO.getVMrqTypeCd();
		String trMrqTypeCd = "";
		String trGoalCd = "";

		//  기능성
		if (mrqTypeCd.indexOf("MRQ040_FUNC") > -1) {
			trMrqTypeCd = "MRQ040";
			trGoalCd = "TMG010";
		}
		// 유해물질
		else if (mrqTypeCd.indexOf("MRQ040_HARM") > -1) {
			trMrqTypeCd = "MRQ040";
			trGoalCd = "TMG030";
		}
		else {
			trMrqTypeCd = mrqTypeCd;
			trGoalCd = "";
		}

		reqDTO.setVTrMrqTypeCd(trMrqTypeCd);
		reqDTO.setVTrGoalCd(trGoalCd);

		//MU,HBO 개발 취소 된 내용물 제외 >> CONT.V_FLAG_CANCEL ='N'
		List<LabNoteTestReqContVO> contList = hbdTestReqMapper.selectTestReqContList(reqDTO.getVLabNoteCd(), reqDTO.getVPlantCd());

		if (!ObjectUtils.isEmpty(contList)) {

			reqDTO.setVLanguage(sessionUtil.getLocalLanguage());
			lotList = hbdTestReqMapper.selectTestReqLotList(reqDTO);

			if (!ObjectUtils.isEmpty(lotList)) {
				final List<LabNoteTestReqLotVO> copiedList = lotList.stream().collect(Collectors.toList());

				contList.stream().forEach(cvo -> {
					cvo.setSubList(copiedList.stream().filter(lvo -> lvo.getVContPkCd().equals(cvo.getVContPkCd())).collect(Collectors.toList()));
				});
			}
		}

		//안전성 및 방부 시험의뢰 인 경우,버전정보도 가져오기
		//lotList를 가지고 올때는 contPkCd가 있으면 안되기 때문에 팝업창OPEN시 파라미터를
		//i_sOtherContPkCd로 이름을 바꿔서 보내고 여기서 재정의해서 사용 후 다시 리셋시킨다

		// 해당 시험의뢰 마지막 버전
		reqDTO.setVFlagAllLast("N");
		ElabNoteLastTrInfoDTO lastTrVo = testReqCommonMapper.selectElabLastTrInfo(reqDTO.getVLabNoteCd(), reqDTO.getVFlagAllLast(), reqDTO.getVFlagUseGate(), reqDTO.getVMrqTypeCd(), reqDTO.getVGateCd());

		// 전체 마지막 버전
		reqDTO.setVFlagAllLast("Y");
		ElabNoteLastTrInfoDTO allLastTrVo = testReqCommonMapper.selectElabLastTrInfo(reqDTO.getVLabNoteCd(), reqDTO.getVFlagAllLast(), reqDTO.getVFlagUseGate(), reqDTO.getVMrqTypeCd(), reqDTO.getVGateCd());
		//방부시험의뢰가 아닐경우
		// 전체 다 입력 받는건 전체 기준으로 마지막 정보를 가져옴
		if (allLastTrVo != null) {
			if (lastTrVo == null) {
				lastTrVo = new ElabNoteLastTrInfoDTO();
			}
			lastTrVo.setVDosageFormCd(allLastTrVo.getVDosageFormCd());
		}

		String vFlagZmBbNote = "Y";

		responseVO.setOk(HbdTestReqResDTO.builder()
				.noteVo(noteVo)
				.contList(contList)
				.lotList(lotList)
				.lastTrVo(lastTrVo)
				.vFlagZmBbNote(vFlagZmBbNote)
				.vTrMrqTypeCd(trMrqTypeCd)
				.vTrGoalCd(trGoalCd)
				.build());
		return responseVO;

	}

	//시험의뢰 중국 안전성 사전검토
	public ResponseVO selectPrdTestReqChinaSafetyReviewInfo(LabNoteTestReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();
		List<LabNoteTestReqLotVO> lotList = null;

		if(StringUtils.isEmpty(reqDTO.getVLabNoteCd()) || reqDTO.getNVersion()<1) {
			responseVO.setOk("필수 입력값이 없습니다");
			return responseVO;
		}

		HbdNoteInfoDTO noteVo = hbdCommonService.selectLabNoteInfo(reqDTO.getVLabNoteCd());

		if(ObjectUtils.isEmpty(noteVo)) {
			responseVO.setOk("해당 실험노트를 찾을수 없습니다.");
			return responseVO;
		}

		String mrqTypeCd = reqDTO.getVMrqTypeCd();
		String trMrqTypeCd = mrqTypeCd;
		String trGoalCd = "";

		reqDTO.setVTrMrqTypeCd(trMrqTypeCd);
		reqDTO.setVTrGoalCd(trGoalCd);

		//MU,HBO 개발 취소 된 내용물 제외 >> CONT.V_FLAG_CANCEL ='N'
		List<LabNoteTestReqContVO> contList = hbdTestReqMapper.selectTestReqContList(reqDTO.getVLabNoteCd(), reqDTO.getVPlantCd());

		if (!ObjectUtils.isEmpty(contList)) {

			reqDTO.setVLanguage(sessionUtil.getLocalLanguage());
			lotList = hbdTestReqMapper.selectTestReqLotList(reqDTO);

			if (!ObjectUtils.isEmpty(lotList)) {
				final List<LabNoteTestReqLotVO> copiedList = lotList.stream().collect(Collectors.toList());

				contList.stream().forEach(cvo -> {
					cvo.setSubList(copiedList.stream().filter(lvo -> lvo.getVContPkCd().equals(cvo.getVContPkCd())).collect(Collectors.toList()));
				});
			}
		}

		//안전성 및 방부 시험의뢰 인 경우,버전정보도 가져오기
		//lotList를 가지고 올때는 contPkCd가 있으면 안되기 때문에 팝업창OPEN시 파라미터를
		//i_sOtherContPkCd로 이름을 바꿔서 보내고 여기서 재정의해서 사용 후 다시 리셋시킨다

		//버전정보 가져오기
		List<VersionListVO> verList = hbdCommonService.selectLabNoteVersionList(reqDTO.getVOtherContPkCd());

		// 해당 시험의뢰 마지막 버전
		reqDTO.setVFlagAllLast("N");
		ElabNoteLastTrInfoDTO lastTrVo = testReqCommonMapper.selectElabLastTrInfo(reqDTO.getVLabNoteCd(), reqDTO.getVFlagAllLast(), reqDTO.getVFlagUseGate(), reqDTO.getVMrqTypeCd(), reqDTO.getVGateCd());

		// 전체 마지막 버전
		reqDTO.setVFlagAllLast("Y");
		ElabNoteLastTrInfoDTO allLastTrVo = testReqCommonMapper.selectElabLastTrInfo(reqDTO.getVLabNoteCd(), reqDTO.getVFlagAllLast(), reqDTO.getVFlagUseGate(), reqDTO.getVMrqTypeCd(), reqDTO.getVGateCd());
		//방부시험의뢰가 아닐경우
		// 전체 다 입력 받는건 전체 기준으로 마지막 정보를 가져옴
		if (allLastTrVo != null) {
			if (lastTrVo == null) {
				lastTrVo = new ElabNoteLastTrInfoDTO();
			}
			lastTrVo.setVDosageFormCd(allLastTrVo.getVDosageFormCd());
		}

		String vFlagZmBbNote = "Y";

		responseVO.setOk(HbdTestReqResDTO.builder()
				.noteVo(noteVo)
				.contList(contList)
				.lotList(lotList)
				.lastTrVo(lastTrVo)
				.vFlagZmBbNote(vFlagZmBbNote)
				.vTrMrqTypeCd(trMrqTypeCd)
				.vTrGoalCd(trGoalCd)
				.verList(verList)
				.vFlagMultiple("Y")
				.build());
		return responseVO;

	}

	@Transactional
	public ResultDTO insertSaveFlavorTestReq (@Valid LabNoteTestReqRegDTO regDTO) {
		ResultDTO resultMap = new ResultDTO();
		regDTO.setVLanguage(sessionUtil.getLocalLanguage());

		HbdNoteInfoDTO noteVo = hbdCommonService.selectLabNoteInfo(regDTO.getVLabNoteCd());

		if (ObjectUtils.isEmpty(noteVo)) {
			resultMap.setStatus(Const.FAIL);
			resultMap.setMessage("해당 시험노트 내용을 찾을수 없습니다.");
			return resultMap;
		}

		List<LabNoteTestReqContVO> contList = regDTO.getContList();

		StringBuffer sb = new StringBuffer();
		boolean isSum100 = true;

		for (LabNoteTestReqContVO cvo : contList) {

			regDTO.setVLand1("UN");
			regDTO.setNVersion(regDTO.getNVersion());
			regDTO.setVLotCd(cvo.getVLotCd());
			regDTO.setVContPkCd(cvo.getVContPkCd());

			LabNoteValidateDTO valiVo = hbdTestReqMapper.selectLabNoteValidateInfo(regDTO);

			if (ObjectUtils.isEmpty(valiVo)) {
				isSum100 = false;

				sb.append(cvo.getVContCd())
				  .append(" : Lot 정보 오류");
			} else if (valiVo.getNSumRate() != 100d) {
				isSum100 = false;

				sb.append(cvo.getVContCd())
				  .append(" : 함량 100이 아님");
			}
		}

		if (!isSum100) {
			sb.append("<br/>위 사유로 시험의뢰가 불가능 합니다.");

			resultMap.setStatus(Const.FAIL);
			resultMap.setMessage(sb.toString());
			return resultMap;
		}

		LabNoteSupTrPrdInfoDTO trVo = testReqCommonMapper.selectLabNoteSupTrProductInfo(regDTO);

//		라인제품 복수개 의뢰 or 부향의뢰시는 버전업이 아닌 새로 생성

		InsertSupTrPrdInfoDTO trTempVo = hbdTestReqMapper.selectInsertSupTrProductInfo(regDTO.getVLabNoteCd(), regDTO.getVRepContPkCd(), regDTO.getVRepLotCd());

		if(ObjectUtils.isEmpty(trTempVo)) {
			resultMap.setStatus(Const.FAIL);
			resultMap.setMessage("해당 시험노트 내용을 찾을수 없습니다.");
			return resultMap;
		}

		regDTO.setVTestReqTable(regDTO.getVTrMrqTypeCd());
		regDTO.setVTrCompleteReqDt(CommonUtil.getOnlyNumber(regDTO.getVTrCompleteReqDt()));
		regDTO.setVTrPrdNm(trTempVo.getVProductNm());
		regDTO.setVTrPrdEngNm(trTempVo.getVProductEngNm());
		regDTO.setVTrSapCd(trTempVo.getVSapCd());
		regDTO.setVUserid(trTempVo.getVUserId());
		regDTO.setVDeptCd(trTempVo.getVDeptCd());
		regDTO.setVAmoreProdYn(trTempVo.getVAmoreProdYn());
		regDTO.setVInnerPlant(trTempVo.getVInnerPlant());
		regDTO.setVMakerNm(trTempVo.getVMakerNm());
		regDTO.setVLot(trTempVo.getVLot());
		regDTO.setVTypeCd(trTempVo.getVTypeCd());
		regDTO.setVTypeCd2(trTempVo.getVTypeCd2());
		regDTO.setVCont1Cd(trTempVo.getVCont1Cd());
		regDTO.setVCont2Cd(trTempVo.getVCont2Cd());

		regDTO.setVRpmsCd(trTempVo.getVRpmsCd());
		regDTO.setVBrdCd(trTempVo.getVBrdCd());
		regDTO.setVMeetingDt(trTempVo.getVMeetingDt());
		regDTO.setVWerks(trTempVo.getVWerks());
		regDTO.setVFlagReleaseAsia(trTempVo.getVFlagReleaseAsia());
		regDTO.setVFlagReleaseAsean(trTempVo.getVFlagReleaseAsean());
		regDTO.setVFlagReleaseEtc(trTempVo.getVFlagReleaseEtc());
		regDTO.setVPartCd(trTempVo.getVPartCd());

		regDTO.setVRegUserid(sessionUtil.getLoginId());
		regDTO.setVUpdateUserid(sessionUtil.getLoginId());

		if (StringUtils.isEmpty(regDTO.getVTrPilotDt())) {
			regDTO.setVTrPilotDt(trTempVo.getVPilotDt());
		}

		int rcvUsrLen = 0;

		List<GroupUserInfoDTO> rcvUsrList = null;

		if(StringUtils.isNotEmpty(noteVo.getVDeptCd())) {
			rcvUsrList = testReqCommonMapper.selectPrsvRcvMailUserList(noteVo.getVDeptCd());
			rcvUsrLen = rcvUsrList == null ? 0 : rcvUsrList.size();
		}

		if(rcvUsrLen == 0) {
			rcvUsrList = commonService.selectGroupUserList("S000292");
		}

		rcvUsrLen = rcvUsrList == null ? 0 : rcvUsrList.size();

		if(rcvUsrLen > 0) {
			regDTO.setVPrescUserid(rcvUsrList.get(0).getVUserid());
		}

		if(!"TMT_2".equals( regDTO.getVTrTestTypeCd())){
			regDTO.setVCreateNo("");
		}

		if (StringUtils.isEmpty(regDTO.getVTrPrdCd())) {
			regDTO.setNTrVersion(1);
			testReqCommonMapper.insertSupTrProduct(regDTO);// v_feature (ver2  부터는 사유 입력)
			hbdTestReqMapper.insertSupTrReleaseCountry(regDTO);
		} else {
			regDTO.setNTrVersion(trVo.getNVersion() + 1);
			testReqCommonMapper.insertSupTrProductVer(regDTO);
			testReqCommonMapper.updateSupTrProduct(regDTO);// v_feature (ver2  부터는 사유 입력)
			hbdTestReqMapper.insertSupTrReleaseCountry(regDTO);
		}

		// [s] MRQ060(부향)만 실행
		testReqCommonMapper.insertLabNoteToMrqTestReqFlavor(regDTO);
		hbdTestReqMapper.insertLabNoteToMrqMateTestReqFlavor(regDTO);
		testReqCommonMapper.updateScentLabMstState(regDTO.getVLabNoteCd());
		// [e] MRQ060(부향)만 실행

		hbdTestReqMapper.updateLabNoteMstFlagTestReq(regDTO.getVLabNoteCd(), regDTO.getVRegUserid());

		testReqCommonService.updateLabNoteProductTestRequest(regDTO);

		if (StringUtils.isNotEmpty(regDTO.getVTrComment().trim())) {
			testReqCommonMapper.insertMrqMessage(regDTO);
		}

		resultMap.setStatus(Const.SUCC);
		resultMap.setMessage("success");
		return resultMap;
	}

	@Transactional
	public ResultDTO insertSaveSafetyTestReq (@Valid LabNoteTestReqRegDTO regDTO) {
		ResultDTO resultMap = new ResultDTO();
		regDTO.setVLanguage(sessionUtil.getLocalLanguage());

		HbdNoteInfoDTO noteVo = hbdCommonService.selectLabNoteInfo(regDTO.getVLabNoteCd());

		if (ObjectUtils.isEmpty(noteVo)) {
			resultMap.setStatus(Const.FAIL);
			resultMap.setMessage("해당 시험노트 내용을 찾을수 없습니다.");
			return resultMap;
		}

		List<LabNoteTestReqContVO> contList = regDTO.getContList();

		StringBuffer sb = new StringBuffer();
		boolean isSum100 = true;

		for (LabNoteTestReqContVO cvo : contList) {

			cvo.setVLand1("UN");

			LabNoteValidateDTO valiVo = hbdTestReqMapper.selectLabNoteValidateInfo2(cvo);

			if (ObjectUtils.isEmpty(valiVo)) {
				isSum100 = false;

				sb.append(cvo.getVContCd())
				  .append(" : Lot 정보 오류");
			} else if (valiVo.getNSumRate() != 100d) {
				isSum100 = false;

				sb.append(cvo.getVContCd())
				  .append(" : 함량 100이 아님");
			}
		}

		if (!isSum100) {
			sb.append("<br/>위 사유로 시험의뢰가 불가능 합니다.");

			resultMap.setStatus(Const.FAIL);
			resultMap.setMessage(sb.toString());
			return resultMap;
		}

		String trPrdCd 	   = "";
		String trMrqTypeCd = regDTO.getVTrMrqTypeCd();

		LabNoteSupTrPrdInfoDTO trVo = testReqCommonMapper.selectLabNoteSupTrProductInfo(regDTO);

//		라인제품 복수개 의뢰 or 부향의뢰시는 버전업이 아닌 새로 생성
		if (trVo != null && trVo.getNLineContCnt() == 0 && !"MRQ060".equals(trMrqTypeCd)) {
			trPrdCd = trVo.getVProductCd();
			regDTO.setVTrPrdCd(trPrdCd);
		}

		InsertSupTrPrdInfoDTO trTempVo = hbdTestReqMapper.selectInsertSupTrProductInfo(regDTO.getVLabNoteCd(), regDTO.getVRepContPkCd(), regDTO.getVRepLotCd());

		if(ObjectUtils.isEmpty(trTempVo)) {
			resultMap.setStatus(Const.FAIL);
			resultMap.setMessage("해당 시험노트 내용을 찾을수 없습니다.");
			return resultMap;
		}

		regDTO.setVTestReqTable(regDTO.getVTrMrqTypeCd());
		regDTO.setVTrCompleteReqDt(CommonUtil.getOnlyNumber(regDTO.getVTrCompleteReqDt()));

		regDTO.setVTrPrdNm(trTempVo.getVProductNm());
		regDTO.setVTrPrdEngNm(trTempVo.getVProductEngNm());
		regDTO.setVTrSapCd(trTempVo.getVSapCd());
		regDTO.setVUserid(trTempVo.getVUserId());
		regDTO.setVDeptCd(trTempVo.getVDeptCd());
		regDTO.setVAmoreProdYn(trTempVo.getVAmoreProdYn());
		regDTO.setVInnerPlant(trTempVo.getVInnerPlant());
		regDTO.setVMakerNm(trTempVo.getVMakerNm());
		regDTO.setVLot(trTempVo.getVLot());
		regDTO.setVTypeCd(trTempVo.getVTypeCd());
		regDTO.setVTypeCd2(trTempVo.getVTypeCd2());
		regDTO.setVTddProdType1Cd(noteVo.getVTddProdType1Cd());
		regDTO.setVTddProdType2Cd(noteVo.getVTddProdType2Cd());
		regDTO.setVCont1Cd(trTempVo.getVCont1Cd());
		regDTO.setVCont2Cd(trTempVo.getVCont2Cd());

		regDTO.setVRpmsCd(trTempVo.getVRpmsCd());
		regDTO.setVBrdCd(trTempVo.getVBrdCd());
		regDTO.setVMeetingDt(trTempVo.getVMeetingDt());
		regDTO.setVWerks(trTempVo.getVWerks());
		regDTO.setVFlagReleaseAsia(trTempVo.getVFlagReleaseAsia());
		regDTO.setVFlagReleaseAsean(trTempVo.getVFlagReleaseAsean());
		regDTO.setVFlagReleaseEtc(trTempVo.getVFlagReleaseEtc());
		regDTO.setVPartCd(trTempVo.getVPartCd());

		regDTO.setVRegUserid(sessionUtil.getLoginId());
		regDTO.setVUpdateUserid(sessionUtil.getLoginId());

		if (StringUtils.isEmpty(regDTO.getVTrPilotDt())) {
			regDTO.setVTrPilotDt(trTempVo.getVPilotDt());
		}

		int rcvUsrLen = 0;

		List<GroupUserInfoDTO> rcvUsrList = null;

		if(StringUtils.isNotEmpty(noteVo.getVDeptCd())) {
			rcvUsrList = testReqCommonMapper.selectPrsvRcvMailUserList(noteVo.getVDeptCd());
			rcvUsrLen = rcvUsrList == null ? 0 : rcvUsrList.size();
		}

		if(rcvUsrLen == 0) {
			rcvUsrList = commonService.selectGroupUserList("S000292");
		}

		rcvUsrLen = rcvUsrList == null ? 0 : rcvUsrList.size();

		if(rcvUsrLen > 0) {
			regDTO.setVPrescUserid(rcvUsrList.get(0).getVUserid());
		}

		if(!"TMT_2".equals( regDTO.getVTrTestTypeCd())){
			regDTO.setVCreateNo("");
		}

		if (StringUtils.isEmpty(regDTO.getVTrPrdCd())) {
			regDTO.setNTrVersion(1);
			testReqCommonMapper.insertSupTrProduct(regDTO);// v_feature (ver2  부터는 사유 입력)
			hbdTestReqMapper.insertSupTrReleaseCountry(regDTO);
		} else {
			regDTO.setNTrVersion(trVo.getNVersion() + 1);
			testReqCommonMapper.insertSupTrProductVer(regDTO);
			testReqCommonMapper.updateSupTrProduct(regDTO);// v_feature (ver2  부터는 사유 입력)
			hbdTestReqMapper.insertSupTrReleaseCountry(regDTO);
		}

		// [s] MRQ010(안전성)만 실행
		List<SupTrProductSameVO> sameList = regDTO.getSameList();

		if (!ObjectUtils.isEmpty(sameList)) {
			testReqCommonMapper.insertSupTrProductSame(regDTO);
		}

		hbdTestReqMapper.insertSupTrProductLine(regDTO);

		SupTrComponentVO componentVO = SupTrComponentVO.builder()
				.vProductCd(regDTO.getVTrPrdCd())
				.nVersion(regDTO.getNTrVersion())
				.vLand1(StringUtils.defaultIfEmpty(regDTO.getVLand1(), "UN"))
				.vContPkCd(regDTO.getVContPkCd())
				.vRegUserid(sessionUtil.getLoginId())
				.vLangCd(StringUtils.defaultIfEmpty(regDTO.getVLand1(), "UN"))
				.build();

		Zplm013MosAjaxVO mosAjaxVO = Zplm013MosAjaxVO.builder()
				.vProductCd(regDTO.getVTrPrdCd())
				.nVersion(regDTO.getNVersion())
				.vTddProdType1Cd(regDTO.getVTddProdType1Cd())
				.vTddProdType2Cd(regDTO.getVTddProdType2Cd())
				.build();

		EssentialTestAddVO testAddVO = EssentialTestAddVO.builder()
				.vProductCd(regDTO.getVTrPrdCd())
				.nVersion(regDTO.getNVersion())
				.vTypeCd(noteVo.getVProdType1Cd())
				.vTypeCd2(noteVo.getVProdType2Cd())
				.vRegUserid(sessionUtil.getLoginId())
				.vLabNoteCd(regDTO.getVLabNoteCd())
				.build();

		for (LabNoteTestReqContVO cvo : contList) {
			componentVO.setVContCd(StringUtils.defaultIfEmpty(cvo.getVContCd(), cvo.getVContPkCd()));
			mosAjaxVO.setVContCd(StringUtils.defaultIfEmpty(cvo.getVContCd(), cvo.getVContPkCd()));

			componentVO.setVLotCd(cvo.getVLotCd());

			componentVO.setVWerks(cvo.getVPlantCd());
			mosAjaxVO.setVWerks(cvo.getVPlantCd());

//			//4자정보 저장할 때, contPkCd의 버전에 따라 가지고 오는 값이 달라지기 때문에
//			//안전성 및 방부시험의뢰를 할 경우에는 해당하는 버전 값으로 셋팅
//			//처방은 lotCd만 사용되기때문에 변경사함 없음
			componentVO.setNVersionTestReq(cvo.getNVersion());

			componentVO.setVContPkCd(cvo.getVContPkCd());

			hbdCommonService.insertTrLabNoteComponent(componentVO);

			if (StringUtils.isNotEmpty(cvo.getVPlantCd())) {
				labNoteCommonService.getZplm013MosAjax(mosAjaxVO);
			}
		}

		labNoteCommonService.essentialTestAdd(testAddVO);

		// 시험법 저장
		List<String> testItemCdList = regDTO.getTestItemCdList();

		if (!ObjectUtils.isEmpty(testItemCdList)) {
			if (testItemCdList.contains("MTI01_07") && StringUtils.isNotEmpty(regDTO.getVMethodEtc())) {
				hbdTestReqMapper.insertNoteMstTag(HbdNoteMstVerTagVO.builder()
						.vLabNoteCd(regDTO.getVLabNoteCd())
						.vTag1Cd("MTI01")
						.vTag2Cd("MTI01_07")
						.nSort(1)
						.vBuffer1("")
						.vBuffer2(regDTO.getVMethodEtc())
						.vBuffer3("")
						.vRegUserid(sessionUtil.getLoginId())
						.vUpdateUserid(sessionUtil.getLoginId())
						.build());
			}

			List<CodeDTO> rmList = labNoteCommonService.selectReqTestMethodList(testItemCdList);

			regDTO.setVReqMethod(!ObjectUtils.isEmpty(rmList) ? rmList.stream().map(CodeDTO::getVBuffer1).collect(Collectors.joining(",")) : "");
			testReqCommonMapper.insertLabNoteToMrqTestReqSafety(regDTO);
			hbdTestReqMapper.updateLabNoteLotTrPrdCd(regDTO);
		}
		// [e] MRQ010(안전성)만 실행

		hbdTestReqMapper.updateLabNoteMstFlagTestReq(regDTO.getVLabNoteCd(), regDTO.getVRegUserid());

		testReqCommonService.updateLabNoteProductTestRequest(regDTO);

		if (StringUtils.isNotEmpty(regDTO.getVTrComment().trim())) {
			testReqCommonMapper.insertMrqMessage(regDTO);
		}

		resultMap.setStatus(Const.SUCC);
		resultMap.setMessage("success");
		return resultMap;
	}

	@Transactional
	public ResultDTO insertSaveHarmSubTestReq (@Valid LabNoteTestReqRegDTO regDTO) {
		ResultDTO resultMap = new ResultDTO();
		regDTO.setVLanguage(sessionUtil.getLocalLanguage());

		HbdNoteInfoDTO noteVo = hbdCommonService.selectLabNoteInfo(regDTO.getVLabNoteCd());

		if (ObjectUtils.isEmpty(noteVo)) {
			resultMap.setStatus(Const.FAIL);
			resultMap.setMessage("해당 시험노트 내용을 찾을수 없습니다.");
			return resultMap;
		}

		List<LabNoteTestReqContVO> contList = regDTO.getContList();

		StringBuffer sb = new StringBuffer();
		boolean isSum100 = true;

		for (LabNoteTestReqContVO cvo : contList) {

			regDTO.setVLand1("UN");
			regDTO.setNVersion(regDTO.getNVersion());
			regDTO.setVLotCd(cvo.getVLotCd());
			regDTO.setVContPkCd(cvo.getVContPkCd());

			LabNoteValidateDTO valiVo = hbdTestReqMapper.selectLabNoteValidateInfo(regDTO);

			if (ObjectUtils.isEmpty(valiVo)) {
				isSum100 = false;

				sb.append(cvo.getVContCd())
				  .append(" : Lot 정보 오류");
			} else if (valiVo.getNSumRate() != 100d) {
				isSum100 = false;

				sb.append(cvo.getVContCd())
				  .append(" : 함량 100이 아님");
			}
		}

		if (!isSum100) {
			sb.append("<br/>위 사유로 시험의뢰가 불가능 합니다.");

			resultMap.setStatus(Const.FAIL);
			resultMap.setMessage(sb.toString());
			return resultMap;
		}

		String trPrdCd 	   = "";
		String trMrqTypeCd = regDTO.getVTrMrqTypeCd();

		LabNoteSupTrPrdInfoDTO trVo = testReqCommonMapper.selectLabNoteSupTrProductInfo(regDTO);

//		라인제품 복수개 의뢰 or 부향의뢰시는 버전업이 아닌 새로 생성
		if (trVo != null && trVo.getNLineContCnt() == 0 && !"MRQ060".equals(trMrqTypeCd)) {
			trPrdCd = trVo.getVProductCd();
			regDTO.setVTrPrdCd(trPrdCd);
		}

		InsertSupTrPrdInfoDTO trTempVo = hbdTestReqMapper.selectInsertSupTrProductInfo(regDTO.getVLabNoteCd(), regDTO.getVRepContPkCd(), regDTO.getVRepLotCd());

		if(ObjectUtils.isEmpty(trTempVo)) {
			resultMap.setStatus(Const.FAIL);
			resultMap.setMessage("해당 시험노트 내용을 찾을수 없습니다.");
			return resultMap;
		}

		regDTO.setVTestReqTable(regDTO.getVTrMrqTypeCd());
		regDTO.setVTrCompleteReqDt(CommonUtil.getOnlyNumber(regDTO.getVTrCompleteReqDt()));
		regDTO.setVTrPrdNm(trTempVo.getVProductNm());
		regDTO.setVTrPrdEngNm(trTempVo.getVProductEngNm());
		regDTO.setVTrSapCd(trTempVo.getVSapCd());
		regDTO.setVUserid(trTempVo.getVUserId());
		regDTO.setVDeptCd(trTempVo.getVDeptCd());
		regDTO.setVAmoreProdYn(trTempVo.getVAmoreProdYn());
		regDTO.setVInnerPlant(trTempVo.getVInnerPlant());
		regDTO.setVMakerNm(trTempVo.getVMakerNm());
		regDTO.setVLot(trTempVo.getVLot());
		regDTO.setVTypeCd(trTempVo.getVTypeCd());
		regDTO.setVTypeCd2(trTempVo.getVTypeCd2());
		regDTO.setVTddProdType1Cd(noteVo.getVTddProdType1Cd());
		regDTO.setVTddProdType2Cd(noteVo.getVTddProdType2Cd());

		regDTO.setVCont1Cd(trTempVo.getVCont1Cd());
		regDTO.setVCont2Cd(trTempVo.getVCont2Cd());

		regDTO.setVRpmsCd(trTempVo.getVRpmsCd());
		regDTO.setVBrdCd(trTempVo.getVBrdCd());
		regDTO.setVMeetingDt(trTempVo.getVMeetingDt());
		regDTO.setVWerks(trTempVo.getVWerks());
		regDTO.setVFlagReleaseAsia(trTempVo.getVFlagReleaseAsia());
		regDTO.setVFlagReleaseAsean(trTempVo.getVFlagReleaseAsean());
		regDTO.setVFlagReleaseEtc(trTempVo.getVFlagReleaseEtc());
		regDTO.setVPartCd(trTempVo.getVPartCd());

		regDTO.setVRegUserid(sessionUtil.getLoginId());
		regDTO.setVUpdateUserid(sessionUtil.getLoginId());

		if (StringUtils.isEmpty(regDTO.getVTrPilotDt())) {
			regDTO.setVTrPilotDt(trTempVo.getVPilotDt());
		}

		int rcvUsrLen = 0;

		List<GroupUserInfoDTO> rcvUsrList = null;

		if(StringUtils.isNotEmpty(noteVo.getVDeptCd())) {
			rcvUsrList = testReqCommonMapper.selectPrsvRcvMailUserList(noteVo.getVDeptCd());
			rcvUsrLen = rcvUsrList == null ? 0 : rcvUsrList.size();
		}

		if(rcvUsrLen == 0) {
			rcvUsrList = commonService.selectGroupUserList("S000292");
		}

		rcvUsrLen = rcvUsrList == null ? 0 : rcvUsrList.size();

		if(rcvUsrLen > 0) {
			regDTO.setVPrescUserid(rcvUsrList.get(0).getVUserid());
		}

		if(!"TMT_2".equals( regDTO.getVTrTestTypeCd())){
			regDTO.setVCreateNo("");
		}

		if (StringUtils.isEmpty(regDTO.getVTrPrdCd())) {
			regDTO.setNTrVersion(1);
			testReqCommonMapper.insertSupTrProduct(regDTO);// v_feature (ver2  부터는 사유 입력)
			hbdTestReqMapper.insertSupTrReleaseCountry(regDTO);
		} else {
			regDTO.setNTrVersion(trVo.getNVersion() + 1);
			testReqCommonMapper.insertSupTrProductVer(regDTO);
			testReqCommonMapper.updateSupTrProduct(regDTO);// v_feature (ver2  부터는 사유 입력)
			hbdTestReqMapper.insertSupTrReleaseCountry(regDTO);
		}

		testReqCommonMapper.insertLabNoteToMrqTestReqFunc(regDTO);

		hbdTestReqMapper.updateLabNoteMstFlagTestReq(regDTO.getVLabNoteCd(), regDTO.getVRegUserid());

		testReqCommonService.updateLabNoteProductTestRequest(regDTO);

		if (StringUtils.isNotEmpty(regDTO.getVTrComment().trim())) {
			testReqCommonMapper.insertMrqMessage(regDTO);
		}

		resultMap.setStatus(Const.SUCC);
		resultMap.setMessage("success");
		return resultMap;
	}

	@Transactional
	public ResultDTO insertSaveChinaSafetyReviewTestReq (@Valid LabNoteTestReqRegDTO regDTO) {
		ResultDTO resultMap = new ResultDTO();
		regDTO.setVLanguage(sessionUtil.getLocalLanguage());

		HbdNoteInfoDTO noteVo = hbdCommonService.selectLabNoteInfo(regDTO.getVLabNoteCd());

		if (ObjectUtils.isEmpty(noteVo)) {
			resultMap.setStatus(Const.FAIL);
			resultMap.setMessage("해당 시험노트 내용을 찾을수 없습니다.");
			return resultMap;
		}

		List<LabNoteTestReqContVO> contList = regDTO.getContList();

		StringBuffer sb = new StringBuffer();
		boolean isSum100 = true;

		for (LabNoteTestReqContVO cvo : contList) {

			cvo.setVLand1("UN");

			LabNoteValidateDTO valiVo = hbdTestReqMapper.selectLabNoteValidateInfo2(cvo);

			if (ObjectUtils.isEmpty(valiVo)) {
				isSum100 = false;

				sb.append(cvo.getVContCd())
				  .append(" : Lot 정보 오류");
			} else if (valiVo.getNSumRate() != 100d) {
				isSum100 = false;

				sb.append(cvo.getVContCd())
				  .append(" : 함량 100이 아님");
			}
		}

		if (!isSum100) {
			sb.append("<br/>위 사유로 시험의뢰가 불가능 합니다.");

			resultMap.setStatus(Const.FAIL);
			resultMap.setMessage(sb.toString());
			return resultMap;
		}

		// etw 2023.07.13
		// 시험의뢰 > 중국 안전성 사전검토는
		// SUP_TR_PRODUCT 테이블에 데이터가 쌓이지 않는다고 함.
		// insertPrdTestReqInfo 메소드의 simpleVo 에 담는 쿼리를 호출하지 않기 때문에
		// 해당 쿼리의 파라미터인 vTrPrdCd를 검색할 필요 없음.

//		String trPrdCd 	   = "";
//		String trMrqTypeCd = regDTO.getVTrMrqTypeCd();
//
//		LabNoteSupTrPrdInfoDTO trVo = testReqCommonMapper.selectLabNoteSupTrProductInfo(regDTO);
//
////		라인제품 복수개 의뢰 or 부향의뢰시는 버전업이 아닌 새로 생성
//		if (trVo != null && trVo.getNLineContCnt() == 0 && !"MRQ060".equals(trMrqTypeCd)) {
//			trPrdCd = trVo.getVProductCd();
//			regDTO.setVTrPrdCd(trPrdCd);
//		}

		InsertSupTrPrdInfoDTO trTempVo = hbdTestReqMapper.selectInsertSupTrProductInfo(regDTO.getVLabNoteCd(), regDTO.getVRepContPkCd(), regDTO.getVRepLotCd());

		if(ObjectUtils.isEmpty(trTempVo)) {
			resultMap.setStatus(Const.FAIL);
			resultMap.setMessage("해당 시험노트 내용을 찾을수 없습니다.");
			return resultMap;
		}

		regDTO.setVTestReqTable(regDTO.getVTrMrqTypeCd());
		regDTO.setVTrCompleteReqDt(CommonUtil.getOnlyNumber(regDTO.getVTrCompleteReqDt()));
		regDTO.setVTrPrdNm(trTempVo.getVProductNm());
		regDTO.setVTrPrdEngNm(trTempVo.getVProductEngNm());
		regDTO.setVTrSapCd(trTempVo.getVSapCd());
		regDTO.setVUserid(trTempVo.getVUserId());
		regDTO.setVDeptCd(trTempVo.getVDeptCd());
		regDTO.setVAmoreProdYn(trTempVo.getVAmoreProdYn());
		regDTO.setVInnerPlant(trTempVo.getVInnerPlant());
		regDTO.setVMakerNm(trTempVo.getVMakerNm());
		regDTO.setVLot(trTempVo.getVLot());
		regDTO.setVTypeCd(trTempVo.getVTypeCd());
		regDTO.setVTypeCd2(trTempVo.getVTypeCd2());
		regDTO.setVTddProdType1Cd(noteVo.getVTddProdType1Cd());
		regDTO.setVTddProdType2Cd(noteVo.getVTddProdType2Cd());
		regDTO.setVCont1Cd(trTempVo.getVCont1Cd());
		regDTO.setVCont2Cd(trTempVo.getVCont2Cd());

		regDTO.setVRpmsCd(trTempVo.getVRpmsCd());
		regDTO.setVBrdCd(trTempVo.getVBrdCd());
		regDTO.setVMeetingDt(trTempVo.getVMeetingDt());
		regDTO.setVWerks(trTempVo.getVWerks());
		regDTO.setVFlagReleaseAsia(trTempVo.getVFlagReleaseAsia());
		regDTO.setVFlagReleaseAsean(trTempVo.getVFlagReleaseAsean());
		regDTO.setVFlagReleaseEtc(trTempVo.getVFlagReleaseEtc());
		regDTO.setVPartCd(trTempVo.getVPartCd());

		regDTO.setVRegUserid(sessionUtil.getLoginId());
		regDTO.setVUpdateUserid(sessionUtil.getLoginId());
		if (StringUtils.isEmpty(regDTO.getVTrPilotDt())) {
			regDTO.setVTrPilotDt(trTempVo.getVPilotDt());
		}

		int rcvUsrLen = 0;

		List<GroupUserInfoDTO> rcvUsrList = null;

		if(StringUtils.isNotEmpty(noteVo.getVDeptCd())) {
			rcvUsrList = testReqCommonMapper.selectPrsvRcvMailUserList(noteVo.getVDeptCd());
			rcvUsrLen = rcvUsrList == null ? 0 : rcvUsrList.size();
		}

		if(rcvUsrLen == 0) {
			rcvUsrList = commonService.selectGroupUserList("S000292");
		}

		rcvUsrLen = rcvUsrList == null ? 0 : rcvUsrList.size();

		if(rcvUsrLen > 0) {
			regDTO.setVPrescUserid(rcvUsrList.get(0).getVUserid());
		}

		if(!"TMT_2".equals( regDTO.getVTrTestTypeCd())){
			regDTO.setVCreateNo("");
		}

		// [s] MRQ070(중국 안전성 사전검토)만 실행
		//선택된 원료들 중국사전안전성에 시험의뢰 상태로 저장
		String tddTypeValue = regDTO.getVProductClass();
		TddProductClassVO tVo = labNoteCommonService.selectTddProductValue(tddTypeValue);

		String vReviewUserid = "";

		String resetBrdCd = labNoteCommonService.selectChinaSafetyElabBrandSubCode(noteVo.getVBrdCd());
		if (StringUtils.isNotEmpty(resetBrdCd)) {
			CpsrTesterUserVO reviewUser = labNoteCommonService.selectChinaSafetyReviewUser(resetBrdCd);

			if (!ObjectUtils.isEmpty(reviewUser)) {
				vReviewUserid = reviewUser.getVNatRa();
			}
		}

		for (LabNoteTestReqContVO cvo : contList) {

			ChinaSafetyMstVO mstVO = ChinaSafetyMstVO.builder()
					.vStatusCd("CSS002")
					.vContCd(cvo.getVContCd())
					.vContNm(regDTO.getVTrContNmEn())
					.vPlantCd(cvo.getVPlantCd())
					.vLeaveonyn(regDTO.getVLeaveOnYn())
					.vVer(String.valueOf(cvo.getNVersion()))
					.vLot(cvo.getVLotNm())
					.vLotCd(cvo.getVLotCd())
					.vReqUserid(sessionUtil.getLoginId())
					.vReviewUserid(vReviewUserid)
					.vBrand(resetBrdCd)
					.vTddProdType(tddTypeValue)
					.vDivFlag("E-LABNOTE")
					.vPrdct(tVo.getVPrdct())
					.vTgpol(tVo.getVTgpol())
					.vZpqew(tVo.getVZpgew())
					.vGday(tVo.getVGday())
					.vMgday(tVo.getVMgday())
					.vRfdt(tVo.getVRfdt())
					.vMkday(tVo.getVMkday())
					.vRegUserid(sessionUtil.getLoginId())
					.build();

			int result = labNoteCommonService.insertChinaSafetyEv(mstVO);

			if (result > 0) {
				ChinaSafetyMsgVO msgVO = ChinaSafetyMsgVO.builder()
						.vRecordid(mstVO.getVRecordid())
						.vMessage(regDTO.getVTrComment())
						.vRegUserid(sessionUtil.getLoginId())
						.build();

				labNoteCommonService.insertChinaSafetyMsgLog(msgVO);
			}
		}
		// [e] MRQ070(중국 안전성 사전검토)만 실행

		hbdTestReqMapper.updateLabNoteMstFlagTestReq(regDTO.getVLabNoteCd(), regDTO.getVRegUserid());

		resultMap.setStatus(Const.SUCC);
		resultMap.setMessage("success");
		return resultMap;
	}

	public ResponseVO selectTestReqLotList(LabNoteTestReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();
		responseVO.setOk(hbdTestReqMapper.selectTestReqLotList(reqDTO));
		return responseVO;
	}

	//시험의뢰 > 방부 팝업 정보
	@SuppressWarnings("unused")
	public ResponseVO selectPrdTestReqPreservativeInfo(@Valid LabNoteTestReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();
		List<LabNoteTestReqLotVO> lotList = null;

		if(StringUtils.isEmpty(reqDTO.getVLabNoteCd()) || reqDTO.getNVersion()<1) {
			responseVO.setOk("필수 입력값이 없습니다");
			return responseVO;
		}

		HbdNoteInfoDTO noteVo = hbdCommonService.selectLabNoteInfo(reqDTO.getVLabNoteCd());

		if(ObjectUtils.isEmpty(noteVo)) {
			responseVO.setOk("해당 실험노트를 찾을수 없습니다.");
			return responseVO;
		}

		String mrqTypeCd = reqDTO.getVMrqTypeCd();
		String trMrqTypeCd = mrqTypeCd;
		String trGoalCd = "";

		reqDTO.setVTrMrqTypeCd(trMrqTypeCd);
		reqDTO.setVTrGoalCd(trGoalCd);

		//MU,HBO 개발 취소 된 내용물 제외 >> CONT.V_FLAG_CANCEL ='N'
		List<LabNoteTestReqContVO> contList = hbdTestReqMapper.selectTestReqContList(reqDTO.getVLabNoteCd(), reqDTO.getVPlantCd());

		if (!ObjectUtils.isEmpty(contList)) {
			reqDTO.setVLanguage(sessionUtil.getLocalLanguage());
			lotList = hbdTestReqMapper.selectTestReqLotList(reqDTO);

			if (!ObjectUtils.isEmpty(lotList)) {
				final List<LabNoteTestReqLotVO> copiedList = lotList.stream().collect(Collectors.toList());

				contList.stream().forEach(cvo -> {
					cvo.setSubList(copiedList.stream().filter(lvo -> lvo.getVContPkCd().equals(cvo.getVContPkCd())).collect(Collectors.toList()));
				});
			}
		}

		//안전성 및 방부 시험의뢰 인 경우,버전정보도 가져오기
		//lotList를 가지고 올때는 contPkCd가 있으면 안되기 때문에 팝업창OPEN시 파라미터를
		//i_sOtherContPkCd로 이름을 바꿔서 보내고 여기서 재정의해서 사용 후 다시 리셋시킨다

		//버전정보 가져오기
		List<VersionListVO> verList = hbdCommonService.selectLabNoteVersionList(reqDTO.getVOtherContPkCd());

		//이미 접수한 방부의뢰가 있는지 체크하는 SAPCD
		String mrq011CheckSapCd = labNoteCommonService.selectStringMrq011CheckSapCd(reqDTO);

		StringBuffer trComment = new StringBuffer();
		trComment.append("카운터 처방과 차이점 :").append("\r\n")
				.append("요청 방부 시스템 :").append("\r\n")
				.append("적용 못하는 방부 시스템 :").append("\r\n")
				.append("완료 요청일 :").append("\r\n")
				.append("현재 실험 가능한 대표 호수 :").append("\r\n")
				.append("사전 협의된 방부 처방 :").append("\r\n");

		//버전별 내용물 카운터 조회
		LabNoteVersionDTO verVo = hbdCommonService.selectLabNoteMstVerInfo(reqDTO.getVLabNoteCd(), reqDTO.getNVersion());
		TestReqCounterDTO counterVo = new TestReqCounterDTO();

		if(verVo != null) {
			counterVo.setVCounterContCd(verVo.getVCounterContCd());
			counterVo.setVCounterContNm(verVo.getVCounterContNm());
			counterVo.setVWerks(hbdTestReqMapper.selectNotePlantInfo(verVo.getVCounterContCd()));
		}

		reqDTO.setVFlagAllLast("N");	// 해당 시험의뢰 마지막 버전
		reqDTO.setVFlagUseGate("N");	// 방부시험의뢰인 경우, GATE값을 무시하고 값을 가져온다
		ElabNoteLastTrInfoDTO lastTrVo = testReqCommonMapper.selectElabLastTrInfo(reqDTO.getVLabNoteCd(), reqDTO.getVFlagAllLast(), reqDTO.getVFlagUseGate(), reqDTO.getVMrqTypeCd(), reqDTO.getVGateCd());

		// 전체 마지막 버전
		reqDTO.setVFlagAllLast("Y");
		ElabNoteLastTrInfoDTO allLastTrVo = testReqCommonMapper.selectElabLastTrInfo(reqDTO.getVLabNoteCd(), reqDTO.getVFlagAllLast(), reqDTO.getVFlagUseGate(), reqDTO.getVMrqTypeCd(), reqDTO.getVGateCd());

		//방부시험의뢰 일때
		List<String> strProdSignCd = null;
		List<ProdSignResDTO> prodSignList = hbdTestReqMapper.selectProdSignList(reqDTO.getVLabNoteCd(), sessionUtil.getLangCd());
		if(prodSignList != null) {
			strProdSignCd = new ArrayList<String>();
			for(int i = 0; i< prodSignList.size(); i++) {
				ProdSignResDTO signVo = prodSignList.get(i);
				strProdSignCd.add(signVo.getVTag2Cd());
			}
		}

		//해당 시험의 마지막버전이 존재하는 경우 그 값으로 진행
		if(lastTrVo != null){
			lastTrVo.setArrProdSignListCd(strProdSignCd);		//제품표시 ( 실험노트 기준 )
		}
		//값이 없다면  실험노트 값으로 진행
		else{
			lastTrVo = ElabNoteLastTrInfoDTO.builder()
					.vContainerCd(noteVo.getVContainerCd())	//용기정보
					.vContainerEtc(noteVo.getVContainerEtc())	//용기정보ETC
					.vTddProdType1Cd(noteVo.getVTddProdType1Cd())	//TDD제품유형1
					.vTddProdType2Cd(noteVo.getVTddProdType2Cd())	//TDD제품유형2
					.vM011ProductionCd(noteVo.getVSiteType())	//생산제조장
					.vKosmetikCd(noteVo.getVLeaveType())	//미용법
					.arrProdSignListCd(strProdSignCd)		//제품표시 ( 실험노트 기준 )
					.build();
		}

		String vFlagZmBbNote = "Y";
		List<TestReqCounterMrq011DTO> counterList = labNoteCommonService.selectCounterMrq011List(lastTrVo.getVProductCd(), lastTrVo.getNVersion());

		responseVO.setOk(HbdTestReqResDTO.builder()
											 .noteVo(noteVo)
											 .contList(contList)
											 .lotList(lotList)
											 .lastTrVo(lastTrVo)
											 .vFlagZmBbNote(vFlagZmBbNote)
											 .vTrMrqTypeCd(trMrqTypeCd)
											 .vTrGoalCd(trGoalCd)
											 .verList(verList)
											 .vFlagMultiple("Y")
											 .mrq011CheckSapCd(mrq011CheckSapCd)
											 .vTrComment2(trComment.toString())
											 .counterVo(counterVo)
											 .counterList(counterList)
											 .build());
		return responseVO;

	}

	@Transactional
	public ResponseVO insertPrdTestPresevaticeInfo (LabNoteTestSavePrsvReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();
		ResultDTO resultVo = new ResultDTO();

		if(StringUtils.isEmpty(reqDTO.getVLabNoteCd())
				|| ObjectUtils.isEmpty(reqDTO.getContList())
				) {
			responseVO.setOkWithCode("C9999", "해당 시험노트 내용을 찾을수 없습니다.", null);
			return responseVO;
		}

		HbdNoteInfoDTO noteVo = hbdCommonService.selectLabNoteInfo(reqDTO.getVLabNoteCd());

		if(noteVo == null) {
			responseVO.setOkWithCode("C9999", "해당 시험노트 내용을 찾을수 없습니다.", null);
			return responseVO;
		}

		boolean isSum100 = true;
		StringBuffer sb = new StringBuffer();

		for(LabNoteTestReqContVO contVo : reqDTO.getContList()) {

			LabNoteValidateDTO valiVo = hbdTestReqMapper.selectLabNoteValidateInfo(LabNoteTestReqRegDTO.builder()
																							.vSiteType(noteVo.getVSiteType())
																							.vLand1("UN")
																							.nVersion(contVo.getNVersion())
																							.vContPkCd(contVo.getVContPkCd())
																							.vLotCd(contVo.getVLotCd())
																							.build());

			if(ObjectUtils.isEmpty(valiVo)) {
				isSum100 = false;
				sb.append(contVo.getVContCd());
				sb.append(" : Lot 정보 오류");
			}else if (valiVo.getNSumRate() != 100d) {
				isSum100 = false;
				sb.append(contVo.getVContCd());
				sb.append(" : 함량 100이 아님");
			}

		}

		if (!isSum100) {
			sb.append("<br/>위 사유로 시험의뢰가 불가능 합니다.");
			responseVO.setOkWithCode("C9999", sb.toString(), null);
			return responseVO;
		}

		//repContPkCd로 rep정보를 가지고 오기
		List<LabNoteTestReqContVO> repContList = reqDTO.getContList().stream().filter(vo -> vo.getVContPkCd().equals(reqDTO.getVRepContPkCd())).collect(Collectors.toList());
		int size = repContList == null ? 0 : repContList.size();
		if(size > 0) {
			reqDTO.setVRepContCd(repContList.get(0).getVContCd());
			reqDTO.setVRepLotCd(repContList.get(0).getVLotCd());
		}
		reqDTO.setVTrMrqTypeCd(reqDTO.getVMrqTypeCd());

		LabNoteSupTrPrdInfoDTO trVo = testReqCommonMapper.selectLabNoteSupTrProductInfo(LabNoteTestReqRegDTO.builder()
																.vLabNoteCd(reqDTO.getVLabNoteCd())
																.vMrqTypeCd(reqDTO.getVMrqTypeCd())
																.vRepContCd(reqDTO.getVRepContCd())
																.build()
																);

		// 라인제품 복수개 의뢰 or 부향의뢰시는 버전업이 아닌 새로 생성
		if(trVo != null && trVo.getNLineContCnt() == 0 && !"MRQ060".equals(reqDTO.getVMrqTypeCd())) {
			reqDTO.setVTrPrdCd(trVo.getVProductCd());
		}

		InsertSupTrPrdInfoDTO trTempVo = hbdTestReqMapper.selectInsertSupTrProductInfo(reqDTO.getVLabNoteCd(), reqDTO.getVRepContPkCd(), reqDTO.getVRepLotCd());

		if(trTempVo == null) {
			responseVO.setOkWithCode("C9999", "해당 시험노트 내용을 찾을수 없습니다.", null);
			return responseVO;
		}

		reqDTO.setVTrCompleteReqDt(CommonUtil.getOnlyNumber(CommonUtil.getOnlyNumber(reqDTO.getVTrCompleteReqDt())));
		reqDTO.setVRegUserid(sessionUtil.getLoginId());
		reqDTO.setVUpdateUserid(sessionUtil.getLoginId());
		reqDTO.setVTrPrdNm(trTempVo.getVProductNm());
		reqDTO.setVTrPrdEngNm(trTempVo.getVProductEngNm());
		reqDTO.setVSapCd(trTempVo.getVSapCd());
		reqDTO.setVUserid(trTempVo.getVUserId());
		reqDTO.setVDeptCd(trTempVo.getVDeptCd());
		reqDTO.setVAmoreProdYn(trTempVo.getVAmoreProdYn());
		reqDTO.setVInnerPlant(trTempVo.getVInnerPlant());
		reqDTO.setVMakerNm(trTempVo.getVMakerNm());
		reqDTO.setVLot(trTempVo.getVLot());
		reqDTO.setVTypeCd(trTempVo.getVTypeCd());
		reqDTO.setVTypeCd2(trTempVo.getVTypeCd2());

		reqDTO.setVRpmsCd(trTempVo.getVRpmsCd());
		reqDTO.setVBrdCd(trTempVo.getVBrdCd());
		reqDTO.setVMeetingDt(trTempVo.getVMeetingDt());
		reqDTO.setVWerks(trTempVo.getVWerks());
		reqDTO.setVFlagReleaseAsia(trTempVo.getVFlagReleaseAsia());
		reqDTO.setVFlagReleaseAsean(trTempVo.getVFlagReleaseAsean());
		reqDTO.setVFlagReleaseEtc(trTempVo.getVFlagReleaseEtc());
		reqDTO.setVPartCd(trTempVo.getVPartCd());
		reqDTO.setVSiteType(reqDTO.getVTrProductionCd());

		reqDTO.setVRegUserid(sessionUtil.getLoginId());
		reqDTO.setVUpdateUserid(sessionUtil.getLoginId());

		if (!StringUtils.isEmpty(reqDTO.getVTrPilotDt())) {
			reqDTO.setVTrPilotDt(reqDTO.getVTrPilotDt());
		}
		else {
			reqDTO.setVTrPilotDt(trTempVo.getVPilotDt());
		}

		String vFlagTmt1 = reqDTO.getVTrTestTypeCd().equals("TMT_1") ? "Y" : "";
		reqDTO.setVFlagTmt1(vFlagTmt1);

		int rcvUsrLen = 0;

		List<GroupUserInfoDTO> rcvUsrList = null;

		if(StringUtils.isNotEmpty(noteVo.getVDeptCd())) {
			rcvUsrList = testReqCommonMapper.selectPrsvRcvMailUserList(noteVo.getVDeptCd());
			rcvUsrLen = rcvUsrList == null ? 0 : rcvUsrList.size();
		}

		if(rcvUsrLen == 0) {
			rcvUsrList = commonService.selectGroupUserList("S000292");
		}

		rcvUsrLen = rcvUsrList == null ? 0 : rcvUsrList.size();

		if(rcvUsrLen > 0) {
			reqDTO.setVPrescUserid(rcvUsrList.get(0).getVUserid());
		}

		if(!"TMT_2".equals( reqDTO.getVTrTestTypeCd())){
			reqDTO.setVCreateNo("");
		}

		LabNoteTestReqRegDTO convertDTO = ConvertUtil.convert(reqDTO, LabNoteTestReqRegDTO.class);

		//중국사전안전평가일때는 안전성시험의뢰에 남기지 않는다. => as-is 조건 : if(!"MRQ070".equals(reqDTO.getVMrqTypeCd()))
		if(StringUtils.isEmpty(reqDTO.getVTrPrdCd())) {
			convertDTO.setNTrVersion(1);
			testReqCommonMapper.insertSupTrProduct(convertDTO);// v_feature (ver2  부터는 사유 입력)
			hbdTestReqMapper.insertSupTrReleaseCountry(convertDTO);
		}else {
			convertDTO.setNTrVersion(trVo.getNVersion() + 1);
			testReqCommonMapper.insertSupTrProductVer(convertDTO);
			testReqCommonMapper.updateSupTrProduct(convertDTO);// v_feature (ver2  부터는 사유 입력)
			hbdTestReqMapper.insertSupTrReleaseCountry(convertDTO);
		}

		// [s] MRQ011 방부 일때 로직
		if(reqDTO.getVTrProductionCd().equals("ETC")) {
			reqDTO.setVTrProductionTxt("");
		}

		reqDTO.setVTrPrdCd(convertDTO.getVTrPrdCd());
		reqDTO.setNTrVersion(convertDTO.getNTrVersion());

		hbdTestReqMapper.insertSupTrProductLine(LabNoteTestReqRegDTO.builder()
				.vTrPrdCd(reqDTO.getVTrPrdCd())
				.nTrVersion(reqDTO.getNTrVersion())
				.vRegUserid(sessionUtil.getLoginId())
				.vUpdateUserid(sessionUtil.getLoginId())
				.vRepContPkCd(reqDTO.getVRepContPkCd())
				.contList(reqDTO.getContList())
				.build());

		SupTrComponentVO componentVO = SupTrComponentVO.builder()
				.vProductCd(reqDTO.getVTrPrdCd())
				.nVersion(reqDTO.getNTrVersion())
				.vLand1(StringUtils.defaultIfEmpty(reqDTO.getVLand1(), "UN"))
				.vContPkCd(reqDTO.getVContPkCd())
				.vRegUserid(sessionUtil.getLoginId())
				.vLangCd(StringUtils.defaultIfEmpty(reqDTO.getVLand1(), "UN"))
				.build();

		Zplm013MosAjaxVO mosAjaxVO = Zplm013MosAjaxVO.builder()
				.vProductCd(reqDTO.getVTrPrdCd())
				.nVersion(reqDTO.getNVersion())
				.vTddProdType1Cd(reqDTO.getVTddProdType1Cd())
				.vTddProdType2Cd(reqDTO.getVTddProdType2Cd())
				.build();

		for (LabNoteTestReqContVO cvo : reqDTO.getContList()) {
			componentVO.setVContCd(StringUtils.defaultIfEmpty(cvo.getVContCd(), cvo.getVContPkCd()));
			mosAjaxVO.setVContCd(StringUtils.defaultIfEmpty(cvo.getVContCd(), cvo.getVContPkCd()));
			componentVO.setVLotCd(cvo.getVLotCd());
			componentVO.setVWerks(cvo.getVPlantCd());
			mosAjaxVO.setVWerks(cvo.getVPlantCd());

			//4자정보 저장할 때, contPkCd의 버전에 따라 가지고 오는 값이 달라지기 때문에
			//안전성 및 방부시험의뢰를 할 경우에는 해당하는 버전 값으로 셋팅
			//처방은 lotCd만 사용되기때문에 변경사항 없음
			componentVO.setNVersionTestReq(cvo.getNVersion());
			hbdCommonService.insertTrLabNoteComponent(componentVO);
		}

		//방부 시험의뢰와 연동
		testReqCommonMapper.insertLabNoteToMrqTestReqPreservative(reqDTO);

		//제품표시 연동
		String [] arrProdSign = reqDTO.getArrProdSignListCd();
		int prodLen = arrProdSign == null ? 0 : arrProdSign.length;
		if(prodLen > 0) {
			for(int i = 0; i < prodLen; i++) {
				testReqCommonMapper.insertProdSign(SupTrProdMarkDTO.builder()
						.vTrPrdCd(reqDTO.getVTrPrdCd())
						.nVersion(reqDTO.getNTrVersion())
						.nSeqno(i + 1)
						.vRegUserid(sessionUtil.getLoginId())
						.vProdSignCd(arrProdSign[i])
						.build());
			}
		}

		//방부처방 공통성분 등록
		testReqCommonService.insertLabNoteTrUpdateCmIngr(reqDTO.getVTrPrdCd(), reqDTO.getNVersion(), reqDTO.getDataPrsvList(), reqDTO.getVFlagTmt1());

		//카운터 등록
		List<TestReqCounterMrq011DTO> counterList = reqDTO.getCounterList();
		int counterLen = counterList == null ? 0 : counterList.size();

		if(counterLen > 0) {
			for(int i = 0; i < counterLen; i++) {
				TestReqCounterMrq011DTO counterVo = counterList.get(i);
				counterVo.setVProductCd(reqDTO.getVTrPrdCd());
				counterVo.setNVersion(reqDTO.getNTrVersion());
				counterVo.setNSeq(i + 1);
			}

			testReqCommonMapper.insertCounterMrq011(counterList);
		}
		// [e] MRQ011 방부 일때 로직

		hbdTestReqMapper.updateLabNoteMstFlagTestReq(reqDTO.getVLabNoteCd(), reqDTO.getVRegUserid());

		convertDTO = ConvertUtil.convert(reqDTO, LabNoteTestReqRegDTO.class);
		testReqCommonService.updateLabNoteProductTestRequest(convertDTO);

		if (StringUtils.isNotEmpty(reqDTO.getVTrComment().trim())) {
			testReqCommonMapper.insertMrqMessage(LabNoteTestReqRegDTO.builder()
					.vTrPrdCd(reqDTO.getVTrPrdCd())
					.nTrVersion(reqDTO.getNTrVersion())
					.vTrMrqTypeCd(reqDTO.getVTrMrqTypeCd())
					.vTrComment(reqDTO.getVTrComment())
					.vRegUserid(sessionUtil.getLoginId())
					.vUpdateUserid(sessionUtil.getLoginId())
					.build());
		}

		if("Y".equals(reqDTO.getVFlagModifyComment2()) && StringUtils.isNotEmpty(reqDTO.getVTrComment2())) {
			testReqCommonMapper.insertMrqMessage(LabNoteTestReqRegDTO.builder()
					.vTrPrdCd(reqDTO.getVTrPrdCd())
					.nTrVersion(reqDTO.getNTrVersion())
					.vTrMrqTypeCd(reqDTO.getVTrMrqTypeCd())
					.vTrComment(reqDTO.getVTrComment2())
					.vRegUserid(sessionUtil.getLoginId())
					.vUpdateUserid(sessionUtil.getLoginId())
					.build());

			testReqCommonService.savePrsvOpn(reqDTO);
		}

		// 미생물 시험의뢰 + 방부처방 의뢰일 경우에 방부 예측시스템으로 데이터 전송
		if("TMT_1".equals(reqDTO.getVTrTestTypeCd())) {
			testReqCommonMapper.insertSendPrsvPredictionSystem(SupTrComponentVO.builder()
					.vProductCd(reqDTO.getVTrPrdCd())
					.nVersion(reqDTO.getNTrVersion())
					.vContentCd(reqDTO.getVRepContCd())
					.build());
		}

//			if("success".equals(resultVo.getStatus())) {
			SupTrProductSimpleInfoVO simpleVo = testReqCommonMapper.selectSupTrProductSimpleInfo(reqDTO.getVTrPrdCd());
			resultVo.setObject(simpleVo);

			List<LabNoteTestReqContVO> contList = reqDTO.getContList();
			if (!ObjectUtils.isEmpty(contList)) {
				for (LabNoteTestReqContVO cvo : contList) {

					// 시험의뢰가 발생하면 해당 LOT 잠김 처리( 기존은 실험결과 등록 시 잠김 처리 to-be : 시험의뢰 발생 시 )
					// vFlagComplete가 값이 N일때만 아래 부분 적용
					hbdCommonService.updateLabNoteLotComplete(cvo.getVLotCd());
				}

				List<CodeDTO> labTestTypeList = commonService.selectCodeListMap(Arrays.asList("LAB_TEST_TYPE")).get("LAB_TEST_TYPE");
				LabNoteTestReqContVO repCont = contList.stream()
						.filter(cvo -> cvo.getVContPkCd().equals(reqDTO.getVRepContPkCd()))
						.findFirst()
						.get();

				StringBuilder contNmSb = new StringBuilder().append(repCont.getVContNm());

				if (contList.size() > 1) {
					contNmSb.append(String.format(" 외 %d건", contList.size() - 1));
				}

				//시험의뢰 알림
				commonService.sendAlarm(AlarmRegDTO.builder()
						.vLabNoteCd(reqDTO.getVLabNoteCd())
						.vStatusCd("AL_NOTE2")
						.vAlrTypeCd("AL_NOTE2_06")
						.typeList(Arrays.asList(Const.SCHEDULE, Const.TIMELINE))
						.vContCd(repCont.getVContCd())
						.vContNm(contNmSb.toString())
						.nVerNo(repCont.getNVersion() < 10 ? "0" + repCont.getNVersion() : Integer.toString(repCont.getNVersion()))
						.vLotNm(repCont.getVLotNm())
						.vExamNm(labTestTypeList.stream().filter(vo -> vo.getVSubCode().equals(reqDTO.getVTrMrqTypeCd())).findFirst().get().getVSubCodenm())
						.build());

				//right > status 탭 히스토리 쌓기
				commonService.insertLotStatusHistory(LotStatusRegDTO.builder()
						.vLabNoteCd(reqDTO.getVLabNoteCd())
						.nVersion(reqDTO.getNVersion())
						.vContPkCd(reqDTO.getVContPkCd())
						.vLotCd(reqDTO.getVRepLotCd())
						.vLabStatusCd(reqDTO.getVMrqTypeCd())
						.build());
			}
//			}

		responseVO.setOk(resultVo.getObject());
		return responseVO;
	}

	public ResponseVO selectLabNotePrdMrq011MailPop(@Valid LabNoteTestReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		if(StringUtils.isEmpty(reqDTO.getVLabNoteCd())
				|| StringUtils.isEmpty(reqDTO.getVLotCd())
				|| reqDTO.getNVersion() < 1
				) {
			responseVO.setOkWithCode("C9999", "잘못된 접근입니다.", null);
			return responseVO;
		}

		TestRequestMrq011MailDTO noteVo = hbdTestReqMapper.selectPrdMrq011RequestMailNoteInfo(reqDTO);

		if(noteVo == null) {
			responseVO.setOkWithCode("C9999", "잘못된 접근입니다.", null);
			return responseVO;
		}

		int rcvUsrLen = 0;
		List<GroupUserInfoDTO> rcvUsrList = null;

		if(StringUtils.isNotEmpty(noteVo.getVDeptCd())) {
			rcvUsrList = testReqCommonMapper.selectPrsvRcvMailUserList(noteVo.getVDeptCd());
			rcvUsrLen = rcvUsrList == null ? 0 : rcvUsrList.size();
		}

		if(rcvUsrLen == 0) {
			rcvUsrList = commonService.selectGroupUserList("S000292");
		}

		TestRequestMrq011MailResDTO resDTO = TestRequestMrq011MailResDTO.builder()
				.noteVo(noteVo)
				.rcvUsrList(rcvUsrList)
				.build();

		responseVO.setOk(resDTO);

		return responseVO;
	}

	public ResponseVO sendLabNotePrdMrq011Mail(TestRequestMrq011MailReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		String lotNm = "";
		if(StringUtils.isNotEmpty(reqDTO.getVLotCd())) {
			lotNm = hbdTestReqMapper.selectLotNm(reqDTO.getVLotCd());
		}

		MailForm mailForm = new MailForm();
		HashMap<String, String> params = new HashMap<>();

		params.put("vProductCd", reqDTO.getVProductCd());
		params.put("nVersion", String.valueOf(reqDTO.getNVersion()));
		params.put("vContCd", reqDTO.getVContCd());
		params.put("vContNm", reqDTO.getVContNm());
		params.put("vLotNm", lotNm);
		params.put("vMailContent", reqDTO.getVMailContent());
		params.put("vTrComment2", reqDTO.getVTrComment2());
		params.put("vFlagModifyComment2", reqDTO.getVFlagModifyComment2());

		String mailContent = mailForm.getMailContent(MailDTO.MAIL_MRQ011_ALARM, params);

		List<OrganizationDTO> referenceList = reqDTO.getReferenceList();
		int refCdLen = referenceList == null ? 0 : referenceList.size();
		if(refCdLen > 0) {
			List<String> rcvList = testReqCommonMapper.selectClsApprovalPrsvMailList(referenceList);
			int rcvLen = rcvList == null ? 0 : rcvList.size();

			if(rcvLen > 0) {
				StringBuffer toMailSb = new StringBuffer();

				for(int i = 0; i < rcvLen; i++) {
					toMailSb.append(rcvList.get(i));

					if(i != (rcvLen -1)) {
						toMailSb.append(",");
					}
				}

				MailUtil.send(toMailSb.toString(), null, reqDTO.getVMailTitle(), mailContent);
			}
		}

		responseVO.setOk(null);
		return responseVO;
	}
}
