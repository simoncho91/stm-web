package com.mybeaker.app.hbd.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class HbdNoteRateDTO {

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("vMatePkCd")
	private String vMatePkCd;

	@JsonProperty("nRate")
	private String nRate;

	@JsonProperty("vFlagRateRest")
	private String vFlagRateRest;

	@JsonProperty("vMateDbLotCd")
	private String vMateDbLotCd;
	
	@JsonProperty("vFlagSave")
	private String vFlagSave;
}
