package com.mybeaker.app.hbd.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class HbdNoteStabilityTitleVO {

	@JsonProperty("vLotCd")
	private String vLotCd;
	
	@JsonProperty("vStabilityCd")
	private String vStabilityCd;
}
