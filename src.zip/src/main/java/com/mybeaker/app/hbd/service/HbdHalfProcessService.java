package com.mybeaker.app.hbd.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mybeaker.app.approval.model.ApprovalDTO;
import com.mybeaker.app.approval.model.ApprovalDetailDTO;
import com.mybeaker.app.approval.model.ReferenceDTO;
import com.mybeaker.app.approval.model.ReqReferenceDTO;
import com.mybeaker.app.approval.model.ReqResApprovalDTO;
import com.mybeaker.app.common.model.AlarmRegDTO;
import com.mybeaker.app.common.model.ResultDTO;
import com.mybeaker.app.common.service.CommonService;
import com.mybeaker.app.hbd.mapper.HbdHalfProcessMapper;
import com.mybeaker.app.hbd.model.HbdNoteInfoDTO;
import com.mybeaker.app.hbd.model.HbdNoteLotDTO;
import com.mybeaker.app.hbd.model.HbdNoteLotVO;
import com.mybeaker.app.labnote.model.BomApprovalReqDTO;
import com.mybeaker.app.labnote.model.BomShelfLifeDTO;
import com.mybeaker.app.labnote.model.ElabBomLotVerVO;
import com.mybeaker.app.labnote.model.ElabShelflifeContVO;
import com.mybeaker.app.labnote.model.FormulaDecideResDTO;
import com.mybeaker.app.labnote.model.LabNoteContInfoVO;
import com.mybeaker.app.labnote.model.LabNoteLotDTO;
import com.mybeaker.app.labnote.model.LabNoteMstVersionDTO;
import com.mybeaker.app.labnote.model.LabNoteMstVersionPqcDTO;
import com.mybeaker.app.labnote.model.LabNotePqcGateCheckListDTO;
import com.mybeaker.app.labnote.model.LabNotePqcGateCheckReqDTO;
import com.mybeaker.app.labnote.model.LabNotePqcResItemListDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessContDecideListDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessContDecideReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessContDecideResDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessPqcCheckApprReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessProgressDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessReportPrdListReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessResDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessTabListDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessTimeLineDTO;
import com.mybeaker.app.labnote.model.LabNoteTestRequestProductDTO;
import com.mybeaker.app.labnote.model.LabNoteTestRequestProductReqDTO;
import com.mybeaker.app.labnote.model.LabNoteTestRequestProductResDTO;
import com.mybeaker.app.labnote.model.MusoguReqDTO;
import com.mybeaker.app.labnote.model.MusoguTagVO;
import com.mybeaker.app.labnote.model.PgcGqteResVO;
import com.mybeaker.app.labnote.model.PilotRequestDTO;
import com.mybeaker.app.labnote.model.PilotRequestDetailReqDTO;
import com.mybeaker.app.labnote.model.PilotRequestDetailResDTO;
import com.mybeaker.app.labnote.model.PilotRequestMateDTO;
import com.mybeaker.app.labnote.model.PilotRequestRegInfoReqDTO;
import com.mybeaker.app.labnote.model.PilotRequestRegInfoResDTO;
import com.mybeaker.app.labnote.model.PilotRequestReqDTO;
import com.mybeaker.app.labnote.model.PilotRequestResDTO;
import com.mybeaker.app.labnote.model.QmsResDTO;
import com.mybeaker.app.labnote.model.ShelfLifeVO;
import com.mybeaker.app.labnote.service.LabNoteCommonService;
import com.mybeaker.app.model.Const;
import com.mybeaker.app.model.dto.PagingDTO;
import com.mybeaker.app.model.dto.ResCommSearchInfoDTO;
import com.mybeaker.app.model.enums.ApprovalResultCode;
import com.mybeaker.app.model.enums.CommonResultCode;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.skincare.model.IngredientContVO;
import com.mybeaker.app.skincare.model.IngredientReqDTO;
import com.mybeaker.app.skincare.model.LotDecideRegDTO;
import com.mybeaker.app.skincare.model.LotPilotRegDTO;
import com.mybeaker.app.skincare.model.MateRateReqVO;
import com.mybeaker.app.skincare.model.PlantRatePriceReqVO;
import com.mybeaker.app.skincare.model.ScNoteLotDTO;
import com.mybeaker.app.skincare.model.SkincareDecideRegDTO;
import com.mybeaker.app.skincare.model.ValidateVO;
import com.mybeaker.app.skincare.model.VersionContVO;
import com.mybeaker.app.utils.CommonUtil;
import com.mybeaker.app.utils.ConvertUtil;
import com.mybeaker.app.utils.SessionUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class HbdHalfProcessService {
	private final HbdHalfProcessMapper hbdHalfProcessMapper;

	private final SessionUtil sessionUtil;

	private final CommonService commonService;

	private final HbdCommonService hbdCommonService;

	private final LabNoteCommonService labNoteCommonService;

	//프로그레스 바만 따로 호출하는 메소드
	public ResponseVO selectProgressBar(String vLabNoteCd) {
		ResponseVO responseVO = new ResponseVO();
		String activeTabStatus = "AL_NOTE1";
		LabNoteProcessResDTO resDTO = new LabNoteProcessResDTO();
		String vStatusCd = "";

		if(StringUtils.isEmpty(vLabNoteCd)) {
			responseVO.setOkWithCode(Const.FAIL, "필수 인자값이 없습니다", null);
			return responseVO;
		}

		HbdNoteInfoDTO noteInfoDTO = hbdCommonService.selectLabNoteInfo(vLabNoteCd);
		if(ObjectUtils.isEmpty(noteInfoDTO)) {
			responseVO.setOkWithCode(Const.FAIL, "실험노트 정보가 없습니다.", null);
			return responseVO;
		}

		vStatusCd = noteInfoDTO.getVStatusCd();

		//개발취소인 경우
		if("LNC06_41".equals(noteInfoDTO.getVStatusCd())) {
			resDTO.setVFlagCancel("Y");
			vStatusCd = hbdCommonService.selectLabNoteStatusCd(vLabNoteCd);		//취소하기 이전 상태를 확인함
		}

		activeTabStatus = hbdHalfProcessMapper.selectLabNoteActiveStatus(vStatusCd);
		int activeNum = Integer.parseInt(activeTabStatus.replaceAll("[^0-9]", ""));

		List<LabNoteProcessProgressDTO> progBar = hbdHalfProcessMapper.selectProgressInfo(vLabNoteCd);

		int size = progBar == null ? 0 : progBar.size();
		if(size > 0) {
			for(int i = 0; i < size; i++) {
				LabNoteProcessProgressDTO progVo = progBar.get(i);
				progVo.setVCurrStatMark("is-none");

				int progNum = Integer.parseInt(progVo.getVStatusCd().replaceAll("[^0-9]", ""));
				if(progNum < activeNum) {
					progVo.setVCurrStatMark("is-past");
				}
				if(activeTabStatus.equals(progVo.getVStatusCd())) {
					progVo.setVCurrStatMark("is-active");
				}
			}
		}

		resDTO.setProgressInfo(progBar);
		responseVO.setOk(resDTO);
		return responseVO;
	}

	public ResponseVO selectProgressInfo(String vLabNoteCd) {
		ResponseVO responseVO = new ResponseVO();
		String activeTabStatus = "AL_NOTE1";
		LabNoteProcessResDTO resDTO = new LabNoteProcessResDTO();
		List<LabNoteProcessTabListDTO> tabList = null;
		String vStatusCd = "";

		try {
			if(StringUtils.isEmpty(vLabNoteCd)) {
				responseVO.setOkWithCode(Const.FAIL, "필수 인자값이 없습니다.", null);
				return responseVO;
			}

			HbdNoteInfoDTO noteInfoDTO = hbdCommonService.selectLabNoteInfo(vLabNoteCd);
			if(ObjectUtils.isEmpty(noteInfoDTO)) {
				responseVO.setOkWithCode(Const.FAIL, "실험노트 정보가 없습니다.", null);
				return responseVO;
			}

			vStatusCd = noteInfoDTO.getVStatusCd();

			//개발취소인 경우
			if("LNC06_41".equals(noteInfoDTO.getVStatusCd())) {
				resDTO.setVFlagCancel("Y");
				vStatusCd = hbdCommonService.selectLabNoteStatusCd(vLabNoteCd);		//취소하기 이전 상태를 확인함
			}

			activeTabStatus = hbdHalfProcessMapper.selectLabNoteActiveStatus(vStatusCd);
			int activeNum = Integer.parseInt(activeTabStatus.replaceAll("[^0-9]", ""));

			List<LabNoteProcessProgressDTO> progBar = hbdHalfProcessMapper.selectProgressInfo(vLabNoteCd);
			int size = progBar == null ? 0 : progBar.size();

			if(size > 0) {
				for(int i = 0; i < size; i++) {
					LabNoteProcessProgressDTO progVo = progBar.get(i);
					progVo.setVCurrStatMark("is-none");

					int progNum = Integer.parseInt(progVo.getVStatusCd().replaceAll("[^0-9]", ""));
					if(progNum < activeNum) {
						progVo.setVCurrStatMark("is-past");
					}
					if(activeTabStatus.equals(progVo.getVStatusCd())) {
						progVo.setVCurrStatMark("is-active");
					}
				}

				activeTabStatus = this.getLabNoteActiveTabStatus(noteInfoDTO);

				LabNoteProcessReqDTO reqDTO = new LabNoteProcessReqDTO();
				reqDTO.setVActiveStatus(activeTabStatus);

				tabList = hbdHalfProcessMapper.selectProgressTabList(reqDTO);
			}

			resDTO.setProgressInfo(progBar);
			resDTO.setTabList(tabList);
		}catch(Exception e) {
			log.error("HbdProcessService.selectProgressInfo : {} " + e);
		}

		responseVO.setOk(resDTO);
		return responseVO;
	}

	private String getLabNoteActiveTabStatus(HbdNoteInfoDTO noteInfoDTO) {
		String activeTabStatus = "AL_NOTE1";

		//현재 상태가 LNC06_20 이상이면 실험중
		int statNum = Integer.parseInt(noteInfoDTO.getVStatusCd().substring(6));
		if(statNum > 20) {
			activeTabStatus = "AL_NOTE2";
		}

		//vFlagOpenBom이 Y 일 때, BOM(AL_NOTE2), PILOT(AL_NOTE3) 두 개 탭이 열린다.
		if(statNum >= 22) {
			activeTabStatus = "AL_NOTE3";
		}

		//파일럿 처방이 있을 때, 처방확정(AL_NOTE4) 탭이 열린다.
		if("Y".equals(noteInfoDTO.getVFlagPilotTest())) {
			activeTabStatus = "AL_NOTE4";
		}

		return activeTabStatus;
	}

	public ResponseVO selectTimeLineList(String vLabNoteCd) {
		ResponseVO responseVO = new ResponseVO();

		if(StringUtils.isEmpty(vLabNoteCd)) {
			responseVO.setOkWithCode(Const.FAIL, "필수 인자값이 없습니다", null);
			return responseVO;
		}

		List<LabNoteProcessTimeLineDTO> timeline = hbdHalfProcessMapper.selectTimeLineList(vLabNoteCd);

		responseVO.setOk(timeline);
		return responseVO;
	}

	public ResponseVO selectLabNoteBomReqList(PilotRequestReqDTO pilotRequestReqDTO) {
		ResponseVO responseVO = new ResponseVO();
		pilotRequestReqDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
		List<PilotRequestDTO> list = null;

		int totalCnt = hbdHalfProcessMapper.selectLabNoteBomReqListCount(pilotRequestReqDTO);
		CommonUtil.setPaging(pilotRequestReqDTO, totalCnt);
		if (totalCnt > 0) {
			list = hbdHalfProcessMapper.selectLabNoteBomReqList(pilotRequestReqDTO);
		}

		PagingDTO page = ConvertUtil.convert(pilotRequestReqDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
									.page(page)
									.list(list)
									.build();
		responseVO.setOk(res);
		return responseVO;
	}

	public ResponseVO selectLabNoteContDecideList(LabNoteProcessContDecideReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		HbdNoteInfoDTO rvo = hbdCommonService.selectLabNoteInfo(reqDTO.getVLabNoteCd());
		List<LabNoteMstVersionDTO> verList = hbdCommonService.selectLabNoteMstVerList(reqDTO.getVLabNoteCd());

		reqDTO.setLocalLanguage(sessionUtil.getLangCd());
		if( !(StringUtils.isNotEmpty(String.valueOf(reqDTO.getNVersion())) && reqDTO.getNVersion() != 0) ){
			reqDTO.setNVersion(rvo.getNMaxVersion());
		}

		List<LabNoteProcessContDecideListDTO> contList = hbdHalfProcessMapper.selectLabNoteContDecideList(reqDTO);

		LabNoteProcessContDecideResDTO<HbdNoteInfoDTO> resDTO = LabNoteProcessContDecideResDTO.<HbdNoteInfoDTO>builder()
				.rvo(rvo)
				.verList(verList)
				.contList(contList)
				.build();

		responseVO.setOk(resDTO);
		return responseVO;
	}

	public ResponseVO selectLabNoteGate2Reg(LabNoteProcessContDecideReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		LabNoteTestRequestProductResDTO<HbdNoteInfoDTO> resDTO = new LabNoteTestRequestProductResDTO<HbdNoteInfoDTO>();

		HbdNoteInfoDTO noteVo = hbdCommonService.selectLabNoteInfo(reqDTO.getVLabNoteCd());
		resDTO.setRvo(noteVo);

		//PQC GATE2
		LabNoteMstVersionPqcDTO verVo = hbdCommonService.selectLabNoteMstVerPqcInfo(reqDTO.getVLabNoteCd(), reqDTO.getNVersion());

		// 시험의뢰 목록
		LabNoteTestRequestProductReqDTO trDTO = LabNoteTestRequestProductReqDTO.builder()
				.vFlagExcelAll("Y")
				.localLanguage(sessionUtil.getLangCd())
				.vLabNoteCd(reqDTO.getVLabNoteCd())
				.build();

		List<LabNoteTestRequestProductDTO> trGate1List = new ArrayList<LabNoteTestRequestProductDTO>();
		List<LabNoteTestRequestProductDTO> trList = hbdCommonService.selectLabNoteTrProductList(trDTO);
		int trSize = trList == null ? 0 : trList.size();
		String key;

		if(trSize > 0) {
			Map<String, List<LabNoteTestRequestProductDTO>> trMap = new HashMap<String, List<LabNoteTestRequestProductDTO>>();
			List<LabNoteTestRequestProductDTO> subList = null;

			for(LabNoteTestRequestProductDTO tvo : trList) {

				key = tvo.getVLabMrqTypeCd();
				if(StringUtils.isNotEmpty(tvo.getVLabGateCd()) && tvo.getVLabGateCd().equals("GATE_1")) {
					trGate1List.add(tvo);
					continue;
				}

				subList = trMap.get(key);

				if(subList == null) {
					subList = new ArrayList<LabNoteTestRequestProductDTO>();
					trMap.put(key, subList);
				}

				subList.add(tvo);

			}
			resDTO.setTrMap(trMap);
		}

		resDTO.setVPqcGateCd("GATE_2");
		resDTO.setTrGate1List(trGate1List);

		LabNotePqcGateCheckReqDTO checkDTO = LabNotePqcGateCheckReqDTO.builder()
				.vNoteType(reqDTO.getVNoteType())
				.vLabNoteCd(reqDTO.getVLabNoteCd())
				.nVersion(reqDTO.getNVersion())
				.arrLotCd(reqDTO.getArrLotCd())
				.vPqcGateCd("GATE_2")
				.vPqcGate1ResCd(reqDTO.getVPqcGate1ResCd())
				.build();
		List<LabNotePqcGateCheckListDTO> pqcCheckList = this.selectPqcGateCheckList(checkDTO, noteVo, verVo, "REG");
		//~ PQC GATE2

		resDTO.setPqcList(pqcCheckList);

		List<ApprovalDetailDTO> userList = hbdCommonService.selectLabNoteApprovalUserList(checkDTO.getVLabNoteCd(), sessionUtil.getLangCd());

		resDTO.setUserList(userList);

		responseVO.setOk(resDTO);
		return responseVO;
	}

	public ResponseVO selectLabNotePilotList(PilotRequestReqDTO pilotRequestReqDTO) {
		ResponseVO responseVO = new ResponseVO();
		pilotRequestReqDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
		List<PilotRequestDTO> list = null;

		int totalCnt = hbdHalfProcessMapper.selectLabNoteBomReqListCount(pilotRequestReqDTO);
		CommonUtil.setPaging(pilotRequestReqDTO, totalCnt);
		if (totalCnt > 0) {
			list = hbdHalfProcessMapper.selectLabNoteBomReqList(pilotRequestReqDTO);
		}

		PagingDTO page = ConvertUtil.convert(pilotRequestReqDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
									.page(page)
									.list(list)
									.build();
		responseVO.setOk(res);
		return responseVO;
	}

	public ResponseVO selectLabNotePilotReqInfo(PilotRequestDetailReqDTO pilotRequestDetailReqDTO) {
		ResponseVO responseVO = new ResponseVO();

		HbdNoteInfoDTO noteInfo = hbdCommonService.selectLabNoteInfo(pilotRequestDetailReqDTO.getVLabNoteCd());

		List<PilotRequestDTO> lotList = hbdHalfProcessMapper.selectLabNoteApprBomLotList(pilotRequestDetailReqDTO);
		List<PilotRequestMateDTO> bomList = null;
		if (lotList != null && !lotList.isEmpty()) {
			bomList = this.selectLabNoteBomMateRateInfo(pilotRequestDetailReqDTO);
		}

		String flagFreePass = labNoteCommonService.checkFlagFreePass(pilotRequestDetailReqDTO);

		PgcGqteResVO pqcVO = labNoteCommonService.selectPqcGqteResInfo(pilotRequestDetailReqDTO.getVApprCd());
		LabNoteMstVersionPqcDTO versionPqcDTO = hbdCommonService.selectLabNoteMstVerPqcInfo(pilotRequestDetailReqDTO.getVLabNoteCd(), pilotRequestDetailReqDTO.getNVersion());

		List<LabNoteTestRequestProductDTO> trList = hbdCommonService.selectLabNoteTrProductList(LabNoteTestRequestProductReqDTO.builder()
															.vFlagExcelAll("Y")
															.localLanguage(sessionUtil.getLangCd())
															.vLabNoteCd(pilotRequestDetailReqDTO.getVLabNoteCd())
															.build());

		List<LabNoteTestRequestProductDTO> trFinalList = trList != null ? trList.stream().filter(v -> StringUtils.isNotEmpty(v.getVLabMrqTypeCd())).collect(Collectors.toList()) : null;
		Map<String, List<LabNoteTestRequestProductDTO>> trMap = trFinalList == null
															? new HashMap<>()
															: trFinalList.stream().collect(Collectors.groupingBy(LabNoteTestRequestProductDTO::getVLabMrqTypeCd));

		List<BomShelfLifeDTO> shelfLifeList = null;
		if(pqcVO != null && "Y".equals(pqcVO.getVShelflifeYn())) {
			shelfLifeList = hbdHalfProcessMapper.selectLabNoteShelfLifePqcList(pilotRequestDetailReqDTO.getVApprCd());
		}

		List<LabNotePqcGateCheckListDTO> pqcList = null;

		if (pqcVO != null && StringUtils.isNotEmpty(pqcVO.getVPqcResCd())) {
			pqcList = this.selectPqcGateResItemList(pqcVO.getVPqcResCd(), pilotRequestDetailReqDTO.getVLabNoteCd(), versionPqcDTO);
		}

		responseVO.setOk(PilotRequestResDTO.<HbdNoteInfoDTO>builder()
								.noteInfo(noteInfo)
								.lotList(lotList)
								.bomList(bomList)
								.flagFreePass(flagFreePass)
								.pqcVO(pqcVO)
								.versionPqcInfo(versionPqcDTO)
								.trMap(trMap)
								.shelfLifeList(shelfLifeList)
								.pqcList(pqcList)
								.build());
		return responseVO;
	}

	public List<PilotRequestMateDTO> selectLabNoteBomMateRateInfo(PilotRequestDetailReqDTO pilotRequestDetailReqDTO) {
		return hbdHalfProcessMapper.selectLabNoteBomMateRateInfo(pilotRequestDetailReqDTO);
	}

	public List<LabNotePqcGateCheckListDTO> selectPqcGateResItemList(String vPqcResCd, String vLabNoteCd, LabNoteMstVersionPqcDTO verVo) {
		List<LabNotePqcGateCheckListDTO> pqcList = labNoteCommonService.selectPqcGateResItemList(vPqcResCd);

		if (pqcList == null || pqcList.isEmpty()) {
			return null;
		}

		List<LabNotePqcGateCheckListDTO> list = new ArrayList<LabNotePqcGateCheckListDTO>();

		String itemTypeCd, chkText, chkValue, chkBeforeText, chkAfterText;
		String[] arrItemTypeCd = null, arrChkText = null, arrChkValue = null, arrChkBeforeText = null, arrChkAfterText = null;
		int chkLen = 0;

		for(LabNotePqcGateCheckListDTO tvo : pqcList) {
			itemTypeCd = tvo.getVItemTypeCd();

			if (itemTypeCd.indexOf("|") > -1) {
				arrItemTypeCd = itemTypeCd.split("\\|");
			}
			else {
				arrItemTypeCd = new String[] {itemTypeCd};
			}

			if (ArrayUtils.contains(arrItemTypeCd, "SAFETY_CT")) {

				int cnt = hbdHalfProcessMapper.selectSafetyCtCount(vLabNoteCd);
				if (cnt == 0) {
					continue;
				}
			} else if (ArrayUtils.contains(arrItemTypeCd, "CHOICE")) {
				chkText = tvo.getVChkText();
				chkValue = tvo.getVChkValue();
				chkBeforeText = tvo.getVChkBeforeText();
				chkAfterText = tvo.getVChkAfterText();

				if (StringUtils.isNotEmpty(chkText)) {
					if (chkText.indexOf("|") > -1) {
						arrChkText = chkText.split("\\|");
						chkLen = arrChkText.length;
					}
					else {
						arrChkText = new String[] {chkText};
					}
				}

				if (StringUtils.isNotEmpty(chkValue)) {
					if (chkValue.indexOf("|") > -1) {
						arrChkValue = chkValue.split("\\|");
					}
					else {
						arrChkValue = new String[] {chkValue};
					}
				}

				if (StringUtils.isNotEmpty(chkBeforeText)) {
					if (chkBeforeText.indexOf("|") > -1) {
						arrChkBeforeText = chkBeforeText.split("\\|", chkLen);
					}
					else {
						arrChkBeforeText = new String[] {chkBeforeText};
					}
				}

				if (StringUtils.isNotEmpty(chkAfterText)) {
					if (chkAfterText.indexOf("|") > -1) {
						arrChkAfterText = chkAfterText.split("\\|", chkLen);
					}
					else {
						arrChkAfterText = new String[] {chkAfterText};
					}
				}
				else {
					arrChkAfterText = null;
				}

				int txtLen = arrChkText == null ? 0 : arrChkText.length;
				int valLen = arrChkValue == null ? 0 : arrChkValue.length;

				if (txtLen > 0 && txtLen == valLen) {
					List<Map<String, Object>> cdList = new ArrayList<Map<String, Object>>();
					Map<String, Object> vo;

					for (int j = 0; j < txtLen; j++) {
						vo = new HashMap<String, Object>();
						cdList.add(vo);

						vo.put("v_text", arrChkText[j]);
						vo.put("v_val", arrChkValue[j]);

						if (ArrayUtils.contains(arrItemTypeCd, "G1_GQMS") && arrChkValue[j].equals("Y")) {

							vo.put("v_flag_chk_text", "Y");
						}else {
							if(arrChkBeforeText != null && StringUtils.isNotEmpty(arrChkBeforeText[j])) {
								vo.put("v_before_text", arrChkBeforeText[j]);
								vo.put("v_flag_chk_text", "Y");
							}

							if(arrChkAfterText != null && StringUtils.isNotEmpty(arrChkAfterText[j])) {
								vo.put("v_after_text", arrChkAfterText[j]);
								vo.put("v_flag_chk_text", "Y");
							}
						}
					}

					tvo.setCodeList(cdList);
					tvo.setCodeType(txtLen == 1 ? "checkbox" : "radio");
					tvo.setVFlagGateChoice("Y");
				}
			}

			//~ 게이트 준수 판단 checkbox | radio
			// 게이트 준수 텍스트 입력
			if (ArrayUtils.contains(arrItemTypeCd, "TEXT")) {
				tvo.setVFlagGateText("Y");
			}

			list.add(tvo);
		}

		return list;
	}

	/**
	 * Gate 자가체크 항목 가져오는 메소드
	 * @param checkDTO
	 * @param noteVo
	 * @param verVo
	 * @param actType
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "unused" })
	public List<LabNotePqcGateCheckListDTO> selectPqcGateCheckList(LabNotePqcGateCheckReqDTO checkDTO, HbdNoteInfoDTO noteVo,
			LabNoteMstVersionPqcDTO verVo, String actType) {

		String pqcCd = checkDTO.getVPqcCd();
		String gateCd = checkDTO.getVPqcGateCd();

		if(StringUtils.isEmpty(pqcCd)) {
			checkDTO.setVPqcType(checkDTO.getVNoteType());
			pqcCd = labNoteCommonService.selectApplyPqcCd(checkDTO);
			checkDTO.setVPqcCd(pqcCd);
		}

		if("GATE_2".equals(gateCd)) {

			MusoguReqDTO tagDTO = MusoguReqDTO.builder()
					.vLabNoteCd(checkDTO.getVLabNoteCd())
					.language(sessionUtil.getLangCd())
					.build();

			//영유아(LNC12_04), 어린이(LNC12_07) 선택한지 확인
			List<MusoguTagVO> lnc12List = hbdCommonService.selectLabNoteTagList(tagDTO, "LNC12", "CHOOSE", "NOTE", null, null);
			checkDTO.setVFlagG2Buffer3("N");
			for(MusoguTagVO lnc12Vo : lnc12List) {
				if("LNC12_04".equals(lnc12Vo.getVTag2Cd()) || "LNC12_07".equals(lnc12Vo.getVTag2Cd())) {
					checkDTO.setVFlagG2Buffer3("Y");
					break;
				}
			}
		}

		List<LabNotePqcGateCheckListDTO> pqcList = labNoteCommonService.selectPqcGateCheckList(checkDTO);

		int size = pqcList == null ? 0 : pqcList.size();
		if(size == 0) {
			return null;
		}

		List<LabNotePqcGateCheckListDTO> list = new ArrayList<LabNotePqcGateCheckListDTO>();
		Map<String, LabNotePqcResItemListDTO> map = null;

		if(!"SAVE".equals(actType)) {
			if(StringUtils.isEmpty(checkDTO.getVPqcResCd())) {
				// 등록일 경우 해당 실험노트 최근 입력건이 있으면 불러온다. // 수정 건일 경우는 해당 플래그 없음
				checkDTO.setFLAG_PQC_LAST_RES("Y");
			}

			List<LabNotePqcResItemListDTO> itemList = labNoteCommonService.selectElabPqcResItemList(checkDTO);
			map = itemList == null ? new HashMap<String, LabNotePqcResItemListDTO>()
					: itemList.stream().collect(Collectors.toMap(LabNotePqcResItemListDTO::getVKey, entity -> entity));
		}

		String itemTypeCd, chkText, chkValue, chkBeforeText, chkAfterText, chkCondDb, chkCondCol, pqcItemCd;
		String[] arrItemTypeCd = null, arrChkText = null, arrChkValue = null, arrChkBeforeText = null, arrChkAfterText = null;
		int chkLen = 0;

		ObjectMapper objectMapper = new ObjectMapper();
		Map<String, Object> afterNoteVo = objectMapper.convertValue(noteVo, Map.class);
		Map<String, Object> afterVerVo = objectMapper.convertValue(verVo, Map.class);

		String[] arrLotCd = checkDTO.getArrLotCd();
		HbdNoteLotVO lotVo = hbdCommonService.selectLabNoteLot(PlantRatePriceReqVO.builder()
								.vLotCd(arrLotCd[0])
								.language(sessionUtil.getLangCd())
								.build());

		for(LabNotePqcGateCheckListDTO tvo : pqcList) {
			pqcItemCd = tvo.getVPqcItemCd();
			itemTypeCd = tvo.getVItemTypeCd();
			chkCondDb = tvo.getVChkCondDb();
			chkCondCol = tvo.getVChkCondCol();


			if (StringUtils.isNotEmpty(chkCondDb) && StringUtils.isNotEmpty(chkCondCol)) {
				if (chkCondDb.equals("mst")) {
					if (!"Y".equals(afterNoteVo.get(CommonUtil.snakeCaseToCamelCase(chkCondCol)))) {
						continue;
					}
				}
				else if (chkCondDb.equals("ver")) {
					if (!"Y".equals(afterVerVo.get(CommonUtil.snakeCaseToCamelCase(chkCondCol)))) {
						continue;
					}
				}
			}


			if(map != null && map.get(pqcItemCd) != null) {

				LabNotePqcResItemListDTO valVo = map.get(pqcItemCd);

				if(valVo != null) {
					tvo.setVChoiceVal01(valVo.getVChoiceVal01());
					tvo.setVChoiceVal02(valVo.getVChoiceVal02());
					tvo.setVChoiceVal03(valVo.getVChoiceVal03());
					tvo.setVChoiceVal04(valVo.getVChoiceVal04());
					tvo.setVChoiceVal05(valVo.getVChoiceVal05());
					tvo.setVTextVal01(valVo.getVTextVal01());
					tvo.setVTextVal02(valVo.getVTextVal02());
					tvo.setVTextVal03(valVo.getVTextVal03());
					tvo.setVTextVal04(valVo.getVTextVal04());
					tvo.setVTextVal05(valVo.getVTextVal05());
					tvo.setVChoiceTextVal01(valVo.getVChoiceTextVal01());
					tvo.setVChoiceTextVal02(valVo.getVChoiceTextVal02());
					tvo.setVChoiceTextVal03(valVo.getVChoiceTextVal03());
					tvo.setVChoiceTextVal04(valVo.getVChoiceTextVal04());
					tvo.setVChoiceTextVal05(valVo.getVChoiceTextVal05());
					tvo.setVBufferVal01(valVo.getVBufferVal01());
					tvo.setVBufferVal02(valVo.getVBufferVal02());
					tvo.setVBufferVal03(valVo.getVBufferVal03());
					tvo.setVBufferVal04(valVo.getVBufferVal04());
					tvo.setVBufferVal05(valVo.getVBufferVal05());
				}
			}

			if (itemTypeCd.indexOf("|") > -1) {
				arrItemTypeCd = itemTypeCd.split("\\|");
			}
			else {
				arrItemTypeCd = new String[] {itemTypeCd};
			}

			if (ArrayUtils.contains(arrItemTypeCd, "SAFETY_CT")) {

				int cnt = hbdHalfProcessMapper.selectSafetyCtCount(checkDTO.getVLabNoteCd());
				if (cnt == 0) {
					continue;
				}
			} //~ 안전성 임상
			// T Cost
			else if (ArrayUtils.contains(arrItemTypeCd, "TCOST")) {
				double tcost = StringUtils.isNotEmpty(noteVo.getNTargetCost()) ? Double.parseDouble(noteVo.getNTargetCost()) : 0;
				int tgram = StringUtils.isNotEmpty(noteVo.getNCapacity()) ? Integer.parseInt(noteVo.getNCapacity()) : 0;
				StringBuffer detSb = new StringBuffer();
				if(tcost > 0 && tgram > 0) {
					checkDTO.setNTargetGram(tgram);

					List<HbdNoteLotDTO> tcList = hbdCommonService.selectElabTargetCostList(checkDTO.getArrLotCd(), checkDTO.getNTargetGram());
					int tcSize = tcList == null ? 0 : tcList.size();

					boolean isTcostClear = true;

					for (int j = 0; j < tcSize; j++) {

						if (j > 0) {
							detSb.append(", ");
						}

						HbdNoteLotDTO tcVo = tcList.get(j);
						if ( tcVo.getNPriceSum() > tcost ) {
							isTcostClear = false;
							detSb.append(tcVo.getVContCd()).append(" : 미준수(").append(tcVo.getNPriceSum()).append("원)");
						}
						else {
							detSb.append(tcVo.getVContCd()).append(" : 준수(").append(tcVo.getNPriceSum()).append("원)");
						}
					}

					tvo.setVChoiceVal01(isTcostClear ? "Y" : "N");
					tvo.setVGateBeforeHtml(detSb.toString());
				} else {
					tvo.setVChoiceVal01("Y");
					detSb.append("준수").append(tcost == 0 ? "(타켓 Cost 미설정)" : "(용량 미설정)");
					tvo.setVGateBeforeHtml(detSb.toString());
				}
			}//~ T Cost
			// 파일럿 정보
			else if (ArrayUtils.contains(arrItemTypeCd, "PILOT")) {
				if (verVo != null && StringUtils.isNotEmpty(verVo.getVPrePilotDt())) {
					tvo.setVGateBeforeHtml("선행 " + CommonUtil.getPointDate(verVo.getVPrePilotDt()));
				}else {
					tvo.setVGateBeforeHtml("일반 " + CommonUtil.getPointYYYYMM(noteVo.getVPilotDt(), "."));
				}
			}
			// 출시국가 법규 적합성 확인
			else if (ArrayUtils.contains(arrItemTypeCd, "GLB_BAN")) {

				int cnt = hbdHalfProcessMapper.selectElabGlobalBanCheck(checkDTO);
				tvo.setVChoiceVal01(cnt > 0 ? "N" : "Y");
			} //~ 출시국가 법규 적합성 확인
			//규격 입력
			else if (ArrayUtils.contains(arrItemTypeCd, "G2_GQMS")) {
				LabNotePqcResItemListDTO g1GqmsVo = labNoteCommonService.selectLabNoteG1gqmsInfo(checkDTO.getVPqcGate1ResCd());

				String bufVal01 = StringUtils.isNotEmpty(tvo.getVBufferVal01()) ? tvo.getVBufferVal01() : (g1GqmsVo != null ? g1GqmsVo.getVBufferVal01() : "");
				String bufVal02 = StringUtils.isNotEmpty(tvo.getVBufferVal02()) ? tvo.getVBufferVal02() : (g1GqmsVo != null ? g1GqmsVo.getVBufferVal02() : "");
				String bufVal03 = StringUtils.isNotEmpty(tvo.getVBufferVal03()) ? tvo.getVBufferVal03() : (g1GqmsVo != null ? g1GqmsVo.getVBufferVal03() : "");
				String bufVal04 = StringUtils.isNotEmpty(tvo.getVBufferVal04()) ? tvo.getVBufferVal04() : (g1GqmsVo != null ? g1GqmsVo.getVBufferVal04() : "");
				String bufVal05 = StringUtils.isNotEmpty(tvo.getVBufferVal05()) ? tvo.getVBufferVal05() : (g1GqmsVo != null ? g1GqmsVo.getVBufferVal05() : "");
				String bufVal06 = StringUtils.isNotEmpty(tvo.getVBufferVal06()) ? tvo.getVBufferVal06() : (g1GqmsVo != null ? g1GqmsVo.getVBufferVal06() : "");
				String bufVal07 = StringUtils.isNotEmpty(tvo.getVBufferVal07()) ? tvo.getVBufferVal07() : (g1GqmsVo != null ? g1GqmsVo.getVBufferVal07() : "");

				tvo.setVBufferVal01(bufVal01);
				tvo.setVBufferVal02(bufVal02);
				tvo.setVBufferVal03(bufVal03);
				tvo.setVBufferVal04(bufVal04);
				tvo.setVBufferVal05(bufVal05);
				tvo.setVBufferVal06(bufVal06);
				tvo.setVBufferVal07(bufVal07);
				tvo.setVG1BufferVal01(bufVal01);
				tvo.setVG1BufferVal02(bufVal02);
				tvo.setVG1BufferVal03(bufVal03);
				tvo.setVG1BufferVal04(bufVal04);
				tvo.setVG1BufferVal05(bufVal05);
				tvo.setVG1BufferVal06(bufVal06);
				tvo.setVG1BufferVal07(bufVal07);
			}
			//~ 규격입력
			// 게이트 준수 판단 checkbox | radio
			if (ArrayUtils.contains(arrItemTypeCd, "CHOICE")) {

				chkText = tvo.getVChkText();
				chkValue = tvo.getVChkValue();
				chkBeforeText = tvo.getVChkBeforeText();
				chkAfterText = tvo.getVChkAfterText();

				if (StringUtils.isNotEmpty(chkText)) {
					if (chkText.indexOf("|") > -1) {
						arrChkText = chkText.split("\\|");
						chkLen = arrChkText.length;
					}
					else {
						arrChkText = new String[] {chkText};
					}
				}

				if (StringUtils.isNotEmpty(chkValue)) {
					if (chkValue.indexOf("|") > -1) {
						arrChkValue = chkValue.split("\\|");
					}
					else {
						arrChkValue = new String[] {chkValue};
					}
				}

				if (StringUtils.isNotEmpty(chkBeforeText)) {
					if (chkBeforeText.indexOf("|") > -1) {
						arrChkBeforeText = chkBeforeText.split("\\|", chkLen);
					}
					else {
						arrChkBeforeText = new String[] {chkBeforeText};
					}
				}

				if (StringUtils.isNotEmpty(chkAfterText)) {
					if (chkAfterText.indexOf("|") > -1) {
						arrChkAfterText = chkAfterText.split("\\|", chkLen);
					}
					else {
						arrChkAfterText = new String[] {chkAfterText};
					}
				}
				else {
					arrChkAfterText = null;
				}

				int txtLen = arrChkText == null ? 0 : arrChkText.length;
				int valLen = arrChkValue == null ? 0 : arrChkValue.length;

				if (txtLen > 0 && txtLen == valLen) {
					List<Map<String, Object>> cdList = new ArrayList<Map<String, Object>>();
					Map<String, Object> vo;

					String bufVal01 = tvo.getVBufferVal01();
					String bufVal02 = tvo.getVBufferVal02();
					String bufVal03 = tvo.getVBufferVal03();
					String bufVal04 = tvo.getVBufferVal04();
					String bufVal05 = tvo.getVBufferVal05();

					int len = arrLotCd.length;

					bufVal01 = "";		//??
					bufVal02 = "";
					bufVal03 = "";
					bufVal04 = "";

					if(len == 1) {

						if(lotVo != null) {
							//점도
							if("MTI00_01".equals(lotVo.getVTestType())) {
								bufVal01 = lotVo.getVTestValue();
							}
							//경도
							else if("MTI00_02".equals(lotVo.getVTestType())) {
								bufVal02 = lotVo.getVTestValue();
							}
							//비중
							else if("MTI00_03".equals(lotVo.getVTestType())) {
								bufVal03 = lotVo.getVTestValue();
							}

							if(StringUtils.isNotEmpty(lotVo.getVTestType())){
								bufVal04 = lotVo.getVPh();
							}
						}
					}

					if (StringUtils.isEmpty(bufVal01)) {
						bufVal01 ="예시) 0000±0000, Spindle: 64번, 12rpm, 2min";
					}

					for (int j = 0; j < txtLen; j++) {
						vo = new HashMap<String, Object>();
						cdList.add(vo);

						vo.put("v_text", arrChkText[j]);
						vo.put("v_val", arrChkValue[j]);

						if (ArrayUtils.contains(arrItemTypeCd, "G1_GQMS") && arrChkValue[j].equals("Y")) {
							vo.put("v_flag_chk_text", "Y");
						}else {
							if(arrChkBeforeText != null && StringUtils.isNotEmpty(arrChkBeforeText[j])) {
								vo.put("v_before_text", arrChkBeforeText[j]);
								vo.put("v_flag_chk_text", "Y");
							}

							if(arrChkAfterText != null && StringUtils.isNotEmpty(arrChkAfterText[j])) {
								vo.put("v_after_text", arrChkAfterText[j]);
								vo.put("v_flag_chk_text", "Y");
							}
						}
					}

					tvo.setCodeList(cdList);
					tvo.setCodeType(txtLen == 1 ? "checkbox" : "radio");
					tvo.setVFlagGateChoice("Y");
				}
			}
			//~ 게이트 준수 판단 checkbox | radio
			// 게이트 준수 텍스트 입력
			if (ArrayUtils.contains(arrItemTypeCd, "TEXT")) {
				tvo.setVFlagGateText("Y");
			}

			list.add(tvo);
		}

		return list;
	}

	// PQC 목록 저장
	@Transactional
	public ResultDTO insertPqcGate(@Valid LabNoteProcessPqcCheckApprReqDTO reqDTO, HbdNoteInfoDTO noteVo,
			LabNoteMstVersionPqcDTO verVo) {

		ResultDTO resultDTO = new ResultDTO();
		try {
			LabNotePqcGateCheckReqDTO checkDTO = LabNotePqcGateCheckReqDTO.builder()
					.vNoteType(reqDTO.getVNoteType())
					.vLabNoteCd(reqDTO.getVLabNoteCd())
					.nVersion(reqDTO.getNVersion())
					.arrLotCd(reqDTO.getArrLotCd())
					.vPqcGateCd(reqDTO.getVPqcGateCd())
					.vPqcGate1ResCd(reqDTO.getVPqcGate1ResCd())
					.build();


			reqDTO.setVRegUserid(sessionUtil.getLoginId());
			reqDTO.setVUpdateUserid(sessionUtil.getLoginId());

			Map<String, LabNotePqcResItemListDTO> resItemMap = null;
			Map<String, PgcGqteResVO> resLotMap = null;

			PgcGqteResVO pqcResVo = null;

			if (StringUtils.isNotEmpty(reqDTO.getVApprCd())) {
				pqcResVo = labNoteCommonService.selectPqcGqteResInfo(reqDTO.getVApprCd());
			}

			if(pqcResVo != null) {
				reqDTO.setVPqcResCd(pqcResVo.getVPqcResCd());
				List<LabNotePqcResItemListDTO> resItemList = labNoteCommonService.selectElabPqcResItemList(checkDTO);
				resItemMap = resItemList == null ? new HashMap<String, LabNotePqcResItemListDTO>()
						: resItemList.stream().collect(Collectors.toMap(LabNotePqcResItemListDTO::getVKey, entity -> entity));

				List<PgcGqteResVO> resLotList = labNoteCommonService.selectElabPqcResLotList(reqDTO.getVPqcResCd());
				resLotMap = resLotList == null ? new HashMap<String, PgcGqteResVO>()
						: resLotList.stream().collect(Collectors.toMap(PgcGqteResVO::getVKey, entity -> entity));
			}
			else {
				labNoteCommonService.insertElabPqcRes(reqDTO);
			}

			double totalCnt = 0;
			double clearCnt = 0;
			String key;
			List<LabNotePqcGateCheckListDTO> pqcCheckList = reqDTO.getPqcCheckList();

			int size = pqcCheckList == null ? 0 : pqcCheckList.size();
			if(size == 0) {
				resultDTO.setStatus("fail");
				resultDTO.setMessage("자가체크 항목을 찾을 수 없습니다.");
				return resultDTO;
			}

			for(LabNotePqcGateCheckListDTO tvo : pqcCheckList) {

				String itemTypeCd = tvo.getVItemTypeCd();
				String itemClearValue = tvo.getVItemClearValue();
				String[] arrItemTypeCd;
				key = tvo.getVPqcItemCd();

				if(itemTypeCd.indexOf("|") > -1) {
					arrItemTypeCd = itemTypeCd.split("\\|");
				}else {
					arrItemTypeCd = new String[] {itemTypeCd};
				}

				if (ArrayUtils.contains(arrItemTypeCd, "PILOT")) {
					tvo.setVFlagObey("-");
				}
				else if (ArrayUtils.contains(arrItemTypeCd, "PAO")) {
					if (StringUtils.isNotEmpty(tvo.getVTextVal01()) && StringUtils.isNotEmpty(tvo.getVTextVal02()) ) {
						tvo.setVFlagObey("Y");
					}
					else {
						tvo.setVFlagObey("N");
					}
				}
				else {
					if (tvo.getVChoiceVal01().equals("PASS")) {
						tvo.setVFlagObey("P");
					}
					else if (tvo.getVChoiceVal01().equals(itemClearValue)) {
						tvo.setVFlagObey("Y");
					}
					else {
						tvo.setVFlagObey("N");
					}
				}

				tvo.setVRegUserid(sessionUtil.getLoginId());
				tvo.setVUpdateUserid(sessionUtil.getLoginId());

				if (resItemMap != null && resItemMap.get(key) != null) {
					tvo.setVPqcResItemCd(resItemMap.get(key).getVPqcResItemCd());
					labNoteCommonService.updateElabPqcResItem(tvo);
					resItemMap.remove(key);
				}
				else {
					tvo.setVPqcResCd(reqDTO.getVPqcResCd());
					labNoteCommonService.insertElabPqcResItem(tvo);
				}

				if(tvo.getVFlagObey().equals("Y")) {
					totalCnt++;
					clearCnt++;
				}else if(tvo.getVFlagObey().equals("N")) {
					totalCnt++;
				}
			}

			if(resItemMap != null) {
				Iterator<String> itr = resItemMap.keySet().iterator();

				while (itr.hasNext()) {
					key = (String)itr.next();

					LabNotePqcResItemListDTO itemDTO = LabNotePqcResItemListDTO.builder()
							.vPqcResItemCd(resItemMap.get(key).getVPqcResItemCd())
							.vPqcResCd("")
							.vUpdateUserid(sessionUtil.getLoginId())
							.build();

					labNoteCommonService.deleteElabPqcResItem(itemDTO);
				}
			}

			if(totalCnt > 0) {
				reqDTO.setNPqcObeyPer(Math.round((clearCnt / totalCnt * 100d) * 100d) / 100d);
			}else {
				reqDTO.setNPqcObeyPer(0);
			}

			labNoteCommonService.updateElabPqcRes(reqDTO);

			String[] arrContPkCd = reqDTO.getArrContPkCd();
			String[] arrLotCd = reqDTO.getArrLotCd();
			int len = arrContPkCd == null ? 0 : arrContPkCd.length;

			for(int i = 0; i < len; i++) {
				reqDTO.setVPqcContPkCd(arrContPkCd[i]);
				reqDTO.setVPqcLotCd(arrLotCd[i]);

				hbdHalfProcessMapper.updateLabContPqcRes(reqDTO);
				hbdHalfProcessMapper.updateLabContVerPqcRes(reqDTO);

				if (resLotMap != null && resLotMap.get(arrLotCd[i]) != null) {
					resLotMap.remove(arrLotCd[i]);
				}
				else {
					labNoteCommonService.insertElabPqcResLot(reqDTO);
				}
			}

		}catch(Exception e) {
			log.error("HbdProcessService.insertPqcGate : {}" + e);
		}

		resultDTO.setStatus("succ");
		resultDTO.setMessage("결재 승인 요청되었습니다.");
		return resultDTO;
	}

	public ResponseVO selectLabNotePilotRegInitInfo(PilotRequestReqDTO pilotRequestReqDTO) {
		ResponseVO responseVO = new ResponseVO();

		HbdNoteInfoDTO noteInfo = hbdCommonService.selectLabNoteInfo(pilotRequestReqDTO.getVLabNoteCd());
		List<LabNoteMstVersionDTO> verList = null;
		List<LabNoteContInfoVO> contList = null;
		Map<String, List<VersionContVO>> plantMap = null;
		Map<String, List<ScNoteLotDTO>> lotMap = null;
		List<ApprovalDetailDTO> userList = null;
		if (noteInfo != null) {
			verList = hbdCommonService.selectLabNoteMstVerList(pilotRequestReqDTO.getVLabNoteCd());
			contList = hbdCommonService.selectLabNoteContList(LabNoteContInfoVO.builder()
													.vLabNoteCd(pilotRequestReqDTO.getVLabNoteCd())
													.vCodeType("HAL4")
													.localLanguage(sessionUtil.getLocalLanguage())
													.build());

			int verSize = verList == null ? 0 : verList.size();
			int ver = verSize == 0 ? 1 : verList.get(verSize - 1).getNVersion();

			List<VersionContVO> plantList = hbdHalfProcessMapper.selectLabNoteContPlantAllList(pilotRequestReqDTO.getVLabNoteCd(), sessionUtil.getLocalLanguage());
			plantMap = plantList == null
								? new HashMap<>()
								: plantList.stream().collect(Collectors.groupingBy(VersionContVO::getVContPkCd));

			List<ScNoteLotDTO> lotList = hbdHalfProcessMapper.selectLabNoteContLotAllList(pilotRequestReqDTO.getVLabNoteCd(), ver);
			lotMap = lotList == null
							? new HashMap<>()
							: lotList.stream().collect(Collectors.groupingBy(ScNoteLotDTO::getVContPkCd));

			userList = hbdCommonService.selectLabNoteApprovalUserList(pilotRequestReqDTO.getVLabNoteCd(), sessionUtil.getLangCd());
		}

		responseVO.setOk(PilotRequestDetailResDTO.<HbdNoteInfoDTO, VersionContVO, ScNoteLotDTO>builder()
															.noteInfo(noteInfo)
															.verList(verList)
															.contList(contList)
															.plantMap(plantMap)
															.lotMap(lotMap)
															.userList(userList)
															.build());

		return responseVO;
	}

	public ResponseVO selectLabNotePilotRegVersionLotList (String vLabNoteCd, int nVersion) {
		ResponseVO responseVO = new ResponseVO();

		List<ScNoteLotDTO> lotList = hbdHalfProcessMapper.selectLabNoteContLotAllList(vLabNoteCd, nVersion);
		Map<String, List<ScNoteLotDTO>> lotMap = lotList == null
												? new HashMap<>()
												: lotList.stream().collect(Collectors.groupingBy(ScNoteLotDTO::getVContPkCd));

		responseVO.setOk(lotMap);
		return responseVO;
	}

	public ResponseVO selectLabNotePilotRegInfo(PilotRequestRegInfoReqDTO pilotRequestRegInfoReqDTO) {
		ResponseVO responseVO = new ResponseVO();
		HbdNoteInfoDTO noteInfo = hbdCommonService.selectLabNoteInfo(pilotRequestRegInfoReqDTO.getVLabNoteCd());

		LabNoteMstVersionPqcDTO versionPqcDTO = hbdCommonService.selectLabNoteMstVerPqcInfo(pilotRequestRegInfoReqDTO.getVLabNoteCd(), pilotRequestRegInfoReqDTO.getNVersion());

		List<LabNoteTestRequestProductDTO> trList = hbdCommonService.selectLabNoteTrProductList(LabNoteTestRequestProductReqDTO.builder()
																.vFlagExcelAll("Y")
																.localLanguage(sessionUtil.getLangCd())
																.vLabNoteCd(pilotRequestRegInfoReqDTO.getVLabNoteCd())
																.build());

		List<LabNoteTestRequestProductDTO> trFinalList = trList != null ? trList.stream().filter(v -> StringUtils.isNotEmpty(v.getVLabMrqTypeCd())).collect(Collectors.toList()) : null;
		Map<String, List<LabNoteTestRequestProductDTO>> trMap = trFinalList == null
															? new HashMap<>()
															: trFinalList.stream().collect(Collectors.groupingBy(LabNoteTestRequestProductDTO::getVLabMrqTypeCd));

		LabNotePqcGateCheckReqDTO checkDTO = LabNotePqcGateCheckReqDTO.builder()
													.vNoteType(pilotRequestRegInfoReqDTO.getVNoteType())
													.vLabNoteCd(pilotRequestRegInfoReqDTO.getVLabNoteCd())
													.nVersion(pilotRequestRegInfoReqDTO.getNVersion())
													.arrLotCd(pilotRequestRegInfoReqDTO.getArrLotCd())
													.vPqcGateCd("GATE_1")
													.build();
		List<LabNotePqcGateCheckListDTO> pqcCheckList = this.selectPqcGateCheckList(checkDTO, noteInfo, versionPqcDTO, "REG");

		List<ShelfLifeVO> shelfLifeContInfoList = labNoteCommonService.selectOneShelfLifeContInfo(ShelfLifeVO.builder()
															 .language(sessionUtil.getLocalLanguage())
															 .contCdList(Arrays.asList(pilotRequestRegInfoReqDTO.getArrContCd()))
															 .build());

		Map<String, ShelfLifeVO> shelfContMap = shelfLifeContInfoList == null
											? new HashMap<>()
											: shelfLifeContInfoList.stream().collect(Collectors.toMap(ShelfLifeVO::getVContCd, entity -> entity));

		List<ShelfLifeVO> shelfLifeList = new ArrayList<ShelfLifeVO>();
		ShelfLifeVO shelfLifeVO = null;
		String[] arrContCd = pilotRequestRegInfoReqDTO.getArrContCd();
		String[] arrPlantCd = pilotRequestRegInfoReqDTO.getArrPlantCd();

		if (arrContCd != null && arrContCd.length > 0) {
			for (int i=0; i < arrContCd.length; i++) {
				shelfLifeVO = ShelfLifeVO.builder()
								.vContCd(arrContCd[i])
								.vPlantCd(arrPlantCd[i])
								.vShelfLife(shelfContMap.get(arrContCd[i]) == null ? "" : shelfContMap.get(arrContCd[i]).getVShelfLife())
								.vFlagLife(shelfContMap.get(arrContCd[i]) == null || StringUtils.isEmpty(shelfContMap.get(arrContCd[i]).getVShelfLife()) ? "N" : "Y")
								.build();

				shelfLifeList.add(shelfLifeVO);
			}
		}

		responseVO.setOk(PilotRequestRegInfoResDTO.builder()
								.versionPqcInfo(versionPqcDTO)
								.trMap(trMap)
								.pqcList(pqcCheckList)
								.shelfLifeList(shelfLifeList)
								.bomList(hbdCommonService.selectLabNoteMateInfo(ConvertUtil.convert(pilotRequestRegInfoReqDTO, MateRateReqVO.class)))
								.build());
		return responseVO;
	}

	public ResponseVO selectLabNoteBomSendList(PilotRequestReqDTO pilotRequestReqDTO) {
		ResponseVO responseVO = new ResponseVO();
		List<PilotRequestDTO> list = null;

		int totalCnt = hbdHalfProcessMapper.selectLabNoteBomSendListCount(pilotRequestReqDTO);
		CommonUtil.setPaging(pilotRequestReqDTO, totalCnt);
		if (totalCnt > 0) {
			list = hbdHalfProcessMapper.selectLabNoteBomSendList(pilotRequestReqDTO);
		}

		PagingDTO page = ConvertUtil.convert(pilotRequestReqDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
									.page(page)
									.list(list)
									.build();
		responseVO.setOk(res);
		return responseVO;
	}

	@Transactional
	public ResponseVO saveLabNoteGate01(LabNoteProcessPqcCheckApprReqDTO params) {
		ResponseVO responseVO = new ResponseVO();

		String apprTitle = hbdCommonService.selectElabApprTitleNm(params);
		String apprCd = commonService.handlingOfApprovalEp("APS030", "[마이비커]" + apprTitle, params.getApprReqInfo());

		commonService.insertReference(ReqReferenceDTO.builder()
											.vRecordid(apprCd)
											.referenceList(params.getReferenceList())
											.build());

		if (StringUtils.isNotEmpty(params.getVLabNoteCd())) {
			params.setVRegUserid(sessionUtil.getLoginId());
			params.setVUpdateUserid(sessionUtil.getLoginId());
			params.setVApprCd(apprCd);

			if (params.getArrLotCd() != null && params.getArrLotCd().length > 0) {
				hbdHalfProcessMapper.insertLabNoteApprBomInfo(params);
				hbdHalfProcessMapper.updateLabNoteLotApprCd(params);

				for (String lotCd : params.getArrLotCd()) {
					hbdCommonService.updateLabNoteLotComplete(lotCd);
					labNoteCommonService.insertElabBomLotVer(ElabBomLotVerVO.builder()
																.vLabNoteCd(params.getVLabNoteCd())
																.vLotCd(lotCd)
																.vBomType("NORMAL")
																.vTempPkCd(apprCd)
																.vRegUserid(sessionUtil.getLoginId())
																.vUpdateUserid(sessionUtil.getLoginId())
																.build());
				}
			}

			params.setVPqcGateCd("GATE_1");
			HbdNoteInfoDTO noteVo = hbdCommonService.selectLabNoteInfo(params.getVLabNoteCd());
			LabNoteMstVersionPqcDTO verVo = hbdCommonService.selectLabNoteMstVerPqcInfo(params.getVLabNoteCd(), params.getNVersion());

			this.insertPqcGate(params, noteVo, verVo);

			int result = hbdCommonService.updateNoteStatusCd(params.getVLabNoteCd(), "LNC06_23");

			String pageUrl = new StringBuilder()
									.append("/hbd/all-lab-note-half-process?vLabNoteCd=")
									.append(params.getVLabNoteCd())
									.append("&vTabId=pilot")
									.append("&vApprCd=")
									.append(apprCd)
									.toString();

			commonService.updateSkyApprovalAprvDtlUrl(apprCd, pageUrl);

			ReqResApprovalDTO apprDTO = params.getApprReqInfo();
			List<ApprovalDetailDTO> apprUserListTemp = apprDTO != null ? apprDTO.getApprList() : null;
			List<String> apprUserList = apprUserListTemp != null
										? apprUserListTemp.stream().map(v -> v.getVApprUserid()).collect(Collectors.toList())
										: null;

			commonService.sendAlarm(AlarmRegDTO.builder()
										.vLabNoteCd(params.getVLabNoteCd())
										.vStatusCd("AL_NOTE3")
										.vAlrTypeCd("AL_NOTE3_04")
										.typeList(Arrays.asList(Const.ALARM, Const.MAIL, Const.TIMELINE))
										.vContCd(params.getVContCd())
										.vContNm(params.getVContNm())
										.nVerNo(params.getNVersion() < 10 ? "0" + params.getNVersion() : "" + params.getNVersion())
										.vLotNm(params.getVLotNm())
										.vNoteType("HBO")
										.userList(apprUserList)
										.vMoveUrl(pageUrl)
										.build());

			commonService.sendMailApproval(ApprovalDTO.builder()
								.vApprCd(apprCd)
								.vUrl(pageUrl)
								.vResultStatus(ApprovalResultCode.APPR_REQUEST.getCode())
								.build());

			commonService.sendMailReference(ReferenceDTO.builder()
								.vTitle(String.format("%s%s", "[참조메일]결재의뢰-", apprTitle))
								.vUrl(pageUrl)
								.build());
			if (result > 0) {
				if (params.getShelfLifeList() != null && !params.getShelfLifeList().isEmpty()) {
					labNoteCommonService.checkPQCShelfLife(apprCd);
					for (ElabShelflifeContVO shelfVO : params.getShelfLifeList()) {
						if ("ETC".equals(shelfVO.getVShelfLife())) {
							shelfVO.setVShelfLife(shelfVO.getVEtcLife());
						}

						shelfVO.setVStatusCd("SLS010");
						shelfVO.setVContType("HAL4");
						shelfVO.setVNoteType("MU");

						labNoteCommonService.insertShelfLifeInfoCont(shelfVO);

						List<LabNoteContInfoVO> checkSubList = hbdCommonService.checkSubPlantList(params.getVLabNoteCd(), shelfVO.getVContCd());

						if (checkSubList != null && !checkSubList.isEmpty()) {
							labNoteCommonService.updateSubPlantFlag(shelfVO.getVContCd());
							labNoteCommonService.deleteShelfLifeSubPlant(shelfVO.getVContCd());

							for (LabNoteContInfoVO checkSub : checkSubList) {
								if (!checkSub.getVPlantCd().equals(shelfVO.getVPlantCd())) {
									labNoteCommonService.insertShelfLifeSubPlant(checkSub.getVContCd(), checkSub.getVPlantCd());
								}
							}
						}
					}
				}

				responseVO.setCreateOk(null);
			} else {
				responseVO.setOkWithCode("C9999", CommonResultCode.SAVE_FAIL, null);
			}
		} else {
			responseVO.setOkWithCode("C9999", CommonResultCode.SAVE_FAIL, null);
		}

		return responseVO;
	}

	public ResponseVO selectHal4FormulaDecideList(PilotRequestReqDTO pilotRequestReqDTO) {
		ResponseVO responseVO = new ResponseVO();

		HbdNoteInfoDTO noteInfo = hbdCommonService.selectLabNoteInfo(pilotRequestReqDTO.getVLabNoteCd());

		if (noteInfo != null) {
			List<PilotRequestDTO> list = hbdHalfProcessMapper.selectHal4FormulaDecideList(pilotRequestReqDTO);


			FormulaDecideResDTO<HbdNoteInfoDTO> res = FormulaDecideResDTO.<HbdNoteInfoDTO>builder()
										.list(list)
										.noteInfo(noteInfo)
										.verList(hbdCommonService.selectLabNoteMstVerList(pilotRequestReqDTO.getVLabNoteCd()))
										.contList(hbdCommonService.selectLabNoteContList(LabNoteContInfoVO.builder()
																			.vLabNoteCd(pilotRequestReqDTO.getVLabNoteCd())
																			.vCodeType(noteInfo.getVCodeType())
																			.localLanguage(sessionUtil.getLocalLanguage())
																			.build()))
										.verList(hbdCommonService.selectLabNoteMstVerList(pilotRequestReqDTO.getVLabNoteCd()))
										.build();
			responseVO.setOk(res);
		} else {
			responseVO.setOkWithCode("C9999", CommonResultCode.NO_DATA, null);
		}


		return responseVO;
	}

	/**
	 * HBO 에서만 사용함
	 * @param reqDTO
	 * @return
	 */
	public ResponseVO selectEvReportProdListPop(LabNoteProcessReportPrdListReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		//AS-IS : supo_ev_report_prod_list_pop 메소드
		//프로세스에서는 vLabNoteCd 있는 경우만 사용함, 해당 로직만 가져오기 => 나머지 로직은 심사 보고서 로직이라 옮겨오지 않음
		List<IngredientContVO> contList = hbdCommonService.selectLabContList(IngredientReqDTO.builder()
				.vLabNoteCd(reqDTO.getVLabNoteCd())
				.nVersion(reqDTO.getNVersion())
				.localLanguage(sessionUtil.getLocalLanguage())
				.build());

		responseVO.setOk(contList);
		return responseVO;
	}

	@Transactional
	public ResponseVO sendBomFreePass(BomApprovalReqDTO bomApprovalReqDTO) {
		ResponseVO responseVO = new ResponseVO();

		int result = hbdCommonService.updateAcceptApprovalRequest(bomApprovalReqDTO);

		if (result > 0) {
			responseVO.setCreateOk(null);
		} else {
			responseVO.setOkWithCode("C9999", CommonResultCode.SAVE_FAIL, null);
		}

		return responseVO;
	}

	public ResponseVO selectQmsInfo(String vLabNoteCd) {
		ResponseVO responseVO = new ResponseVO();

		LabNoteContInfoVO contInfoVO = LabNoteContInfoVO.builder()
											.vLabNoteCd(vLabNoteCd)
											.vCodeType("HAL4")
											.localLanguage(sessionUtil.getLocalLanguage())
											.build();

		List<LabNoteContInfoVO> contList = hbdCommonService.selectLabNoteContList(contInfoVO);
		List<LabNoteContInfoVO> plantList = null;
		if (contList != null && !contList.isEmpty()) {
			contInfoVO.setVContCd(contList.get(0).getVContCd());

			plantList = hbdCommonService.selectLabNotePlantList(contInfoVO);
		}

		responseVO.setOk(QmsResDTO.builder()
								.contList(contList)
								.plantList(plantList)
								.build());

		return responseVO;
	}

	public ResponseVO selectQmsPlantList(String vLabNoteCd, String vContCd) {
		ResponseVO responseVO = new ResponseVO();

		List<LabNoteContInfoVO> plantList = hbdCommonService.selectLabNotePlantList(LabNoteContInfoVO.builder()
																							.vLabNoteCd(vLabNoteCd)
																							.vContCd(vContCd)
																							.vCodeType("HAL4")
																							.localLanguage(sessionUtil.getLocalLanguage())
																							.build());
		responseVO.setOk(plantList);
		return responseVO;
	}

	public ResponseVO checkValidationPilot(LotPilotRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();

		List<String> resNotExists = new ArrayList<>();
		List<String> resUnusableMate = new ArrayList<>();
		List<String> resBanMate = new ArrayList<>();
		List<String> resTempMate = new ArrayList<>();
		List<String> resSumRate = new ArrayList<>();

		ValidateVO reqVO = ValidateVO.builder()
								.nVersion(regDTO.getNVersion())
								.vLand1("UN")
								.build();
		List<LabNoteLotDTO> lotList = regDTO.getLotList();
		if (lotList != null && !lotList.isEmpty()) {
			for (LabNoteLotDTO lotDTO : lotList) {
				reqVO.setVContPkCd(lotDTO.getVContPkCd());
				reqVO.setVLotCd(lotDTO.getVLotCd());

				ValidateVO vo = hbdCommonService.selectLabNoteValidate(reqVO);

				if(vo.getNCntNotExistsMate() > 0) {
					resNotExists.add(vo.getVLotNm());
				}
				else if(vo.getNCntUnusableMate() > 0) {
					resUnusableMate.add(vo.getVLotNm());
				}
				else if(vo.getNCntBanMate() > 0) {
					resBanMate.add(vo.getVLotNm());
				}
				else if(vo.getNCntTempMate() > 0) {
					resTempMate.add(vo.getVLotNm());
				}
				else if(vo.getNSumRate() != 100) {
					resSumRate.add(vo.getVLotNm());
				}
			}
		}

		StringBuilder resBuilder = new StringBuilder();
		if (resNotExists != null && resNotExists.size() > 0) {
			resBuilder.append("해당 플랜트에 없는 원료가 존재합니다.<br>");
			resBuilder.append(String.join("<br>", resNotExists));
			resBuilder.append("<br><br>");
		}

		if (resUnusableMate != null && resUnusableMate.size() > 0) {
			resBuilder.append("해당 처방에 단종된 원료가 존재합니다.<br>");
			resBuilder.append(String.join("<br>", resUnusableMate));
			resBuilder.append("<br><br>");
		}

		if (resBanMate != null && resBanMate.size() > 0) {
			resBuilder.append("해당 처방에 금지원료가 존재합니다.<br>");
			resBuilder.append(String.join("<br>", resBanMate));
			resBuilder.append("<br><br>");
		}

		if (resTempMate != null && resTempMate.size() > 0) {
			resBuilder.append("해당 처방에 임시원료가 존재합니다.<br>");
			resBuilder.append(String.join("<br>", resTempMate));
			resBuilder.append("<br><br>");
		}

		if (resSumRate != null && resSumRate.size() > 0) {
			resBuilder.append("원료 배합 합이 100이 아닙니다.<br>");
			resBuilder.append(String.join("<br>", resSumRate));
			resBuilder.append("<br><br>");
		}

		responseVO.setOk(StringUtils.isNotEmpty(resBuilder.toString()) ? resBuilder.toString() : "SUCC");
		return responseVO;
	}

	@Transactional
	public ResponseVO savePrescribeConfirm (SkincareDecideRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();

		LotDecideRegDTO lotDecideRegDTO = ConvertUtil.convert(regDTO, LotDecideRegDTO.class);

		String result = hbdCommonService.updateLabNoteLotDecide(lotDecideRegDTO);

		if ("SUCC".equals(result)) {
			hbdCommonService.updateNoteMstNoiValue(regDTO.getVContPkCd(), regDTO.getNVersion(), true);
			String pageUrl = new StringBuilder()
					.append("/hbd/all-lab-note-half-process?vLabNoteCd=").append(regDTO.getVLabNoteCd())
					.append("&vTabId=confirm")
					.toString();

			HbdNoteInfoDTO noteVo = hbdCommonService.selectLabNoteInfo(regDTO.getVLabNoteCd());

			commonService.sendAlarm(AlarmRegDTO.builder()
										.vLabNoteCd(regDTO.getVLabNoteCd())
										.vStatusCd("AL_NOTE4")
										.vAlrTypeCd("AL_NOTE4_01")
										.typeList(Arrays.asList(Const.ALARM, Const.SCHEDULE, Const.TIMELINE))
										.vContCd(regDTO.getVContCd())
										.vContNm(regDTO.getVContNm())
										.nVerNo((regDTO.getNVersion() < 10 ? "0" : "") + String.valueOf(regDTO.getNVersion()))
										.vLotNm(regDTO.getVLotNm())
										.vNoteType("HBO")
										// 연구담당자, 랩장
										.userList(Arrays.asList(noteVo.getVUserid(),
																commonService.selectLabLeaderid(noteVo.getVDeptCd())))

										.vMoveUrl(pageUrl)
										.build());
			responseVO.setCreateOk(null);
		} else {
			responseVO.setOkWithCode(Const.FAIL, "", null);
		}

		return responseVO;
	}

	public ResponseVO selectGate1ApprDetailInfo(String vLabNoteCd, String vApprCd) {
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(hbdHalfProcessMapper.selectGate1ApprDetailInfo(vLabNoteCd, vApprCd));
		return responseVO;
	}
	
	public ResponseVO selectLabNoteBomMateView(PilotRequestDetailReqDTO pilotRequestDetailReqDTO) {
		ResponseVO responseVO = new ResponseVO();
		
		List<PilotRequestDTO> lotList = hbdHalfProcessMapper.selectLabNoteApprBomLotList(pilotRequestDetailReqDTO);
		List<PilotRequestMateDTO> bomList = null;
		if (lotList != null && !lotList.isEmpty()) {
			bomList = this.selectLabNoteBomMateRateInfo(pilotRequestDetailReqDTO);
		}
		
		responseVO.setOk(PilotRequestResDTO.<HbdNoteInfoDTO>builder()
				.lotList(lotList)
				.bomList(bomList)
				.build());
		
		return responseVO;
	}
}
