package com.mybeaker.app.hbd.controller;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mybeaker.app.hbd.model.HbdAerosolDecideReqDTO;
import com.mybeaker.app.hbd.service.HbdProcessService;
import com.mybeaker.app.labnote.model.PilotRequestReqDTO;
import com.mybeaker.app.labnote.model.BomApprovalReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessContDecideReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReportReqPopDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReportReqSaveDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReportUserReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncRequestQADTO;
import com.mybeaker.app.labnote.model.LabNoteProcessIngrdApprRegDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessIngrdApprReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessPqcCheckApprReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessReportPrdListReqDTO;
import com.mybeaker.app.labnote.model.PilotRequestDetailReqDTO;
import com.mybeaker.app.labnote.model.PilotRequestRegInfoReqDTO;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.skincare.model.LotPilotRegDTO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Tag(name = "실험노트 프로세스", description="실험노트 프로세스")
@RestController
@RequestMapping("/api/hbd/process")
@RequiredArgsConstructor
public class HbdProcessController {
	private final HbdProcessService hbdProcessService;

	@Operation(summary = "실험노트의 현재 상태 및 개발프로세스 Bar", description = "프로세스 Bar 가져오기")
	@GetMapping("/select-progress-bar")
	public @ResponseBody ResponseEntity<ResponseVO> selectProgressBar (@RequestParam("vLabNoteCd") String vLabNoteCd) {

		log.debug("HbdProcessController.selectProgressBar");
		return ResponseEntity.ok(hbdProcessService.selectProgressBar(vLabNoteCd));
	}

	@Operation(summary = "실험노트의 현재 상태 및 개발프로세스 내용 가져오기", description = "프로세스 기본 정보 가져오기")
	@GetMapping("/select-progress-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectProgressInfo (@RequestParam("vLabNoteCd") String vLabNoteCd) {
		log.debug("HbdProcessController.selectProgressInfo");
		return ResponseEntity.ok(hbdProcessService.selectProgressInfo(vLabNoteCd));
	}

	@Operation(summary = "TIME LINE 탭 알림 목록 가져오기", description = "TIME LINE")
	@GetMapping("/select-timeline-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectTimeLineList (@RequestParam("vLabNoteCd") String vLabNoteCd) {

		log.debug("HbdProcessController.selectTimeLineList");
		return ResponseEntity.ok(hbdProcessService.selectTimeLineList(vLabNoteCd));
	}

	@Operation(summary = "BOM 요청 목록", description = "실험중 > BOM 요청 목록을 조회한다.")
	@GetMapping("/select-lab-note-bom-req-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteBomReqList (
			PilotRequestReqDTO pilotRequestReqDTO
			) {
		log.debug("SkincareProcessTempController.selectLabNoteBomReqList => pilotRequestReqDTO : {}", pilotRequestReqDTO);
		return ResponseEntity.ok(hbdProcessService.selectLabNoteBomReqList(pilotRequestReqDTO));
	}

	@Operation(summary = "전성분 승인 목록 가져오기", description = "전성분 승인 > 리스트")
	@GetMapping("/select-ingrd-approval-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectIngrdApprovalList (@Valid LabNoteProcessIngrdApprReqDTO reqDTO) {

		log.debug("HbdProcessController.selectIngrdApprovalList");
		return ResponseEntity.ok(hbdProcessService.selectIngrdApprovalList(reqDTO));
	}

	@Operation(summary = "전성분 승인에 필요한 정보 가져오기", description = "전성분 승인 > 등록")
	@GetMapping("/select-ingrd-approval-required-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectIngrdApprovalRegRequiredInfo (@Valid LabNoteProcessIngrdApprReqDTO reqDTO) {

		log.debug("HbdProcessController.selectIngrdApprovalRegRequiredInfo");
		return ResponseEntity.ok(hbdProcessService.selectIngrdApprovalRegRequiredInfo(reqDTO));
	}

	@Operation(summary = "알러젠 표기/미표기 비교 정보 가져오기", description = "전성분 승인 > 등록")
	@GetMapping("/select-ingrd-compare-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectIngrdCompareInfo (LabNoteProcessIngrdApprReqDTO reqDTO) {

		log.debug("HbdProcessController.selectIngrdCompareInfo");
		return ResponseEntity.ok(hbdProcessService.selectIngrdCompareInfo(reqDTO));
	}

	@Operation(summary = "전성분 승인", description = "전성분 승인 > 등록")
	@PostMapping("/insert-ingrd-approval")
	public @ResponseBody ResponseEntity<ResponseVO> insertIngrdApproval (@RequestBody @Valid LabNoteProcessIngrdApprRegDTO regDTO) {

		log.debug("HbdProcessController.insertIngrdApproval");
		return ResponseEntity.ok(hbdProcessService.insertIngrdApproval(regDTO));
	}

	@Operation(summary = "전성분 승인 정보 가져오기", description = "전성분 승인 > 상세")
	@GetMapping("/select-ingrd-approval-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectIngrdApprovalInfo (LabNoteProcessIngrdApprReqDTO reqDTO) {

		log.debug("HbdProcessController.selectIngrdApprovalInfo");
		return ResponseEntity.ok(hbdProcessService.selectIngrdApprovalInfo(reqDTO));
	}

	@Operation(summary = "확정제품명 목록 가져오기", description = "기능성허가 > 확정제품명")
	@GetMapping("/select-func-decide-name-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteFuncDecideNameList (LabNoteProcessFuncReqDTO reqDTO) {

		log.debug("HbdProcessController.selectLabNoteFuncDecideNameList");
		return ResponseEntity.ok(hbdProcessService.selectLabNoteFuncDecideNameList(reqDTO));
	}

	@Operation(summary = "확정제품명 등록 페이지 내용물 목록 가져오기", description = "기능성허가 > 확정제품명 > 확정 등록")
	@GetMapping("/select-lab-cont-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabContList (@RequestParam("vLabNoteCd") String vLabNoteCd) {

		log.debug("HbdProcessController.selectLabContList");
		return ResponseEntity.ok(hbdProcessService.selectLabContList(vLabNoteCd));
	}

	@Operation(summary = "확정제품명 수정/조회 페이지 내용물 목록 가져오기", description = "기능성허가 > 확정제품명 > 확정 수정")
	@GetMapping("/select-func-decide-cont-name")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteFuncDecideContName (LabNoteProcessFuncReqDTO reqDTO) {

		log.debug("HbdProcessController.selectLabNoteFuncDecideContName");
		return ResponseEntity.ok(hbdProcessService.selectLabNoteFuncDecideContName(reqDTO));
	}

	@Operation(summary = "확정제품명 저장하기", description = "기능성허가 > 확정제품명 > 확정 등록")
	@PostMapping("/save-func-decide-name")
	public @ResponseBody ResponseEntity<ResponseVO> saveLabNoteFuncDecideName (@RequestBody @Valid LabNoteProcessFuncReqDTO reqDTO) {

		log.debug("HbdProcessController.saveLabNoteFuncDecideName");
		return ResponseEntity.ok(hbdProcessService.saveLabNoteFuncDecideName(reqDTO));
	}

	@Operation(summary = "시험성적서 목록 가져오기", description = "기능성허가 > 시험성적서")
	@GetMapping("/select-func-test-epreport-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectFuncTestEpReportList (LabNoteProcessFuncReqDTO reqDTO) {

		log.debug("HbdProcessController.selectFuncTestEpReportList");
		return ResponseEntity.ok(hbdProcessService.selectFuncTestEpReportList(reqDTO));
	}

	@Operation(summary = "기능성 검사 서류 전송 팝업", description = "기능성허가 > 시험성적서 > 기능성 검사 서류 전송 팝업")
	@GetMapping("/select-labnote-func-request-qa")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteFuncRequestQA (LabNoteProcessFuncReportReqPopDTO reqDTO) {

		log.debug("HbdProcessController.selectLabNoteFuncRequestQA");
		return ResponseEntity.ok(hbdProcessService.selectLabNoteFuncRequestQA(reqDTO));
	}

	@Operation(summary = "기능성 검사 서류 파일 업로드", description = "기능성허가 > 확정제품명 > 확정 등록")
	@PostMapping("/save-upload-func-report-file")
	public @ResponseBody ResponseEntity<ResponseVO> saveUploadFuncReportFile (@RequestBody @Valid LabNoteProcessFuncReportReqPopDTO reqDTO) {

		log.debug("HbdProcessController.saveUploadFuncReportFile");
		return ResponseEntity.ok(hbdProcessService.saveUploadFuncReportFile(reqDTO));
	}

	@Operation(summary = "시험성적서 요청 등록 페이지", description = "기능성허가 > 시험성적서 > 시험성적서 요청")
	@GetMapping("/select-func-test-epreport-reg")
	public @ResponseBody ResponseEntity<ResponseVO> selectFuncTestEpReportReg (LabNoteProcessFuncReqDTO reqDTO) {

		log.debug("HbdProcessController.selectFuncTestEpReportReg");
		return ResponseEntity.ok(hbdProcessService.selectFuncTestEpReportReg(reqDTO));
	}

	@Operation(summary = "시험성적서 요청 등록 페이지", description = "기능성허가 > 시험성적서 > 시험성적서 요청 > Lot 원료 배합량 확인")
	@GetMapping("/select-lab-note-mix-check")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteMixCheckList (@RequestParam("vLotCd") String vLotCd) {

		log.debug("HbdProcessController.selectLabNoteMixCheckList");
		return ResponseEntity.ok(hbdProcessService.selectLabNoteMixCheckList(vLotCd));
	}

	@Operation(summary = "시험성적서 요청 등록 페이지", description = "기능성허가 > 시험성적서 > 시험성적서 요청 > 요청 팝업 그룹 리스트")
	@GetMapping("/select-group-user-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectGroupUserList (LabNoteProcessFuncReportUserReqDTO reqDTO) {

		log.debug("HbdProcessController.selectGroupUserList");
		return ResponseEntity.ok(hbdProcessService.selectGroupUserList(reqDTO));
	}

	@Operation(summary = "시험성적서 요청 등록 저장 및 메일 전송", description = "기능성허가 > 시험성적서 > 시험성적서 요청 > 요청 팝업")
	@PostMapping("/save-lab-note-send-func-mail")
	public @ResponseBody ResponseEntity<ResponseVO> saveLabNoteSendFuncMail (@RequestBody @Valid LabNoteProcessFuncReportReqSaveDTO reqDTO) {

		log.debug("HbdProcessController.saveLabNoteSendFuncMail");
		return ResponseEntity.ok(hbdProcessService.saveLabNoteSendFuncMail(reqDTO));
	}

	@Operation(summary = "시험성적서 요청 심사번호 저장", description = "기능성허가 > 시험성적서 > 시험성적서 요청 > 심사번호 저장")
	@PostMapping("/update-note-ref-note")
	public @ResponseBody ResponseEntity<ResponseVO> updateNoteRefNote (@RequestBody @Valid LabNoteProcessFuncReportReqSaveDTO reqDTO) {

		log.debug("HbdProcessController.updateNoteRefNote");
		return ResponseEntity.ok(hbdProcessService.updateNoteRefNote(reqDTO));
	}

	@Operation(summary = "개발완료(양산승인) 목록", description = "개발완료 단계 목록")
	@GetMapping("/select-lab-note-cont-decide-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteContDecideList (LabNoteProcessContDecideReqDTO reqDTO) {

		log.debug("HbdProcessController.selectLabNoteContDecideList");
		return ResponseEntity.ok(hbdProcessService.selectLabNoteContDecideList(reqDTO));
	}

	@Operation(summary = "개발완료(양산승인) 요청", description = "개발완료 요청 자가체크 페이지")
	@GetMapping("/select-lab-note-gate2-reg")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteGate2Reg (LabNoteProcessContDecideReqDTO reqDTO) {

		log.debug("HbdProcessController.selectLabNoteGate2Reg");
		return ResponseEntity.ok(hbdProcessService.selectLabNoteGate2Reg(reqDTO));
	}

	@Operation(summary = "실험중 > 파일럿 목록", description = "실험중 > 파일럿 목록을 조회한다.")
	@GetMapping("/select-lab-note-pilot-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNotePilotList (
			PilotRequestReqDTO pilotRequestReqDTO
			) {
		log.debug("HbdProcessController.selectLabNotePilotList => pilotRequestReqDTO : {}", pilotRequestReqDTO);
		return ResponseEntity.ok(hbdProcessService.selectLabNotePilotList(pilotRequestReqDTO));
	}

	@Operation(summary = "파일럿 GATE01 승인 요청 등록 초기 정보 조회", description = "실험중 > 파일럿 GATE01 승인 요청 등록 초기 정보를 조회한다.")
	@GetMapping("/select-lab-note-pilot-reg-init-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNotePilotRegInitInfo (
			PilotRequestReqDTO pilotRequestReqDTO
			) {
		log.debug("HbdProcessController.selectLabNotePilotRegInitInfo => pilotRequestReqDTO : {}", pilotRequestReqDTO);
		return ResponseEntity.ok(hbdProcessService.selectLabNotePilotRegInitInfo(pilotRequestReqDTO));
	}

	@Operation(summary = "파일럿 GATE01 승인 요청 등록 정보 조회", description = "실험중 > 파일럿 GATE01 승인 요청 등록 정보를 조회한다.")
	@GetMapping("/select-lab-note-pilot-reg-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNotePilotRegInfo (
			PilotRequestRegInfoReqDTO pilotRequestRegInfoReqDTO
			) {
		log.debug("HbdProcessController.selectLabNotePilotRegInfo => pilotRequestDetailReqDTO : {}", pilotRequestRegInfoReqDTO);
		return ResponseEntity.ok(hbdProcessService.selectLabNotePilotRegInfo(pilotRequestRegInfoReqDTO));
	}

	@Operation(summary = "파일럿 GATE01 승인 요청 버전별 LOT 목록 조회", description = "실험중 > 파일럿 GATE01 승인 요청 버전별 LOT 목록을 조회한다.")
	@GetMapping("/select-lab-note-pilot-reg-version-lot-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNotePilotRegVersionLotList (
			@RequestParam(value="vLabNoteCd") String vLabNoteCd,
			@RequestParam(value="nVersion") int nVersion
			) {
		log.debug("HbdProcessController.selectLabNoteBomRegVersionLotList => params : { vLabNoteCd: {}, nVersion: {} }", vLabNoteCd, nVersion);
		return ResponseEntity.ok(hbdProcessService.selectLabNotePilotRegVersionLotList(vLabNoteCd, nVersion));
	}

	@Operation(summary = "파일럿 GATE01 승인 요청 상세 정보 조회", description = "실험중 > 파일럿 GATE01 승인 요청 상세 정보를 조회한다.")
	@GetMapping("/select-lab-note-pilot-req-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNotePilotReqInfo (
			PilotRequestDetailReqDTO pilotRequestDetailReqDTO
			) {
		log.debug("HbdProcessController.selectLabNoteBomReqInfo => pilotRequestDetailReqDTO : {}", pilotRequestDetailReqDTO);
		return ResponseEntity.ok(hbdProcessService.selectLabNotePilotReqInfo(pilotRequestDetailReqDTO));
	}

	@Operation(summary = "LOT별 BOM 리스트 조회", description = "실험중 > BOM 승인 상세 > LOT별 BOM 리스트를 조회한다.")
	@GetMapping("/select-lab-note-bom-mate-rate-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteBomMateRateInfo (
			PilotRequestDetailReqDTO pilotRequestDetailReqDTO
			) {
		log.debug("HbdProcessController.selectLabNoteBomMateRateInfo => pilotRequestDetailReqDTO : {}", pilotRequestDetailReqDTO);
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(hbdProcessService.selectLabNoteBomMateRateInfo(pilotRequestDetailReqDTO));
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "GATE02 결재 올리기", description = "처방확정 > GATE02 결재 올리기")
	@PostMapping("/save-lab-note-gate02-approval-request")
	public @ResponseBody ResponseEntity<ResponseVO> saveLabNoteGate02ApprovalRequest (@RequestBody @Valid LabNoteProcessPqcCheckApprReqDTO reqDTO) {

		log.debug("HbdProcessController.saveLabNoteGate02ApprovalRequest");
		return ResponseEntity.ok(hbdProcessService.saveLabNoteGate02ApprovalRequest(reqDTO));
	}

	@SuppressWarnings("deprecation")
	@Operation(summary = "양산승인 요청 PASS", description = "개발완료 > 양산승인 저장")
	@PostMapping("/update-lab-note-mass-pass")
	public @ResponseBody ResponseEntity<ResponseVO> updateLabNoteMassPass (@RequestBody @Valid LabNoteProcessPqcCheckApprReqDTO reqDTO) {

		log.debug("HbdProcessController.updateLabNoteMassPass");
		return ResponseEntity.ok(hbdProcessService.updateLabNoteMassPass(reqDTO));
	}

	@Operation(summary = "개발완료(양산승인) Gate2 view 페이지", description = "개발완료 요청 자가체크 페이지")
	@GetMapping("/select-lab-note-gate2-view")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteGate2View (LabNoteProcessContDecideReqDTO reqDTO) {

		log.debug("HbdProcessController.selectLabNoteGate2View");
		return ResponseEntity.ok(hbdProcessService.selectLabNoteGate2View(reqDTO));
	}

	@Operation(summary = "프로세스 > BOM 전송 리스트 조회", description = "프로세스 > BOM 전송 리스트를 조회한다.(BOM 탭)")
	@GetMapping("/select-lab-note-bom-send-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteBomSendList (
			PilotRequestReqDTO pilotRequestReqDTO
			) {
		log.debug("HbdProcessController.selectLabNoteBomSendList => pilotRequestReqDTO : {}", pilotRequestReqDTO);
		return ResponseEntity.ok(hbdProcessService.selectLabNoteBomSendList(pilotRequestReqDTO));
	}

	@Operation(summary = "프로세스 > 파일럿 GATE01 승인 요청", description = "프로세스 > 파일럿 GATE01 결재 요청")
	@PostMapping("/save-lab-note-gate01")
	public @ResponseBody ResponseEntity<ResponseVO> saveLabNoteGate01 (
			@RequestBody LabNoteProcessPqcCheckApprReqDTO labNoteProcessPqcCheckApprReqDTO
			) {
		log.debug("HbdProcessController.saveLabNoteGate01 => labNoteProcessPqcCheckApprReqDTO : {}", labNoteProcessPqcCheckApprReqDTO);
		return ResponseEntity.ok(hbdProcessService.saveLabNoteGate01(labNoteProcessPqcCheckApprReqDTO));
	}

	@Operation(summary = "프로세스 > 처방확정 가능 리스트 조회", description = "프로세스 > 처방확정 가능 리스트를 조회한다.")
	@GetMapping("/select-lab-note-formula-decide-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteFormulaDecideList (
			PilotRequestReqDTO pilotRequestReqDTO
			) {
		log.debug("HbdProcessController.selectLabNoteFormulaDecideList => pilotRequestReqDTO : {}", pilotRequestReqDTO);
		return ResponseEntity.ok(hbdProcessService.selectLabNoteFormulaDecideList(pilotRequestReqDTO));
	}

	@Operation(summary = "프로세스 > 기능성 허가 > 시험성적서 > 내용물 코드 조회 팝업", description = "내용물 코드 조회해서 시험성적서 요청에 추가한다. (HBD인 경우만 사용)")
	@GetMapping("/select-ev-report-prod-list-pop")
	public @ResponseBody ResponseEntity<ResponseVO> selectEvReportProdListPop (LabNoteProcessReportPrdListReqDTO reqDTO) {
		log.debug("HbdProcessController.selectEvReportProdListPop => reqDTO : {}", reqDTO);
		return ResponseEntity.ok(hbdProcessService.selectEvReportProdListPop(reqDTO));
	}

	@Operation(summary = "프로세스 > 결재 pass BOM SAP 전송", description = "프로세스 > 결재 pass BOM SAP 전송")
	@PostMapping("/send-bom-free-pass")
	public @ResponseBody ResponseEntity<ResponseVO> sendBomFreePass (
			@RequestBody BomApprovalReqDTO bomApprovalReqDTO
			) {
		log.debug("HbdProcessController.sendBomFreePass => bomApprovalReqDTO : {}", bomApprovalReqDTO);
		return ResponseEntity.ok(hbdProcessService.sendBomFreePass(bomApprovalReqDTO));
	}

	@Operation(summary = "시험성적서 요청 조회 페이지", description = "기능성허가 > 시험성적서 > 시험성적서 조회")
	@GetMapping("/select-func-test-epreport-view")
	public @ResponseBody ResponseEntity<ResponseVO> selectFuncTestEpReportView (LabNoteProcessFuncRequestQADTO reqDTO) {

		log.debug("HbdProcessController.selectFuncTestEpReportView : {} " + reqDTO);
		return ResponseEntity.ok(hbdProcessService.selectFuncTestEpReportView(reqDTO));
	}

	@Operation(summary = "기능성 확정제품명 상세 정보 조회", description = "기능성 허가 > 확정제품명 결재 후, 메일 링크로 진입 시 정보를 조회")
	@GetMapping("/select-lab-note-func-decide-name-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteFuncDecideNameInfo (
			@RequestParam(value="vLabNoteCd") String vLabNoteCd,
			@RequestParam(value="vApprCd") String vApprCd
			) {
		log.debug("HbdProcessController.selectLabNoteFuncDecideNameInfo => vLabNoteCd : {}, vApprCd : {}", vLabNoteCd, vApprCd);
		return ResponseEntity.ok(hbdProcessService.selectLabNoteFuncDecideNameInfo(vLabNoteCd, vApprCd));
	}

	@Operation(summary = "QMS 탭", description = "QMS 탭 내용물코드 목록 및 플랜트 리스트를 조회한다.")
	@GetMapping("/select-qms-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectQmsInfo (
			@RequestParam(value="vLabNoteCd") String vLabNoteCd
			) {
		log.debug("HbdProcessController.selectQmsInfo => vLabNoteCd : {}", vLabNoteCd);
		return ResponseEntity.ok(hbdProcessService.selectQmsInfo(vLabNoteCd));
	}

	@Operation(summary = "QMS 탭 플랜트정보 조회", description = "QMS 탭 내용물코드 별 플랜트 리스트를 조회한다.")
	@GetMapping("/select-qms-plant-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectQmsPlantList (
			@RequestParam(value="vLabNoteCd") String vLabNoteCd,
			@RequestParam(value="vContCd") String vContCd
			) {
		log.debug("HbdProcessController.selectQmsPlantList => vLabNoteCd : {}, vContCd : {}", vLabNoteCd, vContCd);
		return ResponseEntity.ok(hbdProcessService.selectQmsPlantList(vLabNoteCd, vContCd));
	}

	@Operation(summary = "파일럿 저장 가능 여부 체크", description = "파일럿 저장 가능 여부 체크")
	@PostMapping("/check-validation-pilot")
	public @ResponseBody ResponseEntity<ResponseVO> checkValidationPilot (
			@RequestBody LotPilotRegDTO regDTO
			) {
		log.debug("HbdProcessController.checkValidationPilot => regDTO : {}", regDTO);
		return ResponseEntity.ok(hbdProcessService.checkValidationPilot(regDTO));
	}

	@Operation(summary = "Right Menu > Schedule 정보", description = "Right Menu > Schedule 정보를 조회한다.")
	@GetMapping("/select-note-detail-schedule-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectNoteDetailScheduleList (
			@RequestParam(value="vLabNoteCd") String vLabNoteCd
			) {
		log.debug("HbdProcessController.selectNoteDetailScheduleList => vLabNoteCd : {}", vLabNoteCd);
		return ResponseEntity.ok(hbdProcessService.selectNoteDetailScheduleList(vLabNoteCd));
	}
	
	@Operation(summary = "LOT별 BOM 상세 조회", description = "실험중 > BOM 승인 상세 > LOT별 BOM 상세를 조회한다.")
	@GetMapping("/select-lab-note-bom-mate-view")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteBomMateView (
			PilotRequestDetailReqDTO pilotRequestDetailReqDTO
			) {
		log.debug("HbdProcessController.selectLabNoteBomMateView => pilotRequestDetailReqDTO : {}", pilotRequestDetailReqDTO);
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(hbdProcessService.selectLabNoteBomMateView(pilotRequestDetailReqDTO));
		return ResponseEntity.ok(responseVO);
	}
	
	@Operation(summary = "에어로졸 내용물 처방확정 대상 리스트 조회", description = "프로세스 > 처방확정 > 에어로졸 내용물 처방확정 대상 리스트 조회")
	@GetMapping("/select-aerosol-decide-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectAerosolDecideList (
			@RequestParam(value="vLabNoteCd") String vLabNoteCd
			) {
		log.debug("HbdProcessController.selectAerosolDecideList => vLabNoteCd : {}", vLabNoteCd);
		return ResponseEntity.ok(hbdProcessService.selectAerosolDecideList(vLabNoteCd));
	}
	
	@Operation(summary = "에어로졸 내용물 처방확정", description = "프로세스 > 처방확정 > 에어로졸 내용물 처방확정")
	@PostMapping("/save-aerosol-formula-decide")
	public @ResponseBody ResponseEntity<ResponseVO> saveAerosolFormulaDecide (
			@RequestBody HbdAerosolDecideReqDTO hbdAerosolDecideReqDTO
			) {
		log.debug("HbdProcessController.saveAerosolFormulaDecide => pilotRequestReqDTO : {}", hbdAerosolDecideReqDTO);
		return ResponseEntity.ok(hbdProcessService.saveAerosolFormulaDecide(hbdAerosolDecideReqDTO));
	}
}
