package com.mybeaker.app.hbd.service;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;

import com.mybeaker.app.common.model.AlarmRegDTO;
import com.mybeaker.app.common.model.CodeDTO;
import com.mybeaker.app.common.model.ThumbnailDTO;
import com.mybeaker.app.common.model.UploadDTO;
import com.mybeaker.app.common.service.CommonService;
import com.mybeaker.app.hbd.mapper.HbdMaterialMapper;
import com.mybeaker.app.hbd.model.HbdBomResDTO;
import com.mybeaker.app.hbd.model.HbdGramResDTO;
import com.mybeaker.app.hbd.model.HbdHal4LotResDTO;
import com.mybeaker.app.hbd.model.HbdMaterialFormulationResDTO;
import com.mybeaker.app.hbd.model.HbdMaterialNotePlantVO;
import com.mybeaker.app.hbd.model.HbdMaterialSaveRegDTO;
import com.mybeaker.app.hbd.model.HbdMemoResDTO;
import com.mybeaker.app.hbd.model.HbdNoteContVO;
import com.mybeaker.app.hbd.model.HbdNoteGramTrVO;
import com.mybeaker.app.hbd.model.HbdNoteGramVO;
import com.mybeaker.app.hbd.model.HbdNoteGroupVO;
import com.mybeaker.app.hbd.model.HbdNoteInfoDTO;
import com.mybeaker.app.hbd.model.HbdNoteLotVO;
import com.mybeaker.app.hbd.model.HbdNoteMateVO;
import com.mybeaker.app.hbd.model.HbdNoteMemoVO;
import com.mybeaker.app.hbd.model.HbdNoteMstVO;
import com.mybeaker.app.hbd.model.HbdNoteMstVerTagVO;
import com.mybeaker.app.hbd.model.HbdNoteMstVerVO;
import com.mybeaker.app.hbd.model.HbdNoteRateVO;
import com.mybeaker.app.hbd.model.HbdNoteStabilityTitleVO;
import com.mybeaker.app.hbd.model.HbdNoteStabilityValueVO;
import com.mybeaker.app.hbd.model.HbdNoteVersionDTO;
import com.mybeaker.app.hbd.model.HbdNoteVersionVO;
import com.mybeaker.app.hbd.model.HbdPlantRatePriceResDTO;
import com.mybeaker.app.labnote.model.BomInfoVO;
import com.mybeaker.app.labnote.model.ElabHisLotChgVO;
import com.mybeaker.app.labnote.model.ElabHisPreRateVO;
import com.mybeaker.app.labnote.model.ElabNoteMstSetVO;
import com.mybeaker.app.labnote.model.ElabShelflifeContVO;
import com.mybeaker.app.labnote.model.ElabStats01VO;
import com.mybeaker.app.labnote.model.ElabStats02VO;
import com.mybeaker.app.labnote.model.ElabStats03VO;
import com.mybeaker.app.labnote.model.Hal4MateRegDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonSAPSyncDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonSearchMateDTO;
import com.mybeaker.app.labnote.model.MusoguInfoVO;
import com.mybeaker.app.labnote.model.MusoguRateVO;
import com.mybeaker.app.labnote.model.MusoguReqDTO;
import com.mybeaker.app.labnote.model.MusoguTagVO;
import com.mybeaker.app.labnote.model.VersionListVO;
import com.mybeaker.app.labnote.service.LabNoteCommonService;
import com.mybeaker.app.labnote.service.LabNoteSAPInterfaceService;
import com.mybeaker.app.model.Const;
import com.mybeaker.app.model.dto.PagingDTO;
import com.mybeaker.app.model.dto.ResCommSearchInfoDTO;
import com.mybeaker.app.model.enums.CommonResultCode;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.skincare.model.BomReqDTO;
import com.mybeaker.app.skincare.model.BookmarkReqDTO;
import com.mybeaker.app.skincare.model.BookmarkVO;
import com.mybeaker.app.skincare.model.CounterSAPRegDTO;
import com.mybeaker.app.skincare.model.CounterSAPResDTO;
import com.mybeaker.app.skincare.model.ElabLotMemoRegDTO;
import com.mybeaker.app.skincare.model.ElabLotMemoVO;
import com.mybeaker.app.skincare.model.FinalLotVO;
import com.mybeaker.app.skincare.model.GramReqDTO;
import com.mybeaker.app.skincare.model.GramTrPlanVO;
import com.mybeaker.app.skincare.model.IngredientContVO;
import com.mybeaker.app.skincare.model.IngredientDataVO;
import com.mybeaker.app.skincare.model.IngredientExistsConcdVO;
import com.mybeaker.app.skincare.model.IngredientMateVO;
import com.mybeaker.app.skincare.model.IngredientReqDTO;
import com.mybeaker.app.skincare.model.IngredientReqVO;
import com.mybeaker.app.skincare.model.IngredientResDTO;
import com.mybeaker.app.skincare.model.IngredientVO;
import com.mybeaker.app.skincare.model.LotDecideRegDTO;
import com.mybeaker.app.skincare.model.LotGramResDTO;
import com.mybeaker.app.skincare.model.LotPilotRegDTO;
import com.mybeaker.app.skincare.model.MateRateReqVO;
import com.mybeaker.app.skincare.model.MaterialFormulationReqDTO;
import com.mybeaker.app.skincare.model.MaterialFormulationResDTO;
import com.mybeaker.app.skincare.model.MaterialGradeSumVO;
import com.mybeaker.app.skincare.model.MaterialLotBookmarkRegDTO;
import com.mybeaker.app.skincare.model.MaterialLotVO;
import com.mybeaker.app.skincare.model.MaterialMateRateVO;
import com.mybeaker.app.skincare.model.MaterialMateSumVO;
import com.mybeaker.app.skincare.model.MaterialMateVO;
import com.mybeaker.app.skincare.model.MaterialNoteContVO;
import com.mybeaker.app.skincare.model.MaterialNoteVersionVO;
import com.mybeaker.app.skincare.model.MaterialNumberVO;
import com.mybeaker.app.skincare.model.MaterialOtherResDTO;
import com.mybeaker.app.skincare.model.MaterialPlantRegDTO;
import com.mybeaker.app.skincare.model.MaterialQrInfoVO;
import com.mybeaker.app.skincare.model.MaterialRowGramVO;
import com.mybeaker.app.skincare.model.MaterialSearchVO;
import com.mybeaker.app.skincare.model.MaterialSubReqDTO;
import com.mybeaker.app.skincare.model.MaterialSumMateDTO;
import com.mybeaker.app.skincare.model.MaterialSumReqDTO;
import com.mybeaker.app.skincare.model.MaterialSumReqVO;
import com.mybeaker.app.skincare.model.MaterialSumResDTO;
import com.mybeaker.app.skincare.model.MaterialUploadDTO;
import com.mybeaker.app.skincare.model.MaterialVersionRegDTO;
import com.mybeaker.app.skincare.model.MemoRegDTO;
import com.mybeaker.app.skincare.model.MemoReqDTO;
import com.mybeaker.app.skincare.model.MusoguResDTO;
import com.mybeaker.app.skincare.model.PlantRatePriceReqVO;
import com.mybeaker.app.skincare.model.PlantRatePriceVO;
import com.mybeaker.app.skincare.model.QrCodeResDTO;
import com.mybeaker.app.skincare.model.ScmTCodeRegDTO;
import com.mybeaker.app.skincare.model.SendBomRegDTO;
import com.mybeaker.app.skincare.model.StabilityReqDTO;
import com.mybeaker.app.skincare.model.StabilityResDTO;
import com.mybeaker.app.skincare.model.StabilityTitleVO;
import com.mybeaker.app.skincare.model.SubMateReqDTO;
import com.mybeaker.app.skincare.model.SubMateVO;
import com.mybeaker.app.skincare.model.TestResultFlagDTO;
import com.mybeaker.app.skincare.model.TestResultRegDTO;
import com.mybeaker.app.skincare.model.VersionContVO;
import com.mybeaker.app.skincare.model.VersionRegDTO;
import com.mybeaker.app.skincare.model.VersionReqDTO;
import com.mybeaker.app.skincare.model.VersionResDTO;
import com.mybeaker.app.utils.CommonUtil;
import com.mybeaker.app.utils.ConvertUtil;
import com.mybeaker.app.utils.SessionUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Service
public class HbdMaterialService {

	private final HbdMaterialMapper hbdMaterialMapper;

	private final SessionUtil sessionUtil;

	private final LabNoteSAPInterfaceService labNoteSAPInterfaceService;

	private final MessageSourceAccessor messageSource;

	private final CommonService commonService;

	private final LabNoteCommonService labNoteCommonService;

	private final HbdCommonService hbdCommonService;

	public ResponseVO selectMaterialFormulationInfo(MaterialFormulationReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();
		MaterialSearchVO schVO = new MaterialSearchVO();

		schVO.setVLabNoteCd(reqDTO.getVLabNoteCd());
		schVO.setNVersion(reqDTO.getNVersion());
		schVO.setVContPkCd(reqDTO.getVContPkCd());
		schVO.setLanguage(sessionUtil.getLangCd());
		schVO.setVUserId(sessionUtil.getLoginId());
		schVO.setLocalLanguage(sessionUtil.getLocalLanguage());

		MaterialQrInfoVO qrInfoVO = null;
		if("Y".equals(reqDTO.getVFlagQrCode()) && "NOTE_LOT".equals(reqDTO.getVDivQrCode())) {
			qrInfoVO = hbdMaterialMapper.selectElabNoteInfoVerLotCd(MaterialQrInfoVO.builder()
					.vLotCd(reqDTO.getVQrCode())
					.build());

			if(!ObjectUtils.isEmpty(qrInfoVO)) {
				schVO.setVLabNoteCd(qrInfoVO.getVLabNoteCd());
				schVO.setVContPkCd(qrInfoVO.getVContPkCd());
				schVO.setNVersion(qrInfoVO.getNVersion());
			}
		}

		if(StringUtils.isEmpty(reqDTO.getVLabNoteCd())) {
			responseVO.setOk(messageSource.getMessage("pms.messageCommon.msg50"));
			return responseVO;
		}

		HbdNoteInfoDTO rvo = hbdCommonService.selectLabNoteInfo(schVO.getVLabNoteCd());

		if(ObjectUtils.isEmpty(rvo)) {
			responseVO.setOk(messageSource.getMessage("pms.messageCommon.msg48"));
			return responseVO;
		}

		hbdCommonService.selectElabNoteAuth(schVO, rvo);
		List<String> groups = sessionUtil.getGroups();

		if (!"Y".equals(schVO.getVIsPersonInCharge()) &&
				!"Y".equals(schVO.getVIsRelatedPerson()) &&
				!"Y".equals(schVO.getVIsLabNoteAdmin()) &&
				(!ObjectUtils.isEmpty(groups) && groups.stream().anyMatch(group -> "S000118;S000246;S000000;".indexOf(group) == -1)) &&
				!"Y".equals(labNoteCommonService.checkLabNoteAuth("HBO", rvo.getVStatusCd(), rvo.getVDeptCd()))) {
			responseVO.setOkWithCode("C9999", CommonResultCode.NO_AUTH, null);
			return responseVO;
		}

		String labTypeCtgCd = rvo.getVLabTypeCtgCd();
		schVO.setVCodeType(labTypeCtgCd);

		if(StringUtils.equalsAnyIgnoreCase(labTypeCtgCd, "NONPRD", "PRD")) {
			schVO.setVCodeType("HAL3");

			if("NONPRD".equals(labTypeCtgCd)) {
				schVO.setVIsFlagAuthCheckNonprd("Y");
			}
		}

		return this.selectMaterialFormulation(schVO, rvo);
	}

	/**
	 * 원료배합
	 * @param schVO
	 * @param rvo
	 */
	private ResponseVO selectMaterialFormulation(MaterialSearchVO schVO, HbdNoteInfoDTO rvo) {
		ResponseVO responseVO = new ResponseVO();

		//hbdCommonService.selectElabNoteAuth(schVO, rvo);

		schVO.setVCodeType(StringUtils.defaultIfEmpty(schVO.getVCodeType(), "HAL3"));

		schVO.setNVersion(schVO.getNVersion() < 0 ? rvo.getNMaxVersion() : schVO.getNVersion());
		schVO.setNLatestVersion(1);
		schVO.setVFlagLotDecide(null);

		String statusCd = rvo.getVStatusCd(); // 상태
		schVO.setVStatusCd(statusCd);

		String isPersonInCharge = schVO.getVIsPersonInCharge();
		String isRelatedPerson 	= schVO.getVIsRelatedPerson();
		String isCompleteNote 	= schVO.getVIsCompleteNote();
		String isMuMixingRaw 	= schVO.getVIsMuMixingRaw();
		String isAssistant		= schVO.getVIsAssistant();

		schVO.setVLand1(StringUtils.defaultIfEmpty(schVO.getVLand1(), "UN"));
		schVO.setVSiteType(rvo.getVSiteType());

		schVO.setVSearchType("CONT");
		List<HbdMaterialNotePlantVO> contList = hbdMaterialMapper.selectLabNoteContOrPlantList(schVO);

		HbdMaterialNotePlantVO initContVo;
		MaterialOtherResDTO otherVO = new MaterialOtherResDTO();

		if(StringUtils.isEmpty(schVO.getVContPkCd())) {
			for(int i = 0; i < contList.size(); i++) {
				initContVo = contList.get(i);

				if("Y".equals(isPersonInCharge) || "Y".equals(isRelatedPerson) || "Y".equals(isCompleteNote) || "Y".equals(isMuMixingRaw)) {
					if("Y".equals(initContVo.getVFlagRepresent())){
						schVO.setVContPkCd(initContVo.getVContPkCd());
						schVO.setVContCd(initContVo.getVContCd());
						break;
					}
				}
				else {
					if(schVO.getVUserId().equals(initContVo.getVUserid())) {
						schVO.setVContPkCd(initContVo.getVContPkCd());
						schVO.setVContCd(initContVo.getVContCd());
						break;
					}
				}
			}
		}
		else {
			for(int i = 0; i < contList.size(); i++){
				initContVo = contList.get(i);

				if (initContVo.getVContPkCd().equals(schVO.getVContPkCd())) {
					schVO.setVContCd(initContVo.getVContCd());
					break;
				}
			}
		}

		List<HbdMaterialNotePlantVO> plantList = null;
		if(StringUtils.isNotEmpty(schVO.getVContCd())) {
			schVO.setVSearchType("PLANT");
			plantList = hbdMaterialMapper.selectLabNoteContOrPlantList(schVO);

			if(StringUtils.isEmpty(schVO.getVPlantCd())){
				schVO.setVPlantCd(rvo.getVPlantCd());
			}
			else {
				boolean isExists = false;

				for(HbdMaterialNotePlantVO plantVo : plantList) {
					if(plantVo.getVPlantCd().equals(schVO.getVPlantCd())){
						isExists = true;
						break;
					}
				}

				if(!isExists){
					schVO.setVPlantCd(rvo.getVPlantCd());
				}
			}
		}
		else {
			schVO.setVPlantCd(rvo.getVPlantCd());
		}

		MaterialNoteContVO contVO = hbdMaterialMapper.selectLabNoteContInfo(schVO);

		if(ObjectUtils.isEmpty(contVO)) {
			responseVO.setOk("권한 또는 등록된 코드가 없습니다");
			return responseVO;
		}

		contVO.setVLand1(StringUtils.defaultIfEmpty(contVO.getVLand1(), "UN"));

		schVO.setVContPkCd(contVO.getVContPkCd());

		List<MaterialNoteVersionVO> verList = hbdMaterialMapper.selectLabNoteVersion(schVO);

		if(ObjectUtils.isEmpty(verList)){
			responseVO.setOk("등록된 버전이 없습니다");
			return responseVO;
		}

		if("N".equals(hbdMaterialMapper.selectLabNoteCheckVersion(schVO))) {
			for(MaterialNoteVersionVO tempverVO : verList){
				if("Y".equals(tempverVO.getVFlagView())){
					schVO.setNVersion(tempverVO.getNVersion());
				}
			}
		}

		List<MaterialNoteVersionVO> verTmpVO = hbdMaterialMapper.selectLabNoteVersion(MaterialSearchVO.builder()
				.vContPkCd(schVO.getVContPkCd())
				.vGetType("Vo")
				.nVersion(schVO.getNVersion())
				.build());

		MaterialNoteVersionVO verVO = null;
		if(!ObjectUtils.isEmpty(verTmpVO)){
			verVO = verTmpVO.get(0);

			if(sessionUtil.getLoginId().equals(contVO.getVUserid())
					&& "N".equals(contVO.getVFlagRepresent())
					&& verVO.getNVersion() > 1
					&& "N".equals(verVO.getVFlagCheck())) {
				verVO.setVFlagCheckNewVer("Y");
			}else {
				verVO.setVFlagCheckNewVer("N");
			}
		}

		schVO.setVLotConditionType(null);
		List<MaterialLotVO> lotAllList = hbdMaterialMapper.selectLabNoteLotGramList(schVO);

		String vFlagDecide = "N".equals(schVO.getVIsMuDivFlag())
				&& "N".equals(isCompleteNote)
				&& "N".equals(isMuMixingRaw)
				&& "N".equals(isPersonInCharge)
				&& "N".equals(isAssistant)
				&& "N".equals(isRelatedPerson)
				? "Y" : "N";

		List<MaterialLotVO> lotList = new ArrayList<>();
		if (!lotAllList.isEmpty()) {
//			TOBE. vue 화면에서 제어하는게 이득
//			String vFlagExposure = hbdMaterialMapper.selectLabNoteExistsLotExposure(schVO);
//			lotList = hbdMaterialMapper.selectLabNoteLotGramList(MaterialSearchVO.builder()
//					.vLand1(schVO.getVLand1())
//					.vPlantCd(schVO.getVPlantCd())
//					.vContPkCd(schVO.getVContPkCd())
//					.nVersion(schVO.getNVersion())
//					.vLotConditionType("List")
//					.vFlagDecide(vFlagDecide)
//					.vLotCd(null)
//					.vFlagExposure(vFlagExposure)
//					.build());
			lotList = lotAllList;
		}

		if("Y".equals(contVO.getVFlagExistsDecide()) || "LNC06_41".equals(rvo.getVStatusCd())) {
			otherVO.setVFlagDisabled("Y");
		}
		else {
			if("Y".equals(isPersonInCharge) || schVO.getVUserId().equals(contVO.getVUserid()) || "Y".equals(isMuMixingRaw)) {

				if (lotAllList.isEmpty()) {
					MaterialLotVO lotAllVo = MaterialLotVO.builder()
							.vLotCd("tmp_lot_1")
							.vLotNm("Lot #01")
							.nRowNum(1)
							.nSort(1)
							.vFlagExposure("Y")
							.build();

					lotAllList.add(lotAllVo);
					lotList.add(lotAllVo);
				}
				else {
					for(MaterialLotVO lotAll : lotAllList) {
						lotList.forEach(lot -> {
							if(lotAll.getVLotCd().equals(lot.getVLotCd())) {
								lotAll.setVFlagExposure("Y");
							}
						});
					}
				}

				otherVO.setVFlagDisabled("N");
			}
			else {
				otherVO.setVFlagDisabled("Y");
			}
		}

		if("LNC06_41".equals(rvo.getVStatusCd())) {
			otherVO.setVFlagTestRequest("N");
		}
		else {
			if("Y".equals(isPersonInCharge) || schVO.getVUserId().equals(contVO.getVUserid())) {
				otherVO.setVFlagTestRequest("Y");
			}
			else {
				otherVO.setVFlagTestRequest("N");
			}
		}

		List<MaterialMateVO> mateList = hbdCommonService.checkIngredientOrganization(schVO);

		//[S]원료코드 내 구성성분 없음이 존재하는지 확인
		String checkIngrResult = "";
		for(MaterialMateVO checkIngrVo : mateList){
			if("Y".equals(checkIngrVo.getVFlagNotIngrYn())){
				checkIngrResult = "Y";
			}

			if(StringUtils.isNotEmpty(checkIngrVo.getVMateSimplePrice())) {
				BigDecimal hundredPrice = new BigDecimal(checkIngrVo.getVMateSimplePrice()).multiply(new BigDecimal("100"));
				DecimalFormat df = new DecimalFormat("#.##########");
				checkIngrVo.setVMateHundredPrice(df.format(hundredPrice.doubleValue()));
			}
		}
		schVO.setVIngrBtnYn(checkIngrResult);
		//[E]원료코드 내 구성성분 없음이 존재하는지 확인

		List<MaterialNumberVO> numberList = new ArrayList<>();
		int deno = 0;
		if(StringUtils.isNotEmpty(rvo.getVProdType1Nm())){
			// 무소구 가능여부 flag
			schVO.setVMosuguFlag("Y");

			//selectHal4MateDenominator
			deno = hbdMaterialMapper.selectHal4MateDenominator(MaterialSearchVO.builder()
					.vContPkCd(schVO.getVContPkCd())
					.vLand1(schVO.getVLand1())
					.nVersion(schVO.getNVersion())
					.vProdType1Cd(rvo.getVProdType1Cd())
					.vProdType2Cd(rvo.getVProdType2Cd())
					.build());

			numberList = hbdMaterialMapper.selectHal4MateNumerator(MaterialSearchVO.builder()
					.vContPkCd(contVO.getVContPkCd())
					.vLand1(schVO.getVLand1())
					.nVersion(verVO.getNVersion())
					.vProdType1Cd(rvo.getVProdType1Cd())
					.vProdType2Cd(rvo.getVProdType2Cd())
					.build()); // 분자 구하기
		}

		List<MaterialMateRateVO> rateList = hbdMaterialMapper.selectLabNoteMateRateMap(MaterialSearchVO.builder()
				.vLand1(schVO.getVLand1())
				.vPlantCd(schVO.getVPlantCd())
				.vContPkCd(schVO.getVContPkCd())
				.nVersion(schVO.getNVersion())
				.vLotConditionType("List")
				.vFlagDecide(vFlagDecide)
				.vLotCd(null)
				.build());		// Rate

		if(!ObjectUtils.isEmpty(lotList)) {
			lotList.forEach(lot -> {
				lot.setRateList(rateList.stream()
						.filter(rate -> lot.getVLotCd().equals(rate.getVLotCd()))
						.collect(Collectors.toList()));
			});
		}

		List<MaterialMateSumVO> matePriceList = hbdMaterialMapper.selectLabNoteMatePriceSum(schVO);	// 가격비 합

		List<MaterialMateSumVO> mateNeutList = new ArrayList<>();
		if("Y".equals(rvo.getVFlagSoap())) {
//			TOBE. 중화도 필요시 주석해제
//			schVO.setVSearchType("LOT");
//			mateNeutList = hbdMaterialMapper.selectLabNoteMateNeutralization(schVO);	//중화도
		}

		List<ElabNoteMstSetVO> mstSetVO = labNoteCommonService.selectNoteMstSetList(schVO.getVLabNoteCd());

		//end
		responseVO.setOk(HbdMaterialFormulationResDTO.builder()
				.rvo(rvo)
				.plantList(plantList)
				.contList(contList)
				.contVO(contVO)
				.verList(verList)
				.verVO(verVO)
				.lotAllList(lotAllList)
				.lotList(lotList)
				.mateList(mateList)
				.deno(deno)
				.numberList(numberList)
				.rateList(rateList)
				.matePriceList(matePriceList)
				.mateNeutList(mateNeutList)
				.otherVO(otherVO)
				.mstSetVO(mstSetVO)
				.build());
		return responseVO;
	}

	public ResponseVO selectMaterialFormulationSum (MaterialSumReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		List<String> gramList = reqDTO.getGramList();
		int glen = gramList.size();

		BigDecimal[] arrGram = new BigDecimal[10];
		BigDecimal[] sumGram = new BigDecimal[10];
		BigDecimal[] restGram = new BigDecimal[10];

		for (int i = 0; i < 10; i++) {
			if (glen > i) {
				arrGram[i] = new BigDecimal(StringUtils.isNotEmpty(gramList.get(i)) ? gramList.get(i) : "0");
			}
			else{
				arrGram[i] = new BigDecimal("0");
			}

			sumGram[i] = new BigDecimal("0");
			restGram[i] = new BigDecimal("0");
		}

		glen = arrGram.length;

		BigDecimal rowGram = null;
		BigDecimal rate = null;
		BigDecimal per = new BigDecimal("100");
		BigDecimal sumRate = new BigDecimal("0");

		BigDecimal restRate = null;

		List<MaterialSumMateDTO> mateSumList = reqDTO.getMateSumList();
		int len = mateSumList.size();

		String str = "";
		String flg = "";
		int restIdx = -1;

		List<MaterialRowGramVO> list = new ArrayList<>();
		MaterialRowGramVO restGramVO = new MaterialRowGramVO();
		MaterialRowGramVO sumGramVO = new MaterialRowGramVO();
		MaterialRowGramVO tempVO = null;

		if (len > 0) {
			restIdx = -1;

			for (int i = 0; i < len; i++) {

				tempVO = new MaterialRowGramVO();

				str = mateSumList.get(i).getVMateRate();
				flg = mateSumList.get(i).getVFlagRateRest();

				if ("Y".equals(flg)) {
					restIdx = i;
				}
				else if (StringUtils.isNotEmpty(str)) {
					try {
						rate = new BigDecimal(str);
					} catch (NumberFormatException nfe) {
						rate = new BigDecimal(0);
					}

					for (int j = 0; j < glen; j++) {
						rowGram = arrGram[j].multiply(rate).divide(per);
						sumGram[j] = sumGram[j].add(rowGram);

						if(j == 0) {
							tempVO.setNRowGram1(this.selectPointZeroDel(rowGram.toPlainString()));
						}
						else if(j == 1) {
							tempVO.setNRowGram2(this.selectPointZeroDel(rowGram.toPlainString()));
						}
						else if(j == 2) {
							tempVO.setNRowGram3(this.selectPointZeroDel(rowGram.toPlainString()));
						}
						else if(j == 3) {
							tempVO.setNRowGram4(this.selectPointZeroDel(rowGram.toPlainString()));
						}
						else if(j == 4) {
							tempVO.setNRowGram5(this.selectPointZeroDel(rowGram.toPlainString()));
						}
						else if(j == 5) {
							tempVO.setNRowGram6(this.selectPointZeroDel(rowGram.toPlainString()));
						}
						else if(j == 6) {
							tempVO.setNRowGram7(this.selectPointZeroDel(rowGram.toPlainString()));
						}
						else if(j == 7) {
							tempVO.setNRowGram8(this.selectPointZeroDel(rowGram.toPlainString()));
						}
						else if(j == 8) {
							tempVO.setNRowGram9(this.selectPointZeroDel(rowGram.toPlainString()));
						}
						else if(j == 9) {
							tempVO.setNRowGram10(this.selectPointZeroDel(rowGram.toPlainString()));
						}
					}

					sumRate = sumRate.add(rate);

					tempVO.setVMatePkCd(mateSumList.get(i).getVMatePkCd());
				}

				list.add(tempVO);
			}

			if (restIdx > -1) {
				restRate = per.subtract(sumRate);

				for (int j = 0; j < glen; j++) {
					restGram[j] = arrGram[j].multiply(restRate).divide(per);

					sumGram[j] = sumGram[j].add(restGram[j]);
				}

				sumRate = sumRate.add(restRate);
			}

			for (int j = 0; j < glen; j++) {
				if(j == 0) {
					restGramVO.setNGram1(this.selectPointZeroDel(restGram[j].toPlainString()));
					sumGramVO.setNGram1(this.selectPointZeroDel(sumGram[j].toPlainString()));
				}
				else if(j == 1) {
					restGramVO.setNGram2(this.selectPointZeroDel(restGram[j].toPlainString()));
					sumGramVO.setNGram2(this.selectPointZeroDel(sumGram[j].toPlainString()));
				}
				else if(j == 2) {
					restGramVO.setNGram3(this.selectPointZeroDel(restGram[j].toPlainString()));
					sumGramVO.setNGram3(this.selectPointZeroDel(sumGram[j].toPlainString()));
				}
				else if(j == 3) {
					restGramVO.setNGram4(this.selectPointZeroDel(restGram[j].toPlainString()));
					sumGramVO.setNGram4(this.selectPointZeroDel(sumGram[j].toPlainString()));
				}
				else if(j == 4) {
					restGramVO.setNGram5(this.selectPointZeroDel(restGram[j].toPlainString()));
					sumGramVO.setNGram5(this.selectPointZeroDel(sumGram[j].toPlainString()));
				}
				else if(j == 5) {
					restGramVO.setNGram6(this.selectPointZeroDel(restGram[j].toPlainString()));
					sumGramVO.setNGram6(this.selectPointZeroDel(sumGram[j].toPlainString()));
				}
				else if(j == 6) {
					restGramVO.setNGram7(this.selectPointZeroDel(restGram[j].toPlainString()));
					sumGramVO.setNGram7(this.selectPointZeroDel(sumGram[j].toPlainString()));
				}
				else if(j == 7) {
					restGramVO.setNGram8(this.selectPointZeroDel(restGram[j].toPlainString()));
					sumGramVO.setNGram8(this.selectPointZeroDel(sumGram[j].toPlainString()));
				}
				else if(j == 8) {
					restGramVO.setNGram9(this.selectPointZeroDel(restGram[j].toPlainString()));
					sumGramVO.setNGram9(this.selectPointZeroDel(sumGram[j].toPlainString()));
				}
				else if(j == 9) {
					restGramVO.setNGram10(this.selectPointZeroDel(restGram[j].toPlainString()));
					sumGramVO.setNGram10(this.selectPointZeroDel(sumGram[j].toPlainString()));
				}
			}

		}

		List<MaterialSubReqDTO> mateSubList = reqDTO.getMateSubList();
		BigDecimal sRatio = null;
		BigDecimal pRate = null;
		BigDecimal sRate = null;

		List<MaterialRowGramVO> subList = new ArrayList<>();
		MaterialRowGramVO subTempVO;

		if(!ObjectUtils.isEmpty(mateSubList)) {
			for(int i = 0; i < mateSubList.size(); i++){
				if(StringUtils.isEmpty(mateSubList.get(i).getNParentMateRate())) {
					continue;
				}

				sRatio = new BigDecimal(mateSubList.get(i).getNMateRatio());
				pRate = new BigDecimal(mateSubList.get(i).getNParentMateRate());
				sRate = pRate.multiply(sRatio).divide(per);

				subTempVO = new MaterialRowGramVO();
				subTempVO.setNSubRate(sRate);

				for (int j = 0; j < glen; j++) {
					rowGram = arrGram[j].multiply(sRate).divide(per);

					if(j == 0) {
						subTempVO.setNRowGram1(this.selectPointZeroDel(rowGram.toPlainString()));
					}
					else if(j == 1) {
						subTempVO.setNRowGram2(this.selectPointZeroDel(rowGram.toPlainString()));
					}
					else if(j == 2) {
						subTempVO.setNRowGram3(this.selectPointZeroDel(rowGram.toPlainString()));
					}
					else if(j == 3) {
						subTempVO.setNRowGram4(this.selectPointZeroDel(rowGram.toPlainString()));
					}
					else if(j == 4) {
						subTempVO.setNRowGram5(this.selectPointZeroDel(rowGram.toPlainString()));
					}
					else if(j == 5) {
						subTempVO.setNRowGram6(this.selectPointZeroDel(rowGram.toPlainString()));
					}
					else if(j == 6) {
						subTempVO.setNRowGram7(this.selectPointZeroDel(rowGram.toPlainString()));
					}
					else if(j == 7) {
						subTempVO.setNRowGram8(this.selectPointZeroDel(rowGram.toPlainString()));
					}
					else if(j == 8) {
						subTempVO.setNRowGram9(this.selectPointZeroDel(rowGram.toPlainString()));
					}
					else if(j == 9) {
						subTempVO.setNRowGram10(this.selectPointZeroDel(rowGram.toPlainString()));
					}
				}

				subList.add(subTempVO);

				subTempVO.setVMatePkCd(mateSubList.get(i).getVMatePkCd());
			}
		}

		List<MaterialGradeSumVO> gradeSumList = this.labNoteMateSustainabilityGradeAjax(reqDTO);
		Map<String, String> gradeWeightedSum = this.selectLabNoteMateGradeWeightedSum(gradeSumList);

		List<MaterialMateSumVO> neutList = this.labNoteMateNeutralizationAjax(reqDTO);

		responseVO.setOk(MaterialSumResDTO.builder()
				.restRate(this.selectPointZeroDel(restRate == null ? "" : restRate.toPlainString()))
				.sumRate(this.selectPointZeroDel(sumRate.toPlainString()))
				.restGramVO(restGramVO)
				.sumGramVO(sumGramVO)
				.list(list)
				.subList(subList)
				.gradeSumList(gradeSumList)
				.gradeWeightedSum(gradeWeightedSum)
				.sumPrice(this.labNoteMatePriceSumAjax(reqDTO))
				.neutList(neutList)
				.build());
		return responseVO;
	}

	/**
	 * 소숫점 뒤에 0 을 제거함	ex ) 0.00100 => 0.001
	 * @param str
	 * @return
	 */
	private String selectPointZeroDel (String str) {
		if (str == null || str.equals("") || str.indexOf(".") == -1) {
			return str;
		}

		String[] arr = str.split("\\.");

		if (arr == null || arr.length != 2) {
			return str;
		}

		int strLen = arr[1].length();
		int cnt = 0;
		for (int i = strLen - 1 ; i >= 0; i-- ) {
			if (arr[1].charAt(i) == '0') {
				cnt++;
			}
			else {
				break;
			}
		}

		if (cnt == strLen) {
			return arr[0];
		}
		else {
			return str.substring(0, str.length() - cnt);
		}
	}

	private List<MaterialSumReqVO> selectDynamicSustainabilityTable(MaterialSumReqDTO reqDTO) {
		List<MaterialSumReqVO> sumReqList = new ArrayList<>();

		String labNoteCd = reqDTO.getVLabNoteCd();
		String contPkCd = reqDTO.getVContPkCd();
		int version = reqDTO.getNVersion();
		String lotCd = reqDTO.getVLotCd();
		int lotSort = reqDTO.getNLotSort();
		List<MaterialSumMateDTO> mateSumList = reqDTO.getMateSumList();

		if(!ObjectUtils.isEmpty(mateSumList)){
			for(int i = 0; i < mateSumList.size(); i++){
				sumReqList.add(MaterialSumReqVO.builder()
						.vLabNoteCd(labNoteCd)
						.vContPkCd(contPkCd)
						.nVersion(version)
						.nLotSort(lotSort)
						.vLotCd(lotCd)
						.vMatePkCd(mateSumList.get(i).getVMatePkCd())
						.vMateCd(mateSumList.get(i).getVMateCd())
						.nRate(mateSumList.get(i).getVMateRate())
						.build());
			}
		}
		return sumReqList;
	}

	private List<MaterialGradeSumVO> labNoteMateSustainabilityGradeAjax(MaterialSumReqDTO reqDTO) {
		List<MaterialGradeSumVO> list = null;

		List<MaterialSumReqVO> sumReqList = this.selectDynamicSustainabilityTable(reqDTO);
		if(!ObjectUtils.isEmpty(sumReqList)) {
			list = hbdMaterialMapper.selectLabNoteMateGradeSum(MaterialGradeSumVO.builder()
					.vLabNoteCd(reqDTO.getVLabNoteCd())
					.sumReqList(sumReqList)
					.build());
		}

		return list;
	}

	private List<MaterialMateSumVO> labNoteMateNeutralizationAjax(MaterialSumReqDTO reqDTO) {
		List<MaterialMateSumVO> list = null;

		List<MaterialSumReqVO> sumReqList = this.selectDynamicSustainabilityTable(reqDTO);
		if(!ObjectUtils.isEmpty(sumReqList)) {
			list = hbdMaterialMapper.selectLabNoteMateNeutralization(MaterialSearchVO.builder()
					.vLabNoteCd(reqDTO.getVLabNoteCd())
					.sumReqList(sumReqList)
					.vSearchType("DYNAMIC")
					.build());
		}

		return list;
	}

	private Map<String , String> selectLabNoteMateGradeWeightedSum(List<MaterialGradeSumVO> list) {
		Map<String, String> scoreMap = null;
		Map<String, String> weMap =	null;

		if (!list.isEmpty()) {
			weMap = new HashMap<>();
			scoreMap = new HashMap<>();

			weMap.put("CATE001", "0.7");
			weMap.put("CATE002", "0.2");
			weMap.put("CATE003", "0.1");

			String wekey = "";
			String scorekey = "";

			String arrKey[] = null;

			double sumScore = 0d;

			for(MaterialGradeSumVO tempVO : list) {
				arrKey = tempVO.getVKey().split("_");

				scorekey =  arrKey[0];
				wekey = arrKey[1];

				if(scoreMap.containsKey(scorekey)) {
					sumScore = Double.parseDouble(scoreMap.get(scorekey)) + (tempVO.getNCateScore() * Double.parseDouble(weMap.get(wekey)));
				}
				else {
					sumScore = tempVO.getNCateScore() * Double.parseDouble(weMap.get(wekey));
				}

				sumScore = Math.round(sumScore * 10) / 10.0;
				scoreMap.put(scorekey, String.valueOf(sumScore));
			}
		}
		return scoreMap;
	}

	private String labNoteMatePriceSumAjax (MaterialSumReqDTO reqDTO) {
		String sum_price = "";

		try {
			List<MaterialSumMateDTO> mateSumList = reqDTO.getMateSumList();
			BigDecimal capacity = new BigDecimal(reqDTO.getNCapacity());
			BigDecimal priceSum = new BigDecimal(0);
			BigDecimal mateRate = new BigDecimal(0);
			BigDecimal mateSimplePrice = new BigDecimal(0);
			BigDecimal per = new BigDecimal(100);

			if(!ObjectUtils.isEmpty(mateSumList)) {
				for(int i = 0; i < mateSumList.size(); i++) {

					if(StringUtils.isEmpty(mateSumList.get(i).getVMateRate())) {
						continue;
					}

					try {
						mateRate = new BigDecimal(mateSumList.get(i).getVMateRate());
					}
					catch (NumberFormatException nfe) {
						mateRate = new BigDecimal(0);
					}

					mateSimplePrice = new BigDecimal(mateSumList.get(i).getVMateSimplePrice());

					priceSum = priceSum.add(mateRate.multiply(capacity).multiply(mateSimplePrice).divide(per));
				}
			}

			sum_price = this.selectPointZeroDel(priceSum == null ? "" : priceSum.toPlainString());

		}
		catch (Exception e) {
			log.error("labNoteMatePriceSumAjax Error - ", e.toString());
		}

		return sum_price;
	}

	@Transactional
	public ResponseVO insertLabNoteList (HbdMaterialSaveRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();

		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		String userAgent = CommonUtil.getByteString(request.getHeader("User-Agent"), 2600);

		String vUserid = sessionUtil.getLoginId();

		if(!ObjectUtils.isEmpty(regDTO.getDelGrpCdList())) {
			regDTO.getDelGrpCdList().forEach(o -> {
				hbdMaterialMapper.deleteLabNoteGroup(HbdNoteGroupVO.builder()
						.vGrpCd(o)
						.vUpdateUserid(vUserid)
						.build());
			});
		}

		Map<String, String> grpMap = new HashMap<>();

		if(!ObjectUtils.isEmpty(regDTO.getGroupList())) {
			regDTO.getGroupList().forEach(o -> {
				if(StringUtils.isNotEmpty(o.getVGrpCd())) {
					if(o.getVGrpCd().indexOf("temp_grp_") > -1) {
						String addGrpCd = o.getVGrpCd();

						HbdNoteGroupVO groupVO = HbdNoteGroupVO.builder()
								.vLabNoteCd(o.getVLabNoteCd())
								.vContPkCd(o.getVContPkCd())
								.nVersion(o.getNVersion())
								.vGrpNm(o.getVGrpNm())
								.nSort(o.getNSort())
								.vFlagGrpHide(o.getVFlagGrpHide())
								.vRegUserid(vUserid)
								.vUpdateUserid(vUserid)
								.build();

						hbdMaterialMapper.insertLabNoteGroup(groupVO);

						grpMap.put(addGrpCd, groupVO.getVGrpCd());
					}
					else {
						hbdMaterialMapper.updateLabNoteGroup(HbdNoteGroupVO.builder()
								.vGrpCd(o.getVGrpCd())
								.vGrpNm(o.getVGrpNm())
								.nSort(o.getNSort())
								.vFlagGrpHide(o.getVFlagGrpHide())
								.vUpdateUserid(vUserid)
								.build());
					}
				}
			});
		}

		if(!ObjectUtils.isEmpty(regDTO.getDelMatePkCdList())) {
			regDTO.getDelMatePkCdList().forEach(o -> {
				hbdCommonService.deleteLabNoteMate(HbdNoteMateVO.builder()
						.vMatePkCd(o)
						.vUpdateUserid(vUserid)
						.build());
			});
		}

		Map<String, String> matePkCdMap = new HashMap<>();

		if(!ObjectUtils.isEmpty(regDTO.getMateList())) {
			regDTO.getMateList().forEach(o -> {
				if (StringUtils.isEmpty(o.getVMateCd()) && StringUtils.isEmpty(o.getVMateDbMstCd())) {
					log.debug("vMateCd, vMateDbMstCd is Empty! continue process.");
				}
				else {
					String vGrpCd = o.getVGrpCd();
					if(StringUtils.isNotEmpty(vGrpCd) && vGrpCd.indexOf("temp_grp_") > -1) {
						vGrpCd = grpMap.get(vGrpCd);
					}

					if (StringUtils.isEmpty(o.getVMatePkCd()) || o.getVMatePkCd().indexOf("add_mate_pk_cd_") > -1) {
						String addMatePkCd = o.getVMatePkCd();

						HbdNoteMateVO mateVO = HbdNoteMateVO.builder()
								.vContPkCd(o.getVContPkCd())
								.nVersion(o.getNVersion())
								.vLabNoteCd(o.getVLabNoteCd())
								.vGrpCd(vGrpCd)
								.vMateCd(o.getVMateCd())
								.vMateDbTypeCd(o.getVMateDbTypeCd())
								.vMateDbMstCd(o.getVMateDbMstCd())
								.vMateNm(o.getVMateNm())
								.nReqRate(o.getNReqRate())
								.vFlagReq(o.getVFlagReq())
								.nCounterRate(o.getNCounterRate())
								.vFlagCounter(o.getVFlagCounter())
								.vFlagMateHide(o.getVFlagMateHide())
								.vFlagMateCheck(o.getVFlagMateCheck())
								.nSort(o.getNSort())
								.vRamaMemoTxt(o.getVRamaMemoTxt())
								.vFlagMainIngredientMate(o.getVFlagMainIngredientMate())
								.vRegUserid(vUserid)
								.vUpdateUserid(vUserid)
								.build();
						hbdMaterialMapper.insertLabNoteMate(mateVO);

						o.setVMatePkCd(mateVO.getVMatePkCd());
						matePkCdMap.put(addMatePkCd, mateVO.getVMatePkCd());
					}
					else {
						hbdMaterialMapper.updateLabNoteMate(HbdNoteMateVO.builder()
								.vMatePkCd(o.getVMatePkCd())
								.vGrpCd(vGrpCd)
								.vMateCd(o.getVMateCd())
								.vMateDbTypeCd(o.getVMateDbTypeCd())
								.vMateDbMstCd(o.getVMateDbMstCd())
								.vMateNm(o.getVMateNm())
								.nCounterRate(o.getNCounterRate())
								.vFlagCounter(o.getVFlagCounter())
								.vFlagMateHide(o.getVFlagMateHide())
								.vFlagMateCheck(o.getVFlagMateCheck())
								.nSort(o.getNSort())
								.vRamaMemoTxt(o.getVRamaMemoTxt())
								.vFlagMainIngredientMate(o.getVFlagMainIngredientMate())
								.vUpdateUserid(vUserid)
								.build());
					}

					if(StringUtils.isNotEmpty(o.getVMateCd()) && o.getVMateCd().startsWith("4")){ // 4자코드 원료처방 저장
						labNoteCommonService.insertHal4Mate(Hal4MateRegDTO.builder()
								.vMateCd(o.getVMateCd())
								.vPlantCd(regDTO.getVPlantCd())
								.vLand1(regDTO.getVLand1())
								.build());
					}
				}
			});
		}

		if(!ObjectUtils.isEmpty(regDTO.getLotList())) {
			List<HbdNoteLotVO> lotList = hbdMaterialMapper.selectElabNoteLotList(regDTO);

			regDTO.getLotList().forEach(lot -> {
				boolean canInsertRate = false;  // lot 함량 변경여부
				Map<String, String> vLotCd = new HashMap<>();

				if(StringUtils.isEmpty(lot.getVLotCd()) || lot.getVLotCd().indexOf("tmp_lot_") > -1) {
					HbdNoteLotVO lotVO = HbdNoteLotVO.builder()
							.vLabNoteCd(lot.getVLabNoteCd())
							.vContPkCd(lot.getVContPkCd())
							.nVersion(lot.getNVersion())
							.vLotNm(lot.getVLotNm())
							.vFlagLotHide(lot.getVFlagLotHide())
							.nGramOpenNum(lot.getNGramOpenNum())
							.vLotMemo(lot.getVLotMemo())
							.vFlagStability(lot.getVFlagStability())
							.vFlagUse(lot.getVFlagUse())
							.vFlagSend(lot.getVFlagSend())
							.nSort(lot.getNSort())
							.vRegUserid(vUserid)
							.vUpdateUserid(vUserid)
							.build();
					hbdMaterialMapper.insertLabNoteLot(lotVO);

					vLotCd.put("vLotCd", lotVO.getVLotCd());
					lot.setVLotCd(lotVO.getVLotCd());
				}
				else {
					if(StringUtils.isNotEmpty(lot.getVLotMemo())) {
						hbdMaterialMapper.updateLabNoteLot(HbdNoteLotVO.builder()
								.vLotCd(lot.getVLotCd())
								.vLotNm(lot.getVLotNm())
								.vFlagLotHide(lot.getVFlagLotHide())
								.nGramOpenNum(lot.getNGramOpenNum())
								.vLotMemo(lot.getVLotMemo())
								.vFlagStability(lot.getVFlagStability())
								.vFlagUse(lot.getVFlagUse())
								.vFlagSend(lot.getVFlagSend())
								.vUpdateUserid(vUserid)
								.build());
					}

					vLotCd.put("vLotCd", lot.getVLotCd());
				}

				if(!ObjectUtils.isEmpty(lot.getGramList())) {
					lot.getGramList().forEach(gram -> {
						if(StringUtils.isEmpty(gram.getVGramCd()) || gram.getVGramCd().indexOf("tmp_gram_") > -1 || gram.getVLotCd().indexOf("tmp_lot_") > -1) {
							String vGramLotCd = gram.getVLotCd();
							if(gram.getVLotCd().indexOf("tmp_lot_") > -1) {
								vGramLotCd = vLotCd.get("vLotCd");
							}

							hbdMaterialMapper.insertLabNoteGram(HbdNoteGramVO.builder()
									.vLotCd(vGramLotCd)
									.nGram(gram.getNGram())
									.nSort(gram.getNSort())
									.vRegUserid(vUserid)
									.vUpdateUserid(vUserid)
									.build());
						}
						else {
							if(gram.getVGramCd().indexOf("tmp_gram_") < 0 && "Y".equals(gram.getVFlagSave())) {
								hbdMaterialMapper.updateLabNoteGram(HbdNoteGramVO.builder()
										.vGramCd(gram.getVGramCd())
										.nGram(gram.getNGram())
										.nSort(gram.getNSort())
										.vUpdateUserid(vUserid)
										.build());
							}
						}
					});
				}

				int lotCnt = (int) lotList.stream()
						.filter(o -> o.getVLotCd().equals(vLotCd.get("vLotCd")))
						.count();
				HbdNoteLotVO lotVO = lotCnt > 0 ? lotList.stream()
						.filter(o -> o.getVLotCd().equals(vLotCd.get("vLotCd")))
						.findFirst()
						.get() : null;

				if(ObjectUtils.isEmpty(lotVO) || !"Y".equals(lotVO.getVFlagComplete())) {
					canInsertRate = true;
				}

				if(canInsertRate) {
					Map<String, Boolean> pilotValid = new HashMap<>();
					pilotValid.put("valid", false);
					pilotValid.put("rateLog", true);

					if(!ObjectUtils.isEmpty(lot.getRateList())) {
						lot.getRateList().forEach(rate -> {
							if("Y".equals(rate.getVFlagRateRest()) || "Y".equals(rate.getVFlagSave()) ) {
								if(pilotValid.get("rateLog")) {
									pilotValid.put("rateLog", false);

									String vHisRegDtm = CommonUtil.getNowDate("yyyyMMddHHmmss");
									labNoteCommonService.insertELabHisLotChg(ElabHisLotChgVO.builder()
											.vLotCd(lot.getVLotCd())
											.vNoteType("HBO")
											.vUserAgent(userAgent)
											.vRegUserid(vUserid)
											.vRegDtm(vHisRegDtm)
											.build());
									hbdMaterialMapper.insertELabHisPreRate(ElabHisPreRateVO.builder()
											.vLotCd(lot.getVLotCd())
											.vRegDtm(vHisRegDtm)
											.build());
								}

								String vMatePkCd = matePkCdMap.get(rate.getVMatePkCd());

								if(StringUtils.isNotEmpty(vMatePkCd)) {
									rate.setVMatePkCd(vMatePkCd);
								}

								hbdMaterialMapper.insertLabNoteRate(HbdNoteRateVO.builder()
										.vLotCd(lot.getVLotCd())
										.vMatePkCd(rate.getVMatePkCd())
										.nRate(rate.getNRate())
										.vFlagRateRest(rate.getVFlagRateRest())
										.vMateDbLotCd(rate.getVMateDbLotCd())
										.vRegUserid(vUserid)
										.vUpdateUserid(vUserid)
										.build());
							}

							pilotValid.put("valid", true);
						});
					}

					if(pilotValid.get("valid")) {
						hbdCommonService.updateLabNoteLotPilot(LotPilotRegDTO.builder()
								.vContPkCd(lot.getVContPkCd())
								.nVersion(lot.getNVersion())
								.vLotCd(lot.getVLotCd())
								.vLand1(regDTO.getVLand1())
								.vSiteType(regDTO.getVSiteType())
								.build()
								, regDTO.getVCodeType());
					}
				}
			});
		}

//		TOBE lot show/hide 는 right menu 에서 제어함
//		hbdMaterialMapper.updateLabNoteAllLotExposureN(HbdNoteLotVO.builder()
//				.vContPkCd(regDTO.getVContPkCd())
//				.nVersion(regDTO.getNVersion())
//				.vUpdateUserid(vUserid)
//				.build());
//
//		if(!ObjectUtils.isEmpty(vLotCdList)) {
//			hbdMaterialMapper.updateLabNoteLotExposureY(HbdNoteLotExpoureYVO.builder()
//					.vLotCdList(vLotCdList)
//					.vUpdateUserid(vUserid)
//					.build());
//		}

		HbdNoteVersionDTO versionDTO = regDTO.getVersionDTO();
		hbdMaterialMapper.updateLabNoteVersion(HbdNoteVersionVO.builder()
				.vContPkCd(versionDTO.getVContPkCd())
				.nVersion(versionDTO.getNVersion())
				.vFlagPriceHide(versionDTO.getVFlagPriceHide())
				.vFlagMaxmixHide(versionDTO.getVFlagMaxmixHide())
				.vFlagReqHide(versionDTO.getVFlagReqHide())
				.vFlagExistHide(versionDTO.getVFlagExistHide())
				.vFlagInpMethod(versionDTO.getVFlagInpMethod())
				.vCounterCd(versionDTO.getVCounterCd())
				.vCounterContPkCd(versionDTO.getVCounterContPkCd())
				.vVersionNm(versionDTO.getVVersionNm())
				.vUpdateUserid(vUserid)
				.build());

		if("LNC06_21".equals(regDTO.getVStatusCd())){
			hbdMaterialMapper.updateStatusCd_LNC06_22(HbdNoteMstVO.builder()
					.vLabNoteCd(regDTO.getVLabNoteCd())
					.vUpdateUserid(vUserid)
					.build());

			commonService.sendAlarm(AlarmRegDTO.builder()
					.vLabNoteCd(regDTO.getVLabNoteCd())
					.vStatusCd("AL_NOTE2")
					.vAlrTypeCd("AL_NOTE2_02")
					.typeList(List.of(Const.TIMELINE, Const.SCHEDULE))
					.vContCd(regDTO.getVContCd())
					.vContNm(regDTO.getVContNm())
					.nVerNo(regDTO.getNVersion() < 10 ? "0" + regDTO.getNVersion() : Integer.toString(regDTO.getNVersion()))
					.vNoteType("HBO")
					.build());
		}

		// 글로벌 금지/제한, 문제이력 확인 처리
		hbdMaterialMapper.updateLabNoteMateCheckSharing(HbdNoteMateVO.builder()
				.vLabNoteCd(regDTO.getVLabNoteCd())
				.vUpdateUserid(vUserid)
				.build());

		responseVO.setOk(grpMap);
		return responseVO;
	}

	@Transactional
	public ResponseVO insertLabNoteNewVersion(MaterialVersionRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();

		String vflagAllLaunchComplete = null;
		String vUserid = sessionUtil.getLoginId();

		List<String> labNoteCdList = new ArrayList<>();
		List<FinalLotVO> list = hbdCommonService.selectLabNoteFinalLot(BookmarkReqDTO.builder()
				.vGetType("List")
				.vLabNoteCd(regDTO.getVLabNoteCd())
				.build());

		if(!ObjectUtils.isEmpty(list)) {

			labNoteCdList = list.stream()
					.distinct()
					.map(o -> o.getVLabNoteCd())
					.collect(Collectors.toList());

			vflagAllLaunchComplete = hbdMaterialMapper.selectLabNoteFlagAllLaunchComplete(regDTO.getVLabNoteCd());
			if("Y".equals(vflagAllLaunchComplete)) {
				hbdMaterialMapper.updateLabNoteStats01(ElabStats01VO.builder()
						.vLabNoteCd(regDTO.getVLabNoteCd())
						.vLaunchCompleteType("MST")
						.vSignType("minus")
						.build());
				hbdMaterialMapper.updateLabNoteStats02(ElabStats02VO.builder()
						.vLabNoteCd(regDTO.getVLabNoteCd())
						.vLaunchCompleteType("MST")
						.vSignType("minus")
						.build());
				hbdMaterialMapper.updateLabNoteStats03(ElabStats03VO.builder()
						.vLabNoteCd(regDTO.getVLabNoteCd())
						.vLaunchCompleteType("MST")
						.vSignType("minus")
						.build());
			}

			list.forEach(o -> {
				hbdMaterialMapper.updateLabNoteStats01(ElabStats01VO.builder()
						.vContPkCd(o.getVContPkCd())
						.vLaunchCompleteType("CONT")
						.vSignType("minus")
						.build());
				hbdMaterialMapper.updateLabNoteStats02(ElabStats02VO.builder()
						.vContPkCd(o.getVContPkCd())
						.vLaunchCompleteType("CONT")
						.vSignType("minus")
						.build());
				hbdMaterialMapper.updateLabNoteStats03(ElabStats03VO.builder()
						.vContPkCd(o.getVContPkCd())
						.vLaunchCompleteType("CONT")
						.vSignType("minus")
						.build());

				hbdCommonService.deleteFinalVersionToRate(o.getVLotCd());
				hbdCommonService.deleteFinalVersionToMate(o.getVContPkCd(), o.getNVersion());
				hbdMaterialMapper.deleteFinalVersionToLot(HbdNoteLotVO.builder()
						.vLotCd(o.getVLotCd())
						.build());
				hbdMaterialMapper.deleteFinalVersion(HbdNoteVersionVO.builder()
						.vContPkCd(o.getVContPkCd())
						.nVersion(o.getNVersion())
						.build());

				HbdNoteInfoDTO rvo = hbdCommonService.selectLabNoteInfo(regDTO.getVLabNoteCd());

				if(!ObjectUtils.isEmpty(rvo)) {
					String labLeaderid = commonService.selectLabLeaderid(rvo.getVDeptCd());

					commonService.sendAlarm(AlarmRegDTO.builder()
							.vLabNoteCd(regDTO.getVLabNoteCd())
							.vStatusCd("AL_NOTE4")
							.vAlrTypeCd("AL_NOTE4_05")
							.typeList(List.of(Const.TIMELINE, Const.ALARM))
							.vContCd(regDTO.getVContCd())
							.vContNm(regDTO.getVContNm())
							.nVerNo(o.getVVersionNm())
							.vLotNm(o.getVLotNm())
							.vNoteType("HBO")
							// CTC담당자 / 랩장
							.userList(Arrays.asList(rvo.getVCtcUserid(),
									labLeaderid))
							.vMoveUrl(regDTO.getVMoveUrl())
							.build());
				}
			});

			hbdMaterialMapper.updateLabNoteResetHistory(regDTO);
		}

		int lastVer = hbdMaterialMapper.selectLabNoteMstLastVersion(regDTO);

		hbdMaterialMapper.insertLabNoteMstNewVersion(HbdNoteMstVerVO.builder()
				.vLabNoteCd(regDTO.getVLabNoteCd())
				.nVersion(lastVer + 1)
				.vRegUserid(vUserid)
				.vUpdateUserid(vUserid)
				.build());
		hbdMaterialMapper.insertLabNoteNewVersion(HbdNoteVersionVO.builder()
				.vLabNoteCd(regDTO.getVLabNoteCd())
				.nVersion(lastVer + 1)
				.build());

		//HBD 에어로졸 정보 추가 저장부분
		hbdMaterialMapper.insertLabNoteAerosolContMate(HbdNoteMateVO.builder()
				.vLabNoteCd(regDTO.getVLabNoteCd())
				.nVersion(lastVer + 1)
				.vRegUserid(vUserid)
				.vUpdateUserid(vUserid)
				.build());

		hbdMaterialMapper.insertLabNotePreMstVerTag(HbdNoteMstVerTagVO.builder()
				.vLabNoteCd(regDTO.getVLabNoteCd())
				.nVersion(lastVer + 1)
				.nPreVersion(lastVer)
				.vRegUserid(vUserid)
				.vUpdateUserid(vUserid)
				.build());
		hbdMaterialMapper.insertLabNotePreVerMate(HbdNoteMateVO.builder()
				.vLabNoteCd(regDTO.getVLabNoteCd())
				.nVersion(lastVer + 1)
				.nPreVersion(lastVer)
				.vRegUserid(vUserid)
				.vUpdateUserid(vUserid)
				.build());

		hbdMaterialMapper.updateLabNoteLotFlagDecideN(regDTO.getVLabNoteCd());

		hbdMaterialMapper.updateLabNoteResCostReset(regDTO.getVLabNoteCd());

		hbdMaterialMapper.updateLabNoteContReset(HbdNoteContVO.builder()
				.vLabNoteCd(regDTO.getVLabNoteCd())
				.vUpdateUserid(vUserid)
				.build());
		hbdMaterialMapper.updateLabNoteVersionReset(regDTO.getVLabNoteCd());

		int result = hbdMaterialMapper.updateStatusCd_LNC06_22(HbdNoteMstVO.builder()
				.vLabNoteCd(regDTO.getVLabNoteCd())
				.vFlagCompleteReset("Y")
				.vUpdateUserid(vUserid)
				.build());

		if(result > 0) {
			if(!labNoteCdList.isEmpty()) {
				List<String> completeDtList = hbdMaterialMapper.selectLabNoteCompleteDtList(labNoteCdList);

				if(!ObjectUtils.isEmpty(completeDtList)) {
					completeDtList = completeDtList.stream()
							.distinct()
							.collect(Collectors.toList());

					completeDtList.forEach(o -> {
						hbdMaterialMapper.procElabSustainabilityStatsPr(o);
					});
				}
			}

			commonService.sendAlarm(AlarmRegDTO.builder()
					.vLabNoteCd(regDTO.getVLabNoteCd())
					.vStatusCd("AL_NOTE2")
					.vAlrTypeCd("AL_NOTE2_04")
					.typeList(List.of(Const.TIMELINE))
					.vContCd(regDTO.getVContCd())
					.vContNm(regDTO.getVContNm())
					.nVerNo(lastVer + 1 < 10 ? "0" + (lastVer + 1) : Integer.toString(lastVer + 1))
					.vNoteType("HBO")
					.build());

			responseVO.setOk("버전 추가 되었습니다");
		}
		else {
			responseVO.setOk("버전 추가에 실패했습니다");
		}

		return responseVO;
	}

	@Transactional
	public ResponseVO updateLabNoteLotBookmark(MaterialLotBookmarkRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();

		int result = hbdMaterialMapper.updateLabNoteLotBookmark(regDTO.getVLotCd());

		if(result > 0){
			responseVO.setOk("등록되었습니다");
		}
		else {
			responseVO.setOk("등록에 실패하였습니다");
		}

		return responseVO;
	}

	@Transactional
	public ResponseVO deleteLabNoteLotBookmark(MaterialLotBookmarkRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();

		int result = hbdMaterialMapper.deleteLabNoteLotBookmark(regDTO.getVLotCd());

		if(result > 0){
			responseVO.setOk("삭제하였습니다");
		}
		else {
			responseVO.setOk("삭제에 실패하였습니다");
		}

		return responseVO;
	}

	@Transactional
	public ResponseVO updateLabNoteApplyPlant(MaterialPlantRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();

		hbdMaterialMapper.updateLabNoteApplyMstPlant(HbdNoteMstVO.builder()
				.vLabNoteCd(regDTO.getVLabNoteCd())
				.vPlantCd(regDTO.getVPlantCd())
				.nCapacity(regDTO.getNCapacity())
				.build());

		int result = hbdMaterialMapper.updateLabNoteApplyContPlant(HbdNoteContVO.builder()
				.vContPkCd(regDTO.getVContPkCd())
				.vPlantCd(regDTO.getVPlantCd())
				.build());

		if(result > 0){
			responseVO.setOk("적용되었습니다");
		}
		else {
			responseVO.setOk("적용에 실패하였습니다");
		}

		return responseVO;
	}

	@Transactional
	public ResponseVO insertLabNoteTestResult(TestResultRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();

		String vUserid = sessionUtil.getLoginId();
		String language = sessionUtil.getLangCd();

		hbdMaterialMapper.updateLabNoteTestResLot(HbdNoteLotVO.builder()
				.vLotCd(regDTO.getVLotCd())
				.vTestType(regDTO.getVTestType())
				.vTestValue(regDTO.getVTestValue())
				.vPh(regDTO.getVPh())
				.vUpdateUserid(vUserid)
				.build());

		labNoteCommonService.insertElabLotMemo(ElabLotMemoVO.builder()
				.vLotCd(regDTO.getVLotCd())
				.nSeqno(1)
				.vTitle("안정도")
				.vContent(regDTO.getVLotTestMemo())
				.vFlagStability(regDTO.getVFlagStability())
				.vFlagDel("N")
				.vRegUserid(vUserid)
				.vUpdateUserid(vUserid)
				.build());

		hbdMaterialMapper.updateLabNoteGramDt(HbdNoteGramVO.builder()
				.vGramCd(regDTO.getVGramCd())
				.vTestStDt(regDTO.getVTestStDt())
				.vTestEnDt(regDTO.getVTestEnDt())
				.vUpdateUserid(vUserid)
				.build());

		this.insertLabNoteStabilityTitle(StabilityReqDTO.builder()
				.vLabNoteCd(regDTO.getVLabNoteCd())
				.vLotCd(regDTO.getVLotCd())
				.stabilityCdList(regDTO.getStabilityCdList())
				.build());

		if(!ObjectUtils.isEmpty(regDTO.getDelGramTrCdList())) {
			regDTO.getDelGramTrCdList().forEach(o -> {
				hbdMaterialMapper.deleteLabNoteGramTr(HbdNoteGramTrVO.builder()
						.vGramTrCd(o)
						.vUpdateUserid(vUserid)
						.build());
			});
		}

		List<StabilityTitleVO> list = hbdMaterialMapper.selectLabNoteStabilityTitleList(GramReqDTO.builder()
				.vLotCd(regDTO.getVLotCd())
				.language(language)
				.build());

		List<HbdNoteGramTrVO> gramTrList = hbdMaterialMapper.selectLabNoteGramTrList(regDTO.getVGramCd());

		if(!ObjectUtils.isEmpty(regDTO.getTestResultGramTrList())) {
			regDTO.getTestResultGramTrList().forEach(o -> {
				if(!"Y".equals(o.getVFlagTestPass()) && StringUtils.isEmpty(o.getVResTestDt())) {
					log.debug("값이 없을 경우 패스");
				}
				else {
					HbdNoteGramTrVO gramTrVO = HbdNoteGramTrVO.builder()
							.vGramCd(regDTO.getVGramCd())
							.nSeqno(o.getNSeqno())
							.vPlanTestDt(o.getVPlanTestDt())
							.vResTestDt(o.getVResTestDt())
							.vFlagTestPass(o.getVFlagTestPass())
							.nResCol01(o.getNResCol01())
							.nResCol02(o.getNResCol02())
							.vStabilityNote(o.getVStabilityNote())
							.vFlagSave(o.getVFlagSave())
							.vRegUserid(vUserid)
							.vUpdateUserid(vUserid)
							.build();

					if(StringUtils.isEmpty(o.getVGramTrCd()) || o.getVGramTrCd().indexOf("tmp_gram_tr_") > -1
							|| (ObjectUtils.isEmpty(gramTrList) || gramTrList.stream().filter(gt -> gt.getVGramTrCd().equals(o.getVGramTrCd())).count() == 0)) {
						hbdMaterialMapper.insertLabNoteGramTr(gramTrVO);
					}
					else {
						gramTrVO.setVGramTrCd(o.getVGramTrCd());

						hbdMaterialMapper.updateLabNoteGramTr(gramTrVO);
					}

					if(!ObjectUtils.isEmpty(list)) {
						list.forEach(vo -> {
							String vFlagStability = null;
							if(!ObjectUtils.isEmpty(o.getFlagStabilityList())) {
								for(TestResultFlagDTO flagVO : o.getFlagStabilityList()) {
									if(flagVO.getVStabilityCd().equals(vo.getVSubCode())) {
										vFlagStability = flagVO.getVFlagStability();
										break;
									}
								}
							}

							hbdMaterialMapper.insertLabNoteStabilityValue(HbdNoteStabilityValueVO.builder()
									.vLotCd(regDTO.getVLotCd())
									.vGramTrCd(gramTrVO.getVGramTrCd())
									.vStabilityCd(vo.getVSubCode())
									.vFlagStability(vFlagStability)
									.build());
						});
					}
				}
			});
		}

		commonService.sendAlarm(AlarmRegDTO.builder()
				.vLabNoteCd(regDTO.getVLabNoteCd())
				.vStatusCd("AL_NOTE2")
				.vAlrTypeCd("AL_NOTE2_05")
				.typeList(List.of(Const.TIMELINE))
				.vContCd(regDTO.getVContCd())
				.vContNm(regDTO.getVContNm())
				.nVerNo(regDTO.getNVersion() < 10 ? "0" + regDTO.getNVersion() : Integer.toString(regDTO.getNVersion()))
				.vLotNm(regDTO.getVLotNm())
				.vExamNm("안정도")
				.vNoteType("HBO")
				.build());

//		TOBE - 삭제는 delGramTrCdList 로 대체
//		if(!ObjectUtils.isEmpty(gramTrList)) {
//			gramTrList.forEach(o -> {
//				hbdMaterialMapper.deleteLabNoteGramTr(HbdNoteGramTrVO.builder()
//						.vGramTrCd(o.getVGramTrCd())
//						.vUpdateUserid(vUserid)
//						.build());
//			});
//		}

//		TOBE - 시험의뢰시 LOT 완료일 업데이트 하도록 변경
//		if("Y".equals(regDTO.getVFlagFristSave())) {
//			ValidateVO validateVO = hbdCommonService.selectLabNoteValidate(ValidateVO.builder()
//					.vContPkCd(regDTO.getVContPkCd())
//					.nVersion(regDTO.getNVersion())
//					.vLotCd(regDTO.getVLotCd())
//					.build());
//
//			if(validateVO.getNSumRate() != 100) {
//				responseVO.setOk(Const.FAIL);
//				return responseVO;
//			}

//			hbdMaterialMapper.updateStatusCd_LNC06_31(HbdNoteMstVO.builder()
//					.vLabNoteCd(regDTO.getVLabNoteCd())
//					.vUpdateUserid(vUserid)
//					.build());
//		}

		responseVO.setOk(Const.SUCC);
		return responseVO;
	}

	@Transactional
	public ResponseVO updateLabNoteLotSendBom(SendBomRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();
		Object message = Const.SUCC;

		String precedePkCd = hbdCommonService.selectLabNotePrecedePkCd();

		if(!ObjectUtils.isEmpty(regDTO.getSendBomList())) {
			ResponseVO response = null;
			for(LotDecideRegDTO sendBom : regDTO.getSendBomList()) {
				response = hbdCommonService.updateLabNoteEachLotSendBom(LotDecideRegDTO.builder()
						.vPrecedePkCd(precedePkCd)
						.vLabNoteCd(regDTO.getVLabNoteCd())
						.vContPkCd(sendBom.getVContPkCd())
						.nVersion(sendBom.getNVersion())
						.vLotCd(sendBom.getVLotCd())
						.build()
						, "Y", StringUtils.defaultIfEmpty(sendBom.getVBomType(), Const.BOM_PRECEDE));

				if(!Const.SUCC.equals(response.getData())) {
					message = response.getData();
					break;
				}
			}
		}

		if(StringUtils.isNotEmpty(regDTO.getVFlagSaveContCd())) {
			String userId = sessionUtil.getLoginId();

			if(!ObjectUtils.isEmpty(regDTO.getShelfLifeList())) {
				regDTO.getShelfLifeList().forEach(o -> {
					String contType = "HAL4";
					if(o.getVContCd().startsWith("3")) {
						contType = "HAL3";
					}

					//대표플랜트 저장
					labNoteCommonService.insertShelfLifeCont(ElabShelflifeContVO.builder()
							.vContCd(o.getVContCd())
							.vNoteType(o.getVNoteType())
							.vContType(contType)
							.vStatusCd("SLS020")
							.vShelfLife(o.getVShelfLife())
							.vRegUserid(userId)
							.vUpdateUserid(userId)
							.build());

					//서브플랜트가 존재한다면 함께 저장
					List<HbdNoteContVO> checkSubList = hbdMaterialMapper.selectCheckSubPlantList(HbdNoteContVO.builder()
							.vLabNoteCd(regDTO.getVLabNoteCd())
							.vContCd(o.getVContCd())
							.build());
					if(!ObjectUtils.isEmpty(checkSubList) && checkSubList.size() > 1) {
						//CONT테이블의 SUBPLANT컬럼 UPDATE
						labNoteCommonService.updateSubPlantFlag(o.getVContCd());

						//SUBPLANT테이블 삭제
						labNoteCommonService.deleteShelfLifeSubPlant(o.getVContCd());

						//SUBPLANT테이블에 저장
						checkSubList.forEach(sub -> {
							if(!sub.getVPlantCd().equals(o.getVPlantCd())) {
								labNoteCommonService.insertShelfLifeSubPlant(sub.getVContCd(), sub.getVPlantCd());
							}
						});
					}

					//사용기한 sap 전송
					labNoteCommonService.setElabShelfLifeSendSap(o.getVContCd());
				});
			}
		}

		responseVO.setOk(message.toString());
		return responseVO;
	}















	public ResponseVO selectLabNoteLotGramInfo(MaterialSearchVO schVO) {
		ResponseVO responseVO = new ResponseVO();

		MaterialLotVO lotVO = new MaterialLotVO();
		MaterialMateRateVO rateVO = new MaterialMateRateVO();

		schVO.setVLotConditionType("Vo");

		List<MaterialLotVO> lotList = hbdMaterialMapper.selectLabNoteLotGramList(schVO);
		if(!lotList.isEmpty()) {
			lotVO = lotList.stream().findFirst().get();
		}

		List<MaterialMateRateVO> rateList = hbdMaterialMapper.selectLabNoteMateRateMap(schVO);
		if(!rateList.isEmpty()) {
			rateVO = rateList.stream().findFirst().get();
		}

		List<MaterialMateSumVO> matePriceList = hbdMaterialMapper.selectLabNoteMatePriceSum(schVO);

		List<MaterialGradeSumVO> mateGradeList = hbdMaterialMapper.selectLabNoteMateGradeLotSum(MaterialGradeSumVO.builder()
				.vLabNoteCd(schVO.getVLabNoteCd())
				.vContPkCd(schVO.getVContPkCd())
				.nVersion(schVO.getNVersion())
				.vLotCd(schVO.getVLotCd())
				.build());

		schVO.setVSearchType("Lot");
		List<MaterialMateSumVO> mateNeutList = hbdMaterialMapper.selectLabNoteMateNeutralization(schVO);

		responseVO.setOk(LotGramResDTO.builder()
				.lotVO(lotVO)
				.rateVO(rateVO)
				.matePriceList(matePriceList)
				.mateGradeList(mateGradeList)
				.mateNeutList(mateNeutList)
				.build());
		return responseVO;
	}

	public ResponseVO selectLabNoteSubMateRateInfo(SubMateReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		List<SubMateVO> list = new ArrayList<>();

		String flagHal4 = reqDTO.getVFlagHal4();

		//ELAB_HAL4_MATE에만 원료가 존재하는 4자성분
		if("EHM".equals(flagHal4)) {
			if(StringUtils.isEmpty(reqDTO.getVLand1())) {
				responseVO.setOk("필수 입력값이 없습니다");
				return responseVO;
			}

			list = hbdMaterialMapper.selectLabNoteSubMateRateInfoVerNotNote(reqDTO);
		}
		else {
			if(StringUtils.isEmpty(reqDTO.getVMatePkCd())) {
				responseVO.setOk("필수 입력값이 없습니다");
				return responseVO;
			}

			reqDTO.setVContCd(reqDTO.getVMateCd());
			reqDTO.setVLotState(hbdMaterialMapper.selectLabNoteLotState(reqDTO));
			list = hbdMaterialMapper.selectLabNoteSubMateRateInfo(reqDTO);
		}

		responseVO.setOk(Optional.ofNullable(list)
				.orElseGet(() -> List.of()));
		return responseVO;
	}

//	----------------------------------------------------------------
//	POPUP
	public ResponseVO selectLabNoteBookmarkList(BookmarkReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();
		Map<String, List<CodeDTO>> plantList = null;
		List<BookmarkVO> list = null;

		reqDTO.setVSearchField(StringUtils.defaultIfEmpty(reqDTO.getVSearchField(), "SIMILAR"));
		reqDTO.setVFlagBookPop("Y");
		reqDTO.setLanguage(sessionUtil.getLangCd());

		String searchField = reqDTO.getVSearchField();

		if ("SAP".equals(searchField)) {
			plantList = commonService.selectCodeListMap(List.of("LAB_NOTE_PLANT"));
			List<CodeDTO> codeList = plantList.get("LAB_NOTE_PLANT").stream()
				.filter(o -> "U".equals(o.getVBuffer1()))
				.collect(Collectors.toList());
			plantList.put("LAB_NOTE_PLANT", codeList);
		}
		else {
			if ("SIMILAR".equals(searchField)) {
				if(sessionUtil.isSysadmin()){
					reqDTO.setVUserid(null);
				}
				else{
					reqDTO.setVUserid(sessionUtil.getLoginId());
				}
			}

			int totalCnt = hbdMaterialMapper.selectLabNoteBookmarkListCount(reqDTO);

			if (totalCnt > 0) {
				CommonUtil.setPaging(reqDTO, totalCnt);
				list = hbdMaterialMapper.selectLabNoteBookmarkList(reqDTO);
			}
		}

		responseVO.setOk(ResCommSearchInfoDTO.builder()
				.page(ConvertUtil.convert(reqDTO, PagingDTO.class))
				.list(Optional.ofNullable(list)
						.orElseGet(() -> List.of()))
				.build());
		return responseVO;
	}

	public ResponseVO selectLabNoteMatePlantCheck(BookmarkReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();
		responseVO.setOk(Optional.ofNullable(hbdMaterialMapper.selectLabNoteMatePlantCheck(reqDTO))
				.orElseGet(() -> List.of()));
		return responseVO;
	}

	public ResponseVO selectLabNoteBookmarkApplyList(BookmarkReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		String message = null;
		if("COUNTER".equals(reqDTO.getVSearchField())) {
			message = this.syncToSAP(reqDTO);
		}

		responseVO.setOkWithCode(Const.CODE
				, message
				, Optional.ofNullable(hbdMaterialMapper.selectLabNoteBookmarkApplyList(reqDTO)).orElseGet(() -> List.of()));
		return responseVO;
	}

	public String syncToSAP(BookmarkReqDTO reqDTO) {
		return hbdCommonService.syncToSAP(reqDTO);
	}

	@Transactional
	public ResponseVO insertLabNoteCounterSAPInfo(CounterSAPRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();

		if(!(regDTO.getVContCd().startsWith("3") || regDTO.getVContCd().startsWith("4") || regDTO.getVContCd().startsWith("J"))) {
			responseVO.setOk(CounterSAPResDTO.builder()
					.vMessage("올바른 내용물 코드가 아닙니다.")
					.build());
			return responseVO;
		}

		if("Y".equals(hbdMaterialMapper.selectLabNoteExistsContInfo(regDTO))) {
			responseVO.setOk(CounterSAPResDTO.builder()
					.vMessage("[".concat(regDTO.getVContCd()).concat("]가 이미 실험노트에 존재합니다."))
					.build());
			return responseVO;
		}

		if("N".equals(hbdMaterialMapper.selectZqmtExistsMatnrInfo(regDTO))) {
			responseVO.setOk(CounterSAPResDTO.builder()
					.vMessage("[".concat(regDTO.getVContCd()).concat("]는 존재하지 않습니다."))
					.build());
			return responseVO;
		}

		String userId = sessionUtil.getLoginId();

		HbdNoteMstVO regVO = HbdNoteMstVO.builder()
				.vPlantCd(regDTO.getVPlantCd())
				.vRegUserid(userId)
				.vUpdateUserid(userId)
				.build();

		hbdMaterialMapper.insertLabNoteMstCounterSAPInfo(regVO);
		hbdMaterialMapper.insertLabNoteMstVerCounterSAPInfo(HbdNoteMstVerVO.builder()
				.vLabNoteCd(regVO.getVLabNoteCd())
				.vRegUserid(userId)
				.vUpdateUserid(userId)
				.build());

		String vContNm = hbdMaterialMapper.selectZqmtContNm(HbdNoteContVO.builder()
				.vContCd(regDTO.getVContCd())
				.vPlantCd(regDTO.getVPlantCd())
				.build());

		HbdNoteContVO regContVO = HbdNoteContVO.builder()
				.vLabNoteCd(regVO.getVLabNoteCd())
				.vContCd(regDTO.getVContCd())
				.vContNm(vContNm)
				.vPlantCd(regDTO.getVPlantCd())
				.vCodeType(StringUtils.defaultIfEmpty(regDTO.getVCodeType(), "HAL3"))
				.vRegUserid(userId)
				.vUpdateUserid(userId)
				.build();
		hbdMaterialMapper.insertLabNoteContCounterSAPInfo(regContVO);
		hbdMaterialMapper.insertLabNoteVersionCounterSAPInfo(HbdNoteVersionVO.builder()
				.vContPkCd(regContVO.getVContPkCd())
				.vLabNoteCd(regVO.getVLabNoteCd())
				.vRegUserid(userId)
				.vUpdateUserid(userId)
				.build());
		hbdMaterialMapper.insertLabNoteFinalVersion(HbdNoteVersionVO.builder()
				.vContPkCd(regContVO.getVContPkCd())
				.vLabNoteCd(regVO.getVLabNoteCd())
				.vRegUserid(userId)
				.vUpdateUserid(userId)
				.build());

		HbdNoteLotVO regLotVO = HbdNoteLotVO.builder()
				.vLabNoteCd(regVO.getVLabNoteCd())
				.vContPkCd(regContVO.getVContPkCd())
				.vRegUserid(userId)
				.vUpdateUserid(userId)
				.build();
		hbdMaterialMapper.insertLabNoteFinalLot(regLotVO);

		labNoteCommonService.insertElabNoteFinalLotSAPInfo(LabNoteCommonSAPSyncDTO.builder()
				.vLabNoteCd(regVO.getVLabNoteCd())
				.vLotCd(regLotVO.getVLotCd())
				.vContPkCd(regContVO.getVContPkCd())
				.vNoteType("HBO")
				.build());

		String message = this.syncToSAP(BookmarkReqDTO.builder()
				.vContCd(regDTO.getVContCd())
				.vPlantCd(regDTO.getVPlantCd())
				.vLotCd(regLotVO.getVLotCd())
				.nVersion(0)
				.build());

		Optional.of(message).filter(o -> "동기화 실패".equals(o)).orElseThrow();

		responseVO.setOk(CounterSAPResDTO.builder()
				.vLabNoteCd(regVO.getVLabNoteCd())
				.vContPkCd(regContVO.getVContPkCd())
				.vContCd(regDTO.getVContCd())
				.vContNm(vContNm)
				.build());
		return responseVO;
	}

	public ResponseVO selectLabNoteMateRateInfo(MateRateReqVO reqVO) {
		return hbdCommonService.selectLabNoteMateRateInfo(reqVO);
	}

	public ResponseVO selcetLabNoteVersionList(VersionReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		reqDTO.setLanguage(sessionUtil.getLangCd());

		List<VersionContVO> list = hbdMaterialMapper.selectLabNoteContList(reqDTO);

		if(ObjectUtils.isEmpty(list)) {
			responseVO.setOk(Const.ERROR);
			return responseVO;
		}

		List<String> contPkCdList = list.stream()
				.map(o -> o.getVContPkCd())
				.collect(Collectors.toList());

		responseVO.setOk(VersionResDTO.builder()
				.contList(Optional.ofNullable(list)
						.orElseGet(() -> List.of()))
				.verList(Optional.ofNullable(hbdCommonService.selectLabNoteVersionList(contPkCdList))
						.orElseGet(() -> List.of()))
				.mstSetList(Optional.ofNullable(labNoteCommonService.selectNoteMstSetList(reqDTO.getVLabNoteCd()))
						.orElseGet(() -> List.of()))
				.build());
		return responseVO;
	}

	@Transactional
	public ResponseVO updateVersionView(VersionRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();

		if(!regDTO.getContVerList().isEmpty()) {
			regDTO.getContVerList().forEach(o -> {
				hbdMaterialMapper.updateVersionView(HbdNoteVersionVO.builder()
						.vContPkCd(o.getVContPkCd())
						.nVersion(o.getNVersion())
						.vFlagView(o.getVFlagView())
						.build());
			});
		}

		if(!ObjectUtils.isEmpty(regDTO.getMstSetList())) {
			labNoteCommonService.updateLabNoteMstSet(regDTO.getMstSetList());
		}

		hbdMaterialMapper.updateLotAddType(HbdNoteMstVO.builder()
				.vLabNoteCd(regDTO.getVLabNoteCd())
				.vLotAddType(regDTO.getVLotAddType())
				.build());

		responseVO.setOk(Const.SUCC);
		return responseVO;
	}

	public ResponseVO selcetMusoguList(MusoguReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		reqDTO.setLanguage(sessionUtil.getLangCd());

		MusoguInfoVO rvo = hbdMaterialMapper.selectMusoguInfo(reqDTO);

		List<CodeDTO> list = hbdMaterialMapper.selectMusoguList(rvo);// 무소구 가능항목 (분모)
		List<MusoguRateVO> musoguYnList = this.selectMusoguRate(reqDTO, list); // 함량 구하기

		String getListType = "CHOOSE";
		List<MusoguTagVO> mtr04List = this.selectLabNoteTagList(reqDTO, "MTR04", getListType); // 해당 게시글 프리소구 공통
		List<MusoguTagVO> mtr05List = this.selectLabNoteTagList(reqDTO, "MTR05", getListType); // 해당 게시글 프리소구 특화
		List<MusoguTagVO> mtr06List = this.selectLabNoteTagList(reqDTO, "MTR06", getListType); // 해당 게시글 프리소구 제한

		reqDTO.setVProdType1Cd(rvo.getVProdType1Cd());
		reqDTO.setVProdType2Cd(rvo.getVProdType2Cd());
		reqDTO.setVMstCode("MTR04"); // 해당 프리소구 공통전체
		List<CodeDTO> mtr04All = hbdMaterialMapper.selectLabNoteTagListAll(reqDTO);
		reqDTO.setVMstCode("MTR05"); // 해당 프리소구 특화전체
		List<CodeDTO> mtr05All = hbdMaterialMapper.selectLabNoteTagListAll(reqDTO);
		reqDTO.setVMstCode("MTR06"); // 해당 프리소구 제한전체
		List<CodeDTO> mtr06All = hbdMaterialMapper.selectLabNoteTagListAll(reqDTO);

		List<String> musoguGroupList = hbdMaterialMapper.selectLabNoteMusoguGroup(); // 프리소구 그룹항목

		responseVO.setOk(MusoguResDTO.builder()
				.rvo(rvo)
				.list(list)
				.musoguGroupList(musoguGroupList)
				.musoguYnList(musoguYnList)
				.mtr04List(mtr04List)
				.mtr05List(mtr05List)
				.mtr06List(mtr06List)
				.mtr04All(mtr04All)
				.mtr05All(mtr05All)
				.mtr06All(mtr06All)
				.build());
		return responseVO;
	}

	private List<MusoguRateVO> selectMusoguRate(MusoguReqDTO reqDTO, List<CodeDTO> list) {
		// NWLEE 무소구 4자 확인 Flag 추가
		List<MusoguRateVO> resList = hbdMaterialMapper.selectMusoguRate(reqDTO);

		if(!resList.isEmpty()) {
			for(MusoguRateVO rateVO : resList) {
				boolean flag = false;

				rateVO.setVFlagRequest("N");

				String mateCd = rateVO.getVMateCd();
				String divMateCd = "";

				if(StringUtils.isEmpty(mateCd)) {
					divMateCd = "temp";
				}
				else {
					divMateCd = mateCd.substring(0, 1);
				}

				if("4".equals(divMateCd)) {
					rateVO.setVFlagRequest("Y");

					for(MusoguRateVO tmpVO : resList) {
						String mateCdTmp = tmpVO.getVMateCd();
						String hal4Cd = tmpVO.getVHal4Cd();

						if(mateCd.equals(hal4Cd) && !mateCd.equals(mateCdTmp)) {
							flag = true;
							break;
						}
					}
				}

				if(flag) {
					rateVO.setVFlagRequest("N");
				}
			}

			int count = 0;
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode0()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode1()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode2()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode3()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode4()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode5()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode6()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode7()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode8()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode9()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode10()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode11()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode12()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode13()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode14()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode15()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode16()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode17()))
					.count() > 0 ? "bg-red" : null);
			list.get(count++).setVContent1(resList.stream()
					.filter(o -> "불가".equals(o.getVCode18()))
					.count() > 0 ? "bg-red" : null);
		}

		return resList;
	}

	private List<MusoguTagVO> selectLabNoteTagList(MusoguReqDTO reqDTO, String tag1Cd, String getListType) {
		reqDTO.setVTempTag1Cd(tag1Cd);
		reqDTO.setVGetListType(getListType);
		return hbdCommonService.selectLabNoteTagList(reqDTO);
	}

	@Transactional
	public ResponseVO updateLabNoteMateCheck(ScmTCodeRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();

		hbdMaterialMapper.updateLabNoteMateCheck(regDTO);

		responseVO.setOk(Const.SUCC);
		return responseVO;
	}

	public ResponseVO selectLabNoteAllPlantRateAndPrice(PlantRatePriceReqVO reqVO) {
		ResponseVO responseVO = new ResponseVO();

		if(StringUtils.isEmpty(reqVO.getVLotCd())) {
			responseVO.setOk("아직 실험되지 않았습니다.");
			return responseVO;
		}

		reqVO.setLanguage(sessionUtil.getLangCd());

		List<HbdNoteLotVO> lotList = hbdMaterialMapper.selectLabNoteLotList(HbdNoteLotVO.builder()
				.vContPkCd(reqVO.getVContPkCd())
				.nVersion(reqVO.getNVersion())
				.language(sessionUtil.getLangCd())
				.build());
		List<HbdNoteMateVO> mateList = hbdMaterialMapper.selectLabNoteMateList(reqVO);
		List<PlantRatePriceVO> rateList = hbdMaterialMapper.selectLabNoteAllPlantRateAndPriceMap(reqVO);

		responseVO.setOk(HbdPlantRatePriceResDTO.builder()
				.lotList(lotList)
				.mateList(mateList)
				.rateList(rateList)
				.build());
		return responseVO;
	}

	public ResponseVO selectQrCodeElabNoteInfo(MaterialQrInfoVO reqVO) {
		ResponseVO responseVO = new ResponseVO();

		MaterialQrInfoVO rvo = hbdMaterialMapper.selectElabNoteInfoVerLotCd(reqVO);

		responseVO.setOk(QrCodeResDTO.builder()
				.qrInfoVO(rvo)
				.build());
		return responseVO;
	}

	public ResponseVO selectLabNoteBomLotList(BomReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		List<HbdNoteLotVO> lotList = hbdMaterialMapper.selectLabNoteBomLotList(reqDTO);

		List<HbdMaterialNotePlantVO> contList = hbdMaterialMapper.selectLabNoteContOrPlantList(MaterialSearchVO.builder()
				.vLabNoteCd(reqDTO.getVLabNoteCd())
				.vCodeType(reqDTO.getVCodeType())
				.vPlantCd(reqDTO.getVPlantCd())
				.language(sessionUtil.getLangCd())
				.vSearchType("CONT")
				.build());

		if(!lotList.isEmpty()) {
			for(HbdMaterialNotePlantVO contVO : contList) {
				contVO.setLotList(lotList.stream()
						.filter(o -> contVO.getVContPkCd().equals(o.getVContPkCd()))
						.collect(Collectors.toList()));
			}

		}

		List<VersionListVO> verList = hbdCommonService.selectLabNoteVersionList(reqDTO.getVContPkCd());

		responseVO.setOk(HbdBomResDTO.builder()
				.contList(contList)
				.verList(verList)
				.build());
		return responseVO;
	}

	public ResponseVO selectLabNoteGramList(GramReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		if(StringUtils.isEmpty(reqDTO.getVLotCd())) {
			responseVO.setOk("vLotCd 가 없습니다.");
			return responseVO;
		}

		String vUserid = sessionUtil.getLoginId();
		String language = sessionUtil.getLangCd();
		reqDTO.setLanguage(language);

		if(StringUtils.isNotEmpty(reqDTO.getVTestStDt())
				&& StringUtils.isNotEmpty(reqDTO.getVTestEnDt())
				&& StringUtils.isNotEmpty(reqDTO.getVGramCd())) {
			hbdMaterialMapper.updateLabNoteGramDt(HbdNoteGramVO.builder()
					.vGramCd(reqDTO.getVGramCd())
					.vTestStDt(reqDTO.getVTestStDt())
					.vTestEnDt(reqDTO.getVTestEnDt())
					.vUpdateUserid(vUserid)
					.build());
		}

		List<StabilityTitleVO> titleList = hbdMaterialMapper.selectLabNoteStabilityTitleList(reqDTO);
		if(titleList.isEmpty()) {
			titleList = hbdMaterialMapper.selectLabNoteStabilityDefaultTitleList();
		}

		List<HbdNoteStabilityValueVO> valueList = hbdMaterialMapper.selectLabNoteStabilityValueListMap(reqDTO);

		MaterialNoteContVO contVO = hbdMaterialMapper.selectLabNoteContInfo(MaterialSearchVO.builder()
				.vLabNoteCd(reqDTO.getVLabNoteCd())
				.vContPkCd(reqDTO.getVContPkCd())
				.vContCd(reqDTO.getVContCd())
				.vPlantCd(reqDTO.getVPlantCd())
				.language(language)
				.localLanguage(sessionUtil.getLocalLanguage())
				.build());

		List<MaterialNoteVersionVO> verList = hbdMaterialMapper.selectLabNoteVersion(MaterialSearchVO.builder()
				.vContPkCd(reqDTO.getVContPkCd())
				.vGetType("Vo")
				.nVersion(reqDTO.getNVersion())
				.build());

		MaterialNoteVersionVO verVO = new MaterialNoteVersionVO();
		if(!verList.isEmpty()) {
			verVO = verList.get(0);
		}

		HbdNoteLotVO lotVO = hbdMaterialMapper.selectLabNoteLot(PlantRatePriceReqVO.builder()
				.vLotCd(reqDTO.getVLotCd())
				.language(language)
				.build());

		List<HbdNoteGramVO> gramList = hbdMaterialMapper.selectLabNoteGramList(reqDTO);

		if(StringUtils.isEmpty(reqDTO.getVGramCd())) {
			if(!gramList.isEmpty()) {
				//가장 마지막의 값이 최근에 작성된 것임으로 선택
				int gramIndex = gramList.size()-1;
				reqDTO.setVGramCd(gramList.get(gramIndex).getVGramCd());
			}
		}

		HbdNoteGramVO gramVO = hbdMaterialMapper.selectLabNoteGram(reqDTO);

		List<GramTrPlanVO> gramTrList = hbdMaterialMapper.selectLabNoteGramTrPlanList(reqDTO);

		responseVO.setOk(HbdGramResDTO.builder()
				.titleList(titleList)
				.valueList(valueList)
				.contVO(contVO)
				.verVO(verVO)
				.lotVO(lotVO)
				.gramList(gramList)
				.gramVO(gramVO)
				.gramTrList(gramTrList)
				.vGramCd(reqDTO.getVGramCd())
				.build());
		return responseVO;
	}

	public ResponseVO selectLabNoteDefaultIngredientData(IngredientReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		List<IngredientContVO> contList = null;

		IngredientDataVO deVO = hbdMaterialMapper.selectLabNoteDefaultIngredientData(reqDTO);

		reqDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
		if(!"PREVIEW".equals(reqDTO.getVFlagChoice())) {
			contList = hbdCommonService.selectLabContList(reqDTO);
		}

		responseVO.setOk(IngredientResDTO.builder()
				.deVO(deVO)
				.contList(contList)
				.build());
		return responseVO;
	}

	public ResponseVO selectLabNoteIngredientList(IngredientReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		if(StringUtils.isEmpty(reqDTO.getVLand1())
				|| StringUtils.isEmpty(reqDTO.getVLotCd())) {
			responseVO.setOk("필수 인자 값이 없습니다.");
			return responseVO;
		}

		List<IngredientVO> list = null;

		if("UN".equals(reqDTO.getVLand1())) {
			reqDTO.setVAllergenTabId(StringUtils.defaultIfEmpty(reqDTO.getVAllergenTabId(), "ALLERGEN"));

			if("ALLERGEN".equals(reqDTO.getVAllergenTabId())) {
				list = this.selectLabNoteIngredientVerAllergenList(reqDTO);
			}
			else {
				list = this.selectLabNoteIngredientVerList(reqDTO);	//selectLabNoteIngredientList 메서드명 중복으로 중간에 Ver 키워드 삽입
			}
		}
		else {
			list = this.selectLabNoteIngredientVerAllergenList(reqDTO);
		}

		responseVO.setOk(IngredientResDTO.builder()
				.list(Optional.ofNullable(list)
						.orElseGet(() -> List.of()))
				.nInciTotalPer(reqDTO.getNInciTotalPer())
				.build());
		return responseVO;
	}

	private List<IngredientVO> selectLabNoteIngredientVerAllergenList(IngredientReqDTO reqDTO) {
		String land1 = reqDTO.getVLand1();

		reqDTO.setVFlagVerAllergen("Y");

		List<IngredientExistsConcdVO> rawList = hbdMaterialMapper.selectLabNoteNotExistsConcdList(reqDTO);

		List<IngredientReqVO> conSqlList = new ArrayList<>();
		List<IngredientReqVO> zplmt74SqlList = new ArrayList<>();

		BigDecimal conInPer = new BigDecimal(0);
		BigDecimal dividePer = new BigDecimal(100);

		if(!rawList.isEmpty()) {
			String rawCd = "";
			List<BomInfoVO> rfcList = new ArrayList<>();

			for(IngredientExistsConcdVO rawVO : rawList) {
				rawCd = rawVO.getVMateCd();

				if(StringUtils.isNotEmpty(rawCd) && rawCd.startsWith("4")) {
					rfcList = labNoteSAPInterfaceService.getT_ZPLMS013(reqDTO.getVPlantCd(), rawCd, land1);
					String rfcRawCd = "";
					String flagZplmt74 = "";
					String zplmt74Cds = "";

					if(!ObjectUtils.isEmpty(rfcList)) {
						for(BomInfoVO rfcVO : rfcList) {
							rfcRawCd = rfcVO.getRawCd();

							flagZplmt74 = hbdMaterialMapper.selectFlagZplmt74(rfcRawCd);

							if("Y".equals(flagZplmt74)) {
								if(zplmt74Cds.indexOf(rfcRawCd) <= -1){
									zplmt74Cds = "//"+rfcRawCd;

									zplmt74SqlList.add(IngredientReqVO.builder()
											.vRealMateCd(rawCd)
											.vMateCd(rfcRawCd)
											.nRate(new BigDecimal(rawVO.getNRate()).multiply(new BigDecimal(rfcVO.getRawPer())).divide(dividePer))
											.build());
								}
							}
						}
					}
				}
				else {
					rfcList = labNoteSAPInterfaceService.getT_ZPLMS017(rawCd, land1);
				}

				if(!ObjectUtils.isEmpty(rfcList)) {
					for(BomInfoVO rfcVO : rfcList) {
						conInPer = new BigDecimal(rawVO.getNRate()).multiply(new BigDecimal(rfcVO.getConInPer())).divide(dividePer);

						String sInMateCd = "";
						if(StringUtils.isNotEmpty(rawCd) && rawCd.startsWith("4")) {
							conInPer = conInPer.multiply(new BigDecimal(rfcVO.getRawPer())).divide(dividePer);
							sInMateCd = rfcVO.getRawCd();
						}
						else {
							sInMateCd = rawCd;
						}

						conSqlList.add(IngredientReqVO.builder()
								.vRealMateCd(rawCd)
								.vMateCd(sInMateCd)
								.vConCd(rfcVO.getConcd())
								.nInPer(conInPer)
								.build());
					}
				}
			}
		}

		String vStandardPer = "0.001";
		if("R".equals(reqDTO.getVFlagLeaveType())) {
			vStandardPer = "0.01";
		}

		List<IngredientVO> inciList = hbdMaterialMapper.selectLabNoteIngredientVerAllergenListMap(IngredientVO.builder()
				.conSqlList(conSqlList)
				.zplmt74SqlList(zplmt74SqlList)
				.vLotCd(reqDTO.getVLotCd())
				.vLand1(reqDTO.getVLand1())
				.vStandardPer(vStandardPer)
				.build());

		inciList = this.selectLabNoteInciKeyListSort(inciList);

		List<IngredientMateVO> mateList = null;

		String matnrs = "";
		List<String> matnrsList = null;

		Map<String, List<IngredientMateVO>> mateListMap = new HashMap<>();

		//전성분 함량 총합을 구하기 위해 0으로 초기화
		BigDecimal totalPer = new BigDecimal(0);
		String sMixretxt = "";

		for(IngredientVO inciVO : inciList) {
			if(!"UN".equals(land1)) {
				//ZPLM34일 경우 CARRY OVER값의 기준값에 따라 성분 삭제 진행
				if(StringUtils.isNotEmpty(inciVO.getVMixre())) {
					sMixretxt = inciVO.getVMixre().replaceAll(" ", "");
				}

				if(sMixretxt.indexOf("CARRYOVER") > -1) {
					if(inciVO.getVZabcde() > Double.valueOf(inciVO.getNSumInPer())) {
						continue;
					}
				}
			}

			matnrs = inciVO.getVMatnr();

			if(mateListMap.containsKey(matnrs)) {
				mateList = mateListMap.get(matnrs);
			}
			else {
				matnrsList = Arrays.asList(matnrs.split(","));

				if(matnrsList.size() == 1) {
					mateList = hbdMaterialMapper.selectLabNoteIngredientMateInfoList(IngredientMateVO.builder()
							.vLotCd(reqDTO.getVLotCd())
							.vMateCd(matnrs)
							.build());
					mateListMap.put(matnrs, mateList);
				}
				else if(matnrsList.size() > 1){
					mateList = hbdMaterialMapper.selectLabNoteIngredientMateInfoList(IngredientMateVO.builder()
							.vLotCd(reqDTO.getVLotCd())
							.mateCdList(matnrsList)
							.build());
					mateListMap.put(matnrs, mateList);
				}
			}

			inciVO.setMateList(mateList);

			totalPer = new BigDecimal(inciVO.getNSumInPer()).add(totalPer);
			// 소수점 7자리까지 자리수 맞춤
		}

		reqDTO.setNInciTotalPer(String.format("%.7f", totalPer.doubleValue()));

		return inciList;
	}

	private List<IngredientVO> selectLabNoteIngredientVerList(IngredientReqDTO reqDTO) {
		String land1 = reqDTO.getVLand1();

		List<IngredientExistsConcdVO> rawList = hbdMaterialMapper.selectLabNoteNotExistsConcdList(reqDTO);

		List<IngredientReqVO> conSqlList = new ArrayList<>();
		List<IngredientReqVO> zplmt74SqlList = new ArrayList<>();

		BigDecimal conInPer = new BigDecimal(0);
		BigDecimal dividePer = new BigDecimal(100);

		if(!rawList.isEmpty()) {
			String rawCd = "";
			List<BomInfoVO> rfcList = new ArrayList<>();

			for(IngredientExistsConcdVO rawVO : rawList) {
				rawCd = rawVO.getVMateCd();

				if(StringUtils.isNotEmpty(rawCd) && rawCd.startsWith("4")) {
					rfcList = labNoteSAPInterfaceService.getT_ZPLMS013(reqDTO.getVPlantCd(), rawCd, land1);
					String rfcRawCd = "";
					String flagZplmt74 = "";
					String zplmt74Cds = "";

					if(!ObjectUtils.isEmpty(rfcList)) {
						for(BomInfoVO rfcVO : rfcList) {
							rfcRawCd = rfcVO.getRawCd();

							flagZplmt74 = hbdMaterialMapper.selectFlagZplmt74(rfcRawCd);

							if("Y".equals(flagZplmt74)) {
								if(zplmt74Cds.indexOf(rfcRawCd) <= -1){
									zplmt74Cds = "//"+rfcRawCd;

									zplmt74SqlList.add(IngredientReqVO.builder()
											.vRealMateCd(rawCd)
											.vMateCd(rfcRawCd)
											.nRate(new BigDecimal(rawVO.getNRate()).multiply(new BigDecimal(rfcVO.getRawPer())).divide(dividePer))
											.build());
								}
							}
						}
					}
				}else {
					rfcList = labNoteSAPInterfaceService.getT_ZPLMS017(rawCd, land1);
				}

				if(!ObjectUtils.isEmpty(rfcList)) {
					for(BomInfoVO rfcVO : rfcList) {
						conInPer = new BigDecimal(rawVO.getNRate()).multiply(new BigDecimal(rfcVO.getConInPer())).divide(dividePer);

						String sInMateCd = "";
						if(StringUtils.isNotEmpty(rawCd) && rawCd.startsWith("4")) {
							conInPer = conInPer.multiply(new BigDecimal(rfcVO.getRawPer())).divide(dividePer);
							sInMateCd = rfcVO.getRawCd();
						}
						else {
							sInMateCd = rawCd;
						}

						conSqlList.add(IngredientReqVO.builder()
								.vRealMateCd(rawCd)
								.vMateCd(sInMateCd)
								.vConCd(rfcVO.getConcd())
								.nInPer(conInPer)
								.build());
					}
				}
			}
		}

		List<IngredientVO> inciList = hbdMaterialMapper.selectLabNoteIngredientListMap(IngredientVO.builder()
				.conSqlList(conSqlList)
				.zplmt74SqlList(zplmt74SqlList)
				.vLotCd(reqDTO.getVLotCd())
				.vLand1(reqDTO.getVLand1())
				.build());

		inciList = this.selectLabNoteInciKeyListSort(inciList);

		List<IngredientMateVO> mateList = null;

		String matnrs = "";
		List<String> matnrsList = null;

		Map<String, List<IngredientMateVO>> mateListMap = new HashMap<>();

		//전성분 함량 총합을 구하기 위해 0으로 초기화
		BigDecimal totalPer = new BigDecimal(0);
		String sMixretxt = "";

		for(IngredientVO inciVO : inciList) {
			if(!"UN".equals(land1)) {
				//ZPLM34일 경우 CARRY OVER값의 기준값에 따라 성분 삭제 진행
				if(StringUtils.isNotEmpty(inciVO.getVMixre())) {
					sMixretxt = inciVO.getVMixre().replaceAll(" ", "");
				}

				if(sMixretxt.indexOf("CARRYOVER") > -1) {
					if( inciVO.getVZabcde() > Double.valueOf(inciVO.getNSumInPer())){
						continue;
					}
				}
			}

			matnrs = inciVO.getVMatnr();

			if(mateListMap.containsKey(matnrs)) {
				mateList = mateListMap.get(matnrs);
			}
			else {
				matnrsList = Arrays.asList(matnrs.split(","));

				if(matnrsList.size() == 1) {
					mateList = hbdMaterialMapper.selectLabNoteIngredientMateInfoList(IngredientMateVO.builder()
							.vLotCd(reqDTO.getVLotCd())
							.vMateCd(matnrs)
							.build());
					mateListMap.put(matnrs, mateList);
				}
				else if(matnrsList.size() > 1){
					mateList = hbdMaterialMapper.selectLabNoteIngredientMateInfoList(IngredientMateVO.builder()
							.vLotCd(reqDTO.getVLotCd())
							.mateCdList(matnrsList)
							.build());
					mateListMap.put(matnrs, mateList);
				}
			}

			inciVO.setMateList(mateList);

			totalPer = new BigDecimal(inciVO.getNSumInPer()).add(totalPer);
			// 소수점 7자리까지 자리수 맞춤
		}

		reqDTO.setNInciTotalPer(String.format("%.7f", totalPer.doubleValue()));

		return inciList;
	}

	private List<IngredientVO> selectLabNoteInciKeyListSort(List<IngredientVO> inciList){
		Collections.sort(inciList, new Comparator<IngredientVO>() {
			@Override
			public int compare(IngredientVO o1, IngredientVO o2) {

				Double v1 = Double.valueOf(o1.getNSumInPer());
				Double v2 = Double.valueOf(o2.getNSumInPer());

				Integer v3 = Integer.parseInt(o1.getVConcd());
				Integer v4 = Integer.parseInt(o2.getVConcd());

				int perSort = v2.compareTo(v1);

				if(perSort != 0) {
					return perSort;
				}

				return v3.compareTo(v4);
			}
		});

		return inciList;
	}

	public ResponseVO selectLabNoteStabilityTitleAllList(String vLotCd) {
		ResponseVO responseVO = new ResponseVO();

		String language = sessionUtil.getLangCd();

		List<StabilityTitleVO> titleList = hbdMaterialMapper.selectLabNoteStabilityTitleList(GramReqDTO.builder()
				.vLotCd(vLotCd)
				.language(language)
				.build());

		if(ObjectUtils.isEmpty(titleList)) {
			titleList = hbdMaterialMapper.selectLabNoteStabilityDefaultTitleList();
		}

		List<StabilityTitleVO> list = hbdMaterialMapper.selectLabNoteStabilityTitleAllList();

		for(StabilityTitleVO allVO : list) {
			for(StabilityTitleVO titleVO : titleList) {
				if(allVO.getVSubCode().equals(titleVO.getVSubCode())) {
					allVO.setVFlagCheck("Y");
					break;
				}
			}
		}

		responseVO.setOk(StabilityResDTO.builder()
				.list(Optional.ofNullable(list)
						.orElseGet(() -> List.of()))
				.build());
		return responseVO;
	}

	@Transactional
	public ResponseVO insertLabNoteStabilityTitle(StabilityReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		hbdMaterialMapper.deleteLabNoteStabilityTitle(HbdNoteStabilityTitleVO.builder()
				.vLotCd(reqDTO.getVLotCd())
				.build());

		reqDTO.getStabilityCdList().forEach(o -> {
			hbdMaterialMapper.insertLabNoteStabilityTitle(HbdNoteStabilityTitleVO.builder()
					.vLotCd(reqDTO.getVLotCd())
					.vStabilityCd(o)
					.build());
		});

		responseVO.setOk(Const.SUCC);
		return responseVO;
	}

	public ResponseVO selectLabNoteMemoList(MemoReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		List<HbdNoteMemoVO> list = new ArrayList<>();

		reqDTO.setLanguage(sessionUtil.getLangCd());

		int totalCnt = hbdMaterialMapper.selectLabNoteMemoListCount(reqDTO);

		if (totalCnt > 0) {
			CommonUtil.setPaging(reqDTO, totalCnt);
			list = hbdMaterialMapper.selectLabNoteMemoList(reqDTO);

			list.forEach(o -> {
				List<UploadDTO> attList = commonService.selectCommAttachList(o.getVMemoCd(), "MEMO001"); //첨부파일 리스트
				List<ThumbnailDTO> imgList = commonService.selectThumbnailList(o.getVMemoCd(), "MEMO001"); //이미지 리스트

				o.setAttList(attList);
				o.setImgList(imgList);
			});
		}

		responseVO.setOk(HbdMemoResDTO.builder()
				.list(list)
				.build());
		return responseVO;
	}

	public ResponseVO selectLabNoteMemo(MemoReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		if(StringUtils.isEmpty(reqDTO.getVMemoCd())) {
			responseVO.setOk("필수 인자 값이 없습니다.");
			return responseVO;
		}

		reqDTO.setLanguage(sessionUtil.getLangCd());

		HbdNoteMemoVO rvo = hbdMaterialMapper.selectLabNoteMemo(reqDTO);

		if(!ObjectUtils.isEmpty(rvo)) {
			List<UploadDTO> attList = commonService.selectCommAttachList(rvo.getVMemoCd(), "MEMO001"); //첨부파일 리스트
			List<ThumbnailDTO> imgList = commonService.selectThumbnailList(rvo.getVMemoCd(), "MEMO001"); //이미지 리스트

			rvo.setAttList(attList);
			rvo.setImgList(imgList.stream()
					.filter(o -> "N".equals(o.getVFlagOriginal()))
					.filter(o -> !StringUtils.equalsAnyIgnoreCase(o.getVThumbnailnm(), "bg.png", "front.png"))
					.collect(Collectors.toList()));
		}

		String vMemoTypeCd = reqDTO.getVMemoTypeCd();
		if(StringUtils.isEmpty(vMemoTypeCd)) {
			if(StringUtils.isEmpty(reqDTO.getVLotCd())
					&& StringUtils.isEmpty(reqDTO.getVGramCd())
					&& StringUtils.isEmpty(reqDTO.getVGramTrCd())){
				vMemoTypeCd = "LNC08_01";
			}
			else if(StringUtils.isNotEmpty(reqDTO.getVLotCd())
					&& StringUtils.isEmpty(reqDTO.getVGramCd())
					&& StringUtils.isEmpty(reqDTO.getVGramTrCd())){
				vMemoTypeCd = "LNC08_02";
			}
			else if(StringUtils.isNotEmpty(reqDTO.getVLotCd())
					&& StringUtils.isNotEmpty(reqDTO.getVGramCd())
					&& StringUtils.isEmpty(reqDTO.getVGramTrCd())){
				vMemoTypeCd = "LNC08_03";
			}
			else {
				vMemoTypeCd = "LNC08_04";
			}
		}

		responseVO.setOk(HbdMemoResDTO.builder()
				.rvo(Optional.ofNullable(rvo)
						.orElseGet(() -> new HbdNoteMemoVO()))
				.vMemoTypeCd(vMemoTypeCd)
				.build());
		return responseVO;
	}

	@Transactional
	public ResponseVO insertLabNoteMemo(MemoRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();

		if(StringUtils.isEmpty(regDTO.getVLabNoteCd())
				|| StringUtils.isEmpty(regDTO.getVContPkCd())
				|| regDTO.getNVersion() < 1){
			responseVO.setOk("필수 인자 값이 없습니다.");
			return responseVO;
		}

		String vUserid = sessionUtil.getLoginId();
		int cnt = hbdMaterialMapper.insertLabNoteMemo(HbdNoteMemoVO.builder()
				.vMemoTypeCd(regDTO.getVMemoTypeCd())
				.vLabNoteCd(regDTO.getVLabNoteCd())
				.vContPkCd(regDTO.getVContPkCd())
				.nVersion(regDTO.getNVersion())
				.vLotCd(regDTO.getVLotCd())
				.vGramCd(regDTO.getVGramCd())
				.vGramTrCd(regDTO.getVGramTrCd())
				.vTitle(regDTO.getVTitle())
				.vMemo(regDTO.getVMemo())
				.vUserid(vUserid)
				.vRegUserid(vUserid)
				.vUpdateUserid(vUserid)
				.vFlagWeb(regDTO.getVFlagWeb())
				.build());

		responseVO.setOk(cnt > 0 ? Const.SUCC : Const.FAIL);
		return responseVO;
	}

	@Transactional
	public ResponseVO updateLabNoteMemo(MemoRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();

		if(StringUtils.isEmpty(regDTO.getVMemoCd())) {
			responseVO.setOk("필수 인자 값이 없습니다.");
			return responseVO;
		}

		String vUserid = sessionUtil.getLoginId();
		int cnt = hbdMaterialMapper.updateLabNoteMemo(HbdNoteMemoVO.builder()
				.vMemoCd(regDTO.getVMemoCd())
				.vTitle(regDTO.getVTitle())
				.vMemo(regDTO.getVMemo())
				.vFlagWeb(regDTO.getVFlagWeb())
				.vUpdateUserid(vUserid)
				.build());

		responseVO.setOk(cnt > 0 ? Const.SUCC : Const.FAIL);
		return responseVO;
	}

	@Transactional
	public ResponseVO deleteLabNoteMemo(MemoRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();

		if(StringUtils.isEmpty(regDTO.getVMemoCd())) {
			responseVO.setOk("필수 인자 값이 없습니다.");
			return responseVO;
		}

		String vUserid = sessionUtil.getLoginId();
		int cnt = hbdMaterialMapper.deleteLabNoteMemo(HbdNoteMemoVO.builder()
				.vMemoCd(regDTO.getVMemoCd())
				.vUpdateUserid(vUserid)
				.build());

		responseVO.setOk(cnt > 0 ? Const.SUCC : Const.FAIL);
		return responseVO;
	}

	public ResponseVO selectLabNoteContInfo(MaterialSearchVO schVO) {
		ResponseVO responseVO = new ResponseVO();

		schVO.setLanguage(sessionUtil.getLangCd());
		schVO.setLocalLanguage(sessionUtil.getLocalLanguage());
		MaterialNoteContVO contVO = hbdMaterialMapper.selectLabNoteContInfo(schVO);

		if(ObjectUtils.isEmpty(contVO)) {
			responseVO.setOk(HbdHal4LotResDTO.builder()
					.vMessage("해당 자재 정보가 없습니다.")
					.build());
			return responseVO;
		}

		List<VersionListVO> verList = hbdCommonService.selectLabNoteVersionList(contVO.getVContPkCd());

		responseVO.setOk(HbdHal4LotResDTO.builder()
				.contVO(contVO)
				.verList(verList)
				.build());
		return responseVO;
	}

	public ResponseVO selectLabNoteLotList(MaterialSearchVO schVO) {
		ResponseVO responseVO = new ResponseVO();

		List<HbdNoteLotVO> lotList = hbdMaterialMapper.selectLabNoteLotList(HbdNoteLotVO.builder()
				.vContPkCd(schVO.getVContPkCd())
				.nVersion(schVO.getNVersion())
				.language(sessionUtil.getLangCd())
				.build());

		responseVO.setOk(HbdHal4LotResDTO.builder()
				.lotList(Optional.ofNullable(lotList)
						.orElseGet(() -> List.of()))
				.build());
		return responseVO;
	}

//	Lot Side
	public ResponseVO selectElabLotMemoList(String vLotCd) {
		ResponseVO responseVO = new ResponseVO();

		List<ElabLotMemoVO> list = hbdMaterialMapper.selectElabLotMemoList(vLotCd);

		if(!ObjectUtils.isEmpty(list)) {
			list.forEach(o -> {
				if(o.getNSeqno() == 1 && StringUtils.isEmpty(o.getVContent())) {
					o.setVContent(o.getVLotTestMemo());
				}
			});
		}

		responseVO.setOk(Optional.ofNullable(list)
				.orElseGet(() -> List.of()));
		return responseVO;
	}

	@Transactional
	public ResponseVO insertElabLotMemo(ElabLotMemoRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();

		String vUserid = sessionUtil.getLoginId();

		if(StringUtils.isEmpty(regDTO.getVFlagOnlyMemo())) {
			hbdMaterialMapper.updateLabNoteTestResLot(HbdNoteLotVO.builder()
					.vLotCd(regDTO.getVLotCd())
					.vTestType(regDTO.getVTestType())
					.vTestValue(regDTO.getVTestValue())
					.vPh(regDTO.getVPh())
					.vUpdateUserid(vUserid)
					.build());
		}

		labNoteCommonService.insertElabLotMemo(ElabLotMemoVO.builder()
				.vLotCd(regDTO.getVLotCd())
				.nSeqno(regDTO.getNSeqno())
				.vTitle(regDTO.getVTitle())
				.vContent(regDTO.getVContent())
				.vFlagStability(regDTO.getVFlagStability())
				.vFlagDel(regDTO.getVFlagDel())
				.vRegUserid(vUserid)
				.vUpdateUserid(vUserid)
				.build());

		responseVO.setOk(Const.SUCC);
		return responseVO;
	}

	public ResponseVO selectMaterialFormulationChange(String vContPkCd, int nVersion, String vLotCd) {
		ResponseVO responseVO = new ResponseVO();

		List<MaterialMateVO> mateList = hbdMaterialMapper.selectLabNoteMateAndGrpSimpleList(vContPkCd, nVersion);

		List<MaterialMateRateVO> rateList = hbdMaterialMapper.selectLabNoteMateRateMap(MaterialSearchVO.builder()
				.vContPkCd(vContPkCd)
				.nVersion(nVersion)
				.vLotCd(vLotCd)
				.vLotConditionType("Vo")
				.build());		// Rate

		responseVO.setOk(MaterialFormulationResDTO.builder()
				.mateList(mateList)
				.rateList(rateList)
				.build());
		return responseVO;
	}

	@Transactional
	public ResponseVO updateMaterialFormulationChange(HbdMaterialSaveRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();

		String vUserid = sessionUtil.getLoginId();
		boolean isSave = false;

		if(!ObjectUtils.isEmpty(regDTO.getGroupList())) {
			isSave = true;
			regDTO.getGroupList().forEach(o -> {
				hbdMaterialMapper.updateLabNoteOrderGroup(HbdNoteGroupVO.builder()
						.vGrpCd(o.getVGrpCd())
						.nSort(o.getNSort())
						.vUpdateUserid(vUserid)
						.build());
			});
		}

		if(!ObjectUtils.isEmpty(regDTO.getMateList())) {
			isSave = true;
			regDTO.getMateList().forEach(o -> {
				hbdMaterialMapper.updateLabNoteOrderMate(HbdNoteMateVO.builder()
						.vMatePkCd(o.getVMatePkCd())
						.vGrpCd(o.getVGrpCd())
						.nSort(o.getNSort())
						.vUpdateUserid(vUserid)
						.build());
			});
		}

		if(!isSave) {
			responseVO.setOk(Const.FAIL);
			return responseVO;
		}

		responseVO = this.updateLabNoteLotSendBom(SendBomRegDTO.builder()
				.vLabNoteCd(regDTO.getVLabNoteCd())
				.sendBomList(List.of(LotDecideRegDTO.builder()
						.vContPkCd(regDTO.getVContPkCd())
						.nVersion(regDTO.getNVersion())
						.vLotCd(regDTO.getVLotCd())
						.vBomType(Const.BOM_CHANGE)
						.build()))
				.build());

		HbdNoteInfoDTO rvo = hbdCommonService.selectLabNoteInfo(regDTO.getVLabNoteCd());

		if(!ObjectUtils.isEmpty(rvo)) {
			String labLeaderid = commonService.selectLabLeaderid(rvo.getVDeptCd());

			commonService.sendAlarm(AlarmRegDTO.builder()
					.vLabNoteCd(regDTO.getVLabNoteCd())
					.vStatusCd("AL_NOTE0")
					.vAlrTypeCd("AL_NOTE0_07")
					.typeList(List.of(Const.TIMELINE, Const.ALARM))
					.vContCd(regDTO.getVContCd())
					.vContNm(regDTO.getVContNm())
					.nVerNo(regDTO.getNVersion() < 10 ? "0" + regDTO.getNVersion() : Integer.toString(regDTO.getNVersion()))
					.vLotNm(regDTO.getVLotNm())
					.vNoteType("HBO")
					// CTC담당자 / 랩장
					.userList(Arrays.asList(rvo.getVCtcUserid(),
							labLeaderid))
					.build());
		}

		return responseVO;
	}

	@Transactional
	public ResponseVO updateMaterialFormulationExcel(MaterialUploadDTO regDTO, MultipartFile file) {
		ResponseVO responseVO = new ResponseVO();

		try {
			String fileName = file.getOriginalFilename();
			if (".xlsx".indexOf(fileName.substring(fileName.lastIndexOf(".") + 1).toLowerCase()) == -1) {
				responseVO.setOk("엑셀 파일만 업로드 가능합니다.(.xlsx)");
				return responseVO;
			}

			List<Object> list = CommonUtil.uploadExcelMaterialParsing(file.getInputStream());
			if(!ObjectUtils.isEmpty(list)) {
				String message = CommonUtil.isUploadExcelMaterialValid(list);
				if(!Const.SUCC.equals(message)) {
					responseVO.setOk(message);
					return responseVO;
				}

				String vUserid = sessionUtil.getLoginId();

				hbdMaterialMapper.deleteLabNoteExcelGroup(HbdNoteGroupVO.builder()
						.vContPkCd(regDTO.getVContPkCd())
						.nVersion(regDTO.getNVersion())
						.vUpdateUserid(vUserid)
						.build());

				hbdMaterialMapper.deleteLabNoteExcelMate(HbdNoteMateVO.builder()
						.vContPkCd(regDTO.getVContPkCd())
						.nVersion(regDTO.getNVersion())
						.vLabNoteCd(regDTO.getVLabNoteCd())
						.vUpdateUserid(vUserid)
						.build());

				hbdMaterialMapper.deleteLabNoteExcelGram(HbdNoteLotVO.builder()
						.vContPkCd(regDTO.getVContPkCd())
						.nVersion(regDTO.getNVersion())
						.vLabNoteCd(regDTO.getVLabNoteCd())
						.vUpdateUserid(vUserid)
						.build());

				hbdMaterialMapper.deleteLabNoteExcelLot(HbdNoteLotVO.builder()
						.vContPkCd(regDTO.getVContPkCd())
						.nVersion(regDTO.getNVersion())
						.vLabNoteCd(regDTO.getVLabNoteCd())
						.vUpdateUserid(vUserid)
						.build());

				HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
				String userAgent = CommonUtil.getByteString(request.getHeader("User-Agent"), 2600);
				List<String> lotList = new ArrayList<>();
				List<String> gramList = new ArrayList<>();
				int mateLen = 0;

				for(Object obj : list) {
					if(mateLen == 0) {
						mateLen++;
						gramList = Arrays.asList(CommonUtil.uploadExcelMaterialData(obj.toString().split(","), -1));
						continue;
					}

					String[] arrMate = CommonUtil.uploadExcelMaterialData(obj.toString().split(","), 1);
					String vMateCd = arrMate[0];

					LabNoteCommonSearchMateDTO searchMateVO = labNoteCommonService.selectLabNoteExcelHal4Mate(vMateCd);

					HbdNoteMateVO mateVO = HbdNoteMateVO.builder()
							.vContPkCd(regDTO.getVContPkCd())
							.nVersion(regDTO.getNVersion())
							.vLabNoteCd(regDTO.getVLabNoteCd())
							.vMateCd(vMateCd)
							.vMateDbTypeCd(StringUtils.isNotEmpty(searchMateVO.getVMateDbMstCd()) ? "LAB_HAL4" : null)
							.vMateDbMstCd(searchMateVO.getVMateDbMstCd())
							.vMateNm(searchMateVO.getVMateNm())
							.nSort(mateLen++)
							.vRegUserid(vUserid)
							.vUpdateUserid(vUserid)
							.build();
					hbdMaterialMapper.insertLabNoteMate(mateVO);

					if(StringUtils.isNotEmpty(vMateCd) && vMateCd.startsWith("4")){ // 4자코드 원료처방 저장
						labNoteCommonService.insertHal4Mate(Hal4MateRegDTO.builder()
								.vMateCd(vMateCd)
								.vPlantCd(regDTO.getVPlantCd())
								.vLand1(regDTO.getVLand1())
								.build());
					}

					if(mateLen == 2) {
						int lotLen = arrMate.length - 2;

						if(lotLen > 0) {
							int lotCnt = hbdMaterialMapper.selectLabNoteExcelLotCnt(HbdNoteLotVO.builder()
									.vLabNoteCd(regDTO.getVLabNoteCd())
									.vContPkCd(regDTO.getVContPkCd())
									.nVersion(regDTO.getNVersion())
									.build());

							for(int i = 0; i < lotLen; i++) {
								String vLotNm = "Lot #";
								if(i < 10) {
									vLotNm += "0";
								}

								HbdNoteLotVO lotVO = HbdNoteLotVO.builder()
										.vLabNoteCd(regDTO.getVLabNoteCd())
										.vContPkCd(regDTO.getVContPkCd())
										.nVersion(regDTO.getNVersion())
										.vLotNm(vLotNm.concat(Integer.toString(i + 1)))
										.nGramOpenNum(lotLen)
										.nSort(lotCnt + (i + 1))
										.vRegUserid(vUserid)
										.vUpdateUserid(vUserid)
										.build();
								hbdMaterialMapper.insertLabNoteLot(lotVO);

								lotList.add(lotVO.getVLotCd());

								String nGram = gramList.get(i);
								if(NumberUtils.isCreatable(nGram) || StringUtils.isEmpty(nGram)) {
									hbdMaterialMapper.insertLabNoteGram(HbdNoteGramVO.builder()
											.vLotCd(lotVO.getVLotCd())
											.nGram(nGram)
											.nSort(1)
											.vRegUserid(vUserid)
											.vUpdateUserid(vUserid)
											.build());
								}
							}
						}
					}

					if(!lotList.isEmpty()) {
						for(int i = 0; i < lotList.size(); i++) {
							if(mateLen == 2) {
								String vHisRegDtm = CommonUtil.getNowDate("yyyyMMddHHmmss");
								labNoteCommonService.insertELabHisLotChg(ElabHisLotChgVO.builder()
										.vLotCd(lotList.get(i))
										.vNoteType("SC")
										.vUserAgent(userAgent)
										.vRegUserid(vUserid)
										.vRegDtm(vHisRegDtm)
										.build());
								hbdMaterialMapper.insertELabHisPreRate(ElabHisPreRateVO.builder()
										.vLotCd(lotList.get(i))
										.vRegDtm(vHisRegDtm)
										.build());
							}

							hbdMaterialMapper.insertLabNoteRate(HbdNoteRateVO.builder()
									.vLotCd(lotList.get(i))
									.vMatePkCd(mateVO.getVMatePkCd())
									.nRate(arrMate[i + 2])
									.vFlagRateRest("N")
									.vRegUserid(vUserid)
									.vUpdateUserid(vUserid)
									.build());
						}
					}
				}
			}
		} catch (IOException e) {
			log.error("updateMaterialFormulationExcel Error : {}", e.getMessage());
		}

		responseVO.setOk(Const.SUCC);
		return responseVO;
	}
}
