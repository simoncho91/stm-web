package com.mybeaker.app.hbd.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.mybeaker.app.approval.model.ApprovalDTO;
import com.mybeaker.app.approval.model.NoteApprovalDTO;
import com.mybeaker.app.approval.model.ReferenceDTO;
import com.mybeaker.app.approval.model.ReqApprovalPrcDTO;
import com.mybeaker.app.approval.model.ResApprovalPrcDTO;
import com.mybeaker.app.common.model.AlarmRegDTO;
import com.mybeaker.app.common.service.CommonService;
import com.mybeaker.app.hbd.mapper.HbdApprovalMapper;
import com.mybeaker.app.hbd.model.HbdNoteInfoDTO;
import com.mybeaker.app.labnote.model.BomApprovalReqDTO;
import com.mybeaker.app.labnote.model.ElabBomLotVerVO;
import com.mybeaker.app.labnote.model.FuncDecideContNameVO;
import com.mybeaker.app.labnote.model.FuncDecideNameVO;
import com.mybeaker.app.labnote.model.LabNoteLotDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessContDecideListDTO;
import com.mybeaker.app.labnote.model.MassApprovalReqDTO;
import com.mybeaker.app.labnote.model.PgcGqteResVO;
import com.mybeaker.app.labnote.model.ShelfLifeVO;
import com.mybeaker.app.labnote.service.LabNoteCommonService;
import com.mybeaker.app.model.Const;
import com.mybeaker.app.model.enums.ApprovalResultCode;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.skincare.model.FuncDecideNameReqDTO;
import com.mybeaker.app.skincare.model.LotDecideRegDTO;
import com.mybeaker.app.utils.SessionUtil;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class HbdApprovalService {
	private final HbdApprovalMapper hbdApprovalMapper;

	private final SessionUtil sessionUtil;

	private final CommonService commonService;

	private final LabNoteCommonService labNoteCommonService;

	private final HbdCommonService hbdCommonService;

//	===========================================================================================================================================================
//	BOM 승인 결재 처리(GATE 1) 로직 Start
//	[AS-IS] LabNoteCommonController - lab_note_common_save - 216 line 부터 참고
	@Transactional
	public ResponseVO updateBomApproval(BomApprovalReqDTO bomApprovalReqDTO) {
		ResponseVO responseVO = new ResponseVO();

		List<LabNoteLotDTO> lotList = hbdApprovalMapper.selectLabNoteApprovalLotList(bomApprovalReqDTO.getVApprCd());

		if (lotList == null || lotList.isEmpty()) {
			responseVO.setOkWithCode(Const.FAIL, "필수 입력값이 없습니다", null);
			return responseVO;
		}

		bomApprovalReqDTO.setVLabNoteCd(lotList.get(0).getVLabNoteCd());
		bomApprovalReqDTO.setNVersion(lotList.get(0).getNVersion());

		bomApprovalReqDTO.setVLotNm(lotList.get(0).getVLotNm() + (lotList.size() > 1 ? "외 " + (lotList.size() - 1) + "건" : ""));

		bomApprovalReqDTO.setContPkCdList(lotList.stream().map(LabNoteLotDTO::getVContPkCd).collect(Collectors.toList()));
		bomApprovalReqDTO.setLotCdList(lotList.stream().map(LabNoteLotDTO::getVLotCd).collect(Collectors.toList()));
		bomApprovalReqDTO.setContCdList(lotList.stream().map(LabNoteLotDTO::getVContCd).collect(Collectors.toList()));

		// 결재 승인
		this.labNoteApprovalComplete(responseVO, bomApprovalReqDTO);

		return responseVO;
	}

//	[AS-IS] LabNoteCommonController - lab_note_approval_complete - 398 line 부터 참고
	@Transactional
	private void labNoteApprovalComplete(ResponseVO responseVO, BomApprovalReqDTO bomApprovalReqDTO) {
		String vApprCd = bomApprovalReqDTO.getVApprCd();
		String vLabNoteCd = bomApprovalReqDTO.getVLabNoteCd();

		if (StringUtils.isEmpty(vApprCd) || StringUtils.isEmpty(vLabNoteCd)) {
			responseVO.setOkWithCode(Const.FAIL, "필수 인자값이 없습니다", null);
			return;
		}

		HbdNoteInfoDTO noteInfo = hbdCommonService.selectLabNoteInfo(vLabNoteCd);

		ResApprovalPrcDTO resApprovalPrcDTO = commonService.handlingOfApprovalPrcEp(ReqApprovalPrcDTO.builder()
																									 .vApprCd(bomApprovalReqDTO.getVApprCd())
																									 .nCurRegseq(bomApprovalReqDTO.getNCurRegseq())
																									 .nCurApprseq(bomApprovalReqDTO.getNCurApprseq())
																									 .vApprStatus(bomApprovalReqDTO.getVApprStatus())
																									 .vApprSubStatus(bomApprovalReqDTO.getVApprSubStatus())
																									 .vApprOpinion(bomApprovalReqDTO.getVApprOpinion())
																									 .build());

		ApprovalResultCode resultCode = resApprovalPrcDTO.getApprovalResultCode();
		String labTypeCd = noteInfo != null && StringUtils.isNotEmpty(noteInfo.getVLabTypeCd()) ? noteInfo.getVLabTypeCd() : "";
		String pageType = "LNC07_01".equals(labTypeCd) ? "prd" : "half";
		String pageUrl = new StringBuilder()
							.append("/hbd/all-lab-note-").append(pageType).append("-process?vLabNoteCd=")
							.append(vLabNoteCd)
							.append("&vTabId=pilot")
							.append("&vApprCd=")
							.append(vApprCd)
							.toString();

		List<String> apprUserList = new ArrayList<String>();
		apprUserList.add(noteInfo.getVUserid());		//연구원
		
		List<String> referenceUserList = commonService.selectReferenceUserList(vApprCd);

		if (referenceUserList != null && !referenceUserList.isEmpty()) {
			apprUserList.addAll(referenceUserList);
		}

		if (ApprovalResultCode.ACCEPT_END.getCode().equals(resultCode.getCode())) {
			//승인 완료 처리에 관련
			hbdCommonService.updateAcceptApprovalRequest(bomApprovalReqDTO);

			List<String> contCdList = bomApprovalReqDTO.getContCdList();

			if (!ObjectUtils.isEmpty(contCdList)) {
				for (String contCd : contCdList) {
					labNoteCommonService.updateShelfLifeStatus(contCd, "SLS020");
				}
			}

			// 메일발송(결재완료)
			commonService.sendMailELabNoteApproval(NoteApprovalDTO.builder()
																  .vApprCd(bomApprovalReqDTO.getVApprCd())
																  .vLabNoteCd(bomApprovalReqDTO.getVLabNoteCd())
																  .nVersion(bomApprovalReqDTO.getNVersion())
																  .vNoteType("HBO")
																  .vUrl(pageUrl)
																  .build());

			commonService.sendAlarm(AlarmRegDTO.builder()
										.vLabNoteCd(bomApprovalReqDTO.getVLabNoteCd())
										.vStatusCd("AL_NOTE3")
										.vAlrTypeCd("AL_NOTE3_05")
										.typeList(Arrays.asList(Const.ALARM, Const.MAIL, Const.TIMELINE, Const.SCHEDULE))
										.vContCd(noteInfo.getVContCd())
										.vContNm(noteInfo.getVContNm())
										.nVerNo(bomApprovalReqDTO.getNVersion() < 10 ? "0" + bomApprovalReqDTO.getNVersion() : "" + bomApprovalReqDTO.getNVersion())
										.vLotNm(bomApprovalReqDTO.getVLotNm())
										.vNoteType("HBO")
										.userList(apprUserList)
										.vMoveUrl(pageUrl)
										.build());

			responseVO.setOkWithCode(resultCode.getCode(), "승인하였습니다.", null);
		} else if (ApprovalResultCode.APPR_BACK.getCode().equals(resultCode.getCode())) {
			//반려 처리에 관련
			this.updateReturnApprovalRequest(bomApprovalReqDTO);

			List<String> contCdList = bomApprovalReqDTO.getContCdList();

			if (!ObjectUtils.isEmpty(contCdList)) {
				List<String> checkList = new ArrayList<>();

				List<ShelfLifeVO> shelfLifeContInfoList = labNoteCommonService.selectOneShelfLifeContInfo(ShelfLifeVO.builder()
																													 .language(sessionUtil.getLocalLanguage())
																													 .contCdList(contCdList)
																													 .build());

				if (!ObjectUtils.isEmpty(shelfLifeContInfoList)) {
					for (ShelfLifeVO vo : shelfLifeContInfoList) {
						if ("SLS020".equals(vo.getVStatusCd()) || "SLS040".equals(vo.getVStatusCd())) {
							checkList.add(vo.getVContCd());
						}
					}
				}

				for (String contCd : contCdList) {
					if (!checkList.contains(contCd)) {
						labNoteCommonService.deleteShelfLifeStatus(contCd);
					}
				}
			}

			// 메일발송(결재)
			commonService.sendMailApproval(ApprovalDTO.builder().vApprCd(bomApprovalReqDTO.getVApprCd())
																.vResultStatus(resultCode.getCode())
																.vUrl(pageUrl)
																.build());

			commonService.sendAlarm(AlarmRegDTO.builder()
										.vLabNoteCd(bomApprovalReqDTO.getVLabNoteCd())
										.vStatusCd("AL_NOTE3")
										.vAlrTypeCd("AL_NOTE3_06")
										.typeList(Arrays.asList(Const.ALARM, Const.MAIL, Const.TIMELINE, Const.SCHEDULE))
										.vContCd(noteInfo.getVContCd())
										.vContNm(noteInfo.getVContNm())
										.nVerNo(bomApprovalReqDTO.getNVersion() < 10 ? "0" + bomApprovalReqDTO.getNVersion() : "" + bomApprovalReqDTO.getNVersion())
										.vLotNm(bomApprovalReqDTO.getVLotNm())
										.vNoteType("HBO")
										.userList(apprUserList)
										.vMoveUrl(pageUrl)
										.build());

			responseVO.setOkWithCode(resultCode.getCode(), "반려하였습니다.", null);
		} else if (ApprovalResultCode.APPR_SUCC.getCode().equals(resultCode.getCode())
				|| ApprovalResultCode.MUTUAL_SUCC.getCode().equals(resultCode.getCode())) {
			//결제 중 또는 합의 중 관련
			hbdCommonService.ongoingApprovalRequest(vLabNoteCd);

			// 메일발송(결재)
			commonService.sendMailApproval(ApprovalDTO.builder().vApprCd(bomApprovalReqDTO.getVApprCd())
																.vResultStatus(resultCode.getCode())
																.vUrl(pageUrl)
																.build());

			responseVO.setOkWithCode(resultCode.getCode(), "결재하였습니다.", null);
		} else {
			responseVO.setOkWithCode(Const.FAIL, resultCode.getMessage(), null);
		}

		if (StringUtils.isNotEmpty(resultCode.getCode())) {
			// 승인 완료시에만 참조처 메일링
//			if (ApprovalResultCode.ACCEPT_END.getCode().equals(resultCode.getCode())
//			 || ApprovalResultCode.APPR_SUCC.getCode().equals(resultCode.getCode())
//			 || ApprovalResultCode.MUTUAL_SUCC.getCode().equals(resultCode.getCode())) {
			if (ApprovalResultCode.ACCEPT_END.getCode().equals(resultCode.getCode())) {
				// 참조지정 메일발송
				commonService.sendMailReference(ReferenceDTO.builder().vRecordId(vApprCd)
																	  .vTitle(String.format("%s%s", "[참조메일]결재완료-", resApprovalPrcDTO.getDraftTitle()))
																	  .vUrl(pageUrl)
																	  .build());
			}
		}
	}


//	[AS-IS] LabNoteCommonServiceImpl - updateReturnApprovalRequest - 609 line 부터 참고
	@Transactional
	public void updateReturnApprovalRequest(BomApprovalReqDTO bomApprovalReqDTO) {
		List<String> lotCdList = bomApprovalReqDTO.getLotCdList();

		if (!ObjectUtils.isEmpty(lotCdList)) {
			String vApprCd = bomApprovalReqDTO.getVApprCd();

			ElabBomLotVerVO bomLotVerVO = ElabBomLotVerVO.builder()
														 .vLabNoteCd(bomApprovalReqDTO.getVLabNoteCd())
														 .vBomSendType("E")
														 .vBomSendMessage("반려로 인해 SAP에 BOM을 전송하지 못하였습니다.")
														 .vUpdateUserid(sessionUtil.getLoginId())
														 .build();

			for (String lotCd : lotCdList) {
				hbdApprovalMapper.updateLabNoteLotApprCdClear(lotCd);

				bomLotVerVO.setVLotCd(lotCd);
				bomLotVerVO.setVBomLotVer(labNoteCommonService.selectStringElabBomLotVer(lotCd, vApprCd));

				labNoteCommonService.updateElabBomLotVerType(bomLotVerVO);
			}

			hbdCommonService.updateStatusCd_LNC06_25(bomLotVerVO.getVLabNoteCd());
		}
	}

//	===========================================================================================================================================================
//	처방 확정 결재 처리(GATE 2) 로직 Start
//	[AS-IS] LabNoteCommonController - lab_note_common_save - 290 line 부터 참고
	@Transactional
	public ResponseVO updateGate2Approval(MassApprovalReqDTO massApprovalReqDTO) {
		ResponseVO responseVO = new ResponseVO();

		PgcGqteResVO pgcVo = labNoteCommonService.selectPqcGqteResInfo(massApprovalReqDTO.getVApprCd());

		if (!ObjectUtils.isEmpty(pgcVo)) {
			massApprovalReqDTO.setVLabNoteCd(pgcVo.getVLabNoteCd());
			massApprovalReqDTO.setNVersion(pgcVo.getNVersion());
		}

		List<LabNoteProcessContDecideListDTO> lotList = hbdCommonService.selectGate2ApprLotList(massApprovalReqDTO.getVApprCd());

		if (lotList == null || lotList.isEmpty()) {
			responseVO.setOkWithCode(Const.FAIL, "필수 입력값이 없습니다", null);
			return responseVO;
		}

		if (ObjectUtils.isEmpty(massApprovalReqDTO.getLotList())) {
			massApprovalReqDTO.setLotList(lotList);
		}

		massApprovalReqDTO.setVLotNm(lotList.get(0).getVLotNm() + (lotList.size() > 1 ? "외 " + (lotList.size() - 1) + "건" : ""));

		// 양산승인 결재처리
		this.labNoteApprovalMassComplete(responseVO, massApprovalReqDTO);

		return responseVO;
	}

//	[AS-IS] LabNoteCommonController - lab_note_approval_mass_complete - 524 line 부터 참고
	@Transactional
	private void labNoteApprovalMassComplete(ResponseVO responseVO, MassApprovalReqDTO massApprovalReqDTO) {
		String vApprCd = massApprovalReqDTO.getVApprCd();
		String vLabNoteCd = massApprovalReqDTO.getVLabNoteCd();
		int ver = massApprovalReqDTO.getNVersion();

		if (StringUtils.isEmpty(vApprCd) || StringUtils.isEmpty(vLabNoteCd)) {
			responseVO.setOkWithCode(Const.FAIL, "필수 인자값이 없습니다", null);
			return;
		}

		ResApprovalPrcDTO resApprovalPrcDTO = commonService.handlingOfApprovalPrcEp(ReqApprovalPrcDTO.builder()
																									 .vApprCd(massApprovalReqDTO.getVApprCd())
																									 .nCurRegseq(massApprovalReqDTO.getNCurRegseq())
																									 .nCurApprseq(massApprovalReqDTO.getNCurApprseq())
																									 .vApprStatus(massApprovalReqDTO.getVApprStatus())
																									 .vApprSubStatus(massApprovalReqDTO.getVApprSubStatus())
																									 .vApprOpinion(massApprovalReqDTO.getVApprOpinion())
																									 .build());

		HbdNoteInfoDTO noteInfo = hbdCommonService.selectLabNoteInfo(vLabNoteCd);

		ApprovalResultCode resultCode = resApprovalPrcDTO.getApprovalResultCode();

		String pageUrl = new StringBuilder()
								.append("/hbd/all-lab-note-prd-process?vLabNoteCd=").append(vLabNoteCd)
								.append("&vTabId=confirm")
								.append("&nVersion=").append(massApprovalReqDTO.getNVersion())
								.append("&vFlagEndAppr=Y")
								.append("&vApprCd=").append(vApprCd)
								.toString();
		
		List<String> apprUserList = new ArrayList<String>();
		apprUserList.add(massApprovalReqDTO.getVUserid());		//연구원
		
		List<String> referenceUserList = commonService.selectReferenceUserList(vApprCd);

		if (referenceUserList != null && !referenceUserList.isEmpty()) {
			apprUserList.addAll(referenceUserList);
		}

		if (ApprovalResultCode.ACCEPT_END.getCode().equals(resultCode.getCode())) {
			//승인 완료 처리에 관련
			//this.updateLabNoteGate2End(massApprovalReqDTO);
			if (massApprovalReqDTO.getLotList() != null && !massApprovalReqDTO.getLotList().isEmpty()) {

				LotDecideRegDTO lotDTO = LotDecideRegDTO.builder()
												.vLabNoteCd(vLabNoteCd)
												.nVersion(massApprovalReqDTO.getNVersion())
												.vLand1("UN")
												.vPlantMstCd(massApprovalReqDTO.getVPlantMstCd())
												.build();

				for (LabNoteProcessContDecideListDTO lotInfo : massApprovalReqDTO.getLotList()) {
					lotDTO.setVLotCd(lotInfo.getVG2PqcLotCd());
					lotDTO.setVContPkCd(lotInfo.getVContPkCd());
					lotDTO.setVPlantCd(lotInfo.getVPlantCd());
					lotDTO.setVFlagRepresent(lotInfo.getVFlagRepresent());
					hbdCommonService.updateLabNoteLotDecide(lotDTO);
					hbdCommonService.updateNoteMstNoiValue(lotDTO.getVContPkCd(), lotDTO.getNVersion(), true);
				}
			}

			commonService.sendAlarm(AlarmRegDTO.builder()
										.vLabNoteCd(vLabNoteCd)
										.vStatusCd("AL_NOTE4")
										.vAlrTypeCd("AL_NOTE4_03")
										.typeList(Arrays.asList(Const.ALARM, Const.MAIL, Const.TIMELINE, Const.SCHEDULE))
										.vContCd(noteInfo.getVContCd())
										.vContNm(noteInfo.getVContNm())
										.nVerNo((ver < 10 ? "0" : "") + String.valueOf(ver))
										.vLotNm(massApprovalReqDTO.getVLotNm())
										.vNoteType("HBO")
										.userList(apprUserList)
										.vMoveUrl(pageUrl)
										.build());

			// 메일발송(결재완료)
			commonService.sendMailELabNoteApproval(NoteApprovalDTO.builder()
																  .vApprCd(massApprovalReqDTO.getVApprCd())
																  .vLabNoteCd(massApprovalReqDTO.getVLabNoteCd())
																  .nVersion(massApprovalReqDTO.getNVersion())
																  .vNoteType("HBO")
																  .vUrl(pageUrl)
																  .build());

			responseVO.setOkWithCode(resultCode.getCode(), "결재 완료 처리 되었습니다.", null);
		} else if (ApprovalResultCode.APPR_BACK.getCode().equals(resultCode.getCode())) {
			//반려 처리에 관련
			hbdCommonService.updateNoteStatusCd(vLabNoteCd, "LNC06_28");

			commonService.sendAlarm(AlarmRegDTO.builder()
										.vLabNoteCd(vLabNoteCd)
										.vStatusCd("AL_NOTE4")
										.vAlrTypeCd("AL_NOTE4_04")
										.typeList(Arrays.asList(Const.ALARM, Const.MAIL, Const.TIMELINE, Const.SCHEDULE))
										.vContCd(noteInfo.getVContCd())
										.vContNm(noteInfo.getVContNm())
										.nVerNo((ver < 10 ? "0" : "") + String.valueOf(ver))
										.vLotNm(massApprovalReqDTO.getVLotNm())
										.vNoteType("HBO")
										.userList(apprUserList)
										.vMoveUrl(pageUrl)
										.build());

			// 메일발송(결재)
			commonService.sendMailApproval(ApprovalDTO.builder().vApprCd(vApprCd)
																.vResultStatus(resultCode.getCode())
																.vUrl(pageUrl)
																.build());

			responseVO.setOkWithCode(resultCode.getCode(), "반려하였습니다.", null);
		} else if (ApprovalResultCode.APPR_SUCC.getCode().equals(resultCode.getCode())
				|| ApprovalResultCode.MUTUAL_SUCC.getCode().equals(resultCode.getCode())) {
			//결제 중 또는 합의 중 관련
			// 메일발송(결재)
			commonService.sendMailApproval(ApprovalDTO.builder().vApprCd(vApprCd)
																.vResultStatus(resultCode.getCode())
																.vUrl(pageUrl)
																.build());

			responseVO.setOkWithCode(resultCode.getCode(), "결재하였습니다.", null);
		} else {
			responseVO.setOkWithCode(Const.FAIL, resultCode.getMessage(), null);
		}
	}

//	[AS-IS] LabNoteCommonServiceImpl - updateLabNoteGate2End - 573 line 부터 참고
	@Transactional
	private void updateLabNoteGate2End(MassApprovalReqDTO massApprovalReqDTO) {
		String vLabNoteCd = massApprovalReqDTO.getVLabNoteCd();

		String flagTot = hbdCommonService.selectLabNoteContMassEndCheck(vLabNoteCd);

		if ("Y".equals(flagTot)) {
			hbdCommonService.updateStatusCd_LNC06_51(vLabNoteCd);
		}
	}

//	===========================================================================================================================================================
//	제품명 확정 결재 처리 로직 Start
//	[AS-IS] LabNoteCommonController - lab_note_func_decide_name_save - 5093 line 부터 참고
	@Transactional
	public ResponseVO updateFuncDecideName(FuncDecideNameReqDTO funcDecideNameReqDTO) {
		ResponseVO responseVO = new ResponseVO();

		FuncDecideNameVO nameVo = labNoteCommonService.selectLabNoteFuncDecideNameInfoVerAppr(funcDecideNameReqDTO.getVApprCd());

		if (ObjectUtils.isEmpty(nameVo)) {
			responseVO.setOkWithCode(Const.FAIL, "잘못된 접근입니다.", null);
			return responseVO;
		}

		nameVo.setVUpdateUserid(sessionUtil.getLoginId());
		nameVo.setLocalLanguage(sessionUtil.getLocalLanguage());

		ResApprovalPrcDTO resApprovalPrcDTO = commonService.handlingOfApprovalPrcEp(ReqApprovalPrcDTO.builder()
																									 .vApprCd(funcDecideNameReqDTO.getVApprCd())
																									 .nCurRegseq(funcDecideNameReqDTO.getNCurRegseq())
																									 .nCurApprseq(funcDecideNameReqDTO.getNCurApprseq())
																									 .vApprStatus(funcDecideNameReqDTO.getVApprStatus())
																									 .vApprSubStatus(funcDecideNameReqDTO.getVApprSubStatus())
																									 .vApprOpinion(funcDecideNameReqDTO.getVApprOpinion())
																									 .build());

		HbdNoteInfoDTO noteInfoDTO = hbdCommonService.selectLabNoteInfo(nameVo.getVLabNoteCd());

		ApprovalResultCode resultCode = resApprovalPrcDTO.getApprovalResultCode();

		List<String> apprUserList = new ArrayList<String>();
		apprUserList.add(noteInfoDTO.getVUserid());		//연구원
		
		List<String> referenceUserList = commonService.selectReferenceUserList(funcDecideNameReqDTO.getVApprCd());

		if (referenceUserList != null && !referenceUserList.isEmpty()) {
			apprUserList.addAll(referenceUserList);
		}
		
		if (ApprovalResultCode.ACCEPT_END.getCode().equals(resultCode.getCode())) {
			nameVo.setVStatusCd("DOC500"); //결재완료
			nameVo.setVFlagComplete("Y"); //결재완료 날짜 저장

			labNoteCommonService.updateLabNoteFuncDecideName(nameVo);
			this.updateLabNoteFuncDecideNameComplete(nameVo);

			//AL_NOTE0_04 기능성 제품명 확정 결재 승인
			String pageUrl = new StringBuilder()
					.append("/hbd/all-lab-note-prd-process?vLabNoteCd=").append(nameVo.getVLabNoteCd())
					.append("&vTabId=funcComplete")
					.append("&vSubTabId=prodName")
					.append("&vApprCd=").append(funcDecideNameReqDTO.getVApprCd())
					.toString();

			// 메일발송(결재)
			commonService.sendMailApproval(ApprovalDTO.builder()
							.vApprCd(funcDecideNameReqDTO.getVApprCd())
							.vResultStatus(resultCode.getCode())
							.vUrl(pageUrl)
							.build());
			
			commonService.sendAlarm(AlarmRegDTO.builder()
					.vLabNoteCd(noteInfoDTO.getVLabNoteCd())
					.vStatusCd("AL_NOTE0")
					.vAlrTypeCd("AL_NOTE0_04")
					.typeList(Arrays.asList(Const.ALARM, Const.MAIL, Const.TIMELINE))
					.vContCd(noteInfoDTO.getVContCd())
					.vContNm(noteInfoDTO.getVContNm())
					.vNoteType("HBO")
					.userList(apprUserList)
					.vMoveUrl(pageUrl)
					.build());

			responseVO.setOkWithCode(resultCode.getCode(), "승인하였습니다.", null);
		} else if (ApprovalResultCode.APPR_BACK.getCode().equals(resultCode.getCode())) {
			nameVo.setVStatusCd("DOC030"); //결재완료
			nameVo.setVFlagComplete("Y"); //결재완료 날짜 저장

			labNoteCommonService.updateLabNoteFuncDecideName(nameVo);

			//AL_NOTE0_08 기능성 제품명 확정 결재 반려
			String pageUrl = new StringBuilder()
					.append("/hbd/all-lab-note-prd-process?vLabNoteCd=").append(nameVo.getVLabNoteCd())
					.append("&vTabId=funcComplete")
					.append("&vSubTabId=prodName")
					.append("&vApprCd=").append(funcDecideNameReqDTO.getVApprCd())
					.toString();

			// 메일발송(결재)
			commonService.sendMailApproval(ApprovalDTO.builder()
					.vApprCd(funcDecideNameReqDTO.getVApprCd())
					.vResultStatus(resultCode.getCode())
					.vUrl(pageUrl)
					.build());
			
			commonService.sendAlarm(AlarmRegDTO.builder()
					.vLabNoteCd(noteInfoDTO.getVLabNoteCd())
					.vStatusCd("AL_NOTE0")
					.vAlrTypeCd("AL_NOTE0_08")
					.typeList(Arrays.asList(Const.ALARM, Const.MAIL, Const.TIMELINE))
					.vContCd(noteInfoDTO.getVContCd())
					.vContNm(noteInfoDTO.getVContNm())
					.vNoteType("HBO")
					.userList(apprUserList)
					.vMoveUrl(pageUrl)
					.build());

			responseVO.setOkWithCode(resultCode.getCode(), "반려하였습니다.", null);
		} else if (ApprovalResultCode.APPR_SUCC.getCode().equals(resultCode.getCode())
				|| ApprovalResultCode.MUTUAL_SUCC.getCode().equals(resultCode.getCode())) {

			String pageUrl = new StringBuilder()
					.append("/hbd/all-lab-note-prd-process?vLabNoteCd=").append(nameVo.getVLabNoteCd())
					.append("&vTabId=funcComplete")
					.append("&vSubTabId=prodName")
					.append("&vApprCd=").append(funcDecideNameReqDTO.getVApprCd())
					.toString();
			
			// 메일발송(결재)
			commonService.sendMailApproval(ApprovalDTO.builder().vApprCd(funcDecideNameReqDTO.getVApprCd())
																.vResultStatus(resultCode.getCode())
																.vUrl(pageUrl)
																.build());

			responseVO.setOkWithCode(resultCode.getCode(), "결재하였습니다.", null);
		} else {
			responseVO.setOkWithCode(Const.FAIL, resultCode.getMessage(), null);
		}

		return responseVO;
	}

//	[AS-IS] LabNoteCommonServiceImpl - updateLabNoteFuncDecideNameComplete - 6978 line 부터 참고
	// HBD
	@Transactional
	private void updateLabNoteFuncDecideNameComplete(FuncDecideNameVO funcDecideNameVO) {
		//MST 삭제
		List<FuncDecideContNameVO> list = hbdCommonService.selectLabNoteFuncDecideContName(funcDecideNameVO);

		if (!ObjectUtils.isEmpty(list)) {
			funcDecideNameVO.setVFlagDecide("Y");

			for (FuncDecideContNameVO vo : list) {
				funcDecideNameVO.setVContPkCd(vo.getVContPkCd());
				funcDecideNameVO.setVDecideContNm(vo.getVDecideContNm());

				hbdCommonService.updateLabNoteContUpdateDecideName(funcDecideNameVO);
			}
		}
	}
}
