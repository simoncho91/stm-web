package com.mybeaker.app.hbd.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.skincare.model.GramTrPlanVO;
import com.mybeaker.app.skincare.model.MaterialNoteContVO;
import com.mybeaker.app.skincare.model.MaterialNoteVersionVO;
import com.mybeaker.app.skincare.model.StabilityTitleVO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class HbdGramResDTO {
	
	private List<StabilityTitleVO> titleList;
	
	private List<HbdNoteStabilityValueVO> valueList;
	
	private MaterialNoteContVO contVO;
	
	private MaterialNoteVersionVO verVO;
	
	private HbdNoteLotVO lotVO;
	
	private List<HbdNoteGramVO> gramList;
	
	private HbdNoteGramVO gramVO;
	
	private List<GramTrPlanVO> gramTrList;
	
	@JsonProperty("vGramCd")
	private String vGramCd;
}
