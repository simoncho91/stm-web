package com.mybeaker.app.hbd.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class HbdContentDetailDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vLotNm")
	private String vLotNm;

	@JsonProperty("vMateCd")
	private String vMateCd;

	@JsonProperty("vMateNm")
	private String vMateNm;

	@JsonProperty("nRate")
	private double nRate;

	@JsonProperty("nRateSum")
	private double nRateSum;

	@JsonProperty("vUsernm")
	private String vUsernm;
}
