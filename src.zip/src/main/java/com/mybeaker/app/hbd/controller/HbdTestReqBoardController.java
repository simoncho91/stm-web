package com.mybeaker.app.hbd.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.hbd.service.HbdTestReqBoardService;
import com.mybeaker.app.labnote.model.LabNoteTestQrCodeReqDTO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Tag(name = "HBD 시험의뢰 현황", description = "HBD 시험의뢰 현황")
@RestController
@RequestMapping("/api/hbd/trboard")
public class HbdTestReqBoardController {

	
	private final HbdTestReqBoardService hbdTestReqBoardService;
	
//	/elab/sc/note/sc_note_experiment_view.do
//	lab_note_experiment_view_tab03
	@Operation(summary = "시험의뢰 현황", description = "시험의뢰 현황 목록")
	@GetMapping("/select-test-req-board-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectTestReqBoardList (
			@RequestParam String vLabNoteCd
			, @RequestParam String vContPkCd
			, @RequestParam String vContCd) {
		log.debug("select-test-req-board-list Start!");
		log.debug("vLabNoteCd : {}", vLabNoteCd);
		log.debug("vContPkCd : {}", vContPkCd);
		log.debug("vContCd : {}", vContCd);
		
		return ResponseEntity.ok(hbdTestReqBoardService.selectTestReqBoardList(vLabNoteCd, vContPkCd, vContCd));
	}
	
	@Operation(summary = "시험의뢰 현황 QR코드 생성", description = "시험의뢰 현황 QR코드 생성")
	@GetMapping("/select-qr-code-lab-note-test-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectQrCodeLabNoteTestList (
			LabNoteTestQrCodeReqDTO labNoteTestQrCodeDTO
			) {
		
		log.debug("SkincareTestReqBoardController.selectQrCodeLabNoteTestList => params : { LabNoteTestQrCodeDTO: {} }", labNoteTestQrCodeDTO.toString());
		return ResponseEntity.ok(hbdTestReqBoardService.selectQrCodeLabNoteTestList(labNoteTestQrCodeDTO));
	}
	
	
	
}
