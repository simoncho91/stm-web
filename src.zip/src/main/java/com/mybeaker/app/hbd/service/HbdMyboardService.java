package com.mybeaker.app.hbd.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mybeaker.app.hbd.mapper.HbdMyboardMapper;
import com.mybeaker.app.labnote.model.MyBoardNoteInfoDTO;
import com.mybeaker.app.labnote.model.MyBoardNoteInfoReqDTO;
import com.mybeaker.app.labnote.model.MyBoardStateReqDTO;
import com.mybeaker.app.labnote.service.LabNoteCommonService;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.utils.SessionUtil;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class HbdMyboardService {
	private final HbdMyboardMapper hbdMyboardMapper;

	private final HbdCommonService hbdCommonService;

	private final LabNoteCommonService labNoteCommonService;

	private final SessionUtil sessionUtil;

	public ResponseVO selectMyNoteList() {
		ResponseVO responseVO = new ResponseVO();
		String isAdmin = sessionUtil.isSysadmin() ? "Y" : "N";
		responseVO.setOk(hbdMyboardMapper.selectMyNoteList(MyBoardNoteInfoReqDTO.builder()
																	.vUserid(sessionUtil.getLoginId())
																	.vDeptCd(sessionUtil.getSigmaDeptcd())
																	.localLanguage(sessionUtil.getLocalLanguage())
																	.isAdmin(isAdmin)
																	.endRownum(6)
																	.isMaster(sessionUtil.getManagerYn())
																	.build()));
		return responseVO;
	}

	public ResponseVO selectRecentNoteList() {
		ResponseVO responseVO = new ResponseVO();
		responseVO.setOk(hbdMyboardMapper.selectRecentNoteList(sessionUtil.getLoginId(), sessionUtil.getLocalLanguage()));
		return responseVO;
	}

	public ResponseVO selectSharedNoteList() {
		ResponseVO responseVO = new ResponseVO();
		String isAdmin = sessionUtil.isSysadmin() ? "Y" : "N";
		responseVO.setOk(hbdMyboardMapper.selectSharedNoteList(sessionUtil.getLoginId(), sessionUtil.getLocalLanguage(), isAdmin));
		return responseVO;
	}

	public ResponseVO selectScheduleList() {
		ResponseVO responseVO = new ResponseVO();
		String isAdmin = sessionUtil.isSysadmin() || "Y".equals(sessionUtil.getManagerYn()) ? "Y" : "N";

		List<MyBoardNoteInfoDTO> labNoteList = hbdMyboardMapper.selectMyNoteList(MyBoardNoteInfoReqDTO.builder()
																						.vUserid(sessionUtil.getLoginId())
																						.vDeptCd(sessionUtil.getSigmaDeptcd())
																						.localLanguage(sessionUtil.getLocalLanguage())
																						.isAdmin(isAdmin)
																						.endRownum(4)
																						.isMaster(sessionUtil.getManagerYn())
																						.build());

		String activeTabStatus = "AL_NOTE1";
		String vStatusCd = "";

		for (MyBoardNoteInfoDTO noteInfo : labNoteList) {
			vStatusCd = noteInfo.getVStatusCd();
			if("LNC06_41".equals(noteInfo.getVStatusCd())) {
				vStatusCd = hbdCommonService.selectLabNoteStatusCd(noteInfo.getVLabNoteCd());
			}

			activeTabStatus = labNoteCommonService.selectLabNoteActiveStatus(vStatusCd);

			noteInfo.setVActiveStatus(activeTabStatus);
		}


		responseVO.setOk(labNoteList);
		return responseVO;
	}

	public ResponseVO selectBrandCurrentStateInfo(MyBoardStateReqDTO myBoardStateReqDTO) {
		ResponseVO responseVO = new ResponseVO();

		if (!"Y".equals(sessionUtil.getManagerYn()) && !sessionUtil.isSysadmin()) {
			responseVO.setOk(null);
			return responseVO;
		}

		myBoardStateReqDTO.setVDeptCd(sessionUtil.getSigmaDeptcd());
		myBoardStateReqDTO.setLocalLanguage(sessionUtil.getLocalLanguage());

		responseVO.setOk(hbdMyboardMapper.selectBrandCurrentStateInfo(myBoardStateReqDTO));
		return responseVO;
	}

	public ResponseVO selectLaborCurrentStateInfo(MyBoardStateReqDTO myBoardStateReqDTO) {
		ResponseVO responseVO = new ResponseVO();

		if (!"Y".equals(sessionUtil.getManagerYn()) && !sessionUtil.isSysadmin()) {
			responseVO.setOk(null);
			return responseVO;
		}

		myBoardStateReqDTO.setVDeptCd(sessionUtil.getSigmaDeptcd());
		myBoardStateReqDTO.setLocalLanguage(sessionUtil.getLocalLanguage());

		responseVO.setOk(hbdMyboardMapper.selectLaborCurrentStateInfo(myBoardStateReqDTO));
		return responseVO;
	}

	public ResponseVO selectExaminationList() {
		ResponseVO responseVO = new ResponseVO();
		String isAdmin = sessionUtil.isSysadmin() ? "Y" : "N";

		responseVO.setOk(hbdMyboardMapper.selectExaminationList(sessionUtil.getLoginId(), sessionUtil.getLocalLanguage(), isAdmin));
		return responseVO;
	}
}
