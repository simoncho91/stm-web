package com.mybeaker.app.hbd.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.mybeaker.app.hbd.mapper.HbdSearchMapper;
import com.mybeaker.app.hbd.model.HbdContentDetailReqDTO;
import com.mybeaker.app.hbd.model.HbdCounterMapDTO;
import com.mybeaker.app.hbd.model.HbdCounterMapKeywordDTO;
import com.mybeaker.app.hbd.model.HbdMateRateDTO;
import com.mybeaker.app.hbd.model.HbdMateRateReqDTO;
import com.mybeaker.app.hbd.model.HbdMstSearchDTO;
import com.mybeaker.app.model.Const;
import com.mybeaker.app.model.dto.PagingDTO;
import com.mybeaker.app.model.dto.ReqCommSearchInfoDTO;
import com.mybeaker.app.model.dto.ResCommSearchInfoDTO;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.utils.CommonUtil;
import com.mybeaker.app.utils.ConvertUtil;
import com.mybeaker.app.utils.SessionUtil;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class HbdSearchService {
	private final HbdSearchMapper hbdSearchMapper;
	
	private final SessionUtil sessionUtil;
	
	public ResponseVO selectMstSearchList(ReqCommSearchInfoDTO reqCommSearchInfoDTO) {
		ResponseVO responseVO = new ResponseVO();
		
		int totalCnt = hbdSearchMapper.selectMstSearchListCount(reqCommSearchInfoDTO);
		List<HbdMstSearchDTO> list = null;
		CommonUtil.setPaging(reqCommSearchInfoDTO, totalCnt);
		
		if (totalCnt > 0) {
			reqCommSearchInfoDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
			list = hbdSearchMapper.selectMstSearchList(reqCommSearchInfoDTO);
		}
		
		PagingDTO page = ConvertUtil.convert(reqCommSearchInfoDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
										.page(page)
										.list(list)
										.build();

		responseVO.setOk(res);
		return responseVO;
	}
	
	public ResponseVO selectContentDetail(HbdContentDetailReqDTO contentDetailReqDTO) {
		ResponseVO responseVO = new ResponseVO();
		
		contentDetailReqDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
		
		responseVO.setOk(hbdSearchMapper.selectContentDetail(contentDetailReqDTO));
		return responseVO;
	}
	
	public ResponseVO selectCounterMapList(String vKeyword) {
		ResponseVO responseVO = new ResponseVO();
		
		int totalCnt = hbdSearchMapper.selectCounterMapKeywordListCount(vKeyword);
		
		if (totalCnt > 1000) { 
			responseVO.setOkWithCode(Const.FAIL, "1000건 이상의 결과가 검색됩니다. <br> 좀더 상세한 키워드로 검색해주세요", null);
		}
		
		List<HbdCounterMapDTO> counterMapList = null;
		
		if (totalCnt > 0) {
			List<String> contPkCdList = new ArrayList<>();
			List<HbdCounterMapKeywordDTO> list = hbdSearchMapper.selectCounterMapKeywordList(vKeyword);
			 
			if (!ObjectUtils.isEmpty(list)) {
				String counterCd = null;
				String contPkCd = null;
				boolean existsCounterCd = false;
				 
				for (HbdCounterMapKeywordDTO dto : list) {
					counterCd = dto.getVCompleteCounterCd();
					 
					if (counterCd == null || "".equals(counterCd)) {
						contPkCd = dto.getVContPkCd();

						contPkCdList.add(contPkCd);
					} else {
						do {
							HbdCounterMapKeywordDTO tempDto = hbdSearchMapper.selectCounterMapKeyword(counterCd);
							
							counterCd = tempDto.getVCompleteCounterCd();
							existsCounterCd = !counterCd.isEmpty();
							
							if (!existsCounterCd) {
								contPkCd = tempDto.getVContPkCd();

								if (!contPkCdList.contains(contPkCd)) {
									contPkCdList.add(contPkCd);
								}
							}
						} while (existsCounterCd);
					}
				}
			}
			
			int size = contPkCdList.size();
			
			if (size > 1000)  {
				responseVO.setOkWithCode(Const.FAIL, "1000건 이상의 결과가 검색됩니다. <br> 좀더 상세한 키워드로 검색해주세요", null);
			}
			
			if (size > 0) {
				counterMapList = hbdSearchMapper.selectCounterMapList(contPkCdList);
			}
		}
		
		responseVO.setOk(counterMapList);
		return responseVO;
	}
	
	public ResponseVO selectMateRateInfo(HbdMateRateReqDTO hbdMateRateReqDTO) {
		ResponseVO responseVO = new ResponseVO();
		
		List<HbdContentDetailReqDTO> mateRateParamList = hbdMateRateReqDTO.getMateRateParamList();
		
		List<List<HbdMateRateDTO>> mateRateInfoList = new ArrayList<>();
		
		for (int i = 0; i < mateRateParamList.size(); i++) {
			mateRateParamList.get(i).setLocalLanguage(sessionUtil.getLocalLanguage());
			
			List<HbdMateRateDTO> tempList = hbdSearchMapper.selectMateRateInfo(mateRateParamList.get(i));
			
			if (!ObjectUtils.isEmpty(tempList)) {
				mateRateInfoList.add(tempList);
			}
		}
		
		responseVO.setOk(mateRateInfoList);
		return responseVO;
	}
}
