package com.mybeaker.app.hbd.model;

import java.util.List;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.skincare.model.MaterialDTO;

import lombok.Data;

@Data
public class HbdMaterialSaveRegDTO {

	@NotEmpty
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	private List<String> delGrpCdList;
	
	private List<HbdNoteGroupDTO> groupList;
	
	private List<String> delMatePkCdList;
	
	private List<MaterialDTO> mateList;
	
	@NotEmpty
	@JsonProperty("vPlantCd")
	private String vPlantCd;
	
	@NotEmpty
	@JsonProperty("vLand1")
	private String vLand1;
	
	@JsonProperty("vContPkCd")
	private String vContPkCd;
	
	@JsonProperty("nVersion")
	private int nVersion;
	
	@JsonProperty("vLotCd")
	private String vLotCd;
	
	private List<HbdNoteLotDTO> lotList;
	
	private HbdNoteVersionDTO versionDTO;
	
	@JsonProperty("vStatusCd")
	private String vStatusCd;
	
	@JsonProperty("vSiteType")
	private String vSiteType;

	@JsonProperty("vContCd")
	private String vContCd;
	
	@JsonProperty("vContNm")
	private String vContNm;
	
	@JsonProperty("vLotNm")
	private String vLotNm;
	
	@JsonProperty("vMoveUrl")
	private String vMoveUrl;
	
	@JsonProperty("vCodeType")
	private String vCodeType;
}
