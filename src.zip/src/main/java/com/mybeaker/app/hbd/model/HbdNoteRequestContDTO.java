package com.mybeaker.app.hbd.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HbdNoteRequestContDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vPrdCd")
	private String vPrdCd;

	@JsonProperty("vPrdNm")
	private String vPrdNm;

	@JsonProperty("vPrdNmEn")
	private String vPrdNmEn;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vContNmCn")
	private String vContNmCn;

	@JsonProperty("vContNmEn")
	private String vContNmEn;

	@JsonProperty("vNoteContNm")
	private String vNoteContNm;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vUsernm")
	private String vUsernm;

	@JsonProperty("vCodeType")
	private String vCodeType;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("vFlagRepresent")
	private String vFlagRepresent;

	@JsonProperty("vFlagCancel")
	private String vFlagCancel;

	@JsonProperty("vFlagLaunch")
	private String vFlagLaunch;

	@JsonProperty("vStatusCd")
	private String vStatusCd;

	@JsonProperty("vTctnBynmNm")
	private String vTctnBynmNm;

	private String newYn;

	private String vRegUserid;

	private String vUpdateUserid;
}
