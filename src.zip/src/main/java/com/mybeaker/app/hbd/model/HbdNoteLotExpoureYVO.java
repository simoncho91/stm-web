package com.mybeaker.app.hbd.model;

import java.util.List;

import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@Data
public class HbdNoteLotExpoureYVO extends ParentDTO {

	private List<String> vLotCdList;

	@Builder
	public HbdNoteLotExpoureYVO(String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm,
			List<String> vLotCdList) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.vLotCdList = vLotCdList;
	}
}
