package com.mybeaker.app.hbd.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class HbdMstSearchDTO {
	@JsonProperty("vPlantNm")
	private String vPlantNm;

	@JsonProperty("vBrdNm")
	private String vBrdNm;

	@JsonProperty("vUsernm")
	private String vUsernm;

	@JsonProperty("vDeptNm")
	private String vDeptNm;

	@JsonProperty("vBrdCd")
	private String vBrdCd;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vDeptCd")
	private String vDeptCd;

	@JsonProperty("vCompleteDt")
	private String vCompleteDt;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vLotCd")
	private String vLotCd;
}
