package com.mybeaker.app.hbd.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.mybeaker.app.hbd.model.HbdCounterDTO;
import com.mybeaker.app.hbd.model.HbdLabNoteExperimentVO;
import com.mybeaker.app.hbd.model.HbdNoteContDTO;
import com.mybeaker.app.hbd.model.HbdNoteInfoRegDTO;
import com.mybeaker.app.hbd.model.HbdNoteLotDTO;
import com.mybeaker.app.hbd.model.HbdNoteRequestContDTO;
import com.mybeaker.app.hbd.model.HbdNoteVersionDTO;
import com.mybeaker.app.hbd.model.InsertHbdNoteHalfRegDTO;
import com.mybeaker.app.labnote.model.ElabChgLogDTO;
import com.mybeaker.app.labnote.model.ElabChgLogSearchReqDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonRequestMateDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonTagDTO;
import com.mybeaker.app.labnote.model.LabNoteDecideDTO;
import com.mybeaker.app.labnote.model.LabNoteRequestMateRegDTO;
import com.mybeaker.app.labnote.model.LabNoteRequestPjtDTO;
import com.mybeaker.app.labnote.model.LabNoteVersionDTO;
import com.mybeaker.app.labnote.model.LabNoteVersionModifyReqDTO;
import com.mybeaker.app.labnote.model.LabNoteVersionRegDTO;
import com.mybeaker.app.labnote.model.LaunchCompleteContDTO;
import com.mybeaker.app.labnote.model.PlantChangeReqDTO;
import com.mybeaker.app.labnote.model.PlantExtendDTO;
import com.mybeaker.app.labnote.model.PlantExtendReqDTO;
import com.mybeaker.app.labnote.model.ThisInventoryVO;
import com.mybeaker.app.skincare.model.BookmarkVO;
import com.mybeaker.app.skincare.model.LabNoteExperimentReqDTO;
import com.mybeaker.app.skincare.model.LabNoteHal4VO;
import com.mybeaker.app.skincare.model.LabNoteNonPrdVO;
import com.mybeaker.app.skincare.model.VersionContVO;

@Mapper
public interface HbdNoteRequestMapper {

	int selectHboRequstListCount(LabNoteExperimentReqDTO schVO);

	List<HbdLabNoteExperimentVO> selectHboRequstList(LabNoteExperimentReqDTO schVO);

	int selectHal4RequstListCount(LabNoteExperimentReqDTO schVO);

	List<LabNoteHal4VO> selectHal4RequstList(LabNoteExperimentReqDTO schVO);

	int selectNonPrdRequstListCount(LabNoteExperimentReqDTO schVO);

	List<LabNoteNonPrdVO> selectNonPrdRequstList(LabNoteExperimentReqDTO schVO);

	List<PlantExtendDTO> selectLabNoteContPlantInfoList(String vLabNoteCd, String vCodeType);

	List<VersionContVO> selectLabNotePlantExpansionList(String vLabNoteCd, String vCodeType, String vContCd);

	List<BookmarkVO> selectLabNotePlantExpansionBookmarkList(PlantExtendReqDTO plantExtendReqDTO);

	List<VersionContVO> selectLabNoteSavePlantList(String vLabNoteCd);

	int updatePlantAndSiteType(PlantChangeReqDTO plantChangeDTO);

	void updateCopyPrdCd(PlantChangeReqDTO plantChangeDTO);

	void updateFlagRepresentN(String vLabNoteCd);

	void updateFlagRepresentY(PlantChangeReqDTO plantChangeDTO);

	List<String> selectContList(String vLabNoteCd);

	int selectLabNoteChgLogListCount(ElabChgLogSearchReqDTO elabChgLogSearchReqDTO);

	List<ElabChgLogDTO> selectLabNoteChgLogList(ElabChgLogSearchReqDTO elabChgLogSearchReqDTO);

	List<LabNoteRequestPjtDTO> selectLabNotePjtList(String vLabNoteCd);

	List<LabNoteCommonTagDTO> selectLabNoteMstVerTagList(String tag1Cd, String vLabNoteCd, int nVersion, String localLanguage);

	List<LabNoteCommonRequestMateDTO> selectLabNoteRequestMateList(String vLabNoteCd, int nVersion);

	List<HbdNoteContDTO> selectLabNoteDecideContInfoList(String vLabNoteCd, String vCodeType, String localLanguage);

	String checkFlagAllDecide(String vLabNoteCd);

	String selectLabNoteFlagMassAppr(String vLabNoteCd);

	List<HbdCounterDTO> selectLabNoteThisCounterList(String vLabNoteCd, String vContPkCd, String localLanguage);

	int updateLabNoteVerModify(LabNoteVersionModifyReqDTO labNoteVersionModifyReqDTO);

	List<LabNoteCommonRequestMateDTO> selectLabNoteRequestMateListForRegister(LabNoteRequestMateRegDTO labNoteRequestMateRegDTO);

	void insertLabNoteMate(LabNoteCommonRequestMateDTO dto);

	void updateLabNoteMate(LabNoteCommonRequestMateDTO dto);

	void deleteLabNoteVerModifyMate(LabNoteCommonRequestMateDTO dto);

	int updateContFlagDevelopment(HbdNoteRequestContDTO hbdNoteRequestContDTO);

	int insertLabNoteMst(HbdNoteInfoRegDTO hbdNoteInfoRegDTO);

	void insertLabNotePjt(HbdNoteInfoRegDTO hbdNoteInfoRegDTO);

	void insertLabNoteCont(HbdNoteRequestContDTO dto);

	void insertLabNoteMstVer(LabNoteVersionRegDTO versionInfo);

	void insertLabNoteMstVerTag(LabNoteVersionRegDTO versionInfo);

	LabNoteVersionDTO selectLabNoteCounterInfo(String vLabNoteCd, int nVersion);

	void deleteLabNoteMate(String vLabNoteCd, String vContPkCd, int nVersion, String vAddTypeCd);

	void insertLabNoteCounterRate(LabNoteVersionDTO dto);

	void insertSAPMaterialReq(HbdNoteInfoRegDTO mstInfo);

	List<LabNoteCommonTagDTO> selectEvMaterialFunctionTagList(String vLabNoteCd, String localLanguage);

	void updateLabNoteFinalCont(LaunchCompleteContDTO vo);

	void insertLabNoteFinalVersion(LaunchCompleteContDTO vo);

	void insertLabNoteFinalLot(LaunchCompleteContDTO vo);

	void insertLabNoteFinalMate(LabNoteDecideDTO lvo);

	void insertLabNoteFinalRate(LabNoteDecideDTO lvo);

	int updateLabNoteMst(HbdNoteInfoRegDTO hbdNoteInfoRegDTO);

	void deleteLabNoteMstTag(HbdNoteInfoRegDTO hbdNoteInfoRegDTO);

	void deleteLabNotePjt(String vLabNoteCd);

	void updateLabNoteMstVer(LabNoteVersionRegDTO versionInfo);

	void deleteLabNoteMstVerTag(LabNoteVersionRegDTO versionInfo);

	String selectRepresentContPkCode(String vLabNoteCd);

	void updateNoteContName(HbdNoteRequestContDTO dto);

	void updateNoteContEtc(HbdNoteRequestContDTO dto);

	void updateContVerCounter(LabNoteVersionRegDTO versionInfo);

	void deleteContAllMate(String oldContPkCd, String vUpdateUserid);

	void updateSAPMaterialReqNameChange(HbdNoteInfoRegDTO mstInfo);

	List<HbdNoteLotDTO> selectLabNoteAllLotList(String vLabNoteCd);

	List<HbdNoteContDTO> selectLabNoteContInfoList(String vLabNoteCd);

	List<HbdNoteVersionDTO> selectLabNoteAllVersionList(String vLabNoteCd);

	void insertVersionHistoryMst(LabNoteVersionModifyReqDTO labNoteVersionModifyReqDTO);

	void insertVersionHistoryMate(LabNoteVersionModifyReqDTO labNoteVersionModifyReqDTO);

	List<LabNoteCommonRequestMateDTO> selectProductVersionHistoryMateList(String vLabNoteCd, String vContPkCd,
			String localLanguage);

	int updateFlagNotAdd(HbdNoteInfoRegDTO hbdNoteInfoRegDTO);

	void deleteNotAddMstTag(String vLabNoteCd);

	//반제품 4자[S]
	void insertOtherPrdNoteMst(InsertHbdNoteHalfRegDTO regDTO);

	void insertOtherPrdNoteMstVer(InsertHbdNoteHalfRegDTO regDTO);

	void insertOtherPrdNoteCont(InsertHbdNoteHalfRegDTO regDTO);

	void insertOtherPrdNoteVersion(InsertHbdNoteHalfRegDTO regDTO);

	public int updateOtherPrdNoteMst(InsertHbdNoteHalfRegDTO regDTO);

	void updateOtherPrdNoteCont(InsertHbdNoteHalfRegDTO regDTO);

	//반제품 4자[E]
	public List<ThisInventoryVO> selectLabNoteThisInventoryList(String vLabNoteCd, String language);

	List<String> selectNoteCancelAlarmReceiveUserList(String vLabNoteCd, String vUserid);

	int updateELabNoteBrandAndPlant(InsertHbdNoteHalfRegDTO regDTO);

	int updateELabNoteContInfo(InsertHbdNoteHalfRegDTO regDTO);

	List<LaunchCompleteContDTO> selectLabNoteVerLaunchCompleteContList(String vLabNoteCd, String vFlagCompleteModify);
}
