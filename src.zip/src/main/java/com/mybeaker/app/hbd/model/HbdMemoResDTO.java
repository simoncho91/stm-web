package com.mybeaker.app.hbd.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class HbdMemoResDTO {
	
	private List<HbdNoteMemoVO> list;
	
	private HbdNoteMemoVO rvo;
	
	@JsonProperty("vMemoTypeCd")
	private String vMemoTypeCd;
}
