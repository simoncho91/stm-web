package com.mybeaker.app.hbd.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class HbdLabNoteExperimentVO {

	@JsonProperty("nRowCnt")
	private int nRowCnt;

	@JsonProperty("nNum")
	private int nNum;

	@JsonProperty("nSort")
	private int nSort;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vLabTypeCd")
	private String vLabTypeCd;

	@JsonProperty("vLabTypeNm")
	private String vLabTypeNm;

	@JsonProperty("vStatusCd")
	private String vStatusCd;

	@JsonProperty("vStatusNm")
	private String vStatusNm;

	@JsonProperty("vViewType")
	private String vViewType;

	@JsonProperty("vBrdCd")
	private String vBrdCd;

	@JsonProperty("vBrdNm")
	private String vBrdNm;

	@JsonProperty("vDeptCd")
	private String vDeptCd;

	@JsonProperty("vDeptNm")
	private String vDeptNm;

	@JsonProperty("vPilotDt")
	private String vPilotDt;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vUsernm")
	private String vUsernm;

	@JsonProperty("vMainContPkCd")
	private String vMainContPkCd;

	@JsonProperty("vMainContCd")
	private String vMainContCd;

	@JsonProperty("vMainContNm")
	private String vMainContNm;

	@JsonProperty("vMainUserid")
	private String vMainUserid;

	@JsonProperty("vMainUsernm")
	private String vMainUsernm;

	@JsonProperty("vSubContPkCd")
	private String vSubContPkCd;

	@JsonProperty("vSubContCd")
	private String vSubContCd;

	@JsonProperty("vSubContNm")
	private String vSubContNm;

	@JsonProperty("vSubUserid")
	private String vSubUserid;

	@JsonProperty("vSubUsernm")
	private String vSubUsernm;
	
	@JsonProperty("vSubFlagCancel")
	private String vSubFlagCancel;

	@JsonProperty("vReleaseDt")
	private String vReleaseDt;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vSlUserid")
	private String vSlUserid;

	@JsonProperty("vBrdUserid")
	private String vBrdUserid;

	@JsonProperty("vPerfUserid")
	private String vPerfUserid;

	@JsonProperty("vFlagDel")
	private String vFlagDel;

	@JsonProperty("vTctnBynmNm")
	private String vTctnBynmNm;

	@JsonProperty("vRegDtm")
	private String vRegDtm;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;
}
