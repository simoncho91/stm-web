package com.mybeaker.app.hbd.service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mybeaker.app.common.model.AlarmRegDTO;
import com.mybeaker.app.common.service.CommonService;
import com.mybeaker.app.hbd.mapper.HbdBrandManageMapper;
import com.mybeaker.app.hbd.model.HbdNoteContDTO;
import com.mybeaker.app.hbd.model.HbdNoteInfoDTO;
import com.mybeaker.app.hbd.model.HbdNoteInfoRegDTO;
import com.mybeaker.app.hbd.model.HbdNoteRequestContDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonTagDTO;
import com.mybeaker.app.labnote.model.LabNoteMstVersionDTO;
import com.mybeaker.app.labnote.model.LabNoteVersionRegDTO;
import com.mybeaker.app.model.Const;
import com.mybeaker.app.model.enums.CommonResultCode;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.utils.SessionUtil;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class HbdBrandManageService {
	private final HbdCommonService hbdCommonService;

	private final CommonService commonService;

	private final HbdBrandManageMapper hbdBrandManageMapper;

	private final SessionUtil sessionUtil;

	public ResponseVO selectReqInfo(String vLabNoteCd) {
		ResponseVO responseVO = new ResponseVO();
		HbdNoteInfoDTO resDTO = null;
		List<String> arrTag1Cd = Arrays.asList("MTI01", "LNC12", "LNC13", "LNC15", "LNC02");
		if (StringUtils.isNotEmpty(vLabNoteCd)) {
			resDTO = hbdCommonService.selectLabNoteInfo(vLabNoteCd);

			if (resDTO == null) {
				responseVO.setOkWithCode("C9999", CommonResultCode.NO_DATA, null);
				return responseVO;
			}

			if (!sessionUtil.getLoginId().equals(resDTO.getVBrdUserid()) && !sessionUtil.isSysadmin()) {
				responseVO.setOkWithCode("C9999", CommonResultCode.NO_AUTH, null);
				return responseVO;
			}

			Optional<HbdNoteInfoDTO> optional = Optional.ofNullable(resDTO);

			optional.ifPresentOrElse((dto) -> {
				Map<String, List<LabNoteCommonTagDTO>> tagMap = hbdCommonService.selectLabNoteRequestTagList(arrTag1Cd, vLabNoteCd);
				List<LabNoteCommonTagDTO> effectList = tagMap.get("LNC15");
				List<LabNoteCommonTagDTO> tuserList = tagMap.get("LNC12");

				if (effectList != null && !effectList.isEmpty()) {
					effectList = effectList.stream().filter(vo -> vo.getVBuffer1().indexOf("HBO") > -1).collect(Collectors.toList());
				}

				if (tuserList != null && !tuserList.isEmpty()) {
					tuserList = tuserList.stream().filter(vo -> "NOTE".equals(vo.getVBuffer1())).collect(Collectors.toList());
				}

				dto.setMti01List(tagMap.get("MTI01"));
				dto.setEffectList(effectList);
				dto.setTuserList(tuserList);
				dto.setReqEtcList(tagMap.get("LNC13"));
				dto.setReleaseList(tagMap.get("LNC02"));
				dto.setContList(hbdCommonService.selectRequestContList(vLabNoteCd, "HAL3"));

				responseVO.setOk(dto);
			}, () -> {
				responseVO.setOkWithCode("C9999", CommonResultCode.NO_DATA, null);
			});
		} else {
			responseVO.setOkWithCode("C9999", CommonResultCode.NO_ESSENTIAL_DATA, null);
		}

		return responseVO;
	}

	@Transactional
	public ResponseVO updateReqPrdInfo(HbdNoteInfoRegDTO hbdNoteInfoRegDTO) {
		ResponseVO responseVO = new ResponseVO();
		HbdNoteInfoDTO beforeInfo = hbdCommonService.selectLabNoteInfo(hbdNoteInfoRegDTO.getVLabNoteCd());
		hbdNoteInfoRegDTO.setVRegUserid(sessionUtil.getLoginId());
		hbdNoteInfoRegDTO.setVUpdateUserid(sessionUtil.getLoginId());

		List<String> arrStatusCd = Arrays.asList("LNC06_01", "LNC06_02", "LNC06_03", "LNC06_04", "LNC06_05", "LNC06_06", "LNC06_21", "LNC06_22");

		if (!arrStatusCd.contains(beforeInfo.getVStatusCd())) {
			responseVO.setOkWithCode("C9999", CommonResultCode.NO_AVAILABLE_STATUS, null);
			return responseVO;
		}

		int result = hbdBrandManageMapper.updateReqPrdMstInfo(hbdNoteInfoRegDTO);

		if (result > 0) {
			List<HbdNoteContDTO> beforeContList = hbdCommonService.selectElabNoteContList(hbdNoteInfoRegDTO.getVLabNoteCd());
			Map<String, HbdNoteContDTO> beforeContMap = beforeContList == null
													? new HashMap<>()
													: beforeContList.stream().collect(Collectors.toMap(HbdNoteContDTO::getVContPkCd, entity -> entity));

			List<LabNoteCommonTagDTO> beforeMstTagList = hbdCommonService.selectLabNoteMstTagAllList(hbdNoteInfoRegDTO.getVLabNoteCd());
			hbdBrandManageMapper.deleteLabNoteMstTag(hbdNoteInfoRegDTO);
			if (hbdNoteInfoRegDTO.getMstTagList() != null && !hbdNoteInfoRegDTO.getMstTagList().isEmpty()) {
				hbdCommonService.insertLabNoteMstTag(hbdNoteInfoRegDTO);
			}

			if (hbdNoteInfoRegDTO.getContList() != null && !hbdNoteInfoRegDTO.getContList().isEmpty()) {
				for (HbdNoteRequestContDTO dto : hbdNoteInfoRegDTO.getContList()) {
					dto.setVRegUserid(sessionUtil.getLoginId());
					dto.setVUpdateUserid(sessionUtil.getLoginId());
					dto.setVLabNoteCd(hbdNoteInfoRegDTO.getVLabNoteCd());

					if (StringUtils.isNotEmpty(dto.getVContPkCd())) {
						hbdBrandManageMapper.updateNoteContEtc(dto);
					}
				}
			}

			List<LabNoteMstVersionDTO> verList = hbdCommonService.selectLabNoteMstVerList(hbdNoteInfoRegDTO.getVLabNoteCd());
			int verSize = verList == null ? 0 : verList.size();
			LabNoteMstVersionDTO tempDTO = verSize == 0 ? verList.get(0) : verList.get(verSize - 1);
			int ver = verSize == 0 ? 1 : verList.get(verSize - 1).getNVersion();

			LabNoteVersionRegDTO versionInfo = LabNoteVersionRegDTO.builder()
														.vLabNoteCd(hbdNoteInfoRegDTO.getVLabNoteCd())
														.nVersion(ver)
														.vVersionNm(ver < 10 ? "Ver #0" + ver : "Ver #" + ver)
														.vCounterCd(tempDTO.getVCounterCd())
														.vRegUserid(sessionUtil.getLoginId())
														.vUpdateUserid(sessionUtil.getLoginId())
														.build();
			HbdNoteInfoDTO afterInfo = hbdCommonService.selectLabNoteInfo(hbdNoteInfoRegDTO.getVLabNoteCd());

			if(!"LNC06_01".equals(afterInfo.getVStatusCd())) {
				hbdCommonService.deleteAerosolCont(hbdNoteInfoRegDTO);
				if (versionInfo != null && "Y".equals(hbdNoteInfoRegDTO.getVFlagAerosol())) {
					hbdCommonService.insertAerosolCont(hbdNoteInfoRegDTO);
					versionInfo.setVCodeType("AEROSOL");
					int nVersion = versionInfo.getNVersion();

					for (int i = 0; i < nVersion; i++) {
						versionInfo.setNVersion((i+1));
						versionInfo.setVVersionNm((i+1) < 10 ? "Ver #0" + (i+1) : "Ver #" + (i+1));
						hbdCommonService.insertLabNoteVersion(versionInfo);
						hbdCommonService.insertAerosolContMate(versionInfo);
					}
				}

				String beforePlantCd = StringUtils.isNotEmpty(beforeInfo.getVPlantCd()) ? beforeInfo.getVPlantCd() : "";

				if (!beforePlantCd.equals(afterInfo.getVPlantCd()) && "CN20".equals(afterInfo.getVPlantCd())) {
					hbdCommonService.updateLabNoteMstCopyNoteContNm(hbdNoteInfoRegDTO.getVLabNoteCd());
					hbdCommonService.updateLabNoteContCopyNoteContNm(hbdNoteInfoRegDTO.getVLabNoteCd());
				}
			}

			//List<String> arrStatus = Arrays.asList("LNC06_01", "LNC06_02", "LNC06_03", "LNC06_04", "LNC06_05", "LNC06_06");
			//if (!arrStatus.contains(beforeInfo.getVStatusCd())) {
				if (!beforeInfo.getVPlantCd().equals(afterInfo.getVPlantCd())
						|| !beforeInfo.getVBrdCd().equals(afterInfo.getVBrdCd())) {
					hbdCommonService.updateSAPMaterialReq(hbdNoteInfoRegDTO);
				}

				hbdCommonService.checkContModifyLog(hbdNoteInfoRegDTO, beforeContMap);
				hbdCommonService.checkModifyLog(hbdNoteInfoRegDTO, beforeInfo, beforeMstTagList, afterInfo);
			//}

			List<String> userList = StringUtils.isNotEmpty(afterInfo.getVUserid())
								? Arrays.asList(afterInfo.getVUserid())
								: null;
			commonService.sendAlarm(AlarmRegDTO.builder()
									.vLabNoteCd(afterInfo.getVLabNoteCd())
									.vStatusCd("AL_NOTE1")
									.vAlrTypeCd("AL_NOTE1_07")
									.typeList(Arrays.asList(Const.ALARM, Const.TIMELINE))
									.vContCd(afterInfo.getVContCd())
									.vContNm(afterInfo.getVContNm())
									.vNoteType("HBO")
									.vMoveUrl(new StringBuilder()
											.append("/hbd/all-lab-note-prd-view?vLabNoteCd=")
											.append(afterInfo.getVLabNoteCd())
											.toString())
									.userList(userList)
									.build());

			responseVO.setOk(hbdNoteInfoRegDTO.getVLabNoteCd());
		} else {
			responseVO.setOkWithCode("C9999", CommonResultCode.SAVE_FAIL, null);
		}

		return responseVO;
	}
}
