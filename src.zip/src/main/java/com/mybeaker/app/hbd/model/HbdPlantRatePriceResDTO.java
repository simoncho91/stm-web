package com.mybeaker.app.hbd.model;

import java.util.List;

import com.mybeaker.app.skincare.model.PlantRatePriceVO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class HbdPlantRatePriceResDTO {

	private List<HbdNoteLotVO> lotList;
	
	private List<HbdNoteMateVO> mateList;
	
	private List<PlantRatePriceVO> rateList;
}
