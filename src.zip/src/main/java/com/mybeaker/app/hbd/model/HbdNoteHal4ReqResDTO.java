package com.mybeaker.app.hbd.model;

import java.util.List;

import com.mybeaker.app.labnote.model.LabNoteRequestPjtDTO;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class HbdNoteHal4ReqResDTO {

	private HbdNoteInfoDTO rvo;
	
	private List<LabNoteRequestPjtDTO> pjtList;
	
	
}
