package com.mybeaker.app.hbd.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@Data
public class HbdNoteContVO extends ParentDTO {

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vPrdCd")
	private String vPrdCd;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vContNmCn")
	private String vContNmCn;

	@JsonProperty("vContNmEn")
	private String vContNmEn;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vLabContCd")
	private String vLabContCd;

	@JsonProperty("vFlagRepresent")
	private String vFlagRepresent;

	@JsonProperty("vCodeType")
	private String vCodeType;

	@JsonProperty("vFlagDel")
	private String vFlagDel;

	@JsonProperty("vCompleteCounterCd")
	private String vCompleteCounterCd;

	@JsonProperty("vCompleteShape")
	private String vCompleteShape;

	@JsonProperty("vCompleteCounterNote")
	private String vCompleteCounterNote;

	@JsonProperty("vG1PqcResCd")
	private String vG1PqcResCd;

	@JsonProperty("vG1PqcLotCd")
	private String vG1PqcLotCd;

	@JsonProperty("nG1ObeyPer")
	private int nG1ObeyPer;

	@JsonProperty("vG2PqcResCd")
	private String vG2PqcResCd;

	@JsonProperty("vG2PqcLotCd")
	private String vG2PqcLotCd;

	@JsonProperty("nG2ObeyPer")
	private int nG2ObeyPer;

	@JsonProperty("vPack1Cd")
	private String vPack1Cd;

	@JsonProperty("vPack2Cd")
	private String vPack2Cd;

	@JsonProperty("vPack3Cd")
	private String vPack3Cd;

	@JsonProperty("vDecideContNm")
	private String vDecideContNm;

	@JsonProperty("vFlagDecide")
	private String vFlagDecide;

	@JsonProperty("vFlagCancel")
	private String vFlagCancel;

	@JsonProperty("vNoteContNm")
	private String vNoteContNm;

	@JsonProperty("vCompleteSsrid")
	private String vCompleteSsrid;

	@JsonProperty("nCompleteVer")
	private int nCompleteVer;

	@JsonProperty("vLaunchCompleteDt")
	private String vLaunchCompleteDt;
	
	@JsonProperty("vLotCd")
	private String vLotCd;

	@Builder
	public HbdNoteContVO(String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm, String vContPkCd,
			String vLabNoteCd, String vContCd, String vPrdCd, String vPlantCd, String vContNm, String vContNmCn,
			String vContNmEn, String vUserid, String vLabContCd, String vFlagRepresent, String vCodeType,
			String vFlagDel, String vCompleteCounterCd, String vCompleteShape, String vCompleteCounterNote,
			String vG1PqcResCd, String vG1PqcLotCd, int nG1ObeyPer, String vG2PqcResCd, String vG2PqcLotCd,
			int nG2ObeyPer, String vPack1Cd, String vPack2Cd, String vPack3Cd, String vDecideContNm, String vFlagDecide,
			String vFlagCancel, String vNoteContNm, String vCompleteSsrid, int nCompleteVer, String vLaunchCompleteDt,
			String vLotCd) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.vContPkCd = vContPkCd;
		this.vLabNoteCd = vLabNoteCd;
		this.vContCd = vContCd;
		this.vPrdCd = vPrdCd;
		this.vPlantCd = vPlantCd;
		this.vContNm = vContNm;
		this.vContNmCn = vContNmCn;
		this.vContNmEn = vContNmEn;
		this.vUserid = vUserid;
		this.vLabContCd = vLabContCd;
		this.vFlagRepresent = vFlagRepresent;
		this.vCodeType = vCodeType;
		this.vFlagDel = vFlagDel;
		this.vCompleteCounterCd = vCompleteCounterCd;
		this.vCompleteShape = vCompleteShape;
		this.vCompleteCounterNote = vCompleteCounterNote;
		this.vG1PqcResCd = vG1PqcResCd;
		this.vG1PqcLotCd = vG1PqcLotCd;
		this.nG1ObeyPer = nG1ObeyPer;
		this.vG2PqcResCd = vG2PqcResCd;
		this.vG2PqcLotCd = vG2PqcLotCd;
		this.nG2ObeyPer = nG2ObeyPer;
		this.vPack1Cd = vPack1Cd;
		this.vPack2Cd = vPack2Cd;
		this.vPack3Cd = vPack3Cd;
		this.vDecideContNm = vDecideContNm;
		this.vFlagDecide = vFlagDecide;
		this.vFlagCancel = vFlagCancel;
		this.vNoteContNm = vNoteContNm;
		this.vCompleteSsrid = vCompleteSsrid;
		this.nCompleteVer = nCompleteVer;
		this.vLaunchCompleteDt = vLaunchCompleteDt;
		this.vLotCd = vLotCd;
	}
}
