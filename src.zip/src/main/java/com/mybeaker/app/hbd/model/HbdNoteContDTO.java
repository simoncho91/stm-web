package com.mybeaker.app.hbd.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class HbdNoteContDTO extends ParentDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("vPrdCd")
	private String vPrdCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vUsernm")
	private String vUsernm;

	@JsonProperty("vFlagRepresent")
	private String vFlagRepresent;

	@JsonProperty("vNoteContNm")
	private String vNoteContNm;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vCodeType")
	private String vCodeType;

	@JsonProperty("vCompleteCounterCd")
	private String vCompleteCounterCd;

	@JsonProperty("vCompleteShape")
	private String vCompleteShape;

	@JsonProperty("vLaunchCompleteDt")
	private String vLaunchCompleteDt;

	@JsonProperty("vCompleteShapeNm")
	private String vCompleteShapeNm;

	@JsonProperty("vCompleteCounterNote")
	private String vCompleteCounterNote;

	@JsonProperty("vCounterContPkCd")
	private String vCounterContPkCd;

	@JsonProperty("vInitCounterContCd")
	private String vInitCounterContCd;

	@JsonProperty("vInitCounterContNm")
	private String vInitCounterContNm;

	@JsonProperty("vCompleteCounterContCd")
	private String vCompleteCounterContCd;

	@JsonProperty("vCompleteCounterContNm")
	private String vCompleteCounterContNm;
}
