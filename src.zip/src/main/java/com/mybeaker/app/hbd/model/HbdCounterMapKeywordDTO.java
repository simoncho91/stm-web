package com.mybeaker.app.hbd.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class HbdCounterMapKeywordDTO {
	@JsonProperty("vCompleteCounterCd")
	private String vCompleteCounterCd;

	@JsonProperty("vContPkCd")
	private String vContPkCd;
}
