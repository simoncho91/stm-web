package com.mybeaker.app.hbd.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.mybeaker.app.common.model.CodeDTO;
import com.mybeaker.app.hbd.model.HbdMaterialNotePlantVO;
import com.mybeaker.app.hbd.model.HbdMaterialSaveRegDTO;
import com.mybeaker.app.hbd.model.HbdNoteContVO;
import com.mybeaker.app.hbd.model.HbdNoteGramTrVO;
import com.mybeaker.app.hbd.model.HbdNoteGramVO;
import com.mybeaker.app.hbd.model.HbdNoteGroupVO;
import com.mybeaker.app.hbd.model.HbdNoteLotExpoureYVO;
import com.mybeaker.app.hbd.model.HbdNoteLotVO;
import com.mybeaker.app.hbd.model.HbdNoteMateVO;
import com.mybeaker.app.hbd.model.HbdNoteMemoVO;
import com.mybeaker.app.hbd.model.HbdNoteMstVO;
import com.mybeaker.app.hbd.model.HbdNoteMstVerTagVO;
import com.mybeaker.app.hbd.model.HbdNoteMstVerVO;
import com.mybeaker.app.hbd.model.HbdNoteRateVO;
import com.mybeaker.app.hbd.model.HbdNoteStabilityTitleVO;
import com.mybeaker.app.hbd.model.HbdNoteStabilityValueVO;
import com.mybeaker.app.hbd.model.HbdNoteVersionVO;
import com.mybeaker.app.labnote.model.ElabHisPreRateVO;
import com.mybeaker.app.labnote.model.ElabStats01VO;
import com.mybeaker.app.labnote.model.ElabStats02VO;
import com.mybeaker.app.labnote.model.ElabStats03VO;
import com.mybeaker.app.labnote.model.MusoguInfoVO;
import com.mybeaker.app.labnote.model.MusoguRateVO;
import com.mybeaker.app.labnote.model.MusoguReqDTO;
import com.mybeaker.app.skincare.model.BomReqDTO;
import com.mybeaker.app.skincare.model.BookmarkApplyVO;
import com.mybeaker.app.skincare.model.BookmarkReqDTO;
import com.mybeaker.app.skincare.model.BookmarkVO;
import com.mybeaker.app.skincare.model.CounterSAPRegDTO;
import com.mybeaker.app.skincare.model.ElabLotMemoVO;
import com.mybeaker.app.skincare.model.GramReqDTO;
import com.mybeaker.app.skincare.model.GramTrPlanVO;
import com.mybeaker.app.skincare.model.IngredientDataVO;
import com.mybeaker.app.skincare.model.IngredientExistsConcdVO;
import com.mybeaker.app.skincare.model.IngredientMateVO;
import com.mybeaker.app.skincare.model.IngredientReqDTO;
import com.mybeaker.app.skincare.model.IngredientVO;
import com.mybeaker.app.skincare.model.MaterialGradeSumVO;
import com.mybeaker.app.skincare.model.MaterialLotVO;
import com.mybeaker.app.skincare.model.MaterialMateRateVO;
import com.mybeaker.app.skincare.model.MaterialMateSumVO;
import com.mybeaker.app.skincare.model.MaterialMateVO;
import com.mybeaker.app.skincare.model.MaterialNoteContVO;
import com.mybeaker.app.skincare.model.MaterialNoteVersionVO;
import com.mybeaker.app.skincare.model.MaterialNumberVO;
import com.mybeaker.app.skincare.model.MaterialQrInfoVO;
import com.mybeaker.app.skincare.model.MaterialSearchVO;
import com.mybeaker.app.skincare.model.MaterialVersionRegDTO;
import com.mybeaker.app.skincare.model.MemoReqDTO;
import com.mybeaker.app.skincare.model.PlantRatePriceReqVO;
import com.mybeaker.app.skincare.model.PlantRatePriceVO;
import com.mybeaker.app.skincare.model.ScmTCodeRegDTO;
import com.mybeaker.app.skincare.model.StabilityTitleVO;
import com.mybeaker.app.skincare.model.SubMateReqDTO;
import com.mybeaker.app.skincare.model.SubMateVO;
import com.mybeaker.app.skincare.model.VersionContVO;
import com.mybeaker.app.skincare.model.VersionReqDTO;

@Mapper
public interface HbdMaterialMapper {

	public MaterialQrInfoVO selectElabNoteInfoVerLotCd(MaterialQrInfoVO materialQrInfoVO);
	
	public List<HbdMaterialNotePlantVO> selectLabNoteContOrPlantList(MaterialSearchVO materialSearchVO);
	
	public MaterialNoteContVO selectLabNoteContInfo(MaterialSearchVO materialSearchVO);
	
	public List<MaterialNoteVersionVO> selectLabNoteVersion(MaterialSearchVO materialSearchVO);
	
	public String selectLabNoteCheckVersion(MaterialSearchVO materialSearchVO);
	
	public List<MaterialLotVO> selectLabNoteLotGramList(MaterialSearchVO materialSearchVO);
	
	public String selectLabNoteExistsLotExposure(MaterialSearchVO materialSearchVO);
	
	public int selectHal4MateDenominator(MaterialSearchVO materialSearchVO);
	
	public List<MaterialNumberVO> selectHal4MateNumerator(MaterialSearchVO materialSearchVO);
	
	public List<MaterialMateRateVO> selectLabNoteMateRateMap(MaterialSearchVO materialSearchVO);
	
	public List<MaterialMateSumVO> selectLabNoteMatePriceSum(MaterialSearchVO materialSearchVO);
	
	public List<MaterialMateSumVO> selectLabNoteMateNeutralization(MaterialSearchVO materialSearchVO);
	
	public int deleteLabNoteGroup(HbdNoteGroupVO hbdNoteGroupVO);
	
	public int insertLabNoteGroup(HbdNoteGroupVO hbdNoteGroupVO);
	
	public int updateLabNoteGroup(HbdNoteGroupVO hbdNoteGroupVO);
	
	public int insertLabNoteMate(HbdNoteMateVO hbdNoteMateVO);
	
	public int updateLabNoteMate(HbdNoteMateVO hbdNoteMateVO);
	
	public List<HbdNoteLotVO> selectElabNoteLotList(HbdMaterialSaveRegDTO regDTO);
	
	public int insertLabNoteLot(HbdNoteLotVO hbdNoteLotVO);
	
	public int updateLabNoteLot(HbdNoteLotVO hbdNoteLotVO);
	
	public int insertLabNoteGram(HbdNoteGramVO hbdNoteGramVO);
	
	public int updateLabNoteGram(HbdNoteGramVO hbdNoteGramVO);
	
	public int insertELabHisPreRate(ElabHisPreRateVO elabHisPreRateVO);
	
	public int insertLabNoteRate(HbdNoteRateVO hbdNoteRateVO);
	
	public int updateLabNoteAllLotExposureN(HbdNoteLotVO hbdNoteLotVO);
	
	public int updateLabNoteLotExposureY(HbdNoteLotExpoureYVO hbdNoteLotExpoureYVO);
	
	public int updateLabNoteVersion(HbdNoteVersionVO hbdNoteVersionVO);
	
	public int updateStatusCd_LNC06_22(HbdNoteMstVO hbdNoteMstVO);
	
	public int updateStatusCd_LNC06_31(HbdNoteMstVO hbdNoteMstVO);
	
	public int updateLabNoteMateCheckSharing(HbdNoteMateVO hbdNoteMateVO);
	
	public String selectLabNoteFlagAllLaunchComplete(String vLabNoteCd);
	
	public int updateLabNoteStats01(ElabStats01VO elabStats01VO);
	
	public int updateLabNoteStats02(ElabStats02VO elabStats02VO);
	
	public int updateLabNoteStats03(ElabStats03VO elabStats03VO);
	
	public int deleteFinalVersionToLot(HbdNoteLotVO hdbNoteLotVO);
	
	public int deleteFinalVersion(HbdNoteVersionVO hbdNoteVersionVO);
	
	public int updateLabNoteResetHistory(MaterialVersionRegDTO regDTO);
	
	public int selectLabNoteMstLastVersion(MaterialVersionRegDTO regDTO);
	
	public int insertLabNoteMstNewVersion(HbdNoteMstVerVO hbdNoteMstVerVO);
	
	public int insertLabNoteNewVersion(HbdNoteVersionVO hbdNoteVersionVO);
	
	public int insertLabNoteAerosolContMate(HbdNoteMateVO hbdNoteMateVO);
	
	public int insertLabNotePreMstVerTag(HbdNoteMstVerTagVO hbdNoteMstVerTagVO);
	
	public int insertLabNotePreVerMate(HbdNoteMateVO hbdNoteMateVO);
	
	public int updateLabNoteLotFlagDecideN(String vLabNoteCd);
	
	public int updateLabNoteResCostReset(String vLabNoteCd);
	
	public int updateLabNoteContReset(HbdNoteContVO hbdNoteContVO);
	
	public int updateLabNoteVersionReset(String vLabNoteCd);
	
	public List<String> selectLabNoteCompleteDtList(List<String> labNoteCdList);
	
	public int procElabSustainabilityStatsPr(String vDt);
	
	public int updateLabNoteLotBookmark(String vLotCd);

	public int deleteLabNoteLotBookmark(String vLotCd);
	
	public int updateLabNoteApplyMstPlant(HbdNoteMstVO hbdNoteMstVO);
	
	public int updateLabNoteApplyContPlant(HbdNoteContVO hbdNoteContVO);
	
	public int updateLabNoteTestResLot(HbdNoteLotVO hbdNoteLotVO);

	public int insertLabNoteGramTr(HbdNoteGramTrVO hbdNoteLotVO);
	
	public int updateLabNoteGramTr(HbdNoteGramTrVO hbdNoteLotVO);
	
	public int deleteLabNoteGramTr(HbdNoteGramTrVO hbdNoteLotVO);
	
	public int insertLabNoteStabilityValue(HbdNoteStabilityValueVO hbdNoteStabilityValueVO);
	
	public List<HbdNoteGramTrVO> selectLabNoteGramTrList(String vGramCd);

	public List<HbdNoteContVO> selectCheckSubPlantList(HbdNoteContVO hbdNoteContVO);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public List<MaterialGradeSumVO> selectLabNoteMateGradeSum(MaterialGradeSumVO materialGradeSumVO);
	
	public List<MaterialGradeSumVO> selectLabNoteMateGradeLotSum(MaterialGradeSumVO materialGradeSumVO);
	
	public List<SubMateVO> selectLabNoteSubMateRateInfoVerNotNote(SubMateReqDTO reqDTO);
	
	public String selectLabNoteLotState(SubMateReqDTO reqDTO);
	
	public List<SubMateVO> selectLabNoteSubMateRateInfo(SubMateReqDTO reqDTO);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//	POPUP - 처방 불러오기
	public int selectLabNoteBookmarkListCount(BookmarkReqDTO bookmarkReqDTO);
	
	public List<BookmarkVO> selectLabNoteBookmarkList(BookmarkReqDTO reqDTO);
	
	public List<String> selectLabNoteMatePlantCheck(BookmarkReqDTO reqDTO);
	
	public List<BookmarkApplyVO> selectLabNoteBookmarkApplyList(BookmarkReqDTO reqDTO);
	
	public String selectLabNoteExistsContInfo(CounterSAPRegDTO regDTO);
	
	public String selectZqmtExistsMatnrInfo(CounterSAPRegDTO regDTO);
	
	public int insertLabNoteMstCounterSAPInfo(HbdNoteMstVO hbdNoteMstVO);
	
	public int insertLabNoteMstVerCounterSAPInfo(HbdNoteMstVerVO hbdNoteMstVerVO);
	
	public String selectZqmtContNm(HbdNoteContVO hbdNoteContVO);
	
	public int insertLabNoteContCounterSAPInfo(HbdNoteContVO hbdNoteContVO);
	
	public int insertLabNoteVersionCounterSAPInfo(HbdNoteVersionVO hbdNoteVersionVO);
	
	public int insertLabNoteFinalVersion(HbdNoteVersionVO hbdNoteVersionVO);
	
	public int insertLabNoteFinalLot(HbdNoteLotVO hbdNoteLotVO);
	
//	POPUP - 버전관리
//	getLabNoteContOrPlantList - reqVo.put("i_sSearchType", "CONT");
	public List<VersionContVO> selectLabNoteContList(VersionReqDTO reqDTO);
	
	public int updateVersionView(HbdNoteVersionVO hbdNoteVersionVO);
	
	public int updateLotAddType(HbdNoteMstVO hbdNoteMstVO);
	
//	POPUP - 무소구가능항목
	public MusoguInfoVO selectMusoguInfo(MusoguReqDTO reqDTO);
	
	public List<CodeDTO> selectMusoguList(MusoguInfoVO musoguInfoVO);
	
	public List<MusoguRateVO> selectMusoguRate(MusoguReqDTO reqDTO);
	
	public List<CodeDTO> selectLabNoteTagListAll(MusoguReqDTO reqDTO);
	
	public List<String> selectLabNoteMusoguGroup();
	
//	POPUP - 글로벌금지
	public int updateLabNoteMateCheck(ScmTCodeRegDTO regDTO);
	
//	POPUP - 플랜트 단가
	public HbdNoteLotVO selectLabNoteLot(PlantRatePriceReqVO reqVO);
	
	public List<HbdNoteLotVO> selectLabNoteLotList(HbdNoteLotVO hbdNoteLotVO);
	
	public List<HbdNoteMateVO> selectLabNoteMateList(PlantRatePriceReqVO reqDTO);
	
	public List<PlantRatePriceVO> selectLabNoteAllPlantRateAndPriceMap(PlantRatePriceReqVO reqDTO);
	
//	POPUP - BOM 임시전송
	public List<HbdNoteLotVO> selectLabNoteBomLotList(BomReqDTO reqDTO);
	
//	POPUP - 실험결과
	public int updateLabNoteGramDt(HbdNoteGramVO hbdNoteGramVO);
	
	public List<StabilityTitleVO> selectLabNoteStabilityTitleList(GramReqDTO reqDTO);
	
	public List<StabilityTitleVO> selectLabNoteStabilityDefaultTitleList();
	
	public List<HbdNoteStabilityValueVO> selectLabNoteStabilityValueListMap(GramReqDTO reqDTO);
	
	public HbdNoteGramVO selectLabNoteGram(GramReqDTO reqDTO);
	
	public List<HbdNoteGramVO> selectLabNoteGramList(GramReqDTO reqDTO);
	
	public List<GramTrPlanVO> selectLabNoteGramTrPlanList(GramReqDTO reqDTO);
	
//	POPUP - 전성분
	public IngredientDataVO selectLabNoteDefaultIngredientData(IngredientReqDTO reqDTO);
	
	public List<IngredientExistsConcdVO> selectLabNoteNotExistsConcdList(IngredientReqDTO reqDTO);
	
	public String selectFlagZplmt74(String vMatnr);
	
	public List<IngredientVO> selectLabNoteIngredientVerAllergenListMap(IngredientVO ingredientVO);
	
	public List<IngredientVO> selectLabNoteIngredientListMap(IngredientVO ingredientVO);
	
	public List<IngredientMateVO> selectLabNoteIngredientMateInfoList(IngredientMateVO ingredientMateVO);
	
//	POPUP - 안정도 설정
	public List<StabilityTitleVO> selectLabNoteStabilityTitleAllList();
	
	public int insertLabNoteStabilityTitle(HbdNoteStabilityTitleVO hbdNoteStabilityTitleVO);
	
	public int deleteLabNoteStabilityTitle(HbdNoteStabilityTitleVO hbdNoteStabilityTitleVO);
	
//	POPUP - 메모
	public int selectLabNoteMemoListCount(MemoReqDTO reqDTO);
	
	public List<HbdNoteMemoVO> selectLabNoteMemoList(MemoReqDTO reqDTO);
	
	public HbdNoteMemoVO selectLabNoteMemo(MemoReqDTO reqDTO);
	
	public int insertLabNoteMemo(HbdNoteMemoVO hbdNoteMemoVO);
	
	public int updateLabNoteMemo(HbdNoteMemoVO hbdNoteMemoVO);
	
	public int deleteLabNoteMemo(HbdNoteMemoVO hbdNoteMemoVO);

//	Lot Side
	public List<ElabLotMemoVO> selectElabLotMemoList(String vLotCd);

//	순서 바꾸기
	public List<MaterialMateVO> selectLabNoteMateAndGrpSimpleList(String vContPkCd, int nVersion);

	public int updateLabNoteOrderGroup(HbdNoteGroupVO hbdNoteGroupVO);
	
	public int updateLabNoteOrderMate(HbdNoteMateVO hbdNoteMateVO);
	
//	Excel Upload
	public int deleteLabNoteExcelGroup(HbdNoteGroupVO hbdNoteGroupVO);
	
	public int deleteLabNoteExcelMate(HbdNoteMateVO hbdNoteMateVO);
	
	public int deleteLabNoteExcelGram(HbdNoteLotVO hbdNoteLotVO);
	
	public int deleteLabNoteExcelLot(HbdNoteLotVO hbdNoteLotVO);

	public int selectLabNoteExcelLotCnt(HbdNoteLotVO muNoteLotVO);
}
