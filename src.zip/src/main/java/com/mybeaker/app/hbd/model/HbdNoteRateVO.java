package com.mybeaker.app.hbd.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper=true)
@NoArgsConstructor
@Data
public class HbdNoteRateVO extends ParentDTO {

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("vMatePkCd")
	private String vMatePkCd;

	@JsonProperty("nRate")
	private String nRate;

	@JsonProperty("vFlagRateRest")
	private String vFlagRateRest;

	@JsonProperty("vMateDbLotCd")
	private String vMateDbLotCd;

	@Builder
	public HbdNoteRateVO(String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm, String vLotCd,
			String vMatePkCd, String nRate, String vFlagRateRest, String vMateDbLotCd) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.vLotCd = vLotCd;
		this.vMatePkCd = vMatePkCd;
		this.nRate = nRate;
		this.vFlagRateRest = vFlagRateRest;
		this.vMateDbLotCd = vMateDbLotCd;
	}
}
