package com.mybeaker.app.hbd.model;

import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@Data
public class HbdNoteMstVerTagVO extends ParentDTO {

	private String vLabNoteCd;

	private int nVersion;

	private String vTag1Cd;

	private String vTag2Cd;

	private int nSort;

	private String vBuffer1;

	private String vBuffer2;

	private String vBuffer3;
	
	private int nPreVersion;

	@Builder
	public HbdNoteMstVerTagVO(String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm,
			String vLabNoteCd, int nVersion, String vTag1Cd, String vTag2Cd, int nSort, String vBuffer1,
			String vBuffer2, String vBuffer3, int nPreVersion) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.vLabNoteCd = vLabNoteCd;
		this.nVersion = nVersion;
		this.vTag1Cd = vTag1Cd;
		this.vTag2Cd = vTag2Cd;
		this.nSort = nSort;
		this.vBuffer1 = vBuffer1;
		this.vBuffer2 = vBuffer2;
		this.vBuffer3 = vBuffer3;
		this.nPreVersion = nPreVersion;
	}
}
