package com.mybeaker.app.hbd.service;

import java.awt.Font;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.util.CellRangeAddress;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mybeaker.app.approval.model.ApprovalDTO;
import com.mybeaker.app.approval.model.ApprovalDetailDTO;
import com.mybeaker.app.approval.model.ReqResApprovalDTO;
import com.mybeaker.app.approval.service.ApprovalService;
import com.mybeaker.app.common.form.EpReportForm;
import com.mybeaker.app.common.form.MailForm;
import com.mybeaker.app.common.model.AlarmRegDTO;
import com.mybeaker.app.common.model.CodeDTO;
import com.mybeaker.app.common.model.CommUserDesSearchInfoDTO;
import com.mybeaker.app.common.model.MailDTO;
import com.mybeaker.app.common.model.ResultDTO;
import com.mybeaker.app.common.model.UploadDTO;
import com.mybeaker.app.common.model.UploadTempDTO;
import com.mybeaker.app.common.service.CommonService;
import com.mybeaker.app.hbd.mapper.HbdProcessMapper;
import com.mybeaker.app.hbd.model.HbdAerosolDecideReqDTO;
import com.mybeaker.app.hbd.model.HbdContentDetailDTO;
import com.mybeaker.app.hbd.model.HbdNoteInfoDTO;
import com.mybeaker.app.hbd.model.HbdNoteLotDTO;
import com.mybeaker.app.hbd.model.HbdNoteLotVO;
import com.mybeaker.app.labnote.model.BomApprovalReqDTO;
import com.mybeaker.app.labnote.model.BomInfoVO;
import com.mybeaker.app.labnote.model.BomShelfLifeDTO;
import com.mybeaker.app.labnote.model.ElabBomLotVerVO;
import com.mybeaker.app.labnote.model.ElabContQmsReqVO;
import com.mybeaker.app.labnote.model.ElabContQmsVO;
import com.mybeaker.app.labnote.model.ElabShelflifeContVO;
import com.mybeaker.app.labnote.model.FormulaDecideResDTO;
import com.mybeaker.app.labnote.model.FuncDecideContNameVO;
import com.mybeaker.app.labnote.model.FuncDecideNameVO;
import com.mybeaker.app.labnote.model.LabNoteCommonTagDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonWokReportReqDTO;
import com.mybeaker.app.labnote.model.LabNoteContInfoVO;
import com.mybeaker.app.labnote.model.LabNoteIngrdApprConInfoVO;
import com.mybeaker.app.labnote.model.LabNoteIngrdApprSaveInfoVO;
import com.mybeaker.app.labnote.model.LabNoteLotDTO;
import com.mybeaker.app.labnote.model.LabNoteMateInfoVO;
import com.mybeaker.app.labnote.model.LabNoteMstVersionDTO;
import com.mybeaker.app.labnote.model.LabNoteMstVersionPqcDTO;
import com.mybeaker.app.labnote.model.LabNotePqcGateCheckListDTO;
import com.mybeaker.app.labnote.model.LabNotePqcGateCheckReqDTO;
import com.mybeaker.app.labnote.model.LabNotePqcResItemListDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessContDecideListDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessContDecideReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessContDecideResDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncDecideReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncDecideResDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncMateResDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReportDataDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReportDecideContDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReportRegResDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReportReqPopDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReportReqSaveDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReportResDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReportResPopDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReportUserReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReportUserResDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReportVerLotVO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncRequestQADTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncResDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessIngrdApprDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessIngrdApprRegDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessIngrdApprReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessIngrdApprResDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessMateMixCheckDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessPqcCheckApprReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessProgressDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessReportPrdListReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessResDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessTabListDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessTimeLineDTO;
import com.mybeaker.app.labnote.model.LabNoteSapBomConSearchVO;
import com.mybeaker.app.labnote.model.LabNoteSapBomToConInfoVO;
import com.mybeaker.app.labnote.model.LabNoteSapRfcMat3AllListVO;
import com.mybeaker.app.labnote.model.LabNoteTestRequestProductDTO;
import com.mybeaker.app.labnote.model.LabNoteTestRequestProductReqDTO;
import com.mybeaker.app.labnote.model.LabNoteTestRequestProductResDTO;
import com.mybeaker.app.labnote.model.LabNoteVersionDTO;
import com.mybeaker.app.labnote.model.LotStatusRegDTO;
import com.mybeaker.app.labnote.model.MusoguReqDTO;
import com.mybeaker.app.labnote.model.MusoguTagVO;
import com.mybeaker.app.labnote.model.PgcGqteResVO;
import com.mybeaker.app.labnote.model.PilotRequestDTO;
import com.mybeaker.app.labnote.model.PilotRequestDetailReqDTO;
import com.mybeaker.app.labnote.model.PilotRequestDetailResDTO;
import com.mybeaker.app.labnote.model.PilotRequestMateDTO;
import com.mybeaker.app.labnote.model.PilotRequestRegInfoReqDTO;
import com.mybeaker.app.labnote.model.PilotRequestRegInfoResDTO;
import com.mybeaker.app.labnote.model.PilotRequestReqDTO;
import com.mybeaker.app.labnote.model.PilotRequestResDTO;
import com.mybeaker.app.labnote.model.QmsResDTO;
import com.mybeaker.app.labnote.model.ShelfLifeVO;
import com.mybeaker.app.labnote.model.SupGlobalMailUserVO;
import com.mybeaker.app.labnote.model.Zplmt13VO;
import com.mybeaker.app.labnote.model.Zplmt14VO;
import com.mybeaker.app.labnote.service.LabNoteCommonService;
import com.mybeaker.app.labnote.service.LabNoteSAPInterfaceService;
import com.mybeaker.app.model.Const;
import com.mybeaker.app.model.dto.PagingDTO;
import com.mybeaker.app.model.dto.ResCommSearchInfoDTO;
import com.mybeaker.app.model.enums.ApprovalResultCode;
import com.mybeaker.app.model.enums.CommonResultCode;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.skincare.model.IngredientContVO;
import com.mybeaker.app.skincare.model.IngredientReqDTO;
import com.mybeaker.app.skincare.model.LotDecideRegDTO;
import com.mybeaker.app.skincare.model.LotPilotRegDTO;
import com.mybeaker.app.skincare.model.MateRateReqVO;
import com.mybeaker.app.skincare.model.MaterialSearchVO;
import com.mybeaker.app.skincare.model.PlantRatePriceReqVO;
import com.mybeaker.app.skincare.model.ScNoteLotDTO;
import com.mybeaker.app.skincare.model.ValidateVO;
import com.mybeaker.app.skincare.model.VersionContVO;
import com.mybeaker.app.utils.CommonUtil;
import com.mybeaker.app.utils.ConvertUtil;
import com.mybeaker.app.utils.MailUtil;
import com.mybeaker.app.utils.PropertyUtil;
import com.mybeaker.app.utils.SessionUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class HbdProcessService {
	private final HbdProcessMapper hbdProcessMapper;

	private final SessionUtil sessionUtil;

	private final HbdCommonService hbdCommonService;

	private final LabNoteCommonService labNoteCommonService;

	private final LabNoteSAPInterfaceService labNoteSAPInterfaceService;

	private final CommonService commonService;

	private final ApprovalService approvalService;

	private LabNoteProcessResDTO setProgressBarInfo (String vLabNoteCd, HbdNoteInfoDTO noteInfoDTO) {
		String activeTabStatus = "AL_NOTE1";
		String vStatusCd = noteInfoDTO.getVStatusCd();
		LabNoteProcessResDTO resDTO = new LabNoteProcessResDTO();
		//개발취소인 경우
		if("LNC06_41".equals(noteInfoDTO.getVStatusCd())) {
			resDTO.setVFlagCancel("Y");
			vStatusCd = hbdCommonService.selectLabNoteStatusCd(vLabNoteCd);		//취소하기 이전 상태를 확인함
		}

		activeTabStatus = labNoteCommonService.selectLabNoteActiveStatus(vStatusCd);
		int activeNum = Integer.parseInt(activeTabStatus.replaceAll("[^0-9]", ""));

		String vPageType = "";
		if ("LNC07_02".equals(noteInfoDTO.getVLabTypeCd())) {
			vPageType = "HALF";
		} else if (!"LNC07_01".equals(noteInfoDTO.getVLabTypeCd()) && !"LNC07_02".equals(noteInfoDTO.getVLabTypeCd())) {
			vPageType = "NONPRD";
		}

		List<LabNoteProcessProgressDTO> progBar = labNoteCommonService.selectProgressInfo(vLabNoteCd, vPageType);

		int size = progBar == null ? 0 : progBar.size();
		if(size > 0) {
			for(int i = 0; i < size; i++) {
				LabNoteProcessProgressDTO progVo = progBar.get(i);
				progVo.setVCurrStatMark("is-none");

				int progNum = Integer.parseInt(progVo.getVStatusCd().replaceAll("[^0-9]", ""));
				if(progNum < activeNum) {
					progVo.setVCurrStatMark("is-past");
				}
				if(activeTabStatus.equals(progVo.getVStatusCd())) {
					progVo.setVCurrStatMark("is-active");
				}
			}
		}

		resDTO.setProgressInfo(progBar);
		return resDTO;
	}

	//프로그레스 바만 따로 호출하는 메소드
	public ResponseVO selectProgressBar(String vLabNoteCd) {
		ResponseVO responseVO = new ResponseVO();

		if(StringUtils.isEmpty(vLabNoteCd)) {
			responseVO.setOkWithCode(Const.FAIL, "필수 인자값이 없습니다", null);
			return responseVO;
		}

		HbdNoteInfoDTO noteInfoDTO = hbdCommonService.selectLabNoteInfo(vLabNoteCd);
		if(ObjectUtils.isEmpty(noteInfoDTO)) {
			responseVO.setOkWithCode(Const.FAIL, "실험노트 정보가 없습니다.", null);
			return responseVO;
		}


		responseVO.setOk(this.setProgressBarInfo(vLabNoteCd, noteInfoDTO));
		return responseVO;
	}

	public ResponseVO selectNoteDetailScheduleList(String vLabNoteCd) {
		ResponseVO responseVO = new ResponseVO();

		if(StringUtils.isEmpty(vLabNoteCd)) {
			responseVO.setOkWithCode(Const.FAIL, "필수 인자값이 없습니다", null);
			return responseVO;
		}

		HbdNoteInfoDTO noteInfoDTO = hbdCommonService.selectLabNoteInfo(vLabNoteCd);
		if(ObjectUtils.isEmpty(noteInfoDTO)) {
			responseVO.setOkWithCode(Const.FAIL, "실험노트 정보가 없습니다.", null);
			return responseVO;
		}

		LabNoteProcessResDTO resDTO = this.setProgressBarInfo(vLabNoteCd, noteInfoDTO);

		resDTO.setScheduleList(labNoteCommonService.selectNoteDetailScheduleList(vLabNoteCd));
		responseVO.setOk(resDTO);
		return responseVO;
	}

	public ResponseVO selectProgressInfo(String vLabNoteCd) {
		ResponseVO responseVO = new ResponseVO();
		String activeTabStatus = "AL_NOTE1";
		LabNoteProcessResDTO resDTO = new LabNoteProcessResDTO();
		List<LabNoteProcessTabListDTO> tabList = null;
		String vStatusCd = "";

		try {
			if(StringUtils.isEmpty(vLabNoteCd)) {
				responseVO.setOkWithCode(Const.FAIL, "필수 인자값이 없습니다.", null);
				return responseVO;
			}

			HbdNoteInfoDTO noteInfoDTO = hbdCommonService.selectLabNoteInfo(vLabNoteCd);
			if(ObjectUtils.isEmpty(noteInfoDTO)) {
				responseVO.setOkWithCode(Const.FAIL, "실험노트 정보가 없습니다.", null);
				return responseVO;
			}

			vStatusCd = noteInfoDTO.getVStatusCd();

			//개발취소인 경우
			if("LNC06_41".equals(noteInfoDTO.getVStatusCd())) {
				resDTO.setVFlagCancel("Y");
				vStatusCd = hbdCommonService.selectLabNoteStatusCd(vLabNoteCd);		//취소하기 이전 상태를 확인함
			}

			activeTabStatus = labNoteCommonService.selectLabNoteActiveStatus(vStatusCd);
			int activeNum = Integer.parseInt(activeTabStatus.replaceAll("[^0-9]", ""));

			String vPageType = "";
			if ("LNC07_02".equals(noteInfoDTO.getVLabTypeCd())) {
				vPageType = "HALF";
			} else if (!"LNC07_01".equals(noteInfoDTO.getVLabTypeCd()) && !"LNC07_02".equals(noteInfoDTO.getVLabTypeCd())) {
				vPageType = "NONPRD";
			}

			List<LabNoteProcessProgressDTO> progBar = labNoteCommonService.selectProgressInfo(vLabNoteCd, vPageType);
			int size = progBar == null ? 0 : progBar.size();

			if(size > 0) {
				for(int i = 0; i < size; i++) {
					LabNoteProcessProgressDTO progVo = progBar.get(i);
					progVo.setVCurrStatMark("is-none");

					int progNum = Integer.parseInt(progVo.getVStatusCd().replaceAll("[^0-9]", ""));
					if(progNum < activeNum) {
						progVo.setVCurrStatMark("is-past");
					}
					if(activeTabStatus.equals(progVo.getVStatusCd())) {
						progVo.setVCurrStatMark("is-active");
					}
				}

				activeTabStatus = this.getLabNoteActiveTabStatus(noteInfoDTO);

				LabNoteProcessReqDTO reqDTO = new LabNoteProcessReqDTO();
				String funcTestYn = noteInfoDTO.getVFlagFuncTest();
				reqDTO.setVActiveStatus(activeTabStatus);
				if("Y".equals(funcTestYn)) {
					reqDTO.setVFlagAddTab("FUNC");
				}
				reqDTO.setVFlagAddTab(reqDTO.getVFlagAddTab() + ";" + "QMS");

				tabList = hbdProcessMapper.selectProgressTabList(reqDTO);
			}

			resDTO.setProgressInfo(progBar);
			resDTO.setTabList(tabList);
		}catch(Exception e) {
			log.error("HbdProcessService.selectProgressInfo : {} " + e);
		}

		responseVO.setOk(resDTO);
		return responseVO;
	}

	private String getLabNoteActiveTabStatus(HbdNoteInfoDTO noteInfoDTO) {
		String activeTabStatus = "AL_NOTE1";

		//현재 상태가 LNC06_20 이상이면 실험중
		int statNum = Integer.parseInt(noteInfoDTO.getVStatusCd().substring(6));
		if(statNum > 20) {
			activeTabStatus = "AL_NOTE2";
		}

		//vFlagOpenBom이 Y 일 때, BOM(AL_NOTE2), PILOT(AL_NOTE3) 두 개 탭이 열린다.
		if(statNum >= 22) {
			activeTabStatus = "AL_NOTE3";
		}

		//파일럿 처방이 있을 때, 처방확정(AL_NOTE4) 탭이 열린다.
		if("Y".equals(noteInfoDTO.getVFlagPilotTest())) {
			activeTabStatus = "AL_NOTE4";
		}

		//확정 처방이 있는 경우, 전성분승인(AL_NOTE5) 탭이 열린다.
		if("Y".equals(noteInfoDTO.getVFlagDecideLot()) && !"CN20".equals(noteInfoDTO.getVPlantCd())) {
			activeTabStatus = "AL_NOTE5";
		}

		//전성분 승인된 것이 있는 경우, 개발완료(AL_NOTE7) 탭이 열린다.
		if("Y".equals(noteInfoDTO.getVFlagIngredientComplete()) && !"CN20".equals(noteInfoDTO.getVPlantCd())) {
			activeTabStatus = "AL_NOTE7";
		}

		return activeTabStatus;
	}

	public ResponseVO selectTimeLineList(String vLabNoteCd) {
		ResponseVO responseVO = new ResponseVO();

		if(StringUtils.isEmpty(vLabNoteCd)) {
			responseVO.setOkWithCode(Const.FAIL, "필수 인자값이 없습니다", null);
			return responseVO;
		}

		List<LabNoteProcessTimeLineDTO> timeline = hbdProcessMapper.selectTimeLineList(vLabNoteCd);

		responseVO.setOk(timeline);
		return responseVO;
	}


	public ResponseVO selectLabNoteBomReqList(PilotRequestReqDTO pilotRequestReqDTO) {
		ResponseVO responseVO = new ResponseVO();
		pilotRequestReqDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
		List<PilotRequestDTO> list = null;

		int totalCnt = hbdProcessMapper.selectLabNoteBomReqListCount(pilotRequestReqDTO);
		CommonUtil.setPaging(pilotRequestReqDTO, totalCnt);
		if (totalCnt > 0) {
			list = hbdProcessMapper.selectLabNoteBomReqList(pilotRequestReqDTO);
		}

		PagingDTO page = ConvertUtil.convert(pilotRequestReqDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
									.page(page)
									.list(list)
									.build();
		responseVO.setOk(res);
		return responseVO;
	}

//	===========================================================================================================================================================
//	전성분 승인 리스트 가져오기 로직 start
//	[AS-IS] ElabParentController - lab_note_experiment_view_tab06 - 1068 line 부터 참고
	public ResponseVO selectIngrdApprovalList(LabNoteProcessIngrdApprReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		MaterialSearchVO schVO = new MaterialSearchVO();
		HbdNoteInfoDTO rvo = hbdCommonService.selectLabNoteInfo(reqDTO.getVLabNoteCd());

		schVO.setVLabNoteCd(reqDTO.getVLabNoteCd());
		schVO.setVUserId(sessionUtil.getLoginId());
		hbdCommonService.selectElabNoteAuth(schVO, rvo);

		List<String> groups = sessionUtil.getGroups();

		// TODO)
		// 권한체크를 API를 탈때마다 체크하는 방식으로 할 것인지, 상위(페이즈 탭 클릭 시)에서 전역적으로 체크할 것인지
		// 추후에 이사님에게 여쭤본 후, 변경할 수 있음.
		// 현재는 AS-IS를 옮겨놓음.
		if("Y".equals(schVO.getVIsPersonInCharge())
				|| (!ObjectUtils.isEmpty(groups) && groups.stream().anyMatch(group -> "S000118;S000246".indexOf(group) > -1))){
			reqDTO.setVUserId(null);
		}else{
			reqDTO.setVUserId(sessionUtil.getLoginId());
		}

		reqDTO.setLocalLanguage(sessionUtil.getLocalLanguage());

		int totalCnt = hbdProcessMapper.selectLabNoteIngredientApprovalCount(reqDTO);
		List<LabNoteProcessIngrdApprDTO> list = null;
		CommonUtil.setPaging(reqDTO, totalCnt);

		if (totalCnt > 0) {
			list = hbdProcessMapper.selectLabNoteIngredientApprovalList(reqDTO);
		}

		PagingDTO page = ConvertUtil.convert(reqDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
				.page(page)
				.list(list)
				.build();

		responseVO.setOk(res);
		return responseVO;
	}

//	===========================================================================================================================================================
//	전성분 승인에 필요한 정보 가져오기 로직 start
//	[AS-IS] ElabParentController - lab_note_experiment_view_tab06 - 892 line 부터 참고
	public ResponseVO selectIngrdApprovalRegRequiredInfo(LabNoteProcessIngrdApprReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		String localLanguage = sessionUtil.getLocalLanguage();

		HbdNoteInfoDTO rvo = hbdCommonService.selectLabNoteInfo(reqDTO.getVLabNoteCd());

		List<LabNoteContInfoVO> contList = hbdCommonService.selectLabNoteContList(LabNoteContInfoVO.builder()
																								.vLabNoteCd(reqDTO.getVLabNoteCd())
																								.vCodeType("HAL3")
																								.localLanguage(localLanguage)
																								.build());

		if (StringUtils.isEmpty(reqDTO.getVContPkCd()) && !ObjectUtils.isEmpty(contList)) {
			for (LabNoteContInfoVO contVo : contList) {
				if ("Y".equals(contVo.getVFlagRepresent())) {
					reqDTO.setVContPkCd(contVo.getVContPkCd());
					break;
				}
			}
		}

		LabNoteContInfoVO contVo = hbdCommonService.selectLabNoteContInfo(LabNoteContInfoVO.builder()
																								.vContPkCd(reqDTO.getVContPkCd())
																								.build());

		if(ObjectUtils.isEmpty(contVo)) {
			responseVO.setOkWithCode("not_import_ingrd", "처방을 불러올수 없습니다.", null);
			return responseVO;
		}

		if ("Y".equals(rvo.getVFlagAerosol())) {
			if ("N".equals(labNoteCommonService.selectLabNoteExistsAerosolDecide(reqDTO.getVContPkCd()))) {
				responseVO.setOkWithCode(
					"not_decide_aerosol",
					new StringBuilder().append("[")
									   .append(contVo.getVPlantCd())
									   .append("]")
									   .append(contVo.getVContCd())
									   .append(" 에어로졸 실험노트가 확정 되지 않았습니다.")
									   .toString(),
					null
				);
				return responseVO;
			}
		}

		List<BomInfoVO> bomList = labNoteSAPInterfaceService.getT_ZPLMS013(contVo.getVPlantCd(), contVo.getVContCd(), reqDTO.getVLand());

		Map<String, List<LabNoteMateInfoVO>> mateListMap = hbdCommonService.selectLabNoteMateListMap(reqDTO.getVContPkCd());

		if (!ObjectUtils.isEmpty(bomList) && !ObjectUtils.isEmpty(mateListMap)) {
			String rawCd, hal4Cd;

			for (BomInfoVO bomVo : bomList) {
				rawCd = bomVo.getRawCd();
				hal4Cd = bomVo.getHal4Cd();

				if (StringUtils.isNotEmpty(hal4Cd)) {
					if(mateListMap.containsKey(hal4Cd)) {
						mateListMap.remove(hal4Cd);
					}
				} else if (StringUtils.isNotEmpty(rawCd)) {
					if(mateListMap.containsKey(rawCd)) {
						mateListMap.remove(rawCd);
					}
				}
			}
		}

		if (!ObjectUtils.isEmpty(mateListMap)) {
			StringBuilder resultSb = new StringBuilder();

			for(String key : mateListMap.keySet()) {
				resultSb.append("<br/><strong>[")
						.append(key)
						.append("]")
						.append(mateListMap.get(key).get(0).getVMateNm())
						.append("</strong>");
			}

			responseVO.setOkWithCode("exist_not_reg_matr", new StringBuilder().append("구성성분이 등록되지 않은 원료가 존재합니다.<br/>").append(resultSb.toString()).toString(), null);
			return responseVO;
		}

		LabNoteSapBomConSearchVO reqVo = LabNoteSapBomConSearchVO.builder()
																 .vLand(reqDTO.getVLand())
																 .vLeaveType(reqDTO.getVLeaveType())
																 .vContPkCd(reqDTO.getVContPkCd())
																 .vLabNoteCd(reqDTO.getVLabNoteCd())
																 .build();

		LabNoteSapRfcMat3AllListVO sapMat3Vo = hbdCommonService.getSapRfcMat3AllListMap(reqVo, labNoteSAPInterfaceService.getT_ZPLMS013_BOM_NEW(contVo.getVPlantCd(), contVo.getVContCd(), reqDTO.getVLand()));

		//사용고객이 영유아/어린이인지 확인
		List<MusoguTagVO> tuserList = hbdCommonService.selectLabNoteTagList(MusoguReqDTO.builder()
																							 .vLabNoteCd(reqDTO.getVLabNoteCd())
																							 .vTempTag1Cd("LNC12")
																							 .vGetListType("CHOOSE")
																							 .language(localLanguage)
																							 .build());
		String vKidtab06 = "N";

		if (!ObjectUtils.isEmpty(tuserList)) {
			for (int i = 0; i < tuserList.size(); i++) {
				MusoguTagVO vo = tuserList.get(i);
				if("LNC12_04".equals(vo.getVSubCode()) || "LNC12_07".equals(vo.getVSubCode())){
					vKidtab06 = "Y";
					break;
				}
			}
		}

		//2022-11-29 // 정지희님 요청  // 예외자재로 등록된 3자 매칭 시 안내 문구 // VIEW_INGRT_EXCEPTION
		int cautCnt =  labNoteCommonService.selectLabNoteIngrtCautionListCnt(contVo.getVContCd());

		String vFlagCaution = "N";

		if (cautCnt > 0) {
			vFlagCaution = "Y";
		} else {
			vFlagCaution = "N";
		}
		//2022-11-29 // 정지희님 요청  // 예외자재로 등록된 3자 매칭 시 안내 문구 // VIEW_INGRT_EXCEPTION

		responseVO.setOk(LabNoteProcessIngrdApprResDTO.builder()
													  .contList(contList)
													  .allergenList(sapMat3Vo.getAllergenList())
													  .noAllergenList(sapMat3Vo.getNoAllergenList())
													  .vKidtab06(vKidtab06)
													  .vFlagCaution(vFlagCaution)
													  .vSumRate(reqVo.getVSumRate())
													  .build());
		return responseVO;
	}

	public ResponseVO selectIngrdCompareInfo (LabNoteProcessIngrdApprReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		List<LabNoteSapBomToConInfoVO> allergenList = null;
		List<LabNoteSapBomToConInfoVO> noAllergenList = null;

		LabNoteContInfoVO contVo = hbdCommonService.selectLabNoteContInfo(LabNoteContInfoVO.builder()
																								.vContPkCd(reqDTO.getVContPkCd())
																								.build());

		if (!ObjectUtils.isEmpty(contVo)) {
			LabNoteSapBomConSearchVO reqVo = LabNoteSapBomConSearchVO.builder()
																	 .vLand(reqDTO.getVLand())
																	 .vLeaveType(reqDTO.getVLeaveType())
																	 .build();

			LabNoteSapRfcMat3AllListVO sapMat3Vo = hbdCommonService.getSapRfcMat3AllListMap(reqVo, labNoteSAPInterfaceService.getT_ZPLMS013_BOM_NEW(contVo.getVPlantCd(), contVo.getVContCd(), reqDTO.getVLand()));

			allergenList = sapMat3Vo.getAllergenList();
			noAllergenList = sapMat3Vo.getNoAllergenList();
		}

		responseVO.setOk(LabNoteProcessIngrdApprResDTO.builder()
													  .allergenList(allergenList)
													  .noAllergenList(noAllergenList)
													  .build());

		return responseVO;
	}

//	===========================================================================================================================================================
//  전성분 승인 로직 start
//  [AS-IS] LabNoteCommonController - lab_note_common_save - 280 line 부터 참고
	@Transactional
	public ResponseVO insertIngrdApproval (LabNoteProcessIngrdApprRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();

		String vLeaveType = regDTO.getVLeaveType();
		String vContPkCd = regDTO.getVContPkCd();
		String vLabNoteCd = regDTO.getVLabNoteCd();
//		String vLand = regDTO.getVLand();
//		String vNoteType = regDTO.getVNoteType();

//		hbdCommonService.updateStatusCd_LNC06_26(vLabNoteCd);

		LabNoteIngrdApprSaveInfoVO vo = hbdCommonService.selectLabNoteIngredientApprovalSaveInfo(LabNoteIngrdApprSaveInfoVO.builder()
																														 .vLeaveType(vLeaveType)
																														 .vContPkCd(vContPkCd)
																														 .vLabNoteCd(vLabNoteCd)
																														 .build());
		if (ObjectUtils.isEmpty(vo)) {
			responseVO.setOkWithCode(Const.FAIL, "해당 내용물 정보가 없습니다.(LOT중 확정처방으로 등록된 건이 없습니다.", null);
			return responseVO;
		}

		Zplmt14VO ingrdApprInfo = regDTO.getIngrdApprInfo();

		labNoteCommonService.insertSAPIngredientApproval(Zplmt14VO.builder()
																  .matnr(vo.getVContCd())
																  .werks(vo.getVPlantCd())
																  .zversion(vo.getVZversion())
																  .zchange(vo.getVZchange())
																  .datuv(vo.getVErdat())
																  .erdat(vo.getVErdat())
																  .ernam(vo.getVErnam())
																  .arjart(vo.getVArjart())
																  .land1(ingrdApprInfo.getLand1())
																  .lotCd(vo.getVLotCd())
																  .flag(ingrdApprInfo.getFlag())
																  .ztext(ingrdApprInfo.getZtext())
																  .ztextEn(ingrdApprInfo.getZtextEn())
																  .ztextCn(ingrdApprInfo.getZtextCn())
																  .ztextKcp(ingrdApprInfo.getZtextKcp())
																  .ztextEcp(ingrdApprInfo.getZtextEcp())
																  .displayLt(ingrdApprInfo.getDisplayLt())
																  .warningLt(ingrdApprInfo.getWarningLt())
																  .warningLtEn(ingrdApprInfo.getWarningLtEn())
																  .warningLtZh(ingrdApprInfo.getWarningLtZh())
																  .build());
		if (!ObjectUtils.isEmpty(regDTO.getIngrdRateList())) {
			List<Zplmt13VO> ingrdRateList = regDTO.getIngrdRateList();

			for (Zplmt13VO zvo : ingrdRateList) {
				labNoteCommonService.insertSAPIngredientRate(Zplmt13VO.builder()
																	  .matnr(vo.getVContCd())
																	  .concd(zvo.getConcd())
																	  .zversion(vo.getVZversion())
																	  .land1(zvo.getLand1())
																	  .inSeq(zvo.getInSeq())
																	  .inPer(zvo.getInPer())
																	  .inPerA(zvo.getInPerA())
																	  .erdat(vo.getVErdat())
																	  .ernam(vo.getVErnam())
																	  .casno(zvo.getCasno())
																	  .build());
			}
		}

		hbdCommonService.updateStatusCd_LNC06_26(vLabNoteCd);

		hbdCommonService.updateNoteLotStatusCd(vo.getVLotCd(), Const.LOT_04);

		commonService.insertLotStatusHistory(LotStatusRegDTO.builder()
															.vLabNoteCd(vLabNoteCd)
															.nVersion(vo.getNVersion())
															.vContPkCd(vContPkCd)
															.vLotCd(vo.getVLotCd())
															.vLabStatusCd(Const.LOT_04)
															.build());

		commonService.sendAlarm(AlarmRegDTO.builder()
									.vLabNoteCd(vLabNoteCd)
									.vStatusCd("AL_NOTE5")
									.vAlrTypeCd("AL_NOTE5_01")
									.typeList(Arrays.asList(Const.SCHEDULE, Const.TIMELINE))
									.vContCd(vo.getVContCd())
									.vContNm(vo.getVContNm())
									.nVerNo((vo.getNVersion() < 10 ? "0" : "") + String.valueOf(vo.getNVersion()))
									.vLotNm(vo.getVLotNm())
									.vNoteType("HBO")
									.build());

		responseVO.setOk(Const.SUCC);
		return responseVO;
	}

//	===========================================================================================================================================================
//	전성분 승인 정보 가져오기 로직 start
//	[AS-IS] ElabParentController - lab_note_experiment_view_tab06 - 1047 line 부터 참고
	public ResponseVO selectIngrdApprovalInfo(LabNoteProcessIngrdApprReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(hbdCommonService.selectLabNoteIngredientApproval(LabNoteIngrdApprConInfoVO.builder()
																										.vContPkCd(reqDTO.getVContPkCd())
																										.vMatnr(reqDTO.getVMatnr())
																										.vWerks(reqDTO.getVWerks())
																										.vZversion(reqDTO.getVZversion())
																										.build()));
		return responseVO;
	}

	public ResponseVO selectLabNoteFuncDecideNameList(LabNoteProcessFuncReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();
		List<LabNoteProcessFuncResDTO> list = null;

		reqDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
		int recordCnt = hbdProcessMapper.selectLabNoteFuncDecideNameListCount(reqDTO);
		CommonUtil.setPaging(reqDTO, recordCnt);

		if(recordCnt > 0) {
			list = hbdProcessMapper.selectLabNoteFuncDecideNameList(reqDTO);
		}

		PagingDTO page = ConvertUtil.convert(reqDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
															.page(page)
															.list(list)
															.build();

		responseVO.setOk(res);
		return responseVO;
	}

	public ResponseVO selectLabContList(String vLabNoteCd) {
		ResponseVO responseVO = new ResponseVO();
		HbdNoteInfoDTO noteInfoDTO = hbdCommonService.selectLabNoteInfo(vLabNoteCd);
		List<IngredientContVO> nameList = null;

		if(noteInfoDTO != null) {
			IngredientReqDTO ingrDto = new IngredientReqDTO();
			ingrDto.setVLabNoteCd(noteInfoDTO.getVLabNoteCd());
			ingrDto.setNVersion(noteInfoDTO.getNMaxVersion());
			ingrDto.setLocalLanguage(sessionUtil.getLocalLanguage());
			nameList = hbdCommonService.selectLabContList(ingrDto);

			List<ApprovalDetailDTO> apprList = hbdProcessMapper.selectLabNoteFuncDecideNameApprUserList(vLabNoteCd);

			LabNoteProcessFuncResDTO res = LabNoteProcessFuncResDTO.builder()
																	.vFlagSaveAction("R")
																	.vLabNoteCd(vLabNoteCd)
																	.vFdnStatusCd("DOC010")
																	.vFlagNameModAuth("Y")
																	.vStatusCd(noteInfoDTO.getVStatusCd())
																	.build();

			LabNoteProcessFuncDecideResDTO resDTO = LabNoteProcessFuncDecideResDTO.builder()
																.resVo(res)
																.nameList(nameList)
																.apprList(apprList)
																.build();
			responseVO.setOk(resDTO);
		}
		return responseVO;
	}

	public ResponseVO saveLabNoteFuncDecideName(LabNoteProcessFuncReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();
		String flagSaveAction = reqDTO.getVFlagSaveAction();
		ResultDTO resultVo = new ResultDTO();

		if(!"APPR_NEXT".equals(flagSaveAction)) {
			if(StringUtils.isEmpty(reqDTO.getVNoteType())
					|| StringUtils.isEmpty(reqDTO.getVLabNoteCd())
					|| StringUtils.isEmpty(reqDTO.getVFlagSaveAction())
					) {
				responseVO.setOkWithCode(Const.FAIL, "필수 인자값이 없습니다", null);
				return responseVO;
			}
		}

		if("R".equals(flagSaveAction)) {	//임시저장 > 최초 등록
			resultVo = this.insertLabNoteFuncDecideName(reqDTO);
		}
		else if("M".equals(flagSaveAction)) {	//임시저장 > 기존 내용 수정
			resultVo = this.updateLabNoteFuncDecideName(reqDTO);
		}
		else if("D".equals(flagSaveAction)) {	//삭제
			resultVo = this.deleteLabNoteFuncDecideName(reqDTO);
		}
//		else if("APPR_NEXT".equals(flagSaveAction)) {	//결재함 - 의견작성 (승인/반려)
//			approvalService.updateFuncDecideName()		//이 과정은 해당 소스에 따로 구현함
//		}
		else {
			responseVO.setOkWithCode(Const.FAIL, "필수 인자값이 없습니다", null);
			return responseVO;
		}

		//결재 요청
		String statusCd = reqDTO.getVStatusCd();
		HbdNoteInfoDTO noteInfoDTO = hbdCommonService.selectLabNoteInfo(reqDTO.getVLabNoteCd());

		//결재 요청으로 코드가 내려오면 결재 요청
		if("DOC020".equals(statusCd) && (flagSaveAction.equals("R")||flagSaveAction.equals("M"))) {

			FuncDecideNameVO funcDecideNameVO = this.convertReqToFuncNameVo(reqDTO);
			funcDecideNameVO.setLocalLanguage(sessionUtil.getLocalLanguage());
			List<FuncDecideContNameVO> nameList = hbdCommonService.selectLabNoteFuncDecideContName(funcDecideNameVO);
			int nameListSize = nameList == null ? 0 : nameList.size();

			if(nameListSize > 0) {
				String draftTitle = "[기능성 확정제품명 확인요청]"+" ("+nameList.get(0).getVContCd()+") "+nameList.get(0).getVContNm();
				if(nameListSize > 1) {
					draftTitle += " 외 " +(nameListSize-1)+"건";
				}

				String apprCd = commonService.handlingOfApprovalEp("APS030", draftTitle, reqDTO.getApprReqInfo());

				reqDTO.setVApprCd(apprCd);
				reqDTO.setVFlagCompleteDtmDel("Y");
				FuncDecideNameVO funcNameVo = this.convertReqToFuncNameVo(reqDTO);
				labNoteCommonService.updateLabNoteFuncDecideName(funcNameVo);

				String pageUrl = new StringBuilder()
						.append("/hbd/all-lab-note-prd-process?vLabNoteCd=").append(reqDTO.getVLabNoteCd())
						.append("&vTabId=funcComplete")
						.append("&vSubTabId=prodName")
						.append("&vApprCd=").append(apprCd)
						.toString();

				commonService.updateSkyApprovalAprvDtlUrl(apprCd, pageUrl);
				commonService.sendMailApproval(ApprovalDTO.builder()
						.vApprCd(apprCd)
						.vUrl(pageUrl)
						.vResultStatus(ApprovalResultCode.APPR_REQUEST.getCode())
						.build());

				//AL_NOTE0_03 기능성 제품명 확정 결재 의뢰
				List<String> arrUserList = new ArrayList<String>();
				//알람이 있는 상태만 userList 설정함
				List<ApprovalDetailDTO> approvalUserList = reqDTO.getApprReqInfo().getApprList();
				for(ApprovalDetailDTO apprVo : approvalUserList) {
					arrUserList.add(apprVo.getVApprUserid());	//결재권자
				}

				commonService.sendAlarm(AlarmRegDTO.builder()
						.vLabNoteCd(noteInfoDTO.getVLabNoteCd())
						.vStatusCd("AL_NOTE0")
						.vAlrTypeCd("AL_NOTE0_03")
						.typeList(Arrays.asList(Const.ALARM, Const.MAIL, Const.TIMELINE))
						.vContCd(noteInfoDTO.getVContCd())
						.vContNm(noteInfoDTO.getVContNm())
						.vNoteType("HBO")
						.userList(arrUserList)
						.vMoveUrl(pageUrl)
						.build());
			}
		}

		responseVO.setOkWithCode(resultVo.getStatus(), resultVo.getMessage(), resultVo.getObject());
		return responseVO;
	}

	public ResultDTO insertLabNoteFuncDecideName(LabNoteProcessFuncReqDTO reqDTO) {
		ResultDTO resultMap = new ResultDTO();
		reqDTO.setVRegUserid(sessionUtil.getLoginId());
		reqDTO.setVUpdateUserid(sessionUtil.getLoginId());

		//신규 등록시 해당 LabNoteCd에 등록된  V_FLAG_LAST 값을 'N'으로 변경
		labNoteCommonService.updateLabNoteFuncDecideNameAllLastN(reqDTO);

		//MST 저장
		int nFdnVer = labNoteCommonService.selectLabNoteFuncDecideNameMaxVer(reqDTO);

		reqDTO.setNFdnVer(nFdnVer);
		labNoteCommonService.insertLabNoteFuncDecideName(reqDTO);

		//확장명 저장
		List<LabNoteProcessFuncDecideReqDTO> arrDecideContList = reqDTO.getArrDecideContList();
		int len = arrDecideContList == null ? 0 : arrDecideContList.size();

		if(len > 0) {
			for(LabNoteProcessFuncDecideReqDTO decideCont : arrDecideContList) {
				decideCont.setVLabNoteCd(reqDTO.getVLabNoteCd());
				decideCont.setNFdnVer(reqDTO.getNFdnVer());
				decideCont.setVNoteType(reqDTO.getVNoteType());
				decideCont.setVRegUserid(sessionUtil.getLoginId());
				decideCont.setVUpdateUserid(sessionUtil.getLoginId());

				if(!"N".equals(decideCont.getVFlagNmDel())) {
					decideCont.setVDecideContNm("");
				}

				labNoteCommonService.insertLabNoteFuncDecideContName(decideCont);
			}
		}

		resultMap.setStatus(Const.CODE);
		resultMap.setMessage("저장하였습니다.");
		return resultMap;
	}

	public ResultDTO updateLabNoteFuncDecideName(LabNoteProcessFuncReqDTO reqDTO) {
		ResultDTO resultMap = new ResultDTO();
		reqDTO.setVUpdateUserid(sessionUtil.getLoginId());
		FuncDecideNameVO funcNameVo = this.convertReqToFuncNameVo(reqDTO);

		//MST 수정
		labNoteCommonService.updateLabNoteFuncDecideName(funcNameVo);

		//확장명 수정
		List<LabNoteProcessFuncDecideReqDTO> arrDecideContList = reqDTO.getArrDecideContList();
		int len = arrDecideContList == null ? 0 : arrDecideContList.size();
		if(len > 0) {
			for(LabNoteProcessFuncDecideReqDTO decideCont : arrDecideContList) {
				decideCont.setVLabNoteCd(reqDTO.getVLabNoteCd());
				decideCont.setNFdnVer(reqDTO.getNFdnVer());
				decideCont.setVNoteType(reqDTO.getVNoteType());
				decideCont.setVRegUserid(sessionUtil.getLoginId());
				decideCont.setVUpdateUserid(sessionUtil.getLoginId());

				if("N".equals(decideCont.getVFlagNmDel())) {
					labNoteCommonService.updateLabNoteFuncDecideContName(decideCont);
				}else {
					labNoteCommonService.deleteLabNoteFuncDecideContName(decideCont);
				}
			}
		}

		resultMap.setStatus(Const.CODE);
		resultMap.setMessage("수정하였습니다.");
		return resultMap;
	}

	private FuncDecideNameVO convertReqToFuncNameVo(LabNoteProcessFuncReqDTO reqDTO) {
		FuncDecideNameVO funcNameVo = new FuncDecideNameVO();
		funcNameVo.setVUpdateUserid(reqDTO.getVUpdateUserid());
		funcNameVo.setVStatusCd(reqDTO.getVStatusCd());
		funcNameVo.setVApprCd(reqDTO.getVApprCd());
		funcNameVo.setVFlagComplete(reqDTO.getVFlagComplete());
		funcNameVo.setVFlagCompleteDtmDel(reqDTO.getVFlagCompleteDtmDel());

		funcNameVo.setVLabNoteCd(reqDTO.getVLabNoteCd());
		funcNameVo.setNFdnVer(reqDTO.getNFdnVer());
		funcNameVo.setVNoteType(reqDTO.getVNoteType());
		funcNameVo.setVFlagNameModAuth(reqDTO.getVFlagNameModAuth());

		return funcNameVo;
	}

	public ResultDTO deleteLabNoteFuncDecideName(LabNoteProcessFuncReqDTO reqDTO) {
		ResultDTO resultMap = new ResultDTO();

		//MST 삭제
		labNoteCommonService.deleteLabNoteFuncDecideName(reqDTO);

		LabNoteProcessFuncDecideReqDTO decideCont = new LabNoteProcessFuncDecideReqDTO();
		decideCont.setVLabNoteCd(reqDTO.getVLabNoteCd());
		decideCont.setNFdnVer(reqDTO.getNFdnVer());
		decideCont.setVUpdateUserid(reqDTO.getVUpdateUserid());
		decideCont.setVContPkCd("");		//확장명 전체 삭제

		labNoteCommonService.deleteLabNoteFuncDecideContName(decideCont);

		resultMap.setStatus(Const.CODE);
		resultMap.setMessage("삭제하였습니다.");
		return resultMap;
	}

	public ResponseVO selectLabNoteFuncDecideContName(LabNoteProcessFuncReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		HbdNoteInfoDTO noteInfoDTO = hbdCommonService.selectLabNoteInfo(reqDTO.getVLabNoteCd());
		List<FuncDecideContNameVO> nameList = null;
		String flagNameModAuth = "N";
		String apprCd = "";

		if(noteInfoDTO != null) {
			String regUserId = reqDTO.getVRegUserid();
			if(StringUtils.isNotEmpty(regUserId)) {
				if(regUserId.equals(sessionUtil.getLoginId()) || sessionUtil.isSysadmin()) {
					if("DOC010".equals(reqDTO.getVStatusCd()) || "DOC030".equals(reqDTO.getVStatusCd())) {
						flagNameModAuth = "Y";
					}
				}
			}

			reqDTO.setVFlagNameModAuth(flagNameModAuth);
			FuncDecideNameVO funcNameVo = this.convertReqToFuncNameVo(reqDTO);
			nameList = hbdCommonService.selectLabNoteFuncDecideContName(funcNameVo);
			int nameListSize = nameList == null ? 0 : nameList.size();
			if(nameListSize > 0) {
				apprCd = nameList.get(0).getVApprCd();
			}

			List<ApprovalDetailDTO> apprList = hbdProcessMapper.selectLabNoteFuncDecideNameApprUserList(reqDTO.getVLabNoteCd());

			LabNoteProcessFuncResDTO res = LabNoteProcessFuncResDTO.builder()
																	.vFlagSaveAction(reqDTO.getVFlagSaveAction())
																	.vLabNoteCd(reqDTO.getVLabNoteCd())
																	.vFdnStatusCd(reqDTO.getVStatusCd())
																	.vFlagNameModAuth(flagNameModAuth)
																	.vStatusCd(noteInfoDTO.getVStatusCd())
																	.nFdnVer(reqDTO.getNFdnVer())
																	.vApprCd(apprCd)
																	.build();

			LabNoteProcessFuncDecideResDTO resDTO = LabNoteProcessFuncDecideResDTO.builder()
																				.resVo(res)
																				.savedNameList(nameList)
																				.apprList(apprList)
																				.build();
			responseVO.setOk(resDTO);
		}

		return responseVO;
	}

	public ResponseVO selectFuncTestEpReportList(LabNoteProcessFuncReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();
		List<LabNoteProcessFuncReportResDTO> list = null;

		reqDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
		int recordCnt = hbdProcessMapper.selectFuncTestEpReportListCount(reqDTO);
		CommonUtil.setPaging(reqDTO, recordCnt);

		if(recordCnt > 0) {
			list = hbdProcessMapper.selectFuncTestEpReportList(reqDTO);
		}

		PagingDTO page = ConvertUtil.convert(reqDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
															.page(page)
															.list(list)
															.build();

		responseVO.setOk(res);
		return responseVO;
	}

	public ResponseVO selectLabNoteFuncRequestQA(LabNoteProcessFuncReportReqPopDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		if(StringUtils.isEmpty(reqDTO.getVNoteType())
				|| StringUtils.isEmpty(reqDTO.getVLabNoteCd())
				|| StringUtils.isEmpty(String.valueOf(reqDTO.getNVersion()))
				|| StringUtils.isEmpty(String.valueOf(reqDTO.getNSeqno()))
				) {
			responseVO.setOkWithCode(Const.FAIL, "필수 인자값이 없습니다", null);
			return responseVO;
		}

		LabNoteProcessFuncReportResPopDTO rvo = hbdProcessMapper.selectLabNoteFuncRequestQA(reqDTO);
		String deCideName = labNoteCommonService.selectLabNoteDecideContNm(reqDTO.getVLabNoteCd());

		if(rvo != null) {
			if(StringUtils.isNotEmpty(deCideName)) {
				int idx = rvo.getVTitle().indexOf(")");
				String deCideNm = rvo.getVTitle().substring(0, idx+1);
				rvo.setVTitle(deCideNm + " " + deCideName);
				rvo.setVDecideContNm(deCideName);
			}
		}

		responseVO.setOk(rvo);
		return responseVO;
	}

	public ResponseVO saveUploadFuncReportFile(@Valid LabNoteProcessFuncReportReqPopDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		try {
			if(StringUtils.isEmpty(reqDTO.getVNoteType())
					|| StringUtils.isEmpty(reqDTO.getVLabNoteCd())
					|| StringUtils.isEmpty(String.valueOf(reqDTO.getNVersion()))
					|| StringUtils.isEmpty(String.valueOf(reqDTO.getNSeqno()))
					) {
				responseVO.setOkWithCode(Const.FAIL, "필수 인자값이 없습니다", null);
				return responseVO;
			}

			String refTypeCd = reqDTO.getVRefTypeCd();
			String docClass = "";

			if(refTypeCd.equals("LNC05_02") || refTypeCd.equals("LNC05_05")) {
				docClass = "REP113";
			}else if(refTypeCd.equals("LNC05_03")) {
				docClass = "REP111";
			}else if(refTypeCd.equals("LNC05_04")) {
				docClass = "REP112";
			}else {
				responseVO.setOkWithCode(Const.FAIL, "[docClass] 인자값이 없습니다.", null);
				return responseVO;
			}

			reqDTO.setVDocClass(docClass);
			reqDTO.setVDocType("TYP010");
			reqDTO.setVStorageCd("STR999");
			reqDTO.setVApprStatus("DOC010");
			reqDTO.setVStatusCd("002");

			ResultDTO resultDTO = this.insertFuncEpReport(reqDTO);

	        if ("succ".equals(resultDTO.getStatus())) {
	        	responseVO.setCreateOk(null);
	        } else {
	        	responseVO.setOkWithCode("C9999", CommonResultCode.SAVE_FAIL, null);
	        }
		}catch(Exception e) {
			log.error("HbdProcessService.saveUploadFuncReportFile {}", e.getMessage());
		}
		return responseVO;
	}

	public ResultDTO insertFuncEpReport(@Valid LabNoteProcessFuncReportReqPopDTO reqDTO) {
		ResultDTO resultDTO = new ResultDTO();
		int result = 0;
		String pk = reqDTO.getVRecordid();
		String refTypeCd = reqDTO.getVRefTypeCd();
		LabNoteProcessFuncReportResPopDTO rvo = hbdProcessMapper.selectLabNoteFuncRequestQA(reqDTO);

		if(StringUtils.isEmpty(pk)) {
			if(refTypeCd.equals("LNC05_02") || refTypeCd.equals("LNC05_05")) {
				//기능성 보고 신규접수를 위해 i_sSort(V_BUFFER1)에 NEW를 넣어줌
				reqDTO.setVContent("");
				reqDTO.setVSort("NEW");
				reqDTO.setVTag("#2019");
			}

			// 셀프등록이 아닐 경우에는 시험성적서 요청자/요청자 소속부서로 설정
			if(!"Y".equals(reqDTO.getVFlagSelf())){
				reqDTO.setVRegUserid(rvo.getVSenderId());		// 등록자 해당 시험성적서 요청자로 변경
				reqDTO.setSigma_deptcd(rvo.getVSenderDeptcd());		// 소속부서 해당 시험성적서 요청자의 소속부서로 변경
			}

			LabNoteProcessFuncReportDataDTO fvo = this.selectFuncData(reqDTO, null, null, rvo, null, null, null);
			String vContent = new EpReportForm().getEpReportContent(refTypeCd, fvo);

			pk = labNoteCommonService.selectEpReportSeq();

			reqDTO.setVRecordid(pk);
			LabNoteCommonWokReportReqDTO wokReportVo = LabNoteCommonWokReportReqDTO.builder()
					.vRecordid(pk)
					.vTitle(reqDTO.getVTitle())
					.vApprStatus(reqDTO.getVApprStatus())
					.vContent(vContent)
					.vDocType(reqDTO.getVDocType())
					.vDocClass(reqDTO.getVDocClass())
					.vStorageCd(reqDTO.getVStorageCd())
					.vRegUserid(StringUtils.isNotEmpty(reqDTO.getVRegUserid()) ? reqDTO.getVRegUserid() : sessionUtil.getLoginId())
					.vUpdateUserid(StringUtils.isNotEmpty(reqDTO.getVUpdateUserid()) ? reqDTO.getVUpdateUserid() : sessionUtil.getLoginId())
					.sigma_deptcd(reqDTO.getSigma_deptcd())
					.vLabNoteCd(reqDTO.getVLabNoteCd())
					.nVersion(reqDTO.getNVersion())
					.vTag(reqDTO.getVTag())
					.vSort(reqDTO.getVSort())
					.build();
			result = labNoteCommonService.insertEpReport(wokReportVo);
		}

		if(result > 0) {

			reqDTO.setTargetCd(pk);
			reqDTO.setVRecordid(pk);
			commonService.saveCommAttach(reqDTO.getFileList(), reqDTO.getVUploadCd(), reqDTO.getVRecordid());

			if("LNC05_03".equals(reqDTO.getVRefTypeCd())) {
				reqDTO.setVRegUserid(sessionUtil.getLoginId());
				hbdProcessMapper.insertLabFuncToNewFunc(reqDTO);
			}

			reqDTO.setVUpdateUserid(sessionUtil.getLoginId());
			hbdProcessMapper.updateLabNoteFuncRequestQA(reqDTO);

			String title = "[기능성 검사 첨부 파일 전송 완료]" + reqDTO.getVTitle();
			MailForm mailForm = new MailForm();
			HashMap<String, String> params = new HashMap<>();

			params.put("vTitle", reqDTO.getVTitle());
			params.put("vNoteType", reqDTO.getVNoteType());
			params.put("vNoteTypeNm", reqDTO.getVNoteTypeNm());
			params.put("vLabNoteCd", reqDTO.getVLabNoteCd());
			params.put("vRecordid", reqDTO.getVRecordid());
			params.put("nVersion", String.valueOf(reqDTO.getNVersion()));
			params.put("nSeqno", String.valueOf(reqDTO.getNSeqno()));
			params.put("vMybkRegYn", hbdCommonService.selectLabNoteMybkRegYn(reqDTO.getVLabNoteCd()));
			String mailContent = mailForm.getMailContent(MailDTO.MAIL_ANSWER_FUNC_TEST, params);
			SupGlobalMailUserVO userEmail =  labNoteCommonService.selectUserEmail(rvo.getVSenderId());
			MailUtil.send(userEmail.getVEmail(), null, title, mailContent);

			resultDTO.setStatus("succ");
		}
		else {
			resultDTO.setStatus("fail");
		}

		return resultDTO;
	}

	private LabNoteProcessFuncReportDataDTO selectFuncData(@Valid LabNoteProcessFuncReportReqPopDTO reqDTO,
				HbdNoteInfoDTO rvo,
				LabNoteVersionDTO verVo,
				LabNoteProcessFuncReportResPopDTO funcReqVo,
				List<LabNoteProcessFuncMateResDTO> mateList,
				List<LabNoteCommonTagDTO> funcList,
				List<MusoguTagVO> releaseDtList
			) {

		String getListType = "CHOOSE";

		if(rvo == null) {
			rvo = hbdCommonService.selectLabNoteInfo(reqDTO.getVLabNoteCd());
		}

		if(verVo == null) {
			verVo = hbdCommonService.selectLabNoteMstVerInfo(reqDTO.getVLabNoteCd(), reqDTO.getNVersion());
		}

		if(funcReqVo == null) {
			funcReqVo = hbdProcessMapper.selectLabNoteFuncRequestQA(reqDTO);
		}

		if(mateList == null) {
			mateList = hbdProcessMapper.selectLabNoteFuncMateList(reqDTO.getVLabNoteCd(), reqDTO.getNVersion(), reqDTO.getVContPkCd());
		}

		if(funcList == null) {
			funcList = this.selectLabNoteMstVerTagList("EV_MATERIAL_FUNC2", reqDTO.getVLabNoteCd(), reqDTO.getNVersion());
		}

		if(releaseDtList == null) {
			MusoguReqDTO musoguDTO = MusoguReqDTO.builder()
					.vLabNoteCd(reqDTO.getVLabNoteCd())
					.language(sessionUtil.getLangCd())
					.vTempTag1Cd("LNC02")
					.vGetListType(getListType)
					.build();
			releaseDtList = hbdCommonService.selectLabNoteTagList(musoguDTO);
		}

		int mateListSize = mateList == null ? 0 : mateList.size();
		int funcListSize = funcList == null ? 0 : funcList.size();
		int releaseDtSize = releaseDtList == null ? 0 :releaseDtList.size();

		StringBuilder mateStr 	   = new StringBuilder();
		StringBuilder mateCdStr 	   = new StringBuilder();
		StringBuilder mateCdNmStr 	   = new StringBuilder();
		StringBuilder mateCdperStr 	   = new StringBuilder();
		StringBuilder permitStr 	   = new StringBuilder();
		StringBuilder funcStr 	   = new StringBuilder();
		StringBuilder releaseStr   = new StringBuilder();

		if(mateListSize > 0) {
			for(int i = 0;  i < mateListSize; i++) {
				LabNoteProcessFuncMateResDTO mateVo = mateList.get(i);
				mateStr.append("[" + mateVo.getVMateCd() + "] ").append(mateVo.getVMateNm()).append("(" + mateVo.getNReqRate() + "% )");
				permitStr.append("[" + mateVo.getVMateCd() + "] ").append(mateVo.getVMatePermitNm()).append("(" + mateVo.getNReqRate() + "% )");
				mateCdStr.append(mateVo.getVMateCd());
				mateCdNmStr.append(mateVo.getVMateNm());
				mateCdperStr.append(mateVo.getNReqRate());
				if(i != (mateListSize - 1)) {
					mateStr.append("\n");
					permitStr.append("");
					mateCdStr.append(",");
					mateCdNmStr.append("\n");
					mateCdperStr.append(",");
				}
			}
		}

		if(funcListSize > 0) {
			for(int i = 0; i < funcListSize; i++){
				LabNoteCommonTagDTO funcVo = funcList.get(i);
				if(i != 0){
					funcStr.append(", ");
				}
				funcStr.append(funcVo.getVSubCodenm());
			}
		}

		String key;
		String sKorMeetingDt ="";
		List<MusoguTagVO> subList = null;
		Map<String, List<MusoguTagVO>> releaseMap = new HashMap<String, List<MusoguTagVO>>();

		if(releaseDtSize > 0) {
			for(int i = 0; i < releaseDtSize; i++) {
				MusoguTagVO releaseVo = releaseDtList.get(i);

				releaseStr.append(releaseVo.getVSubCodenm() + "(" + CommonUtil.getPointDate(releaseVo.getVTagBuffer1()) + ") ");		//v_tag_buffer1  => v_release_dt

				if(releaseVo.getVSubCode().equals("LNC02_04")) {
					releaseStr.append("(" + releaseVo.getVTagBuffer2() + ")");		//v_tag_buffer2  => v_release_note
				}

				if(releaseVo.getVSubCode().equals("LNC02_01")) {
					sKorMeetingDt = releaseVo.getVTagBuffer1();	//v_tag_buffer1  => v_release_dt
				}

				key = releaseVo.getVBuffer1().equals("") ? "EMPTY" : releaseVo.getVBuffer1();

				subList = releaseMap.get(key);

				if (subList == null) {
					subList = new ArrayList<MusoguTagVO>();
					releaseMap.put(key, subList);
				}

				subList.add(releaseVo);
			}
		}

		String str = verVo.getVRefNote();
		if(verVo.getVRefTypeCd().equals("LNC05_02")) {
			if(StringUtils.isNotEmpty(verVo.getVEvaluateGosiCd())) {
				str = verVo.getVEvaluateno()  + "/"  + verVo.getVEvaluateGosiNm();
			}else {
				str = verVo.getVEvaluateno();
			}
		}

		String [] splitShape = {};
		if(!verVo.getVRefTypeCd().equals("LNC05_03")) {
			if(StringUtils.isNotEmpty(verVo.getVDosageNmList())) {
				splitShape = verVo.getVDosageNmList().split(",");
			}
		}

		LabNoteProcessFuncReportDataDTO returnVo = LabNoteProcessFuncReportDataDTO.builder()
				.vNoteType(reqDTO.getVNoteType())
				.vContCd(rvo.getVContCd())
				.vContNm(rvo.getVContNm())
				.vRealDecideContNm(rvo.getVDecideContNm())
				.vUserid(rvo.getVUserid())
				.vUsernm(rvo.getVUsernm())
				.vPlantCd(rvo.getVPlantCd())
				.vUserInfo(rvo.getVUsernm() + "("  + rvo.getVUsrDeptnm()  + ")")
				.vBrdUserid(rvo.getVBrdUserid())
				.vBrdUsernm(rvo.getVBrdUsernm())
				.vBrdUserInfo(rvo.getVBrdUsernm() + "(" + rvo.getVBrdDeptnm() + ")")
				.vFlagReleaseAsia(rvo.getVFlagReleaseAsia())
				.vFlagReleaseAsean(rvo.getVFlagReleaseAsean())
				.vFlagReleaseEtc(rvo.getVFlagReleaseEtc())
				.vFlagFuncTest(rvo.getVFlagFuncTest())
				.vPilotDt(CommonUtil.getPointDate(rvo.getVPilotDt()))
				.vMassProdDt(CommonUtil.getPointDate(rvo.getVMassProdDt()))
				.vMeetingDt(CommonUtil.getPointDate(sKorMeetingDt))
				.vDecideContNm(verVo.getVDecideContNm())
				.vFlagDecide(verVo.getVFlagDecide())
				.vEvaluateCd(verVo.getVEvaluateCd())
				.vEvalueteNo(verVo.getVEvaluateno())
				.vEvalueteGosiCd(verVo.getVEvaluateGosiCd())
				.vEvalueteGosiNm(verVo.getVEvaluateGosiNm())
				.vShape(verVo.getVShape())
				.vDosageCd(verVo.getVDosageCd())
				.vDosageCdList(verVo.getVDosageCdList())
				.vRefTypeCd(verVo.getVRefTypeCd())
				.vRefTypeNm(verVo.getVRefTypeNm())
				.vRefTypeInfo(verVo.getVRefTypeNm() + "(" + str + ")")
				.vLabNoteCd(funcReqVo.getVLabNoteCd())
				.nVersion(funcReqVo.getNVersion())
				.nSeqno(funcReqVo.getNSeqno())
				.vTitle(funcReqVo.getVTitle())
				.vReqContent(funcReqVo.getVReqContent())
				.vNumberNm(funcReqVo.getVNumberNm())
				.vFlagOverEthanol(funcReqVo.getVFlagOverEthanol())
				.vFlagOverEthanolNm(funcReqVo.getVFlagOverEthanolNm())
				.vPh(funcReqVo.getVPh())
				.vMaker(funcReqVo.getVMaker())
				.nTioTwoRate(funcReqVo.getNTioTwoRate())
				.nZnoRate(funcReqVo.getNZnoRate())
				.vTioTwoNote(funcReqVo.getVTioTwoNote())
				.vZnoNote(funcReqVo.getVZnoNote())
				.vEvaluateNum(funcReqVo.getVEvaluateNum())
				.vChangeProduct(funcReqVo.getVChangeProduct())
				.vChangeCd(funcReqVo.getVChangeCd())
				.vChangeNote(funcReqVo.getVChangeNote())
				.vEffect(funcReqVo.getVEffect())
				.vUsageCapacity(funcReqVo.getVUsageCapacity())
				.vMakePlace(funcReqVo.getVMakePlace())
				.vReleaseDt(releaseStr.toString())
				.vFuncTypeInfo(funcStr.toString())
				.vFuncMateInfo(mateStr.toString())
				.vFuncMatePermitNmInfo(permitStr.toString())
				.vManagementNum(rvo.getVContCd() + "_" + funcReqVo.getNVersion() + "_" + funcReqVo.getNSeqno())
				.releaseMap(releaseMap)
				.vDosageNm1( splitShape.length > 0 && StringUtils.isNotEmpty(splitShape[0]) ? splitShape[0] : "")
				.vDosageNm2( splitShape.length > 0 && StringUtils.isNotEmpty(splitShape[1]) ? splitShape[1] : "")
				.vDosageNm3( splitShape.length > 0 && StringUtils.isNotEmpty(splitShape[2]) ? splitShape[2] : "")
				.build();

		//[s] HBO 일 때만 해당 로직 수행
		String hboRepresentCd = hbdProcessMapper.selectHboRepresentContCd(reqDTO);

		if(StringUtils.isNotEmpty(hboRepresentCd)) {
			reqDTO.setVHboRepresentContCd(hboRepresentCd);
			HbdContentDetailDTO hboVo = hbdProcessMapper.selectHBONoteRequestCont(reqDTO);

			if(hboVo != null) {
				returnVo.setVContCd(hboVo.getVContCd());
				returnVo.setVContNm(hboVo.getVContNm());
			}
		}
		//[e] HBO 일 때만 해당 로직 수행

		return returnVo;
	}

	public ResponseVO selectFuncTestEpReportReg(LabNoteProcessFuncReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();
		LabNoteProcessFuncReportRegResDTO<HbdNoteInfoDTO> resDTO = new LabNoteProcessFuncReportRegResDTO<HbdNoteInfoDTO>();
		LabNoteProcessFuncReportVerLotVO basicInfo = new LabNoteProcessFuncReportVerLotVO();

		if(StringUtils.isEmpty(reqDTO.getVLabNoteCd())
				) {
			responseVO.setOkWithCode(Const.FAIL, "필수 인자값이 없습니다", null);
			return responseVO;
		}

		String getListType = "CHOOSE";
		List<IngredientContVO> contList = null;
		HbdNoteInfoDTO noteInfoDTO = hbdCommonService.selectLabNoteInfo(reqDTO.getVLabNoteCd());
		int nVersion = 1;

		if(noteInfoDTO != null) {
			IngredientReqDTO ingrDto = new IngredientReqDTO();
			ingrDto.setVLabNoteCd(noteInfoDTO.getVLabNoteCd());
			if(StringUtils.isNotEmpty(String.valueOf(reqDTO.getNVersion())) && reqDTO.getNVersion() != 0){
				nVersion = reqDTO.getNVersion();
			}else {
				nVersion = noteInfoDTO.getNMaxVersion();
			}

			ingrDto.setNVersion(nVersion);
			ingrDto.setLocalLanguage(sessionUtil.getLocalLanguage());
			contList = hbdCommonService.selectLabContList(ingrDto);
			int contListSize = contList == null ? 0 : contList.size();

			if(contListSize > 0) {
				if(StringUtils.isEmpty(reqDTO.getVContPkCd())) {
					for(IngredientContVO contVo : contList) {
						if("Y".equals(contVo.getVFlagRepresent())) {
							reqDTO.setVContPkCd(contVo.getVContPkCd());
							break;
						}
					}
				}

				//vPlantCd
				basicInfo.setVPlantCd(contList.get(0).getVPlantCd());

				//스킨케어일때만 ELAB_QMS_LOT_INFO 테이블에서 해당 내용물에 해당하는 정보 가져오기
				String[] qmsContList = new String[contListSize];
				for(int i = 0; i < contListSize; i++) {
					IngredientContVO contVo = contList.get(i);
					qmsContList[i] = contVo.getVContCd();
				}

				ElabContQmsReqVO qmsReqDTO = ElabContQmsReqVO.builder()
							.vQmsPlantCd(contList.get(0).getVPlantCd())
							.arrQmsContCd(qmsContList)
							.build();

				List<ElabContQmsVO> qmsLotInfoList = labNoteCommonService.selectElabQmsLotInfo(qmsReqDTO);
				resDTO.setQmsLotInfoList(qmsLotInfoList);

				//qmsLotInfoList값이 있을 경우, 필수값으로 지정. 없을경우 필수값 해제
				String vFlagQmsLotCheck = qmsLotInfoList.size() > 0 ? "Y" : "N";
				basicInfo.setVFlagQmsLotCheck(vFlagQmsLotCheck);
			}

			List<LabNoteMstVersionDTO> verList = hbdCommonService.selectLabNoteMstVerList(reqDTO.getVLabNoteCd());
			int verSize = verList ==null ? 0 : verList.size();
			if(verSize > 0) {
				nVersion = verList.get(verSize - 1).getNVersion();
			}

			//탭 클릭하여 version 바꿨을 때
			if(StringUtils.isNotEmpty(String.valueOf(reqDTO.getNVersion())) && reqDTO.getNVersion() != 0){
				nVersion = reqDTO.getNVersion();
			}

			basicInfo.setNVersion(nVersion);
			basicInfo.setVLabNoteCd(reqDTO.getVLabNoteCd());
			basicInfo.setVContPkCd(reqDTO.getVContPkCd());

			resDTO.setContList(contList);		// 내용물 코드
			resDTO.setVerList(verList);			// 버전리스트

			List<LabNoteProcessFuncMateResDTO> mateList = hbdProcessMapper.selectLabNoteFuncMateList(reqDTO.getVLabNoteCd(), nVersion, reqDTO.getVContPkCd());
			resDTO.setMateList(mateList);	// 기능성 원료

			LabNoteVersionDTO verVo = hbdCommonService.selectLabNoteMstVerInfo(reqDTO.getVLabNoteCd(), nVersion);
			resDTO.setVerVo(verVo);		// 버전 정보

//			MusoguReqDTO musoguDTO = MusoguReqDTO.builder()
//					.vLabNoteCd(reqDTO.getVLabNoteCd())
//					.language(sessionUtil.getLangCd())
//					.vTempTag1Cd("EV_MATERIAL_FUNC2")
//					.vGetListType(getListType)
//					.build();
			List<LabNoteCommonTagDTO> funcList = this.selectLabNoteMstVerTagList("EV_MATERIAL_FUNC2", reqDTO.getVLabNoteCd(), nVersion);
			resDTO.setFuncList(funcList);		// 기능성 분류 (미백,주름개선 등등)

			MusoguReqDTO releaseDTO = MusoguReqDTO.builder()
					.vLabNoteCd(reqDTO.getVLabNoteCd())
					.language(sessionUtil.getLangCd())
					.vTempTag1Cd("LNC02")
					.vGetListType(getListType)
					.build();
			List<MusoguTagVO> releaseDtList = hbdCommonService.selectLabNoteTagList(releaseDTO);
			resDTO.setReleaseDt(releaseDtList);		// 출시지역/시기

			Map<String, List<CodeDTO>> makerList = null;
			makerList = commonService.selectCodeListMap(List.of("LAB_NOTE_PLANT"));
			List<CodeDTO> codeList = makerList.get("LAB_NOTE_PLANT").stream()
					.filter(o -> "Y".equals(o.getVContent1()))
					.collect(Collectors.toList());
			makerList.put("LAB_NOTE_PLANT", codeList);
			resDTO.setMakerList(makerList);			// 제조원

			resDTO.setRvo(noteInfoDTO);		//실험노트 기본 정보
			resDTO.setBasicInfo(basicInfo);
		}

		responseVO.setOk(resDTO);
		return responseVO;
	}

	private List<LabNoteCommonTagDTO> selectLabNoteMstVerTagList(String tag1Cd, String vLabNoteCd, int nVersion) {
		return hbdProcessMapper.selectLabNoteMstVerTagList(tag1Cd, vLabNoteCd, nVersion, sessionUtil.getLocalLanguage());
	}

	public ResponseVO selectLabNoteMixCheckList(String vLotCd) {
		ResponseVO responseVO = new ResponseVO();

		List<LabNoteProcessMateMixCheckDTO> list = hbdProcessMapper.selectLabNoteMixCheckList(vLotCd);
		int size = list == null ? 0 : list.size();
		if(size == 0) {
			responseVO.setOkWithCode("C9999", "해당 내용물 코드 LOT의 원료 배합이 존재하지 않습니다.", null);
			return responseVO;
		}

		StringBuffer str = new StringBuffer();
		boolean isChk = false;
		if(size > 0) {
			for(LabNoteProcessMateMixCheckDTO rvo : list) {
				double sum = rvo.getNRateSum();
				if(sum < 100) {
					isChk = true;
					str.append("\n").append("내용물 코드 : "+rvo.getVContCd()+"["+ rvo.getVLotNm()+"]"+" 의 햠랑이 100이 되지 않습니다.");
				}
			}
		}

		if(isChk) {
			responseVO.setOkWithCode("C9999", str.toString(), null);
		}else {
			responseVO.setOk(null);
		}

		return responseVO;
	}

	public ResponseVO selectGroupUserList(LabNoteProcessFuncReportUserReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		String vNoteType = reqDTO.getVNoteType();
		String groupId = "";

		if(StringUtils.isEmpty(vNoteType)) {
			responseVO.setOkWithCode("C9999", "필수 인자값이 없습니다", null);
			return responseVO;
		}

		switch(vNoteType) {
			case "SC" : groupId = "S000273";	break;
			case "MU" : groupId = "S000274";	break;
			case "MC" : groupId = "S000275";	break;
			default : groupId = "S000277";	break;
		}
		reqDTO.setVGroupId(groupId);
		List<CommUserDesSearchInfoDTO> userList = labNoteCommonService.selectGroupUserRetireList(reqDTO);

		LabNoteProcessFuncReportUserResDTO resDTO = LabNoteProcessFuncReportUserResDTO.builder()
				.vNoteType(vNoteType)
				.vGroupId(groupId)
				.vChargeUserId(reqDTO.getVChargeUserId())
				.vChargeUserNm(reqDTO.getVChargeUserNm())
				.userList(userList)
				.build();

		responseVO.setOk(resDTO);
		return responseVO;
	}

	public ResponseVO saveLabNoteSendFuncMail(@Valid LabNoteProcessFuncReportReqSaveDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		if(StringUtils.isEmpty(reqDTO.getVNoteType())
				||StringUtils.isEmpty(reqDTO.getVLabNoteCd())
				||StringUtils.isEmpty(String.valueOf(reqDTO.getNVersion()))
				) {
			responseVO.setOkWithCode("C9999", "필수 인자값이 없습니다", null);
			return responseVO;
		}

		this.insertLabNoteFuncRequestQA(reqDTO);

		String getListType = "CHOOSE";

		HbdNoteInfoDTO rvo = hbdCommonService.selectLabNoteInfo(reqDTO.getVLabNoteCd());
		LabNoteVersionDTO verVo = hbdCommonService.selectLabNoteMstVerInfo(reqDTO.getVLabNoteCd(), reqDTO.getNVersion());

		LabNoteProcessFuncReportReqPopDTO tempVo = LabNoteProcessFuncReportReqPopDTO.builder()
				.vLabNoteCd(reqDTO.getVLabNoteCd())
				.nVersion(reqDTO.getNVersion())
				.nSeqno(reqDTO.getNSeqno())
				.build();
		LabNoteProcessFuncReportResPopDTO funcReqVo = hbdProcessMapper.selectLabNoteFuncRequestQA(tempVo);

		List<LabNoteProcessFuncMateResDTO> mateList = hbdProcessMapper.selectLabNoteFuncMateList(reqDTO.getVLabNoteCd(), reqDTO.getNVersion(), "");

		List<LabNoteCommonTagDTO> funcList = this.selectLabNoteMstVerTagList("EV_MATERIAL_FUNC2", reqDTO.getVLabNoteCd(), reqDTO.getNVersion());

		MusoguReqDTO releaseDTO = MusoguReqDTO.builder()
				.vLabNoteCd(reqDTO.getVLabNoteCd())
				.language(sessionUtil.getLangCd())
				.vTempTag1Cd("LNC02")
				.vGetListType(getListType)
				.build();
		List<MusoguTagVO> releaseDt = hbdCommonService.selectLabNoteTagList(releaseDTO);

		if("SC".equals(reqDTO.getVNoteType())) {
			reqDTO.setVQmsPlantCd(rvo.getVPlantCd());
			this.insertLabNoteContQmsInfo(reqDTO);
		}

		if(StringUtils.isEmpty(verVo.getVRefTypeCd())) {
			responseVO.setOkWithCode("C9999", "등록된 기능성이 없습니다.", null);
			return responseVO;
		}

		if(mateList.isEmpty()) {
			responseVO.setOkWithCode("C9999", "등록된 기능성 원료가 없습니다.", null);
			return responseVO;
		}

		//시험성적서 요청 엑셀 파일 만들기
		List<UploadDTO> funcExcelUploadList   = this.labNoteFuncExcel(reqDTO, rvo, verVo, funcReqVo, mateList, funcList, releaseDt);
		int excelFileCnt = funcExcelUploadList == null ? 0 : funcExcelUploadList.size();

		String target_cd = reqDTO.getVLabNoteCd() + "_"+ reqDTO.getNVersion() + "_" + reqDTO.getNSeqno();
		List<UploadDTO> reportReqUploadList = commonService.selectCommAttachList(target_cd, "NOTETAB08");
		int uploadFileCnt = reportReqUploadList == null ? 0 : reportReqUploadList.size();

		int len = uploadFileCnt  + excelFileCnt;

		String[] fileName = new String[len];
		String[] filePath = new String[len];
		String WEB_URL				= PropertyUtil.getProperty("bkr.web.url");

		if(uploadFileCnt > 0) {
			for(int i = 0; i < uploadFileCnt; i++) {
				String vAttachid = reportReqUploadList.get(i).getVAttachid();
				String path = WEB_URL  + "/api/file/mail-download?vAttachid=" + vAttachid;

				fileName[i] = reportReqUploadList.get(i).getVAttachnm();
				filePath[i] = path;
			}
		}

		if(excelFileCnt > 0) {
			for(int i = 0; i< excelFileCnt; i++) {
				String vAttachid = funcExcelUploadList.get(i).getVAttachid();
				String path = WEB_URL + "api/file/mail-download?vAttachid=" + vAttachid;

				fileName[uploadFileCnt + i] = funcExcelUploadList.get(i).getVAttachnm();
				filePath[uploadFileCnt + i] = path;
			}
		}

		//메일 발송
		this.sendFuncRequestMail(reqDTO, rvo, verVo, funcReqVo, mateList, funcList, releaseDt, fileName, filePath);

		//AL_NOTE0_05 기능성 보고 의뢰
		commonService.sendAlarm(AlarmRegDTO.builder()
				.vLabNoteCd(rvo.getVLabNoteCd())
				.vStatusCd("AL_NOTE0")
				.vAlrTypeCd("AL_NOTE0_05")
				.typeList(Arrays.asList(Const.TIMELINE, Const.MAIL))
				.vFlagMail("Y")
				.vContCd(rvo.getVContCd())
				.vContNm(rvo.getVContNm())
				.nVerNo((reqDTO.getNVersion() < 10 ? "0" : "") + String.valueOf(reqDTO.getNVersion()))
				.nSeqno(String.valueOf(reqDTO.getNSeqno()))
				.vNoteType("HBO")
				.build());

		responseVO.setOk(null);
		return responseVO;
	}

	private void sendFuncRequestMail(@Valid LabNoteProcessFuncReportReqSaveDTO saveReqDTO, HbdNoteInfoDTO rvo,
			LabNoteVersionDTO verVo, LabNoteProcessFuncReportResPopDTO funcReqVo,
			List<LabNoteProcessFuncMateResDTO> mateList, List<LabNoteCommonTagDTO> funcList,
			List<MusoguTagVO> releaseDt, String[] fileName, String[] filePath) {

		LabNoteProcessFuncReportReqPopDTO reqDTO = LabNoteProcessFuncReportReqPopDTO.builder()
				.vNoteType(saveReqDTO.getVNoteType())
				.vLabNoteCd(saveReqDTO.getVLabNoteCd())
				.nVersion(saveReqDTO.getNVersion())
				.build();

		LabNoteProcessFuncReportDataDTO fvo = this.selectFuncData(reqDTO, rvo, verVo, funcReqVo, mateList, funcList, releaseDt);
		String mailTitle = "[기능성 검사 첨부 파일 요청] (" + fvo.getVContCd()  + ")" + fvo.getVContNm();

		MailForm mailForm = new MailForm();
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("fvo", fvo);
		params.put("filePath", filePath);
		params.put("fileName", fileName);
		String mailContent = mailForm.getMailContentFromObject(MailDTO.MAIL_REQUEST_FUNC_TEST, params);

		List<String> list = labNoteCommonService.selectLabNoteFuncQaUserList(saveReqDTO);
		int listSize = list == null ? 0 : list.size();
		//메일 보낼 사람이 존재하지 않으면
		//메일 전송하지 않음
		if(listSize > 0) {
			StringBuffer toEmail = new StringBuffer();
			String[] arrUserId = new String[listSize];
			for(int i = 0; i < listSize; i++) {
				arrUserId[i] = list.get(i);
				SupGlobalMailUserVO userEmail =  labNoteCommonService.selectUserEmail(arrUserId[i]);
				toEmail.append(userEmail.getVEmail());
				if(i < listSize - 1) {
					toEmail.append(",");
				}
			}

			MailUtil.send(toEmail.toString(), null, mailTitle, mailContent, fileName, filePath);
		}

		//스킨케어일때, SEND_QMS_TEST_REP_REQ_IF 테이블에 해당하는 정보 INSERT => HBD 에서는 로직 삭제

	}

	private void insertLabNoteContQmsInfo(@Valid LabNoteProcessFuncReportReqSaveDTO reqDTO) {
		String [] arrContCd = reqDTO.getArrContCd();
		String [] arrQmsInfo = reqDTO.getArrQmsLotInfo();
		String [] arrContNm = reqDTO.getArrQmsContNm();

		int len = arrContCd == null ? 0 : arrContCd.length;
		if(len > 0) {
			for(int i = 0; i < len; i++) {
				reqDTO.setVContCd(arrContCd[i]);
				reqDTO.setVContNm(arrContNm[i]);
				if(StringUtils.isNotEmpty(arrQmsInfo[i])) {
					String [] splitStr = arrQmsInfo[i].split("/");
					reqDTO.setNQmsSeq(StringUtils.isNotEmpty(splitStr[0]) ? Integer.parseInt(splitStr[0]) : null);
					reqDTO.setVQmsDate(StringUtils.isNotEmpty(splitStr[1]) ? splitStr[1] : "");
					reqDTO.setVQmsLot(StringUtils.isNotEmpty(splitStr[2]) ? splitStr[2] : "");
				}
				hbdProcessMapper.insertLabNoteContQmsInfo(reqDTO);
			}
		}
	}

	private void insertLabNoteFuncRequestQA(@Valid LabNoteProcessFuncReportReqSaveDTO reqDTO) {
		HbdNoteInfoDTO rvo = hbdCommonService.selectLabNoteInfo(reqDTO.getVLabNoteCd());
		LabNoteVersionDTO verVo = hbdCommonService.selectLabNoteMstVerInfo(reqDTO.getVLabNoteCd(), reqDTO.getNVersion());

		String title = "";
		String refTypeCd = verVo.getVRefTypeCd();
		if(refTypeCd.equals("LNC05_02")) {
			title = "[기능성 보고의뢰] ";
		}else if(refTypeCd.equals("LNC05_03")) {
			title = "[기능성 신규의뢰] ";
		}else if(refTypeCd.equals("LNC05_04")){
			title = "[기능성 변경의뢰] ";
		}

		reqDTO.setVTitle(title + "(" + rvo.getVContCd()  +")" + rvo.getVContNm());
		reqDTO.setVSenderId(sessionUtil.getLoginId());
		reqDTO.setVRegUserid(sessionUtil.getLoginId());
		reqDTO.setVUpdateUserid(sessionUtil.getLoginId());

		hbdProcessMapper.insertLabNoteFuncRequestQA(reqDTO);

		String target_cd = reqDTO.getVLabNoteCd() + "_"+ reqDTO.getNVersion() + "_" + reqDTO.getNSeqno();
		reqDTO.setVRecordid(target_cd);
		commonService.saveCommAttach(reqDTO.getFileList(), reqDTO.getVUploadCd(), reqDTO.getVRecordid());		//시험성적서 요청 시 첨부한 파일 저장

		String [] arrContCd = reqDTO.getArrContCd();
		int len = arrContCd == null ? 0 : arrContCd.length;
		if(len > 0) {
			String [] arrLotCd = reqDTO.getArrLotCd();
			for(int i = 0; i < len; i++) {
				reqDTO.setVContCd(arrContCd[i]);
				reqDTO.setVLotCd((arrLotCd[i] != null ? arrLotCd[i] : ""));
				labNoteCommonService.insertRequestQaCont(reqDTO);
			}
		}

		String[] arrUserId = reqDTO.getArrQaUserId();
		len = arrUserId == null ? 0 : arrUserId.length;
		String userId = "";

		if(len > 0) {
			for(int i = 0; i < len; i++) {
				userId = arrUserId[i];
				reqDTO.setVUserId(userId);
				labNoteCommonService.insertLabNoteFuncQaUser(reqDTO);
			}
		}
	}

	private List<UploadDTO> labNoteFuncExcel(@Valid LabNoteProcessFuncReportReqSaveDTO reqDTO, HbdNoteInfoDTO rvo,
			LabNoteVersionDTO verVo, LabNoteProcessFuncReportResPopDTO funcReqVo,
			List<LabNoteProcessFuncMateResDTO> mateList, List<LabNoteCommonTagDTO> funcList,
			List<MusoguTagVO> releaseDtList) {

		String excelFileName = "";
		List<UploadDTO> uploadSuccList = null;

		try {
			int mateListSize = mateList == null ? 0 : mateList.size();
			int funcListSize = funcList == null ? 0 : funcList.size();
			int releaseDtSize = releaseDtList == null ? 0 : releaseDtList.size();

			StringBuilder mateStr = new StringBuilder();
			StringBuilder funcStr = new StringBuilder();
			StringBuilder releaseStr = new StringBuilder();

			excelFileName = "["+rvo.getVContCd()+"] " + rvo.getVContNm() + "_" + funcReqVo.getNVersion() + "_" + funcReqVo.getNSeqno() + "_시험성적서"+ ".xls";

			if(mateListSize > 0) {
				for(int i = 0; i < mateListSize; i++) {
					LabNoteProcessFuncMateResDTO mateVo = mateList.get(i);
					mateStr.append("[" + mateVo.getVMateCd() + "] ").append(mateVo.getVMateNm()).append("(" +mateVo.getNReqRate() + "%)");
					if(i != mateListSize) {
						mateStr.append("\n");
					}
				}
			}

			if(funcListSize > 0) {
				for(int i = 0; i < funcListSize; i++) {
					LabNoteCommonTagDTO funcVo = funcList.get(i);
					if(i != 0) {
						funcStr.append(", ");
					}
					funcStr.append(funcVo.getVSubCodenm());
				}
			}

			if(releaseDtSize > 0) {
				for(int i = 0; i < releaseDtSize; i++) {
					MusoguTagVO releaseVo = releaseDtList.get(i);
					releaseStr.append(releaseVo.getVSubCodenm() + "(" + CommonUtil.getPointDate(releaseVo.getVTag1Cd()) + ") ");	//getVTag1Cd : v_release_dt

					if(releaseVo.getVSubCode().equals("LNC02_04")) {
						releaseStr.append("(" + releaseVo.getVTag2Cd() + ")");	//getVTag2Cd : v_release_note
					}
				}
			}

			String[] columnNmArray = new String[]{
					"시료명",
					"주성분 및 표시량",
					"제형",
					"기능성 분류",
					"근거품목",
					"에탄올 4% 초과여부",
					"파일럿 일자",
					"출시 예정일"};

			String refTxt  = verVo.getVRefTypeCd().equals("LNC05_02") ?
						(StringUtils.isNotEmpty(verVo.getVEvaluateGosiCd()) ? verVo.getVEvaluateno() + "/" + verVo.getVEvaluateGosiNm() : verVo.getVEvaluateGosiNo())
						: verVo.getVRefNote();

			String[] columnValArray = new String[] {
					rvo.getVContNm(),
					mateStr.toString(),
					verVo.getVShape(),
					verVo.getVRefTypeNm(),
					refTxt,
					funcReqVo.getVFlagOverEthanolNm(),
					CommonUtil.getPointDate(rvo.getVPilotDt()),
					releaseStr.toString()
			};

			int[] columWidth = new int[]{5,50,75,75};
			int columNmLen = columnNmArray.length;
			int columWidthLen = columWidth.length;

			HSSFWorkbook wb = new HSSFWorkbook();
			HSSFCellStyle cs;
			HSSFSheet sheet;
			HSSFRow row;
			HSSFCell cell;
			HSSFFont font;
			CreationHelper ch;
			RichTextString str;

			Map<String, CellStyle> styleMap = CommonUtil.createStyles(wb);
			HSSFFont defaultFont = wb.createFont();
			defaultFont.setFontName("맑은 고딕");
			defaultFont.setFontHeightInPoints((short) 9);

			sheet = wb.createSheet("QA시험성적서 발급");

			for(int i=0; i<columWidthLen; i++){
				sheet.setColumnWidth(i, columWidth[i]*256);
			}

			row = sheet.createRow(0);
			cell = row.createCell(1);
			cell.setCellValue("시험 성적서");
			sheet.addMergedRegion(new CellRangeAddress(0, 0, 1, 4));

			font = wb.createFont();
			font.setFontName("맑은 고딕");
			font.setFontHeightInPoints((short) 18);
			font.setBoldweight((short)Font.BOLD);
			font.setUnderline(HSSFFont.U_SINGLE);

			cs = wb.createCellStyle();
			cs.setFont(font);
			cs.setAlignment(CellStyle.ALIGN_CENTER);
			cs.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
			cell.setCellStyle(cs);

			row = sheet.createRow(1);
			cell = row.createCell(1);
			cell.setCellValue("1. 관리 번호 : " + rvo.getVContCd() + "_" +
														funcReqVo.getNVersion() + "_" +
														funcReqVo.getNSeqno());
			sheet.addMergedRegion(new CellRangeAddress(1, 1, 1, 4));

			cs = wb.createCellStyle();
			cs.setFont(defaultFont);
			cs.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
			cs.setFillPattern(CellStyle.SOLID_FOREGROUND);
			cell.setCellStyle(cs);

			row = sheet.createRow(2);
			cell = row.createCell(1);
			cell.setCellValue("2. 발행일 : ");
			sheet.addMergedRegion(new CellRangeAddress(2, 2, 1, 4));

			cs = wb.createCellStyle();
			cs.setFont(defaultFont);
			cs.setFillForegroundColor(IndexedColors.LEMON_CHIFFON.getIndex());
			cs.setFillPattern(CellStyle.SOLID_FOREGROUND);
			cell.setCellStyle(cs);

			row = sheet.createRow(3);
			cell = row.createCell(1);
			cell.setCellValue("3. 시험일 : ");
			sheet.addMergedRegion(new CellRangeAddress(3, 3, 1, 4));

			cs = wb.createCellStyle();
			cs.setFont(defaultFont);
			cs.setFillForegroundColor(IndexedColors.LEMON_CHIFFON.getIndex());
			cs.setFillPattern(CellStyle.SOLID_FOREGROUND);
			cell.setCellStyle(cs);

			row = sheet.createRow(4);
			cell = row.createCell(1);
			cell.setCellValue("4. 의뢰자 : " + sessionUtil.getUserNm());
			sheet.addMergedRegion(new CellRangeAddress(4, 4, 1, 4));

			cs = wb.createCellStyle();
			cs.setFont(defaultFont);
			cs.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
			cs.setFillPattern(CellStyle.SOLID_FOREGROUND);
			cell.setCellStyle(cs);

			row = sheet.createRow(5);
			cell = row.createCell(1);
			cell.setCellValue("5. 시험자 : " + rvo.getVUsernm());
			sheet.addMergedRegion(new CellRangeAddress(5, 5, 1, 4));

			cs = wb.createCellStyle();
			cs.setFont(defaultFont);
			cs.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
			cs.setFillPattern(CellStyle.SOLID_FOREGROUND);
			cell.setCellStyle(cs);

			row = sheet.createRow(6);
			cell = row.createCell(1);
			cell.setCellValue("6. 시료내용 : (내용물 코드 : " + rvo.getVContCd() + ")");
			sheet.addMergedRegion(new CellRangeAddress(6, 6, 1, 4));

			cs = wb.createCellStyle();
			cs.setFont(defaultFont);
			cs.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
			cs.setFillPattern(CellStyle.SOLID_FOREGROUND);
			cell.setCellStyle(cs);

			for(int i=0; i<columNmLen; i++){
				row = sheet.createRow(i+7);

				if(i == 1){
					if (funcListSize > 0){
						row.setHeightInPoints(50 * funcListSize);
					}
				}

				cell = row.createCell(1);
				cell.setCellValue(columnNmArray[i]);
				cell.setCellStyle(styleMap.get("default"));

				cell = row.createCell(2);
				cell.setCellValue(columnValArray[i]);
				cell.setCellStyle(styleMap.get("default"));

				cell = row.createCell(3);
				cell.setCellStyle(styleMap.get("default"));

				cell = row.createCell(4);
				cell.setCellStyle(styleMap.get("default"));

				sheet.addMergedRegion(new CellRangeAddress(i+7, i+7, 2, 4));
			}

			row = sheet.createRow(16);
			cell = row.createCell(1);
			cell.setCellValue("7. 기능성 주성분의 확인시험 및 함량시험 결과 ");

			cs = wb.createCellStyle();
			cs.setFont(defaultFont);
			cell.setCellStyle(cs);

			row = sheet.createRow(17);
			cell = row.createCell(1);
			cell.setCellValue("1)확인시험");

			cs = wb.createCellStyle();
			cs.setFont(defaultFont);
			cell.setCellStyle(cs);

			row = sheet.createRow(18);
			cell = row.createCell(1);
			cell.setCellValue("시험항목");
			cell.setCellStyle(styleMap.get("default_bold_c"));
			cell = row.createCell(2);
			cell.setCellValue("규 격 (기준 및 시험방법)");
			cell.setCellStyle(styleMap.get("default_bold_c"));
			cell = row.createCell(3);
			cell.setCellValue("결 과");
			cell.setCellStyle(styleMap.get("default_bold_c"));

			for(int i=0; i<mateListSize; i++){
				LabNoteProcessFuncMateResDTO mateVo = mateList.get(i);

				row = sheet.createRow(i + 19);
				cell = row.createCell(1);
				cell.setCellValue(mateVo.getVMateNm());
				cell.setCellStyle(styleMap.get("default"));
				cell = row.createCell(2);
				cell.setCellStyle(styleMap.get("default"));
				cell = row.createCell(3);
				cell.setCellStyle(styleMap.get("default"));
			}

			row = sheet.createRow(19 + mateListSize);
			cell = row.createCell(1);
			cell.setCellValue("2)함량시험");

			cs = wb.createCellStyle();
			cs.setFont(defaultFont);
			cell.setCellStyle(cs);

			row = sheet.createRow(20 + mateListSize);
			cell = row.createCell(1);
			cell.setCellValue("시험항목");
			cell.setCellStyle(styleMap.get("default_bold_c"));
			cell = row.createCell(2);
			cell.setCellValue("함량 (%)");
			cell.setCellStyle(styleMap.get("default_bold_c"));
			cell = row.createCell(3);
			cell.setCellValue("표시량에 대해 (%)");
			cell.setCellStyle(styleMap.get("default_bold_c"));

			for(int i=0; i<mateListSize; i++){
				LabNoteProcessFuncMateResDTO mateVo = mateList.get(i);

				row = sheet.createRow(i + 21 + mateListSize);
				cell = row.createCell(1);
				cell.setCellValue(mateVo.getVMateNm() + " : " + mateVo.getNReqRate() + "%");
				cell.setCellStyle(styleMap.get("default"));
				cell = row.createCell(2);
				cell.setCellStyle(styleMap.get("default"));
				cell = row.createCell(3);
				cell.setCellStyle(styleMap.get("default"));
			}

			row = sheet.createRow(21 + 2*mateListSize);
			cell = row.createCell(1);
			cell.setCellValue("3)pH");

			cs = wb.createCellStyle();
			cs.setFont(defaultFont);
			cell.setCellStyle(cs);

			row = sheet.createRow(22 + 2*mateListSize);
			cell = row.createCell(1);
			cell.setCellValue("시험항목");
			cell.setCellStyle(styleMap.get("default_bold_c"));
			cell = row.createCell(2);
			cell.setCellValue("규 격 (기준 및 시험방법)");
			cell.setCellStyle(styleMap.get("default_bold_c"));
			cell = row.createCell(3);
			cell.setCellValue("결 과");
			cell.setCellStyle(styleMap.get("default_bold_c"));

			row = sheet.createRow(23 + 2*mateListSize);
			cell = row.createCell(1);
			cell.setCellValue("pH");
			cell.setCellStyle(styleMap.get("default"));
			cell = row.createCell(2);
			cell.setCellValue(funcReqVo.getVPh());
			cell.setCellStyle(styleMap.get("default"));
			cell = row.createCell(3);
			cell.setCellStyle(styleMap.get("default"));

			row = sheet.createRow(24 + 2*mateListSize);
			font = wb.createFont();
			font.setColor(IndexedColors.RED.getIndex());

			ch = wb.getCreationHelper();
			str = ch.createRichTextString("4)적합성 표준시료와의 비교시험(단, TiO2, ZnO 한하여 해당)");
			str.applyFont(17, 38, font);

			cell = row.createCell(1);
			cell.setCellValue(str);

			cs = wb.createCellStyle();
			cs.setFont(defaultFont);
			cell.setCellStyle(cs);

			row = sheet.createRow(25 + 2*mateListSize);
			cell = row.createCell(1);
			cell.setCellValue("성분");
			cell.setCellStyle(styleMap.get("default_bold_c"));
			cell = row.createCell(2);
			cell.setCellValue("규 격 (기준 및 시험방법)");
			cell.setCellStyle(styleMap.get("default_bold_c"));
			cell = row.createCell(3);
			cell.setCellValue("결 과");
			cell.setCellStyle(styleMap.get("default_bold_c"));

			row = sheet.createRow(26 + 2*mateListSize);
			cell = row.createCell(1);
			cell.setCellValue("티타늄디옥사이드");
			cell.setCellStyle(styleMap.get("default"));
			cell = row.createCell(2);
			cell.setCellValue("검체시료에서 측정되는 크롬, 망간, 철, 코발트, 구리, 니켈 및 징크의 에너지 세기가 적합성 표준시료의 값을 초과하지 않음");
			cell.setCellStyle(styleMap.get("default"));
			cell = row.createCell(3);
			cell.setCellStyle(styleMap.get("default"));

			row = sheet.createRow(27 + 2*mateListSize);
			cell = row.createCell(1);
			cell.setCellValue("징크옥사이드");
			cell.setCellStyle(styleMap.get("default"));
			cell = row.createCell(2);
			cell.setCellValue("검체시료에서 측정되는 크롬, 망간, 철, 코발트, 니켈 및 구리의 에너지 세기가 적합성 표준시료의 값을 초과하지 않음");
			cell.setCellStyle(styleMap.get("default"));
			cell = row.createCell(3);
			cell.setCellStyle(styleMap.get("default"));

			row = sheet.createRow(29 + 2*mateListSize);

			font = wb.createFont();
			font.setColor(IndexedColors.RED.getIndex());

			ch = wb.getCreationHelper();
			str = ch.createRichTextString("8. 판정의견 : 합 격 / 불합격");
			str.applyFont(10, 19, font);

			cell = row.createCell(1);
			cell.setCellValue(str);
			sheet.addMergedRegion(new CellRangeAddress(29 + 2*mateListSize, 29 + 2*mateListSize, 1, 2));

			cs = wb.createCellStyle();
			cs.setFont(defaultFont);
			cs.setFillForegroundColor(IndexedColors.LEMON_CHIFFON.getIndex());
			cs.setFillPattern(CellStyle.SOLID_FOREGROUND);
			cell.setCellStyle(cs);

			// 파일명에 들어갈 수 없는 특수문자를 제거합니다.
			excelFileName = CommonUtil.convertFileName(excelFileName);

			ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
            wb.write(outByteStream);
            byte [] bytes = outByteStream.toByteArray();

			UploadTempDTO tempDTO = UploadTempDTO.builder()
					.vAttachnm(excelFileName)
					.vAttachExt(excelFileName.indexOf(".") > -1 ? excelFileName.substring(excelFileName.lastIndexOf(".")) : "")
					.nAttachSize(bytes.length)
					.vFileBytea(bytes)
					.vRegUserid(sessionUtil.getLoginId())
					.vUpdateUserid(sessionUtil.getLoginId())
					.vUploadid("FUNC_QA_REQ")
					.build();

			commonService.insertCommAttachTemp(tempDTO);

			List<UploadTempDTO> list = new ArrayList<UploadTempDTO>();
			list.add(tempDTO);

			reqDTO.setVRecordid(reqDTO.getVLabNoteCd() + "_" + reqDTO.getNVersion() + "_" + reqDTO.getNSeqno());		//recordid : 실험노트번호_버전_시퀀스
			int result = commonService.saveCommAttach(list, "FUNC_QA_REQ", reqDTO.getVRecordid());
			if(result > 0) {
				uploadSuccList = commonService.selectCommAttachList(reqDTO.getVRecordid(), "FUNC_QA_REQ");
			}

		}catch(Exception e) {
			log.error("HbdProcessService.labNoteFuncExcel : {}" + e);
		}
		return uploadSuccList;
	}

	public ResponseVO updateNoteRefNote(@Valid LabNoteProcessFuncReportReqSaveDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		if(StringUtils.isEmpty(reqDTO.getVNoteType())
				||StringUtils.isEmpty(reqDTO.getVLabNoteCd())
				||StringUtils.isEmpty(String.valueOf(reqDTO.getNVersion()))
				) {
			responseVO.setOkWithCode("C9999", "필수 인자값이 없습니다", null);
			return responseVO;
		}

		int recordCnt = hbdProcessMapper.updateNoteRefNote(reqDTO);

		if(recordCnt > 0) {
			responseVO.setOk(null);
		}else {
			responseVO.setOkWithCode("C9999", "작업중 오류가 발생하였습니다.", null);
		}
		return responseVO;
	}

	public ResponseVO selectLabNoteContDecideList(LabNoteProcessContDecideReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		HbdNoteInfoDTO rvo = hbdCommonService.selectLabNoteInfo(reqDTO.getVLabNoteCd());
		List<LabNoteMstVersionDTO> verList = hbdCommonService.selectLabNoteMstVerList(reqDTO.getVLabNoteCd());

		reqDTO.setLocalLanguage(sessionUtil.getLangCd());
		if( !(StringUtils.isNotEmpty(String.valueOf(reqDTO.getNVersion())) && reqDTO.getNVersion() != 0) ){
			reqDTO.setNVersion(rvo.getNMaxVersion());
		}

		List<LabNoteProcessContDecideListDTO> contList = hbdProcessMapper.selectLabNoteContDecideList(reqDTO);

		LabNoteProcessContDecideResDTO<HbdNoteInfoDTO> resDTO = LabNoteProcessContDecideResDTO.<HbdNoteInfoDTO>builder()
				.rvo(rvo)
				.verList(verList)
				.contList(contList)
				.build();

		responseVO.setOk(resDTO);
		return responseVO;
	}

	public ResponseVO selectLabNoteGate2Reg(LabNoteProcessContDecideReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		LabNoteTestRequestProductResDTO<HbdNoteInfoDTO> resDTO = new LabNoteTestRequestProductResDTO<HbdNoteInfoDTO>();

		HbdNoteInfoDTO noteVo = hbdCommonService.selectLabNoteInfo(reqDTO.getVLabNoteCd());
		resDTO.setRvo(noteVo);

		//PQC GATE2
		LabNoteMstVersionPqcDTO verVo = hbdCommonService.selectLabNoteMstVerPqcInfo(reqDTO.getVLabNoteCd(), reqDTO.getNVersion());

		// 시험의뢰 목록
		LabNoteTestRequestProductReqDTO trDTO = LabNoteTestRequestProductReqDTO.builder()
				.vFlagExcelAll("Y")
				.localLanguage(sessionUtil.getLangCd())
				.vLabNoteCd(reqDTO.getVLabNoteCd())
				.build();

		List<LabNoteTestRequestProductDTO> trGate1List = new ArrayList<LabNoteTestRequestProductDTO>();
		List<LabNoteTestRequestProductDTO> trList = hbdCommonService.selectLabNoteTrProductList(trDTO);
		int trSize = trList == null ? 0 : trList.size();
		String key;

		if(trSize > 0) {
			Map<String, List<LabNoteTestRequestProductDTO>> trMap = new HashMap<String, List<LabNoteTestRequestProductDTO>>();
			List<LabNoteTestRequestProductDTO> subList = null;

			for(LabNoteTestRequestProductDTO tvo : trList) {

				key = tvo.getVLabMrqTypeCd();
				if(StringUtils.isNotEmpty(tvo.getVLabGateCd()) && tvo.getVLabGateCd().equals("GATE_1")) {
					trGate1List.add(tvo);
					continue;
				}

				subList = trMap.get(key);

				if(subList == null) {
					subList = new ArrayList<LabNoteTestRequestProductDTO>();
					trMap.put(key, subList);
				}

				subList.add(tvo);

			}
			resDTO.setTrMap(trMap);
		}

		resDTO.setVPqcGateCd("GATE_2");
		resDTO.setTrGate1List(trGate1List);

		LabNotePqcGateCheckReqDTO checkDTO = LabNotePqcGateCheckReqDTO.builder()
				.vNoteType(reqDTO.getVNoteType())
				.vLabNoteCd(reqDTO.getVLabNoteCd())
				.nVersion(reqDTO.getNVersion())
				.arrLotCd(reqDTO.getArrLotCd())
				.vPqcGateCd("GATE_2")
				.vPqcGate1ResCd(reqDTO.getVPqcGate1ResCd())
				.build();
		List<LabNotePqcGateCheckListDTO> pqcCheckList = this.selectPqcGateCheckList(checkDTO, noteVo, verVo, "REG");
		//~ PQC GATE2

		resDTO.setPqcList(pqcCheckList);

		List<ApprovalDetailDTO> userList = hbdCommonService.selectLabNoteApprovalUserList(checkDTO.getVLabNoteCd(), sessionUtil.getLangCd());

		resDTO.setUserList(userList);

		responseVO.setOk(resDTO);
		return responseVO;
	}

	public ResponseVO selectLabNotePilotList(PilotRequestReqDTO pilotRequestReqDTO) {
		ResponseVO responseVO = new ResponseVO();
		pilotRequestReqDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
		List<PilotRequestDTO> list = null;

		int totalCnt = hbdProcessMapper.selectLabNoteBomReqListCount(pilotRequestReqDTO);
		CommonUtil.setPaging(pilotRequestReqDTO, totalCnt);
		if (totalCnt > 0) {
			list = hbdProcessMapper.selectLabNoteBomReqList(pilotRequestReqDTO);
		}

		PagingDTO page = ConvertUtil.convert(pilotRequestReqDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
									.page(page)
									.list(list)
									.build();
		responseVO.setOk(res);
		return responseVO;
	}

	public ResponseVO selectLabNotePilotReqInfo(PilotRequestDetailReqDTO pilotRequestDetailReqDTO) {
		ResponseVO responseVO = new ResponseVO();

		HbdNoteInfoDTO noteInfo = hbdCommonService.selectLabNoteInfo(pilotRequestDetailReqDTO.getVLabNoteCd());

		List<PilotRequestDTO> lotList = hbdProcessMapper.selectLabNoteApprBomLotList(pilotRequestDetailReqDTO);
		List<PilotRequestMateDTO> bomList = null;
		if (lotList != null && !lotList.isEmpty()) {
			bomList = this.selectLabNoteBomMateRateInfo(pilotRequestDetailReqDTO);
		}

		String flagFreePass = labNoteCommonService.checkFlagFreePass(pilotRequestDetailReqDTO);

		PgcGqteResVO pqcVO = labNoteCommonService.selectPqcGqteResInfo(pilotRequestDetailReqDTO.getVApprCd());
		LabNoteMstVersionPqcDTO versionPqcDTO = hbdCommonService.selectLabNoteMstVerPqcInfo(pilotRequestDetailReqDTO.getVLabNoteCd(), pilotRequestDetailReqDTO.getNVersion());

		List<LabNoteTestRequestProductDTO> trList = hbdCommonService.selectLabNoteTrProductList(LabNoteTestRequestProductReqDTO.builder()
															.vFlagExcelAll("Y")
															.localLanguage(sessionUtil.getLangCd())
															.vLabNoteCd(pilotRequestDetailReqDTO.getVLabNoteCd())
															.build());

		List<LabNoteTestRequestProductDTO> trFinalList = trList != null ? trList.stream().filter(v -> StringUtils.isNotEmpty(v.getVLabMrqTypeCd())).collect(Collectors.toList()) : null;
		Map<String, List<LabNoteTestRequestProductDTO>> trMap = trFinalList == null
															? new HashMap<>()
															: trFinalList.stream().collect(Collectors.groupingBy(LabNoteTestRequestProductDTO::getVLabMrqTypeCd));

		List<BomShelfLifeDTO> shelfLifeList = null;
		if(pqcVO != null && "Y".equals(pqcVO.getVShelflifeYn())) {
			shelfLifeList = hbdProcessMapper.selectLabNoteShelfLifePqcList(pilotRequestDetailReqDTO.getVApprCd());
		}

		List<LabNotePqcGateCheckListDTO> pqcList = null;

		if (pqcVO != null && StringUtils.isNotEmpty(pqcVO.getVPqcResCd())) {
			pqcList = this.selectPqcGateResItemList(pqcVO.getVPqcResCd(), pilotRequestDetailReqDTO.getVLabNoteCd(), versionPqcDTO);
		}

		responseVO.setOk(PilotRequestResDTO.<HbdNoteInfoDTO>builder()
								.noteInfo(noteInfo)
								.lotList(lotList)
								.bomList(bomList)
								.flagFreePass(flagFreePass)
								.pqcVO(pqcVO)
								.versionPqcInfo(versionPqcDTO)
								.trMap(trMap)
								.shelfLifeList(shelfLifeList)
								.pqcList(pqcList)
								.build());
		return responseVO;
	}

	public List<PilotRequestMateDTO> selectLabNoteBomMateRateInfo(PilotRequestDetailReqDTO pilotRequestDetailReqDTO) {
		return hbdProcessMapper.selectLabNoteBomMateRateInfo(pilotRequestDetailReqDTO);
	}

	public List<LabNotePqcGateCheckListDTO> selectPqcGateResItemList(String vPqcResCd, String vLabNoteCd, LabNoteMstVersionPqcDTO verVo) {
		List<LabNotePqcGateCheckListDTO> pqcList = labNoteCommonService.selectPqcGateResItemList(vPqcResCd);

		if (pqcList == null || pqcList.isEmpty()) {
			return null;
		}

		List<LabNotePqcGateCheckListDTO> list = new ArrayList<LabNotePqcGateCheckListDTO>();

		String itemTypeCd, chkText, chkValue, chkBeforeText, chkAfterText;
		String[] arrItemTypeCd = null, arrChkText = null, arrChkValue = null, arrChkBeforeText = null, arrChkAfterText = null;
		int chkLen = 0;

		for(LabNotePqcGateCheckListDTO tvo : pqcList) {
			itemTypeCd = tvo.getVItemTypeCd();

			if (itemTypeCd.indexOf("|") > -1) {
				arrItemTypeCd = itemTypeCd.split("\\|");
			}
			else {
				arrItemTypeCd = new String[] {itemTypeCd};
			}

			if (ArrayUtils.contains(arrItemTypeCd, "SAFETY_CT")) {

				int cnt = hbdProcessMapper.selectSafetyCtCount(vLabNoteCd);
				if (cnt == 0) {
					continue;
				}
			} else if (ArrayUtils.contains(arrItemTypeCd, "CHOICE")) {
				chkText = tvo.getVChkText();
				chkValue = tvo.getVChkValue();
				chkBeforeText = tvo.getVChkBeforeText();
				chkAfterText = tvo.getVChkAfterText();

				if (StringUtils.isNotEmpty(chkText)) {
					if (chkText.indexOf("|") > -1) {
						arrChkText = chkText.split("\\|");
						chkLen = arrChkText.length;
					}
					else {
						arrChkText = new String[] {chkText};
					}
				}

				if (StringUtils.isNotEmpty(chkValue)) {
					if (chkValue.indexOf("|") > -1) {
						arrChkValue = chkValue.split("\\|");
					}
					else {
						arrChkValue = new String[] {chkValue};
					}
				}

				if (StringUtils.isNotEmpty(chkBeforeText)) {
					if (chkBeforeText.indexOf("|") > -1) {
						arrChkBeforeText = chkBeforeText.split("\\|", chkLen);
					}
					else {
						arrChkBeforeText = new String[] {chkBeforeText};
					}
				}

				if (StringUtils.isNotEmpty(chkAfterText)) {
					if (chkAfterText.indexOf("|") > -1) {
						arrChkAfterText = chkAfterText.split("\\|", chkLen);
					}
					else {
						arrChkAfterText = new String[] {chkAfterText};
					}
				}
				else {
					arrChkAfterText = null;
				}

				int txtLen = arrChkText == null ? 0 : arrChkText.length;
				int valLen = arrChkValue == null ? 0 : arrChkValue.length;

				if (txtLen > 0 && txtLen == valLen) {
					List<Map<String, Object>> cdList = new ArrayList<Map<String, Object>>();
					Map<String, Object> vo;

					for (int j = 0; j < txtLen; j++) {
						vo = new HashMap<String, Object>();
						cdList.add(vo);

						vo.put("v_text", arrChkText[j]);
						vo.put("v_val", arrChkValue[j]);

						if (ArrayUtils.contains(arrItemTypeCd, "G1_GQMS") && arrChkValue[j].equals("Y")) {

							vo.put("v_flag_chk_text", "Y");
						}else {
							if(arrChkBeforeText != null && StringUtils.isNotEmpty(arrChkBeforeText[j])) {
								vo.put("v_before_text", arrChkBeforeText[j]);
								vo.put("v_flag_chk_text", "Y");
							}

							if(arrChkAfterText != null && StringUtils.isNotEmpty(arrChkAfterText[j])) {
								vo.put("v_after_text", arrChkAfterText[j]);
								vo.put("v_flag_chk_text", "Y");
							}
						}
					}

					tvo.setCodeList(cdList);
					tvo.setCodeType(txtLen == 1 ? "checkbox" : "radio");
					tvo.setVFlagGateChoice("Y");
				}
			}

			//~ 게이트 준수 판단 checkbox | radio
			// 게이트 준수 텍스트 입력
			if (ArrayUtils.contains(arrItemTypeCd, "TEXT")) {
				tvo.setVFlagGateText("Y");
			}

			list.add(tvo);
		}

		return list;
	}

	/**
	 * Gate 자가체크 항목 가져오는 메소드
	 * @param checkDTO
	 * @param noteVo
	 * @param verVo
	 * @param actType
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "unused" })
	public List<LabNotePqcGateCheckListDTO> selectPqcGateCheckList(LabNotePqcGateCheckReqDTO checkDTO, HbdNoteInfoDTO noteVo,
			LabNoteMstVersionPqcDTO verVo, String actType) {

		String pqcCd = checkDTO.getVPqcCd();
		String gateCd = checkDTO.getVPqcGateCd();

		if(StringUtils.isEmpty(pqcCd)) {
			checkDTO.setVPqcType(checkDTO.getVNoteType());
			pqcCd = labNoteCommonService.selectApplyPqcCd(checkDTO);
			checkDTO.setVPqcCd(pqcCd);
		}

		if("GATE_2".equals(gateCd)) {

			MusoguReqDTO tagDTO = MusoguReqDTO.builder()
					.vLabNoteCd(checkDTO.getVLabNoteCd())
					.language(sessionUtil.getLangCd())
					.build();

			//영유아(LNC12_04), 어린이(LNC12_07) 선택한지 확인
			List<MusoguTagVO> lnc12List = hbdCommonService.selectLabNoteTagList(tagDTO, "LNC12", "CHOOSE", "NOTE", null, null);
			checkDTO.setVFlagG2Buffer3("N");
			for(MusoguTagVO lnc12Vo : lnc12List) {
				if("LNC12_04".equals(lnc12Vo.getVTag2Cd()) || "LNC12_07".equals(lnc12Vo.getVTag2Cd())) {
					checkDTO.setVFlagG2Buffer3("Y");
					break;
				}
			}
		}

		List<LabNotePqcGateCheckListDTO> pqcList = labNoteCommonService.selectPqcGateCheckList(checkDTO);

		int size = pqcList == null ? 0 : pqcList.size();
		if(size == 0) {
			return null;
		}

		List<LabNotePqcGateCheckListDTO> list = new ArrayList<LabNotePqcGateCheckListDTO>();
		Map<String, LabNotePqcResItemListDTO> map = null;

		if(!"SAVE".equals(actType)) {
			if(StringUtils.isEmpty(checkDTO.getVPqcResCd())) {
				// 등록일 경우 해당 실험노트 최근 입력건이 있으면 불러온다. // 수정 건일 경우는 해당 플래그 없음
				checkDTO.setFLAG_PQC_LAST_RES("Y");
			}

			List<LabNotePqcResItemListDTO> itemList = labNoteCommonService.selectElabPqcResItemList(checkDTO);
			map = itemList == null ? new HashMap<String, LabNotePqcResItemListDTO>()
					: itemList.stream().collect(Collectors.toMap(LabNotePqcResItemListDTO::getVKey, entity -> entity));
		}

		String itemTypeCd, chkText, chkValue, chkBeforeText, chkAfterText, chkCondDb, chkCondCol, pqcItemCd;
		String[] arrItemTypeCd = null, arrChkText = null, arrChkValue = null, arrChkBeforeText = null, arrChkAfterText = null;
		int chkLen = 0;

		ObjectMapper objectMapper = new ObjectMapper();
		Map<String, Object> afterNoteVo = objectMapper.convertValue(noteVo, Map.class);
		Map<String, Object> afterVerVo = objectMapper.convertValue(verVo, Map.class);

		String[] arrLotCd = checkDTO.getArrLotCd();
		HbdNoteLotVO lotVo = hbdCommonService.selectLabNoteLot(PlantRatePriceReqVO.builder()
								.vLotCd(arrLotCd[0])
								.language(sessionUtil.getLangCd())
								.build());

		for(LabNotePqcGateCheckListDTO tvo : pqcList) {
			pqcItemCd = tvo.getVPqcItemCd();
			itemTypeCd = tvo.getVItemTypeCd();
			chkCondDb = tvo.getVChkCondDb();
			chkCondCol = tvo.getVChkCondCol();


			if (StringUtils.isNotEmpty(chkCondDb) && StringUtils.isNotEmpty(chkCondCol)) {
				if (chkCondDb.equals("mst")) {
					if (!"Y".equals(afterNoteVo.get(CommonUtil.snakeCaseToCamelCase(chkCondCol)))) {
						continue;
					}
				}
				else if (chkCondDb.equals("ver")) {
					if (!"Y".equals(afterVerVo.get(CommonUtil.snakeCaseToCamelCase(chkCondCol)))) {
						continue;
					}
				}
			}


			if(map != null && map.get(pqcItemCd) != null) {

				LabNotePqcResItemListDTO valVo = map.get(pqcItemCd);

				if(valVo != null) {
					tvo.setVChoiceVal01(valVo.getVChoiceVal01());
					tvo.setVChoiceVal02(valVo.getVChoiceVal02());
					tvo.setVChoiceVal03(valVo.getVChoiceVal03());
					tvo.setVChoiceVal04(valVo.getVChoiceVal04());
					tvo.setVChoiceVal05(valVo.getVChoiceVal05());
					tvo.setVTextVal01(valVo.getVTextVal01());
					tvo.setVTextVal02(valVo.getVTextVal02());
					tvo.setVTextVal03(valVo.getVTextVal03());
					tvo.setVTextVal04(valVo.getVTextVal04());
					tvo.setVTextVal05(valVo.getVTextVal05());
					tvo.setVChoiceTextVal01(valVo.getVChoiceTextVal01());
					tvo.setVChoiceTextVal02(valVo.getVChoiceTextVal02());
					tvo.setVChoiceTextVal03(valVo.getVChoiceTextVal03());
					tvo.setVChoiceTextVal04(valVo.getVChoiceTextVal04());
					tvo.setVChoiceTextVal05(valVo.getVChoiceTextVal05());
					tvo.setVBufferVal01(valVo.getVBufferVal01());
					tvo.setVBufferVal02(valVo.getVBufferVal02());
					tvo.setVBufferVal03(valVo.getVBufferVal03());
					tvo.setVBufferVal04(valVo.getVBufferVal04());
					tvo.setVBufferVal05(valVo.getVBufferVal05());
				}
			}

			if (itemTypeCd.indexOf("|") > -1) {
				arrItemTypeCd = itemTypeCd.split("\\|");
			}
			else {
				arrItemTypeCd = new String[] {itemTypeCd};
			}

			if (ArrayUtils.contains(arrItemTypeCd, "SAFETY_CT")) {

				int cnt = hbdProcessMapper.selectSafetyCtCount(checkDTO.getVLabNoteCd());
				if (cnt == 0) {
					continue;
				}
			} //~ 안전성 임상
			// T Cost
			else if (ArrayUtils.contains(arrItemTypeCd, "TCOST")) {
				double tcost = StringUtils.isNotEmpty(noteVo.getNTargetCost()) ? Double.parseDouble(noteVo.getNTargetCost()) : 0;
				int tgram = StringUtils.isNotEmpty(noteVo.getNCapacity()) ? Integer.parseInt(noteVo.getNCapacity()) : 0;
				StringBuffer detSb = new StringBuffer();
				if(tcost > 0 && tgram > 0) {
					checkDTO.setNTargetGram(tgram);

					List<HbdNoteLotDTO> tcList = hbdCommonService.selectElabTargetCostList(checkDTO.getArrLotCd(), checkDTO.getNTargetGram());
					int tcSize = tcList == null ? 0 : tcList.size();

					boolean isTcostClear = true;

					for (int j = 0; j < tcSize; j++) {

						if (j > 0) {
							detSb.append(", ");
						}

						HbdNoteLotDTO tcVo = tcList.get(j);
						if ( tcVo.getNPriceSum() > tcost ) {
							isTcostClear = false;
							detSb.append(tcVo.getVContCd()).append(" : 미준수(").append(tcVo.getNPriceSum()).append("원)");
						}
						else {
							detSb.append(tcVo.getVContCd()).append(" : 준수(").append(tcVo.getNPriceSum()).append("원)");
						}
					}

					tvo.setVChoiceVal01(isTcostClear ? "Y" : "N");
					tvo.setVGateBeforeHtml(detSb.toString());
				} else {
					tvo.setVChoiceVal01("Y");
					detSb.append("준수").append(tcost == 0 ? "(타켓 Cost 미설정)" : "(용량 미설정)");
					tvo.setVGateBeforeHtml(detSb.toString());
				}
			}//~ T Cost
			// 파일럿 정보
			else if (ArrayUtils.contains(arrItemTypeCd, "PILOT")) {
				if (verVo != null && StringUtils.isNotEmpty(verVo.getVPrePilotDt())) {
					tvo.setVGateBeforeHtml("선행 " + CommonUtil.getPointDate(verVo.getVPrePilotDt()));
				}else {
					tvo.setVGateBeforeHtml("일반 " + CommonUtil.getPointYYYYMM(noteVo.getVPilotDt(), "."));
				}
			}
			// 출시국가 법규 적합성 확인
			else if (ArrayUtils.contains(arrItemTypeCd, "GLB_BAN")) {

				int cnt = hbdProcessMapper.selectElabGlobalBanCheck(checkDTO);
				tvo.setVChoiceVal01(cnt > 0 ? "N" : "Y");
			} //~ 출시국가 법규 적합성 확인
			//규격 입력
			else if (ArrayUtils.contains(arrItemTypeCd, "G2_GQMS")) {
				LabNotePqcResItemListDTO g1GqmsVo = labNoteCommonService.selectLabNoteG1gqmsInfo(checkDTO.getVPqcGate1ResCd());

				String bufVal01 = StringUtils.isNotEmpty(tvo.getVBufferVal01()) ? tvo.getVBufferVal01() : (g1GqmsVo != null ? g1GqmsVo.getVBufferVal01() : "");
				String bufVal02 = StringUtils.isNotEmpty(tvo.getVBufferVal02()) ? tvo.getVBufferVal02() : (g1GqmsVo != null ? g1GqmsVo.getVBufferVal02() : "");
				String bufVal03 = StringUtils.isNotEmpty(tvo.getVBufferVal03()) ? tvo.getVBufferVal03() : (g1GqmsVo != null ? g1GqmsVo.getVBufferVal03() : "");
				String bufVal04 = StringUtils.isNotEmpty(tvo.getVBufferVal04()) ? tvo.getVBufferVal04() : (g1GqmsVo != null ? g1GqmsVo.getVBufferVal04() : "");
				String bufVal05 = StringUtils.isNotEmpty(tvo.getVBufferVal05()) ? tvo.getVBufferVal05() : (g1GqmsVo != null ? g1GqmsVo.getVBufferVal05() : "");
				String bufVal06 = StringUtils.isNotEmpty(tvo.getVBufferVal06()) ? tvo.getVBufferVal06() : (g1GqmsVo != null ? g1GqmsVo.getVBufferVal06() : "");
				String bufVal07 = StringUtils.isNotEmpty(tvo.getVBufferVal07()) ? tvo.getVBufferVal07() : (g1GqmsVo != null ? g1GqmsVo.getVBufferVal07() : "");

				tvo.setVBufferVal01(bufVal01);
				tvo.setVBufferVal02(bufVal02);
				tvo.setVBufferVal03(bufVal03);
				tvo.setVBufferVal04(bufVal04);
				tvo.setVBufferVal05(bufVal05);
				tvo.setVBufferVal06(bufVal06);
				tvo.setVBufferVal07(bufVal07);
				tvo.setVG1BufferVal01(bufVal01);
				tvo.setVG1BufferVal02(bufVal02);
				tvo.setVG1BufferVal03(bufVal03);
				tvo.setVG1BufferVal04(bufVal04);
				tvo.setVG1BufferVal05(bufVal05);
				tvo.setVG1BufferVal06(bufVal06);
				tvo.setVG1BufferVal07(bufVal07);
			}
			//~ 규격입력
			// 게이트 준수 판단 checkbox | radio
			if (ArrayUtils.contains(arrItemTypeCd, "CHOICE")) {

				chkText = tvo.getVChkText();
				chkValue = tvo.getVChkValue();
				chkBeforeText = tvo.getVChkBeforeText();
				chkAfterText = tvo.getVChkAfterText();

				if (StringUtils.isNotEmpty(chkText)) {
					if (chkText.indexOf("|") > -1) {
						arrChkText = chkText.split("\\|");
						chkLen = arrChkText.length;
					}
					else {
						arrChkText = new String[] {chkText};
					}
				}

				if (StringUtils.isNotEmpty(chkValue)) {
					if (chkValue.indexOf("|") > -1) {
						arrChkValue = chkValue.split("\\|");
					}
					else {
						arrChkValue = new String[] {chkValue};
					}
				}

				if (StringUtils.isNotEmpty(chkBeforeText)) {
					if (chkBeforeText.indexOf("|") > -1) {
						arrChkBeforeText = chkBeforeText.split("\\|", chkLen);
					}
					else {
						arrChkBeforeText = new String[] {chkBeforeText};
					}
				}

				if (StringUtils.isNotEmpty(chkAfterText)) {
					if (chkAfterText.indexOf("|") > -1) {
						arrChkAfterText = chkAfterText.split("\\|", chkLen);
					}
					else {
						arrChkAfterText = new String[] {chkAfterText};
					}
				}
				else {
					arrChkAfterText = null;
				}

				int txtLen = arrChkText == null ? 0 : arrChkText.length;
				int valLen = arrChkValue == null ? 0 : arrChkValue.length;

				if (txtLen > 0 && txtLen == valLen) {
					List<Map<String, Object>> cdList = new ArrayList<Map<String, Object>>();
					Map<String, Object> vo;

					String bufVal01 = tvo.getVBufferVal01();
					String bufVal02 = tvo.getVBufferVal02();
					String bufVal03 = tvo.getVBufferVal03();
					String bufVal04 = tvo.getVBufferVal04();
					String bufVal05 = tvo.getVBufferVal05();

					int len = arrLotCd.length;

					bufVal01 = "";		//??
					bufVal02 = "";
					bufVal03 = "";
					bufVal04 = "";

					if(len == 1) {

						if(lotVo != null) {
							//점도
							if("MTI00_01".equals(lotVo.getVTestType())) {
								bufVal01 = lotVo.getVTestValue();
							}
							//경도
							else if("MTI00_02".equals(lotVo.getVTestType())) {
								bufVal02 = lotVo.getVTestValue();
							}
							//비중
							else if("MTI00_03".equals(lotVo.getVTestType())) {
								bufVal03 = lotVo.getVTestValue();
							}

							if(StringUtils.isNotEmpty(lotVo.getVTestType())){
								bufVal04 = lotVo.getVPh();
							}
						}
					}

					if (StringUtils.isEmpty(bufVal01)) {
						bufVal01 ="예시) 0000±0000, Spindle: 64번, 12rpm, 2min";
					}

					for (int j = 0; j < txtLen; j++) {
						vo = new HashMap<String, Object>();
						cdList.add(vo);

						vo.put("v_text", arrChkText[j]);
						vo.put("v_val", arrChkValue[j]);

						if (ArrayUtils.contains(arrItemTypeCd, "G1_GQMS") && arrChkValue[j].equals("Y")) {
							vo.put("v_flag_chk_text", "Y");
						}else {
							if(arrChkBeforeText != null && StringUtils.isNotEmpty(arrChkBeforeText[j])) {
								vo.put("v_before_text", arrChkBeforeText[j]);
								vo.put("v_flag_chk_text", "Y");
							}

							if(arrChkAfterText != null && StringUtils.isNotEmpty(arrChkAfterText[j])) {
								vo.put("v_after_text", arrChkAfterText[j]);
								vo.put("v_flag_chk_text", "Y");
							}
						}
					}

					tvo.setCodeList(cdList);
					tvo.setCodeType(txtLen == 1 ? "checkbox" : "radio");
					tvo.setVFlagGateChoice("Y");
				}
			}
			//~ 게이트 준수 판단 checkbox | radio
			// 게이트 준수 텍스트 입력
			if (ArrayUtils.contains(arrItemTypeCd, "TEXT")) {
				tvo.setVFlagGateText("Y");
			}

			list.add(tvo);
		}

		return list;
	}

	@Transactional
	public ResponseVO saveLabNoteGate02ApprovalRequest(@Valid LabNoteProcessPqcCheckApprReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();
		ResultDTO resultDTO = new ResultDTO();

		try {
			//양산승인 관련 코드들이 결재코드를 많이 이용하기 때문에 양산승인 PASS시 강제로 결재 승인진행
			String ttl = hbdCommonService.selectElabApprTitleNm(reqDTO);

			String apprCd = commonService.handlingOfApprovalEp("APS030", "[마이비커]" + ttl, reqDTO.getApprReqInfo());
			reqDTO.setVApprCd(apprCd);

			//AS-IS 소스에는 참조 등록 handlingOfReference 메소드가 있었으나 기존 화면단에도 등록하는 곳이 없어 삭제함

			if(StringUtils.isNotEmpty(reqDTO.getVLabNoteCd())) {
				hbdCommonService.updateNoteStatusCd(reqDTO.getVLabNoteCd(), "LNC06_27");
				resultDTO = this.updateLabNoteGate2ApprCd(reqDTO);
			}

			if(resultDTO.getStatus().equals("succ")) {
				//메일 발송
				String pageUrl = new StringBuilder()
						.append("/hbd/all-lab-note-prd-process?vLabNoteCd=").append(reqDTO.getVLabNoteCd())
						.append("&vTabId=confirm")
						.append("&nVersion=").append(reqDTO.getNVersion())
						.append("&vFlagEndAppr=Y")
						.append("&vApprCd=").append(apprCd)
						.toString();

				commonService.updateSkyApprovalAprvDtlUrl(apprCd, pageUrl);

				commonService.sendMailApproval(ApprovalDTO.builder()
						.vApprCd(apprCd)
						.vUrl(pageUrl)
						.vResultStatus(ApprovalResultCode.APPR_REQUEST.getCode())
						.build());

				ReqResApprovalDTO apprDTO = reqDTO.getApprReqInfo();
				List<ApprovalDetailDTO> apprUserListTemp = apprDTO != null ? apprDTO.getApprList() : null;
				List<String> apprUserList = apprUserListTemp != null
											? apprUserListTemp.stream().map(v -> v.getVApprUserid()).collect(Collectors.toList())
											: null;

				commonService.sendAlarm(AlarmRegDTO.builder()
											.vLabNoteCd(reqDTO.getVLabNoteCd())
											.vStatusCd("AL_NOTE4")
											.vAlrTypeCd("AL_NOTE4_02")
											.typeList(Arrays.asList(Const.ALARM, Const.MAIL, Const.TIMELINE))
											.vContCd(reqDTO.getVContCd())
											.vContNm(reqDTO.getVContNm())
											.nVerNo((reqDTO.getNVersion() < 10 ? "0" : "") + String.valueOf(reqDTO.getNVersion()))
											.vLotNm(reqDTO.getVLotNm())
											.vNoteType("HBO")
											.userList(apprUserList)
											.vMoveUrl(pageUrl)
											.build());
			}

			responseVO.setOk(null);
		}catch(Exception e) {
			log.error("HbdProcessService.saveLabNoteGate02ApprovalRequest : " + e);
		}

		return responseVO;
	}

	//메이크업, hbd, 의약외품 => Gate02 자가체크 및 결재를 처방확정 tab에서 의뢰하는 것으로 변경되어 해당 로직은 사용하지 않음 (스킨케어만 사용), 추후 입고완료 시 개발완료 처리함
	@Transactional
	public ResultDTO updateLabNoteGate2ApprCd(@Valid LabNoteProcessPqcCheckApprReqDTO reqDTO) {

		reqDTO.setVPqcGateCd("GATE_2");
		HbdNoteInfoDTO noteVo = hbdCommonService.selectLabNoteInfo(reqDTO.getVLabNoteCd());
		LabNoteMstVersionPqcDTO verVo = hbdCommonService.selectLabNoteMstVerPqcInfo(reqDTO.getVLabNoteCd(), reqDTO.getNVersion());

		ResultDTO resultDTO = this.insertPqcGate(reqDTO, noteVo, verVo);

		return resultDTO;
	}

	// PQC 목록 저장
	@Transactional
	public ResultDTO insertPqcGate(@Valid LabNoteProcessPqcCheckApprReqDTO reqDTO, HbdNoteInfoDTO noteVo,
			LabNoteMstVersionPqcDTO verVo) {

		ResultDTO resultDTO = new ResultDTO();
		try {
			LabNotePqcGateCheckReqDTO checkDTO = LabNotePqcGateCheckReqDTO.builder()
					.vNoteType(reqDTO.getVNoteType())
					.vLabNoteCd(reqDTO.getVLabNoteCd())
					.nVersion(reqDTO.getNVersion())
					.arrLotCd(reqDTO.getArrLotCd())
					.vPqcGateCd(reqDTO.getVPqcGateCd())
					.vPqcGate1ResCd(reqDTO.getVPqcGate1ResCd())
					.build();


			reqDTO.setVRegUserid(sessionUtil.getLoginId());
			reqDTO.setVUpdateUserid(sessionUtil.getLoginId());

			Map<String, LabNotePqcResItemListDTO> resItemMap = null;
			Map<String, PgcGqteResVO> resLotMap = null;

			PgcGqteResVO pqcResVo = null;

			if (StringUtils.isNotEmpty(reqDTO.getVApprCd())) {
				pqcResVo = labNoteCommonService.selectPqcGqteResInfo(reqDTO.getVApprCd());
			}

			if(pqcResVo != null) {
				reqDTO.setVPqcResCd(pqcResVo.getVPqcResCd());
				List<LabNotePqcResItemListDTO> resItemList = labNoteCommonService.selectElabPqcResItemList(checkDTO);
				resItemMap = resItemList == null ? new HashMap<String, LabNotePqcResItemListDTO>()
						: resItemList.stream().collect(Collectors.toMap(LabNotePqcResItemListDTO::getVKey, entity -> entity));

				List<PgcGqteResVO> resLotList = labNoteCommonService.selectElabPqcResLotList(reqDTO.getVPqcResCd());
				resLotMap = resLotList == null ? new HashMap<String, PgcGqteResVO>()
						: resLotList.stream().collect(Collectors.toMap(PgcGqteResVO::getVKey, entity -> entity));
			}
			else {
				labNoteCommonService.insertElabPqcRes(reqDTO);
			}

			double totalCnt = 0;
			double clearCnt = 0;
			String key;
			List<LabNotePqcGateCheckListDTO> pqcCheckList = reqDTO.getPqcCheckList();

			int size = pqcCheckList == null ? 0 : pqcCheckList.size();
			if(size == 0) {
				resultDTO.setStatus("fail");
				resultDTO.setMessage("자가체크 항목을 찾을 수 없습니다.");
				return resultDTO;
			}

			for(LabNotePqcGateCheckListDTO tvo : pqcCheckList) {

				String itemTypeCd = tvo.getVItemTypeCd();
				String itemClearValue = tvo.getVItemClearValue();
				String[] arrItemTypeCd;
				key = tvo.getVPqcItemCd();

				if(itemTypeCd.indexOf("|") > -1) {
					arrItemTypeCd = itemTypeCd.split("\\|");
				}else {
					arrItemTypeCd = new String[] {itemTypeCd};
				}

				if (ArrayUtils.contains(arrItemTypeCd, "PILOT")) {
					tvo.setVFlagObey("-");
				}
				else if (ArrayUtils.contains(arrItemTypeCd, "PAO")) {
					if (StringUtils.isNotEmpty(tvo.getVTextVal01()) && StringUtils.isNotEmpty(tvo.getVTextVal02()) ) {
						tvo.setVFlagObey("Y");
					}
					else {
						tvo.setVFlagObey("N");
					}
				}
				else {
					if (tvo.getVChoiceVal01().equals("PASS")) {
						tvo.setVFlagObey("P");
					}
					else if (tvo.getVChoiceVal01().equals(itemClearValue)) {
						tvo.setVFlagObey("Y");
					}
					else {
						tvo.setVFlagObey("N");
					}
				}

				tvo.setVRegUserid(sessionUtil.getLoginId());
				tvo.setVUpdateUserid(sessionUtil.getLoginId());

				if (resItemMap != null && resItemMap.get(key) != null) {
					tvo.setVPqcResItemCd(resItemMap.get(key).getVPqcResItemCd());
					labNoteCommonService.updateElabPqcResItem(tvo);
					resItemMap.remove(key);
				}
				else {
					tvo.setVPqcResCd(reqDTO.getVPqcResCd());
					labNoteCommonService.insertElabPqcResItem(tvo);
				}

				if(tvo.getVFlagObey().equals("Y")) {
					totalCnt++;
					clearCnt++;
				}else if(tvo.getVFlagObey().equals("N")) {
					totalCnt++;
				}
			}

			if(resItemMap != null) {
				Iterator<String> itr = resItemMap.keySet().iterator();

				while (itr.hasNext()) {
					key = (String)itr.next();

					LabNotePqcResItemListDTO itemDTO = LabNotePqcResItemListDTO.builder()
							.vPqcResItemCd(resItemMap.get(key).getVPqcResItemCd())
							.vPqcResCd("")
							.vUpdateUserid(sessionUtil.getLoginId())
							.build();

					labNoteCommonService.deleteElabPqcResItem(itemDTO);
				}
			}

			if(totalCnt > 0) {
				reqDTO.setNPqcObeyPer(Math.round((clearCnt / totalCnt * 100d) * 100d) / 100d);
			}else {
				reqDTO.setNPqcObeyPer(0);
			}

			labNoteCommonService.updateElabPqcRes(reqDTO);

			String[] arrContPkCd = reqDTO.getArrContPkCd();
			String[] arrLotCd = reqDTO.getArrLotCd();
			int len = arrContPkCd == null ? 0 : arrContPkCd.length;

			for(int i = 0; i < len; i++) {
				reqDTO.setVPqcContPkCd(arrContPkCd[i]);
				reqDTO.setVPqcLotCd(arrLotCd[i]);

				hbdProcessMapper.updateLabContPqcRes(reqDTO);
				hbdProcessMapper.updateLabContVerPqcRes(reqDTO);

				if (resLotMap != null && resLotMap.get(arrLotCd[i]) != null) {
					resLotMap.remove(arrLotCd[i]);
				}
				else {
					labNoteCommonService.insertElabPqcResLot(reqDTO);
				}
			}

		}catch(Exception e) {
			log.error("HbdProcessService.insertPqcGate : {}" + e);
		}

		resultDTO.setStatus("succ");
		resultDTO.setMessage("결재 승인 요청되었습니다.");
		return resultDTO;
	}

	//메이크업, hbd, 의약외품 => Gate02 자가체크 및 결재를 처방확정 tab에서 의뢰하는 것으로 변경되어 해당 로직은 사용하지 않음 (스킨케어만 사용), 추후 입고완료 시 개발완료 처리함
	@Deprecated
	public ResponseVO updateLabNoteMassPass(@Valid LabNoteProcessPqcCheckApprReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		//양산승인 관련 코드들이 결재코드를 많이 이용하기 때문에 양산승인 PASS시 강제로 결재 승인진행
		String ttl = hbdCommonService.selectElabApprTitleNm(reqDTO);

		ApprovalDTO apprInfo = ApprovalDTO.builder()
				.nCurRegseq(1)
				.nCurApprseq(1)
				.vApprClass("LAB002_" + reqDTO.getVNoteType())
				.vApprStatus("APS010")
				.vDraftUserid(sessionUtil.getLoginId())
				.vDraftTitle("[실험노트]" + ttl)
				.vDraftOpinion("")
				.build();

		approvalService.insertApprovalMst(apprInfo);

		if(StringUtils.isNotEmpty(apprInfo.getVApprCd())) {
			this.updateLabNoteGate2ApprCd(reqDTO);
			this.updateLabNoteGate2End(reqDTO.getVLabNoteCd());
		}

		responseVO.setOk("양산승인 되었습니다.");
		return responseVO;
	}

	//메이크업, hbd, 의약외품 => Gate02 자가체크 및 결재를 처방확정 tab에서 의뢰하는 것으로 변경되어 해당 로직은 사용하지 않음 (스킨케어만 사용), 추후 입고완료 시 개발완료 처리함
	@Deprecated
	public void updateLabNoteGate2End(String vLabNoteCd) {
		String vFlagDecideLot = hbdCommonService.selectLabNoteContMassEndCheck(vLabNoteCd);
		if("Y".equals(vFlagDecideLot)) {
			hbdCommonService.updateStatusCd_LNC06_51(vLabNoteCd);
		}
	}

	public ResponseVO selectLabNoteGate2View(LabNoteProcessContDecideReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();
		try {
			LabNoteTestRequestProductResDTO<HbdNoteInfoDTO> resDTO = new LabNoteTestRequestProductResDTO<HbdNoteInfoDTO>();

			ReqResApprovalDTO apprVo = commonService.selectApprovalInfo(reqDTO.getVApprCd());

			List<LabNoteProcessContDecideListDTO> pqcContList = hbdProcessMapper.selectLabNoteContMassList(reqDTO.getVApprCd(), sessionUtil.getLocalLanguage());
			LabNoteProcessContDecideListDTO contVo;

			if(pqcContList != null && ObjectUtils.isNotEmpty(pqcContList)) {
				contVo = pqcContList.get(0);
				reqDTO.setVLabNoteCd(contVo.getVLabNoteCd());
				reqDTO.setNVersion(contVo.getNVersion());
			}

			HbdNoteInfoDTO noteVo = null;
			PgcGqteResVO pqcResVo = labNoteCommonService.selectPqcGqteResInfo(reqDTO.getVApprCd());

			if(pqcResVo != null) {
				noteVo = hbdCommonService.selectLabNoteInfo(pqcResVo.getVLabNoteCd());
				//PQC GATE2
				LabNoteMstVersionPqcDTO versionPqcDTO = hbdCommonService.selectLabNoteMstVerPqcInfo(pqcResVo.getVLabNoteCd(), pqcResVo.getNVersion());

				// 시험의뢰 목록
				LabNoteTestRequestProductReqDTO trDTO = LabNoteTestRequestProductReqDTO.builder()
						.vFlagExcelAll("Y")
						.localLanguage(sessionUtil.getLangCd())
						.vLabNoteCd(pqcResVo.getVLabNoteCd())
						.build();

				List<LabNoteTestRequestProductDTO> trGate1List = new ArrayList<LabNoteTestRequestProductDTO>();
				List<LabNoteTestRequestProductDTO> trList = hbdCommonService.selectLabNoteTrProductList(trDTO);
				int trSize = trList == null ? 0 : trList.size();
				String key;

				Map<String, List<LabNoteTestRequestProductDTO>> trMap = new HashMap<String, List<LabNoteTestRequestProductDTO>>();
				List<LabNoteTestRequestProductDTO> subList = null;

				if(trSize > 0) {

					for(LabNoteTestRequestProductDTO tvo : trList) {

						key = tvo.getVLabMrqTypeCd();
						if(StringUtils.isNotEmpty(tvo.getVLabGateCd()) && tvo.getVLabGateCd().equals("GATE_1")) {
							trGate1List.add(tvo);
							continue;
						}

						subList = trMap.get(key);

						if(subList == null) {
							subList = new ArrayList<LabNoteTestRequestProductDTO>();
							trMap.put(key, subList);
						}

						subList.add(tvo);

					}
					resDTO.setTrMap(trMap);
				}

				resDTO.setPqcResVo(pqcResVo);
				resDTO.setTrGate1List(trGate1List);
				resDTO.setPqcList(this.selectPqcGateResItemList(pqcResVo.getVPqcResCd(), pqcResVo.getVLabNoteCd(), versionPqcDTO));
			}

			resDTO.setApprVo(apprVo);
			resDTO.setContList(pqcContList);
			resDTO.setRvo(noteVo);

			responseVO.setOk(resDTO);

		}catch(Exception e) {
			log.error("HbdProcessService.selectLabNoteGate2View : " + e);
		}

		return responseVO;
	}

	public ResponseVO selectLabNotePilotRegInitInfo(PilotRequestReqDTO pilotRequestReqDTO) {
		ResponseVO responseVO = new ResponseVO();

		HbdNoteInfoDTO noteInfo = hbdCommonService.selectLabNoteInfo(pilotRequestReqDTO.getVLabNoteCd());
		List<LabNoteMstVersionDTO> verList = null;
		List<LabNoteContInfoVO> contList = null;
		Map<String, List<VersionContVO>> plantMap = null;
		Map<String, List<ScNoteLotDTO>> lotMap = null;
		List<ApprovalDetailDTO> userList = null;
		if (noteInfo != null) {
			verList = hbdCommonService.selectLabNoteMstVerList(pilotRequestReqDTO.getVLabNoteCd());
			contList = hbdCommonService.selectLabNoteContList(LabNoteContInfoVO.builder()
													.vLabNoteCd(pilotRequestReqDTO.getVLabNoteCd())
													.vCodeType("HAL3")
													.localLanguage(sessionUtil.getLocalLanguage())
													.build());

			int verSize = verList == null ? 0 : verList.size();
			int ver = verSize == 0 ? 1 : verList.get(verSize - 1).getNVersion();

			List<VersionContVO> plantList = hbdProcessMapper.selectLabNoteContPlantAllList(pilotRequestReqDTO.getVLabNoteCd(), sessionUtil.getLocalLanguage());
			plantMap = plantList == null
								? new HashMap<>()
								: plantList.stream().collect(Collectors.groupingBy(VersionContVO::getVContPkCd));

			List<ScNoteLotDTO> lotList = hbdProcessMapper.selectLabNoteContLotAllList(pilotRequestReqDTO.getVLabNoteCd(), ver);
			lotMap = lotList == null
							? new HashMap<>()
							: lotList.stream().collect(Collectors.groupingBy(ScNoteLotDTO::getVContPkCd));

			userList = hbdCommonService.selectLabNoteApprovalUserList(pilotRequestReqDTO.getVLabNoteCd(), sessionUtil.getLangCd());
		}

		responseVO.setOk(PilotRequestDetailResDTO.<HbdNoteInfoDTO, VersionContVO, ScNoteLotDTO>builder()
															.noteInfo(noteInfo)
															.verList(verList)
															.contList(contList)
															.plantMap(plantMap)
															.lotMap(lotMap)
															.userList(userList)
															.build());

		return responseVO;
	}

	public ResponseVO selectLabNotePilotRegVersionLotList (String vLabNoteCd, int nVersion) {
		ResponseVO responseVO = new ResponseVO();

		List<ScNoteLotDTO> lotList = hbdProcessMapper.selectLabNoteContLotAllList(vLabNoteCd, nVersion);
		Map<String, List<ScNoteLotDTO>> lotMap = lotList == null
												? new HashMap<>()
												: lotList.stream().collect(Collectors.groupingBy(ScNoteLotDTO::getVContPkCd));

		responseVO.setOk(lotMap);
		return responseVO;
	}

	public ResponseVO selectLabNotePilotRegInfo(PilotRequestRegInfoReqDTO pilotRequestRegInfoReqDTO) {
		ResponseVO responseVO = new ResponseVO();
		HbdNoteInfoDTO noteInfo = hbdCommonService.selectLabNoteInfo(pilotRequestRegInfoReqDTO.getVLabNoteCd());

		LabNoteMstVersionPqcDTO versionPqcDTO = hbdCommonService.selectLabNoteMstVerPqcInfo(pilotRequestRegInfoReqDTO.getVLabNoteCd(), pilotRequestRegInfoReqDTO.getNVersion());

		List<LabNoteTestRequestProductDTO> trList = hbdCommonService.selectLabNoteTrProductList(LabNoteTestRequestProductReqDTO.builder()
																.vFlagExcelAll("Y")
																.localLanguage(sessionUtil.getLangCd())
																.vLabNoteCd(pilotRequestRegInfoReqDTO.getVLabNoteCd())
																.build());

		List<LabNoteTestRequestProductDTO> trFinalList = trList != null ? trList.stream().filter(v -> StringUtils.isNotEmpty(v.getVLabMrqTypeCd())).collect(Collectors.toList()) : null;
		Map<String, List<LabNoteTestRequestProductDTO>> trMap = trFinalList == null
															? new HashMap<>()
															: trFinalList.stream().collect(Collectors.groupingBy(LabNoteTestRequestProductDTO::getVLabMrqTypeCd));

		LabNotePqcGateCheckReqDTO checkDTO = LabNotePqcGateCheckReqDTO.builder()
													.vNoteType(pilotRequestRegInfoReqDTO.getVNoteType())
													.vLabNoteCd(pilotRequestRegInfoReqDTO.getVLabNoteCd())
													.nVersion(pilotRequestRegInfoReqDTO.getNVersion())
													.arrLotCd(pilotRequestRegInfoReqDTO.getArrLotCd())
													.vPqcGateCd("GATE_1")
													.build();
		List<LabNotePqcGateCheckListDTO> pqcCheckList = this.selectPqcGateCheckList(checkDTO, noteInfo, versionPqcDTO, "REG");

		List<ShelfLifeVO> shelfLifeContInfoList = labNoteCommonService.selectOneShelfLifeContInfo(ShelfLifeVO.builder()
															 .language(sessionUtil.getLocalLanguage())
															 .contCdList(Arrays.asList(pilotRequestRegInfoReqDTO.getArrContCd()))
															 .build());

		Map<String, ShelfLifeVO> shelfContMap = shelfLifeContInfoList == null
											? new HashMap<>()
											: shelfLifeContInfoList.stream().collect(Collectors.toMap(ShelfLifeVO::getVContCd, entity -> entity));

		List<ShelfLifeVO> shelfLifeList = new ArrayList<ShelfLifeVO>();
		ShelfLifeVO shelfLifeVO = null;
		String[] arrContCd = pilotRequestRegInfoReqDTO.getArrContCd();
		String[] arrPlantCd = pilotRequestRegInfoReqDTO.getArrPlantCd();

		if (arrContCd != null && arrContCd.length > 0) {
			for (int i=0; i < arrContCd.length; i++) {
				shelfLifeVO = ShelfLifeVO.builder()
								.vContCd(arrContCd[i])
								.vPlantCd(arrPlantCd[i])
								.vShelfLife(shelfContMap.get(arrContCd[i]) == null ? "" : shelfContMap.get(arrContCd[i]).getVShelfLife())
								.vFlagLife(shelfContMap.get(arrContCd[i]) == null || StringUtils.isEmpty(shelfContMap.get(arrContCd[i]).getVShelfLife()) ? "N" : "Y")
								.build();

				shelfLifeList.add(shelfLifeVO);
			}
		}

		responseVO.setOk(PilotRequestRegInfoResDTO.builder()
								.versionPqcInfo(versionPqcDTO)
								.trMap(trMap)
								.pqcList(pqcCheckList)
								.shelfLifeList(shelfLifeList)
								.bomList(hbdCommonService.selectLabNoteMateInfo(ConvertUtil.convert(pilotRequestRegInfoReqDTO, MateRateReqVO.class)))
								.build());
		return responseVO;
	}

	public ResponseVO selectLabNoteBomSendList(PilotRequestReqDTO pilotRequestReqDTO) {
		ResponseVO responseVO = new ResponseVO();
		List<PilotRequestDTO> list = null;

		int totalCnt = hbdProcessMapper.selectLabNoteBomSendListCount(pilotRequestReqDTO);
		CommonUtil.setPaging(pilotRequestReqDTO, totalCnt);
		if (totalCnt > 0) {
			list = hbdProcessMapper.selectLabNoteBomSendList(pilotRequestReqDTO);
		}

		PagingDTO page = ConvertUtil.convert(pilotRequestReqDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
									.page(page)
									.list(list)
									.build();
		responseVO.setOk(res);
		return responseVO;
	}

	@Transactional
	public ResponseVO saveLabNoteGate01(LabNoteProcessPqcCheckApprReqDTO params) {
		ResponseVO responseVO = new ResponseVO();
		String apprCd = labNoteCommonService.selectLabNoteApprBomInfoApprCdTemp();

		if (StringUtils.isNotEmpty(params.getVLabNoteCd())) {
			params.setVRegUserid(sessionUtil.getLoginId());
			params.setVUpdateUserid(sessionUtil.getLoginId());
			params.setVApprCd(apprCd);

			if (params.getArrLotCd() != null && params.getArrLotCd().length > 0) {
				hbdProcessMapper.insertLabNoteApprBomInfo(params);
				hbdProcessMapper.updateLabNoteLotApprCd(params);

				for (String lotCd : params.getArrLotCd()) {
					hbdCommonService.updateLabNoteLotComplete(lotCd);
					labNoteCommonService.insertElabBomLotVer(ElabBomLotVerVO.builder()
																.vLabNoteCd(params.getVLabNoteCd())
																.vLotCd(lotCd)
																.vBomType("NORMAL")
																.vTempPkCd(apprCd)
																.vRegUserid(sessionUtil.getLoginId())
																.vUpdateUserid(sessionUtil.getLoginId())
																.build());
				}
			}

			params.setVPqcGateCd("GATE_1");
			HbdNoteInfoDTO noteVo = hbdCommonService.selectLabNoteInfo(params.getVLabNoteCd());
			LabNoteMstVersionPqcDTO verVo = hbdCommonService.selectLabNoteMstVerPqcInfo(params.getVLabNoteCd(), params.getNVersion());

			this.insertPqcGate(params, noteVo, verVo);

			int result = hbdCommonService.updateAcceptApprovalRequest(BomApprovalReqDTO.builder()
													.contPkCdList(Arrays.asList(params.getArrContPkCd()))
													.lotCdList(Arrays.asList(params.getArrLotCd()))
													.vLabNoteCd(params.getVLabNoteCd())
													.nVersion(params.getNVersion())
													.build());

			if (result > 0) {
				if (params.getShelfLifeList() != null && !params.getShelfLifeList().isEmpty()) {
					labNoteCommonService.checkPQCShelfLife(apprCd);
					for (ElabShelflifeContVO shelfVO : params.getShelfLifeList()) {
						if ("ETC".equals(shelfVO.getVShelfLife())) {
							shelfVO.setVShelfLife(shelfVO.getVEtcLife());
						}

						shelfVO.setVStatusCd("SLS020");
						shelfVO.setVContType("HAL3");
						shelfVO.setVNoteType("HBD");

						labNoteCommonService.insertShelfLifeInfoCont(shelfVO);

						List<LabNoteContInfoVO> checkSubList = hbdCommonService.checkSubPlantList(params.getVLabNoteCd(), shelfVO.getVContCd());

						if (checkSubList != null && !checkSubList.isEmpty()) {
							labNoteCommonService.updateSubPlantFlag(shelfVO.getVContCd());
							labNoteCommonService.deleteShelfLifeSubPlant(shelfVO.getVContCd());

							for (LabNoteContInfoVO checkSub : checkSubList) {
								if (!checkSub.getVPlantCd().equals(shelfVO.getVPlantCd())) {
									labNoteCommonService.insertShelfLifeSubPlant(checkSub.getVContCd(), checkSub.getVPlantCd());
								}
							}
						}
					}
				}

				String pageUrl = new StringBuilder()
						.append("/hbd/all-lab-note-prd-process?vLabNoteCd=")
						.append(params.getVLabNoteCd())
						.append("&vTabId=pilot")
						.append("&vApprCd=")
						.append(apprCd)
						.toString();

				commonService.sendAlarm(AlarmRegDTO.builder()
											.vLabNoteCd(params.getVLabNoteCd())
											.vStatusCd("AL_NOTE3")
											.vAlrTypeCd("AL_NOTE3_02")
											.typeList(Arrays.asList(Const.TIMELINE, Const.SCHEDULE, Const.ALARM))
											.vContCd(params.getVContCd())
											.vContNm(params.getVContNm())
											.nVerNo(params.getNVersion() < 10 ? "0" + params.getNVersion() : "" + params.getNVersion())
											.vLotNm(params.getVLotNm())
											.vNoteType("HBO")
											.userList(Arrays.asList(commonService.selectLabLeaderid(noteVo.getVDeptCd())))
											.vMoveUrl(pageUrl)
											.build());

				responseVO.setCreateOk(null);
			} else {
				responseVO.setOkWithCode("C9999", CommonResultCode.SAVE_FAIL, null);
			}
		} else {
			responseVO.setOkWithCode("C9999", CommonResultCode.SAVE_FAIL, null);
		}

		return responseVO;
	}

	public ResponseVO selectLabNoteFormulaDecideList(PilotRequestReqDTO pilotRequestReqDTO) {
		ResponseVO responseVO = new ResponseVO();

		HbdNoteInfoDTO noteInfo = hbdCommonService.selectLabNoteInfo(pilotRequestReqDTO.getVLabNoteCd());

		if (noteInfo != null) {
			List<PilotRequestDTO> list = hbdProcessMapper.selectFormulaDecideList(pilotRequestReqDTO);

			FormulaDecideResDTO<HbdNoteInfoDTO> res = FormulaDecideResDTO.<HbdNoteInfoDTO>builder()
										.list(list)
										.noteInfo(noteInfo)
										.verList(hbdCommonService.selectLabNoteMstVerList(pilotRequestReqDTO.getVLabNoteCd()))
										.contList(hbdCommonService.selectLabNoteContList(LabNoteContInfoVO.builder()
																			.vLabNoteCd(pilotRequestReqDTO.getVLabNoteCd())
																			.vCodeType(noteInfo.getVCodeType())
																			.localLanguage(sessionUtil.getLocalLanguage())
																			.build()))
										.build();
			responseVO.setOk(res);
		} else {
			responseVO.setOkWithCode("C9999", CommonResultCode.NO_DATA, null);
		}


		return responseVO;
	}

	/**
	 * HBO 에서만 사용함
	 * @param reqDTO
	 * @return
	 */
	public ResponseVO selectEvReportProdListPop(LabNoteProcessReportPrdListReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		//AS-IS : supo_ev_report_prod_list_pop 메소드
		//프로세스에서는 vLabNoteCd 있는 경우만 사용함, 해당 로직만 가져오기 => 나머지 로직은 심사 보고서 로직이라 옮겨오지 않음
		List<IngredientContVO> contList = hbdCommonService.selectLabContList(IngredientReqDTO.builder()
				.vLabNoteCd(reqDTO.getVLabNoteCd())
				.nVersion(reqDTO.getNVersion())
				.localLanguage(sessionUtil.getLocalLanguage())
				.build());

		responseVO.setOk(contList);
		return responseVO;
	}

	@Transactional
	public ResponseVO sendBomFreePass(BomApprovalReqDTO bomApprovalReqDTO) {
		ResponseVO responseVO = new ResponseVO();

		int result = hbdCommonService.updateAcceptApprovalRequest(bomApprovalReqDTO);

		if (result > 0) {
			responseVO.setCreateOk(null);
		} else {
			responseVO.setOkWithCode("C9999", CommonResultCode.SAVE_FAIL, null);
		}

		return responseVO;
	}

	public ResponseVO selectFuncTestEpReportView(LabNoteProcessFuncRequestQADTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		try {
			reqDTO.setLocalLanguage(sessionUtil.getLangCd());
			HbdNoteInfoDTO noteInfoDTO = hbdCommonService.selectLabNoteInfo(reqDTO.getVLabNoteCd());
			List<LabNoteProcessFuncReportDecideContDTO> decideNmList = hbdProcessMapper.selectLabNoteDecideContNmList(reqDTO);
			List<LabNoteCommonTagDTO> funcList = this.selectLabNoteMstVerTagList("EV_MATERIAL_FUNC2", reqDTO.getVLabNoteCd(), reqDTO.getNVersion());
			List<LabNoteProcessFuncMateResDTO> mateList = hbdProcessMapper.selectLabNoteFuncMateList(reqDTO.getVLabNoteCd(), reqDTO.getNVersion(), null);
			LabNoteVersionDTO verVo = hbdCommonService.selectLabNoteMstVerInfo(reqDTO.getVLabNoteCd(), reqDTO.getNVersion());
			List<MusoguTagVO> releaseDt = hbdCommonService.selectLabNoteTagList(MusoguReqDTO.builder()
					.vLabNoteCd(reqDTO.getVLabNoteCd())
					.language(sessionUtil.getLangCd())
					.vTempTag1Cd("LNC02")
					.vGetListType("CHOOSE")
					.build());

			LabNoteProcessFuncReportResPopDTO qaVo = hbdProcessMapper.selectLabNoteFuncRequestQA(LabNoteProcessFuncReportReqPopDTO.builder()
					.vLabNoteCd(reqDTO.getVLabNoteCd())
					.nVersion(reqDTO.getNVersion())
					.nSeqno(reqDTO.getNSeqno())
					.build());

			List<ElabContQmsVO> qmsInfoList = labNoteCommonService.selectElabContQmsInfo(LabNoteProcessFuncReportResPopDTO.builder()
					.vLabNoteCd(reqDTO.getVLabNoteCd())
					.nVersion(reqDTO.getNVersion())
					.nSeqno(reqDTO.getNSeqno())
					.build());

			LabNoteProcessFuncReportRegResDTO<HbdNoteInfoDTO> resDTO = LabNoteProcessFuncReportRegResDTO.<HbdNoteInfoDTO>builder()
					.rvo(noteInfoDTO)
					.decideNmList(decideNmList)
					.funcList(funcList)
					.mateList(mateList)
					.verVo(verVo)
					.releaseDt(releaseDt)
					.qaVo(qaVo)
					.qmsLotInfoList(qmsInfoList)	//SC만 있음
					.build();

			responseVO.setOk(resDTO);

		}catch(Exception e) {
			log.error("MakeupProcessServcie.selectFuncTestEpReportView" + e);
		}

		return responseVO;
	}

	public ResponseVO selectLabNoteFuncDecideNameInfo(String vLabNoteCd, String vApprCd) {
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(hbdProcessMapper.selectLabNoteFuncDecideNameInfo(vLabNoteCd, vApprCd, sessionUtil.getLangCd()));
		return responseVO;
	}

	public ResponseVO selectQmsInfo(String vLabNoteCd) {
		ResponseVO responseVO = new ResponseVO();

		LabNoteContInfoVO contInfoVO = LabNoteContInfoVO.builder()
											.vLabNoteCd(vLabNoteCd)
											.vCodeType("HAL3")
											.localLanguage(sessionUtil.getLocalLanguage())
											.build();

		List<LabNoteContInfoVO> contList = hbdCommonService.selectLabNoteContList(contInfoVO);
		List<LabNoteContInfoVO> plantList = null;
		if (contList != null && !contList.isEmpty()) {
			contInfoVO.setVContCd(contList.get(0).getVContCd());

			plantList = hbdCommonService.selectLabNotePlantList(contInfoVO);
		}

		responseVO.setOk(QmsResDTO.builder()
								.contList(contList)
								.plantList(plantList)
								.build());

		return responseVO;
	}

	public ResponseVO selectQmsPlantList(String vLabNoteCd, String vContCd) {
		ResponseVO responseVO = new ResponseVO();

		List<LabNoteContInfoVO> plantList = hbdCommonService.selectLabNotePlantList(LabNoteContInfoVO.builder()
																							.vLabNoteCd(vLabNoteCd)
																							.vContCd(vContCd)
																							.vCodeType("HAL3")
																							.localLanguage(sessionUtil.getLocalLanguage())
																							.build());
		responseVO.setOk(plantList);
		return responseVO;
	}

	public ResponseVO checkValidationPilot(LotPilotRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();

		List<String> resNotExists = new ArrayList<>();
		List<String> resUnusableMate = new ArrayList<>();
		List<String> resBanMate = new ArrayList<>();
		List<String> resTempMate = new ArrayList<>();
		List<String> resSumRate = new ArrayList<>();

		ValidateVO reqVO = ValidateVO.builder()
								.nVersion(regDTO.getNVersion())
								.vLand1("UN")
								.build();
		List<LabNoteLotDTO> lotList = regDTO.getLotList();
		if (lotList != null && !lotList.isEmpty()) {
			for (LabNoteLotDTO lotDTO : lotList) {
				reqVO.setVContPkCd(lotDTO.getVContPkCd());
				reqVO.setVLotCd(lotDTO.getVLotCd());

				ValidateVO vo = hbdCommonService.selectLabNoteValidate(reqVO);

				if(vo.getNCntNotExistsMate() > 0) {
					resNotExists.add(vo.getVLotNm());
				}
				else if(vo.getNCntUnusableMate() > 0) {
					resUnusableMate.add(vo.getVLotNm());
				}
				else if(vo.getNCntBanMate() > 0) {
					resBanMate.add(vo.getVLotNm());
				}
				else if(vo.getNCntTempMate() > 0) {
					resTempMate.add(vo.getVLotNm());
				}
				else if(vo.getNSumRate() != 100) {
					resSumRate.add(vo.getVLotNm());
				}
			}
		}

		StringBuilder resBuilder = new StringBuilder();
		if (resNotExists != null && resNotExists.size() > 0) {
			resBuilder.append("해당 플랜트에 없는 원료가 존재합니다.<br>");
			resBuilder.append(String.join("<br>", resNotExists));
			resBuilder.append("<br><br>");
		}

		if (resUnusableMate != null && resUnusableMate.size() > 0) {
			resBuilder.append("해당 처방에 단종된 원료가 존재합니다.<br>");
			resBuilder.append(String.join("<br>", resUnusableMate));
			resBuilder.append("<br><br>");
		}

		if (resBanMate != null && resBanMate.size() > 0) {
			resBuilder.append("해당 처방에 금지원료가 존재합니다.<br>");
			resBuilder.append(String.join("<br>", resBanMate));
			resBuilder.append("<br><br>");
		}

		if (resTempMate != null && resTempMate.size() > 0) {
			resBuilder.append("해당 처방에 임시원료가 존재합니다.<br>");
			resBuilder.append(String.join("<br>", resTempMate));
			resBuilder.append("<br><br>");
		}

		if (resSumRate != null && resSumRate.size() > 0) {
			resBuilder.append("원료 배합 합이 100이 아닙니다.<br>");
			resBuilder.append(String.join("<br>", resSumRate));
			resBuilder.append("<br><br>");
		}

		responseVO.setOk(StringUtils.isNotEmpty(resBuilder.toString()) ? resBuilder.toString() : "SUCC");
		return responseVO;
	}
	
	public ResponseVO selectLabNoteBomMateView(PilotRequestDetailReqDTO pilotRequestDetailReqDTO) {
		ResponseVO responseVO = new ResponseVO();
		
		List<PilotRequestDTO> lotList = hbdProcessMapper.selectLabNoteApprBomLotList(pilotRequestDetailReqDTO);
		List<PilotRequestMateDTO> bomList = null;
		if (lotList != null && !lotList.isEmpty()) {
			bomList = this.selectLabNoteBomMateRateInfo(pilotRequestDetailReqDTO);
		}
		
		responseVO.setOk(PilotRequestResDTO.<HbdNoteInfoDTO>builder()
				.lotList(lotList)
				.bomList(bomList)
				.build());
		
		return responseVO;
	}

	public ResponseVO selectAerosolDecideList(String vLabNoteCd) {
		ResponseVO responseVO = new ResponseVO();
		
		responseVO.setOk(hbdProcessMapper.selectAerosolDecideList(vLabNoteCd, sessionUtil.getLocalLanguage()));
		return responseVO;
	}

	@Transactional
	public ResponseVO saveAerosolFormulaDecide(HbdAerosolDecideReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();
		
		if (!ObjectUtils.isEmpty(reqDTO.getLotList())) {
			for (PilotRequestDTO dto : reqDTO.getLotList()) {
				hbdCommonService.updateLabNoteLotDecide(LotDecideRegDTO.builder()
															.vLabNoteCd(reqDTO.getVLabNoteCd())
															.vContPkCd(dto.getVContPkCd())
															.nVersion(dto.getNVersion())
															.vLotCd(dto.getVLotCd())
															.vPlantCd(dto.getVPlantCd())
															.vPlantMstCd(dto.getVPlantMstCd())
															.vCodeType("AEROSOL")
															.build());
				
				hbdCommonService.updateLabNoteLotComplete(dto.getVLotCd());
			}
		}
		
		responseVO.setOk(null);
		return responseVO;
	}
}
