package com.mybeaker.app.hbd.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.mybeaker.app.labnote.model.LabNoteLotDTO;

@Mapper
public interface HbdApprovalMapper {

	List<LabNoteLotDTO> selectLabNoteApprovalLotList(String vApprCd);
	
	int updateLabNoteLotApprCdClear(String vLotCd);
	
}
