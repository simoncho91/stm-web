package com.mybeaker.app.hbd.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@Data
public class HbdNoteMateVO extends ParentDTO {

	@JsonProperty("vMatePkCd")
	private String vMatePkCd;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vGrpCd")
	private String vGrpCd;

	@JsonProperty("vMateCd")
	private String vMateCd;

	@JsonProperty("vMateDbTypeCd")
	private String vMateDbTypeCd;

	@JsonProperty("vMateDbMstCd")
	private String vMateDbMstCd;

	@JsonProperty("vMateNm")
	private String vMateNm;

	@JsonProperty("nReqRate")
	private String nReqRate;

	@JsonProperty("vFlagReq")
	private String vFlagReq;

	@JsonProperty("nCounterRate")
	private String nCounterRate;

	@JsonProperty("vFlagCounter")
	private String vFlagCounter;

	@JsonProperty("vFlagMateHide")
	private String vFlagMateHide;

	@JsonProperty("vFlagMateCheck")
	private String vFlagMateCheck;

	@JsonProperty("nSort")
	private int nSort;

	@JsonProperty("vRamaMemoTxt")
	private String vRamaMemoTxt;
	
	@JsonProperty("vFlagMainIngredientMate")
	private String vFlagMainIngredientMate;

	@JsonProperty("vFlagDel")
	private String vFlagDel;
	
	@JsonProperty("nPreVersion")
	private int nPreVersion;

	@Builder
	public HbdNoteMateVO(String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm, String vMatePkCd,
			String vContPkCd, int nVersion, String vLabNoteCd, String vGrpCd, String vMateCd, String vMateDbTypeCd,
			String vMateDbMstCd, String vMateNm, String nReqRate, String vFlagReq, String nCounterRate,
			String vFlagCounter, String vFlagMateHide, String vFlagMateCheck, int nSort, String vRamaMemoTxt,
			String vFlagMainIngredientMate, String vFlagDel, int nPreVersion) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.vMatePkCd = vMatePkCd;
		this.vContPkCd = vContPkCd;
		this.nVersion = nVersion;
		this.vLabNoteCd = vLabNoteCd;
		this.vGrpCd = vGrpCd;
		this.vMateCd = vMateCd;
		this.vMateDbTypeCd = vMateDbTypeCd;
		this.vMateDbMstCd = vMateDbMstCd;
		this.vMateNm = vMateNm;
		this.nReqRate = nReqRate;
		this.vFlagReq = vFlagReq;
		this.nCounterRate = nCounterRate;
		this.vFlagCounter = vFlagCounter;
		this.vFlagMateHide = vFlagMateHide;
		this.vFlagMateCheck = vFlagMateCheck;
		this.nSort = nSort;
		this.vRamaMemoTxt = vRamaMemoTxt;
		this.vFlagMainIngredientMate = vFlagMainIngredientMate;
		this.vFlagDel = vFlagDel;
		this.nPreVersion = nPreVersion;
	}
}
