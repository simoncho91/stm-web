package com.mybeaker.app.hbd.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class HbdNoteStabilityValueVO {

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("vStabilityCd")
	private String vStabilityCd;

	@JsonProperty("vGramTrCd")
	private String vGramTrCd;

	@JsonProperty("vFlagStability")
	private String vFlagStability;
	
	@JsonProperty("vKey")
	private String vKey;
}
