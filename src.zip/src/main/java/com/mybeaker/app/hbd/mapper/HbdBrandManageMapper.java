package com.mybeaker.app.hbd.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.mybeaker.app.hbd.model.HbdNoteInfoRegDTO;
import com.mybeaker.app.hbd.model.HbdNoteRequestContDTO;

@Mapper
public interface HbdBrandManageMapper {

	int updateReqPrdMstInfo(HbdNoteInfoRegDTO hbdNoteInfoRegDTO);

	void deleteLabNoteMstTag(HbdNoteInfoRegDTO hbdNoteInfoRegDTO);

	void updateNoteContEtc(HbdNoteRequestContDTO dto);

}
