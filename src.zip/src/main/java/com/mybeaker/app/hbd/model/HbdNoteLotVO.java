package com.mybeaker.app.hbd.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@Data
public class HbdNoteLotVO extends ParentDTO {

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vLotNm")
	private String vLotNm;

	@JsonProperty("vFlagDecide")
	private String vFlagDecide;

	@JsonProperty("vFlagNotice")
	private String vFlagNotice;

	@JsonProperty("vFlagComplete")
	private String vFlagComplete;

	@JsonProperty("vFlagLotHide")
	private String vFlagLotHide;

	@JsonProperty("nGramOpenNum")
	private int nGramOpenNum;

	@JsonProperty("nPilotTestSeqno")
	private int nPilotTestSeqno;

	@JsonProperty("vPilotTestDtm")
	private String vPilotTestDtm;

	@JsonProperty("vApprCd")
	private String vApprCd;

	@JsonProperty("vFlagBomReq")
	private String vFlagBomReq;

	@JsonProperty("vFlagIngredientReq")
	private String vFlagIngredientReq;

	@JsonProperty("vEffectDtm")
	private String vEffectDtm;

	@JsonProperty("vTrPrdCd")
	private String vTrPrdCd;

	@JsonProperty("vTestType")
	private String vTestType;

	@JsonProperty("vTestValue")
	private String vTestValue;

	@JsonProperty("vPh")
	private String vPh;

	@JsonProperty("vLotMemo")
	private String vLotMemo;

	@JsonProperty("vFlagExposure")
	private String vFlagExposure;

	@JsonProperty("vFlagStability")
	private String vFlagStability;

	@JsonProperty("vFlagUse")
	private String vFlagUse;

	@JsonProperty("vFlagSend")
	private String vFlagSend;

	@JsonProperty("nSort")
	private int nSort;

	@JsonProperty("vFlagBookmark")
	private String vFlagBookmark;

	@JsonProperty("vLotTestMemo")
	private String vLotTestMemo;

	@JsonProperty("vFlagFinal")
	private String vFlagFinal;

	@JsonProperty("vFlagExistsBom")
	private String vFlagExistsBom;

	@JsonProperty("vFlagTransferBase")
	private String vFlagTransferBase;

	@JsonProperty("vTumnTsntLotStCd")
	private String vTumnTsntLotStCd;
	
	@JsonProperty("vFlagToHundred")
	private String vFlagToHundred;

	private String language;

	@Builder
	public HbdNoteLotVO(String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm, String vLotCd,
			String vContPkCd, int nVersion, String vLabNoteCd, String vLotNm, String vFlagDecide, String vFlagNotice,
			String vFlagComplete, String vFlagLotHide, int nGramOpenNum, int nPilotTestSeqno, String vPilotTestDtm,
			String vApprCd, String vFlagBomReq, String vFlagIngredientReq, String vEffectDtm, String vTrPrdCd,
			String vTestType, String vTestValue, String vPh, String vLotMemo, String vFlagExposure,
			String vFlagStability, String vFlagUse, String vFlagSend, int nSort, String vFlagBookmark,
			String vLotTestMemo, String vFlagFinal, String vFlagExistsBom, String vFlagTransferBase,
			String vTumnTsntLotStCd, String vFlagToHundred, String language) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.vLotCd = vLotCd;
		this.vContPkCd = vContPkCd;
		this.nVersion = nVersion;
		this.vLabNoteCd = vLabNoteCd;
		this.vLotNm = vLotNm;
		this.vFlagDecide = vFlagDecide;
		this.vFlagNotice = vFlagNotice;
		this.vFlagComplete = vFlagComplete;
		this.vFlagLotHide = vFlagLotHide;
		this.nGramOpenNum = nGramOpenNum;
		this.nPilotTestSeqno = nPilotTestSeqno;
		this.vPilotTestDtm = vPilotTestDtm;
		this.vApprCd = vApprCd;
		this.vFlagBomReq = vFlagBomReq;
		this.vFlagIngredientReq = vFlagIngredientReq;
		this.vEffectDtm = vEffectDtm;
		this.vTrPrdCd = vTrPrdCd;
		this.vTestType = vTestType;
		this.vTestValue = vTestValue;
		this.vPh = vPh;
		this.vLotMemo = vLotMemo;
		this.vFlagExposure = vFlagExposure;
		this.vFlagStability = vFlagStability;
		this.vFlagUse = vFlagUse;
		this.vFlagSend = vFlagSend;
		this.nSort = nSort;
		this.vFlagBookmark = vFlagBookmark;
		this.vLotTestMemo = vLotTestMemo;
		this.vFlagFinal = vFlagFinal;
		this.vFlagExistsBom = vFlagExistsBom;
		this.vFlagTransferBase = vFlagTransferBase;
		this.vTumnTsntLotStCd = vTumnTsntLotStCd;
		this.vFlagToHundred = vFlagToHundred;
		this.language = language;
	}
}
