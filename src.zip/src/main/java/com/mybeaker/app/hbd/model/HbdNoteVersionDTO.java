package com.mybeaker.app.hbd.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.PositiveOrZero;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class HbdNoteVersionDTO {

	@NotEmpty
	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@PositiveOrZero
	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("vFlagView")
	private String vFlagView;
	
	@JsonProperty("vFlagPriceHide")
	private String vFlagPriceHide;

	@JsonProperty("vFlagReqHide")
	private String vFlagReqHide;

	@JsonProperty("vFlagMaxmixHide")
	private String vFlagMaxmixHide;

	@JsonProperty("vFlagExistHide")
	private String vFlagExistHide;

	@JsonProperty("vFlagInpMethod")
	private String vFlagInpMethod;

	@JsonProperty("vCounterCd")
	private String vCounterCd;

	@JsonProperty("vCounterContPkCd")
	private String vCounterContPkCd;

	@JsonProperty("vVersionNm")
	private String vVersionNm;
}
