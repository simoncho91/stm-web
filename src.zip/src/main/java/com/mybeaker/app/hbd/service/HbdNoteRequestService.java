package com.mybeaker.app.hbd.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Service;

import com.mybeaker.app.common.form.MailForm;
import com.mybeaker.app.common.model.AlarmRegDTO;
import com.mybeaker.app.common.model.MailDTO;
import com.mybeaker.app.common.model.MessageDTO;
import com.mybeaker.app.common.model.ResultDTO;
import com.mybeaker.app.common.service.CommonService;
import com.mybeaker.app.hbd.mapper.HbdNoteRequestMapper;
import com.mybeaker.app.hbd.model.HbdLabNoteExperimentVO;
import com.mybeaker.app.hbd.model.HbdNoteContDTO;
import com.mybeaker.app.hbd.model.HbdNoteInfoDTO;
import com.mybeaker.app.hbd.model.HbdNoteInfoRegDTO;
import com.mybeaker.app.hbd.model.HbdNoteLotDTO;
import com.mybeaker.app.hbd.model.HbdNoteMateVO;
import com.mybeaker.app.hbd.model.HbdNoteRateVO;
import com.mybeaker.app.hbd.model.HbdNoteRequestContDTO;
import com.mybeaker.app.hbd.model.HbdNoteVersionDTO;
import com.mybeaker.app.hbd.model.InsertHbdNoteHalfRegDTO;
import com.mybeaker.app.labnote.model.BrandManagerGroupDTO;
import com.mybeaker.app.labnote.model.BrandManagerShareDTO;
import com.mybeaker.app.labnote.model.ElabChgLogDTO;
import com.mybeaker.app.labnote.model.ElabChgLogSearchReqDTO;
import com.mybeaker.app.labnote.model.ElabShelflifeContVO;
import com.mybeaker.app.labnote.model.IssueTrackerNoteInfoDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonListResDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonReqDevelopCancelDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonRequestMateDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonTagDTO;
import com.mybeaker.app.labnote.model.LabNoteDecideDTO;
import com.mybeaker.app.labnote.model.LabNoteMstVersionDTO;
import com.mybeaker.app.labnote.model.LabNoteRequestMateRegDTO;
import com.mybeaker.app.labnote.model.LabNoteVersionDTO;
import com.mybeaker.app.labnote.model.LabNoteVersionModifyReqDTO;
import com.mybeaker.app.labnote.model.LabNoteVersionRegDTO;
import com.mybeaker.app.labnote.model.LaunchCompleteContDTO;
import com.mybeaker.app.labnote.model.LaunchCompleteReqDTO;
import com.mybeaker.app.labnote.model.PlantChangeReqDTO;
import com.mybeaker.app.labnote.model.PlantExtendDTO;
import com.mybeaker.app.labnote.model.PlantExtendReqDTO;
import com.mybeaker.app.labnote.model.PlantExtendResDTO;
import com.mybeaker.app.labnote.model.ProductVersionHistoryDTO;
import com.mybeaker.app.labnote.model.ProductVersionHistoryResDTO;
import com.mybeaker.app.labnote.model.ZmdMaterialReqDTO;
import com.mybeaker.app.labnote.service.LabNoteCommonService;
import com.mybeaker.app.model.Const;
import com.mybeaker.app.model.dto.PagingDTO;
import com.mybeaker.app.model.dto.ResCommSearchInfoDTO;
import com.mybeaker.app.model.enums.CommonResultCode;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.skincare.model.BookmarkReqDTO;
import com.mybeaker.app.skincare.model.BookmarkVO;
import com.mybeaker.app.skincare.model.LabNoteExperimentReqDTO;
import com.mybeaker.app.skincare.model.LabNoteHal4VO;
import com.mybeaker.app.skincare.model.LabNoteNonPrdVO;
import com.mybeaker.app.skincare.model.MaterialSearchVO;
import com.mybeaker.app.utils.CommonUtil;
import com.mybeaker.app.utils.ConvertUtil;
import com.mybeaker.app.utils.MailUtil;
import com.mybeaker.app.utils.SessionUtil;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class HbdNoteRequestService {
	private final HbdNoteRequestMapper hbdNoteRequestMapper;

	private final LabNoteCommonService labNoteCommonService;

	private final HbdCommonService hbdCommonService;

	private final HbdMaterialService hbdMaterialService;

	private final SessionUtil sessionUtil;

	private final MessageSourceAccessor messageSource;

	private final CommonService commonService;

	public ResponseVO selectReqList(LabNoteExperimentReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		reqDTO.setVListType(StringUtils.defaultIfEmpty(reqDTO.getVListType(), "HAL3"));
		reqDTO.setVSortCol(StringUtils.defaultIfEmpty(reqDTO.getVSortCol(), "MCONT.V_LAB_NOTE_CD"));
		reqDTO.setVSortDir(StringUtils.defaultIfEmpty(reqDTO.getVSortDir(), "DESC"));
		reqDTO.setLanguage(sessionUtil.getLangCd());

		String checkAdmin = labNoteCommonService.checkLabNoteAdmin("HBO", "N");

		if("F".equals(checkAdmin)) {
			reqDTO.setVFlagMyLabNote(StringUtils.defaultIfEmpty(reqDTO.getVFlagMyLabNote(), "Y"));
			if ("Y".equals(reqDTO.getVFlagMyLabNote())) {
				reqDTO.setVFlagIncLabNote("Y");
			}
		}
		else {
			reqDTO.setVFlagMyLabNote(StringUtils.defaultIfEmpty(reqDTO.getVFlagMyLabNote(), sessionUtil.getGroups().stream()
					.filter(o -> o.equals("S000246"))
					.count() > 0 ? "Y" : "N"));

			if ("Y".equals(checkAdmin)) {
				reqDTO.setVSysadminYn("Y");
			}
		}

		reqDTO.setVFlagLabNote("N");

		if("Y".equals(reqDTO.getVFlagMyLabNote()) || "Y".equals(reqDTO.getVFlagIncLabNote())) {
			reqDTO.setVFlagLabNote("Y");
			reqDTO.setVUserid(sessionUtil.getLoginId());
		}

		String listType = reqDTO.getVListType();
		int recordCnt = 0;

		List<HbdLabNoteExperimentVO> list = null;
		List<LabNoteHal4VO> hal4List = null;
		List<LabNoteNonPrdVO> nonPrdList = null;
		if("HAL3".equals(listType)) {
			if (StringUtils.isNotEmpty(reqDTO.getVStateType())) {
				reqDTO.setVDeptCd(sessionUtil.getSigmaDeptcd());
			}

			recordCnt = hbdNoteRequestMapper.selectHboRequstListCount(reqDTO);

			if (recordCnt > 0) {
				CommonUtil.setPaging(reqDTO, recordCnt);
				list = hbdNoteRequestMapper.selectHboRequstList(reqDTO);
			}
		}
		else if("HAL4".equals(listType)) {
			recordCnt = hbdNoteRequestMapper.selectHal4RequstListCount(reqDTO);

			if (recordCnt > 0) {
				CommonUtil.setPaging(reqDTO, recordCnt);
				hal4List = hbdNoteRequestMapper.selectHal4RequstList(reqDTO);
			}
		}
		else if("NONPRD".equals(listType)) {
			reqDTO.setVUserid(sessionUtil.getLoginId());
			recordCnt = hbdNoteRequestMapper.selectNonPrdRequstListCount(reqDTO);

			if (recordCnt > 0) {
				CommonUtil.setPaging(reqDTO, recordCnt);
				nonPrdList = hbdNoteRequestMapper.selectNonPrdRequstList(reqDTO);
			}
		}

		responseVO.setOk(LabNoteCommonListResDTO.builder()
				.page(ConvertUtil.convert(reqDTO, PagingDTO.class))
				.list(Optional.ofNullable(list == null ? hal4List == null ? nonPrdList : hal4List : list)
						.orElseGet(() -> List.of()))
				.vFlagMyLabNote(reqDTO.getVFlagMyLabNote())
				.build());
		return responseVO;
	}

	public ResponseVO selectReqInfo(String vLabNoteCd, String vPageFlag) {
		ResponseVO responseVO = new ResponseVO();
		HbdNoteInfoDTO resDTO = null;
		List<String> arrTag1Cd = Arrays.asList("MTI01", "LNC12", "LNC13", "LNC15", "LNC02", "MTR04", "MTR05", "MTR06");
		if (StringUtils.isNotEmpty(vLabNoteCd)) {
			resDTO = hbdCommonService.selectLabNoteInfo(vLabNoteCd);

			if (resDTO != null) {
				MaterialSearchVO schVO = new MaterialSearchVO();

				schVO.setVLabNoteCd(vLabNoteCd);
				schVO.setVUserId(sessionUtil.getLoginId());

				hbdCommonService.selectElabNoteAuth(schVO, resDTO);
				List<String> groups = sessionUtil.getGroups();

				if (!"Y".equals(schVO.getVIsPersonInCharge()) &&
						!"Y".equals(schVO.getVIsRelatedPerson()) &&
						!"Y".equals(schVO.getVIsLabNoteAdmin()) &&
						(!ObjectUtils.isEmpty(groups) && groups.stream().anyMatch(group -> "S000118;S000246;S000000;".indexOf(group) == -1)) &&
						!"Y".equals(labNoteCommonService.checkLabNoteAuth("HBO", resDTO.getVStatusCd(), resDTO.getVDeptCd()))) {
					responseVO.setOkWithCode("C9999", CommonResultCode.NO_AUTH, null);
					return responseVO;
				}
			}

			Optional<HbdNoteInfoDTO> optional = Optional.ofNullable(resDTO);

			optional.ifPresentOrElse((dto) -> {
				Map<String, List<LabNoteCommonTagDTO>> tagMap = hbdCommonService.selectLabNoteRequestTagList(arrTag1Cd, vLabNoteCd);

				List<LabNoteCommonTagDTO> effectList = tagMap.get("LNC15");
				List<LabNoteCommonTagDTO> tuserList = tagMap.get("LNC12");

				if (effectList != null && !effectList.isEmpty()) {
					effectList = effectList.stream().filter(vo -> vo.getVBuffer1().indexOf("HBO") > -1).collect(Collectors.toList());
				}

				if (tuserList != null && !tuserList.isEmpty()) {
					tuserList = tuserList.stream().filter(vo -> "NOTE".equals(vo.getVBuffer1())).collect(Collectors.toList());
				}

				dto.setMti01List(tagMap.get("MTI01"));
				dto.setEffectList(effectList);
				dto.setTuserList(tuserList);
				dto.setReqEtcList(tagMap.get("LNC13"));
				dto.setReleaseList(tagMap.get("LNC02"));
				dto.setMtr04List(tagMap.get("MTR04"));
				dto.setMtr05List(tagMap.get("MTR05"));
				dto.setMtr06List(tagMap.get("MTR06"));
				dto.setPjtList(hbdNoteRequestMapper.selectLabNotePjtList(vLabNoteCd));
				dto.setContList(hbdCommonService.selectRequestContList(vLabNoteCd, "HAL3"));

				if ("REG".equals(vPageFlag)) {
					dto.setVIsLabNoteAdmin(labNoteCommonService.checkLabNoteAdmin("HBO", "N"));
				} else {
					String isLabNoteAdmin = this.isLabNoteRequestAdmin(dto, "N");
					String isLabNoteStatus = this.isLabNoteRequestStatus(dto);
					dto.setVIsLabNoteAdmin(isLabNoteAdmin);
					dto.setVIsLabNoteStatus(isLabNoteStatus);

					if ("LNC06_50".equals(dto.getVStatusCd())) {
						dto.setCompContList(hbdNoteRequestMapper.selectLabNoteDecideContInfoList(vLabNoteCd, "HAL3", sessionUtil.getLocalLanguage()));

						if (dto.getContList() != null && !dto.getContList().isEmpty()) {
							List<HbdNoteRequestContDTO> contList = dto.getContList().stream().filter(cont -> !"Y".equals(cont.getVFlagCancel())).collect(Collectors.toList());

							if (contList != null && !contList.isEmpty()) {
								dto.setReleaseDateList(labNoteCommonService.selectMultiContReleaseDateList(contList));
							}
						}
					} else {
						String flagAllDecide = hbdNoteRequestMapper.checkFlagAllDecide(vLabNoteCd);

						if ("CN20".equals(dto.getVPlantCd()) || "Y".equals(dto.getVFlagOem())) {
							dto.setVFlagAllDecide(flagAllDecide);
						} else {
							dto.setVFlagAllDecide("LNC06_51".equals(dto.getVStatusCd()) ? flagAllDecide : "N");
						}

						dto.setVFlagMassAppr(hbdNoteRequestMapper.selectLabNoteFlagMassAppr(vLabNoteCd));
					}

					dto.setCounterList(hbdNoteRequestMapper.selectLabNoteThisCounterList(vLabNoteCd, dto.getVContPkCd(), sessionUtil.getLocalLanguage()));
				}

				List<LabNoteMstVersionDTO> verList = hbdCommonService.selectLabNoteMstVerList(vLabNoteCd);
				dto.setVerList(verList);

				int nVersion = verList != null && !verList.isEmpty() ? verList.get(verList.size() - 1).getNVersion() : 1;
				LabNoteVersionDTO versionInfo = this.selectLabNoteMstVerInfo(vLabNoteCd, nVersion);

				dto.setVersionInfo(versionInfo);
				dto.setFuncTagList(hbdNoteRequestMapper.selectEvMaterialFunctionTagList(vLabNoteCd, sessionUtil.getLocalLanguage()));

				responseVO.setOk(dto);
			}, () -> {
				responseVO.setOkWithCode(Const.FAIL, "", null);
			});
		} else {
			Map<String, List<LabNoteCommonTagDTO>> tagMap = hbdCommonService.selectLabNoteRequestTagList(arrTag1Cd, vLabNoteCd);
			List<LabNoteCommonTagDTO> effectList = tagMap.get("LNC15");
			List<LabNoteCommonTagDTO> tuserList = tagMap.get("LNC12");

			if (effectList != null && !effectList.isEmpty()) {
				effectList = effectList.stream().filter(vo -> vo.getVBuffer1().indexOf("HBO") > -1).collect(Collectors.toList());
			}

			if (tuserList != null && !tuserList.isEmpty()) {
				tuserList = tuserList.stream().filter(vo -> "NOTE".equals(vo.getVBuffer1())).collect(Collectors.toList());
			}

			LabNoteVersionDTO versionInfo = LabNoteVersionDTO.builder()
					.funcList(this.selectLabNoteMstVerTagList("EV_MATERIAL_FUNC2", vLabNoteCd, 0))
					.build();

			resDTO = HbdNoteInfoDTO.builder()
							.mti01List(tagMap.get("MTI01"))
							.effectList(effectList)
							.tuserList(tuserList)
							.reqEtcList(tagMap.get("LNC13"))
							.releaseList(tagMap.get("LNC02"))
							.mtr04List(tagMap.get("MTR04"))
							.mtr05List(tagMap.get("MTR05"))
							.mtr06List(tagMap.get("MTR06"))
							.versionInfo(versionInfo)
							.vIsLabNoteAdmin(labNoteCommonService.checkLabNoteAdmin("HBO", "N"))
							.build();

			if (StringUtils.isNotEmpty(labNoteCommonService.selectLabNoteLaborCd(sessionUtil.getLoginId()))) {
				resDTO.setVUserid(sessionUtil.getLoginId());
				resDTO.setVUsernm(sessionUtil.getUserNm());
				resDTO.setVDeptCd(sessionUtil.getSigmaDeptcd());
			}

			responseVO.setOk(resDTO);
		}

		return responseVO;
	}

	private String isLabNoteRequestStatus(HbdNoteInfoDTO dto) {
		List<String> arrStatuscd = Arrays.asList("LNC06_01", "LNC06_02", "LNC06_03", "LNC06_04",
				"LNC06_06", "LNC06_21", "LNC06_22", "LNC06_24",
				"LNC06_25", "LNC06_26", "LNC06_30", "LNC06_31",
				"LNC06_32", "LNC06_40");

		return arrStatuscd.contains(dto.getVStatusCd()) ? "Y" : "N";
	}

	private String isLabNoteRequestAdmin(HbdNoteInfoDTO dto, String flagAuthCheckNonprd) {
		boolean isLabNoteAdmin = sessionUtil.isSysadmin()
				|| sessionUtil.getLoginId().equals(dto.getVUserid())
				|| "Y".equals(labNoteCommonService.checkLabNoteAdmin("HBO", flagAuthCheckNonprd));
		return isLabNoteAdmin ? "Y" : "N";
	}

	private List<LabNoteCommonTagDTO> selectLabNoteMstVerTagList(String tag1Cd, String vLabNoteCd, int nVersion) {
		return hbdNoteRequestMapper.selectLabNoteMstVerTagList(tag1Cd, vLabNoteCd, nVersion, sessionUtil.getLocalLanguage());
	}

	@Transactional
	public ResponseVO updateElabNoteCancelInfo(LabNoteCommonReqDevelopCancelDTO cancelDTO) {
		ResponseVO responseVO = new ResponseVO();
		String vLabNoteCd = cancelDTO.getVLabNoteCd();
		String vMessage = cancelDTO.getVMessage();

		int result = hbdCommonService.updateNoteStatusCd(vLabNoteCd, "LNC06_41");

		if (result > 0) {
			labNoteCommonService.insertMessage(MessageDTO.builder()
												.vRecordid(vLabNoteCd)
												.vMessage(vMessage)
												.build());

			String vUrl = new StringBuilder()
								.append("/hbd/")
								.append("all-lab-note-")
								.append(cancelDTO.getVNotePageType())
								.append("-view?vLabNoteCd=")
								.append(vLabNoteCd)
								.toString();
			commonService.sendAlarm(AlarmRegDTO.builder()
								.vLabNoteCd(vLabNoteCd)
								.vStatusCd("AL_NOTE0")
								.vAlrTypeCd("AL_NOTE0_06")
								.typeList(Arrays.asList(Const.ALARM, Const.TIMELINE))
								.vContNm(cancelDTO.getVContNm())
								.vContCd(cancelDTO.getVContCd())
								.vNoteType("HBO")
								.vMoveUrl(vUrl)
								.userList(hbdNoteRequestMapper.selectNoteCancelAlarmReceiveUserList(vLabNoteCd, sessionUtil.getLoginId()))
								.build());

			responseVO.setCreateOk(null);
		} else {
			responseVO.setOkWithCode("C9999", CommonResultCode.SAVE_FAIL, null);;
		}

		return responseVO;
	}

	@Transactional
	public ResponseVO updateElabNoteRestart(LabNoteCommonReqDevelopCancelDTO labNoteCommonReqDevelopCancelDTO) {
		ResponseVO responseVO = new ResponseVO();

		String statusCd = hbdCommonService.selectLabNoteStatusCd(labNoteCommonReqDevelopCancelDTO.getVLabNoteCd());
		int result = hbdCommonService.updateNoteStatusCd(labNoteCommonReqDevelopCancelDTO.getVLabNoteCd(), statusCd);

		if (result > 0) {
			responseVO.setCreateOk(null);
		} else {
			responseVO.setOkWithCode("C9999", CommonResultCode.SAVE_FAIL, null);
		}

		return responseVO;
	}

	public ResponseVO selectLabNoteContPlantInfoList(String vLabNoteCd, String vCodeType) {
		ResponseVO responseVO = new ResponseVO();

		List<PlantExtendDTO> contList = hbdNoteRequestMapper.selectLabNoteContPlantInfoList(vLabNoteCd, vCodeType);

		contList.forEach(dto -> {
			dto.setPlantList(hbdNoteRequestMapper.selectLabNotePlantExpansionList(vLabNoteCd, vCodeType, dto.getVContCd()));
		});

		responseVO.setCreateOk(contList);
		return responseVO;
	}

	@Transactional
	public ResponseVO insertLabNotePlantExpansion (PlantExtendReqDTO plantExtendReqDTO) {
		ResponseVO responseVO = new ResponseVO();

		if (plantExtendReqDTO.getExtendContList() == null || plantExtendReqDTO.getExtendContList().isEmpty()) {
			responseVO.setOkWithCode("C9999", CommonResultCode.NO_ESSENTIAL_DATA, null);
			return responseVO;
		}

		List<BookmarkVO> bookmarkList = hbdNoteRequestMapper.selectLabNotePlantExpansionBookmarkList(plantExtendReqDTO);

		List<String> copyList = new ArrayList<String>();
		List<String> copyFailList = new ArrayList<String>();
		String resultContCd = "";
		int shelfLifeCnt = 0;
		String changeReason = "";

		for (PlantExtendDTO dto : plantExtendReqDTO.getExtendContList()) {
			resultContCd = labNoteCommonService.checkPlantExpansionBookmark(bookmarkList, dto.getVContCd());

			if (StringUtils.isNotEmpty(resultContCd)) {
				copyList.add(resultContCd);
			} else {
				copyFailList.add(dto.getVContCd());
			}

			labNoteCommonService.insertSAPMaterialReqVerPlantExp(ZmdMaterialReqDTO.builder()
									.vLabNoteCd(plantExtendReqDTO.getVLabNoteCd())
									.mtart(plantExtendReqDTO.getVCodeType())
									.hal1t("")
									.maktxEn(dto.getVContNmEn())
									.maktxKo(dto.getVContNm())
									.maktxZh(dto.getVContNmCn())
									.meins("G")
									.pflag("C")
									.flag(plantExtendReqDTO.getVNoteType())
									.vNoteType(plantExtendReqDTO.getVNoteType())
									.brand(plantExtendReqDTO.getVBrdCd())
									.labor(dto.getVLabContCd())
									.manft(dto.getVPlantCd())
									.matnrC(dto.getVContCd())
									.werks(dto.getVPlantCd())
									.originalContPkCd(dto.getVContPkCd())
									.matkl("")
									.vRegUserid(sessionUtil.getLoginId())
									.build());

			shelfLifeCnt = labNoteCommonService.selectShelfLifePlantCount(dto.getVContCd());

			if (shelfLifeCnt > 0) {
				labNoteCommonService.updateSubPlantFlag(dto.getVContCd());
				labNoteCommonService.insertShelfLifeSubPlant(dto.getVContCd(), dto.getVPlantCd());

				changeReason = "실험노트에서 플랜트코드 [" + dto.getVPlantCd() + "]를 확장 하였습니다.";
				labNoteCommonService.insertShelfListHis(dto.getVContCd(), changeReason);
			}
		}

		responseVO.setCreateOk(PlantExtendResDTO.builder()
						.copyList(copyList)
						.copyFailList(copyFailList)
						.build());
		return responseVO;
	}

	public ResponseVO selectLabNoteSavePlantList(String vLabNoteCd) {
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(hbdNoteRequestMapper.selectLabNoteSavePlantList(vLabNoteCd));
		return responseVO;
	}

	public ResponseVO updatePlantAndSiteType(PlantChangeReqDTO plantChangeReqDTO) {
		ResponseVO responseVO = new ResponseVO();

		int result = hbdNoteRequestMapper.updatePlantAndSiteType(plantChangeReqDTO);

		String oldPlantCd = StringUtils.isNotEmpty(plantChangeReqDTO.getVOldPlantCd()) ? plantChangeReqDTO.getVOldPlantCd() : "";
		String plantCd = StringUtils.isNotEmpty(plantChangeReqDTO.getVPlantCd()) ? plantChangeReqDTO.getVPlantCd() : "";
		String shelfLifeOldPlantCd = "";
		if (result > 0) {
			if (!oldPlantCd.equals(plantCd)) {
				// 대표 플랜트 - 내용물코드의 제품코드 값을 나머지 플랜트에 복사합니다.
				hbdNoteRequestMapper.updateCopyPrdCd(plantChangeReqDTO);

				// 모든 대표 플랜트 여부를 해제합니다.
				hbdNoteRequestMapper.updateFlagRepresentN(plantChangeReqDTO.getVLabNoteCd());

				// 모든 대표 플랜트 여부를 해제합니다.
				hbdNoteRequestMapper.updateFlagRepresentY(plantChangeReqDTO);

				//[S]실험노트 - 사용기한 플랜트확장 추가 수정//
				//사용기한에 등록되어있는 내용물코드의 대표플랜트를 수정한다.
				//1.대표및 홋수내용물코드 가져오기
				List<String> contList = hbdNoteRequestMapper.selectContList(plantChangeReqDTO.getVLabNoteCd());
				List<ElabShelflifeContVO> plantList = null;
				for (String contCd : contList) {
					//각 내용물코드가 가지고 있는 사용기한플랜트 확인하기
					plantList = labNoteCommonService.selectShelfLifePlant(plantChangeReqDTO);

					if (plantList != null && !plantList.isEmpty()) {
						for (ElabShelflifeContVO vo : plantList) {
							//변경하려는 대표플랜트가 서브플랜트테이블에 포함되어 있는 경우
							if ("N".equals(vo.getVFlag())) {
								//기존 대표플랜트값 확인
								shelfLifeOldPlantCd = labNoteCommonService.selectShelfOldPlantCd(contCd);

								//기존 대표플랜트를 변경하려는 대표플랜트로 수정
								labNoteCommonService.updateShelfLifeContPlant(plantCd, contCd);

								//서브플랜트에  변경하려는 대표플랜트값 삭제
								labNoteCommonService.deleteShelfLifeSubPlant(contCd);

								//서브플랜트에 기존 대표플랜트를 서브로 추가
								labNoteCommonService.insertShelfLifeSubPlant(contCd, shelfLifeOldPlantCd);
							}
						}
					}
				}

				//[E]실험노트 - 사용기한 플랜트확장 추가 수정//
			}

			responseVO.setCreateOk(null);
		} else {
			responseVO.setOkWithCode("C9999", CommonResultCode.SAVE_FAIL, null);
			return responseVO;
		}

		return responseVO;
	}

	public ResponseVO selectLabNoteChgLogList(ElabChgLogSearchReqDTO elabChgLogSearchReqDTO) {
		ResponseVO responseVO = new ResponseVO();
		int totalCnt = hbdNoteRequestMapper.selectLabNoteChgLogListCount(elabChgLogSearchReqDTO);
		List<ElabChgLogDTO> list = null;
		CommonUtil.setPaging(elabChgLogSearchReqDTO, totalCnt);

		if (totalCnt > 0) {
			elabChgLogSearchReqDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
			list = hbdNoteRequestMapper.selectLabNoteChgLogList(elabChgLogSearchReqDTO);
		}

		PagingDTO page = ConvertUtil.convert(elabChgLogSearchReqDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
										.page(page)
										.list(list)
										.build();
		responseVO.setOk(res);
		return responseVO;
	}

	public LabNoteVersionDTO selectLabNoteMstVerInfo(String vLabNoteCd, int nVersion) {
		LabNoteVersionDTO versionInfo = hbdCommonService.selectLabNoteMstVerInfo(vLabNoteCd, nVersion);

		if (versionInfo == null) {
			versionInfo = new LabNoteVersionDTO();
		}

		versionInfo.setFuncList(this.selectLabNoteMstVerTagList("EV_MATERIAL_FUNC2", vLabNoteCd, nVersion));
		List<LabNoteCommonRequestMateDTO> mateList = hbdNoteRequestMapper.selectLabNoteRequestMateList(vLabNoteCd, nVersion);

		if (mateList != null && !mateList.isEmpty()) {
			versionInfo.setNewMateList(mateList.stream().filter(vo -> "LNC19_NEW".equals(vo.getVAddTypeCd())).collect(Collectors.toList()));
			versionInfo.setPerfMateList(mateList.stream().filter(vo -> "LNC19_PREF".equals(vo.getVAddTypeCd())).collect(Collectors.toList()));
			versionInfo.setFuncMateList(mateList.stream().filter(vo -> "LNC19_FUNC".equals(vo.getVAddTypeCd())).collect(Collectors.toList()));
			versionInfo.setRequMateList(mateList.stream().filter(vo -> "LNC19_REQU".equals(vo.getVAddTypeCd())).collect(Collectors.toList()));
		}

		return versionInfo;
	}

	public ResponseVO updateLabNoteVersionInfo(LabNoteVersionModifyReqDTO labNoteVersionModifyReqDTO) {
		ResponseVO responseVO = new ResponseVO();
		labNoteVersionModifyReqDTO.setVRegUserid(sessionUtil.getLoginId());
		labNoteVersionModifyReqDTO.setVUpdateUserid(sessionUtil.getLoginId());

		labNoteVersionModifyReqDTO.setVNoteType("HBO");
		int historyCnt = labNoteCommonService.selectVersionHistoryMstCount(labNoteVersionModifyReqDTO);

		if (historyCnt == 0) {
			labNoteVersionModifyReqDTO.setVFirstSaveFlag("Y");
			hbdNoteRequestMapper.insertVersionHistoryMst(labNoteVersionModifyReqDTO);
			hbdNoteRequestMapper.insertVersionHistoryMate(labNoteVersionModifyReqDTO);
		}

		int result = hbdNoteRequestMapper.updateLabNoteVerModify(labNoteVersionModifyReqDTO);

		if (result > 0) {
			this.updateLabNoteMate(LabNoteRequestMateRegDTO.builder()
								.vLabNoteCd(labNoteVersionModifyReqDTO.getVLabNoteCd())
								.vContPkCd(labNoteVersionModifyReqDTO.getVContPkCd())
								.nVersion(labNoteVersionModifyReqDTO.getNVersion())
								.vAddTypeCd("LNC19_NEW")
								.mateList(labNoteVersionModifyReqDTO.getNewMateList())
								.build());

			this.updateLabNoteMate(LabNoteRequestMateRegDTO.builder()
								.vLabNoteCd(labNoteVersionModifyReqDTO.getVLabNoteCd())
								.vContPkCd(labNoteVersionModifyReqDTO.getVContPkCd())
								.nVersion(labNoteVersionModifyReqDTO.getNVersion())
								.vAddTypeCd("LNC19_PREF")
								.mateList(labNoteVersionModifyReqDTO.getPerfMateList())
								.build());

			this.updateLabNoteMate(LabNoteRequestMateRegDTO.builder()
								.vLabNoteCd(labNoteVersionModifyReqDTO.getVLabNoteCd())
								.vContPkCd(labNoteVersionModifyReqDTO.getVContPkCd())
								.nVersion(labNoteVersionModifyReqDTO.getNVersion())
								.vAddTypeCd("LNC19_REQU")
								.mateList(labNoteVersionModifyReqDTO.getRequMateList())
								.build());

			labNoteVersionModifyReqDTO.setVFirstSaveFlag("N");
			hbdNoteRequestMapper.insertVersionHistoryMst(labNoteVersionModifyReqDTO);
			hbdNoteRequestMapper.insertVersionHistoryMate(labNoteVersionModifyReqDTO);

			commonService.sendAlarm(AlarmRegDTO.builder()
										.vLabNoteCd(labNoteVersionModifyReqDTO.getVLabNoteCd())
										.vStatusCd("AL_NOTE2")
										.vAlrTypeCd("AL_NOTE2_03")
										.typeList(Arrays.asList(Const.TIMELINE))
										.vContCd(labNoteVersionModifyReqDTO.getVContCd())
										.vContNm(labNoteVersionModifyReqDTO.getVContNm())
										.nVerNo((labNoteVersionModifyReqDTO.getNVersion() < 10 ? "0" : "") + String.valueOf(labNoteVersionModifyReqDTO.getNVersion()))
										.vNoteType("HBO")
										.build());

			responseVO.setCreateOk(null);
		} else {
			responseVO.setOkWithCode("C9999", CommonResultCode.SAVE_FAIL, null);
		}

		return responseVO;
	}

	@Transactional
	private void updateLabNoteMate(LabNoteRequestMateRegDTO labNoteRequestMateRegDTO) {
		List<LabNoteCommonRequestMateDTO> mateList = labNoteRequestMateRegDTO.getMateList();
		List<LabNoteCommonRequestMateDTO> registerMateList = hbdNoteRequestMapper.selectLabNoteRequestMateListForRegister(labNoteRequestMateRegDTO);

		Map<String, LabNoteCommonRequestMateDTO> map = registerMateList == null
														? new HashMap<>()
														: registerMateList.stream().collect(Collectors.toMap(LabNoteCommonRequestMateDTO::getVMatePkCd, entity -> entity));

		if (mateList != null && !mateList.isEmpty()) {
			for (LabNoteCommonRequestMateDTO dto : mateList) {
				dto.setVLabNoteCd(labNoteRequestMateRegDTO.getVLabNoteCd());
				dto.setVContPkCd(labNoteRequestMateRegDTO.getVContPkCd());
				dto.setNVersion(labNoteRequestMateRegDTO.getNVersion());
				dto.setVAddTypeCd(labNoteRequestMateRegDTO.getVAddTypeCd());
				dto.setVFlagReq("Y");
				dto.setVUpdateUserid(sessionUtil.getLoginId());

				if ("LNC19_FUNC".equals(labNoteRequestMateRegDTO.getVAddTypeCd())) {
					dto.setVFlagMainIngredientMate("Y");
				}

				if ("Y".equals(dto.getVFlagMateNew())) {
					dto.setVRegUserid(sessionUtil.getLoginId());

					hbdNoteRequestMapper.insertLabNoteMate(dto);
				} else {
					hbdNoteRequestMapper.updateLabNoteMate(dto);
					map.remove(dto.getVMatePkCd());
				}
			}
		}

		map.forEach((key, dto) -> {
			hbdNoteRequestMapper.deleteLabNoteVerModifyMate(LabNoteCommonRequestMateDTO.builder()
										.vMatePkCd(dto.getVMatePkCd())
										.vUpdateUserid(sessionUtil.getLoginId())
										.build());
		});
	}

	@Transactional
	public ResponseVO saveLabNotePrdRequest(HbdNoteInfoRegDTO hbdNoteInfoRegDTO) {
		ResponseVO responseVO = new ResponseVO();

		hbdNoteInfoRegDTO.setVRegUserid(sessionUtil.getLoginId());
		hbdNoteInfoRegDTO.setVUpdateUserid(sessionUtil.getLoginId());
		hbdNoteInfoRegDTO.setVLabTypeCd("LNC07_01");
		hbdNoteInfoRegDTO.setVCodeType("HAL3");

		int result = 0;

		if ("R".equals(hbdNoteInfoRegDTO.getFlagAction())) {
			result = this.insertLabNotePrdRequest(hbdNoteInfoRegDTO);
		} else {
			result = this.updateLabNotePrdRequest(hbdNoteInfoRegDTO);
		}

		if (result > 0) {
			responseVO.setOk(hbdNoteInfoRegDTO.getVLabNoteCd());
		} else {
			responseVO.setOkWithCode("C9999", CommonResultCode.SAVE_FAIL, null);
		}

		return responseVO;
	}

	@Transactional
	private int insertLabNotePrdRequest(HbdNoteInfoRegDTO hbdNoteInfoRegDTO) {
		int result = hbdNoteRequestMapper.insertLabNoteMst(hbdNoteInfoRegDTO);

		if (result > 0) {
			LabNoteVersionRegDTO versionInfo = hbdNoteInfoRegDTO.getVersionInfo();
			if (hbdNoteInfoRegDTO.getMstTagList() != null && !hbdNoteInfoRegDTO.getMstTagList().isEmpty()) {
				hbdCommonService.insertLabNoteMstTag(hbdNoteInfoRegDTO);
			}

			if (hbdNoteInfoRegDTO.getPjtList() != null && !hbdNoteInfoRegDTO.getPjtList().isEmpty()) {
				hbdNoteRequestMapper.insertLabNotePjt(hbdNoteInfoRegDTO);
			}

			String contPkCd = "";
			if (hbdNoteInfoRegDTO.getContList() != null && !hbdNoteInfoRegDTO.getContList().isEmpty()) {
				for (HbdNoteRequestContDTO dto : hbdNoteInfoRegDTO.getContList()) {
					dto.setVRegUserid(sessionUtil.getLoginId());
					dto.setVUpdateUserid(sessionUtil.getLoginId());
					dto.setVLabNoteCd(hbdNoteInfoRegDTO.getVLabNoteCd());
					dto.setVCodeType("HAL3");
					dto.setVPlantCd(hbdNoteInfoRegDTO.getVPlantCd());
					hbdNoteRequestMapper.insertLabNoteCont(dto);

					if ("Y".equals(dto.getVFlagRepresent())) {
						contPkCd = dto.getVContPkCd();
					}
				}
			}

			if (versionInfo != null) {
				versionInfo.setVLabNoteCd(hbdNoteInfoRegDTO.getVLabNoteCd());
				versionInfo.setVContPkCd(contPkCd);
				versionInfo.setNVersion(1);
				versionInfo.setVVersionNm("Ver #01");
				versionInfo.setVRegUserid(sessionUtil.getLoginId());
				versionInfo.setVUpdateUserid(sessionUtil.getLoginId());
				hbdNoteRequestMapper.insertLabNoteMstVer(versionInfo);

				if (versionInfo.getFuncList() != null && !versionInfo.getFuncList().isEmpty()) {
					List<LabNoteCommonTagDTO> funcList = versionInfo.getFuncList().stream()
															.filter(vo -> StringUtils.isNotEmpty(vo.getVTag2Cd()))
															.collect(Collectors.toList());

					if (funcList != null && !funcList.isEmpty()) {
						versionInfo.setFuncList(funcList);
						hbdNoteRequestMapper.insertLabNoteMstVerTag(versionInfo);
					}
				}

				hbdCommonService.insertLabNoteVersion(versionInfo);

				this.insertLabNoteMate(LabNoteRequestMateRegDTO.builder()
										.vLabNoteCd(hbdNoteInfoRegDTO.getVLabNoteCd())
										.vContPkCd(contPkCd)
										.nVersion(1)
										.vAddTypeCd("LNC19_FUNC")
										.mateList(versionInfo.getFuncMateList())
										.build());

				this.insertLabNoteMate(LabNoteRequestMateRegDTO.builder()
										.vLabNoteCd(hbdNoteInfoRegDTO.getVLabNoteCd())
										.vContPkCd(contPkCd)
										.nVersion(1)
										.vAddTypeCd("LNC19_NEW")
										.mateList(versionInfo.getNewMateList())
										.build());

				this.insertLabNoteMate(LabNoteRequestMateRegDTO.builder()
										.vLabNoteCd(hbdNoteInfoRegDTO.getVLabNoteCd())
										.vContPkCd(contPkCd)
										.nVersion(1)
										.vAddTypeCd("LNC19_PREF")
										.mateList(versionInfo.getPerfMateList())
										.build());

				this.insertLabNoteMate(LabNoteRequestMateRegDTO.builder()
										.vLabNoteCd(hbdNoteInfoRegDTO.getVLabNoteCd())
										.vContPkCd(contPkCd)
										.nVersion(1)
										.vAddTypeCd("LNC19_REQU")
										.mateList(versionInfo.getRequMateList())
										.build());
			}

			if ("LNC06_21".equals(hbdNoteInfoRegDTO.getVStatusCd())) {
				this.saveLabNoteTestRequest(hbdNoteInfoRegDTO);

				if (!"Y".equals(hbdNoteInfoRegDTO.getVFlagNewVer())) {
					commonService.sendAlarm(AlarmRegDTO.builder()
													.vLabNoteCd(hbdNoteInfoRegDTO.getVLabNoteCd())
													.vStatusCd("AL_NOTE1")
													.vAlrTypeCd("AL_NOTE1_01")
													.typeList(Arrays.asList(Const.TIMELINE, Const.SCHEDULE))
													.vContCd(hbdNoteInfoRegDTO.getVContCd())
													.vContNm(hbdNoteInfoRegDTO.getVContNm())
													.vFlagDupl("N")
													.vNoteType("HBO")
													.build());

					commonService.sendAlarm(AlarmRegDTO.builder()
												.vLabNoteCd(hbdNoteInfoRegDTO.getVLabNoteCd())
												.vStatusCd("AL_NOTE1")
												.vAlrTypeCd("AL_NOTE1_08")
												.typeList(Arrays.asList(Const.TIMELINE))
												.vContCd(hbdNoteInfoRegDTO.getVContCd())
												.vContNm(hbdNoteInfoRegDTO.getVContNm())
												.vFlagDupl("N")
												.vNoteType("HBO")
												.build());
				}
			}

			commonService.saveCommAttach(hbdNoteInfoRegDTO.getFileList(), "HBO_NOTE_ATT01", hbdNoteInfoRegDTO.getVLabNoteCd());
		}
		return result;
	}

	@Transactional
	private void saveLabNoteTestRequest (HbdNoteInfoRegDTO hbdNoteInfoRegDTO) {
		LabNoteVersionRegDTO versionInfo = hbdNoteInfoRegDTO.getVersionInfo();

		hbdCommonService.deleteAerosolCont(hbdNoteInfoRegDTO);
		if (versionInfo != null && "Y".equals(hbdNoteInfoRegDTO.getVFlagAerosol())) {
			hbdCommonService.insertAerosolCont(hbdNoteInfoRegDTO);
			versionInfo.setVCodeType("AEROSOL");
			int nVersion = versionInfo.getNVersion();

			for (int i = 0; i < nVersion; i++) {
				versionInfo.setNVersion((i+1));
				versionInfo.setVVersionNm((i+1) < 10 ? "Ver #0" + (i+1) : "Ver #" + (i+1));
				hbdCommonService.insertLabNoteVersion(versionInfo);
				hbdCommonService.insertAerosolContMate(versionInfo);
			}
		}

		if ("CN20".equals(hbdNoteInfoRegDTO.getVPlantCd())) {
			hbdCommonService.updateLabNoteMstCopyNoteContNm(hbdNoteInfoRegDTO.getVLabNoteCd());
			hbdCommonService.updateLabNoteContCopyNoteContNm(hbdNoteInfoRegDTO.getVLabNoteCd());
		}

		HbdNoteInfoDTO mstInfo = hbdCommonService.selectLabNoteInfo(hbdNoteInfoRegDTO.getVLabNoteCd());
		this.insertLabNoteNewVerCounterMate(mstInfo);
		hbdNoteRequestMapper.insertSAPMaterialReq(hbdNoteInfoRegDTO);
	}

	@Transactional
	private void insertLabNoteNewVerCounterMate(HbdNoteInfoDTO mstInfo) {
		if (mstInfo.getNMaxVersion() <= 1) {
			return;
		}

		LabNoteVersionDTO counterInfo = hbdNoteRequestMapper.selectLabNoteCounterInfo(mstInfo.getVLabNoteCd(), mstInfo.getNMaxVersion());

		if (counterInfo == null) {
			return;
		}

		hbdNoteRequestMapper.deleteLabNoteMate(mstInfo.getVLabNoteCd(), mstInfo.getVContPkCd(), mstInfo.getNMaxVersion(), "LNC19_CUST");

		if (StringUtils.isEmpty(counterInfo.getVCounterContPkCd()) && StringUtils.isEmpty(counterInfo.getVCounterInvenJoinCd())) {
			return;
		}

		if (!"".equals(counterInfo.getVLotCd())) {
			hbdNoteRequestMapper.insertLabNoteCounterRate(LabNoteVersionDTO.builder()
																.vLabNoteCd(mstInfo.getVLabNoteCd())
																.vContPkCd(mstInfo.getVContPkCd())
																.nVersion(mstInfo.getNMaxVersion())
																.vRegUserid(sessionUtil.getLoginId())
																.build());
		} else {
			hbdMaterialService.syncToSAP(BookmarkReqDTO.builder()
													.vContCd(counterInfo.getVCounterContCd())
													.vPlantCd(counterInfo.getVPlantCd())
													.vContPkCd(counterInfo.getVCounterContPkCd())
													.build());

			hbdNoteRequestMapper.insertLabNoteCounterRate(LabNoteVersionDTO.builder()
													.vLabNoteCd(mstInfo.getVLabNoteCd())
													.vContPkCd(mstInfo.getVContPkCd())
													.nVersion(mstInfo.getNMaxVersion())
													.vRegUserid(sessionUtil.getLoginId())
													.build());
		}
	}

	@Transactional
	private int updateLabNotePrdRequest(HbdNoteInfoRegDTO hbdNoteInfoRegDTO) {
		HbdNoteInfoDTO beforeInfo = hbdCommonService.selectLabNoteInfo(hbdNoteInfoRegDTO.getVLabNoteCd());

		// 양산일정 LNC02 존재 시 쿼리로 넣던 부분 front에서 min값 계산하여 한꺼번에 업데이트로 변경
		int result = hbdNoteRequestMapper.updateLabNoteMst(hbdNoteInfoRegDTO);

		if (result > 0) {
			List<HbdNoteContDTO> beforeContList = hbdCommonService.selectElabNoteContList(hbdNoteInfoRegDTO.getVLabNoteCd());
			Map<String, HbdNoteContDTO> beforeContMap = beforeContList == null
												? new HashMap<>()
												: beforeContList.stream().collect(Collectors.toMap(HbdNoteContDTO::getVContPkCd, entity -> entity));

			List<LabNoteCommonTagDTO> beforeMstTagList = hbdCommonService.selectLabNoteMstTagAllList(hbdNoteInfoRegDTO.getVLabNoteCd());

			hbdNoteRequestMapper.deleteLabNoteMstTag(hbdNoteInfoRegDTO);
			if (hbdNoteInfoRegDTO.getMstTagList() != null && !hbdNoteInfoRegDTO.getMstTagList().isEmpty()) {
				hbdCommonService.insertLabNoteMstTag(hbdNoteInfoRegDTO);
			}

			hbdNoteRequestMapper.deleteLabNotePjt(hbdNoteInfoRegDTO.getVLabNoteCd());
			if (hbdNoteInfoRegDTO.getPjtList() != null && !hbdNoteInfoRegDTO.getPjtList().isEmpty()) {
				hbdNoteRequestMapper.insertLabNotePjt(hbdNoteInfoRegDTO);
			}

			List<LabNoteMstVersionDTO> verList = hbdCommonService.selectLabNoteMstVerList(hbdNoteInfoRegDTO.getVLabNoteCd());
			int verSize = verList == null ? 0 : verList.size();

			String flagVerAction = "";
			String flagNewVer = "";
			int ver = 0;
			if (verSize == 0) {
				flagVerAction = "R";
				ver = 1;
			} else {
				flagNewVer = hbdNoteInfoRegDTO.getVFlagNewVer();
				LabNoteMstVersionDTO tempVerInfo = verList.get(verSize - 1);
				ver = tempVerInfo.getNVersion();

				if ("Y".equals(flagNewVer) && "N".equals(tempVerInfo.getVFlagModify())) {
					flagVerAction = "R";
					ver++;
				} else if ("Y".equals(tempVerInfo.getVFlagModify())) {
					flagVerAction = "M";
				}
			}

			LabNoteVersionRegDTO versionInfo = hbdNoteInfoRegDTO.getVersionInfo();
			if (versionInfo != null) {
				versionInfo.setVLabNoteCd(hbdNoteInfoRegDTO.getVLabNoteCd());
				versionInfo.setNVersion(ver);
				versionInfo.setVVersionNm(ver < 10 ? "Ver #0" + ver : "Ver #" + ver);
				versionInfo.setVRegUserid(sessionUtil.getLoginId());
				versionInfo.setVUpdateUserid(sessionUtil.getLoginId());

				if ("R".equals(flagVerAction)) {
					hbdNoteRequestMapper.insertLabNoteMstVer(versionInfo);
				} else {
					hbdNoteRequestMapper.updateLabNoteMstVer(versionInfo);
					hbdNoteRequestMapper.deleteLabNoteMstVerTag(versionInfo);
				}

				if (versionInfo.getFuncList() != null) {
					List<LabNoteCommonTagDTO> funcList = versionInfo.getFuncList().stream()
							.filter(vo -> StringUtils.isNotEmpty(vo.getVTag2Cd()))
							.collect(Collectors.toList());

					if (funcList != null && !funcList.isEmpty()) {
						versionInfo.setFuncList(funcList);
						hbdNoteRequestMapper.insertLabNoteMstVerTag(versionInfo);
					}
				}
			}

			String contPkCd = "";
			String oldContPkCd = hbdNoteRequestMapper.selectRepresentContPkCode(hbdNoteInfoRegDTO.getVLabNoteCd());
			if (hbdNoteInfoRegDTO.getContList() != null && !hbdNoteInfoRegDTO.getContList().isEmpty()) {
				for (HbdNoteRequestContDTO dto : hbdNoteInfoRegDTO.getContList()) {
					dto.setVRegUserid(sessionUtil.getLoginId());
					dto.setVUpdateUserid(sessionUtil.getLoginId());
					dto.setVLabNoteCd(hbdNoteInfoRegDTO.getVLabNoteCd());
					dto.setVCodeType("HAL3");
					dto.setVPlantCd(hbdNoteInfoRegDTO.getVPlantCd());

					if (StringUtils.isNotEmpty(dto.getVContPkCd())) {
						// ??
						//dto.setVContCd(makeupNoteRequestMapper.selectElabNoteContCd(dto.getVContPkCd()));
						hbdNoteRequestMapper.updateNoteContName(dto);
						hbdNoteRequestMapper.updateNoteContEtc(dto);
					} else {
						hbdNoteRequestMapper.insertLabNoteCont(dto);
					}

					if ("Y".equals(dto.getVFlagRepresent())) {
						contPkCd = dto.getVContPkCd();
					}
				}
			}

			if (versionInfo != null) {
				versionInfo.setVContPkCd(contPkCd);
				hbdCommonService.insertLabNoteVersion(versionInfo);

				if (StringUtils.isNotEmpty(versionInfo.getVCounterCd())) {
					hbdNoteRequestMapper.updateContVerCounter(versionInfo);
				}

				if (StringUtils.isEmpty(oldContPkCd) || !contPkCd.equals(oldContPkCd)) {
					hbdNoteRequestMapper.deleteContAllMate(oldContPkCd, sessionUtil.getLoginId());
				}

				if ("M".equals(flagVerAction) || "R".equals(flagVerAction)) {
					this.insertLabNoteMate(LabNoteRequestMateRegDTO.builder()
												.vLabNoteCd(hbdNoteInfoRegDTO.getVLabNoteCd())
												.vContPkCd(contPkCd)
												.nVersion(ver)
												.vAddTypeCd("LNC19_FUNC")
												.mateList(versionInfo.getFuncMateList())
												.build());

					this.insertLabNoteMate(LabNoteRequestMateRegDTO.builder()
												.vLabNoteCd(hbdNoteInfoRegDTO.getVLabNoteCd())
												.vContPkCd(contPkCd)
												.nVersion(ver)
												.vAddTypeCd("LNC19_NEW")
												.mateList(versionInfo.getNewMateList())
												.build());

					this.insertLabNoteMate(LabNoteRequestMateRegDTO.builder()
												.vLabNoteCd(hbdNoteInfoRegDTO.getVLabNoteCd())
												.vContPkCd(contPkCd)
												.nVersion(ver)
												.vAddTypeCd("LNC19_PREF")
												.mateList(versionInfo.getPerfMateList())
												.build());

					this.insertLabNoteMate(LabNoteRequestMateRegDTO.builder()
												.vLabNoteCd(hbdNoteInfoRegDTO.getVLabNoteCd())
												.vContPkCd(contPkCd)
												.nVersion(ver)
												.vAddTypeCd("LNC19_REQU")
												.mateList(versionInfo.getRequMateList())
												.build());

				}
			}

			if (!"LNC06_01".equals(hbdNoteInfoRegDTO.getVStatusCd())) {
				hbdNoteInfoRegDTO.setVersionInfo(versionInfo);
				this.saveLabNoteTestRequest(hbdNoteInfoRegDTO);
				if (!"Y".equals(flagNewVer)) {
					commonService.sendAlarm(AlarmRegDTO.builder()
												.vLabNoteCd(hbdNoteInfoRegDTO.getVLabNoteCd())
												.vStatusCd("AL_NOTE1")
												.vAlrTypeCd("AL_NOTE1_01")
												.typeList(Arrays.asList(Const.TIMELINE, Const.SCHEDULE))
												.vContCd(hbdNoteInfoRegDTO.getVContCd())
												.vContNm(hbdNoteInfoRegDTO.getVContNm())
												.vFlagDupl("N")
												.vNoteType("HBO")
												.build());
					if ("LNC06_21".equals(hbdNoteInfoRegDTO.getVStatusCd())) {
						commonService.sendAlarm(AlarmRegDTO.builder()
													.vLabNoteCd(hbdNoteInfoRegDTO.getVLabNoteCd())
													.vStatusCd("AL_NOTE1")
													.vAlrTypeCd("AL_NOTE1_08")
													.typeList(Arrays.asList(Const.TIMELINE))
													.vContCd(hbdNoteInfoRegDTO.getVContCd())
													.vContNm(hbdNoteInfoRegDTO.getVContNm())
													.vFlagDupl("N")
													.vNoteType("HBO")
													.build());
					}
				}
			}

			HbdNoteInfoDTO afterInfo = hbdCommonService.selectLabNoteInfo(hbdNoteInfoRegDTO.getVLabNoteCd());
			if (!"".equals(flagVerAction)) {
				this.insertLabNoteNewVerCounterMate(afterInfo);
			}

			List<String> arrStatus = Arrays.asList("LNC06_01", "LNC06_02", "LNC06_03", "LNC06_04", "LNC06_05", "LNC06_06");

			if (!arrStatus.contains(beforeInfo.getVStatusCd())) {
				this.updateSAPMaterialReq(hbdNoteInfoRegDTO, beforeInfo, afterInfo);
				hbdCommonService.checkContModifyLog(hbdNoteInfoRegDTO, beforeContMap);
				hbdCommonService.checkModifyLog(hbdNoteInfoRegDTO, beforeInfo, beforeMstTagList, afterInfo);
			}

			commonService.saveCommAttach(hbdNoteInfoRegDTO.getFileList(), "HBO_NOTE_ATT01", hbdNoteInfoRegDTO.getVLabNoteCd());

			if ("Y".equals(flagNewVer)) {
				commonService.sendAlarm(AlarmRegDTO.builder()
											.vLabNoteCd(afterInfo.getVLabNoteCd())
											.vStatusCd("AL_NOTE2")
											.vAlrTypeCd("AL_NOTE2_04")
											.typeList(Arrays.asList(Const.TIMELINE))
											.vContCd(afterInfo.getVContCd())
											.vContNm(afterInfo.getVContNm())
											.nVerNo((ver < 10 ? "0" : "") + String.valueOf(ver))
											.vNoteType("HBO")
											.build());
			}
		}

		return result;
	}

	private void updateSAPMaterialReq(HbdNoteInfoRegDTO mstInfo, HbdNoteInfoDTO beforeInfo, HbdNoteInfoDTO afterInfo) {
		if (!beforeInfo.getVPlantCd().equals(afterInfo.getVPlantCd())
				|| !beforeInfo.getVBrdCd().equals(afterInfo.getVBrdCd())
				|| !beforeInfo.getVUserid().equals(afterInfo.getVUserid())
				) {
			hbdNoteRequestMapper.insertSAPMaterialReq(mstInfo);
			hbdCommonService.updateSAPMaterialReq(mstInfo);
		} else {
			hbdNoteRequestMapper.insertSAPMaterialReq(mstInfo);
			hbdNoteRequestMapper.updateSAPMaterialReqNameChange(mstInfo);
		}
	}

	@Transactional
	public ResponseVO updateContFlagDevelopment(HbdNoteRequestContDTO hbdNoteRequestContDTO) {
		ResponseVO responseVO = new ResponseVO();

		hbdNoteRequestContDTO.setVUpdateUserid(sessionUtil.getLoginId());
		int result = hbdNoteRequestMapper.updateContFlagDevelopment(hbdNoteRequestContDTO);

		if (result > 0) {
			responseVO.setCreateOk(null);
		} else {
			responseVO.setOkWithCode("C9999", CommonResultCode.SAVE_FAIL, null);
		}

		return responseVO;
	}

	@Transactional
	private void insertLabNoteMate(LabNoteRequestMateRegDTO labNoteRequestMateRegDTO) {
		List<LabNoteCommonRequestMateDTO> mateList = labNoteRequestMateRegDTO.getMateList();
		List<LabNoteCommonRequestMateDTO> registerMateList = hbdNoteRequestMapper.selectLabNoteRequestMateListForRegister(labNoteRequestMateRegDTO);

		Map<String, LabNoteCommonRequestMateDTO> map = registerMateList == null
													? new HashMap<>()
													: registerMateList.stream().collect(Collectors.toMap(LabNoteCommonRequestMateDTO::getVMatePkCd, entity -> entity));

		if (mateList != null && !mateList.isEmpty()) {
			for (LabNoteCommonRequestMateDTO dto : mateList) {
				dto.setVLabNoteCd(labNoteRequestMateRegDTO.getVLabNoteCd());
				dto.setVContPkCd(labNoteRequestMateRegDTO.getVContPkCd());
				dto.setNVersion(labNoteRequestMateRegDTO.getNVersion());
				dto.setVAddTypeCd(labNoteRequestMateRegDTO.getVAddTypeCd());
				dto.setVFlagReq("Y");;
				dto.setVUpdateUserid(sessionUtil.getLoginId());

				if ("LNC19_FUNC".equals(labNoteRequestMateRegDTO.getVAddTypeCd())) {
					dto.setVFlagMainIngredientMate("Y");
				}

				if ("Y".equals(dto.getVFlagMateNew())) {
					/*
					dto.setNSort(sort);
					dto.setNSortReq(sort);
					*/
					dto.setVRegUserid(sessionUtil.getLoginId());

					hbdNoteRequestMapper.insertLabNoteMate(dto);
				} else {
					hbdNoteRequestMapper.updateLabNoteMate(dto);
					map.remove(dto.getVMatePkCd());
				}
			}
		}

		map.forEach((key, dto) -> {
			hbdCommonService.deleteLabNoteMate(HbdNoteMateVO.builder()
										.vMatePkCd(dto.getVMatePkCd())
										.vUpdateUserid(sessionUtil.getLoginId())
										.vFlagReq("Y")
										.build());
		});
	}

	@Transactional
	public ResponseVO saveLaunchComplete(LaunchCompleteReqDTO launchCompleteDTO) {
		ResponseVO responseVO = new ResponseVO();

		if (launchCompleteDTO.getContList() != null && !launchCompleteDTO.getContList().isEmpty()) {
			for (LaunchCompleteContDTO vo : launchCompleteDTO.getContList()) {
				if ("Y".equals(vo.getVFlagCancel()) || "N".equals(vo.getVFlagMassAppr())) {
					continue;
				}

				if ("Y".equals(launchCompleteDTO.getVFlagAllComplete())) {
					vo.setVLaunchCompleteDt(launchCompleteDTO.getVCompleteDt());
				}

				if (StringUtils.isEmpty(vo.getVLaunchCompleteDt())) {
					continue;
				}

				vo.setVRegUserid(sessionUtil.getLoginId());
				vo.setVUpdateUserid(sessionUtil.getLoginId());
				vo.setLocalLanguage(sessionUtil.getLocalLanguage());
				vo.setVLaunchCompleteType("CONT");

				if (!"Y".equals(vo.getVFlagNewReg())) {
					vo.setVSignType("minus");
					vo.setVLabNoteCd(launchCompleteDTO.getVLabNoteCd());
					vo.setVRegUserid(sessionUtil.getLoginId());
					vo.setVUpdateUserid(sessionUtil.getLoginId());

					hbdCommonService.updateLabNoteStats01(vo);
					hbdCommonService.updateLabNoteStats02(vo);
					hbdCommonService.updateLabNoteStats03(vo);

					hbdCommonService.updateLabNoteSustainabilityStats01(vo);
					hbdCommonService.updateLabNoteSustainabilityStats02(vo);
					hbdCommonService.updateLabNoteSustainabilityStats03(vo);
				}

				hbdNoteRequestMapper.updateLabNoteFinalCont(vo);

				vo.setVSignType("plus");
				vo.setVCompleteDt(vo.getVLaunchCompleteDt());
				hbdCommonService.updateLabNoteStats01(vo);
				hbdCommonService.updateLabNoteStats02(vo);
				hbdCommonService.updateLabNoteStats03(vo);

				hbdCommonService.updateLabNoteSustainabilityStats01(vo);
				hbdCommonService.updateLabNoteSustainabilityStats02(vo);
				hbdCommonService.updateLabNoteSustainabilityStats03(vo);

				if ("Y".equals(vo.getVFlagNewReg())) {
					HbdNoteContDTO contDTO = ConvertUtil.convert(vo, HbdNoteContDTO.class);
					hbdCommonService.insertLabNoteFinalVersion(contDTO);
					hbdCommonService.insertLabNoteFinalLot(contDTO);

					List<LabNoteDecideDTO> list = hbdCommonService.selectLabNoteDecideInfoList(vo);

					int i = 0;
					if (list != null && !list.isEmpty()) {
						for (LabNoteDecideDTO lvo : list) {
							lvo.setVContPkCd(vo.getVContPkCd());
							lvo.setNSort(i);
							lvo.setVRegUserid(sessionUtil.getLoginId());
							lvo.setVUpdateUserid(sessionUtil.getLoginId());
							lvo.setNVersion(0);

							HbdNoteMateVO mateVO = ConvertUtil.convert(lvo, HbdNoteMateVO.class);
							HbdNoteRateVO rateVO = ConvertUtil.convert(lvo, HbdNoteRateVO.class);
							hbdCommonService.insertLabNoteFinalMate(mateVO);

							rateVO.setVMatePkCd(mateVO.getVMatePkCd());
							rateVO.setVLotCd(contDTO.getVLotCd());
							hbdCommonService.insertLabNoteFinalRate(rateVO);
							i++;
						}
					}
				}
			}
		}

		if ("Y".equals(hbdCommonService.selectLabNoteFlagAllLaunchComplete(launchCompleteDTO.getVLabNoteCd()))) {
			launchCompleteDTO.setVLaunchCompleteType("MST");
			launchCompleteDTO.setVSignType("minus");
			launchCompleteDTO.setVUpdateUserid(sessionUtil.getLoginId());
			launchCompleteDTO.setVRegUserid(sessionUtil.getLoginId());
			launchCompleteDTO.setVUpdateUserid(sessionUtil.getLoginId());
			launchCompleteDTO.setLocalLanguage(sessionUtil.getLocalLanguage());

			LaunchCompleteContDTO contDTO = ConvertUtil.convert(launchCompleteDTO, LaunchCompleteContDTO.class);

			hbdCommonService.updateLabNoteStats01(contDTO);
			hbdCommonService.updateLabNoteStats02(contDTO);
			hbdCommonService.updateLabNoteStats03(contDTO);

			hbdCommonService.updateLabNoteMstLaunchComplete(launchCompleteDTO);

			launchCompleteDTO.setVSignType("plus");
			hbdCommonService.updateLabNoteStats01(contDTO);
			hbdCommonService.updateLabNoteStats02(contDTO);
			hbdCommonService.updateLabNoteStats03(contDTO);
		}

		responseVO.setCreateOk(null);
		return responseVO;
	}

	public ResponseVO selectLabNoteVerLaunchCompleteContList(String vLabNoteCd, String vFlagCompleteModify) {
		ResponseVO responseVO = new ResponseVO();
		responseVO.setOk(hbdNoteRequestMapper.selectLabNoteVerLaunchCompleteContList(vLabNoteCd, vFlagCompleteModify));
		return responseVO;
	}

	public ResponseVO selectIssueTrackerNoteInfo(String vLabNoteCd) {
		ResponseVO responseVO = new ResponseVO();

		HbdNoteInfoDTO noteInfo = hbdCommonService.selectLabNoteInfo(vLabNoteCd);
		List<HbdNoteContDTO> contList = null;
		List<HbdNoteLotDTO> lotList = null;
		List<HbdNoteVersionDTO> verList = null;
		if (noteInfo != null) {
			verList = hbdNoteRequestMapper.selectLabNoteAllVersionList(vLabNoteCd);
			contList = hbdNoteRequestMapper.selectLabNoteContInfoList(vLabNoteCd);
			lotList = hbdNoteRequestMapper.selectLabNoteAllLotList(vLabNoteCd);
		}

		IssueTrackerNoteInfoDTO<HbdNoteInfoDTO> result = IssueTrackerNoteInfoDTO.<HbdNoteInfoDTO>builder()
																.noteInfo(noteInfo)
																.verList(verList)
																.contList(contList)
																.lotList(lotList)
																.build();
		responseVO.setOk(result);
		return responseVO;
	}

	public ResponseVO selectProductVersionHistoryList(String vLabNoteCd, String vContPkCd) {
		ResponseVO responseVO = new ResponseVO();

		List<ProductVersionHistoryDTO> mstList = labNoteCommonService.selectProductVersionHistoryMstList(vLabNoteCd);
		List<LabNoteCommonRequestMateDTO> mateList = null;

		if (mstList != null && !mstList.isEmpty()) {
			mateList = hbdNoteRequestMapper.selectProductVersionHistoryMateList(vLabNoteCd, vContPkCd, sessionUtil.getLocalLanguage());
		}

		responseVO.setOk(ProductVersionHistoryResDTO.builder()
				.mstList(mstList)
				.mateList(mateList)
				.build());

		return responseVO;
	}

	@Transactional
	public ResponseVO updateNotAddIngredientInfo(HbdNoteInfoRegDTO hbdNoteInfoRegDTO) {
		ResponseVO responseVO = new ResponseVO();
		hbdNoteInfoRegDTO.setVRegUserid(sessionUtil.getLoginId());
		hbdNoteInfoRegDTO.setVUpdateUserid(sessionUtil.getLoginId());

		HbdNoteInfoDTO beforeInfo = hbdCommonService.selectLabNoteInfo(hbdNoteInfoRegDTO.getVLabNoteCd());

		int result = hbdNoteRequestMapper.updateFlagNotAdd(hbdNoteInfoRegDTO);

		if (result > 0) {
			List<HbdNoteContDTO> beforeContList = hbdCommonService.selectElabNoteContList(hbdNoteInfoRegDTO.getVLabNoteCd());
			Map<String, HbdNoteContDTO> beforeContMap = beforeContList == null
					? new HashMap<>()
					: beforeContList.stream().collect(Collectors.toMap(HbdNoteContDTO::getVContPkCd, entity -> entity));

			List<LabNoteCommonTagDTO> beforeMstTagList = hbdCommonService.selectLabNoteMstTagAllList(hbdNoteInfoRegDTO.getVLabNoteCd());

			hbdNoteRequestMapper.deleteNotAddMstTag(hbdNoteInfoRegDTO.getVLabNoteCd());
			if (hbdNoteInfoRegDTO.getMstTagList() != null && !hbdNoteInfoRegDTO.getMstTagList().isEmpty()) {
				hbdCommonService.insertLabNoteMstTag(hbdNoteInfoRegDTO);
			}

			HbdNoteInfoDTO afterInfo = hbdCommonService.selectLabNoteInfo(hbdNoteInfoRegDTO.getVLabNoteCd());
			List<String> arrStatus = Arrays.asList("LNC06_01", "LNC06_02", "LNC06_03", "LNC06_04", "LNC06_05", "LNC06_06");

			if (!arrStatus.contains(beforeInfo.getVStatusCd())) {
				hbdCommonService.checkContModifyLog(hbdNoteInfoRegDTO, beforeContMap);
				hbdCommonService.checkModifyLog(hbdNoteInfoRegDTO, beforeInfo, beforeMstTagList, afterInfo);
			}

			responseVO.setCreateOk(null);
		} else {
			responseVO.setOkWithCode("C9999", CommonResultCode.SAVE_FAIL, null);
		}

		return responseVO;
	}

	public ResponseVO sendMarketerShareMail(BrandManagerShareDTO brandManagerShareDTO) {
		String vLabNoteCd = brandManagerShareDTO.getVLabNoteCd();
		ResponseVO responseVO = new ResponseVO();
		
		if (StringUtils.isEmpty(vLabNoteCd)) {
			responseVO.setOkWithCode("C9999", CommonResultCode.NO_ESSENTIAL_DATA, null);
			return responseVO;
		}
		
		HbdNoteInfoDTO noteInfo = hbdCommonService.selectLabNoteInfo(vLabNoteCd);

		if (noteInfo != null) {
			labNoteCommonService.insertBrandManagerGroupUser(BrandManagerGroupDTO.builder()
																.vUserid(noteInfo.getVBrdUserid())
																.vDeptCd(noteInfo.getVBrdDeptcd())
																.vRegUserid(sessionUtil.getLoginId())
																.vUpdateUserid(sessionUtil.getLoginId())
																.build());
			HashMap<String, String> mailArgs = new HashMap<String, String>();
			String pageUrl = "/hbd/all-lab-note-brand-manager-view?vLabNoteCd=" + vLabNoteCd;

			mailArgs.put("vContCdOrigin", StringUtils.isNotEmpty(noteInfo.getVContCd()) ? noteInfo.getVContCd() : "");
			mailArgs.put("vContCd", StringUtils.isNotEmpty(noteInfo.getVContCd()) ? "[" + noteInfo.getVContCd() + "] " : "");
			mailArgs.put("vContNm", StringUtils.isNotEmpty(noteInfo.getVContNm()) ? noteInfo.getVContNm() : "");
			mailArgs.put("vUserNm", noteInfo.getVBrdUsernm());
			mailArgs.put("vFromTeamNm", sessionUtil.getDeptNm());
			mailArgs.put("vFromUsernm", sessionUtil.getUserNm());
			mailArgs.put("vPageUrl", pageUrl);
			mailArgs.put("vOpinion", brandManagerShareDTO.getVOpinion());

			String mailContent = new MailForm().getMailContent(MailDTO.MAIL_MARKETER_SHARE, mailArgs);
			String mailTitle = mailArgs.get("vContCd") + mailArgs.get("vContNm") + " 내용물 개요 항목 입력 요청";
			MailUtil.send(noteInfo.getVBrdUsermail(), null, mailTitle, mailContent);

			commonService.sendAlarm(AlarmRegDTO.builder()
										.vLabNoteCd(noteInfo.getVLabNoteCd())
										.vStatusCd("AL_NOTE1")
										.vAlrTypeCd("AL_NOTE1_06")
										.typeList(Arrays.asList(Const.TIMELINE, Const.MAIL, Const.ALARM))
										.vFlagMail("Y")
										.vContCd(noteInfo.getVContCd())
										.vContNm(noteInfo.getVContNm())
										.userList(Arrays.asList(noteInfo.getVBrdUserid()))
										.vToUsernm(noteInfo.getVBrdUsernm())
										.vToTeamNm(noteInfo.getVBrdDeptnm())
										.vMoveUrl(pageUrl)
										.vNoteType("HBO")
										.build());

			responseVO.setCreateOk(null);
		} else {
			responseVO.setOkWithCode("C9999", CommonResultCode.NO_DATA, null);
		}

		return responseVO;
	}


	//반제품, 과제 부분[S]

	//반제품 내용물 개요 상세
	public ResponseVO selectHalfReqInfo(String vLabNoteCd) {
		ResponseVO responseVO = new ResponseVO();

		if (StringUtils.isEmpty(vLabNoteCd)) {
			responseVO.setOk(messageSource.getMessage("pms.messageCommon.msg50"));
			return responseVO;
		}

		HbdNoteInfoDTO resDTO = hbdCommonService.selectLabNoteInfo(vLabNoteCd);

		if (resDTO != null) {
			MaterialSearchVO schVO = new MaterialSearchVO();

			schVO.setVLabNoteCd(vLabNoteCd);
			schVO.setVUserId(sessionUtil.getLoginId());

			hbdCommonService.selectElabNoteAuth(schVO, resDTO);
			List<String> groups = sessionUtil.getGroups();

			if (!"Y".equals(schVO.getVIsPersonInCharge()) &&
					!"Y".equals(schVO.getVIsRelatedPerson()) &&
					!"Y".equals(schVO.getVIsLabNoteAdmin()) &&
					(!ObjectUtils.isEmpty(groups) && groups.stream().anyMatch(group -> "S000118;S000246;S000000;".indexOf(group) == -1)) &&
					!"Y".equals(labNoteCommonService.checkLabNoteAuth("HBO", resDTO.getVStatusCd(), resDTO.getVDeptCd()))) {
				responseVO.setOkWithCode("C9999", CommonResultCode.NO_AUTH, null);
				return responseVO;
			}
		}

		Optional<HbdNoteInfoDTO> optional = Optional.ofNullable(resDTO);

		optional.ifPresentOrElse((dto) -> {

			dto.setPjtList(hbdNoteRequestMapper.selectLabNotePjtList(vLabNoteCd));

			responseVO.setOk(dto);
		}, () -> {
			responseVO.setOkWithCode(Const.FAIL, messageSource.getMessage("pms.messageCommon.msg48"), null);
		});

		return responseVO;
	}

	//과제 내용물 개요 상세
	public ResponseVO selectNonReqInfo(String vLabNoteCd) {
		ResponseVO responseVO = new ResponseVO();

		if (StringUtils.isEmpty(vLabNoteCd)) {
			responseVO.setOk(messageSource.getMessage("pms.messageCommon.msg50"));
			return responseVO;
		}

		HbdNoteInfoDTO resDTO = hbdCommonService.selectLabNoteInfo(vLabNoteCd);

		if (resDTO != null) {
			MaterialSearchVO schVO = new MaterialSearchVO();

			schVO.setVLabNoteCd(vLabNoteCd);
			schVO.setVUserId(sessionUtil.getLoginId());

			hbdCommonService.selectElabNoteAuth(schVO, resDTO);
			List<String> groups = sessionUtil.getGroups();

			if (!"Y".equals(schVO.getVIsPersonInCharge()) &&
					!"Y".equals(schVO.getVIsRelatedPerson()) &&
					!"Y".equals(schVO.getVIsLabNoteAdmin()) &&
					(!ObjectUtils.isEmpty(groups) && groups.stream().anyMatch(group -> "S000118;S000246;S000000;".indexOf(group) == -1)) &&
					!"Y".equals(labNoteCommonService.checkLabNoteAuth("HBO", resDTO.getVStatusCd(), resDTO.getVDeptCd()))) {
				responseVO.setOkWithCode("C9999", CommonResultCode.NO_AUTH, null);
				return responseVO;
			}
		}

		Optional<HbdNoteInfoDTO> optional = Optional.ofNullable(resDTO);

		optional.ifPresentOrElse((dto) -> {

			dto.setPjtList(hbdNoteRequestMapper.selectLabNotePjtList(vLabNoteCd));

			List<LabNoteMstVersionDTO> verList = hbdCommonService.selectLabNoteMstVerList(vLabNoteCd);
			dto.setVerList(verList);

			int nVersion = verList != null && !verList.isEmpty() ? verList.get(verList.size() - 1).getNVersion() : 1;
			LabNoteVersionDTO versionInfo = this.selectLabNoteMstVerInfo(vLabNoteCd, nVersion);

			dto.setVersionInfo(versionInfo);

//			List<ThisInventoryVO> inventoryList = hbdNoteRequestMapper.selectLabNoteThisInventoryList(vLabNoteCd, sessionUtil.getLocalLanguage());
//			dto.setInventoryList(inventoryList);

//			dto.setCounterList(hbdNoteRequestMapper.selectLabNoteThisCounterList(vLabNoteCd, dto.getVContPkCd(), sessionUtil.getLocalLanguage()));

			dto.setVIsLabNoteAdmin(labNoteCommonService.checkLabNoteAdmin("HBO", "N"));

			responseVO.setOk(dto);
		}, () -> {
			responseVO.setOkWithCode(Const.FAIL, messageSource.getMessage("pms.messageCommon.msg48"), null);
		});

		return responseVO;
	}

	//반제품, 과제 저장
	@Transactional
	public ResponseVO insertElabNoteRequestInfo (InsertHbdNoteHalfRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();
		ResultDTO resultVo = new ResultDTO();

		String flagAction = regDTO.getVFlagAction();

		if ("HAL4_R".equals(flagAction)) {
			//반제품 신규 등록
			regDTO.setVCodeType("HAL4");
			resultVo = this.insertHal4AndNonPrdMst(regDTO);
//			labNoteCommonServiceImpl.insertHal4Mst(reqVo);
		}else if ("HAL4_M".equals(flagAction)) {
			//반제품 수정
			resultVo = this.updateHal4AndNonPrdMst(regDTO);
//			labNoteCommonServiceImpl.updateHal4Mst(reqVo);
		}else if ("NONPRD_R".equals(flagAction)){
			//과제 신규등록
			regDTO.setVCodeType("HAL3");
			resultVo = this.insertHal4AndNonPrdMst(regDTO);
//			labNoteCommonServiceImpl.insertNonPrdMst(reqVo);
		}else if ("NONPRD_M".equals(flagAction)){
			//과제 수정
			resultVo = this.updateHal4AndNonPrdMst(regDTO);
//			labNoteCommonServiceImpl.updateNonPrdMst(reqVo);`
		}else if ("AUTHORITY_R".equals(flagAction)){
			//열람권한 등록
			//LabNoteCommonController.java 이미 생성 되어있음
//			labNoteCommonServiceImpl.insertLabNoteAuthority(reqVo);
		}else if ("AUTHORITY_D".equals(flagAction)){
			//열람권한 삭제
			//LabNoteCommonController.java 이미 생성 되어있음
//			labNoteCommonServiceImpl.deleteLabNoteAuthority(reqVo);
		}else if("NOTE_PLANT_EXPANSION".equals(flagAction)){
			//플랜트 확장
			///SkincareNoteRequestController.java 이미 생성 되어있음
//			labNoteCommonServiceImpl.insertLabNotePlatnExpansion(reqVo);
		}else if("PRD_NOTE_INFO_SAVE".equals(flagAction)) {
			//제품화하기 위해 정보저장
//			labNoteCommonServiceImpl.insertPrdLabNoteInfo(reqVo);
		}else if("PRD_NOTE_APPR".equals(flagAction)) {
			//제품화 하기 결재 요청

		}else if("USR_APPR_NEXT".equals(flagAction)) {

		}
		else if("SAVE_GENERATE_CODE".equals(flagAction)){
			// 과제 제품화
			resultVo = this.insertLabNoteGenerateCode(regDTO);
//			labNoteCommonServiceImpl.insertLabNoteGenerateCode(reqVo);
		}
		else {
			resultVo.setStatus(Const.FAIL);
			resultVo.setMessage("필수 인자값이 없습니다.");
		}

		if (Const.SUCC.equals(resultVo.getStatus())){

			if("NOTE_PLANT_EXPANSION".equals(flagAction)){
				resultVo.setStatus(Const.CODE);
				resultVo.setMessage("success");
				resultVo.setObject(regDTO);
			} else{
				resultVo.setStatus(Const.CODE);
				resultVo.setMessage("success");
				resultVo.setObject(regDTO.getVLabNoteCd());
			}

		}
		else {
			resultVo.setStatus(Const.FAIL);
			resultVo.setMessage("필수 인자값이 없습니다.");
		}

		responseVO.setOkWithCode(resultVo.getStatus(), resultVo.getMessage(), resultVo.getObject());
		return responseVO;
	}

	public ResultDTO insertHal4AndNonPrdMst(InsertHbdNoteHalfRegDTO regDTO) {
		ResultDTO resultVo = new ResultDTO();

		if ("NONPRD_R".equals(regDTO.getVFlagAction())){
			//과제일때만 셋팅
			regDTO.setVPlantCd("NONPRD");
		}

		//연구원 코드를 지정하여 넣어준다.
		String vLabContCd = labNoteCommonService.selectLabNoteLaborCd(regDTO.getVUserid());
		regDTO.setVLabContCd(vLabContCd);
		regDTO.setVRegUserid(sessionUtil.getLoginId());
		regDTO.setVUpdateUserid(sessionUtil.getLoginId());

		hbdNoteRequestMapper.insertOtherPrdNoteMst(regDTO);

		//예산코드 저장
		if (regDTO.getPjtList() != null && !regDTO.getPjtList().isEmpty()) {

			HbdNoteInfoRegDTO hbdNoteInfoRegDTO = new HbdNoteInfoRegDTO();
			hbdNoteInfoRegDTO.setPjtList(regDTO.getPjtList());
			hbdNoteInfoRegDTO.setVLabNoteCd(regDTO.getVLabNoteCd());
			hbdNoteInfoRegDTO.setVRegUserid(sessionUtil.getLoginId());

			hbdNoteRequestMapper.insertLabNotePjt(hbdNoteInfoRegDTO);
		}

		regDTO.setNVersion(1);
		regDTO.setVVersionNm("Ver #01");

		hbdNoteRequestMapper.insertOtherPrdNoteMstVer(regDTO);

		hbdNoteRequestMapper.insertOtherPrdNoteCont(regDTO);
		hbdNoteRequestMapper.insertOtherPrdNoteVersion(regDTO);

		String statusCd	= regDTO.getVStatusCd();

		//임시 저장이 아니라면 4자코드 생성
		if(!"LNC06_01".equals(statusCd) && "HAL4_R".equals(regDTO.getVFlagAction())){
			HbdNoteInfoRegDTO mstInfo = new HbdNoteInfoRegDTO();

			mstInfo.setVLabNoteCd(regDTO.getVLabNoteCd());
			hbdNoteRequestMapper.insertSAPMaterialReq(mstInfo);
		}

		commonService.saveCommAttach(regDTO.getFileList(), regDTO.getVUploadCd(), regDTO.getVLabNoteCd());

		//알림
		commonService.sendAlarm(AlarmRegDTO.builder()
				.vLabNoteCd(regDTO.getVLabNoteCd())
				.vStatusCd("AL_NOTE1")
				.vAlrTypeCd("AL_NOTE1_01")
				.typeList(Arrays.asList(Const.TIMELINE, Const.SCHEDULE))
				.vContCd("")
				.vContNm(regDTO.getVContNm())
				.vFlagDupl("N")
				.vNoteType("HBO")
				.build());

		resultVo.setStatus(Const.SUCC);

		return resultVo;
	}

	ResultDTO updateHal4AndNonPrdMst(InsertHbdNoteHalfRegDTO regDTO) {
		ResultDTO resultVo = new ResultDTO();
		HbdNoteInfoDTO beforeVo = null;

		if ("NONPRD_M".equals(regDTO.getVFlagAction())){
			//과제일때만 셋팅
			regDTO.setVPlantCd("NONPRD");
		}else {
			//HAL4_M
			beforeVo = hbdCommonService.selectLabNoteInfo(regDTO.getVLabNoteCd());
			//MU,HBO 개발시 컬럼 확인

			if (beforeVo == null) {
				resultVo.setStatus(Const.FAIL);
				resultVo.setMessage("[수정실패] 수정된 내역이 없습니다.");
			}
		}

		//연구원 코드를 지정하여 넣어준다.
		String vLabContCd = labNoteCommonService.selectLabNoteLaborCd(regDTO.getVUserid());
		regDTO.setVLabContCd(vLabContCd);

		regDTO.setVUpdateUserid(sessionUtil.getLoginId());
		//실험노트 MST 저장
		int uptCnt = hbdNoteRequestMapper.updateOtherPrdNoteMst(regDTO);

		//예산코드 수정
		hbdNoteRequestMapper.deleteLabNotePjt(regDTO.getVLabNoteCd());
		if (regDTO.getPjtList() != null && !regDTO.getPjtList().isEmpty()) {

			HbdNoteInfoRegDTO hbdNoteInfoRegDTO = new HbdNoteInfoRegDTO();
			hbdNoteInfoRegDTO.setPjtList(regDTO.getPjtList());
			hbdNoteInfoRegDTO.setVLabNoteCd(regDTO.getVLabNoteCd());
			hbdNoteInfoRegDTO.setVRegUserid(sessionUtil.getLoginId());

			hbdNoteRequestMapper.insertLabNotePjt(hbdNoteInfoRegDTO);
		}

		if (uptCnt > 0) {

			hbdNoteRequestMapper.updateOtherPrdNoteCont(regDTO);

			String statusCd	= regDTO.getVStatusCd();

			if (!"LNC06_01".equals(statusCd) && "HAL4_M".equals(regDTO.getVFlagAction())) {
				HbdNoteInfoDTO afterVo = hbdCommonService.selectLabNoteInfo(regDTO.getVLabNoteCd());

				// 브랜드, 플랜트 변경 시 SAP 자재변경요청
				HbdNoteInfoRegDTO hbdNoteInfoRegDTO = new HbdNoteInfoRegDTO();
				hbdNoteInfoRegDTO.setVPlantCd(regDTO.getVPlantCd());
				hbdNoteInfoRegDTO.setVLabNoteCd(regDTO.getVLabNoteCd());

				//임시저장 후 아래 데이터가 없을때 오류 방지하기 위해
				if(StringUtils.isEmpty(beforeVo.getVPlantCd())) {
					beforeVo.setVPlantCd("tmpValue");
				}
				if(StringUtils.isEmpty(beforeVo.getVBrdCd())) {
					beforeVo.setVBrdCd("tmpValue");
				}

				if(StringUtils.isEmpty(beforeVo.getVUserid())) {
					beforeVo.setVUserid("tmpValue");
				}
				//

				this.updateSAPMaterialReq(hbdNoteInfoRegDTO, beforeVo, afterVo);
			}

			commonService.saveCommAttach(regDTO.getFileList(), regDTO.getVUploadCd(), regDTO.getVLabNoteCd());

			resultVo.setStatus(Const.SUCC);

		}else {
			resultVo.setStatus(Const.FAIL);
			resultVo.setMessage("[수정실패] 수정된 내역이 없습니다.");
		}

		return resultVo;
	}

	//반제품, 과제 부분[E]

	ResultDTO insertLabNoteGenerateCode(InsertHbdNoteHalfRegDTO regDTO) {
		ResultDTO resultVo = new ResultDTO();

		regDTO.setVUpdateUserid(sessionUtil.getLoginId());

		int result = hbdNoteRequestMapper.updateELabNoteBrandAndPlant(regDTO);

		hbdNoteRequestMapper.updateELabNoteContInfo(regDTO);

		hbdNoteRequestMapper.insertSAPMaterialReq(HbdNoteInfoRegDTO.builder()
				.vLabNoteCd(regDTO.getVLabNoteCd())
				.build());

		if (result > 0) {
			resultVo.setStatus(Const.SUCC);

		}else {
			resultVo.setStatus(Const.FAIL);
			resultVo.setMessage("[수정실패] 수정된 내역이 없습니다.");
		}

		return resultVo;
	}
}
