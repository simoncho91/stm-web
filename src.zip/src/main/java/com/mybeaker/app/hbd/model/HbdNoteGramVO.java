package com.mybeaker.app.hbd.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@Data
public class HbdNoteGramVO extends ParentDTO {

	@JsonProperty("vGramCd")
	private String vGramCd;

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("nGram")
	private String nGram;

	@JsonProperty("nSort")
	private int nSort;

	@JsonProperty("vFlagDel")
	private String vFlagDel;
	
	@JsonProperty("vTestStDt")
	private String vTestStDt;
	
	@JsonProperty("vTestEnDt")
	private String vTestEnDt;

	@Builder
	public HbdNoteGramVO(String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm, String vGramCd,
			String vLotCd, String nGram, int nSort, String vFlagDel, String vTestStDt, String vTestEnDt) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.vGramCd = vGramCd;
		this.vLotCd = vLotCd;
		this.nGram = nGram;
		this.nSort = nSort;
		this.vFlagDel = vFlagDel;
		this.vTestStDt = vTestStDt;
		this.vTestEnDt = vTestEnDt;
	}
}
