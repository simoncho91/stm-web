package com.mybeaker.app.hbd.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mybeaker.app.hbd.model.HbdNoteInfoRegDTO;
import com.mybeaker.app.hbd.model.HbdNoteRequestContDTO;
import com.mybeaker.app.hbd.model.InsertHbdNoteHalfRegDTO;
import com.mybeaker.app.hbd.service.HbdNoteRequestService;
import com.mybeaker.app.labnote.model.BrandManagerShareDTO;
import com.mybeaker.app.labnote.model.ElabChgLogSearchReqDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonReqDevelopCancelDTO;
import com.mybeaker.app.labnote.model.LabNoteVersionModifyReqDTO;
import com.mybeaker.app.labnote.model.LaunchCompleteReqDTO;
import com.mybeaker.app.labnote.model.PlantChangeReqDTO;
import com.mybeaker.app.labnote.model.PlantExtendReqDTO;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.skincare.model.LabNoteExperimentReqDTO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Tag(name = "HBD 내용물 등록 의뢰 api", description="HBD 내용물 등록 의뢰 api")
@RestController
@RequestMapping("/api/hbd/request")
@RequiredArgsConstructor
public class HbdNoteRequestController {
	private final HbdNoteRequestService hbdNoteRequestService;

	@Operation(summary = "내용물 리스트", description = "내용물 리스트 조회. (화면ID : SC-PA-002)")
	@GetMapping("/select-req-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectReqList (
			LabNoteExperimentReqDTO reqDTO) {
		log.debug("HbdNoteRequestController.selectReqList => params : { LabNoteExperimentReqDTO: {} }", reqDTO.toString());
		return ResponseEntity.ok(hbdNoteRequestService.selectReqList(reqDTO));
	}

	@Operation(summary = "내용물 등록 의뢰", description = "내용물 등록 의뢰 조회.")
	@GetMapping("/select-req-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectReqInfo (
			@RequestParam(value="vLabNoteCd", defaultValue = "") String vLabNoteCd,
			@RequestParam(value="vPageFlag", defaultValue = "REG") String vPageFlag
			) {
		log.debug("HbdNoteRequestController.selectReqInfo => params : { vLabNoteCd: {}, vPageFlag: {} }", vLabNoteCd, vPageFlag);

		return ResponseEntity.ok(hbdNoteRequestService.selectReqInfo(vLabNoteCd, vPageFlag));
	}

	@Operation(summary = "내용물 등록 의뢰 - 버전 정보", description = "내용물 등록 의뢰 - 버전 정보를 조회한다.")
	@GetMapping("/select-lab-note-mst-ver-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteMstVerInfo (
			@RequestParam(value="vLabNoteCd") String vLabNoteCd,
			@RequestParam(value="nVersion", defaultValue = "0") int nVersion
			) {
		log.debug("HbdNoteRequestController.selectLabNoteMstVerInfo => params : { vLabNoteCd: {}, nVersion: {} }", vLabNoteCd, nVersion);

		ResponseVO responseVO = new ResponseVO();
		responseVO.setOk(hbdNoteRequestService.selectLabNoteMstVerInfo(vLabNoteCd, nVersion));
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "개발 취소", description = "실험노트 개발 취소 상태 변경, 의견 저장")
	@PostMapping("/update-elab-note-cancel-info")
	public @ResponseBody ResponseEntity<ResponseVO> updateElabNoteCancelInfo (
			@RequestBody LabNoteCommonReqDevelopCancelDTO labNoteCommonReqDevelopCancelDTO
			) {
		log.debug("HbdNoteRequestController.updateElabNoteCancelInfo => labNoteCommonReqDevelopCancelDTO : {}", labNoteCommonReqDevelopCancelDTO);

		return ResponseEntity.ok(hbdNoteRequestService.updateElabNoteCancelInfo(labNoteCommonReqDevelopCancelDTO));
	}

	@Operation(summary = "개발 재개", description = "실험노트 개발 재개")
	@PostMapping("/update-elab-note-restart")
	public @ResponseBody ResponseEntity<ResponseVO> updateElabNoteRestart (
			@RequestBody LabNoteCommonReqDevelopCancelDTO labNoteCommonReqDevelopCancelDTO
			) {
		log.debug("HbdNoteRequestController.updateElabNoteRestart => labNoteCommonReqDevelopCancelDTO : {}", labNoteCommonReqDevelopCancelDTO);

		return ResponseEntity.ok(hbdNoteRequestService.updateElabNoteRestart(labNoteCommonReqDevelopCancelDTO));
	}

	@Operation(summary = "제품 내용물 등록 의뢰", description = "제품 내용물 등록 의뢰 저장")
	@PostMapping("/save-lab-note-prd-request")
	public @ResponseBody ResponseEntity<ResponseVO> saveLabNotePrdRequest (
			@RequestBody HbdNoteInfoRegDTO hbdNoteInfoRegDTO
			) {
		log.debug("MakeupNoteRequestController.saveLabNoteRequest => hbdNoteInfoRegDTO : {}", hbdNoteInfoRegDTO);

		return ResponseEntity.ok(hbdNoteRequestService.saveLabNotePrdRequest(hbdNoteInfoRegDTO));
	}

	@Operation(summary = "플랜트 확장 - 내용물 플랜트 정보 리스트 조회", description = "플랜트 확장 - 내용물 플랜트 정보 리스트를 조회한다.")
	@GetMapping("/select-lab-note-cont-plant-info-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteContPlantInfoList (
			@RequestParam(value="vLabNoteCd") String vLabNoteCd,
			@RequestParam(value="vCodeType") String vCodeType
			) {
		log.debug("HbdNoteRequestController.selectLabNoteContPlantInfoList => params : { vLabNoteCd : {}, vCodeType : {} }", vLabNoteCd, vCodeType);

		return ResponseEntity.ok(hbdNoteRequestService.selectLabNoteContPlantInfoList(vLabNoteCd, vCodeType));
	}

	@Operation(summary = "플랜트 확장 저장", description = "플랜트 확장 내용을 저장한다.")
	@PostMapping("/insert-lab-note-plant-expansion")
	public @ResponseBody ResponseEntity<ResponseVO> insertLabNotePlantExpansion(
			@RequestBody PlantExtendReqDTO plantExtendReqDTO
			) {
		log.debug("HbdNoteRequestController.insertLabNotePlantExpansion => plantExtendReqDTO : {}", plantExtendReqDTO);

		return ResponseEntity.ok(hbdNoteRequestService.insertLabNotePlantExpansion(plantExtendReqDTO));
	}

	@Operation(summary = "대표 플랜트 변경 - 저장 플랜트 조회", description = "대표 플랜트 변경 - 저장된 플랜트를 조회한다.")
	@GetMapping("/select-lab-note-save-plant-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteSavePlantList (
			@RequestParam(value="vLabNoteCd") String vLabNoteCd
			) {
		log.debug("HbdNoteRequestController.selectLabNoteSavePlantList => params : { vLabNoteCd : {} }", vLabNoteCd);

		return ResponseEntity.ok(hbdNoteRequestService.selectLabNoteSavePlantList(vLabNoteCd));
	}

	@Operation(summary = "대표 플랜트 변경", description = "대표 플랜트를 업데이트한다.")
	@PostMapping("/update-plant-and-site-type")
	public @ResponseBody ResponseEntity<ResponseVO> updatePlantAndSiteType (
			@RequestBody PlantChangeReqDTO plantChangeReqDTO
			) {
		log.debug("HbdNoteRequestController.updatePlantAndSiteType => plantChangeReqDTO : {}", plantChangeReqDTO);

		return ResponseEntity.ok(hbdNoteRequestService.updatePlantAndSiteType(plantChangeReqDTO));
	}

	@Operation(summary = "변경 이력 조회", description = "변경 이력을 조회한다.")
	@GetMapping("/select-lab-note-chg-log-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteChgLogList (
			ElabChgLogSearchReqDTO elabChgLogSearchReqDTO
			) {
		log.debug("HbdNoteRequestController.selectLabNoteChgLogList => elabChgLogSearchReqDTO : {}", elabChgLogSearchReqDTO);

		return ResponseEntity.ok(hbdNoteRequestService.selectLabNoteChgLogList(elabChgLogSearchReqDTO));
	}

	@Operation(summary = "내용물 개발취소, 재개", description = "메이크업 내용물의 개발 취소 / 재개 처리를 한다.")
	@PostMapping("/update-cont-flag-development")
	public @ResponseBody ResponseEntity<ResponseVO> updateContFlagDevelopment (
			@RequestBody HbdNoteRequestContDTO hbdNoteRequestContDTO
			) {
		log.debug("HbdNoteRequestController.updateContFlagDevelopment => hbdNoteRequestContDTO : {}", hbdNoteRequestContDTO);

		return ResponseEntity.ok(hbdNoteRequestService.updateContFlagDevelopment(hbdNoteRequestContDTO));
	}

	@Operation(summary = "버전 정보 수정", description = "버전 정보를 수정한다.")
	@PostMapping("/update-lab-note-version-info")
	public @ResponseBody ResponseEntity<ResponseVO> updateLabNoteVersionInfo (
			@RequestBody LabNoteVersionModifyReqDTO labNoteVersionModifyReqDTO
			) {
		log.debug("HbdNoteRequestController.updateLabNoteVersionInfo => labNoteVersionModifyReqDTO : {}", labNoteVersionModifyReqDTO);

		return ResponseEntity.ok(hbdNoteRequestService.updateLabNoteVersionInfo(labNoteVersionModifyReqDTO));
	}

	@Operation(summary = "출시완료 처리 정보 조회", description = "출시완료 처리를 위한 정보를 조회한다.")
	@GetMapping("/select-lab-note-ver-launch-complete-cont-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteVerLaunchCompleteContList (
			@RequestParam(value="vLabNoteCd") String vLabNoteCd,
			@RequestParam(value="vFlagCompleteModify") String vFlagCompleteModify
			) {
		log.debug("HbdNoteRequestController.selectReleaseCompleteInfo => vLabNoteCd : {}", vLabNoteCd);

		return ResponseEntity.ok(hbdNoteRequestService.selectLabNoteVerLaunchCompleteContList(vLabNoteCd, vFlagCompleteModify));
	}

	@Operation(summary = "출시완료일 변경", description = "출시완료일을 일괄 변경한다.")
	@PostMapping("/save-launch-complete")
	public @ResponseBody ResponseEntity<ResponseVO> saveLaunchComplete (
			@RequestBody LaunchCompleteReqDTO launchCompleteDTO
			) {
		log.debug("HbdNoteRequestController.saveLaunchComplete => launchCompleteDTO : {}", launchCompleteDTO);

		return ResponseEntity.ok(hbdNoteRequestService.saveLaunchComplete(launchCompleteDTO));
	}

	@Operation(summary = "이슈 트래커 실험노트 기본 정보 조회", description = "이슈 트래커 실험노트 기본 정보 조회")
	@GetMapping("/select-issue-tracker-note-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectIssueTrackerNoteInfo (
			@RequestParam(value="vLabNoteCd") String vLabNoteCd
			) {
		log.debug("HbdNoteRequestController.selectIssueTrackerNoteInfo => params : { vLabNoteCd : {} }", vLabNoteCd);
		return ResponseEntity.ok(hbdNoteRequestService.selectIssueTrackerNoteInfo(vLabNoteCd));
	}

	@Operation(summary = "Product 변경이력 조회", description = "Product 변경이력을 조회한다.")
	@GetMapping("/select-product-version-history-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectProductVersionHistoryList (
			@RequestParam(value="vLabNoteCd") String vLabNoteCd,
			@RequestParam(value="vContPkCd") String vContPkCd
			) {
		log.debug("HbdNoteRequestController.selectProductVersionHistoryList => params : { vLabNoteCd : {}, vContPkCd : {} }", vLabNoteCd, vContPkCd);
		return ResponseEntity.ok(hbdNoteRequestService.selectProductVersionHistoryList(vLabNoteCd, vContPkCd));
	}

	@Operation(summary = "무소구 수정", description = "무소구 정보를 수정한다.")
	@PostMapping("/update-not-add-ingredient-info")
	public @ResponseBody ResponseEntity<ResponseVO> updateNotAddIngredientInfo (
			@RequestBody HbdNoteInfoRegDTO hbdNoteInfoRegDTO
			) {
		log.debug("HbdNoteRequestController.updateNotAddIngredientInfo => hbdNoteInfoRegDTO : {}", hbdNoteInfoRegDTO);
		return ResponseEntity.ok(hbdNoteRequestService.updateNotAddIngredientInfo(hbdNoteInfoRegDTO));
	}

	@Operation(summary = "마케터 공유하기 메일 발송", description = "마케터에게 공유, 내용 수정 요청")
	@PostMapping("/send-marketer-share-mail")
	public @ResponseBody ResponseEntity<ResponseVO> sendMarketerShareMail (
			@RequestBody BrandManagerShareDTO brandManagerShareDTO
			) {
		log.debug("MakeupNoteRequestController.sendMarketerShareMail => brandManagerShareDTO : {}", brandManagerShareDTO);
		return ResponseEntity.ok(hbdNoteRequestService.sendMarketerShareMail(brandManagerShareDTO));
	}

	// 반제품 [S]
	//
	@Operation(summary = "반제품 내용물 개요 상세", description = "반제품 내용물 개요 상세 정보. (화면ID : SC-PA-050)")
	@GetMapping("/select-halfreq-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectHalfReqInfo (
			@RequestParam(value="vLabNoteCd", defaultValue = "") String vLabNoteCd
			) {
		log.debug("HbdNoteRequestController.selectHalfReqInfo => params : { vLabNoteCd: {} }", vLabNoteCd);
		
		return ResponseEntity.ok(hbdNoteRequestService.selectHalfReqInfo(vLabNoteCd));
	}

//	/elab/common/lab_request_save
	@Operation(summary = "반제품, 과제 저장", description = "반제품, 과제 저장한다.")
	@PostMapping("/save-lab-request-info")
	public @ResponseBody ResponseEntity<ResponseVO> insertElabNoteRequestInfo (
			@RequestBody InsertHbdNoteHalfRegDTO regDTO) {
		log.debug("insert-elab-note-request-infoStart!");
		log.debug("InsertLabNoteHalfRegDTO : {}", regDTO.toString());
		
		return ResponseEntity.ok(hbdNoteRequestService.insertElabNoteRequestInfo(regDTO));
	}
	//
	//반제품 [E]
	
	@Operation(summary = "과제 내용물 개요 상세", description = "과제 내용물 개요 상세 정보. (화면ID : SC-PA-065)")
	@GetMapping("/select-nonreq-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectNonReqInfo (
			@RequestParam(value="vLabNoteCd", defaultValue = "") String vLabNoteCd
			) {
		log.debug("HbdNoteRequestController.selectNonReqInfo => params : { vLabNoteCd: {} }", vLabNoteCd);

		return ResponseEntity.ok(hbdNoteRequestService.selectNonReqInfo(vLabNoteCd));
	}
}
