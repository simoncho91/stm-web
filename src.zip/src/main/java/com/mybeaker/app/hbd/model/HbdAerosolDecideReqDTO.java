package com.mybeaker.app.hbd.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.labnote.model.PilotRequestDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HbdAerosolDecideReqDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("lotList")
	private List<PilotRequestDTO> lotList;
}
