package com.mybeaker.app.hbd.mapper;

import java.util.List;

import javax.validation.Valid;

import org.apache.ibatis.annotations.Mapper;

import com.mybeaker.app.approval.model.ApprovalDetailDTO;
import com.mybeaker.app.hbd.model.HbdContentDetailDTO;
import com.mybeaker.app.labnote.model.BomShelfLifeDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonTagDTO;
import com.mybeaker.app.labnote.model.LabNotePqcGateCheckListDTO;
import com.mybeaker.app.labnote.model.LabNotePqcGateCheckReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessContDecideListDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessContDecideReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncMateResDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReportDecideContDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReportReqPopDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReportReqSaveDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReportResDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReportResPopDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncRequestQADTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncResDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessIngrdApprDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessIngrdApprReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessMateMixCheckDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessPqcCheckApprReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessTabListDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessTimeLineDTO;
import com.mybeaker.app.labnote.model.PilotRequestDTO;
import com.mybeaker.app.labnote.model.PilotRequestDetailReqDTO;
import com.mybeaker.app.labnote.model.PilotRequestMateDTO;
import com.mybeaker.app.labnote.model.PilotRequestReqDTO;
import com.mybeaker.app.skincare.model.ScNoteLotDTO;
import com.mybeaker.app.skincare.model.VersionContVO;

@Mapper
public interface HbdProcessMapper {
	List<LabNoteProcessTabListDTO> selectProgressTabList(LabNoteProcessReqDTO reqDTO);

	List<LabNoteProcessTimeLineDTO> selectTimeLineList(String vLabNoteCd);

	int selectLabNoteBomReqListCount(PilotRequestReqDTO pilotRequestReqDTO);

	List<PilotRequestDTO> selectLabNoteBomReqList(PilotRequestReqDTO pilotRequestReqDTO);

	public int selectSafetyCtCount(String vLabNoteCd);

	public int selectElabGlobalBanCheck(LabNotePqcGateCheckReqDTO checkDTO);

	int selectLabNoteIngredientApprovalCount(LabNoteProcessIngrdApprReqDTO reqDTO);

	List<LabNoteProcessIngrdApprDTO> selectLabNoteIngredientApprovalList(LabNoteProcessIngrdApprReqDTO reqDTO);

	int selectLabNoteBomSendListCount(PilotRequestReqDTO pilotRequestReqDTO);

	List<PilotRequestDTO> selectLabNoteBomSendList(PilotRequestReqDTO pilotRequestReqDTO);

	int selectLabNoteFuncDecideNameListCount(LabNoteProcessFuncReqDTO reqDTO);

	List<LabNoteProcessFuncResDTO> selectLabNoteFuncDecideNameList(LabNoteProcessFuncReqDTO reqDTO);

	List<ApprovalDetailDTO> selectLabNoteFuncDecideNameApprUserList(String vLabNoteCd);

	int selectFuncTestEpReportListCount(LabNoteProcessFuncReqDTO reqDTO);

	List<LabNoteProcessFuncReportResDTO> selectFuncTestEpReportList(LabNoteProcessFuncReqDTO reqDTO);

	LabNoteProcessFuncReportResPopDTO selectLabNoteFuncRequestQA(LabNoteProcessFuncReportReqPopDTO reqDTO);

	void updateLabNoteFuncRequestQA(@Valid LabNoteProcessFuncReportReqPopDTO reqDTO);

	void insertLabFuncToNewFunc(@Valid LabNoteProcessFuncReportReqPopDTO reqDTO);

	List<LabNoteProcessFuncMateResDTO> selectLabNoteFuncMateList(String vLabNoteCd, int nVersion, String vContPkCd);

	List<LabNoteCommonTagDTO> selectLabNoteMstVerTagList(String tag1Cd, String vLabNoteCd, int nVersion, String localLanguage);

	List<LabNoteProcessMateMixCheckDTO> selectLabNoteMixCheckList(String vLotCd);

	void insertLabNoteContQmsInfo(@Valid LabNoteProcessFuncReportReqSaveDTO reqDTO);

	int insertLabNoteFuncRequestQA(@Valid LabNoteProcessFuncReportReqSaveDTO reqDTO);

	int updateNoteRefNote(@Valid LabNoteProcessFuncReportReqSaveDTO reqDTO);

	List<LabNoteProcessContDecideListDTO> selectLabNoteContDecideList(LabNoteProcessContDecideReqDTO reqDTO);

	List<PilotRequestDTO> selectLabNoteApprBomLotList(PilotRequestDetailReqDTO pilotRequestDetailReqDTO);

	List<PilotRequestMateDTO> selectLabNoteBomMateRateInfo(PilotRequestDetailReqDTO pilotRequestDetailReqDTO);

	List<BomShelfLifeDTO> selectLabNoteShelfLifePqcList(String vApprCd);

	List<LabNotePqcGateCheckListDTO> selectPqcGateResItemList(String vPqcResCd);

	void updateLabContPqcRes(@Valid LabNoteProcessPqcCheckApprReqDTO reqDTO);

	void updateLabContVerPqcRes(@Valid LabNoteProcessPqcCheckApprReqDTO reqDTO);

	List<VersionContVO> selectLabNoteContPlantAllList(String vLabNoteCd, String localLanguage);

	List<ScNoteLotDTO> selectLabNoteContLotAllList(String vLabNoteCd, int nVersion);

	List<LabNoteProcessContDecideListDTO> selectLabNoteContMassList(String vApprCd, String localLanguage);

	void insertLabNoteApprBomInfo(LabNoteProcessPqcCheckApprReqDTO params);

	void updateLabNoteLotApprCd(LabNoteProcessPqcCheckApprReqDTO params);

	List<PilotRequestDTO> selectFormulaDecideList(PilotRequestReqDTO pilotRequestReqDTO);

	String selectHboRepresentContCd(LabNoteProcessFuncReportReqPopDTO reqDTO);

	HbdContentDetailDTO selectHBONoteRequestCont(LabNoteProcessFuncReportReqPopDTO reqDTO);

	List<LabNoteProcessFuncReportDecideContDTO> selectLabNoteDecideContNmList(LabNoteProcessFuncRequestQADTO reqDTO);

	LabNoteProcessFuncResDTO selectLabNoteFuncDecideNameInfo(String vLabNoteCd, String vApprCd, String localLanguage);

	List<PilotRequestDTO> selectAerosolDecideList(String vLabNoteCd, String localLanguage);
}
