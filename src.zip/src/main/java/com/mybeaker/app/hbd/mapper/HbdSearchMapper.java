package com.mybeaker.app.hbd.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.mybeaker.app.hbd.model.HbdContentDetailDTO;
import com.mybeaker.app.hbd.model.HbdContentDetailReqDTO;
import com.mybeaker.app.hbd.model.HbdCounterMapDTO;
import com.mybeaker.app.hbd.model.HbdCounterMapKeywordDTO;
import com.mybeaker.app.hbd.model.HbdMateRateDTO;
import com.mybeaker.app.hbd.model.HbdMstSearchDTO;
import com.mybeaker.app.model.dto.ReqCommSearchInfoDTO;

@Mapper
public interface HbdSearchMapper {

	int selectMstSearchListCount(ReqCommSearchInfoDTO reqCommSearchInfoDTO);
	
	List<HbdMstSearchDTO> selectMstSearchList(ReqCommSearchInfoDTO reqCommSearchInfoDTO);
	
	List<HbdContentDetailDTO> selectContentDetail(HbdContentDetailReqDTO contentDetailReqDTO);
	
	int selectCounterMapKeywordListCount(String vKeyword);
	
	List<HbdCounterMapKeywordDTO> selectCounterMapKeywordList(String vKeyword);
	
	HbdCounterMapKeywordDTO selectCounterMapKeyword(String vCompleteCounterCd);
	
	List<HbdCounterMapDTO> selectCounterMapList(List<String> contPkCdList);
	
	List<HbdMateRateDTO> selectMateRateInfo(HbdContentDetailReqDTO contentDetailReqDTO);
}
