package com.mybeaker.app.hbd.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mybeaker.app.approval.model.ApprovalDetailDTO;
import com.mybeaker.app.common.model.AlarmRegDTO;
import com.mybeaker.app.common.model.MessageDTO;
import com.mybeaker.app.common.service.CommonService;
import com.mybeaker.app.hbd.mapper.HbdCommonMapper;
import com.mybeaker.app.hbd.model.HbdCounterDTO;
import com.mybeaker.app.hbd.model.HbdNoteContDTO;
import com.mybeaker.app.hbd.model.HbdNoteContVO;
import com.mybeaker.app.hbd.model.HbdNoteGroupVO;
import com.mybeaker.app.hbd.model.HbdNoteInfoDTO;
import com.mybeaker.app.hbd.model.HbdNoteInfoRegDTO;
import com.mybeaker.app.hbd.model.HbdNoteLotDTO;
import com.mybeaker.app.hbd.model.HbdNoteLotVO;
import com.mybeaker.app.hbd.model.HbdNoteMateVO;
import com.mybeaker.app.hbd.model.HbdNoteMstVO;
import com.mybeaker.app.hbd.model.HbdNoteRateVO;
import com.mybeaker.app.hbd.model.HbdNoteRequestContDTO;
import com.mybeaker.app.hbd.model.HbdNoteVersionVO;
import com.mybeaker.app.labnote.model.BatchStatusProcessVO;
import com.mybeaker.app.labnote.model.BomAllerenListVO;
import com.mybeaker.app.labnote.model.BomApprovalReqDTO;
import com.mybeaker.app.labnote.model.BomInfoVO;
import com.mybeaker.app.labnote.model.CompleteCounterSearchReqDTO;
import com.mybeaker.app.labnote.model.ElabBomLotVerVO;
import com.mybeaker.app.labnote.model.ElabChgLogDTO;
import com.mybeaker.app.labnote.model.ElabIngredientCheckVO;
import com.mybeaker.app.labnote.model.ElabPrecedeBomHeaderVO;
import com.mybeaker.app.labnote.model.ElabPrecedeBomItemVO;
import com.mybeaker.app.labnote.model.ElabSafeTestDTO;
import com.mybeaker.app.labnote.model.FuncDecideContNameVO;
import com.mybeaker.app.labnote.model.FuncDecideNameVO;
import com.mybeaker.app.labnote.model.Hal4MateRegDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonPlantCheckDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonReq4MRawSearchDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonReqSAPSyncDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonResSAPSyncDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonSAPSyncDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonTagDTO;
import com.mybeaker.app.labnote.model.LabNoteComponentVerVO;
import com.mybeaker.app.labnote.model.LabNoteContInfoVO;
import com.mybeaker.app.labnote.model.LabNoteDecideDTO;
import com.mybeaker.app.labnote.model.LabNoteIngrdApprConInfoVO;
import com.mybeaker.app.labnote.model.LabNoteIngrdApprSaveInfoVO;
import com.mybeaker.app.labnote.model.LabNoteLatestBomInfoVO;
import com.mybeaker.app.labnote.model.LabNoteMateInfoVO;
import com.mybeaker.app.labnote.model.LabNoteMstVersionDTO;
import com.mybeaker.app.labnote.model.LabNoteMstVersionPqcDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessContDecideListDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessPqcCheckApprReqDTO;
import com.mybeaker.app.labnote.model.LabNoteSapBomConSearchVO;
import com.mybeaker.app.labnote.model.LabNoteSapBomToConInfoVO;
import com.mybeaker.app.labnote.model.LabNoteSapRfcMat3AllListVO;
import com.mybeaker.app.labnote.model.LabNoteTestReqApprContVO;
import com.mybeaker.app.labnote.model.LabNoteTestReqLotCompleVO;
import com.mybeaker.app.labnote.model.LabNoteTestRequestProductCntDTO;
import com.mybeaker.app.labnote.model.LabNoteTestRequestProductDTO;
import com.mybeaker.app.labnote.model.LabNoteTestRequestProductReqDTO;
import com.mybeaker.app.labnote.model.LabNoteVersionDTO;
import com.mybeaker.app.labnote.model.LabNoteVersionRegDTO;
import com.mybeaker.app.labnote.model.LaunchCompleteContDTO;
import com.mybeaker.app.labnote.model.LaunchCompleteReqDTO;
import com.mybeaker.app.labnote.model.LotStatusRegDTO;
import com.mybeaker.app.labnote.model.Mat4MMstVO;
import com.mybeaker.app.labnote.model.MusoguReqDTO;
import com.mybeaker.app.labnote.model.MusoguTagVO;
import com.mybeaker.app.labnote.model.ProcCpcVO;
import com.mybeaker.app.labnote.model.SupTrComponentVO;
import com.mybeaker.app.labnote.model.VersionListVO;
import com.mybeaker.app.labnote.model.ZbomHeaderVO;
import com.mybeaker.app.labnote.model.ZbomItemVO;
import com.mybeaker.app.labnote.service.LabNoteCommonService;
import com.mybeaker.app.labnote.service.LabNoteSAPInterfaceService;
import com.mybeaker.app.model.Const;
import com.mybeaker.app.model.dto.PagingDTO;
import com.mybeaker.app.model.dto.ReqCommSearchInfoDTO;
import com.mybeaker.app.model.dto.ResCommSearchInfoDTO;
import com.mybeaker.app.model.enums.CommonResultCode;
import com.mybeaker.app.model.enums.LabNoteResultCode;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.skincare.model.BasicsInfoVerLotVO;
import com.mybeaker.app.skincare.model.BookmarkReqDTO;
import com.mybeaker.app.skincare.model.DecideCancelRegDTO;
import com.mybeaker.app.skincare.model.ElabPqcResVO;
import com.mybeaker.app.skincare.model.FinalLotVO;
import com.mybeaker.app.skincare.model.IngredientContVO;
import com.mybeaker.app.skincare.model.IngredientReqDTO;
import com.mybeaker.app.skincare.model.LotDecideRegDTO;
import com.mybeaker.app.skincare.model.LotPilotRegDTO;
import com.mybeaker.app.skincare.model.MateRateReqVO;
import com.mybeaker.app.skincare.model.MateRateResDTO;
import com.mybeaker.app.skincare.model.MaterialMateVO;
import com.mybeaker.app.skincare.model.MaterialSearchVO;
import com.mybeaker.app.skincare.model.PlantRatePriceReqVO;
import com.mybeaker.app.skincare.model.ValidateVO;
import com.mybeaker.app.skincare.model.VersionReqDTO;
import com.mybeaker.app.utils.CommonUtil;
import com.mybeaker.app.utils.ConvertUtil;
import com.mybeaker.app.utils.SessionUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class HbdCommonService {
	private final HbdCommonMapper hbdCommonMapper;

	private final LabNoteCommonService labNoteCommonService;

	private final CommonService commonService;

	private final SessionUtil sessionUtil;

	private final LabNoteSAPInterfaceService labNoteSAPInterfaceService;

	public int selectLabNoteCounterListCount(ReqCommSearchInfoDTO reqCommSearchInfoDTO) {
		return hbdCommonMapper.selectLabNoteCounterListCount(reqCommSearchInfoDTO);
	}

	public List<HbdCounterDTO> selectLabNoteCounterList(ReqCommSearchInfoDTO reqCommSearchInfoDTO) {
		reqCommSearchInfoDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
		return hbdCommonMapper.selectLabNoteCounterList(reqCommSearchInfoDTO);
	}

	public int selectLabNoteInventoryListCount(ReqCommSearchInfoDTO reqCommSearchInfoDTO) {
		reqCommSearchInfoDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
		return hbdCommonMapper.selectLabNoteInventoryListCount(reqCommSearchInfoDTO);
	}

	public List<HbdCounterDTO> selectLabNoteInventoryList(ReqCommSearchInfoDTO reqCommSearchInfoDTO) {
		reqCommSearchInfoDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
		return hbdCommonMapper.selectLabNoteInventoryList(reqCommSearchInfoDTO);
	}

	@Transactional
	public LabNoteCommonResSAPSyncDTO insertCounterSapSync(LabNoteCommonReqSAPSyncDTO reqSAPSyncDTO) {
		String noteExistYn = hbdCommonMapper.selectLabNoteExistsContInfo(reqSAPSyncDTO);

		if ("Y".equals(noteExistYn)) {
			return LabNoteCommonResSAPSyncDTO.builder()
						.vResultCode(LabNoteResultCode.ALREADY_CONTCD.getCode())
						.build();
		}

		String zqmtExistYn = labNoteCommonService.selectZqmtExistsMatnrInfo(reqSAPSyncDTO);

		if ("N".equals(zqmtExistYn)) {
			return LabNoteCommonResSAPSyncDTO.builder()
					.vResultCode(LabNoteResultCode.NOT_EXIST_CONTCD.getCode())
					.build();
		}

		HbdNoteContDTO contDTO = ConvertUtil.convert(reqSAPSyncDTO, HbdNoteContDTO.class);

		contDTO.setVRegUserid(sessionUtil.getLoginId());
		contDTO.setVUpdateUserid(sessionUtil.getLoginId());

		hbdCommonMapper.insertLabNoteMstCounterSAPInfo(contDTO);
		hbdCommonMapper.insertLabNoteMstVerCounterSAPInfo(contDTO);

		contDTO.setVContNm(labNoteCommonService.selectZqmtContNm(reqSAPSyncDTO));

		hbdCommonMapper.insertLabNoteContCounterSAPInfo(contDTO);
		hbdCommonMapper.insertLabNoteVersionCounterSAPInfo(contDTO);
		hbdCommonMapper.insertLabNoteFinalVersion(contDTO);
		hbdCommonMapper.insertLabNoteFinalLot(contDTO);

		LabNoteCommonSAPSyncDTO sapSyncDTO = ConvertUtil.convert(reqSAPSyncDTO, LabNoteCommonSAPSyncDTO.class);
		sapSyncDTO.setVNoteType("HBO");

		labNoteCommonService.insertElabNoteFinalLotSAPInfo(sapSyncDTO);

		return LabNoteCommonResSAPSyncDTO.builder()
					.vContCd(contDTO.getVContCd())
					.vContNm(contDTO.getVContNm())
					.vLabNoteCd(contDTO.getVLabNoteCd())
					.vContPkCd(contDTO.getVContPkCd())
					.vResultCode(CommonResultCode.SAVE_SUCC.getCode())
					.build();
	}

	public List<LabNoteCommonPlantCheckDTO> selectLabNoteMatePlantCheckList(String vPlantCd, String vContPkCd, String vLotCd) {
		return hbdCommonMapper.selectLabNoteMatePlantCheckList(vPlantCd, vContPkCd, vLotCd);
	}

	public HbdNoteInfoDTO selectLabNoteInfo (String vLabNoteCd) {
		return hbdCommonMapper.selectLabNoteInfo(vLabNoteCd, sessionUtil.getLocalLanguage(), sessionUtil.getLoginId());
	}

	public List<VersionListVO> selectLabNoteVersionList (String vContPkCd) {
		return hbdCommonMapper.selectLabNoteVersionList(VersionReqDTO.builder()
				.vContPkCd(vContPkCd)
				.build());
	}

	public List<VersionListVO> selectLabNoteVersionList (List<String> contPkCdList) {
		return hbdCommonMapper.selectLabNoteVersionList(VersionReqDTO.builder()
				.contPkCdList(contPkCdList)
				.build());
	}

	@Transactional
	public ResponseVO insertElabNoteLatestBomInfo(String vLotCd) {
		ResponseVO responseVO = new ResponseVO();

		String sReurn = "E";

		MaterialSearchVO schVO = new MaterialSearchVO();
		schVO.setVLotCd(vLotCd);

		BasicsInfoVerLotVO infoVO = hbdCommonMapper.selectElabBasicsInfoVerLotCd(vLotCd);

		//SAP에서 SAP애 호출 후 LAB_NOTE_LATEST_BOM_INFO에 저장
		if(!ObjectUtils.isEmpty(infoVO)) {
			List<BomInfoVO> bomList = labNoteSAPInterfaceService.getT_ZPLMS014(infoVO.getVPlantCd(), infoVO.getVContCd());

			if(!ObjectUtils.isEmpty(bomList)) {
				schVO.setVLabNoteCd(infoVO.getVLabNoteCd());
				schVO.setVContPkCd(infoVO.getVContPkCd());
				schVO.setVContCd(infoVO.getVContCd());
				schVO.setNVersion(infoVO.getNVersion());
				schVO.setVPlantCd(infoVO.getVPlantCd());
				schVO.setVSendDatetime(infoVO.getVSendDatetime());

				labNoteCommonService.deleteElabNoteLatestBomInfo(LabNoteLatestBomInfoVO.builder()
						.vLabNoteCd(infoVO.getVLabNoteCd())
						.vContPkCd(infoVO.getVContPkCd())
						.vWerks(infoVO.getVPlantCd())
						.build());

				for(int i = 0; i < bomList.size(); i++) {
					labNoteCommonService.insertElabNoteLatestBomInfo(LabNoteLatestBomInfoVO.builder()
							.vSendDatetime(infoVO.getVSendDatetime())
							.nSendSeq(i + 1)
							.vMatnr(infoVO.getVContCd())
							.vIdnrk(bomList.get(i).getRawCd()) //원료코드
							.vRawPer(bomList.get(i).getRawPer()) //함량
							.vLabNoteCd(infoVO.getVLabNoteCd())
							.vWerks(infoVO.getVPlantCd())
							.vContPkCd(infoVO.getVContPkCd())
							.build());
				}
			}
			else {
				responseVO.setOk("R");
				return responseVO;
			}
		}
		else {
			responseVO.setOk(sReurn);
			return responseVO;
		}

		// 0이면 SAP과 해당 LOT BOM 동일, 0이 아니면 동일하지 않음
		int count = hbdCommonMapper.selectSAPBomItemCount(schVO);
		if(count == 0){
			sReurn = "Y";
		}
		else {
			sReurn = "N";
		}

		responseVO.setOk(sReurn);
		return responseVO;
	}

	@Transactional
	public int insertSAPBomHeaderReq(ZbomHeaderVO zbomHeaderVO) {
		return hbdCommonMapper.insertSAPBomHeaderReq(zbomHeaderVO);
	}

	@Transactional
	public int insertSAPBomItemReq(ZbomItemVO zbomItemVO) {
		return hbdCommonMapper.insertSAPBomItemReq(zbomItemVO);
	}

	public String selectLabNoteContMassEndCheck(String vLabNoteCd) {
		return hbdCommonMapper.selectLabNoteContMassEndCheck(vLabNoteCd);
	}

	@Transactional
	public int updateStatusCd_LNC06_51(String vLabNoteCd) {
		return hbdCommonMapper.updateStatusCd_LNC06_51(vLabNoteCd);
	}

	@Transactional
	public int updateNoteStatusCd(String vLabNoteCd, String vStatusCd) {
		return hbdCommonMapper.updateNoteStatusCd(vLabNoteCd, vStatusCd, sessionUtil.getLoginId());
	}

	@Transactional
	public int deleteLabNoteMate(HbdNoteMateVO hbdNoteMateVO) {
		return hbdCommonMapper.deleteLabNoteMate(hbdNoteMateVO);
	}

	public List<IngredientContVO> selectLabContList(IngredientReqDTO reqDTO){
		return hbdCommonMapper.selectLabContList(reqDTO);
	}

	public List<FuncDecideContNameVO> selectLabNoteFuncDecideContName(FuncDecideNameVO funcDecideNameVO) {
		return hbdCommonMapper.selectLabNoteFuncDecideContName(funcDecideNameVO);
	}

	@Transactional
	public int updateLabNoteContUpdateDecideName(FuncDecideNameVO funcDecideNameVO) {
		return hbdCommonMapper.updateLabNoteContUpdateDecideName(funcDecideNameVO);
	}

	@Transactional
	public int updateLabNoteLotBomSucc(String vLotCd) {
		return hbdCommonMapper.updateLabNoteLotBomSucc(vLotCd);
	}

	@Transactional
	public int updateLabNoteMstBomSucc(String vLabNoteCd) {
		return hbdCommonMapper.updateLabNoteMstBomSucc(vLabNoteCd);
	}

	@Transactional
	public int updateStatusCd_LNC06_25(String vLabNoteCd) {
		return hbdCommonMapper.updateStatusCd_LNC06_25(vLabNoteCd);
	}

	@Transactional
	public int ongoingApprovalRequest(String vLabNoteCd) {
		return hbdCommonMapper.updateStatusCd_LNC06_23(vLabNoteCd);
	}

	public List<MusoguTagVO> selectLabNoteTagList(MusoguReqDTO reqDTO) {
		return hbdCommonMapper.selectLabNoteTagList(reqDTO);
	}

	public LabNoteVersionDTO selectLabNoteMstVerInfo(String vLabNoteCd, int nVersion) {
		return hbdCommonMapper.selectLabNoteMstVerInfo(vLabNoteCd, nVersion, sessionUtil.getLocalLanguage());
	}

	public List<LabNoteMstVersionDTO> selectLabNoteMstVerList(String vLabNoteCd) {
		return hbdCommonMapper.selectLabNoteMstVerList(vLabNoteCd, sessionUtil.getLocalLanguage());
	}

	public ResponseVO selectCompleteCounterList(CompleteCounterSearchReqDTO completeCounterSearchReqDTO) {
		ResponseVO responseVO = new ResponseVO();

		if (!sessionUtil.isSysadmin()) {
			completeCounterSearchReqDTO.setVUserid(sessionUtil.getLoginId());
		}

		int totalCnt = 0;
		List<?> list = null;
		PagingDTO page = null;

		if ("Y".equals(completeCounterSearchReqDTO.getVFlagNp())) {
			ReqCommSearchInfoDTO reqCommSearchInfoDTO = ReqCommSearchInfoDTO.builder()
											.vCodeType(completeCounterSearchReqDTO.getVCodeType())
											.vKeyword(completeCounterSearchReqDTO.getVKeyword())
											.build();

			totalCnt = this.selectLabNoteCounterListCount(reqCommSearchInfoDTO);
			CommonUtil.setPaging(reqCommSearchInfoDTO, totalCnt);

			if (totalCnt > 0) {
				list = this.selectLabNoteCounterList(reqCommSearchInfoDTO);
			}

			page = ConvertUtil.convert(reqCommSearchInfoDTO, PagingDTO.class);
		} else {
			completeCounterSearchReqDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
			totalCnt = hbdCommonMapper.selectLabNoteNonPrdListCount(completeCounterSearchReqDTO);
			CommonUtil.setPaging(completeCounterSearchReqDTO, totalCnt);

			if (totalCnt > 0) {
				list = hbdCommonMapper.selectLabNoteNonPrdList(completeCounterSearchReqDTO);
			}

			page = ConvertUtil.convert(completeCounterSearchReqDTO, PagingDTO.class);
		}

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
										.page(page)
										.list(list)
										.build();

		responseVO.setOk(res);
		return responseVO;
	}

	/**
	 * 실험노트 권한체크
	 * @param schVO
	 * @param noteVo
	 */
	public void selectElabNoteAuth(MaterialSearchVO schVO, HbdNoteInfoDTO noteVo) {
		String isCompleteNote	= "N";
		String isPersonInCharge	= "N";
		String isAssistant		= "N";
		String isRelatedPerson	= "N";
		String isMuDivFlag		= "N";
		String isMuMixingRaw	= "N";

		String userId = sessionUtil.getLoginId(); // 접속한 유저
		String researcherId = noteVo.getVUserid(); // 연구할 연구원
		String allResearcherId = noteVo.getVAllUserid(); //연구할 연구원

		// 완료여부 판단
		if(!ObjectUtils.isEmpty(noteVo)) {
			if("LNC06_50".equals(noteVo.getVStatusCd())) {
				isCompleteNote = "Y";
			}
		}
		schVO.setVIsCompleteNote(isCompleteNote);

		// 담당자 여부 판별 시작
		if (StringUtils.isNotEmpty(userId)){
			// 접속한 사람과 연구원이 같을때와 관리자 일때 // 내용물 담당자일때.
			// 라인 내용물 담당자일 경우
			if (userId.equals(researcherId)
					|| sessionUtil.isSysadmin()
					|| userId.indexOf(allResearcherId) > -1
				) {
				isPersonInCharge = "Y";
			}

			// 2021.07.07
			// 최동원님 >>> 실험노트 연구담당자에 상해연구소(SAP ID 보유 중국연구원) 추가 조치 요청
			// Plant가 CN20일때 연구할 연구원이 CTC담당자 권한으로
			String plant = noteVo.getVPlantCd(); // plant
			String chinaDepts = hbdCommonMapper.selectLabNoteChinaDepts();

			String ctcUserId = noteVo.getVSlUserid(); // CTC 담당자를 사용하지 않으면 SL 담당자로 넣어준다.

			if ("CN20".equals(plant) && chinaDepts.indexOf(noteVo.getVDeptCd()) > -1) {
				// researcherId
				if (userId.indexOf(ctcUserId) > -1) {
					isPersonInCharge = "Y";
				}
			}
		}

		schVO.setVIsPersonInCharge(isPersonInCharge);

		String isContUser = hbdCommonMapper.selectIsLabNoteContUser(schVO);
		isAssistant = "N".equals(isPersonInCharge) && "Y".equals(isContUser) ? "Y" : "N";
		schVO.setVIsAssistant(isAssistant);

		if (StringUtils.isNotEmpty(userId)){
			String isLabNotAuthority = hbdCommonMapper.selectLabNoteAuthority(schVO);
			String isLabNoteAdmin = labNoteCommonService.checkLabNoteAdmin("HBO", schVO.getVIsFlagAuthCheckNonprd());

			//접속한 사람이 관련자와 같을때와 팀장님들 일때
			if(StringUtils.equalsAny(userId
					, noteVo.getVSlUserid(), noteVo.getVBrdUserid(), noteVo.getVPerfUserid())
					|| StringUtils.equalsAny(isLabNoteAdmin, "Y", "N")
					|| "Y".equals(isLabNotAuthority)){
				isRelatedPerson = "Y";
			}

			schVO.setVIsLabNoteAdmin("F".equals(isLabNoteAdmin) ? "N" : isLabNoteAdmin);
		}

		schVO.setVIsRelatedPerson(isRelatedPerson);

		schVO.setVIsMuMixingRaw(isMuMixingRaw);
		schVO.setVIsMuDivFlag(isMuDivFlag);
	}

	public List<LabNoteContInfoVO> selectLabNoteContList(LabNoteContInfoVO labNoteInfoVO) {
		return hbdCommonMapper.selectLabNoteContList(labNoteInfoVO);
	}

	public List<LabNoteContInfoVO> selectLabNotePlantList(LabNoteContInfoVO labNoteInfoVO) {
		return hbdCommonMapper.selectLabNotePlantList(labNoteInfoVO);
	}

	public LabNoteContInfoVO selectLabNoteContInfo(LabNoteContInfoVO labNoteContInfoVO) {
		return hbdCommonMapper.selectLabNoteContInfo(labNoteContInfoVO);
	}

	public Map<String, List<LabNoteMateInfoVO>> selectLabNoteMateListMap(String vContPkCd) {
		Map<String, List<LabNoteMateInfoVO>> rtnMap = new HashMap<>();

		List<LabNoteMateInfoVO> list = hbdCommonMapper.selectLabNoteMateListMap(vContPkCd);

		if (!ObjectUtils.isEmpty(list)) {
			rtnMap = list.stream().collect(Collectors.groupingBy(LabNoteMateInfoVO::getVMateCd));
		}

		return rtnMap;
	}

	public Map<String, List<LabNoteCommonTagDTO>> selectLabNoteRequestTagList(List<String> arrTag1Cd, String vLabNoteCd) {
		Map<String, List<LabNoteCommonTagDTO>> tagListMap;
		List<LabNoteCommonTagDTO> list = hbdCommonMapper.selectLabNoteRequestTagList(arrTag1Cd, vLabNoteCd, sessionUtil.getLocalLanguage());

		if (list != null) {
			tagListMap = list.stream().collect(Collectors.groupingBy(LabNoteCommonTagDTO::getVMstCode));
		} else {
			tagListMap = new HashMap<>();
		}

		return tagListMap;
	}

	public List<HbdNoteRequestContDTO> selectRequestContList(String vLabNoteCd, String vCodeType) {
		return hbdCommonMapper.selectRequestContList(vLabNoteCd, vCodeType);
	}

	public List<HbdNoteContDTO> selectElabNoteContList(String vLabNoteCd) {
		return hbdCommonMapper.selectElabNoteContList(vLabNoteCd, sessionUtil.getLocalLanguage());
	}

	public List<LabNoteCommonTagDTO> selectLabNoteMstTagAllList(String vLabNoteCd) {
		return hbdCommonMapper.selectLabNoteMstTagAllList(vLabNoteCd);
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public void checkContModifyLog(HbdNoteInfoRegDTO mstInfo, Map<String, HbdNoteContDTO> beforeContMap) {
		if (beforeContMap == null) {
			return;
		}

		List<HbdNoteContDTO> contList = this.selectElabNoteContList(mstInfo.getVLabNoteCd());
		boolean isChange;
		HbdNoteContDTO beforeInfo = null;
		Map<String, Object> afterMap = null;
		Map<String, Object> beforeMap = null;

		List<String> arrKey = Arrays.asList(
								"vContCd"
								, "vPrdCd"
								, "vPlantCd"
								, "vContNm"
								, "vNoteContNm"
								, "vUserid"
								, "nPrice"
								, "nCapacity");

		String str = "";

		if ("CN20".equals(mstInfo.getVPlantCd())) {
			str = "[${vContCd} / ${vPrdCd}]\n내용물명 : ${vContNm}\n실험노트명 : ${vNoteContNm}\n\n담당자 : ${vUsernm}";
		} else {
			str = "[${vContCd} / ${vPrdCd}]\n${vContNm}\n\n담당자 : ${vUsernm}";
		}

		ObjectMapper objectMapper = new ObjectMapper();

		String afterContNm = "";
		String beforeContNm = "";

		//ElabChgLogDTO elabChgLogDTO = null;

		if (!ObjectUtils.isEmpty(contList)) {
			for (HbdNoteContDTO afterInfo : contList) {
				afterMap = objectMapper.convertValue(afterInfo, Map.class);
				beforeInfo = beforeContMap.get(afterInfo.getVContPkCd());
				if (beforeInfo == null) {
					// ?
					/*
					elabChgLogDTO = ElabChgLogDTO.builder()
							.vChgFieldCd("CONT")
							.vChgBefore("")
							.vChgAfter(labNoteCommonService.getElabContLogText(afterMap, str))
							.vRegUserid(sessionUtil.getLoginId())
							.build();
					*/
					continue;
				}

				isChange = false;

				beforeMap = objectMapper.convertValue(beforeInfo, Map.class);

				for (int j = 0; j < arrKey.size(); j++) {

					if (!String.valueOf(afterMap.get(arrKey.get(j))).trim().equals(String.valueOf(beforeMap.get(arrKey.get(j))).trim())) {
						isChange = true;
						break;
					}
				}

				if (isChange) {
					hbdCommonMapper.insertLabNoteChgLog(ElabChgLogDTO.builder()
											.vLabNoteCd(mstInfo.getVLabNoteCd())
											.vChgFieldCd("CONT")
											.vChgBefore(labNoteCommonService.getElabContLogText(beforeMap, str))
											.vChgAfter(labNoteCommonService.getElabContLogText(afterMap, str))
											.vRegUserid(sessionUtil.getLoginId())
											.build());
				}

				afterContNm = afterInfo.getVContNm() != null ? afterInfo.getVContNm() : "";
				beforeContNm = beforeInfo.getVContNm() != null ? beforeInfo.getVContNm() : "";
				ElabSafeTestDTO saveDTO = null;
				if (!afterContNm.equals(beforeContNm)) {
					List<ElabSafeTestDTO> safeList = labNoteCommonService.selectLabNoteSafeTestInfoList(mstInfo.getVLabNoteCd(), afterInfo.getVContCd().trim());
					if (!ObjectUtils.isEmpty(safeList)) {
						for (ElabSafeTestDTO safeDTO : safeList) {
							saveDTO = ElabSafeTestDTO.builder()
											.vProductNm(safeDTO.getVProductNm())
											.vProductEngNm(safeDTO.getVProductEngNm())
											.vNewProductNm(afterInfo.getVContNm())
											.vNewProductEngNm(safeDTO.getVProductEngNm())
											.vType(safeDTO.getVType())
											.vProductCd(safeDTO.getVProductCd())
											.vUpdateUserid(sessionUtil.getLoginId())
											.vRegUserid(sessionUtil.getLoginId())
											.build();
							labNoteCommonService.updateLabNoteSafeTestProductNm(saveDTO);
							labNoteCommonService.updateLabNoteSafeTestProductVerNm(saveDTO);
							labNoteCommonService.insertLabNoteSafeTestHist(saveDTO);
						}
					}
				}

				beforeContMap.remove(afterInfo.getVContPkCd());
			}

			if (beforeContMap != null) {
				Iterator<String> itr = beforeContMap.keySet().iterator();
				String chgBefore = "";
				while(itr.hasNext()) {
					chgBefore = labNoteCommonService.getElabContLogText(objectMapper.convertValue(beforeContMap.get((String)itr.next()), Map.class), str);
					hbdCommonMapper.insertLabNoteChgLog(ElabChgLogDTO.builder()
																.vLabNoteCd(mstInfo.getVLabNoteCd())
																.vChgFieldCd("CONT")
																.vChgBefore(chgBefore)
																.vChgAfter("")
																.vRegUserid(sessionUtil.getLoginId())
																.build());
				}
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public void checkModifyLog(HbdNoteInfoRegDTO hbdNoteInfoRegDTO, HbdNoteInfoDTO beforeInfo,
			List<LabNoteCommonTagDTO> beforeMstTagList, HbdNoteInfoDTO afterInfo) {
		if (beforeInfo == null || afterInfo == null) {
			return;
		}

		String[][] arrKey = new String[][] {
			{"vPjtCd", "V_PJT_CD", "[${vRpmsCd}] ${vPjtNm}"} // 예산코드
			, {"vBrdCd", "V_BRD_CD", " ${vBrdNm}"} // 브랜드
			, {"vSlUserid", "V_SL_USERID", "[${vSlUserid}] ${vSlUsernm}"} //Sl 담당자
			, {"vBrdUserid", "V_BRD_USERID", "[${vBrdUserid}] ${vBrdUsernm}"} //브랜드 담당 Pm
			, {"vPerfUserid", "V_PERF_USERID", "[${vPerfUserid}] ${vPerfUsernm}"} //향 담당자
			, {"vUserid", "V_USERID", "[${vUserid}] ${vUsernm}"} //연구 담당자
			, {"vDeptCd", "V_DEPTCD", "${vDeptNm}"} // 담당부서
			, {"vProdType1Cd", "V_PROD_TYPE1_CD", "${vProdType1Nm} - ${vProdType2Nm}", "vProdType2Cd"} // 제품유형
			, {"vFlagNew", "V_FLAG_NEW", ""} // 신상품여부
			, {"vFlagSoap", "V_FLAG_SOAP", ""} // Soap 여부
			, {"vPartCd", "V_PART_CD", "${vPartNm}"} // 적용부위
			, {"vFlagAerosol", "V_FLAG_AEROSOL", ""} // 에어로졸 여부
			, {"vLeaveType", "V_LEAVE_TYPE", "${vLeaveTypeNm}"} // 적용방식
			, {"vPilotDt", "V_PILOT_DT", ""} // 파일럿 시기
			, {"vMeetingDt", "V_MEETING_DT", ""} // 생산회의
			, {"vCustResearchDt", "V_CUST_RESEARCH_DT", ""} // 고객조사시점
			, {"vContainerCd", "V_CONTAINER_CD", "${vContainerNm} (${vContainerEtc})", "vContainerEtc"} // 내용물 용기
			, {"nPrice", "N_PRICE", ""} // 소비자 가격
			, {"nProductCapacity", "N_PRODUCT_CAPACITY", "${nProductCapacity}${vProductCapacityNm}", "vProductCapacityCd"} // 실 제품 용량
			, {"nTargetCost", "N_TARGET_COST", ""} // 타겟 Cost
			, {"nCapacity", "N_CAPACITY", "${nCapacity}${vCapacityNm}", "vCapacityCd"} // 용량
			, {"vEffTestItemDt", "V_EFF_TEST_ITEM_DT", ""} //임상심의 시점
			, {"vOnePoint", "V_ONE_POINT", ""} // One Point
			, {"vTargetCustomer", "V_TARGET_CUSTOMER", ""} // 타겟고객
			, {"vNote", "V_NOTE", ""} // 비고
		};

		boolean isChange = false;

		ObjectMapper objectMapper = new ObjectMapper();
		Map<String, Object> afterMap = objectMapper.convertValue(afterInfo, Map.class);
		Map<String, Object> beforeMap = objectMapper.convertValue(beforeInfo, Map.class);

		for (int i=0; i < arrKey.length; i++) {
			isChange = labNoteCommonService.isElabNoteFieldChange(beforeMap, afterMap, arrKey[i]);

			if (isChange) {
				hbdCommonMapper.insertLabNoteChgLog(ElabChgLogDTO.builder()
										.vLabNoteCd(hbdNoteInfoRegDTO.getVLabNoteCd())
										.vChgFieldCd(arrKey[i][1])
										.vChgBefore(labNoteCommonService.getElabFieldLogText(beforeMap, arrKey[i]))
										.vChgAfter(labNoteCommonService.getElabFieldLogText(afterMap, arrKey[i]))
										.vRegUserid(sessionUtil.getLoginId())
										.build());
			}
		}

		List<LabNoteCommonTagDTO> afterMstTagList = this.selectLabNoteMstTagAllList(hbdNoteInfoRegDTO.getVLabNoteCd());

		arrKey = new String[][] {
			{"RELEASE_DT", "LNC02"}
			, {"EFF_TEST", "LNC15", "#{LNC15}\n\n시험기간 : ${nEffTestDcnt}일\n소구문구 입력 : ${vEffTestSogooMemo}\n임상진행기관 : ${vEffCompTypeNm}\n임상심의 시점 : ${vEffTestItemDt}", "nEffTestDcnt|vEffTestSogooMemo|vEffCompTypeCd|vEffTestItemDt"}
			, {"TEST", "MTI01", "#{MTI01}\n\n임상심의 시점 : ${vTestItemDt}", "vTestItemDt"} // 안전성 임상
			, {"TUSER", "LNC12", ""} // 사용고객
			, {"NOT_ADD", "MTR04|MTR05|MTR06", "무소구 성분 : ${vFlagNotAdd}\n\n공통항목 : #{MTR04}\n특화항목 : #{MTR05}\n협의항목 : #{MTR06}\n비고 : ${vNotAddNote}", "vFlagNotAdd|vNotAddNote"} // 무소구 성분
		};

		for (int i = 0; i < arrKey.length; i++) {
			isChange = labNoteCommonService.isElabNoteTagChange(beforeMap, afterMap, beforeMstTagList, afterMstTagList, arrKey[i]);

			if (isChange) {
				hbdCommonMapper.insertLabNoteChgLog(ElabChgLogDTO.builder()
											.vLabNoteCd(hbdNoteInfoRegDTO.getVLabNoteCd())
											.vChgFieldCd(arrKey[i][0])
											.vChgBefore(labNoteCommonService.getElabTagLogText(beforeMap, beforeMstTagList, arrKey[i]))
											.vChgAfter(labNoteCommonService.getElabTagLogText(afterMap, afterMstTagList, arrKey[i]))
											.vRegUserid(sessionUtil.getLoginId())
											.build());
			}
		}
	}

	@Transactional
	public void insertLabNoteMstTag(HbdNoteInfoRegDTO hbdNoteInfoRegDTO) {
		hbdCommonMapper.insertLabNoteMstTag(hbdNoteInfoRegDTO);
	}

	@Transactional
	public void updateSAPMaterialReq(HbdNoteInfoRegDTO mstInfo) {
		hbdCommonMapper.updateSAPMaterialReq(mstInfo);
	}

	@Transactional
	public void deleteAerosolCont(HbdNoteInfoRegDTO hbdNoteInfoRegDTO) {
		hbdCommonMapper.deleteAerosolCont(hbdNoteInfoRegDTO);
	}

	@Transactional
	public void insertAerosolCont(HbdNoteInfoRegDTO hbdNoteInfoRegDTO) {
		hbdCommonMapper.insertAerosolCont(hbdNoteInfoRegDTO);
	}

	@Transactional
	public void insertLabNoteVersion(LabNoteVersionRegDTO versionInfo) {
		hbdCommonMapper.insertLabNoteVersion(versionInfo);
	}

	@Transactional
	public void insertAerosolContMate(LabNoteVersionRegDTO versionInfo) {
		hbdCommonMapper.insertAerosolContMate(versionInfo);
	}

	@Transactional
	public void updateLabNoteMstCopyNoteContNm(String vLabNoteCd) {
		hbdCommonMapper.updateLabNoteMstCopyNoteContNm(vLabNoteCd);
	}

	@Transactional
	public void updateLabNoteContCopyNoteContNm(String vLabNoteCd) {
		hbdCommonMapper.updateLabNoteContCopyNoteContNm(vLabNoteCd);
	}

	public LabNoteMstVersionPqcDTO selectLabNoteMstVerPqcInfo(String vLabNoteCd, int nVersion) {
		return hbdCommonMapper.selectLabNoteMstVerPqcInfo(vLabNoteCd, nVersion, sessionUtil.getLocalLanguage());
	}

	public LabNoteTestRequestProductCntDTO selectLabNoteTrProductListCountStats(LabNoteTestRequestProductReqDTO trDTO) {
		return hbdCommonMapper.selectLabNoteTrProductListCountStats(trDTO);
	}

	public List<LabNoteTestRequestProductDTO> selectLabNoteTrProductList(LabNoteTestRequestProductReqDTO trDTO) {
		return hbdCommonMapper.selectLabNoteTrProductList(trDTO);
	}


	public List<MusoguTagVO> selectLabNoteTagList(MusoguReqDTO reqDTO, String tag1Cd, String getListType) {
		return this.selectLabNoteTagList(reqDTO, tag1Cd, getListType, null);
	}

	/**
	 * buffer1, 2, 3까지 조회할 수 있는 Tag List 메소드
	 * @param reqDTO
	 * @param tag1Cd
	 * @param getListType
	 * @param subBuffer1
	 * @param subBuffer2
	 * @param subBuffer3
	 * @return
	 */
	public List<MusoguTagVO> selectLabNoteTagList(MusoguReqDTO reqDTO, String tag1Cd, String getListType, String subBuffer1, String subBuffer2, String subBuffer3) {

		String[][] arrBuffer = new String[3][3];

		if (StringUtils.isNotEmpty(subBuffer1)) {
			arrBuffer[0] = new String[]{"buffer1", subBuffer1, ""};
		}

		if (StringUtils.isNotEmpty(subBuffer2)) {
			arrBuffer[1] = new String[]{"buffer2", subBuffer2, ""};
		}

		if (StringUtils.isNotEmpty(subBuffer3)) {
			arrBuffer[2] = new String[]{"buffer3", subBuffer3, ""};
		}

		return this.selectLabNoteTagList(reqDTO, tag1Cd, getListType, arrBuffer);
	}

	//arrBuffer 를 직접적으로 사용하는 경우도 있음. ex) new String[][]{{"buffer1", "HBO", "instr"}}
	public List<MusoguTagVO> selectLabNoteTagList(MusoguReqDTO reqDTO, String tag1Cd, String getListType, String[][] arrBuffer) {
		reqDTO.setVTempTag1Cd(tag1Cd);
		reqDTO.setVGetListType(getListType);

		if (arrBuffer != null) {
			int len = arrBuffer.length;

			for (int i = 0; i < len; i++) {
				if (arrBuffer[i] == null) {
					continue;
				}
				if("buffer1".equals(arrBuffer[i][0])) {
					reqDTO.setVBuffer1(arrBuffer[i][1]);
					if (arrBuffer[i].length >= 3) {
						reqDTO.setVBuffer1SearchType(arrBuffer[i][2]);
					}
				}
				else if("buffer2".equals(arrBuffer[i][0])) {
					reqDTO.setVBuffer2(arrBuffer[i][1]);
					if (arrBuffer[i].length >= 3) {
						reqDTO.setVBuffer2SearchType(arrBuffer[i][2]);
					}
				}
				else if("buffer3".equals(arrBuffer[i][0])) {
					reqDTO.setVBuffer3(arrBuffer[i][1]);
					if (arrBuffer[i].length >= 3) {
						reqDTO.setVBuffer3SearchType(arrBuffer[i][2]);
					}
				}

			}
		}
		return hbdCommonMapper.selectLabNoteTagList(reqDTO);
	}

	public List<ApprovalDetailDTO> selectLabNoteApprovalUserList(String vLabNoteCd, String localLanguage) {
		return hbdCommonMapper.selectLabNoteApprovalUserList(vLabNoteCd, localLanguage);
	}

	public LabNoteIngrdApprConInfoVO selectLabNoteIngredientApproval(LabNoteIngrdApprConInfoVO vo) {
		return hbdCommonMapper.selectLabNoteIngredientApproval(vo);
	}

	public LabNoteIngrdApprSaveInfoVO selectLabNoteIngredientApprovalSaveInfo(LabNoteIngrdApprSaveInfoVO vo) {
		return hbdCommonMapper.selectLabNoteIngredientApprovalSaveInfo(vo);
	}

	public List<HbdNoteLotDTO> selectElabTargetCostList(String[] arrLotCd, int nTargetGram) {
		return hbdCommonMapper.selectElabTargetCostList(arrLotCd, nTargetGram);
	}

	public HbdNoteLotVO selectLabNoteLot(PlantRatePriceReqVO build) {
		return hbdCommonMapper.selectLabNoteLot(build);
	}

	public int updateStatusCd_LNC06_26(String vLabNoteCd) {
		return hbdCommonMapper.updateStatusCd_LNC06_26(vLabNoteCd);
	}

	public LabNoteSapRfcMat3AllListVO getSapRfcMat3AllListMap(LabNoteSapBomConSearchVO reqVo, BomAllerenListVO bomInfo) {
		LabNoteSapRfcMat3AllListVO returnVo = new LabNoteSapRfcMat3AllListVO();

//		if("flagNoData".equals(bomInfo)) {
//			return null;
//		}

		BigDecimal contentPer = new BigDecimal(100);
		BigDecimal dividePer = new BigDecimal(0.0001);

		LabNoteContInfoVO contVo = this.selectLabNoteContInfo(LabNoteContInfoVO.builder()
																			   .vContPkCd(reqVo.getVContPkCd())
																			   .build());
		String rate = "";
		if (contVo != null) {
			rate = hbdCommonMapper.selectHboAerosolContRate(contVo.getVContCd(), contVo.getVPlantCd(), reqVo.getVLabNoteCd());
		}

		if (StringUtils.isNotEmpty(rate)) {
			contentPer = new BigDecimal(rate);
			reqVo.setVFlagAerosolYn("Y");
		}

		// 기준함량을 구한다 - 보통의 경우 0.01이며, HBO의 경우 에어로졸 포함시 0.01을 넘을 수 있음
		reqVo.setStandardPer(contentPer.multiply(dividePer).setScale(6, RoundingMode.HALF_UP).toPlainString());

		if("UN".equals(reqVo.getVLand())) {
			reqVo.setNoAllergenList(bomInfo.getNoAllergenList());
			returnVo.setNoAllergenList(hbdCommonMapper.selectSapBomToConList(reqVo));
		}

		reqVo.setAllergenList(bomInfo.getAllergenList());
		returnVo.setAllergenList(this.getSapBomToConVerAllergenList(reqVo));

		return returnVo;
	}

	public List<LabNoteSapBomToConInfoVO> getSapBomToConVerAllergenList(LabNoteSapBomConSearchVO reqVo) {
		List<LabNoteSapBomToConInfoVO> bomList = null;

		if("L".equals(reqVo.getVLeaveType())){
			reqVo.setNStandardPer("0.001");
		}else if("R".equals(reqVo.getVLeaveType())){
			reqVo.setNStandardPer("0.01");
		} else {
			reqVo.setNStandardPer("0.001");
		}

		bomList = hbdCommonMapper.selectSapBomToConList2(reqVo);

		if(!"UN".equals(reqVo.getVLand())) {
		//ZPLM34일 경우 CARRY OVER값의 기준값에 따라 성분 삭제 진행
			LabNoteSapBomToConInfoVO tempVo = null;
			BigDecimal sumPer = new BigDecimal(0);

			String sMixretxt = "";

			for(Iterator<LabNoteSapBomToConInfoVO> it = bomList.iterator() ; it.hasNext(); ) {
				tempVo = it.next();

				if (StringUtils.isNotEmpty(tempVo.getVMixre())) {
					sMixretxt = tempVo.getVMixre().replaceAll(" ", "");

					if(sMixretxt.indexOf("CARRYOVER") > -1) {
						if( Double.parseDouble(tempVo.getVZabcde()) > Double.parseDouble(tempVo.getNConPer())){
							it.remove();
							continue;
						}
					}
				}

				sumPer = new BigDecimal(tempVo.getNConPer()).add(sumPer);
			}

			reqVo.setVSumRate(String.format("%.7f", sumPer.doubleValue()));
		}

		return bomList;
	}

	public List<FinalLotVO> selectLabNoteFinalLot(BookmarkReqDTO reqDTO) {
		return hbdCommonMapper.selectLabNoteFinalLot(reqDTO);
	}

	public int deleteFinalVersionToRate(String vLotCd) {
		return hbdCommonMapper.deleteFinalVersionToRate(HbdNoteRateVO.builder()
				.vLotCd(vLotCd)
				.build());
	}

	public int deleteFinalVersionToMate(String vContPkCd, Integer nVersion) {
		return hbdCommonMapper.deleteFinalVersionToMate(HbdNoteMateVO.builder()
				.vContPkCd(vContPkCd)
				.nVersion(nVersion)
				.build());
	}

	public String syncToSAP(BookmarkReqDTO reqDTO) {
		List<BomInfoVO> rawList = null;
		boolean saveStatus = false;

		String plantCd = reqDTO.getVPlantCd();
		String contCd = reqDTO.getVContCd();

		if(StringUtils.isNotEmpty(contCd) && StringUtils.isNotEmpty(plantCd)){
			List<BomInfoVO> inciList = labNoteSAPInterfaceService.getT_ZPLMS013(plantCd, contCd, "UN");

			// ZPLMT34E가 존재하지 않으면 ZPLMT34를 호출
			if(ObjectUtils.isEmpty(inciList)) {
				inciList = labNoteSAPInterfaceService.getT_ZPLMS013(plantCd, contCd);
			}

			if(!ObjectUtils.isEmpty(inciList)) {
				BomInfoVO tempVo = null;

				rawList = new ArrayList<>();
				String hal4Cd = "";
				String hal4Per = "";
				String rawCd = "";
				String rawPer = "";
				int cnt = 0;

				for(BomInfoVO inciVo : inciList) {
					tempVo = new BomInfoVO();

					if(StringUtils.isNotEmpty(inciVo.getHal4Cd())) {
						if(hal4Cd.equals(inciVo.getHal4Cd()) && hal4Per.equals(inciVo.getHal4Per())) {
							continue;
						}

						cnt ++;
						hal4Cd = inciVo.getHal4Cd();
						hal4Per = inciVo.getHal4Per();

						tempVo.setNSort(cnt);
						tempVo.setRawCd(hal4Cd);
						tempVo.setRawNm(inciVo.getHal4Nm());
						double t1 = Double.parseDouble(hal4Per);
						tempVo.setRawPer(Double.toString(t1));
					}
					else {
						if(rawCd.equals(inciVo.getRawCd()) && rawPer.equals(inciVo.getRawPer())) {
							continue;
						}

						cnt ++;
						rawCd = inciVo.getRawCd();
						rawPer = inciVo.getRawPer();

						tempVo.setNSort(cnt);
						tempVo.setRawCd(rawCd);
						tempVo.setRawNm(inciVo.getRawNm());
						double t1 = Double.parseDouble(rawPer);
						tempVo.setRawPer(Double.toString(t1));
					}
					rawList.add(tempVo);
				}

				reqDTO.setVGetType("Vo");
				List<FinalLotVO> finalLotList = this.selectLabNoteFinalLot(reqDTO);

				if(!ObjectUtils.isEmpty(finalLotList)) {
					FinalLotVO fvo = finalLotList.stream()
							.findFirst()
							.get();

					String userId = sessionUtil.getLoginId();

					this.deleteFinalVersionToRate(reqDTO.getVLotCd());
					this.deleteFinalVersionToMate(reqDTO.getVContPkCd(), reqDTO.getNVersion());

					for(BomInfoVO rawVO : rawList) {
						HbdNoteMateVO regVO = HbdNoteMateVO.builder()
								.vLabNoteCd(fvo.getVLabNoteCd())
								.vContPkCd(fvo.getVContPkCd())
								.nVersion(fvo.getNVersion())
								.vMateCd(rawVO.getRawCd())
								.vMateNm(rawVO.getRawNm())
								.nSort(rawVO.getNSort())
								.vRegUserid(userId)
								.vUpdateUserid(userId)
								.build();
						hbdCommonMapper.insertLabNoteFinalMate(regVO);
						hbdCommonMapper.insertLabNoteFinalRate(HbdNoteRateVO.builder()
								.vLotCd(fvo.getVLotCd())
								.vMatePkCd(regVO.getVMatePkCd())
								.nRate(rawVO.getRawPer())
								.vRegUserid(userId)
								.vUpdateUserid(userId)
								.build());
					}

					saveStatus = true;
				}
			}
		}

		if(saveStatus){
			return "동기화 완료";
		}else{
			return "동기화 실패";
		}
	}

	public ValidateVO selectLabNoteValidate(ValidateVO vo) {
		return hbdCommonMapper.selectLabNoteValidate(vo);
	}

	public ResponseVO updateLabNoteLotPilot(LotPilotRegDTO regDTO, String vCodeType) {
		ResponseVO responseVO = new ResponseVO();

		ValidateVO vo = this.selectLabNoteValidate(ValidateVO.builder()
				.vContPkCd(regDTO.getVContPkCd())
				.nVersion(regDTO.getNVersion())
				.vLotCd(regDTO.getVLotCd())
				.vLand1(regDTO.getVLand1())
				.vSiteType(regDTO.getVSiteType())
				.build());

		if(ObjectUtils.isEmpty(vo)) {
			responseVO.setOk(Const.SUCC);
			return responseVO;
		}

		boolean isPass = false;
		String vFlagToHundred = "Y";
		if(!Const.AEROSOL.equals(vCodeType)) {
			if(vo.getNCntNotExistsMate() > 0) {
				log.debug("해당 플랜트에 없는 원료가 존재합니다.");
			}
			else if(vo.getNCntUnusableMate() > 0) {
				log.debug("해당 처방에 단종된 원료가 존재합니다.");
			}
			else if(vo.getNCntBanMate() > 0) {
				log.debug("해당 처방에 금지원료가 존재합니다.");
			}
			else if(vo.getNCntTempMate() > 0) {
				log.debug("해당 처방에 임시원료가 존재합니다.");
			}
		}

		if(vo.getNSumRate() != 100) {
			log.debug("원료 배합 합이 100이 아닙니다.");
			isPass = true;
			vFlagToHundred = "N";
		}
		else {
			isPass = true;
		}

		if(isPass) {
			hbdCommonMapper.updateLabNoteLotPilot(HbdNoteLotVO.builder()
					.vLotCd(regDTO.getVLotCd())
					.vFlagToHundred(vFlagToHundred)
					.build());
		}

		responseVO.setOk(Const.SUCC);
		return responseVO;
	}

	@Transactional
	public String updateLabNoteLotDecide(LotDecideRegDTO regDTO) {
		int result = hbdCommonMapper.updateLabNoteLotDecide(HbdNoteLotVO.builder()
				.vLotCd(regDTO.getVLotCd())
				.vTumnTsntLotStCd(Const.LOT_03)
				.build());

		if(result > 0){
			if (!"AEROSOL".equals(regDTO.getVCodeType())) {
				hbdCommonMapper.updateStatusCd_LNC06_30(HbdNoteMstVO.builder()
						.vLabNoteCd(regDTO.getVLabNoteCd())
						.vUpdateUserid(sessionUtil.getLoginId())
						.build());
			}
			hbdCommonMapper.updateLabNoteVersionFlagHideN(HbdNoteVersionVO.builder()
					.vContPkCd(regDTO.getVContPkCd())
					.build());
			hbdCommonMapper.updateLabNoteLotFlagHideN(HbdNoteLotVO.builder()
					.vContPkCd(regDTO.getVContPkCd())
					.build());
			hbdCommonMapper.updateLabNoteMateFlagHideN(HbdNoteMateVO.builder()
					.vContPkCd(regDTO.getVContPkCd())
					.build());
			hbdCommonMapper.updateLabNoteGroupFlagHideN(HbdNoteGroupVO.builder()
					.vContPkCd(regDTO.getVContPkCd())
					.build());

			ProcCpcVO procCpcVO = ProcCpcVO.builder()
					.vLabNoteCd(regDTO.getVLabNoteCd())
					.vContPkCd(regDTO.getVContPkCd())
					.nVersion(regDTO.getNVersion() )
					.vLotCd(regDTO.getVLotCd())
					.vSendActionFlag("F")
					.vNoteType("HBO")
					.build();
			labNoteCommonService.updateLabNoteSendContToCpc(procCpcVO);		// CPC로 내용물 개요 정보 전송
			labNoteCommonService.updateLabNoteSendBomToCpc(procCpcVO);		// CPC로 BOM 정보 전송

			//확정 처방과 SAP BOM처방이 동일하지 않는 경우 확정처방으로 SAP에 전송
			if("Y".equals(regDTO.getVFlagSendDecideBom())) {
				this.updateLabNoteEachLotSendBom(regDTO, "Y", "DECIDE");
			}

			if(regDTO.getVPlantCd().equals(regDTO.getVPlantMstCd())
					&& "Y".equals(regDTO.getVFlagRepresent())) {

				hbdCommonMapper.updateLabNoteResCost(HbdNoteMstVO.builder()
						.vLabNoteCd(regDTO.getVLabNoteCd())
						.vContPkCd(regDTO.getVContPkCd())
						.nVersion(regDTO.getNVersion() )
						.vLotCd(regDTO.getVLotCd())
						.build());
			}

			// *_NOTE_VERSION 에 G1 데이터 갱신
			// 에어로졸은 GI 데이터 없으므로 수행하지 않음
			ElabPqcResVO gate1Info = hbdCommonMapper.selectGate1Info(regDTO.getVLotCd());
			if(!ObjectUtils.isEmpty(gate1Info)) {
				hbdCommonMapper.updateGate1Info(HbdNoteVersionVO.builder()
						.vLabNoteCd(regDTO.getVContPkCd())
						.nVersion(regDTO.getNVersion())
						.vG1PqcResCd(gate1Info.getVPqcResCd())
						.vG1PqcLotCd(regDTO.getVLotCd())
						.nG1ObeyPer(gate1Info.getNObeyPer())
						.build());
			}

			//과거 버전 확정시 VER에 저장되어 있는 PQC정보를 CONT 테이블에 저장
			hbdCommonMapper.updateLabNoteCopyVerPqcData(HbdNoteContVO.builder()
					.vLotCd(regDTO.getVLotCd())
					.build());

			// TODO :: jslee 로직 확인 필요
			/*
			if(cnt > 0) {
				//과거 버전 확장처방시 상태값을 양산승인으로 바꿀것인지 확인
				String flagTot = this.selectLabNoteContMassEndCheck(regDTO.getVLabNoteCd());

				if("Y".equals(flagTot)) {
					this.updateStatusCd_LNC06_51(regDTO.getVLabNoteCd());
				}
			}
			*/

			commonService.insertLotStatusHistory(LotStatusRegDTO.builder()
													.vLabNoteCd(regDTO.getVLabNoteCd())
													.nVersion(regDTO.getNVersion())
													.vContPkCd(regDTO.getVContPkCd())
													.vLotCd(regDTO.getVLotCd())
													.vLabStatusCd(Const.LOT_03)
													.build());

			return "SUCC";
		}
		else {
			return "FAIL";
		}
	}

	public String selectLabNotePrecedePkCd() {
		return hbdCommonMapper.selectLabNotePrecedePkCd();
	}

	@Transactional
	public ResponseVO updateLabNoteEachLotSendBom(LotDecideRegDTO regDTO, String vFlagPrecede, String sBomType) {
		ResponseVO responseVO = new ResponseVO();
		String sPrecedePkCd = "";
		if("Y".equals(vFlagPrecede)) {
			sPrecedePkCd = this.selectLabNotePrecedePkCd();
		}

		ValidateVO vo = this.selectLabNoteValidate(ValidateVO.builder()
				.vContPkCd(regDTO.getVContPkCd())
				.nVersion(regDTO.getNVersion())
				.vLotCd(regDTO.getVLotCd())
				.vLand1(regDTO.getVLand1())
				.build());

		if(vo.getNCntNotExistsMate() > 0) {
			responseVO.setOk("해당 플랜트에 없는 원료가 존재합니다.");
		}
		else if(vo.getNCntUnusableMate() > 0) {
			responseVO.setOk("해당 처방에 단종된 원료가 존재합니다.");
		}
		else if(vo.getNCntBanMate() > 0) {
			responseVO.setOk("해당 처방에 금지원료가 존재합니다.");
		}
		else if(vo.getNCntTempMate() > 0) {
			responseVO.setOk("해당 처방에 임시원료가 존재합니다.");
		}
		else if(vo.getNSumRate() != 100) {
			responseVO.setOk("원료 배합 합이 100이 아닙니다.");
		}
		else if("Y".equals(vo.getVFlagExistsBom()) && (!"DECIDE".equals(sBomType))) {
			responseVO.setOk("이미 등록된 BOM이 존재합니다.");
		}
		else {
			String vUserid = sessionUtil.getLoginId();

			//선행전송 부분 저장
			labNoteCommonService.insertLabNotePrecedeBomHeader(ElabPrecedeBomHeaderVO.builder()
					.vPrecedePkCd(sPrecedePkCd)
					.vLotCd(regDTO.getVLotCd())
					.vRegUserid(vUserid)
					.vUpdateUserid(vUserid)
					.build());
			hbdCommonMapper.insertLabNotePrecedeBomItem(ElabPrecedeBomItemVO.builder()
					.vPrecedePkCd(sPrecedePkCd)
					.vLotCd(regDTO.getVLotCd())
					.vRegUserid(vUserid)
					.vUpdateUserid(vUserid)
					.build());

			//BOM 전송파트 저장
			ElabBomLotVerVO bomLotVerVO = ElabBomLotVerVO.builder()
					.vLabNoteCd(regDTO.getVLabNoteCd())
					.vLotCd(regDTO.getVLotCd())
					.vBomType(sBomType)
					.vTempPkCd(sPrecedePkCd)
					.vRegUserid(vUserid)
					.vUpdateUserid(vUserid)
					.build();
			labNoteCommonService.insertElabBomLotVer(bomLotVerVO);

			ResponseVO res = this.insertElabNoteLatestBomInfo(regDTO.getVLotCd());
			String CheckCd = res.getMessage();

			ZbomHeaderVO zbomHeaderVO = ZbomHeaderVO.builder()
					.vLabNoteCd(regDTO.getVLabNoteCd())
					.vContPkCd(regDTO.getVContPkCd())
					.nVersion(regDTO.getNVersion())
					.vLotCd(regDTO.getVLotCd())
					.vFlagPrecede(vFlagPrecede)
					.vBomLotVer(bomLotVerVO.getVBomLotVer())
					.build();
			ZbomItemVO zbomItemVO = ZbomItemVO.builder()
					.vLabNoteCd(regDTO.getVLabNoteCd())
					.vContPkCd(regDTO.getVContPkCd())
					.nVersion(regDTO.getNVersion())
					.vLotCd(regDTO.getVLotCd())
					.build();

			if("R".equals(CheckCd)) {
				this.insertSAPBomHeaderReq(zbomHeaderVO);

				zbomItemVO.setVSendDatetime(zbomHeaderVO.getVSendDatetime());
				this.insertSAPBomItemReq(zbomItemVO);
			}
			else if("N".equals(CheckCd)) {
				//SAP에 데이터 가 존재시 강제로 U로 전송
				zbomHeaderVO.setVCudCi("U");
				this.insertSAPBomHeaderReq(zbomHeaderVO);

				zbomItemVO.setVSendDatetime(zbomHeaderVO.getVSendDatetime());
				this.insertSAPBomItemReq(zbomItemVO);
			}
			else if("Y".equals(CheckCd)) {
				//SAP과 동일하기 때문에 전송 성공처리
				bomLotVerVO.setVBomSendType("S");
				bomLotVerVO.setVBomSendMessage("SAP와 동일하여 성공처리 하였습니다.");
				labNoteCommonService.updateElabBomLotVerType(bomLotVerVO);
			}
			else {
				//SAP과 확인하는 과정에서 에러처리
				bomLotVerVO.setVBomSendType("E");
				bomLotVerVO.setVBomSendMessage("SAP와 확인하는 과정에서 에러가 발생하여 에러 처리하였습니다.");
				labNoteCommonService.updateElabBomLotVerType(bomLotVerVO);
			}
		}

		responseVO.setOk(Const.SUCC);
		return responseVO;
	}

	@Transactional
	public ResponseVO updateDecideCancel(DecideCancelRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();

		// 확정 해제 + 전성분 승인 초기화
		hbdCommonMapper.updateDecideCancel(HbdNoteLotVO.builder()
				.vLabNoteCd(regDTO.getVLabNoteCd())
				.vContPkCd(regDTO.getVContPkCd())
				.vLotCd(regDTO.getVLotCd())
				.build());

		// 해당 내용물코드 + 버전의 양산승인 데이터 초기화
		hbdCommonMapper.updateGate2Cancel(HbdNoteVersionVO.builder()
				.vContPkCd(regDTO.getVContPkCd())
				.build());

		// 상태를 BOM 승인완료로 변경
		if (!"Y".equals(regDTO.getVFlagAerosol())) {
			hbdCommonMapper.updateStatusCd_LNC06_24(HbdNoteMstVO.builder()
					.vLabNoteCd(regDTO.getVLabNoteCd())
					.build());
			
			commonService.sendAlarm(AlarmRegDTO.builder()
										.vLabNoteCd(regDTO.getVLabNoteCd())
										.vStatusCd("AL_NOTE4")
										.vAlrTypeCd("AL_NOTE4_05")
										.typeList(Arrays.asList(Const.SCHEDULE, Const.TIMELINE, Const.ALARM))
										.vContCd(regDTO.getVContCd())
										.vContNm(regDTO.getVContNm())
										.nVerNo((regDTO.getNVersion() < 10 ? "0" : "") + String.valueOf(regDTO.getNVersion()))
										.vLotNm(regDTO.getVLotNm())
										.userList(Arrays.asList(commonService.selectLabLeaderid(regDTO.getVDeptCd())))
										.vNoteType("HBO")
										.build());
		}

		this.updateNoteLotStatusCd(regDTO.getVLotCd(), Const.LOT_02);

		this.updateNoteMstNoiValue(regDTO.getVContPkCd(), regDTO.getNVersion(), false);

		responseVO.setOk(Const.SUCC);
		return responseVO;
	}

	public String selectElabApprTitleNm(LabNoteProcessPqcCheckApprReqDTO reqDTO) {
		List<LabNoteTestReqApprContVO> list = hbdCommonMapper.selectApprContList(reqDTO);
		String rtn = "";

		int size = list == null ? 0 : list.size();
		if(size == 0) {
			return "";
		}

		LabNoteTestReqApprContVO tvo = list.get(0);
		if(StringUtils.isEmpty(tvo.getVContCd())) {
			rtn = tvo.getVContNm();
		}else {
			rtn = "(" + tvo.getVContCd() + ")" + tvo.getVContNm();
		}

		if(size > 1) {
			rtn += " 외 " + (size-1) + "건";
		}

		return rtn;
	}

	public String selectLabNoteStatusCd(String vLabNoteCd) {
		return hbdCommonMapper.selectLabNoteStatusCd(vLabNoteCd);
	}

	public ResponseVO selectLabNoteMateRateInfo(MateRateReqVO reqVO) {
		ResponseVO responseVO = new ResponseVO();
		reqVO.setLanguage(sessionUtil.getLangCd());
		responseVO.setOk(Optional.ofNullable(this.selectLabNoteMateInfo(reqVO))
									.orElseGet(() -> List.of()));
		return responseVO;
	}

	public List<MateRateResDTO> selectLabNoteMateInfo (MateRateReqVO reqVO) {
		return hbdCommonMapper.selectLabNoteMateRateInfo(reqVO);
	}

//	[AS-IS] LabNoteCommonServiceImpl - updateAcceptApprovalRequest - 587 line 부터 참고
	@Transactional
	public int updateAcceptApprovalRequest(BomApprovalReqDTO bomApprovalReqDTO) {
		List<String> contPkCdList = bomApprovalReqDTO.getContPkCdList();
		List<String> lotCdList = bomApprovalReqDTO.getLotCdList();

		bomApprovalReqDTO.setVFlagPrecede("N");
		int result = 0;

		hbdCommonMapper.updateLabNoteMstFlagPilot(bomApprovalReqDTO.getVLabNoteCd());
		if (!ObjectUtils.isEmpty(lotCdList)) {
			for(int i = 0; i < lotCdList.size(); i++) {
				bomApprovalReqDTO.setVContPkCd(contPkCdList.get(i));
				bomApprovalReqDTO.setVLotCd(lotCdList.get(i));
				bomApprovalReqDTO.setVTumnTsntLotStCd(Const.LOT_02);

				// 파일럿 완료일자, 상태 업데이트
				hbdCommonMapper.updateLabNoteLotPilotComplete(bomApprovalReqDTO);

				//SAP호출 후 해당 LOT의 BOM과 비교하여 처리
				this.updateElabNoteBomSendSap(bomApprovalReqDTO);

				// CPC 정보 전송
				labNoteCommonService.savePilotCompleteCpc(bomApprovalReqDTO);

				commonService.insertLotStatusHistory(LotStatusRegDTO.builder()
															.vLabNoteCd(bomApprovalReqDTO.getVLabNoteCd())
															.nVersion(bomApprovalReqDTO.getNVersion())
															.vContPkCd(bomApprovalReqDTO.getVContPkCd())
															.vLotCd(bomApprovalReqDTO.getVLotCd())
															.nPilotNo(String.valueOf(bomApprovalReqDTO.getNPilotTestSeqno()))
															.vLabStatusCd(Const.LOT_02)
															.build());

				result++;
			}
		}

		return result;
	}

//	[AS-IS] LabNoteCommonServiceImpl - updateElabNoteBomSendSap - 8390 line 부터 참고
	@Transactional
	private void updateElabNoteBomSendSap(BomApprovalReqDTO bomApprovalReqDTO) {
		ResponseVO res = this.insertElabNoteLatestBomInfo(bomApprovalReqDTO.getVLotCd());
		String CheckCd = (String) res.getData();

		String vBomLotVer = labNoteCommonService.selectStringElabBomLotVer(bomApprovalReqDTO.getVLotCd(), bomApprovalReqDTO.getVApprCd());

		if ("R".equals(CheckCd) || "N".equals(CheckCd)) {
			ZbomHeaderVO zbomHeaderVO = ZbomHeaderVO.builder()
													.vLabNoteCd(bomApprovalReqDTO.getVLabNoteCd())
													.vContPkCd(bomApprovalReqDTO.getVContPkCd())
													.nVersion(bomApprovalReqDTO.getNVersion())
													.vLotCd(bomApprovalReqDTO.getVLotCd())
													.vFlagPrecede(bomApprovalReqDTO.getVFlagPrecede())
													.vBomLotVer(vBomLotVer)
													.build();
			ZbomItemVO zbomItemVO = ZbomItemVO.builder()
											  .vLabNoteCd(bomApprovalReqDTO.getVLabNoteCd())
											  .vContPkCd(bomApprovalReqDTO.getVContPkCd())
											  .nVersion(bomApprovalReqDTO.getNVersion())
											  .vLotCd(bomApprovalReqDTO.getVLotCd())
											  .build();

			if("R".equals(CheckCd)) {
				this.insertSAPBomHeaderReq(zbomHeaderVO);

				zbomItemVO.setVSendDatetime(zbomHeaderVO.getVSendDatetime());
				this.insertSAPBomItemReq(zbomItemVO);
			} else if ("N".equals(CheckCd)) {
				//SAP에 데이터 가 존재시 강제로 U로 전송
				zbomHeaderVO.setVCudCi("U");
				this.insertSAPBomHeaderReq(zbomHeaderVO);

				zbomItemVO.setVSendDatetime(zbomHeaderVO.getVSendDatetime());
				this.insertSAPBomItemReq(zbomItemVO);
			}
		} else if ("Y".equals(CheckCd) || "E".equals(CheckCd)) {
			ElabBomLotVerVO bomLotVerVO = ElabBomLotVerVO.builder()
														 .vLabNoteCd(bomApprovalReqDTO.getVLabNoteCd())
														 .vLotCd(bomApprovalReqDTO.getVLotCd())
														 .vBomLotVer(vBomLotVer)
														 .vUpdateUserid(sessionUtil.getLoginId())
														 .build();

			if ("Y".equals(CheckCd)) {
				this.updateLabNoteLotBomSucc(bomLotVerVO.getVLotCd());
				this.updateLabNoteMstBomSucc(bomLotVerVO.getVLabNoteCd());

				//SAP과 동일하기 때문에 전송 성공처리
				bomLotVerVO.setVBomSendType("S");
				bomLotVerVO.setVBomSendMessage("SAP와 동일하여 성공처리 하였습니다.");
				labNoteCommonService.updateElabBomLotVerType(bomLotVerVO);
			} else if ("E".equals(CheckCd)) {
				//SAP과 확인하는 과정에서 에러처리
				bomLotVerVO.setVBomSendType("E");
				bomLotVerVO.setVBomSendMessage("SAP와 확인하는 과정에서 에러가 발생하여 에러 처리하였습니다.");
				labNoteCommonService.updateElabBomLotVerType(bomLotVerVO);
			}
		}
	}

	/**
	 * @param schVO
	 * @param list
	 * @return
	 */
	public List<MaterialMateVO> checkIngredientOrganization (MaterialSearchVO schVO) {
		String matnr = null;

		List<BomInfoVO> rfcList = null;
		String werks = schVO.getVPlantCd();
		String land1 = schVO.getVLand1();

		schVO.setVWerks(werks);
		schVO.setVLand1(land1);

		List<MaterialMateVO> list = hbdCommonMapper.selectLabNoteMateAndGrpList(schVO);

		if(!ObjectUtils.isEmpty(list)) {
			for(MaterialMateVO vo : list) {
				matnr = vo.getVMateCd();

				if(StringUtils.isEmpty(vo.getVMateCd())) {
					continue;
				}

				schVO.setVMatnr(matnr);

				String zplmt13Tx = labNoteCommonService.selectZplmt13Tx(schVO.getVMatnr(), schVO.getVLand1());
				if("LAB_CONT".equals(vo.getVMateDbTypeCd()) || "O".equals(zplmt13Tx)) {
					vo.setVFlagOrganizationMate("Y");
					continue;
				}
				else {
					ElabIngredientCheckVO zvo = labNoteCommonService.selectElabIngredientCheck(schVO.getVMatnr(), schVO.getVWerks(), schVO.getVLand1());

					if(!ObjectUtils.isEmpty(zvo) && "Y".equals(zvo.getVFlagOrganization())) {
						vo.setVFlagOrganizationMate("Y");
						continue;
					}
					else {
						if(ObjectUtils.isEmpty(zvo) || "Y".equals(zvo.getVFlagRefresh())) {
							if(matnr.startsWith("4")) {
								rfcList = labNoteSAPInterfaceService.getT_ZPLMS013(werks, matnr, land1);
							}
							else {
								rfcList = labNoteSAPInterfaceService.getT_ZPLMS017(matnr, land1);
							}

							String flag = !ObjectUtils.isEmpty(rfcList) ? "Y" : "N";

							labNoteCommonService.insertElabIngredientCheck(ElabIngredientCheckVO.builder()
									.vMatnr(matnr)
									.vWerks(werks)
									.vFlagOrganization(flag)
									.vLand1(land1)
									.build());

							vo.setVFlagOrganizationMate(flag);
						}else {
							vo.setVFlagOrganizationMate("N");
						}
					}
				}
			}
		}

		return list;
	}

	@Transactional
	public void insertTrLabNoteComponent(SupTrComponentVO componentVO) {					// 처방(랩노트) 등록

		if (StringUtils.isNotEmpty(componentVO.getVLotCd())) {

			MaterialSearchVO schVO = new MaterialSearchVO();
			schVO.setNLatestVersion(componentVO.getNVersion());
			schVO.setNVersion(componentVO.getNVersionTestReq());

			//4자정보 리스트 가져와서 ELAB_HAL4_MATE 비교하여 없으면 저장
			//ELAB_HAL4_MATE 4자정보 저장
			schVO.setVPlantCd(componentVO.getVWerks());

			schVO.setVLand1(componentVO.getVLand1());
			schVO.setVContPkCd(componentVO.getVContPkCd());

			List<MaterialMateVO> mateList = this.checkIngredientOrganization(schVO);
			MaterialMateVO mateVo = null;

			int mateListLen = mateList == null ? 0 : mateList.size();

			for(int i=0; i<mateListLen; i++){
				mateVo = mateList.get(i);
				//GRP 은 vMateCd가 null 이라 분기 추가함
				if("MATE".equals(mateVo.getVRecType())) {
					if(mateVo.getVMateCd().startsWith("4")){ // // 4자코드 원료처방 저장
						labNoteCommonService.insertHal4Mate(Hal4MateRegDTO.builder()
								.vMateCd(mateVo.getVMateCd())
								.vPlantCd(schVO.getVPlantCd())
								.vLand1(schVO.getVLand1())
								.build());
					}
				}
			}

			labNoteCommonService.deleteTrComponent(componentVO);

			List<LabNoteComponentVerVO> labNoteList = labNoteCommonService.selectLabNoteComponentVer2(LabNoteComponentVerVO.builder()
					.vProductCd(componentVO.getVProductCd())
					.nVersion(componentVO.getNVersion())
					.vContCd(componentVO.getVContCd())
					.vRegUserid(sessionUtil.getLoginId())
					.vLangCd(componentVO.getVLangCd())
					.vLotCd(componentVO.getVLotCd())
					.build());

			if (!ObjectUtils.isEmpty(labNoteList)) {
				labNoteCommonService.insertTrLabNoteComponent2(labNoteList);
			}
		}
	}

	public int selectMat4MMstListCount(LabNoteCommonReq4MRawSearchDTO reqDTO) {
		reqDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
		return hbdCommonMapper.selectMat4MMstListCount(reqDTO);
	}

	public List<Mat4MMstVO> selectMat4MMstList(LabNoteCommonReq4MRawSearchDTO reqDTO) {
		reqDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
		return hbdCommonMapper.selectMat4MMstList(reqDTO);
	}

	public int labNoteInsertMessage(MessageDTO messageDTO) {
		int result = labNoteCommonService.insertMessage(messageDTO);
		String laborUserid = messageDTO.getVLaborUserid();

		if (result > 0 && StringUtils.isNotEmpty(laborUserid) && !laborUserid.equals(sessionUtil.getLoginId())) {
			HbdNoteInfoDTO noteInfo = this.selectLabNoteInfo(messageDTO.getVRecordid());
			String notePageType = "LNC07_01".equals(noteInfo.getVLabTypeCd()) ? "prd"
								: ("LNC07_02".equals(noteInfo.getVLabTypeCd()) ? "half" : "nonprd");

			String vUrl = new StringBuilder()
								.append("/hbd/")
								.append("all-lab-note-")
								.append(notePageType)
								.append("-view?vLabNoteCd=")
								.append(messageDTO.getVRecordid())
								.toString();
			commonService.sendAlarm(AlarmRegDTO.builder()
										.vLabNoteCd(messageDTO.getVRecordid())
										.vStatusCd("AL_NOTE0")
										.vAlrTypeCd("AL_NOTE0_01")
										.typeList(Arrays.asList(Const.ALARM, Const.TIMELINE))
										.vContCd(noteInfo.getVContCd())
										.vContNm(noteInfo.getVContNm())
										.vMoveUrl(vUrl)
										.userList(Arrays.asList(laborUserid))
										.build());
		}

		return result;
	}

	@Transactional
	public void updateLabNoteLotComplete(String vLotCd) {
		// LOT 잠김 처리

		if (StringUtils.isNotEmpty(vLotCd)) {

			//vFlagComplete가 값이 N일때만 아래 부분 적용
			LabNoteTestReqLotCompleVO lotComVo = hbdCommonMapper.selectLabNoteLotCompleteChk(vLotCd);

			if("N".equals(lotComVo.getVFlagComplete())) {
				// 화면설계서 page-60
				// - 시험의뢰가 발생하면 해당 LOT 잠김 처리( 기존은 실험결과 등록 시 잠김 처리 to-be : 시험의뢰 발생 시 )
				hbdCommonMapper.updateLabNoteLotComplete(vLotCd);
			}

		}

	}

	public ResponseVO selectLabNoteMstBaseInfo(String vLabNoteCd) {
		ResponseVO responseVO = new ResponseVO();
		responseVO.setOk(hbdCommonMapper.selectLabNoteMstBaseInfo(vLabNoteCd));
		return responseVO;
	}

	@Transactional
	public int updateNoteLotStatusCd(String vLotCd, String vTumnTsntLotStCd) {
		return hbdCommonMapper.updateNoteLotStatusCd(vLotCd, vTumnTsntLotStCd);
	}

	@Transactional
	public int updateNoteMstNoiValue(String vContPkCd, int nVersion, boolean isDecide) {
		List<MaterialMateVO> list = hbdCommonMapper.selectLabNoteMateSimpleList(vContPkCd, nVersion);
		if(!ObjectUtils.isEmpty(list)) {
			list.forEach(o -> {
				String nNoiRsltVl = isDecide ? StringUtils.defaultIfEmpty(o.getNNoiRsltVl(), "-1") : null;
				hbdCommonMapper.updateNoteMstNoiValue(o.getVMatePkCd(), nNoiRsltVl);
			});
		}
		return list.size();
	}

	public ResponseVO updateLotFlagSend(HbdNoteLotVO hbdNoteLotVO) {
		ResponseVO responseVO = new ResponseVO();
		hbdCommonMapper.updateLotFlagSend(hbdNoteLotVO);
		responseVO.setOk(null);
		return responseVO;
	}

	public ResponseVO updateLotFlagExposure(HbdNoteLotVO hbdNoteLotVO) {
		ResponseVO responseVO = new ResponseVO();
		hbdCommonMapper.updateLotFlagExposure(hbdNoteLotVO);
		responseVO.setOk(null);
		return responseVO;
	}

	public List<LabNoteContInfoVO> checkSubPlantList(String vLabNoteCd, String vContCd) {
		return hbdCommonMapper.checkSubPlantList(vLabNoteCd, vContCd);
	}

	public List<LabNoteProcessContDecideListDTO> selectGate2ApprLotList(String vApprCd) {
		return hbdCommonMapper.selectGate2ApprLotList(vApprCd);
	}

	@Transactional
	public void updateLabNoteStats01(LaunchCompleteContDTO contDTO) {
		hbdCommonMapper.updateLabNoteStats01(contDTO);
	}

	@Transactional
	public void updateLabNoteStats02(LaunchCompleteContDTO contDTO) {
		hbdCommonMapper.updateLabNoteStats02(contDTO);
	}

	@Transactional
	public void updateLabNoteStats03(LaunchCompleteContDTO contDTO) {
		hbdCommonMapper.updateLabNoteStats03(contDTO);
	}

	@Transactional
	public void updateLabNoteSustainabilityStats01(LaunchCompleteContDTO contDTO) {
		hbdCommonMapper.updateLabNoteSustainabilityStats01(contDTO);
	}

	@Transactional
	public void updateLabNoteSustainabilityStats02(LaunchCompleteContDTO contDTO) {
		hbdCommonMapper.updateLabNoteSustainabilityStats02(contDTO);
	}

	@Transactional
	public void updateLabNoteSustainabilityStats03(LaunchCompleteContDTO contDTO) {
		hbdCommonMapper.updateLabNoteSustainabilityStats03(contDTO);
	}

	public List<LabNoteDecideDTO> selectLabNoteDecideInfoList(LaunchCompleteContDTO contDTO) {
		return hbdCommonMapper.selectLabNoteDecideInfoList(contDTO);
	}

	@Transactional
	public void insertLabNoteFinalVersion(HbdNoteContDTO contDTO) {
		hbdCommonMapper.insertLabNoteFinalVersion(contDTO);
	}

	@Transactional
	public void insertLabNoteFinalLot(HbdNoteContDTO contDTO) {
		hbdCommonMapper.insertLabNoteFinalLot(contDTO);
	}

	@Transactional
	public void insertLabNoteFinalMate(HbdNoteMateVO hbdNoteMateVO) {
		hbdCommonMapper.insertLabNoteFinalMate(hbdNoteMateVO);
	}

	@Transactional
	public void insertLabNoteFinalRate(HbdNoteRateVO hbdNoteRateVO) {
		hbdCommonMapper.insertLabNoteFinalRate(hbdNoteRateVO);
	}

	public String selectLabNoteFlagAllLaunchComplete(String vLabNoteCd) {
		return hbdCommonMapper.selectLabNoteFlagAllLaunchComplete(vLabNoteCd);
	}

	@Transactional
	public void updateLabNoteMstLaunchComplete(LaunchCompleteReqDTO launchCompleteDTO) {
		hbdCommonMapper.updateLabNoteMstLaunchComplete(launchCompleteDTO);
	};

	public List<HbdCounterDTO> selectSpCodeNoteList(String vSpCode) {
		return hbdCommonMapper.selectSpCodeNoteList(sessionUtil.getLocalLanguage(), vSpCode);
	}

	public int selectSpCodeNoteListCount(String vSpCode) {
		return hbdCommonMapper.selectSpCodeNoteListCount(vSpCode);
	}

	@Transactional
	public void saveNoteReleaseInfo(List<BatchStatusProcessVO> targetList) {
		List<String> allCompleteCodeList = new ArrayList<String>();
		for (BatchStatusProcessVO targetVO : targetList) {
			LaunchCompleteReqDTO launchCompleteDTO = LaunchCompleteReqDTO.builder()
															.vLabNoteCd(targetVO.getVLabNoteCd())
															.vCompleteDt(targetVO.getVCompleteDt())
															.build();

			LaunchCompleteContDTO contDTO = ConvertUtil.convert(launchCompleteDTO, LaunchCompleteContDTO.class);
			contDTO.setVRegUserid("BATCH");
			contDTO.setVUpdateUserid("BATCH");
			contDTO.setLocalLanguage("_ko");
			contDTO.setVLaunchCompleteDt(launchCompleteDTO.getVCompleteDt());
			contDTO.setVLaunchCompleteType("CONT");
			contDTO.setVContPkCd(targetVO.getVContPkCd());

			hbdCommonMapper.updateNoteContReleaseInfo(contDTO);

			contDTO.setVSignType("plus");
			this.updateLabNoteStats01(contDTO);
			this.updateLabNoteStats02(contDTO);
			this.updateLabNoteStats03(contDTO);

			this.updateLabNoteSustainabilityStats01(contDTO);
			this.updateLabNoteSustainabilityStats02(contDTO);
			this.updateLabNoteSustainabilityStats03(contDTO);

			this.insertLabNoteFinalVersion(ConvertUtil.convert(contDTO, HbdNoteContDTO.class));
			this.insertLabNoteFinalLot(ConvertUtil.convert(contDTO, HbdNoteContDTO.class));

			List<LabNoteDecideDTO> list = this.selectLabNoteDecideInfoList(contDTO);

			int i = 0;
			if (list != null && !list.isEmpty()) {
				for (LabNoteDecideDTO lvo : list) {
					lvo.setVContPkCd(contDTO.getVContPkCd());
					lvo.setNSort(i);
					lvo.setNVersion(0);
					lvo.setVRegUserid("BATCH");
					lvo.setVUpdateUserid("BATCH");

					HbdNoteMateVO mateVO = ConvertUtil.convert(lvo, HbdNoteMateVO.class);
					HbdNoteRateVO rateVO = ConvertUtil.convert(lvo, HbdNoteRateVO.class);
					this.insertLabNoteFinalMate(mateVO);

					rateVO.setVMatePkCd(mateVO.getVMatePkCd());
					rateVO.setVLotCd(contDTO.getVLotCd());
					this.insertLabNoteFinalRate(rateVO);
					i++;
				}
			}

			if ("Y".equals(this.selectLabNoteFlagAllLaunchComplete(launchCompleteDTO.getVLabNoteCd()))) {
				launchCompleteDTO.setVLaunchCompleteType("MST");
				launchCompleteDTO.setVSignType("minus");
				launchCompleteDTO.setVRegUserid("BATCH");
				launchCompleteDTO.setVUpdateUserid("BATCH");
				launchCompleteDTO.setLocalLanguage("_ko");

				LaunchCompleteContDTO completeContDTO = ConvertUtil.convert(launchCompleteDTO, LaunchCompleteContDTO.class);

				this.updateLabNoteStats01(completeContDTO);
				this.updateLabNoteStats02(completeContDTO);
				this.updateLabNoteStats03(completeContDTO);

				this.updateLabNoteMstLaunchComplete(launchCompleteDTO);

				launchCompleteDTO.setVSignType("plus");
				this.updateLabNoteStats01(contDTO);
				this.updateLabNoteStats02(contDTO);
				this.updateLabNoteStats03(contDTO);

				allCompleteCodeList.add(launchCompleteDTO.getVLabNoteCd());
			}
		}

		if (allCompleteCodeList.size() > 0) {
			List<BatchStatusProcessVO> alarmTargetList = targetList.stream().filter(note -> allCompleteCodeList.contains(note.getVLabNoteCd())).collect(Collectors.toList());
			if (!ObjectUtils.isEmpty(alarmTargetList)) {
				List<BatchStatusProcessVO> alarmList = this.selectBatchAlarmInfoList(alarmTargetList);
				labNoteCommonService.sendCompleteAlarm(alarmList, "RELEASE", "hbd", "HBO");
			}
		}
	}

	@Transactional
	public void updateNoteContStockDt(List<BatchStatusProcessVO> list) {
		for (BatchStatusProcessVO stockProcessVO : list) {
			hbdCommonMapper.updateNoteContStockDt(stockProcessVO.getVStockDt(), stockProcessVO.getVContPkCd());
			hbdCommonMapper.updateNoteLotStockStatus(stockProcessVO.getVContPkCd(), Const.LOT_05);
		}
	}

	public List<String> selectStockAllCompleteList(List<BatchStatusProcessVO> list) {
		return hbdCommonMapper.selectStockAllCompleteList(list);
	}

	@Transactional
	public void updateDevelopmentCompletedStatus(List<String> list) {
		hbdCommonMapper.updateDevelopmentCompletedStatus(list);
	}

	public String selectLabNoteMybkRegYn(String vLabNoteCd) {
		return hbdCommonMapper.selectLabNoteMybkRegYn(vLabNoteCd);
	}

	public List<BatchStatusProcessVO> selectBatchAlarmInfoList(List<BatchStatusProcessVO> list) {
		return hbdCommonMapper.selectBatchAlarmInfoList(list);
	}

	public ResponseVO selectLabNoteInfoCheckAuth(String vLabNoteCd) {
		ResponseVO responseVO = new ResponseVO();

		HbdNoteInfoDTO resDTO = this.selectLabNoteInfo(vLabNoteCd);

		MaterialSearchVO schVO = new MaterialSearchVO();

		schVO.setVLabNoteCd(vLabNoteCd);
		schVO.setVUserId(sessionUtil.getLoginId());

		this.selectElabNoteAuth(schVO, resDTO);
		List<String> groups = sessionUtil.getGroups();

		if (!"Y".equals(schVO.getVIsPersonInCharge()) &&
				!"Y".equals(schVO.getVIsRelatedPerson()) &&
				!"Y".equals(schVO.getVIsLabNoteAdmin()) &&
				(!ObjectUtils.isEmpty(groups) && groups.stream().anyMatch(group -> "S000118;S000246;S000000;".indexOf(group) == -1)) &&
				!"Y".equals(labNoteCommonService.checkLabNoteAuth("HBO", resDTO.getVStatusCd(), resDTO.getVDeptCd()))) {
			responseVO.setOkWithCode("C9999", CommonResultCode.NO_AUTH, null);
			return responseVO;
		}

		responseVO.setOk(resDTO);
		return responseVO;
	}
}
