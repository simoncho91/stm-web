package com.mybeaker.app.hbd.controller;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mybeaker.app.model.dto.ReqCommSearchInfoDTO;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.hbd.model.HbdContentDetailReqDTO;
import com.mybeaker.app.hbd.model.HbdMateRateReqDTO;
import com.mybeaker.app.hbd.service.HbdSearchService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Tag(name = "HBD 검색", description="HBD 검색")
@RestController
@RequestMapping("/api/hbd/search")
@RequiredArgsConstructor
public class HbdSearchController {
	private final HbdSearchService hbdSearchService;

	@Operation(summary = "검색 > 원료 검색 > 원료 검색 리스트", description = "원료 검색 리스트를 조회한다. (화면ID : CO-PA-115)")
	@GetMapping("/select-mst-search-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectMstSearchList (
			ReqCommSearchInfoDTO reqCommSearchInfoDTO
			) {
		log.debug("HbdSearchController.selectMstSearchList");
		log.debug("reqCommSearchInfoDTO : {}", reqCommSearchInfoDTO);
		
		return ResponseEntity.ok(hbdSearchService.selectMstSearchList(reqCommSearchInfoDTO));
	}
	
	@Operation(summary = "검색 > 원료 검색 > 내용물 상세 팝업", description = "내용물 상세정보를 조회한다. (화면 ID : CO-PO-128)")
	@GetMapping("/select-content-detail")
	public @ResponseBody ResponseEntity<ResponseVO> selectContentDetail (
			HbdContentDetailReqDTO contentDetailReqDTO
			) {
		log.debug("HbdSearchController.selectContentDetail");
		log.debug("contentDetailReqDTO : {}", contentDetailReqDTO);

		return ResponseEntity.ok(hbdSearchService.selectContentDetail(contentDetailReqDTO));
	}
	
	@Operation(summary = "검색 > 카운터 맵 > 카운터 맵 리스트", description = "카운터 맵 리스트를 조회한다. (화면ID : CO-PA-116)")
	@GetMapping("/select-counter-map-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectCounterMapList (
			@RequestParam(name = "vKeyword", required = true) String vKeyword
			) {
		log.debug("HbdSearchController.selectCounterMapList");
		log.debug("vKeyword = ", vKeyword);
		
		return ResponseEntity.ok(hbdSearchService.selectCounterMapList(vKeyword));
	}
	
	@Operation(summary = "검색 > 카운터 맵 > 내용물 비교 팝업", description = "내용물 비교 정보를 조회한다. (화면 ID : CO-PO-117)")
	@PostMapping("/select-content-compare-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectMateRateInfo (
			@RequestBody @Valid HbdMateRateReqDTO hbdMateRateReqDTO
			) {
		log.debug("HbdSearchController.selectMateRateInfo");
		log.debug("hbdMateRateReqDTO : {}", hbdMateRateReqDTO);
		
		return ResponseEntity.ok(hbdSearchService.selectMateRateInfo(hbdMateRateReqDTO));
	}
}
