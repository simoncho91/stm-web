package com.mybeaker.app.hbd.model;

import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@Data
public class HbdNoteVersionVO extends ParentDTO {

	private String vContPkCd;

	private int nVersion;

	private String vLabNoteCd;
	
	private String vFlagView;
	
	private String vFlagPriceHide;

	private String vFlagReqHide;

	private String vFlagMaxmixHide;

	private String vFlagExistHide;
	
	private String vFlagBaseHide;

	private String vFlagInpMethod;
	
	private String vG1PqcResCd;
	
	private String vG1PqcLotCd;
	
	private int nG1ObeyPer;

	private String vCounterCd;

	private String vCounterContPkCd;

	private String vVersionNm;

	@Builder
	public HbdNoteVersionVO(String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm, String vContPkCd,
			int nVersion, String vLabNoteCd, String vFlagView, String vFlagPriceHide, String vFlagReqHide,
			String vFlagMaxmixHide, String vFlagExistHide, String vFlagBaseHide, String vFlagInpMethod,
			String vG1PqcResCd, String vG1PqcLotCd, int nG1ObeyPer, String vCounterCd, String vCounterContPkCd,
			String vVersionNm) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.vContPkCd = vContPkCd;
		this.nVersion = nVersion;
		this.vLabNoteCd = vLabNoteCd;
		this.vFlagView = vFlagView;
		this.vFlagPriceHide = vFlagPriceHide;
		this.vFlagReqHide = vFlagReqHide;
		this.vFlagMaxmixHide = vFlagMaxmixHide;
		this.vFlagExistHide = vFlagExistHide;
		this.vFlagBaseHide = vFlagBaseHide;
		this.vFlagInpMethod = vFlagInpMethod;
		this.vG1PqcResCd = vG1PqcResCd;
		this.vG1PqcLotCd = vG1PqcLotCd;
		this.nG1ObeyPer = nG1ObeyPer;
		this.vCounterCd = vCounterCd;
		this.vCounterContPkCd = vCounterContPkCd;
		this.vVersionNm = vVersionNm;
	}
}
