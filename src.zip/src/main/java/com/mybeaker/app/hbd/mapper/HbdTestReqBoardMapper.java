package com.mybeaker.app.hbd.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.mybeaker.app.labnote.model.LabNoteTestBoardContDTO;
import com.mybeaker.app.labnote.model.LabNoteTestBoardVerLotDTO;
import com.mybeaker.app.labnote.model.LabNoteTestQrCodeInfoDTO;
import com.mybeaker.app.labnote.model.LabNoteTestQrCodeReqDTO;
import com.mybeaker.app.labnote.model.LabNoteTestBoardLotDTO;
import com.mybeaker.app.labnote.model.LabNoteTestReqBoardVo;

@Mapper
public interface HbdTestReqBoardMapper {

	int selectTestReqBoardListCount(String vLabNoteCd);
	
	List<LabNoteTestBoardContDTO> selectTestReqBoardContList(String vLabNoteCd);
	
	List<LabNoteTestBoardVerLotDTO> selectTestReqBoardVerLotList(String vLabNoteCd, String vContCd);
	
	List<LabNoteTestBoardLotDTO> selectTestReqBoardLotList(String vLabNoteCd, String vContPkCd);
	
	List<LabNoteTestReqBoardVo> selectTestReqBoardList(String vLabNoteCd, String vContCd, String localLanguage);
	
	List<LabNoteTestQrCodeInfoDTO> selectQrCodeLabNoteTestList(LabNoteTestQrCodeReqDTO labNoteTestQrCodeDTO);
	
}
