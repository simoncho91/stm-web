package com.mybeaker.app.hbd.controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mybeaker.app.hbd.model.HbdCounterDTO;
import com.mybeaker.app.hbd.model.HbdNoteLotVO;
import com.mybeaker.app.hbd.service.HbdCommonService;
import com.mybeaker.app.labnote.model.CompleteCounterSearchReqDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonReq4MRawSearchDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonReqSAPSyncDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonResSAPSyncDTO;
import com.mybeaker.app.labnote.model.Mat4MMstVO;
import com.mybeaker.app.model.dto.PagingDTO;
import com.mybeaker.app.model.dto.ReqCommSearchInfoDTO;
import com.mybeaker.app.model.dto.ResCommSearchInfoDTO;
import com.mybeaker.app.model.enums.CommonResultCode;
import com.mybeaker.app.model.enums.LabNoteResultCode;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.skincare.model.DecideCancelRegDTO;
import com.mybeaker.app.skincare.model.LatestBomRegDTO;
import com.mybeaker.app.skincare.model.MateRateReqVO;
import com.mybeaker.app.utils.CommonUtil;
import com.mybeaker.app.utils.ConvertUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Tag(name = "HBD 공통 팝업 및 모듈 api", description="HBD 공통 팝업 및 모듈 api")
@RestController
@RequestMapping("/api/hbd/common")
@RequiredArgsConstructor
public class HbdCommonController {
	private final HbdCommonService hbdCommonService;

	@Operation(summary = "자사 카운터 검색 - 실험노트 탭", description = "자사 카운터 검색 - 실험노트 탭 리스트를 조회한다. (화면ID : SC-PO-119)")
	@GetMapping("/select-lab-note-counter-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteCounterList (
			ReqCommSearchInfoDTO reqCommSearchInfoDTO
			) {
		ResponseVO responseVO = new ResponseVO();

		log.debug("HbdCommonController.selectLabNoteCounterList : {}", reqCommSearchInfoDTO);

		int totalCnt = hbdCommonService.selectLabNoteCounterListCount(reqCommSearchInfoDTO);
		List<HbdCounterDTO> list = null;
		CommonUtil.setPaging(reqCommSearchInfoDTO, totalCnt);

		if (totalCnt > 0) {
			list = hbdCommonService.selectLabNoteCounterList(reqCommSearchInfoDTO);
		}

		PagingDTO page = ConvertUtil.convert(reqCommSearchInfoDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
									.page(page)
									.list(list)
									.build();

		responseVO.setOk(res);
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "자사 카운터 검색 - 인벤토리 탭", description = "자사 카운터 검색 - 인벤토리 탭 리스트를 조회한다. (화면 ID : SC-PO-119)")
	@GetMapping("/select-lab-note-inventory-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteInventoryList (
			ReqCommSearchInfoDTO reqCommSearchInfoDTO
			) {
		ResponseVO responseVO = new ResponseVO();
		log.debug("HbdCommonController.selectLabNoteInventoryList : {}", reqCommSearchInfoDTO);

		int totalCnt = hbdCommonService.selectLabNoteInventoryListCount(reqCommSearchInfoDTO);
		List<HbdCounterDTO> list = null;
		CommonUtil.setPaging(reqCommSearchInfoDTO, totalCnt);

		if (totalCnt > 0) {
			list = hbdCommonService.selectLabNoteInventoryList(reqCommSearchInfoDTO);
		}

		PagingDTO page = ConvertUtil.convert(reqCommSearchInfoDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
									.page(page)
									.list(list)
									.build();

		responseVO.setOk(res);
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "자사 카운터 검색 - SAP SYNC 탭", description = "자사 카운터 검색 - SAP SYNC (화면 ID : SC-PO-119)")
	@PostMapping("/insert-counter-sap-sync")
	public @ResponseBody ResponseEntity<ResponseVO> insertCounterSapSync (
			@RequestBody LabNoteCommonReqSAPSyncDTO reqSAPSyncDTO
			) {
		ResponseVO responseVO = new ResponseVO();

		if (StringUtils.isEmpty(reqSAPSyncDTO.getVContCd()) || StringUtils.isEmpty(reqSAPSyncDTO.getVPlantCd())) {
			responseVO.setOk(CommonResultCode.NO_ESSENTIAL_DATA, null);
			return ResponseEntity.ok(responseVO);
		} else if (!(reqSAPSyncDTO.getVContCd().startsWith("3") || reqSAPSyncDTO.getVContCd().startsWith("4") || reqSAPSyncDTO.getVContCd().startsWith("J"))) {
			responseVO.setOk(LabNoteResultCode.WRONG_CONTCD, null);
			return ResponseEntity.ok(responseVO);
		}

		LabNoteCommonResSAPSyncDTO resSAPSyncDTO = hbdCommonService.insertCounterSapSync(reqSAPSyncDTO);

		if (CommonResultCode.SAVE_SUCC.getCode().equals(resSAPSyncDTO.getVResultCode())) {
			responseVO.setCreateOk(resSAPSyncDTO);
		} else {
			responseVO.setOkWithCode(resSAPSyncDTO.getVResultCode(), "", null);
		}

		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "자사 카운터 선택 - 카운터 원료 플랜트 체크", description = "자사 카운터 선택 - 카운터 적용 버튼 클릭 (화면 ID : SC-PO-119)")
	@GetMapping("/select-lab-note-mate-plant-check-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteMatePlantCheckList (
			@RequestParam(value="vPlantCd") String vPlantCd,
			@RequestParam(value="vContPkCd") String vContPkCd,
			@RequestParam(value="vLotCd") String vLotCd
			) {
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(hbdCommonService.selectLabNoteMatePlantCheckList(vPlantCd, vContPkCd, vLotCd));

		return ResponseEntity.ok(responseVO);
	}

//	elab/experiment/lab_note_check_sap_bom_ajax
	@Operation(summary = "BOM 동일여부 판단(확정 처방 저장)", description = "확정 처방 저장시 실험노트 LOT의 BOM과 SAP의 BOM이 동일한지 판단한다.")
	@PostMapping("/insert-elab-note-latest-bom-info")
	public @ResponseBody ResponseEntity<ResponseVO> insertElabNoteLatestBomInfo (
			@RequestBody @Valid LatestBomRegDTO regDTO) {
		log.debug("insert-elab-note-latest-bom-info Start!");
		log.debug("LatestBomRegDTO : {}", regDTO.toString());

		return ResponseEntity.ok(hbdCommonService.insertElabNoteLatestBomInfo(regDTO.getVLotCd()));
	}

	@Operation(summary = "완료 카운터 리스트 조회", description = "출시완료 팝업 - 완료 카운터 리스트를 조회한다.")
	@GetMapping("/select-complete-counter-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectCompleteCounterList (
			CompleteCounterSearchReqDTO completeCounterSearchReqDTO
			) {
		log.debug("HbdCommonController.selectCompleteCounterList => completeCounterSearchReqDTO : {}", completeCounterSearchReqDTO);

		return ResponseEntity.ok(hbdCommonService.selectCompleteCounterList(completeCounterSearchReqDTO));
	}

//	elab/experiment/lab_note_decide_cancel_ajax
	@Operation(summary = "확정 처방 해제", description = "확정 처방 해제한다.")
	@PostMapping("/update-decide-cancel")
	public @ResponseBody ResponseEntity<ResponseVO> updateDecideCancel (
			@RequestBody @Valid DecideCancelRegDTO regDTO) {
		log.debug("update-decide-cancel Start!");
		log.debug("DecideCancelRegDTO : {}", regDTO.toString());

		return ResponseEntity.ok(hbdCommonService.updateDecideCancel(regDTO));
	}

	@Operation(summary = "LOT별 BOM 리스트 조회", description = "LOT별 BOM 리스트를 조회한다.")
	@GetMapping("/select-lab-note-mate-rate-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteMateRateInfo (MateRateReqVO mateRateVO) {
		log.debug("HbdCommonController.selectLabNoteMateRateInfo => MateRateReqVO : {}", mateRateVO);
		return ResponseEntity.ok(hbdCommonService.selectLabNoteMateRateInfo(mateRateVO));
	}

	@Operation(summary = "실험노트 마스터 정보 조회", description = "실험노트 마스터 정보를 조회한다.")
	@GetMapping("/select-lab-note-info-check-auth")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteInfoCheckAuth (
			@RequestParam(value = "vLabNoteCd") String vLabNoteCd
			) {
		log.debug("HbdCommonController.selectLabNoteInfoCheckAuth => vLabNoteCd : {}", vLabNoteCd);

		return ResponseEntity.ok(hbdCommonService.selectLabNoteInfoCheckAuth(vLabNoteCd));
	}

	@Operation(summary = "4M 원료 검색", description = "4M 원료를 조회한다.")
	@GetMapping("/select-mat-4m-mst-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectMat4MMstList (
			LabNoteCommonReq4MRawSearchDTO reqDTO
			) {
		ResponseVO responseVO = new ResponseVO();

		log.debug("HbdCommonController.selectMat4MMstList : {}", reqDTO);

		int totalCnt = hbdCommonService.selectMat4MMstListCount(reqDTO);
		List<Mat4MMstVO> list = null;
		CommonUtil.setPaging(reqDTO, totalCnt);

		if (totalCnt > 0) {
			list = hbdCommonService.selectMat4MMstList(reqDTO);
		}

		PagingDTO page = ConvertUtil.convert(reqDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
									.page(page)
									.list(list)
									.build();

		responseVO.setOk(res);
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "실험노트 마스터 정보 조회(3자 코드 채번 팝업)", description = "실험노트 마스터 정보를 조회한다.")
	@GetMapping("/select-lab-note-mst-basic-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteMstBaseInfo (
			@RequestParam(value = "vLabNoteCd") String vLabNoteCd
			) {
		log.debug("HbdCommonController.selectLabNoteMstBaseInfo");

		return ResponseEntity.ok(hbdCommonService.selectLabNoteMstBaseInfo(vLabNoteCd));
	}

	@Operation(summary = "마케팅 송부 체크/체크 해제", description = "LOT별 마케팅 송부 체크/체크 해제")
	@PostMapping("/update-lot-flag-send")
	public @ResponseBody ResponseEntity<ResponseVO> updateLotFlagSend (
			@RequestBody HbdNoteLotVO hbdNoteLotVO
			) {
		log.debug("HbdCommonController.updateLotFlagSend => hbdNoteLotVO : {}", hbdNoteLotVO);

		return ResponseEntity.ok(hbdCommonService.updateLotFlagSend(hbdNoteLotVO));
	}

	@Operation(summary = "LOT 숨김/해제", description = "LOT별 숨김/해제")
	@PostMapping("/update-lot-flag-exposure")
	public @ResponseBody ResponseEntity<ResponseVO> updateLotFlagExposure (
			@RequestBody HbdNoteLotVO hbdNoteLotVO
			) {
		log.debug("HbdCommonController.updateLotFlagSend => hbdNoteLotVO : {}", hbdNoteLotVO);

		return ResponseEntity.ok(hbdCommonService.updateLotFlagExposure(hbdNoteLotVO));
	}

	@Operation(summary = "노트 마스터 버전 리스트 조회", description = "노트별 마스터 버전 리스트를 조회한다.")
	@GetMapping("/select-note-mst-ver-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteMstVerList (
			@RequestParam(value = "vLabNoteCd") String vLabNoteCd
			) {
		log.debug("HbdCommonController.selectLabNoteMstVerList => vLabNoteCd : {}", vLabNoteCd);

		ResponseVO responseVO = new ResponseVO();
		responseVO.setOk(hbdCommonService.selectLabNoteMstVerList(vLabNoteCd));
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "실험노트 리스트(과제 상세 > 참여 인벤토리)", description = "실험노트 리스트를 조회한다.")
	@GetMapping("/select-exhibit-add-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectExhibitAddList (
			@RequestParam(value = "vSpCode") String vSpCode
			) {
		ResponseVO responseVO = new ResponseVO();

		log.debug("HbdCommonController.selectExhibitAddList");

		int totalCnt = hbdCommonService.selectSpCodeNoteListCount(vSpCode);
		List<HbdCounterDTO> list = null;

		if (totalCnt > 0) {
			list = hbdCommonService.selectSpCodeNoteList(vSpCode);
		}

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
									.list(list)
									.build();

		responseVO.setOk(res);
		return ResponseEntity.ok(responseVO);
	}
}
