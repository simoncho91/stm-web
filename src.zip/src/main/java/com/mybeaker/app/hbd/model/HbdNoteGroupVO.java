package com.mybeaker.app.hbd.model;

import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@Data
public class HbdNoteGroupVO extends ParentDTO {

	private String vGrpCd;

	private String vLabNoteCd;

	private String vContPkCd;

	private int nVersion;

	private String vGrpNm;

	private String vFlagReq;

	private int nSortReq;

	private int nSort;

	private String vFlagGrpHide;

	private String vFlagDel;

	@Builder
	public HbdNoteGroupVO(String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm, String vGrpCd,
			String vLabNoteCd, String vContPkCd, int nVersion, String vGrpNm, String vFlagReq, int nSortReq, int nSort,
			String vFlagGrpHide, String vFlagDel) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.vGrpCd = vGrpCd;
		this.vLabNoteCd = vLabNoteCd;
		this.vContPkCd = vContPkCd;
		this.nVersion = nVersion;
		this.vGrpNm = vGrpNm;
		this.vFlagReq = vFlagReq;
		this.nSortReq = nSortReq;
		this.nSort = nSort;
		this.vFlagGrpHide = vFlagGrpHide;
		this.vFlagDel = vFlagDel;
	}
}
