package com.mybeaker.app.hbd.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mybeaker.app.labnote.model.LabNoteTestBoardContDTO;
import com.mybeaker.app.labnote.model.LabNoteTestBoardResDTO;
import com.mybeaker.app.labnote.model.LabNoteTestBoardVerLotDTO;
import com.mybeaker.app.labnote.model.LabNoteTestQrCodeCheckVO;
import com.mybeaker.app.labnote.model.LabNoteTestQrCodeInfoDTO;
import com.mybeaker.app.labnote.model.LabNoteTestQrCodeReqDTO;
import com.mybeaker.app.labnote.model.LabNoteTestQrCodeResDTO;
import com.mybeaker.app.labnote.model.LabNoteTestReqBoardVo;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.hbd.mapper.HbdTestReqBoardMapper;
import com.mybeaker.app.hbd.model.HbdNoteInfoDTO;
import com.mybeaker.app.utils.SessionUtil;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class HbdTestReqBoardService {

	private final HbdTestReqBoardMapper hbdTestReqBoardMapper;

	private final HbdCommonService hbdCommonService;

	private final SessionUtil sessionUtil;

	public int selectTestReqBoardListCount(String vLabNoteCd) {
		return hbdTestReqBoardMapper.selectTestReqBoardListCount(vLabNoteCd);
	}

	public ResponseVO selectTestReqBoardList(String vLabNoteCd, String vContPkCd, String vContCd) {
		ResponseVO responseVO = new ResponseVO();
		
		//정렬순서
		//version, lot, 부향시험의뢰, 안전성시험의뢰, 방부시험의뢰, 기능성시험의뢰, 효능/임상시험의뢰, 무소구시험의뢰, 중국안전성사전검토, 유해물질시험의뢰
		//ex) version 1, lot#3
		HbdNoteInfoDTO noteInfo = null;
		List<LabNoteTestBoardContDTO> contList = null;
		List<LabNoteTestBoardVerLotDTO> verLotList = null;
		
		noteInfo = hbdCommonService.selectLabNoteInfo(vLabNoteCd);
		
		if (noteInfo != null) {
			contList = hbdTestReqBoardMapper.selectTestReqBoardContList(vLabNoteCd);
		}
		
		int totalCnt = this.selectTestReqBoardListCount(vLabNoteCd);
		List<LabNoteTestReqBoardVo> list = null;
		Map<String, List<LabNoteTestReqBoardVo>> resultMap = null;
		if (totalCnt > 0) {
			if(StringUtils.isEmpty(vContCd)){
				vContCd = contList.get(0).getVContCd();
			}
			
			verLotList = hbdTestReqBoardMapper.selectTestReqBoardVerLotList(vLabNoteCd, vContCd);
			list = hbdTestReqBoardMapper.selectTestReqBoardList(vLabNoteCd, vContCd, sessionUtil.getLocalLanguage());
			resultMap = list != null && !list.isEmpty()
						? list.stream().collect(Collectors.groupingBy(LabNoteTestReqBoardVo::getVLabMrqTypeCd))
						: null;
		}
		
		LabNoteTestBoardResDTO<HbdNoteInfoDTO> result = LabNoteTestBoardResDTO.<HbdNoteInfoDTO>builder()
				.noteInfo(noteInfo)
				.verLotList(verLotList)
				.contList(contList)
				.list(list)
				.resultMap(resultMap)
				.build();
		responseVO.setOk(result);
		return responseVO;
	}
	
	public ResponseVO selectQrCodeLabNoteTestList(LabNoteTestQrCodeReqDTO labNoteTestQrCodeDTO) {
		ResponseVO responseVO = new ResponseVO();
		///amore_rdp/src/java/com/iShift/pms/controller/cm/CmQrCodeController.java
		//cm_make_lab_note_test_qr_code_pop
		//getQrCodeElabNoteTestList
		
		String[] arrQrCheckInfo = labNoteTestQrCodeDTO.getArrQrCheckInfo().split("/");
		
		List<LabNoteTestQrCodeCheckVO> qrCheckList = new ArrayList<LabNoteTestQrCodeCheckVO>();
		
		if (arrQrCheckInfo.length >= 1) {
			
			for(int i=0; i<arrQrCheckInfo.length; i++) {
				
				String arrProVerInfo[] = arrQrCheckInfo[i].split(",");
				if(arrProVerInfo.length >= 1) {
					
					qrCheckList.add(LabNoteTestQrCodeCheckVO.builder()
							.vProductCd(arrProVerInfo[0])
							.nVersion(Integer.parseInt(arrProVerInfo[1]))
							.build());
					
				}
			}
			
		}
		
		labNoteTestQrCodeDTO.setQrCheckList(qrCheckList);
		
		List<LabNoteTestQrCodeInfoDTO> list = hbdTestReqBoardMapper.selectQrCodeLabNoteTestList(labNoteTestQrCodeDTO);
		responseVO.setOk(LabNoteTestQrCodeResDTO.builder()
				.list(list)
				.build());
		return responseVO;
	}


}