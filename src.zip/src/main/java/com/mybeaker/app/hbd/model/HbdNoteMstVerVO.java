package com.mybeaker.app.hbd.model;

import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@Data
public class HbdNoteMstVerVO extends ParentDTO {

	private String vLabNoteCd;
	
	private int nVersion;

	@Builder
	public HbdNoteMstVerVO(String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm,
			String vLabNoteCd, int nVersion) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.vLabNoteCd = vLabNoteCd;
		this.nVersion = nVersion;
	}
}
