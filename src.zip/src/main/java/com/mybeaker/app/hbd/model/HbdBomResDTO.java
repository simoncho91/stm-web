package com.mybeaker.app.hbd.model;

import java.util.List;

import com.mybeaker.app.labnote.model.VersionListVO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class HbdBomResDTO {
	
	private List<HbdMaterialNotePlantVO> contList;
	
	private List<VersionListVO> verList;
}
