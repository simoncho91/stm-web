package com.mybeaker.app.hbd.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.common.model.UploadTempDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonTagDTO;
import com.mybeaker.app.labnote.model.LabNoteRequestPjtDTO;
import com.mybeaker.app.labnote.model.LabNoteVersionRegDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HbdNoteInfoRegDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vLabTypeCd")
	private String vLabTypeCd;

	@JsonProperty("vFlagLineProduct")
	@Builder.Default
	private String vFlagLineProduct = "Y";

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vCodeType")
	private String vCodeType;

	@JsonProperty("vStatusCd")
	private String vStatusCd;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vSiteType")
	private String vSiteType;

	@JsonProperty("vBrdCd")
	private String vBrdCd;

	@JsonProperty("vPrdCd")
	private String vPrdCd;

	@JsonProperty("vFlagOem")
	private String vFlagOem;

	@JsonProperty("vOemManufacturer")
	private String vOemManufacturer;

	@JsonProperty("vFlagNew")
	private String vFlagNew;

	@JsonProperty("vProdType1Cd")
	private String vProdType1Cd;

	@JsonProperty("vProdType2Cd")
	private String vProdType2Cd;

	@JsonProperty("vTddProdType1Cd")
	private String vTddProdType1Cd;

	@JsonProperty("vTddProdType2Cd")
	private String vTddProdType2Cd;

	@JsonProperty("vPartCd")
	private String vPartCd;

	@JsonProperty("vLeaveType")
	private String vLeaveType;

	@JsonProperty("vFlagReleaseASIA")
	private String vFlagReleaseAsia;

	@JsonProperty("vFlagReleaseASEAN")
	private String vFlagReleaseAsean;

	@JsonProperty("vFlagReleaseETC")
	private String vFlagReleaseEtc;

	@JsonProperty("vFlagFuncTest")
	private String vFlagFuncTest;

	@JsonProperty("vPilotDt")
	private String vPilotDt;

	@JsonProperty("vMeetingDt")
	private String vMeetingDt;

	@JsonProperty("vContainerCd")
	private String vContainerCd;

	@JsonProperty("vContainerEtc")
	private String vContainerEtc;

	@JsonProperty("vOnePointTech")
	private String vOnePointTech;

	@JsonProperty("vSlUserid")
	private String vSlUserid;

	@JsonProperty("vBrdUserid")
	private String vBrdUserid;

	@JsonProperty("vPerfUserid")
	private String vPerfUserid;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vDeptCd")
	private String vDeptCd;

	@JsonProperty("vNote")
	private String vNote;

	@JsonProperty("nPrice")
	private String nPrice;

	@JsonProperty("nTargetCost")
	private String nTargetCost;

	@JsonProperty("nCapacity")
	private String nCapacity;

	@JsonProperty("vCapacityCd")
	private String vCapacityCd;

	@JsonProperty("nProductCapacity")
	private String nProductCapacity;

	@JsonProperty("vProductCapacityCd")
	private String vProductCapacityCd;

	@JsonProperty("nEffTestDcnt")
	private String nEffTestDcnt;

	@JsonProperty("vEffTestDcntUnit")
	private String vEffTestDcntUnit;

	@JsonProperty("vEffCompTypeCd")
	private String vEffCompTypeCd;

	@JsonProperty("vEffTestSogooMemo")
	private String vEffTestSogooMemo;

	@JsonProperty("vEffTestItemDt")
	private String vEffTestItemDt;

	@JsonProperty("vTestItemDt")
	private String vTestItemDt;

	@JsonProperty("vOnePoint")
	private String vOnePoint;

	@JsonProperty("vTargetCustomer")
	private String vTargetCustomer;

	@JsonProperty("vMassProdDt")
	private String vMassProdDt;

	@JsonProperty("vFlagNotAdd")
	private String vFlagNotAdd;

	@JsonProperty("vNotAddNote")
	private String vNotAddNote;

	@JsonProperty("vProdTypeNote")
	private String vProdTypeNote;

	@JsonProperty("vFlagAerosol")
	private String vFlagAerosol;

	@JsonProperty("vFlagSoap")
	private String vFlagSoap;

	@JsonProperty("vFlagNewVer")
	private String vFlagNewVer;

	@JsonProperty("vCustResearchDt")
	private String vCustResearchDt;
	
	@JsonProperty("vNonprdNoteCd")
	private String vNonprdNoteCd;

	private String vRegUserid;

	private String vUpdateUserid;

	private String flagAction;

	private List<LabNoteCommonTagDTO> mstTagList;

	private List<HbdNoteRequestContDTO> contList;

	private List<LabNoteRequestPjtDTO> pjtList;

	private LabNoteVersionRegDTO versionInfo;

	private List<UploadTempDTO> fileList;
}
