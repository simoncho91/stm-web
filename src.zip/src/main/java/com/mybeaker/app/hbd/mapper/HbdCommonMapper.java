package com.mybeaker.app.hbd.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.mybeaker.app.approval.model.ApprovalDetailDTO;
import com.mybeaker.app.hbd.model.HbdCounterDTO;
import com.mybeaker.app.hbd.model.HbdNoteContDTO;
import com.mybeaker.app.hbd.model.HbdNoteContVO;
import com.mybeaker.app.hbd.model.HbdNoteGroupVO;
import com.mybeaker.app.hbd.model.HbdNoteInfoDTO;
import com.mybeaker.app.hbd.model.HbdNoteInfoRegDTO;
import com.mybeaker.app.hbd.model.HbdNoteLotDTO;
import com.mybeaker.app.hbd.model.HbdNoteLotVO;
import com.mybeaker.app.hbd.model.HbdNoteMateVO;
import com.mybeaker.app.hbd.model.HbdNoteMstVO;
import com.mybeaker.app.hbd.model.HbdNoteRateVO;
import com.mybeaker.app.hbd.model.HbdNoteRequestContDTO;
import com.mybeaker.app.hbd.model.HbdNoteVersionVO;
import com.mybeaker.app.labnote.model.BatchStatusProcessVO;
import com.mybeaker.app.labnote.model.BomApprovalReqDTO;
import com.mybeaker.app.labnote.model.CompleteCounterSearchReqDTO;
import com.mybeaker.app.labnote.model.ElabChgLogDTO;
import com.mybeaker.app.labnote.model.ElabPrecedeBomItemVO;
import com.mybeaker.app.labnote.model.FuncDecideContNameVO;
import com.mybeaker.app.labnote.model.FuncDecideNameVO;
import com.mybeaker.app.labnote.model.LabNoteCommonPlantCheckDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonReq4MRawSearchDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonReqSAPSyncDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonTagDTO;
import com.mybeaker.app.labnote.model.LabNoteContInfoVO;
import com.mybeaker.app.labnote.model.LabNoteDecideDTO;
import com.mybeaker.app.labnote.model.LabNoteIngrdApprConInfoVO;
import com.mybeaker.app.labnote.model.LabNoteIngrdApprSaveInfoVO;
import com.mybeaker.app.labnote.model.LabNoteMateInfoVO;
import com.mybeaker.app.labnote.model.LabNoteMstVersionDTO;
import com.mybeaker.app.labnote.model.LabNoteMstVersionPqcDTO;
import com.mybeaker.app.labnote.model.LabNotePqcGateCheckReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessContDecideListDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessPqcCheckApprReqDTO;
import com.mybeaker.app.labnote.model.LabNoteSapBomConSearchVO;
import com.mybeaker.app.labnote.model.LabNoteSapBomToConInfoVO;
import com.mybeaker.app.labnote.model.LabNoteTestReqApprContVO;
import com.mybeaker.app.labnote.model.LabNoteTestReqLotCompleVO;
import com.mybeaker.app.labnote.model.LabNoteTestRequestProductCntDTO;
import com.mybeaker.app.labnote.model.LabNoteTestRequestProductDTO;
import com.mybeaker.app.labnote.model.LabNoteTestRequestProductReqDTO;
import com.mybeaker.app.labnote.model.LabNoteVersionDTO;
import com.mybeaker.app.labnote.model.LabNoteVersionRegDTO;
import com.mybeaker.app.labnote.model.LaunchCompleteContDTO;
import com.mybeaker.app.labnote.model.LaunchCompleteReqDTO;
import com.mybeaker.app.labnote.model.Mat4MMstVO;
import com.mybeaker.app.labnote.model.MusoguReqDTO;
import com.mybeaker.app.labnote.model.MusoguTagVO;
import com.mybeaker.app.labnote.model.VersionListVO;
import com.mybeaker.app.labnote.model.ZbomHeaderVO;
import com.mybeaker.app.labnote.model.ZbomItemVO;
import com.mybeaker.app.model.dto.ReqCommSearchInfoDTO;
import com.mybeaker.app.skincare.model.BasicsInfoVerLotVO;
import com.mybeaker.app.skincare.model.BookmarkReqDTO;
import com.mybeaker.app.skincare.model.ElabPqcResVO;
import com.mybeaker.app.skincare.model.FinalLotVO;
import com.mybeaker.app.skincare.model.IngredientContVO;
import com.mybeaker.app.skincare.model.IngredientReqDTO;
import com.mybeaker.app.skincare.model.MateRateReqVO;
import com.mybeaker.app.skincare.model.MateRateResDTO;
import com.mybeaker.app.skincare.model.MaterialMateVO;
import com.mybeaker.app.skincare.model.MaterialSearchVO;
import com.mybeaker.app.skincare.model.PlantRatePriceReqVO;
import com.mybeaker.app.skincare.model.ValidateVO;
import com.mybeaker.app.skincare.model.VersionReqDTO;

@Mapper
public interface HbdCommonMapper {

	int selectLabNoteCounterListCount(ReqCommSearchInfoDTO reqCommSearchInfoDTO);

	List<HbdCounterDTO> selectLabNoteCounterList(ReqCommSearchInfoDTO reqCommSearchInfoDTO);

	int selectLabNoteInventoryListCount(ReqCommSearchInfoDTO reqCommSearchInfoDTO);

	List<HbdCounterDTO> selectLabNoteInventoryList(ReqCommSearchInfoDTO reqCommSearchInfoDTO);

	String selectLabNoteExistsContInfo(LabNoteCommonReqSAPSyncDTO reqSAPSyncDTO);

	void insertLabNoteMstCounterSAPInfo(HbdNoteContDTO contDTO);

	void insertLabNoteMstVerCounterSAPInfo(HbdNoteContDTO contDTO);

	void insertLabNoteContCounterSAPInfo(HbdNoteContDTO contDTO);

	void insertLabNoteVersionCounterSAPInfo(HbdNoteContDTO contDTO);

	void insertLabNoteFinalVersion(HbdNoteContDTO contDTO);

	void insertLabNoteFinalLot(HbdNoteContDTO contDTO);

	List<LabNoteCommonPlantCheckDTO> selectLabNoteMatePlantCheckList(String vPlantCd, String vContPkCd, String vLotCd);

	HbdNoteInfoDTO selectLabNoteInfo(String vLabNoteCd, String localLanguage, String vUserid);

	List<VersionListVO> selectLabNoteVersionList(VersionReqDTO versionReqDTO);

	public BasicsInfoVerLotVO selectElabBasicsInfoVerLotCd(String vLotCd);

	public int selectSAPBomItemCount(MaterialSearchVO materialSearchVO);

	public int insertSAPBomHeaderReq(ZbomHeaderVO zbomHeaderVO);

	public int insertSAPBomItemReq(ZbomItemVO zbomItemVO);

	public String selectLabNoteContMassEndCheck(String vLabNoteCd);

	public int updateStatusCd_LNC06_51(String vLabNoteCd);

	int updateNoteStatusCd(String vLabNoteCd, String vStatusCd, String vUpdateUserid);

	public int deleteLabNoteMate(HbdNoteMateVO hbdNoteMateVO);

	public List<IngredientContVO> selectLabContList(IngredientReqDTO reqDTO);

	public List<FuncDecideContNameVO> selectLabNoteFuncDecideContName(FuncDecideNameVO funcDecideNameVO);

	public int updateLabNoteContUpdateDecideName(FuncDecideNameVO funcDecideNameVO);

	int updateLabNoteLotBomSucc(String vLotCd);

	int updateLabNoteMstBomSucc(String vLabNoteCd);

	int updateStatusCd_LNC06_25(String vLabNoteCd);

	int updateStatusCd_LNC06_23(String vLabNoteCd);

	public List<MusoguTagVO> selectLabNoteTagList(MusoguReqDTO reqDTO);

	LabNoteVersionDTO selectLabNoteMstVerInfo(String vLabNoteCd, int nVersion, String localLanguage);

	List<LabNoteMstVersionDTO> selectLabNoteMstVerList(String vLabNoteCd, String localLanguage);

	int selectLabNoteNonPrdListCount(CompleteCounterSearchReqDTO completeCounterSearchReqDTO);

	List<HbdCounterDTO> selectLabNoteNonPrdList(CompleteCounterSearchReqDTO completeCounterSearchReqDTO);

	public String selectLabNoteChinaDepts();

	public String selectIsLabNoteContUser(MaterialSearchVO materialSearchVO);

	public String selectLabNoteAuthority(MaterialSearchVO materialSearchVO);

	public List<LabNoteContInfoVO> selectLabNoteContList(LabNoteContInfoVO labNoteInfoVO);

	public List<LabNoteContInfoVO> selectLabNotePlantList(LabNoteContInfoVO labNoteInfoVO);

	public LabNoteContInfoVO selectLabNoteContInfo(LabNoteContInfoVO labNoteContInfoVO);

	List<LabNoteCommonTagDTO> selectLabNoteRequestTagList(List<String> arrTag1Cd, String vLabNoteCd, String localLanguage);

	List<HbdNoteRequestContDTO> selectRequestContList(String vLabNoteCd, String vCodeType);

	List<HbdNoteContDTO> selectElabNoteContList(String vLabNoteCd, String localLanguage);

	List<LabNoteCommonTagDTO> selectLabNoteMstTagAllList(String vLabNoteCd);

	void insertLabNoteMstTag(HbdNoteInfoRegDTO hbdNoteInfoRegDTO);

	void updateSAPMaterialReq(HbdNoteInfoRegDTO mstInfo);

	void insertLabNoteChgLog(ElabChgLogDTO dto);

	void deleteAerosolCont(HbdNoteInfoRegDTO hbdNoteInfoRegDTO);

	void insertAerosolCont(HbdNoteInfoRegDTO hbdNoteInfoRegDTO);

	void insertLabNoteVersion(LabNoteVersionRegDTO versionInfo);

	void insertAerosolContMate(LabNoteVersionRegDTO versionInfo);

	void updateLabNoteMstCopyNoteContNm(String vLabNoteCd);

	void updateLabNoteContCopyNoteContNm(String vLabNoteCd);

	public List<LabNoteMateInfoVO> selectLabNoteMateListMap(String vContPkCd);

	public LabNoteMstVersionPqcDTO selectLabNoteMstVerPqcInfo(String vLabNoteCd, int nVersion, String localLanguage);

	public List<LabNoteTestRequestProductDTO> selectLabNoteTrProductList(LabNoteTestRequestProductReqDTO trDTO);

	public LabNoteTestRequestProductCntDTO selectLabNoteTrProductListCountStats(LabNoteTestRequestProductReqDTO trDTO);

	public String selectApplyPqcCd(LabNotePqcGateCheckReqDTO checkDTO);

	public List<HbdNoteLotDTO> selectElabTargetCostList(String[] arrLotCd, int nTargetGram);

	public HbdNoteLotVO selectLabNoteLot(PlantRatePriceReqVO reqVo);

	public List<ApprovalDetailDTO> selectLabNoteApprovalUserList(String vLabNoteCd, String localLanguage);

	public LabNoteIngrdApprConInfoVO selectLabNoteIngredientApproval(LabNoteIngrdApprConInfoVO vo);

	public LabNoteIngrdApprSaveInfoVO selectLabNoteIngredientApprovalSaveInfo(LabNoteIngrdApprSaveInfoVO vo);

	public int updateStatusCd_LNC06_26(String vLabNoteCd);

	public String selectHboAerosolContRate(String vContCd, String vPlantCd, String vLabNoteCd);

	public List<LabNoteSapBomToConInfoVO> selectSapBomToConList(LabNoteSapBomConSearchVO searchVO);

	public List<LabNoteSapBomToConInfoVO> selectSapBomToConList2(LabNoteSapBomConSearchVO searchVO);

	public List<FinalLotVO> selectLabNoteFinalLot(BookmarkReqDTO reqDTO);

	public int deleteFinalVersionToRate(HbdNoteRateVO hbdNoteRateVO);

	public int deleteFinalVersionToMate(HbdNoteMateVO hbdNoteMateVO);

	public int insertLabNoteFinalMate(HbdNoteMateVO hbdNoteMateVO);

	public int insertLabNoteFinalRate(HbdNoteRateVO hbdNoteRateVO);

	public ValidateVO selectLabNoteValidate(ValidateVO validateVO);

	public int updateLabNoteLotPilot(HbdNoteLotVO hbdNoteLotVO);

	public int updateLabNoteLotDecide(HbdNoteLotVO hbdNoteLotVO);

	public int updateStatusCd_LNC06_30(HbdNoteMstVO hbdNoteMstVO);

	public int updateLabNoteVersionFlagHideN(HbdNoteVersionVO hbdNoteVersionVO);

	public int updateLabNoteLotFlagHideN(HbdNoteLotVO hbdNoteLotVO);

	public int updateLabNoteMateFlagHideN(HbdNoteMateVO hbdNoteMateVO);

	public int updateLabNoteGroupFlagHideN(HbdNoteGroupVO hbdNoteGroupVO);

	public String selectLabNotePrecedePkCd();

	public int insertLabNotePrecedeBomItem(ElabPrecedeBomItemVO elabPrecedeBomItemVO);

	public int updateLabNoteResCost(HbdNoteMstVO hbdNoteMstVO);

	public ElabPqcResVO selectGate1Info(String vLotCd);

	public int updateGate1Info(HbdNoteVersionVO hbdNoteVersionVO);

	public int updateLabNoteCopyVerPqcData(HbdNoteContVO hbdNoteContVO);
//
	public int updateDecideCancel(HbdNoteLotVO hbdNoteLotVO);

	public int updateGate2Cancel(HbdNoteVersionVO hbdNoteVersionVO);

	public int updateStatusCd_LNC06_24(HbdNoteMstVO hbdNoteMstVO);

	public List<LabNoteTestReqApprContVO> selectApprContList(LabNoteProcessPqcCheckApprReqDTO reqDTO);

	public String selectLabNoteStatusCd(String vLabNoteCd);

	public List<MateRateResDTO> selectLabNoteMateRateInfo(MateRateReqVO reqDTO);

	public List<MaterialMateVO> selectLabNoteMateAndGrpList(MaterialSearchVO materialSearchVO);

	int updateLabNoteMstFlagPilot(String vLabNoteCd);

	void updateLabNoteLotPilotComplete(BomApprovalReqDTO bomApprovalReqDTO);

	int selectMat4MMstListCount(LabNoteCommonReq4MRawSearchDTO reqDTO);

	List<Mat4MMstVO> selectMat4MMstList(LabNoteCommonReq4MRawSearchDTO reqDTO);

	public int updateLabNoteLotComplete(String vLotCd);

	LabNoteTestReqLotCompleVO selectLabNoteLotCompleteChk(String vLotCd);

	HbdNoteInfoDTO selectLabNoteMstBaseInfo(String vLabNoteCd);

	public int updateNoteLotStatusCd(String vLotCd, String vTumnTsntLotStCd);

	public List<MaterialMateVO> selectLabNoteMateSimpleList(String vContPkCd, int nVersion);

	public int updateNoteMstNoiValue(String vMatePkCd, String nNoiRsltVl);

	void updateLotFlagSend(HbdNoteLotVO hbdNoteLotVO);

	void updateLotFlagExposure(HbdNoteLotVO hbdNoteLotVO);

	List<LabNoteContInfoVO> checkSubPlantList(String vLabNoteCd, String vContCd);

	List<LabNoteProcessContDecideListDTO> selectGate2ApprLotList(String vApprCd);

	void updateLabNoteStats01(LaunchCompleteContDTO vo);

	void updateLabNoteStats02(LaunchCompleteContDTO vo);

	void updateLabNoteStats03(LaunchCompleteContDTO vo);

	void updateLabNoteSustainabilityStats01(LaunchCompleteContDTO vo);

	void updateLabNoteSustainabilityStats02(LaunchCompleteContDTO vo);

	void updateLabNoteSustainabilityStats03(LaunchCompleteContDTO vo);

	String selectLabNoteFlagAllLaunchComplete(String vLabNoteCd);

	void updateLabNoteMstLaunchComplete(LaunchCompleteReqDTO launchCompleteDTO);

	List<LabNoteDecideDTO> selectLabNoteDecideInfoList(LaunchCompleteContDTO vo);

	public List<HbdCounterDTO> selectSpCodeNoteList(String language, String vSpCode);

	public int selectSpCodeNoteListCount(String vSpCode);

	void updateNoteContReleaseInfo(LaunchCompleteContDTO contDTO);

	void updateNoteContStockDt(String vStockDt, String vContPkCd);

	List<String> selectStockAllCompleteList(List<BatchStatusProcessVO> list);

	void updateDevelopmentCompletedStatus(List<String> list);

	String selectLabNoteMybkRegYn(String vLabNoteCd);

	void updateNoteLotStockStatus(String vContPkCd, String vTumnTsntLotStCd);

	List<BatchStatusProcessVO> selectBatchAlarmInfoList(List<BatchStatusProcessVO> noteList);
}
