package com.mybeaker.app.hbd.controller;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mybeaker.app.hbd.service.HbdTestReqService;
import com.mybeaker.app.labnote.model.LabNoteTestReqDTO;
import com.mybeaker.app.labnote.model.LabNoteTestReqRegDTO;
import com.mybeaker.app.labnote.model.LabNoteTestSavePrsvReqDTO;
import com.mybeaker.app.labnote.model.MusoguReqDTO;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.testreq.model.TestRequestMrq011MailReqDTO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Tag(name = "HBD 원료배합 시험의뢰", description = "HBD 원료배합 시험의뢰")
@RestController
@RequestMapping("/api/hbd/testreq")
public class HbdTestReqController {

	
	private final HbdTestReqService hbdTestReqService;
	
//	/elab/common/lab_note_prd_test_req_pop
	@Operation(summary = "원료배합 시험의뢰(기능성, 효능임상)", description = "원료배합 시험의뢰(기능성) 팝업")
	@GetMapping("/select-prd-test-req-func-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectPrdTestReqFuncInfo (
			@Valid LabNoteTestReqDTO reqDTO) {
		log.debug("select-prd-test-req-func-info Start!");
		log.debug("LabNoteTestReqDTO : {}", reqDTO.toString());
		
		return ResponseEntity.ok(hbdTestReqService.selectPrdTestReqFuncInfo(reqDTO));
	}
	
	@Operation(summary = "원료배합 시험의뢰(무소구)", description = "원료배합 시험의뢰(무소구) 팝업")
	@GetMapping("/select-prd-test-req-muso-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectPrdTestReqMusoInfo (
			@Valid LabNoteTestReqDTO reqDTO) {
		log.debug("select-prd-test-req-muso-info Start!");
		log.debug("LabNoteTestReqDTO : {}", reqDTO.toString());
		
		return ResponseEntity.ok(hbdTestReqService.selectPrdTestReqMusoInfo(reqDTO));
	}
	
	@Operation(summary = "원료배합 시험의뢰(무소구)", description = "원료배합 시험의뢰(무소구) 팝업")
	@GetMapping("/select-ptr-muso-contents-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectPtrMusoContentsInfo (
			@Valid MusoguReqDTO reqDTO) {
		log.debug("select-ptr-muso-contents-info Start!");
		log.debug("MusoguReqDTO : {}", reqDTO.toString());
		
		return ResponseEntity.ok(hbdTestReqService.selectPtrMusoContentsInfo(reqDTO));
	}
	
	@Operation(summary = "원료배합 시험의뢰 저장", description = "원료배합 시험의뢰 저장한다.")
	@PostMapping("/insert-prd-test-req-info")
	public @ResponseBody ResponseEntity<ResponseVO> insertPrdTestReqInfo (
			@RequestBody LabNoteTestReqRegDTO regDTO) {
		log.debug("insert-prd-test-req-info Start!");
		log.debug("LabNoteTestReqRegDTO : {}", regDTO.toString());
		
		return ResponseEntity.ok(hbdTestReqService.insertPrdTestReqInfo(regDTO));
	}
	
	@Operation(summary = "원료배합 시험의뢰(부향)", description = "원료배합 시험의뢰(부향) 팝업")
	@GetMapping("/select-prd-test-req-flavor-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectPrdTestReqFlavorInfo (
			@Valid LabNoteTestReqDTO reqDTO) {
		log.debug("select-prd-test-req-flavor-info Start!");
		log.debug("LabNoteTestReqDTO : {}", reqDTO.toString());
		
		return ResponseEntity.ok(hbdTestReqService.selectPrdTestReqFlavorInfo(reqDTO));
	}
	
	@Operation(summary = "원료배합 시험의뢰(안전성)", description = "원료배합 시험의뢰(안전성) 팝업")
	@GetMapping("/select-prd-test-req-safety-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectPrdTestReqSafetyInfo (
			@Valid LabNoteTestReqDTO reqDTO) {
		log.debug("select-prd-test-req-safety-info Start!");
		log.debug("LabNoteTestReqDTO : {}", reqDTO.toString());
		
		return ResponseEntity.ok(hbdTestReqService.selectPrdTestReqSafetyInfo(reqDTO));
	}
	
	@Operation(summary = "원료배합 시험의뢰(유해물질)", description = "원료배합 시험의뢰(유해물질) 팝업")
	@GetMapping("/select-prd-test-req-harm-sub-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectPrdTestReqHarmSubInfo (
			@Valid LabNoteTestReqDTO reqDTO) {
		log.debug("select-prd-test-req-harm-sub-info Start!");
		log.debug("LabNoteTestReqDTO : {}", reqDTO.toString());
		
		return ResponseEntity.ok(hbdTestReqService.selectPrdTestReqHarmSubInfo(reqDTO));
	}
	
	@Operation(summary = "원료배합 시험의뢰(중국 안전성 사전검토)", description = "원료배합 시험의뢰(중국 안전성 사전검토) 팝업")
	@GetMapping("/select-prd-test-req-china-safety-review-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectPrdTestReqChinaSafetyReviewInfo (
			@Valid LabNoteTestReqDTO reqDTO) {
		log.debug("select-prd-test-req-china-safety-review-info Start!");
		log.debug("LabNoteTestReqDTO : {}", reqDTO.toString());
		
		return ResponseEntity.ok(hbdTestReqService.selectPrdTestReqChinaSafetyReviewInfo(reqDTO));
	}
	
	@Operation(summary = "내용물 버젼별 LOT 리스트 조회", description = "버젼별 LOT 리스트 조회한다.")
	@GetMapping("/select-test-req-lot-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectTestReqLotList (
			LabNoteTestReqDTO reqDTO) {
		log.debug("select-test-req-lot-list Start!");
		log.debug("LabNoteTestReqDTO : {}", reqDTO.toString());
		
		return ResponseEntity.ok(hbdTestReqService.selectTestReqLotList(reqDTO));
	}
	
	@Operation(summary = "원료배합 시험의뢰(방부)", description = "원료배합 시험의뢰(방부) 팝업")
	@GetMapping("/select-prd-test-req-preservative-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectPrdTestReqPreservativeInfo (
			@Valid LabNoteTestReqDTO reqDTO) {
		log.debug("select-prd-test-req-preservative-info Start!");
		log.debug("LabNoteTestReqDTO : {}", reqDTO.toString());
		
		return ResponseEntity.ok(hbdTestReqService.selectPrdTestReqPreservativeInfo(reqDTO));
	}
	
	@Operation(summary = "원료배합 시험의뢰 방부 내용 저장", description = "원료배합 시험의뢰 방부 내용 저장한다.")
	@PostMapping("/insert-prd-test-preservative-info")
	public @ResponseBody ResponseEntity<ResponseVO> insertPrdTestPresevaticeInfo (
			@RequestBody LabNoteTestSavePrsvReqDTO reqDTO) {
		log.debug("insert-prd-test-preservative-info Start!");
		log.debug("LabNoteTestSavePrsvReqDTO : {}", reqDTO);
		
		return ResponseEntity.ok(hbdTestReqService.insertPrdTestPresevaticeInfo(reqDTO));
	}
	
	@Operation(summary = "원료배합 시험의뢰(방부) 메일 전송 팝업", description = "원료배합 시험의뢰(방부) 메일 전송 팝업")
	@GetMapping("/select-lab-note-prd-mrq011-mail-pop")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNotePrdMrq011MailPop (@Valid LabNoteTestReqDTO reqDTO) {
		log.debug("select-lab-note-prd-mrq011-mail-pop Start!");
		log.debug("LabNoteTestReqDTO : {}", reqDTO.toString());
		
		return ResponseEntity.ok(hbdTestReqService.selectLabNotePrdMrq011MailPop(reqDTO));
	}
	
	@Operation(summary = "원료배합 시험의뢰 방부 메일 전송", description = "원료배합 시험의뢰 방부 메일 전송")
	@PostMapping("/send-lab-note-prd-mrq011-mail")
	public @ResponseBody ResponseEntity<ResponseVO> sendLabNotePrdMrq011Mail (@RequestBody TestRequestMrq011MailReqDTO reqDTO) {
		log.debug("send-lab-note-prd-mrq011-mail Start!");
		log.debug("TestRequestMrq011MailReqDTO : {}", reqDTO);
		
		return ResponseEntity.ok(hbdTestReqService.sendLabNotePrdMrq011Mail(reqDTO));
	}
}
