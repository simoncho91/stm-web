package com.mybeaker.app.hbd.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@Data
public class HbdNoteMstVO extends ParentDTO {

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vPjtCd")
	private String vPjtCd;

	@JsonProperty("vLabTypeCd")
	private String vLabTypeCd;

	@JsonProperty("vStatusCd")
	private String vStatusCd;

	@JsonProperty("vBrdCd")
	private String vBrdCd;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vDeptCd")
	private String vDeptCd;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vBsmUserid")
	private String vBsmUserid;

	@JsonProperty("vBrdUserid")
	private String vBrdUserid;

	@JsonProperty("vPerfUserid")
	private String vPerfUserid;

	@JsonProperty("vPilotDt")
	private String vPilotDt;

	@JsonProperty("vMeetingDt")
	private String vMeetingDt;

	@JsonProperty("vMassProdDt")
	private String vMassProdDt;

	@JsonProperty("vProdType1Cd")
	private String vProdType1Cd;

	@JsonProperty("vProdType2Cd")
	private String vProdType2Cd;

	@JsonProperty("nPrice")
	private int nPrice;

	@JsonProperty("nTargetCost")
	private int nTargetCost;

	@JsonProperty("nCapacity")
	private int nCapacity;

	@JsonProperty("vCapacityCd")
	private String vCapacityCd;

	@JsonProperty("vContainerFormCd")
	private String vContainerFormCd;

	@JsonProperty("vContainerTypeCd")
	private String vContainerTypeCd;

	@JsonProperty("vNote")
	private String vNote;

	@JsonProperty("vFlagNew")
	private String vFlagNew;

	@JsonProperty("vFlagApPromise")
	private String vFlagApPromise;

	@JsonProperty("vFlagNotAdd")
	private String vFlagNotAdd;

	@JsonProperty("vApPromiseNote")
	private String vApPromiseNote;

	@JsonProperty("vNotAddNote")
	private String vNotAddNote;

	@JsonProperty("vTrPrdCd")
	private String vTrPrdCd;

	@JsonProperty("vCtcUserid")
	private String vCtcUserid;

	@JsonProperty("vApprCd")
	private String vApprCd;

	@JsonProperty("nLabResCost")
	private int nLabResCost;

	@JsonProperty("vFlagStandard")
	private String vFlagStandard;

	@JsonProperty("vChannelCd")
	private String vChannelCd;

	@JsonProperty("nProductCapacity")
	private int nProductCapacity;

	@JsonProperty("vProductCapacityCd")
	private String vProductCapacityCd;

	@JsonProperty("vTargetCustomer")
	private String vTargetCustomerCustomer;

	@JsonProperty("vBsmUseridSub1")
	private String vBsmUseridSub1;

	@JsonProperty("vBsmUseridSub2")
	private String vBsmUseridSub2;

	@JsonProperty("vLabNoteYear")
	private String vLabNoteYear;

	@JsonProperty("vCompleteDt")
	private String vCompleteDt;

	@JsonProperty("vProdTypeNote")
	private String vProdTypeNote;

	@JsonProperty("vOnePoint")
	private String vOnePoint;

	@JsonProperty("vLeaveType")
	private String vLeaveType;

	@JsonProperty("vCustResearchDt")
	private String vCustResearchDt;

	@JsonProperty("vHarmfulCd")
	private String vHarmfulCd;

	@JsonProperty("nEffTestDcnt")
	private int nEffTestDcnt;

	@JsonProperty("vEffTestDcntUnit")
	private String vEffTestDcntUnit;

	@JsonProperty("vPartCd")
	private String vPartCd;

	@JsonProperty("vFlagReleaseAsia")
	private String vFlagReleaseAsia;

	@JsonProperty("vFlagReleaseAsean")
	private String vFlagReleaseAsean;

	@JsonProperty("vFlagReleaseEtc")
	private String vFlagReleaseEtc;

	@JsonProperty("vEffCompTypeCd")
	private String vEffCompTypeCd;

	@JsonProperty("vEffTestSogooMemo")
	private String vEffTestSogooMemo;

	@JsonProperty("vEffTestItemDt")
	private String vEffTestItemDt;

	@JsonProperty("vTestItemDt")
	private String vTestItemDt;

	@JsonProperty("vFlagDel")
	private String vFlagDel;

	@JsonProperty("vLabContCd")
	private String vLabContCd;

	@JsonProperty("vFlagBomComplete")
	private String vFlagBomComplete;

	@JsonProperty("vFlagTestReq")
	private String vFlagTestReq;

	@JsonProperty("vFlagFuncTest")
	private String vFlagFuncTest;

	@JsonProperty("vFlagPilotTest")
	private String vFlagPilotTest;

	@JsonProperty("vFlagIngredientComplete")
	private String vFlagIngredientComplete;

	@JsonProperty("vFlagDecideLot")
	private String vFlagDecideLot;

	@JsonProperty("v4mMatCd")
	private String v4mMatCd;

	@JsonProperty("vFlagNp")
	private String vFlagNp;

	@JsonProperty("vContainerCd")
	private String vContainerCd;

	@JsonProperty("vContainerEtc")
	private String vContainerEtc;

	@JsonProperty("vFlagReset")
	private String vFlagReset;

	@JsonProperty("vFlagPilotGenerate")
	private String vFlagPilotGenerate;

	@JsonProperty("vBenefit")
	private String vBenefit;

	@JsonProperty("vShapeFeature")
	private String vShapeFeature;

	@JsonProperty("vSpContNm")
	private String vSpContNm;

	@JsonProperty("vFlagOem")
	private String vFlagOem;

	@JsonProperty("vSiteType")
	private String vSiteType;

	@JsonProperty("vOemManufacturer")
	private String vOemManufacturer;

	@JsonProperty("vFlagSameShape")
	private String vFlagSameShape;

	@JsonProperty("vPjtTypeCd")
	private String vPjtTypeCd;

	@JsonProperty("vPrdTypeCd")
	private String vPrdTypeCd;

	@JsonProperty("vRealCompleteDt")
	private String vRealCompleteDt;

	@JsonProperty("vNoteContNm")
	private String vNoteContNm;

	@JsonProperty("vTddProdType1Cd")
	private String vTddProdType1Cd;

	@JsonProperty("vTddProdType2Cd")
	private String vTddProdType2Cd;

	@JsonProperty("vFlagSecurity")
	private String vFlagSecurity;
	
	@JsonProperty("vFlagCompleteReset")
	private String vFlagCompleteReset;
	
	@JsonProperty("vContPkCd")
	private String vContPkCd;
	
	@JsonProperty("nVersion")
	private int nVersion;
	
	@JsonProperty("vLotCd")
	private String vLotCd;
	
	@JsonProperty("vLotAddType")
	private String vLotAddType;

	@Builder
	public HbdNoteMstVO(String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm, String vLabNoteCd,
			String vPjtCd, String vLabTypeCd, String vStatusCd, String vBrdCd, String vPlantCd, String vContCd,
			String vContNm, String vDeptCd, String vUserid, String vBsmUserid, String vBrdUserid, String vPerfUserid,
			String vPilotDt, String vMeetingDt, String vMassProdDt, String vProdType1Cd, String vProdType2Cd,
			int nPrice, int nTargetCost, int nCapacity, String vCapacityCd, String vContainerFormCd,
			String vContainerTypeCd, String vNote, String vFlagNew, String vFlagApPromise, String vFlagNotAdd,
			String vApPromiseNote, String vNotAddNote, String vTrPrdCd, String vCtcUserid, String vApprCd,
			int nLabResCost, String vFlagStandard, String vChannelCd, int nProductCapacity, String vProductCapacityCd,
			String vTargetCustomerCustomer, String vBsmUseridSub1, String vBsmUseridSub2, String vLabNoteYear,
			String vCompleteDt, String vProdTypeNote, String vOnePoint, String vLeaveType, String vCustResearchDt,
			String vHarmfulCd, int nEffTestDcnt, String vEffTestDcntUnit, String vPartCd, String vFlagReleaseAsia,
			String vFlagReleaseAsean, String vFlagReleaseEtc, String vEffCompTypeCd, String vEffTestSogooMemo,
			String vEffTestItemDt, String vTestItemDt, String vFlagDel, String vLabContCd, String vFlagBomComplete,
			String vFlagTestReq, String vFlagFuncTest, String vFlagPilotTest, String vFlagIngredientComplete,
			String vFlagDecideLot, String v4mMatCd, String vFlagNp, String vContainerCd, String vContainerEtc,
			String vFlagReset, String vFlagPilotGenerate, String vBenefit, String vShapeFeature, String vSpContNm,
			String vFlagOem, String vSiteType, String vOemManufacturer, String vFlagSameShape, String vPjtTypeCd,
			String vPrdTypeCd, String vRealCompleteDt, String vNoteContNm, String vTddProdType1Cd,
			String vTddProdType2Cd, String vFlagSecurity, String vFlagCompleteReset, String vContPkCd, int nVersion,
			String vLotCd, String vLotAddType) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.vLabNoteCd = vLabNoteCd;
		this.vPjtCd = vPjtCd;
		this.vLabTypeCd = vLabTypeCd;
		this.vStatusCd = vStatusCd;
		this.vBrdCd = vBrdCd;
		this.vPlantCd = vPlantCd;
		this.vContCd = vContCd;
		this.vContNm = vContNm;
		this.vDeptCd = vDeptCd;
		this.vUserid = vUserid;
		this.vBsmUserid = vBsmUserid;
		this.vBrdUserid = vBrdUserid;
		this.vPerfUserid = vPerfUserid;
		this.vPilotDt = vPilotDt;
		this.vMeetingDt = vMeetingDt;
		this.vMassProdDt = vMassProdDt;
		this.vProdType1Cd = vProdType1Cd;
		this.vProdType2Cd = vProdType2Cd;
		this.nPrice = nPrice;
		this.nTargetCost = nTargetCost;
		this.nCapacity = nCapacity;
		this.vCapacityCd = vCapacityCd;
		this.vContainerFormCd = vContainerFormCd;
		this.vContainerTypeCd = vContainerTypeCd;
		this.vNote = vNote;
		this.vFlagNew = vFlagNew;
		this.vFlagApPromise = vFlagApPromise;
		this.vFlagNotAdd = vFlagNotAdd;
		this.vApPromiseNote = vApPromiseNote;
		this.vNotAddNote = vNotAddNote;
		this.vTrPrdCd = vTrPrdCd;
		this.vCtcUserid = vCtcUserid;
		this.vApprCd = vApprCd;
		this.nLabResCost = nLabResCost;
		this.vFlagStandard = vFlagStandard;
		this.vChannelCd = vChannelCd;
		this.nProductCapacity = nProductCapacity;
		this.vProductCapacityCd = vProductCapacityCd;
		this.vTargetCustomerCustomer = vTargetCustomerCustomer;
		this.vBsmUseridSub1 = vBsmUseridSub1;
		this.vBsmUseridSub2 = vBsmUseridSub2;
		this.vLabNoteYear = vLabNoteYear;
		this.vCompleteDt = vCompleteDt;
		this.vProdTypeNote = vProdTypeNote;
		this.vOnePoint = vOnePoint;
		this.vLeaveType = vLeaveType;
		this.vCustResearchDt = vCustResearchDt;
		this.vHarmfulCd = vHarmfulCd;
		this.nEffTestDcnt = nEffTestDcnt;
		this.vEffTestDcntUnit = vEffTestDcntUnit;
		this.vPartCd = vPartCd;
		this.vFlagReleaseAsia = vFlagReleaseAsia;
		this.vFlagReleaseAsean = vFlagReleaseAsean;
		this.vFlagReleaseEtc = vFlagReleaseEtc;
		this.vEffCompTypeCd = vEffCompTypeCd;
		this.vEffTestSogooMemo = vEffTestSogooMemo;
		this.vEffTestItemDt = vEffTestItemDt;
		this.vTestItemDt = vTestItemDt;
		this.vFlagDel = vFlagDel;
		this.vLabContCd = vLabContCd;
		this.vFlagBomComplete = vFlagBomComplete;
		this.vFlagTestReq = vFlagTestReq;
		this.vFlagFuncTest = vFlagFuncTest;
		this.vFlagPilotTest = vFlagPilotTest;
		this.vFlagIngredientComplete = vFlagIngredientComplete;
		this.vFlagDecideLot = vFlagDecideLot;
		this.v4mMatCd = v4mMatCd;
		this.vFlagNp = vFlagNp;
		this.vContainerCd = vContainerCd;
		this.vContainerEtc = vContainerEtc;
		this.vFlagReset = vFlagReset;
		this.vFlagPilotGenerate = vFlagPilotGenerate;
		this.vBenefit = vBenefit;
		this.vShapeFeature = vShapeFeature;
		this.vSpContNm = vSpContNm;
		this.vFlagOem = vFlagOem;
		this.vSiteType = vSiteType;
		this.vOemManufacturer = vOemManufacturer;
		this.vFlagSameShape = vFlagSameShape;
		this.vPjtTypeCd = vPjtTypeCd;
		this.vPrdTypeCd = vPrdTypeCd;
		this.vRealCompleteDt = vRealCompleteDt;
		this.vNoteContNm = vNoteContNm;
		this.vTddProdType1Cd = vTddProdType1Cd;
		this.vTddProdType2Cd = vTddProdType2Cd;
		this.vFlagSecurity = vFlagSecurity;
		this.vFlagCompleteReset = vFlagCompleteReset;
		this.vContPkCd = vContPkCd;
		this.nVersion = nVersion;
		this.vLotCd = vLotCd;
		this.vLotAddType = vLotAddType;
	}
}
