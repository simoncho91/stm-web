package com.mybeaker.app.hbd.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mybeaker.app.hbd.model.HbdNoteInfoRegDTO;
import com.mybeaker.app.hbd.service.HbdBrandManageService;
import com.mybeaker.app.model.vo.ResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Tag(name = "브랜드 매니저 내용물 개요 수정 api", description = "브랜드 매니저 내용물 개요 수정 api")
@RestController
@RequestMapping("/api/brand-manage-hbd")
@RequiredArgsConstructor
public class HbdBrandManageController {
	private final HbdBrandManageService hbdBrandManageService;

	@Operation(summary = "내용물 개요 상세 조회", description = "내용물 개요 상세 내용을 조회한다.")
	@GetMapping("/select-req-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectReqInfo (
			@RequestParam(value = "vLabNoteCd", defaultValue = "") String vLabNoteCd
			) {
		log.debug("HbdBrandManageController.selectReqInfo => params : { vLabNoteCd: {} }", vLabNoteCd);

		return ResponseEntity.ok(hbdBrandManageService.selectReqInfo(vLabNoteCd));
	}

	@Operation(summary = "내용물 개요 수정", description = "내용물 개요 내용을 수정한다.")
	@PostMapping("/update-req-prd-info")
	public @ResponseBody ResponseEntity<ResponseVO> updateReqPrdInfo (
			@RequestBody HbdNoteInfoRegDTO hbdNoteInfoRegDTO
			) {
		log.debug("HbdBrandManageController.updateReqPrdInfo => hbdNoteInfoRegDTO : {}", hbdNoteInfoRegDTO);

		return ResponseEntity.ok(hbdBrandManageService.updateReqPrdInfo(hbdNoteInfoRegDTO));
	}
}
