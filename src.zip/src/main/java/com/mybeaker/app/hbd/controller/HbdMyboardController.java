package com.mybeaker.app.hbd.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mybeaker.app.hbd.service.HbdMyboardService;
import com.mybeaker.app.labnote.model.MyBoardStateReqDTO;
import com.mybeaker.app.model.vo.ResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Tag(name = "스킨케어 실험노트 마이보드", description="스킨케어 실험노트 마이보드")
@RestController
@RequestMapping("/api/hbd/myboard")
@RequiredArgsConstructor
public class HbdMyboardController {
	private final HbdMyboardService hbdMyboardService;

	@Operation(summary = "마이보드 > 노트 > my note", description = "마이보드 > 노트 > my note 목록을 조회한다.")
	@GetMapping("/select-my-note-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectMyNoteList () {
		return ResponseEntity.ok(hbdMyboardService.selectMyNoteList());
	}

	@Operation(summary = "마이보드 > 노트 > recent note", description = "마이보드 > 노트 > recent note 목록을 조회한다.")
	@GetMapping("/select-recent-note-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectRecentNoteList () {
		return ResponseEntity.ok(hbdMyboardService.selectRecentNoteList());
	}

	@Operation(summary = "마이보드 > 노트 > shared note", description = "마이보드 > 노트 > shared note 목록을 조회한다.")
	@GetMapping("/select-shared-note-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectSharedNoteList () {
		return ResponseEntity.ok(hbdMyboardService.selectSharedNoteList());
	}

	@Operation(summary = "마이보드 > Schedule", description = "마이보드 > Schedule 목록을 조회한다.")
	@GetMapping("/select-schedule-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectScheduleList () {
		return ResponseEntity.ok(hbdMyboardService.selectScheduleList());
	}

	@Operation(summary = "마이보드 > 랩장 대시보드 > 연구원별 집계", description = "마이보드 > 랩장 대시보드 > 연구원별 현황을 조회한다.")
	@GetMapping("/select-labor-current-state-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLaborCurrentStateInfo (
			MyBoardStateReqDTO myBoardStateReqDTO
			) {
		log.debug("HbdMyboardController.selectLaborCurrentStateInfo => params : { MyBoardStateReqDTO: {} }", myBoardStateReqDTO.toString());
		return ResponseEntity.ok(hbdMyboardService.selectLaborCurrentStateInfo(myBoardStateReqDTO));
	}

	@Operation(summary = "마이보드 > 랩장 대시보드 > 브랜드별 집계", description = "마이보드 > 랩장 대시보드 > 브랜드별 현황을 조회한다.")
	@GetMapping("/select-brand-current-state-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectBrandCurrentStateInfo (
			MyBoardStateReqDTO myBoardStateReqDTO
			) {
		log.debug("HbdMyboardController.selectBrandCurrentStateInfo => params : { MyBoardStateReqDTO: {} }", myBoardStateReqDTO.toString());
		return ResponseEntity.ok(hbdMyboardService.selectBrandCurrentStateInfo(myBoardStateReqDTO));
	}

	@Operation(summary = "마이보드 > Examination", description = "마이보드 > Examination 리스트 조회")
	@GetMapping("/select-examination-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectExaminationList () {
		return ResponseEntity.ok(hbdMyboardService.selectExaminationList());
	}
}
