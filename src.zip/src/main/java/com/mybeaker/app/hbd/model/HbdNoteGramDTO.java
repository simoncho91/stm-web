package com.mybeaker.app.hbd.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class HbdNoteGramDTO {

	@JsonProperty("vGramCd")
	private String vGramCd;

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("nGram")
	private String nGram;

	@JsonProperty("nSort")
	private int nSort;

	@JsonProperty("vFlagDel")
	private String vFlagDel;

	@JsonProperty("vFlagSave")
	private String vFlagSave;
}
