package com.mybeaker.app.hbd.controller;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mybeaker.app.hbd.service.HbdApprovalService;
import com.mybeaker.app.labnote.model.BomApprovalReqDTO;
import com.mybeaker.app.labnote.model.MassApprovalReqDTO;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.skincare.model.FuncDecideNameReqDTO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Tag(name = "HBD 결제 api", description="HBD 결제 api")
@RestController
@RequestMapping("/api/hbd/appr")
@RequiredArgsConstructor
public class HbdApprovalController {
	private final HbdApprovalService hbdApprovalService;

	@Operation(summary = "BOM 승인 결재 처리(GATE 1)", description = "BOM 승인 결재 처리(GATE 1)")
	@PostMapping("/update-bom-approval")
	public @ResponseBody ResponseEntity<ResponseVO> updateBomApproval (
			@RequestBody @Valid BomApprovalReqDTO bomApprovalReqDTO
			) {
		log.debug("HbdApprovalController.updateBomApproval");
		log.debug("BomApprovalReqDTO : {}", bomApprovalReqDTO);

		return ResponseEntity.ok(hbdApprovalService.updateBomApproval(bomApprovalReqDTO));
	}

	@Operation(summary = "처방 확정 결재 처리(GATE 2)", description = "처방 확정 결재 처리(GATE 2)")
	@PostMapping("/update-gate2-approval")
	public @ResponseBody ResponseEntity<ResponseVO> updateGate2Approval (
			@RequestBody @Valid MassApprovalReqDTO massApprovalReqDTO
			) {
		log.debug("HbdApprovalController.updateGate2Approval");
		log.debug("MassApprovalReqDTO : {}", massApprovalReqDTO);

		return ResponseEntity.ok(hbdApprovalService.updateGate2Approval(massApprovalReqDTO));
	}

	@Operation(summary = "제품명 확정 결재 처리", description = "제품명 확정 결재 처리")
	@PostMapping("/update-func-decide-name")
	public @ResponseBody ResponseEntity<ResponseVO> updateFuncDecideName (
			@RequestBody @Valid FuncDecideNameReqDTO funcDecideNameReqDTO
			) {
		log.debug("HbdApprovalController.updateFuncDecideName");
		log.debug("FuncDecideNameReqDTO : {}", funcDecideNameReqDTO);

		return ResponseEntity.ok(hbdApprovalService.updateFuncDecideName(funcDecideNameReqDTO));
	}
}
