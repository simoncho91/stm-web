package com.mybeaker.app.hbd.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@Data
public class HbdNoteGramTrVO extends ParentDTO {

	@JsonProperty("vGramCd")
	private String vGramCd;

	@JsonProperty("nSeqno")
	private int nSeqno;

	@JsonProperty("vPlanTestDt")
	private String vPlanTestDt;

	@JsonProperty("vResTestDt")
	private String vResTestDt;
	
	@JsonProperty("vFlagTestPass")
	private String vFlagTestPass;
	
	@JsonProperty("nResCol01")
	private String nResCol01;
	
	@JsonProperty("nResCol02")
	private String nResCol02;
	
	@JsonProperty("vStabilityNote")
	private String vStabilityNote;
	
	@JsonProperty("vFlagSave")
	private String vFlagSave;
	
	@JsonProperty("vGramTrCd")
	private String vGramTrCd;

	@JsonProperty("vFlagDel")
	private String vFlagDel;

	@Builder
	public HbdNoteGramTrVO(String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm, String vGramCd,
			int nSeqno, String vPlanTestDt, String vResTestDt, String vFlagTestPass, String nResCol01, String nResCol02,
			String vStabilityNote, String vFlagSave, String vGramTrCd, String vFlagDel) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.vGramCd = vGramCd;
		this.nSeqno = nSeqno;
		this.vPlanTestDt = vPlanTestDt;
		this.vResTestDt = vResTestDt;
		this.vFlagTestPass = vFlagTestPass;
		this.nResCol01 = nResCol01;
		this.nResCol02 = nResCol02;
		this.vStabilityNote = vStabilityNote;
		this.vFlagSave = vFlagSave;
		this.vGramTrCd = vGramTrCd;
		this.vFlagDel = vFlagDel;
	}
}
