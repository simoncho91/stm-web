package com.mybeaker.app.hbd.model;

import java.util.List;

import com.mybeaker.app.common.model.ThumbnailDTO;
import com.mybeaker.app.common.model.UploadDTO;
import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@Data
public class HbdNoteMemoVO extends ParentDTO {

	private String vMemoCd;

	private String vMemoTypeCd;

	private String vLabNoteCd;
	
	private String vContPkCd;

	private int nVersion;

	private String vLotCd;

	private String vGramCd;

	private String vGramTrCd;

	private String vTitle;

	private String vMemo;
	
	private String vUserid;
	
	private String vFlagWeb;

	private String vFlagDel;
	
	private String vUsernm;

	private String vMemoTypeNm;

	private String vLotNm;
	
	private List<UploadDTO> attList;
	
	private List<ThumbnailDTO> imgList;

	@Builder
	public HbdNoteMemoVO(String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm, String vMemoCd,
			String vMemoTypeCd, String vLabNoteCd, String vContPkCd, int nVersion, String vLotCd, String vGramCd,
			String vGramTrCd, String vTitle, String vMemo, String vUserid, String vFlagWeb, String vFlagDel,
			String vUsernm, String vMemoTypeNm, String vLotNm, List<UploadDTO> attList, List<ThumbnailDTO> imgList) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.vMemoCd = vMemoCd;
		this.vMemoTypeCd = vMemoTypeCd;
		this.vLabNoteCd = vLabNoteCd;
		this.vContPkCd = vContPkCd;
		this.nVersion = nVersion;
		this.vLotCd = vLotCd;
		this.vGramCd = vGramCd;
		this.vGramTrCd = vGramTrCd;
		this.vTitle = vTitle;
		this.vMemo = vMemo;
		this.vUserid = vUserid;
		this.vFlagWeb = vFlagWeb;
		this.vFlagDel = vFlagDel;
		this.vUsernm = vUsernm;
		this.vMemoTypeNm = vMemoTypeNm;
		this.vLotNm = vLotNm;
		this.attList = attList;
		this.imgList = imgList;
	}
}
