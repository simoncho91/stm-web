package com.mybeaker.app.hbd.model;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class HbdMateRateReqDTO {

	@Valid
	@NotEmpty
	@Size(min = 1)
	@JsonProperty("mateRateParamList")
	private List<HbdContentDetailReqDTO> mateRateParamList;
}
