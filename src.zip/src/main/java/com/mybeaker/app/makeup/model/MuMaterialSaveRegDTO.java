package com.mybeaker.app.makeup.model;

import java.util.List;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.skincare.model.MaterialDTO;

import lombok.Data;

@Data
public class MuMaterialSaveRegDTO {

	@NotEmpty
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	private List<String> delGrpCdList;
	
	private List<MuNoteGroupDTO> groupList;
	
	private List<String> delMatePkCdList;
	
	private List<MaterialDTO> mateList;
	
	@NotEmpty
	@JsonProperty("vPlantCd")
	private String vPlantCd;
	
	@NotEmpty
	@JsonProperty("vLand1")
	private String vLand1;
	
	@JsonProperty("vContPkCd")
	private String vContPkCd;
	
	@JsonProperty("nVersion")
	private int nVersion;
	
	@JsonProperty("vLotCd")
	private String vLotCd;
	
	private List<MuNoteLotDTO> lotList;
	
	private MuNoteVersionDTO versionDTO;
	
	@JsonProperty("vStatusCd")
	private String vStatusCd;
	
	@JsonProperty("vSiteType")
	private String vSiteType;

	@JsonProperty("vContCd")
	private String vContCd;
	
	@JsonProperty("vContNm")
	private String vContNm;
	
	@JsonProperty("vLotNm")
	private String vLotNm;
	
	@JsonProperty("vMoveUrl")
	private String vMoveUrl;
}
