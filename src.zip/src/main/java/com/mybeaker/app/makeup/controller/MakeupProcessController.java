package com.mybeaker.app.makeup.controller;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mybeaker.app.labnote.model.BomApprovalReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessContDecideReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReportReqPopDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReportReqSaveDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReportUserReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncRequestQADTO;
import com.mybeaker.app.labnote.model.LabNoteProcessIngrdApprRegDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessIngrdApprReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessPqcCheckApprReqDTO;
import com.mybeaker.app.labnote.model.PilotRequestDetailReqDTO;
import com.mybeaker.app.labnote.model.PilotRequestRegInfoReqDTO;
import com.mybeaker.app.labnote.model.PilotRequestReqDTO;
import com.mybeaker.app.makeup.service.MakeupProcessService;
import com.mybeaker.app.model.dto.ReqCommSearchInfoDTO;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.skincare.model.LotPilotRegDTO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Tag(name = "메이크업 실험노트 프로세스", description="메이크업 실험노트 프로세스")
@RestController
@RequestMapping("/api/makeup/process")
@RequiredArgsConstructor
public class MakeupProcessController {

	private final MakeupProcessService makeupProcessService;

	@Operation(summary = "실험노트의 현재 상태 및 개발프로세스 Bar", description = "프로세스 Bar 가져오기")
	@GetMapping("/select-progress-bar")
	public @ResponseBody ResponseEntity<ResponseVO> selectProgressBar (@RequestParam("vLabNoteCd") String vLabNoteCd) {

		log.debug("MakeupProcessController.selectProgressBar");
		return ResponseEntity.ok(makeupProcessService.selectProgressBar(vLabNoteCd));
	}

	@Operation(summary = "실험노트의 현재 상태 및 개발프로세스 내용 가져오기", description = "프로세스 기본 정보 가져오기")
	@GetMapping("/select-progress-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectProgressInfo (@RequestParam("vLabNoteCd") String vLabNoteCd) {
		log.debug("MakeupProcessController.selectProgressInfo");
		return ResponseEntity.ok(makeupProcessService.selectProgressInfo(vLabNoteCd));
	}

	@Operation(summary = "TIME LINE 탭 알림 목록 가져오기", description = "TIME LINE")
	@GetMapping("/select-timeline-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectTimeLineList (@RequestParam("vLabNoteCd") String vLabNoteCd) {

		log.debug("MakeupProcessController.selectTimeLineList");
		return ResponseEntity.ok(makeupProcessService.selectTimeLineList(vLabNoteCd));
	}

	@Operation(summary = "BOM 요청 목록", description = "실험중 > BOM 요청 목록을 조회한다.")
	@GetMapping("/select-lab-note-bom-req-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteBomReqList (
			PilotRequestReqDTO pilotRequestReqDTO
			) {
		log.debug("MakeupProcessController.selectLabNoteBomReqList => pilotRequestReqDTO : {}", pilotRequestReqDTO);
		return ResponseEntity.ok(makeupProcessService.selectLabNoteBomReqList(pilotRequestReqDTO));
	}

	@Operation(summary = "전성분 승인 목록 가져오기", description = "전성분 승인 > 리스트")
	@GetMapping("/select-ingrd-approval-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectIngrdApprovalList (@Valid LabNoteProcessIngrdApprReqDTO reqDTO) {

		log.debug("MakeupProcessController.selectIngrdApprovalList");
		return ResponseEntity.ok(makeupProcessService.selectIngrdApprovalList(reqDTO));
	}

	@Operation(summary = "전성분 승인에 필요한 정보 가져오기", description = "전성분 승인 > 등록")
	@GetMapping("/select-ingrd-approval-required-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectIngrdApprovalRegRequiredInfo (@Valid LabNoteProcessIngrdApprReqDTO reqDTO) {

		log.debug("MakeupProcessController.selectIngrdApprovalRegRequiredInfo");
		return ResponseEntity.ok(makeupProcessService.selectIngrdApprovalRegRequiredInfo(reqDTO));
	}

	@Operation(summary = "알러젠 표기/미표기 비교 정보 가져오기", description = "전성분 승인 > 등록")
	@GetMapping("/select-ingrd-compare-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectIngrdCompareInfo (LabNoteProcessIngrdApprReqDTO reqDTO) {

		log.debug("MakeupProcessController.selectIngrdCompareInfo");
		return ResponseEntity.ok(makeupProcessService.selectIngrdCompareInfo(reqDTO));
	}

	@Operation(summary = "전성분 승인", description = "전성분 승인 > 등록")
	@PostMapping("/insert-ingrd-approval")
	public @ResponseBody ResponseEntity<ResponseVO> insertIngrdApproval (@RequestBody @Valid LabNoteProcessIngrdApprRegDTO regDTO) {

		log.debug("MakeupProcessController.insertIngrdApproval");
		return ResponseEntity.ok(makeupProcessService.insertIngrdApproval(regDTO));
	}

	@Operation(summary = "전성분 승인 정보 가져오기", description = "전성분 승인 > 상세")
	@GetMapping("/select-ingrd-approval-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectIngrdApprovalInfo (LabNoteProcessIngrdApprReqDTO reqDTO) {

		log.debug("MakeupProcessController.selectIngrdApprovalInfo");
		return ResponseEntity.ok(makeupProcessService.selectIngrdApprovalInfo(reqDTO));
	}

	@Operation(summary = "확정제품명 목록 가져오기", description = "기능성허가 > 확정제품명")
	@GetMapping("/select-func-decide-name-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteFuncDecideNameList (LabNoteProcessFuncReqDTO reqDTO) {

		log.debug("MakeupProcessController.selectLabNoteFuncDecideNameList");
		return ResponseEntity.ok(makeupProcessService.selectLabNoteFuncDecideNameList(reqDTO));
	}

	@Operation(summary = "확정제품명 등록 페이지 내용물 목록 가져오기", description = "기능성허가 > 확정제품명 > 확정 등록")
	@GetMapping("/select-lab-cont-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabContList (@RequestParam("vLabNoteCd") String vLabNoteCd) {

		log.debug("MakeupProcessController.selectLabContList");
		return ResponseEntity.ok(makeupProcessService.selectLabContList(vLabNoteCd));
	}

	@Operation(summary = "확정제품명 수정/조회 페이지 내용물 목록 가져오기", description = "기능성허가 > 확정제품명 > 확정 수정")
	@GetMapping("/select-func-decide-cont-name")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteFuncDecideContName (LabNoteProcessFuncReqDTO reqDTO) {

		log.debug("MakeupProcessController.selectLabNoteFuncDecideContName");
		return ResponseEntity.ok(makeupProcessService.selectLabNoteFuncDecideContName(reqDTO));
	}

	@Operation(summary = "확정제품명 저장하기", description = "기능성허가 > 확정제품명 > 확정 등록")
	@PostMapping("/save-func-decide-name")
	public @ResponseBody ResponseEntity<ResponseVO> saveLabNoteFuncDecideName (@RequestBody @Valid LabNoteProcessFuncReqDTO reqDTO) {

		log.debug("MakeupProcessController.saveLabNoteFuncDecideName");
		return ResponseEntity.ok(makeupProcessService.saveLabNoteFuncDecideName(reqDTO));
	}

	@Operation(summary = "시험성적서 목록 가져오기", description = "기능성허가 > 시험성적서")
	@GetMapping("/select-func-test-epreport-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectFuncTestEpReportList (LabNoteProcessFuncReqDTO reqDTO) {

		log.debug("MakeupProcessController.selectFuncTestEpReportList");
		return ResponseEntity.ok(makeupProcessService.selectFuncTestEpReportList(reqDTO));
	}

	@Operation(summary = "기능성 검사 서류 전송 팝업", description = "기능성허가 > 시험성적서 > 기능성 검사 서류 전송 팝업")
	@GetMapping("/select-labnote-func-request-qa")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteFuncRequestQA (LabNoteProcessFuncReportReqPopDTO reqDTO) {

		log.debug("MakeupProcessController.selectLabNoteFuncRequestQA");
		return ResponseEntity.ok(makeupProcessService.selectLabNoteFuncRequestQA(reqDTO));
	}

	@Operation(summary = "기능성 검사 서류 파일 업로드", description = "기능성허가 > 확정제품명 > 확정 등록")
	@PostMapping("/save-upload-func-report-file")
	public @ResponseBody ResponseEntity<ResponseVO> saveUploadFuncReportFile (@RequestBody @Valid LabNoteProcessFuncReportReqPopDTO reqDTO) {

		log.debug("MakeupProcessController.saveUploadFuncReportFile");
		return ResponseEntity.ok(makeupProcessService.saveUploadFuncReportFile(reqDTO));
	}

	@Operation(summary = "시험성적서 요청 등록 페이지", description = "기능성허가 > 시험성적서 > 시험성적서 요청")
	@GetMapping("/select-func-test-epreport-reg")
	public @ResponseBody ResponseEntity<ResponseVO> selectFuncTestEpReportReg (LabNoteProcessFuncReqDTO reqDTO) {

		log.debug("MakeupProcessController.selectFuncTestEpReportReg");
		return ResponseEntity.ok(makeupProcessService.selectFuncTestEpReportReg(reqDTO));
	}

	@Operation(summary = "시험성적서 요청 등록 페이지", description = "기능성허가 > 시험성적서 > 시험성적서 요청 > Lot 원료 배합량 확인")
	@GetMapping("/select-lab-note-mix-check")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteMixCheckList (@RequestParam("vLotCd") String vLotCd) {

		log.debug("MakeupProcessController.selectLabNoteMixCheckList");
		return ResponseEntity.ok(makeupProcessService.selectLabNoteMixCheckList(vLotCd));
	}

	@Operation(summary = "시험성적서 요청 등록 페이지", description = "기능성허가 > 시험성적서 > 시험성적서 요청 > 요청 팝업 그룹 리스트")
	@GetMapping("/select-group-user-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectGroupUserList (LabNoteProcessFuncReportUserReqDTO reqDTO) {

		log.debug("MakeupProcessController.selectGroupUserList");
		return ResponseEntity.ok(makeupProcessService.selectGroupUserList(reqDTO));
	}

	@Operation(summary = "시험성적서 요청 등록 저장 및 메일 전송", description = "기능성허가 > 시험성적서 > 시험성적서 요청 > 요청 팝업")
	@PostMapping("/save-lab-note-send-func-mail")
	public @ResponseBody ResponseEntity<ResponseVO> saveLabNoteSendFuncMail (@RequestBody @Valid LabNoteProcessFuncReportReqSaveDTO reqDTO) {

		log.debug("MakeupProcessController.saveLabNoteSendFuncMail");
		return ResponseEntity.ok(makeupProcessService.saveLabNoteSendFuncMail(reqDTO));
	}

	@Operation(summary = "시험성적서 요청 심사번호 저장", description = "기능성허가 > 시험성적서 > 시험성적서 요청 > 심사번호 저장")
	@PostMapping("/update-note-ref-note")
	public @ResponseBody ResponseEntity<ResponseVO> updateNoteRefNote (@RequestBody @Valid LabNoteProcessFuncReportReqSaveDTO reqDTO) {

		log.debug("MakeupProcessController.updateNoteRefNote");
		return ResponseEntity.ok(makeupProcessService.updateNoteRefNote(reqDTO));
	}

	@Operation(summary = "개발완료(양산승인) 목록", description = "개발완료 단계 목록")
	@GetMapping("/select-lab-note-cont-decide-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteContDecideList (LabNoteProcessContDecideReqDTO reqDTO) {

		log.debug("MakeupProcessController.selectLabNoteContDecideList");
		return ResponseEntity.ok(makeupProcessService.selectLabNoteContDecideList(reqDTO));
	}

	@Operation(summary = "개발완료(양산승인) 요청", description = "개발완료 요청 자가체크 페이지")
	@GetMapping("/select-lab-note-gate2-reg")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteGate2Reg (LabNoteProcessContDecideReqDTO reqDTO) {

		log.debug("MakeupProcessController.selectLabNoteGate2Reg");
		return ResponseEntity.ok(makeupProcessService.selectLabNoteGate2Reg(reqDTO));
	}

	@Operation(summary = "실험중 > 파일럿 목록", description = "실험중 > 파일럿 목록을 조회한다.")
	@GetMapping("/select-lab-note-pilot-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNotePilotList (
			PilotRequestReqDTO pilotRequestReqDTO
			) {
		log.debug("MakeupProcessController.selectLabNotePilotList => pilotRequestReqDTO : {}", pilotRequestReqDTO);
		return ResponseEntity.ok(makeupProcessService.selectLabNotePilotList(pilotRequestReqDTO));
	}

	@Operation(summary = "파일럿 GATE01 승인 요청 등록 초기 정보 조회", description = "실험중 > 파일럿 GATE01 승인 요청 등록 초기 정보를 조회한다.")
	@GetMapping("/select-lab-note-pilot-reg-init-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNotePilotRegInitInfo (
			PilotRequestReqDTO pilotRequestReqDTO
			) {
		log.debug("MakeupProcessController.selectLabNotePilotRegInitInfo => pilotRequestReqDTO : {}", pilotRequestReqDTO);
		return ResponseEntity.ok(makeupProcessService.selectLabNotePilotRegInitInfo(pilotRequestReqDTO));
	}

	@Operation(summary = "파일럿 GATE01 승인 요청 등록 정보 조회", description = "실험중 > 파일럿 GATE01 승인 요청 등록 정보를 조회한다.")
	@GetMapping("/select-lab-note-pilot-reg-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNotePilotRegInfo (
			PilotRequestRegInfoReqDTO pilotRequestRegInfoReqDTO
			) {
		log.debug("MakeupProcessController.selectLabNotePilotRegInfo => pilotRequestDetailReqDTO : {}", pilotRequestRegInfoReqDTO);
		return ResponseEntity.ok(makeupProcessService.selectLabNotePilotRegInfo(pilotRequestRegInfoReqDTO));
	}

	@Operation(summary = "파일럿 GATE01 승인 요청 버전별 LOT 목록 조회", description = "실험중 > 파일럿 GATE01 승인 요청 버전별 LOT 목록을 조회한다.")
	@GetMapping("/select-lab-note-pilot-reg-version-lot-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNotePilotRegVersionLotList (
			@RequestParam(value="vLabNoteCd") String vLabNoteCd,
			@RequestParam(value="nVersion") int nVersion
			) {
		log.debug("MakeupProcessController.selectLabNoteBomRegVersionLotList => params : { vLabNoteCd: {}, nVersion: {} }", vLabNoteCd, nVersion);
		return ResponseEntity.ok(makeupProcessService.selectLabNotePilotRegVersionLotList(vLabNoteCd, nVersion));
	}

	@Operation(summary = "파일럿 GATE01 승인 요청 상세 정보 조회", description = "실험중 > 파일럿 GATE01 승인 요청 상세 정보를 조회한다.")
	@GetMapping("/select-lab-note-pilot-req-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNotePilotReqInfo (
			PilotRequestDetailReqDTO pilotRequestDetailReqDTO
			) {
		log.debug("MakeupProcessController.selectLabNoteBomReqInfo => pilotRequestDetailReqDTO : {}", pilotRequestDetailReqDTO);
		return ResponseEntity.ok(makeupProcessService.selectLabNotePilotReqInfo(pilotRequestDetailReqDTO));
	}

	@Operation(summary = "LOT별 BOM 리스트 조회", description = "실험중 > BOM 승인 상세 > LOT별 BOM 리스트를 조회한다.")
	@GetMapping("/select-lab-note-bom-mate-rate-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteBomMateRateInfo (
			PilotRequestDetailReqDTO pilotRequestDetailReqDTO
			) {
		log.debug("MakeupProcessController.selectLabNoteBomMateRateInfo => pilotRequestDetailReqDTO : {}", pilotRequestDetailReqDTO);
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(makeupProcessService.selectLabNoteBomMateRateInfo(pilotRequestDetailReqDTO));
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "GATE02 결재 올리기", description = "처방확정 > GATE02 결재 올리기")
	@PostMapping("/save-lab-note-gate02-approval-request")
	public @ResponseBody ResponseEntity<ResponseVO> saveLabNoteGate02ApprovalRequest (@RequestBody @Valid LabNoteProcessPqcCheckApprReqDTO reqDTO) {

		log.debug("MakeupProcessController.saveLabNoteGate02ApprovalRequest");
		return ResponseEntity.ok(makeupProcessService.saveLabNoteGate02ApprovalRequest(reqDTO));
	}

	@SuppressWarnings("deprecation")
	@Operation(summary = "양산승인 요청 PASS", description = "개발완료 > 양산승인 저장")
	@PostMapping("/update-lab-note-mass-pass")
	public @ResponseBody ResponseEntity<ResponseVO> updateLabNoteMassPass (@RequestBody @Valid LabNoteProcessPqcCheckApprReqDTO reqDTO) {

		log.debug("MakeupProcessController.updateLabNoteMassPass");
		return ResponseEntity.ok(makeupProcessService.updateLabNoteMassPass(reqDTO));
	}

	@Operation(summary = "개발완료(양산승인) Gate2 view 페이지", description = "개발완료 요청 자가체크 페이지")
	@GetMapping("/select-lab-note-gate2-view")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteGate2View (LabNoteProcessContDecideReqDTO reqDTO) {

		log.debug("MakeupProcessController.selectLabNoteGate2View");
		return ResponseEntity.ok(makeupProcessService.selectLabNoteGate2View(reqDTO));
	}

	@Operation(summary = "프로세스 > BOM 전송 리스트 조회", description = "프로세스 > BOM 전송 리스트를 조회한다.(BOM 탭)")
	@GetMapping("/select-lab-note-bom-send-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteBomSendList (
			PilotRequestReqDTO pilotRequestReqDTO
			) {
		log.debug("MakeupProcessController.selectLabNoteBomSendList => pilotRequestReqDTO : {}", pilotRequestReqDTO);
		return ResponseEntity.ok(makeupProcessService.selectLabNoteBomSendList(pilotRequestReqDTO));
	}

	@Operation(summary = "프로세스 > 파일럿 GATE01 저장", description = "프로세스 > 파일럿 GATE01 저장")
	@PostMapping("/save-lab-note-gate01")
	public @ResponseBody ResponseEntity<ResponseVO> saveLabNoteGate01 (
			@RequestBody LabNoteProcessPqcCheckApprReqDTO labNoteProcessPqcCheckApprReqDTO
			) {
		log.debug("MakeupProcessController.saveLabNoteGate01 => labNoteProcessPqcCheckApprReqDTO : {}", labNoteProcessPqcCheckApprReqDTO);
		return ResponseEntity.ok(makeupProcessService.saveLabNoteGate01(labNoteProcessPqcCheckApprReqDTO));
	}

	@Operation(summary = "프로세스 > 처방확정 가능 리스트 조회", description = "프로세스 > 처방확정 가능 리스트를 조회한다.")
	@GetMapping("/select-lab-note-formula-decide-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteFormulaDecideList (
			PilotRequestReqDTO pilotRequestReqDTO
			) {
		log.debug("MakeupProcessController.selectLabNoteFormulaDecideList => pilotRequestReqDTO : {}", pilotRequestReqDTO);
		return ResponseEntity.ok(makeupProcessService.selectLabNoteFormulaDecideList(pilotRequestReqDTO));
	}

	@Operation(summary = "프로세스 > 결재 pass BOM SAP 전송", description = "프로세스 > 결재 pass BOM SAP 전송")
	@PostMapping("/send-bom-free-pass")
	public @ResponseBody ResponseEntity<ResponseVO> sendBomFreePass (
			@RequestBody BomApprovalReqDTO bomApprovalReqDTO
			) {
		log.debug("MakeupProcessController.sendBomFreePass => bomApprovalReqDTO : {}", bomApprovalReqDTO);
		return ResponseEntity.ok(makeupProcessService.sendBomFreePass(bomApprovalReqDTO));
	}

	@Operation(summary = "시험성적서 요청 조회 페이지", description = "기능성허가 > 시험성적서 > 시험성적서 조회")
	@GetMapping("/select-func-test-epreport-view")
	public @ResponseBody ResponseEntity<ResponseVO> selectFuncTestEpReportView (LabNoteProcessFuncRequestQADTO reqDTO) {

		log.debug("MakeupProcessController.selectFuncTestEpReportView : {} " + reqDTO);
		return ResponseEntity.ok(makeupProcessService.selectFuncTestEpReportView(reqDTO));
	}

	@Operation(summary = "기능성 확정제품명 상세 정보 조회", description = "기능성 허가 > 확정제품명 결재 후, 메일 링크로 진입 시 정보를 조회")
	@GetMapping("/select-lab-note-func-decide-name-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteFuncDecideNameInfo (
			@RequestParam(value="vLabNoteCd") String vLabNoteCd,
			@RequestParam(value="vApprCd") String vApprCd
			) {
		log.debug("MakeupProcessController.selectLabNoteFuncDecideNameInfo => vLabNoteCd : {}, vApprCd : {}", vLabNoteCd, vApprCd);
		return ResponseEntity.ok(makeupProcessService.selectLabNoteFuncDecideNameInfo(vLabNoteCd, vApprCd));
	}

	@Operation(summary = "QMS 탭", description = "QMS 탭 내용물코드 목록 및 플랜트 리스트를 조회한다.")
	@GetMapping("/select-qms-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectQmsInfo (
			@RequestParam(value="vLabNoteCd") String vLabNoteCd
			) {
		log.debug("MakeupProcessController.selectQmsInfo => vLabNoteCd : {}", vLabNoteCd);
		return ResponseEntity.ok(makeupProcessService.selectQmsInfo(vLabNoteCd));
	}

	@Operation(summary = "QMS 탭 플랜트정보 조회", description = "QMS 탭 내용물코드 별 플랜트 리스트를 조회한다.")
	@GetMapping("/select-qms-plant-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectQmsPlantList (
			@RequestParam(value="vLabNoteCd") String vLabNoteCd,
			@RequestParam(value="vContCd") String vContCd
			) {
		log.debug("MakeupProcessController.selectQmsPlantList => vLabNoteCd : {}, vContCd : {}", vLabNoteCd, vContCd);
		return ResponseEntity.ok(makeupProcessService.selectQmsPlantList(vLabNoteCd, vContCd));
	}

	@Operation(summary = "파일럿 저장 가능 여부 체크", description = "파일럿 저장 가능 여부 체크")
	@PostMapping("/check-validation-pilot")
	public @ResponseBody ResponseEntity<ResponseVO> checkValidationPilot (
			@RequestBody LotPilotRegDTO regDTO
			) {
		log.debug("MakeupProcessController.checkValidationPilot => regDTO : {}", regDTO);
		return ResponseEntity.ok(makeupProcessService.checkValidationPilot(regDTO));
	}

	@Operation(summary = "Right Menu > Schedule 정보", description = "Right Menu > Schedule 정보를 조회한다.")
	@GetMapping("/select-note-detail-schedule-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectNoteDetailScheduleList (
			@RequestParam(value="vLabNoteCd") String vLabNoteCd
			) {
		log.debug("MakeupProcessController.selectNoteDetailScheduleList => vLabNoteCd : {}", vLabNoteCd);
		return ResponseEntity.ok(makeupProcessService.selectNoteDetailScheduleList(vLabNoteCd));
	}
	
	@Operation(summary = "May Contain 생성에 필요한 정보 가져오기", description = "전성분 승인 > 등록")
	@PostMapping("/select-create-may-contain-required-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectCreateMayContainRequiredInfo (@RequestBody LabNoteProcessIngrdApprReqDTO reqDTO) {

		log.debug("MakeupProcessController.selectCreateMayContainRequiredInfo");
		return ResponseEntity.ok(makeupProcessService.selectCreateMayContainRequiredInfo(reqDTO));
	}
	
	@Operation(summary = "LOT별 BOM 상세 조회", description = "실험중 > BOM 승인 상세 > LOT별 BOM 상세를 조회한다.")
	@GetMapping("/select-lab-note-bom-mate-view")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteBomMateView (
			PilotRequestDetailReqDTO pilotRequestDetailReqDTO
			) {
		log.debug("MakeupProcessController.selectLabNoteBomMateView => pilotRequestDetailReqDTO : {}", pilotRequestDetailReqDTO);
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(makeupProcessService.selectLabNoteBomMateView(pilotRequestDetailReqDTO));
		return ResponseEntity.ok(responseVO);
	}
	
	@Operation(summary = "May Contain 생성", description = "전성분 승인 > 등록")
	@PostMapping("/insert-may-contain")
	public @ResponseBody ResponseEntity<ResponseVO> insertMayContain (@RequestBody LabNoteProcessIngrdApprRegDTO regDTO) {

		log.debug("MakeupProcessController.insertMayContain");
		return ResponseEntity.ok(makeupProcessService.insertMayContain(regDTO));
	}
	
	@Operation(summary = "May Contain 찾기(기존 작성 된)", description = "전성분 승인 > 등록")
	@GetMapping("/select-may-contain-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectMayContainList (@Valid ReqCommSearchInfoDTO reqDTO) {

		log.debug("MakeupProcessController.selectMayContainList");
		return ResponseEntity.ok(makeupProcessService.selectMayContainList(reqDTO));
	}
	
	@Operation(summary = "작성 된 May Contain 선택 하여 승계", description = "전성분 승인 > 등록")
	@PostMapping("/insert-may-contain-clone-succ")
	public @ResponseBody ResponseEntity<ResponseVO> insertMayContainCloneSucc (@RequestBody LabNoteProcessIngrdApprRegDTO regDTO) {
		
		log.debug("MakeupProcessController.insertMayContainCloneSucc");
		return ResponseEntity.ok(makeupProcessService.insertMayContainCloneSucc(regDTO));
	}
}
