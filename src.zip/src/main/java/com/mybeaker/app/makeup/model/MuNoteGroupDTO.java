package com.mybeaker.app.makeup.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class MuNoteGroupDTO {

	@JsonProperty("vGrpCd")
	private String vGrpCd;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vGrpNm")
	private String vGrpNm;

	@JsonProperty("vFlagReq")
	private String vFlagReq;

	@JsonProperty("nSortReq")
	private int nSortReq;

	@JsonProperty("nSort")
	private int nSort;

	@JsonProperty("vFlagGrpHide")
	private String vFlagGrpHide;

	@JsonProperty("vFlagDel")
	private String vFlagDel;
}
