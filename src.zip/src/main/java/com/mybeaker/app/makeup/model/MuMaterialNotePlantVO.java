package com.mybeaker.app.makeup.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class MuMaterialNotePlantVO {

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vFlagRepresent")
	private String vFlagRepresent;

	@JsonProperty("vCodeType")
	private String vCodeType;

	@JsonProperty("vPrdCd")
	private String vPrdCd;

	@JsonProperty("vPlantNm")
	private String vPlantNm;

	@JsonProperty("vContTxt")
	private String vContTxt;
	
	@JsonProperty("vTctnBynmNm")
	private String vTctnBynmNm;
	
	private String language;
	
	private List<MuNoteLotVO> lotList;
}
