package com.mybeaker.app.makeup.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.mybeaker.app.labnote.model.LabNoteTestRequestProductDTO;
import com.mybeaker.app.labnote.model.MyBoardLabStateCountDTO;
import com.mybeaker.app.labnote.model.MyBoardNoteInfoDTO;
import com.mybeaker.app.labnote.model.MyBoardNoteInfoReqDTO;
import com.mybeaker.app.labnote.model.MyBoardStateReqDTO;

@Mapper
public interface MakeupMyboardMapper {

	List<MyBoardNoteInfoDTO> selectMyNoteList(MyBoardNoteInfoReqDTO myboardNoteInfoReqDTO);

	List<MyBoardNoteInfoDTO> selectRecentNoteList(String vUserid, String localLanguage);

	List<MyBoardNoteInfoDTO> selectSharedNoteList(String vUserid, String localLanguage, String isAdmin);

	List<MyBoardLabStateCountDTO> selectBrandCurrentStateInfo(MyBoardStateReqDTO myBoardStateReqDTO);

	List<MyBoardLabStateCountDTO> selectLaborCurrentStateInfo(MyBoardStateReqDTO myBoardStateReqDTO);

	List<LabNoteTestRequestProductDTO> selectExaminationList(String vUserid, String localLanguage, String isAdmin);
}
