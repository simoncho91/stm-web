package com.mybeaker.app.makeup.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.mybeaker.app.approval.model.ApprovalDetailDTO;
import com.mybeaker.app.labnote.model.BatchStatusProcessVO;
import com.mybeaker.app.labnote.model.BomApprovalReqDTO;
import com.mybeaker.app.labnote.model.CompleteCounterSearchReqDTO;
import com.mybeaker.app.labnote.model.ElabChgLogDTO;
import com.mybeaker.app.labnote.model.ElabPrecedeBomItemVO;
import com.mybeaker.app.labnote.model.FuncDecideContNameVO;
import com.mybeaker.app.labnote.model.FuncDecideNameVO;
import com.mybeaker.app.labnote.model.LabNoteCommonPlantCheckDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonReq4MRawSearchDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonReqSAPSyncDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonRequestMateDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonTagDTO;
import com.mybeaker.app.labnote.model.LabNoteContInfoVO;
import com.mybeaker.app.labnote.model.LabNoteDecideDTO;
import com.mybeaker.app.labnote.model.LabNoteIngrdApprConInfoVO;
import com.mybeaker.app.labnote.model.LabNoteIngrdApprSaveInfoVO;
import com.mybeaker.app.labnote.model.LabNoteMateInfoVO;
import com.mybeaker.app.labnote.model.LabNoteMstVersionDTO;
import com.mybeaker.app.labnote.model.LabNoteMstVersionPqcDTO;
import com.mybeaker.app.labnote.model.LabNotePqcGateCheckReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessContDecideListDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessPqcCheckApprReqDTO;
import com.mybeaker.app.labnote.model.LabNoteSapBomConSearchVO;
import com.mybeaker.app.labnote.model.LabNoteSapBomToConInfoVO;
import com.mybeaker.app.labnote.model.LabNoteTestReqApprContVO;
import com.mybeaker.app.labnote.model.LabNoteTestReqLotCompleVO;
import com.mybeaker.app.labnote.model.LabNoteTestRequestProductCntDTO;
import com.mybeaker.app.labnote.model.LabNoteTestRequestProductDTO;
import com.mybeaker.app.labnote.model.LabNoteTestRequestProductReqDTO;
import com.mybeaker.app.labnote.model.LabNoteVersionDTO;
import com.mybeaker.app.labnote.model.LaunchCompleteContDTO;
import com.mybeaker.app.labnote.model.LaunchCompleteReqDTO;
import com.mybeaker.app.labnote.model.Mat4MMstVO;
import com.mybeaker.app.labnote.model.MusoguReqDTO;
import com.mybeaker.app.labnote.model.MusoguTagVO;
import com.mybeaker.app.labnote.model.VersionListVO;
import com.mybeaker.app.labnote.model.ZbomHeaderVO;
import com.mybeaker.app.labnote.model.ZbomItemVO;
import com.mybeaker.app.makeup.model.MakeupCounterDTO;
import com.mybeaker.app.makeup.model.MakeupNoteContDTO;
import com.mybeaker.app.makeup.model.MakeupNoteInfoDTO;
import com.mybeaker.app.makeup.model.MakeupNoteInfoRegDTO;
import com.mybeaker.app.makeup.model.MakeupNoteRequestContDTO;
import com.mybeaker.app.makeup.model.MayContainSearchVO;
import com.mybeaker.app.makeup.model.MuNoteContVO;
import com.mybeaker.app.makeup.model.MuNoteGroupVO;
import com.mybeaker.app.makeup.model.MuNoteLotDTO;
import com.mybeaker.app.makeup.model.MuNoteLotVO;
import com.mybeaker.app.makeup.model.MuNoteMateVO;
import com.mybeaker.app.makeup.model.MuNoteMayContainConUseVO;
import com.mybeaker.app.makeup.model.MuNoteMayContainConVO;
import com.mybeaker.app.makeup.model.MuNoteMayContainHistoryVO;
import com.mybeaker.app.makeup.model.MuNoteMayContainInfoVO;
import com.mybeaker.app.makeup.model.MuNoteMstVO;
import com.mybeaker.app.makeup.model.MuNoteRateVO;
import com.mybeaker.app.makeup.model.MuNoteVersionVO;
import com.mybeaker.app.makeup.model.MuSapBomMayContainConVO;
import com.mybeaker.app.model.dto.ReqCommSearchInfoDTO;
import com.mybeaker.app.skincare.model.BasicsInfoVerLotVO;
import com.mybeaker.app.skincare.model.BookmarkReqDTO;
import com.mybeaker.app.skincare.model.ElabPqcResVO;
import com.mybeaker.app.skincare.model.FinalLotVO;
import com.mybeaker.app.skincare.model.IngredientContVO;
import com.mybeaker.app.skincare.model.IngredientReqDTO;
import com.mybeaker.app.skincare.model.MateRateReqVO;
import com.mybeaker.app.skincare.model.MateRateResDTO;
import com.mybeaker.app.skincare.model.MaterialMateVO;
import com.mybeaker.app.skincare.model.MaterialSearchVO;
import com.mybeaker.app.skincare.model.PlantRatePriceReqVO;
import com.mybeaker.app.skincare.model.ValidateVO;
import com.mybeaker.app.skincare.model.VersionReqDTO;

@Mapper
public interface MakeupCommonMapper {

	int selectLabNoteCounterListCount(ReqCommSearchInfoDTO reqCommSearchInfoDTO);

	List<MakeupCounterDTO> selectLabNoteCounterList(ReqCommSearchInfoDTO reqCommSearchInfoDTO);

	int selectLabNoteInventoryListCount(ReqCommSearchInfoDTO reqCommSearchInfoDTO);

	List<MakeupCounterDTO> selectLabNoteInventoryList(ReqCommSearchInfoDTO reqCommSearchInfoDTO);

	String selectLabNoteExistsContInfo(LabNoteCommonReqSAPSyncDTO reqSAPSyncDTO);

	void insertLabNoteMstCounterSAPInfo(MakeupNoteContDTO contDTO);

	void insertLabNoteMstVerCounterSAPInfo(MakeupNoteContDTO contDTO);

	void insertLabNoteContCounterSAPInfo(MakeupNoteContDTO contDTO);

	void insertLabNoteVersionCounterSAPInfo(MakeupNoteContDTO contDTO);

	void insertLabNoteFinalVersion(MakeupNoteContDTO contDTO);

	void insertLabNoteFinalLot(MakeupNoteContDTO contDTO);

	List<LabNoteCommonPlantCheckDTO> selectLabNoteMatePlantCheckList(String vPlantCd, String vContPkCd, String vLotCd);

	MakeupNoteInfoDTO selectLabNoteInfo(String vLabNoteCd, String localLanguage, String vUserid);

	List<LabNoteMstVersionDTO> selectLabNoteMstVerList(String vLabNoteCd, String localLanguage);

	List<VersionListVO> selectLabNoteVersionList(VersionReqDTO versionReqDTO);

	public BasicsInfoVerLotVO selectElabBasicsInfoVerLotCd(String vLotCd);

	public int selectSAPBomItemCount(MaterialSearchVO materialSearchVO);

	public int insertSAPBomHeaderReq(ZbomHeaderVO zbomHeaderVO);

	public int insertSAPBomItemReq(ZbomItemVO zbomItemVO);

	public String selectLabNoteContMassEndCheck(String vLabNoteCd);

	public int updateStatusCd_LNC06_51(String vLabNoteCd);

	int updateNoteStatusCd(String vLabNoteCd, String vStatusCd, String vUpdateUserid);

	public int deleteLabNoteMate(MuNoteMateVO muNoteMateVO);

	public List<IngredientContVO> selectLabContList(IngredientReqDTO reqDTO);

	public List<FuncDecideContNameVO> selectLabNoteFuncDecideContName(FuncDecideNameVO funcDecideNameVO);

	public int updateLabNoteContUpdateDecideName(FuncDecideNameVO funcDecideNameVO);

	int updateLabNoteLotBomSucc(String vLotCd);

	int updateLabNoteMstBomSucc(String vLabNoteCd);

	int updateStatusCd_LNC06_25(String vLabNoteCd);

	int updateStatusCd_LNC06_23(String vLabNoteCd);

	public List<MusoguTagVO> selectLabNoteTagList(MusoguReqDTO reqDTO);

	LabNoteVersionDTO selectLabNoteMstVerInfo(String vLabNoteCd, int nVersion, String localLanguage);

	int selectLabNoteNonPrdListCount(CompleteCounterSearchReqDTO completeCounterSearchReqDTO);

	List<MakeupCounterDTO> selectLabNoteNonPrdList(CompleteCounterSearchReqDTO completeCounterSearchReqDTO);

	public String selectLabNoteChinaDepts();

	public String selectIsLabNoteContUser(MaterialSearchVO materialSearchVO);

	public String selectLabNoteAuthority(MaterialSearchVO materialSearchVO);

	public List<LabNoteContInfoVO> selectLabNoteContList(LabNoteContInfoVO labNoteInfoVO);

	public List<LabNoteContInfoVO> selectLabNotePlantList(LabNoteContInfoVO labNoteInfoVO);

	public LabNoteContInfoVO selectLabNoteContInfo(LabNoteContInfoVO labNoteContInfoVO);

	List<LabNoteCommonTagDTO> selectLabNoteRequestTagList(List<String> arrTag1Cd, String vLabNoteCd, String localLanguage);

	List<MakeupNoteRequestContDTO> selectRequestContList(String vLabNoteCd, String vCodeType);

	List<LabNoteCommonRequestMateDTO> selectLabNoteRequestMateList(String vLabNoteCd, int nVersion);

	List<MakeupNoteContDTO> selectElabNoteContList(String vLabNoteCd, String localLanguage);

	List<LabNoteCommonTagDTO> selectLabNoteMstTagAllList(String vLabNoteCd);

	void insertLabNoteChgLog(ElabChgLogDTO dto);

	void insertLabNoteMstTag(MakeupNoteInfoRegDTO makeupNoteInfoRegDTO);

	void updateSAPMaterialReq(MakeupNoteInfoRegDTO mstInfo);

	public List<LabNoteMateInfoVO> selectLabNoteMateListMap(String vContPkCd);

	public LabNoteMstVersionPqcDTO selectLabNoteMstVerPqcInfo(String vLabNoteCd, int nVersion, String localLanguage);

	public List<LabNoteTestRequestProductDTO> selectLabNoteTrProductList(LabNoteTestRequestProductReqDTO trDTO);

	public LabNoteTestRequestProductCntDTO selectLabNoteTrProductListCountStats(LabNoteTestRequestProductReqDTO trDTO);

	public String selectApplyPqcCd(LabNotePqcGateCheckReqDTO checkDTO);

	public List<MuNoteLotDTO> selectElabTargetCostList(String[] arrLotCd, int nTargetGram);

	public MuNoteLotVO selectLabNoteLot(PlantRatePriceReqVO reqVo);

	public List<ApprovalDetailDTO> selectLabNoteApprovalUserList(String vLabNoteCd, String localLanguage);

	public LabNoteIngrdApprConInfoVO selectLabNoteIngredientApproval(LabNoteIngrdApprConInfoVO vo);

	public LabNoteIngrdApprSaveInfoVO selectLabNoteIngredientApprovalSaveInfo(LabNoteIngrdApprSaveInfoVO vo);

	public int updateStatusCd_LNC06_26(String vLabNoteCd);

	public List<LabNoteSapBomToConInfoVO> selectSapBomToConList(LabNoteSapBomConSearchVO searchVO);

	public List<LabNoteSapBomToConInfoVO> selectSapBomToConList2(LabNoteSapBomConSearchVO searchVO);

	public String selectMuNoteMayContainInfoEn(MuNoteMayContainInfoVO reqVo);

	public String selectMuNoteMayContainInfoKo(MuNoteMayContainInfoVO reqVo);

	public List<MuSapBomMayContainConVO> selectSapBomDefaultMainConList(MuNoteMayContainInfoVO reqVo);

	public List<MuSapBomMayContainConVO> selectSapBomDefaultConList(MuNoteMayContainInfoVO reqVo);

	public List<FinalLotVO> selectLabNoteFinalLot(BookmarkReqDTO reqDTO);

	public int deleteFinalVersionToRate(MuNoteRateVO muNoteRateVO);

	public int deleteFinalVersionToMate(MuNoteMateVO muNoteMateVO);

	public int insertLabNoteFinalMate(MuNoteMateVO muNoteMateVO);

	public int insertLabNoteFinalRate(MuNoteRateVO muNoteRateVO);

	public ValidateVO selectLabNoteValidate(ValidateVO validateVO);

	public int updateLabNoteLotPilot(MuNoteLotVO muNoteLotVO);
//
	public int updateLabNoteLotDecide(MuNoteLotVO muNoteLotVO);

	public int updateStatusCd_LNC06_30(MuNoteMstVO muNoteMstVO);

	public int updateLabNoteVersionFlagHideN(MuNoteVersionVO muNoteVersionVO);

	public int updateLabNoteLotFlagHideN(MuNoteLotVO muNoteLotVO);

	public int updateLabNoteMateFlagHideN(MuNoteMateVO muNoteMateVO);

	public int updateLabNoteGroupFlagHideN(MuNoteGroupVO muNoteGroupVO);

	public String selectLabNotePrecedePkCd();

	public int insertLabNotePrecedeBomItem(ElabPrecedeBomItemVO elabPrecedeBomItemVO);

	public int updateLabNoteResCost(MuNoteMstVO muNoteMstVO);

	public ElabPqcResVO selectGate1Info(String vLotCd);

	public int updateGate1Info(MuNoteVersionVO muNoteVersionVO);

	public int updateLabNoteCopyVerPqcData(MuNoteContVO muNoteContVO);
//
	public int updateDecideCancel(MuNoteLotVO muNoteLotVO);

	public int updateGate2Cancel(MuNoteVersionVO muNoteVersionVO);

	public int updateStatusCd_LNC06_24(MuNoteMstVO muNoteMstVO);

	public List<LabNoteTestReqApprContVO> selectApprContList(LabNoteProcessPqcCheckApprReqDTO reqDTO);

	public String selectLabNoteStatusCd(String vLabNoteCd);

	public List<MateRateResDTO> selectLabNoteMateRateInfo(MateRateReqVO reqDTO);

	public List<MaterialMateVO> selectLabNoteMateAndGrpList(MaterialSearchVO materialSearchVO);

	int updateLabNoteMstFlagPilot(String vLabNoteCd);

	void updateLabNoteLotPilotComplete(BomApprovalReqDTO bomApprovalReqDTO);

	int selectMat4MMstListCount(LabNoteCommonReq4MRawSearchDTO reqDTO);

	List<Mat4MMstVO> selectMat4MMstList(LabNoteCommonReq4MRawSearchDTO reqDTO);

	public int updateLabNoteLotComplete(String vLotCd);

	LabNoteTestReqLotCompleVO selectLabNoteLotCompleteChk(String vLotCd);

	MakeupNoteInfoDTO selectLabNoteMstBaseInfo(String vLabNoteCd);

	public int updateNoteLotStatusCd(String vLotCd, String vTumnTsntLotStCd);

	public List<MaterialMateVO> selectLabNoteMateSimpleList(String vContPkCd, int nVersion);

	public int updateNoteMstNoiValue(String vMatePkCd, String nNoiRsltVl);

	void updateLotFlagSend(MuNoteLotVO muNoteLotVO);

	void updateLotFlagExposure(MuNoteLotVO muNoteLotVO);

	List<LabNoteContInfoVO> checkSubPlantList(String vLabNoteCd, String vContCd);

	List<LabNoteProcessContDecideListDTO> selectGate2ApprLotList(String vApprCd);

	void updateLabNoteStats01(LaunchCompleteContDTO contDTO);

	void updateLabNoteStats02(LaunchCompleteContDTO contDTO);

	void updateLabNoteStats03(LaunchCompleteContDTO contDTO);

	void updateLabNoteSustainabilityStats01(LaunchCompleteContDTO contDTO);

	void updateLabNoteSustainabilityStats02(LaunchCompleteContDTO contDTO);

	void updateLabNoteSustainabilityStats03(LaunchCompleteContDTO contDTO);

	List<LabNoteDecideDTO> selectLabNoteDecideInfoList(LaunchCompleteContDTO contDTO);

	String selectLabNoteFlagAllLaunchComplete(String vLabNoteCd);

	void updateLabNoteMstLaunchComplete(LaunchCompleteReqDTO launchCompleteDTO);

	public List<MakeupCounterDTO> selectSpCodeNoteList(String language, String vSpCode);

	public int selectSpCodeNoteListCount(String vSpCode);

	void updateNoteContReleaseInfo(LaunchCompleteContDTO contDTO);

	void updateNoteContStockDt(String vStockDt, String vContPkCd);

	List<String> selectStockAllCompleteList(List<BatchStatusProcessVO> list);

	void updateDevelopmentCompletedStatus(List<String> list);

	String selectLabNoteMybkRegYn(String vLabNoteCd);

	void updateNoteLotStockStatus(String vContPkCd, String vTumnTsntLotStCd);

	void deleteMuNoteMayContainContent(String vLabNoteCd);

	void deleteMuNoteMayContain(String vLabNoteCd);

	void deleteMuNoteMayContainHistory(String vLabNoteCd);

	void insertMayContainTempSave(MuNoteMayContainConVO muNoteMayContainConVO);

	List<BatchStatusProcessVO> selectBatchAlarmInfoList(List<BatchStatusProcessVO> noteList);

	void updateMuNoteMayContainConList(MuNoteMayContainConVO muNoteMayContainConVO);
	
	void insertMuNoteMayContainContent(MuNoteMayContainInfoVO muNoteMayContainInfoVO);
	
	int selectMayContainSearchListCount(ReqCommSearchInfoDTO reqCommSearchInfoDTO);
	
	List<MayContainSearchVO> selectMayContainSearchList(ReqCommSearchInfoDTO reqCommSearchInfoDTO);
	
	void updateMuNoteMayContainSucc(String vLabNoteCd, String vSuccessionCd);
	
	List<String> selectMuNoteMayContainCloneParentList(String vSuccessionCd);
	
	List<String> selectmuNoteMayContainCloneChildList(String vLabNoteCd);
	
	void insertMuNoteMayContainSuccHistory(MuNoteMayContainHistoryVO muNoteMayContainHistoryVO);
	
	void insertMuNoteMayContainSuccClone(MuNoteMayContainConUseVO muNoteMayContainConUseVO);
	
	void insertMuNoteMayContain(MuNoteMayContainConVO muNoteMayContainConVO);
	
	void insertMuNoteMayContainConUse(MuSapBomMayContainConVO muSapBomMayContainConVO);
}
