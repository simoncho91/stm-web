package com.mybeaker.app.makeup.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class MakeupContentDetailReqDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("vContPkCd")
	private String vContPkCd;
	
	@JsonProperty("nVersion")
	private String nVersion;
	
	@JsonProperty("vLotCd")
	private String vLotCd;
	
	private String localLanguage;
}
