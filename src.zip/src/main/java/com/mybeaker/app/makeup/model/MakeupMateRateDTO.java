package com.mybeaker.app.makeup.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class MakeupMateRateDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vSiteType")
	private String vSiteType;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vVersionTxt")
	private String vVersionTxt;

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("vLotNm")
	private String vLotNm;

	@JsonProperty("vMateCd")
	private String vMateCd;

	@JsonProperty("vMateNm")
	private String vMateNm;

	@JsonProperty("nRate")
	private double nRate;

	@JsonProperty("nRateSum")
	private double nRateSum;

	@JsonProperty("vUsernm")
	private String vUsernm;
}
