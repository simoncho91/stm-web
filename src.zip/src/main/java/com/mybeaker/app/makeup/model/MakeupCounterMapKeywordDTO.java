package com.mybeaker.app.makeup.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class MakeupCounterMapKeywordDTO {
	@JsonProperty("vCompleteCounterCd")
	private String vCompleteCounterCd;

	@JsonProperty("vContPkCd")
	private String vContPkCd;
}
