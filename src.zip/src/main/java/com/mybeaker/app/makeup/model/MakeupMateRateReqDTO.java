package com.mybeaker.app.makeup.model;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class MakeupMateRateReqDTO {

	@Valid
	@NotEmpty
	@Size(min = 1)
	@JsonProperty("mateRateParamList")
	private List<MakeupContentDetailReqDTO> mateRateParamList;
}
