package com.mybeaker.app.makeup.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class MuLabNoteInfoVO {

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vPjtCd")
	private String vPjtCd;

	@JsonProperty("vPjtNm")
	private String vPjtNm;

	@JsonProperty("vRpmsCd")
	private String vRpmsCd;

	@JsonProperty("vLabTypeCd")
	private String vLabTypeCd;

	@JsonProperty("vLabTypeNm")
	private String vLabTypeNm;

	@JsonProperty("vLabPageType")
	private String vLabPageType;

	@JsonProperty("vLabTypeCtgCd")
	private String vLabTypeCtgCd;

	@JsonProperty("vStatusCd")
	private String vStatusCd;

	@JsonProperty("vStatusNm")
	private String vStatusNm;

	@JsonProperty("vViewType")
	private String vViewType;

	@JsonProperty("vFlagLineProduct")
	private String vFlagLineProduct;

	@JsonProperty("vBrdCd")
	private String vBrdCd;

	@JsonProperty("vBrdNm")
	private String vBrdNm;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vPlantNm")
	private String vPlantNm;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vNoteContNm")
	private String vNoteContNm;

	@JsonProperty("vPrdCd")
	private String vPrdCd;

	@JsonProperty("vLabContCd")
	private String vLabContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vDecideContNm")
	private String vDecideContNm;

	@JsonProperty("vCodeType")
	private String vCodeType;

	@JsonProperty("vDeptCd")
	private String vDeptCd;

	@JsonProperty("vDeptNm")
	private String vDeptNm;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vUsernm")
	private String vUsernm;

	@JsonProperty("vUsrDeptnm")
	private String vUsrDeptnm;

	@JsonProperty("vUsrDeptcd")
	private String vUsrDeptcd;

	@JsonProperty("vSlUserid")
	private String vSlUserid;

	@JsonProperty("vSlUsernm")
	private String vSlUsernm;

	@JsonProperty("vSlDeptnm")
	private String vSlDeptnm;

	@JsonProperty("vSlDeptcd")
	private String vSlDeptcd;

	@JsonProperty("vBrdUserid")
	private String vBrdUserid;

	@JsonProperty("vBrdUsernm")
	private String vBrdUsernm;

	@JsonProperty("vBrdDeptnm")
	private String vBrdDeptnm;

	@JsonProperty("vBrdDeptcd")
	private String vBrdDeptcd;

	@JsonProperty("vPerfUserid")
	private String vPerfUserid;

	@JsonProperty("vPerfUsernm")
	private String vPerfUsernm;

	@JsonProperty("vPerfDeptnm")
	private String vPerfDeptnm;

	@JsonProperty("vPerfDeptcd")
	private String vPerfDeptcd;

	@JsonProperty("vPilotDt")
	private String vPilotDt;

	@JsonProperty("vMeetingDt")
	private String vMeetingDt;

	@JsonProperty("vMassProdDt")
	private String vMassProdDt;

	@JsonProperty("vProdType1Cd")
	private String vProdType1Cd;

	@JsonProperty("vProdType1Nm")
	private String vProdType1Nm;

	@JsonProperty("vProdType2Cd")
	private String vProdType2Cd;

	@JsonProperty("vProdType2Nm")
	private String vProdType2Nm;

	@JsonProperty("vTddProdType1Cd")
	private String vTddProdType1Cd;

	@JsonProperty("vTddProdType2Cd")
	private String vTddProdType2Cd;

	@JsonProperty("vTddProdType1Nm")
	private String vTddProdType1Nm;

	@JsonProperty("vTddProdType2Nm")
	private String vTddProdType2Nm;

	@JsonProperty("vMaterialGroupCd")
	private String vMaterialGroupCd;

	@JsonProperty("vMaterialGroupNm")
	private String vMaterialGroupNm;

	@JsonProperty("nPrice")
	private int nPrice;

	@JsonProperty("nTargetCost")
	private int nTargetCost;

	@JsonProperty("nCapacity")
	private int nCapacity;

	@JsonProperty("vCapacityCd")
	private String vCapacityCd;

	@JsonProperty("vCapacityNm")
	private String vCapacityNm;

	@JsonProperty("vContainerFormCd")
	private String vContainerFormCd;

	@JsonProperty("vContainerFormNm")
	private String vContainerFormNm;

	@JsonProperty("vContainerTypeCd")
	private String vContainerTypeCd;

	@JsonProperty("vContainerTypeNm")
	private String vContainerTypeNm;

	@JsonProperty("vNote")
	private String vNote;

	@JsonProperty("vFlagNew")
	private String vFlagNew;

	@JsonProperty("vFlagApPromise")
	private String vFlagApPromise;

	@JsonProperty("vFlagNotAdd")
	private String vFlagNotAdd;

	@JsonProperty("vApPromiseNote")
	private String vApPromiseNote;

	@JsonProperty("vNotAddNote")
	private String vNotAddNote;

	@JsonProperty("vTrPrdCd")
	private String vTrPrdCd;

	@JsonProperty("vCtcUserid")
	private String vCtcUserid;

	@JsonProperty("vCtcUsernm")
	private String vCtcUsernm;

	@JsonProperty("vCtcDeptnm")
	private String vCtcDeptnm;

	@JsonProperty("vCtcDeptcd")
	private String vCtcDeptcd;

	@JsonProperty("nLabResCost")
	private int nLabResCost;

	@JsonProperty("vFlagStandard")
	private String vFlagStandard;

	@JsonProperty("vChannelCd")
	private String vChannelCd;

	@JsonProperty("vChannelNm")
	private String vChannelNm;

	@JsonProperty("nProductCapacity")
	private int nProductCapacity;

	@JsonProperty("vProductCapacityCd")
	private String vProductCapacityCd;

	@JsonProperty("vProductCapacityNm")
	private String vProductCapacityNm;

	@JsonProperty("vTargetCustomer")
	private String vTargetCustomerCustomer;

	@JsonProperty("vLabNoteYear")
	private String vLabNoteYear;

	@JsonProperty("vCompleteDt")
	private String vCompleteDt;

	@JsonProperty("vProdTypeNote")
	private String vProdTypeNote;

	@JsonProperty("vOnePoint")
	private String vOnePoint;

	@JsonProperty("vOnePointTech")
	private String vOnePointTech;

	@JsonProperty("vLeaveType")
	private String vLeaveType;

	@JsonProperty("vLeaveTypeNm")
	private String vLeaveTypeNm;

	@JsonProperty("vCustResearchDt")
	private String vCustResearchDt;

	@JsonProperty("vHarmfulCd")
	private String vHarmfulCd;

	@JsonProperty("vHarmfulNm")
	private String vHarmfulNm;

	@JsonProperty("nEffTestDcnt")
	private int nEffTestDcnt;

	@JsonProperty("vEffTestDcntUnit")
	private String vEffTestDcntUnit;

	@JsonProperty("vEffTestDcntUnitTxt")
	private String vEffTestDcntUnitTxt;

	@JsonProperty("vPartCd")
	private String vPartCd;

	@JsonProperty("vPartNm")
	private String vPartNm;

	@JsonProperty("vFlagReleaseAsia")
	private String vFlagReleaseAsia;

	@JsonProperty("vFlagReleaseAsean")
	private String vFlagReleaseAsean;

	@JsonProperty("vFlagReleaseEtc")
	private String vFlagReleaseEtc;

	@JsonProperty("vEffCompTypeCd")
	private String vEffCompTypeCd;

	@JsonProperty("vEffCompTypeNm")
	private String vEffCompTypeNm;

	@JsonProperty("vEffTestSogooMemo")
	private String vEffTestSogooMemo;

	@JsonProperty("vEffTestItemDt")
	private String vEffTestItemDt;

	@JsonProperty("vTestItemDt")
	private String vTestItemDt;

	@JsonProperty("vFlagBomComplete")
	private String vFlagBomComplete;

	@JsonProperty("vFlagDecideLot")
	private String vFlagDecideLot;

	@JsonProperty("vFlagTestReq")
	private String vFlagTestReq;

	@JsonProperty("vFlagFuncTest")
	private String vFlagFuncTest;

	@JsonProperty("vFlagPilotTest")
	private String vFlagPilotTest;

	@JsonProperty("vFlagIngredientComplete")
	private String vFlagIngredientComplete;

	@JsonProperty("vFlagReset")
	private String vFlagReset;

	@JsonProperty("vFlagPilotGenerate")
	private String vFlagPilotGenerate;

	@JsonProperty("vBenefit")
	private String vBenefit;

	@JsonProperty("vShapeFeature")
	private String vShapeFeature;

	@JsonProperty("vSpContNm")
	private String vSpContNm;

	@JsonProperty("vFlagOem")
	private String vFlagOem;

	@JsonProperty("vOemManufacturer")
	private String vOemManufacturer;

	@JsonProperty("vSiteType")
	private String vSiteType;

	@JsonProperty("vSiteTypeNm")
	private String vSiteTypeNm;

	@JsonProperty("vFlagDel")
	private String vFlagDel;

	@JsonProperty("vRegUserid")
	private String vRegUserid;

	@JsonProperty("vRegDtm")
	private String vRegDtm;

	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;

	@JsonProperty("vUpdateDtm")
	private String vUpdateDtm;

	@JsonProperty("nMaxVersion")
	private int nMaxVersion;

	@JsonProperty("nContNum")
	private int nContNum;

	@JsonProperty("vFlagExistMatnr")
	private String vFlagExistMatnr;

	@JsonProperty("vFlagGateTcost")
	private String vFlagGateTcost;

	@JsonProperty("vContainerNm")
	private String vContainerNm;

	@JsonProperty("vContainerCd")
	private String vContainerCd;

	@JsonProperty("vContainerEtc")
	private String vContainerEtc;

	@JsonProperty("vFlagGateEffTest")
	private String vFlagGateEffTest;

	@JsonProperty("vContAllUserids")
	private String vContAllUserids;

	@JsonProperty("vShelfLife")
	private String vShelfLife;

	@JsonProperty("vShelflifeStatus")
	private String vShelflifeStatus;

	@JsonProperty("vFlagOpenBom")
	private String vFlagOpenBom;

	@JsonProperty("vFlagSecurity")
	private String vFlagSecurity;

	@JsonProperty("vColorUserid")
	private String vColorUserid;

	@JsonProperty("vColorUsernm")
	private String vColorUsernm;

	@JsonProperty("vColorDeptnm")
	private String vColorDeptnm;

	private String language;
}
