package com.mybeaker.app.makeup.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MakeupNoteRequestContDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vPrdCd")
	private String vPrdCd;

	@JsonProperty("vPrdNm")
	private String vPrdNm;

	@JsonProperty("vPrdNmEn")
	private String vPrdNmEn;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vContNmCn")
	private String vContNmCn;

	@JsonProperty("vContNmEn")
	private String vContNmEn;

	@JsonProperty("vNoteContNm")
	private String vNoteContNm;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vUsernm")
	private String vUsernm;

	@JsonProperty("vCodeType")
	private String vCodeType;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("vFlagRepresent")
	private String vFlagRepresent;

	@JsonProperty("vFlagCancel")
	private String vFlagCancel;

	@JsonProperty("vFlagLaunch")
	private String vFlagLaunch;

	@JsonProperty("vFlagExistMatnr")
	private String vFlagExistMatnr;

	@JsonProperty("vFlagExistsHal4")
	private String vFlagExistsHal4;

	@JsonProperty("vHal4ContPkCd")
	private String vHal4ContPkCd;

	@JsonProperty("vHal4ContCd")
	private String vHal4ContCd;

	@JsonProperty("vHal4ContNm")
	private String vHal4ContNm;

	@JsonProperty("vHal4LabNoteCd")
	private String vHal4LabNoteCd;

	@JsonProperty("vShelfLife")
	private String vShelfLife;

	@JsonProperty("vStatusCd")
	private String vStatusCd;

	@JsonProperty("vTctnBynmNm")
	private String vTctnBynmNm;
	
	@JsonProperty("vFlagMate")
	private String vFlagMate;

	private String newYn;

	private String vRegUserid;

	private String vUpdateUserid;
}
