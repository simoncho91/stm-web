package com.mybeaker.app.makeup.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class MuMemoResDTO {
	
	private List<MuNoteMemoVO> list;
	
	private MuNoteMemoVO rvo;
	
	@JsonProperty("vMemoTypeCd")
	private String vMemoTypeCd;
}
