package com.mybeaker.app.makeup.mapper;

import java.util.List;

import javax.validation.Valid;

import org.apache.ibatis.annotations.Mapper;

import com.mybeaker.app.labnote.model.InsertSupTrPrdInfoDTO;
import com.mybeaker.app.labnote.model.LabNoteMusoguTemp2DTO;
import com.mybeaker.app.labnote.model.LabNoteMusoguTempDTO;
import com.mybeaker.app.labnote.model.LabNoteTestReqContVO;
import com.mybeaker.app.labnote.model.LabNoteTestReqDTO;
import com.mybeaker.app.labnote.model.LabNoteTestReqLotVO;
import com.mybeaker.app.labnote.model.LabNoteTestReqRegDTO;
import com.mybeaker.app.labnote.model.LabNoteTestReqTagListVO;
import com.mybeaker.app.labnote.model.LabNoteValidateDTO;
import com.mybeaker.app.labnote.model.MusoguInfoVO;
import com.mybeaker.app.labnote.model.MusoguRateVO;
import com.mybeaker.app.labnote.model.MusoguReqDTO;
import com.mybeaker.app.labnote.model.MusoguTagVO;
import com.mybeaker.app.labnote.model.ProdSignResDTO;
import com.mybeaker.app.makeup.model.MuNoteMstVO;
import com.mybeaker.app.makeup.model.MuNoteMstVerTagVO;
import com.mybeaker.app.testreq.model.TestRequestMrq011MailDTO;

@Mapper
public interface MakeupTestReqMapper {

	List<LabNoteTestReqContVO> selectTestReqContList(String vLabNoteCd, String vPlantCd);

	List<LabNoteTestReqLotVO> selectTestReqLotList(LabNoteTestReqDTO reqDTO);

	public List<MusoguTagVO> selectLabNoteTagList(LabNoteTestReqDTO reqDTO);

	public LabNoteValidateDTO selectLabNoteValidateInfo(LabNoteTestReqRegDTO reqDTO);
	
	public LabNoteValidateDTO selectLabNoteValidateInfo2(LabNoteTestReqContVO contVO);

	public int updateLabNoteMstFlagTestReq(String vLabNoteCd, String vRegUserid);

	public MusoguInfoVO selectMusoguInfo(MusoguReqDTO reqDTO);

	InsertSupTrPrdInfoDTO selectInsertSupTrProductInfo(String vLabNoteCd, String vRepContPkCd, String vRepLotCd);

	public int insertSupTrReleaseCountry(LabNoteTestReqRegDTO reqDTO);

	List<LabNoteTestReqTagListVO> selectLabNoteTagList(LabNoteMusoguTempDTO tempMap);

	public int insertLabNoteToMrqMateTestReqMusogu(LabNoteTestReqRegDTO regDTO);
	
	public int insertLabNoteToMrqMateTestReqFlavor(LabNoteTestReqRegDTO regDTO);

	public int insertSupTrMrq050MtrList(LabNoteTestReqRegDTO regDTO);

	public int insertMrq050_HAL4CD(LabNoteMusoguTemp2DTO temp);

	public List<MusoguRateVO> selectMusoguRate(MusoguReqDTO reqDTO);

	public int insertSupTrProductLine(LabNoteTestReqRegDTO regDTO);
	
	public int updateStatusCd_LNC06_31(MuNoteMstVO muNoteMstVO);
	
	public int updateLabNoteLotTrPrdCd(LabNoteTestReqRegDTO regDTO);
	
	public String selectNotePlantInfo(String countercd);

	public List<ProdSignResDTO> selectProdSignList(String vLabNoteCd, String localLanguage);

	public TestRequestMrq011MailDTO selectPrdMrq011RequestMailNoteInfo(@Valid LabNoteTestReqDTO reqDTO);

	public String selectLotNm(String vLotCd);
	
	public int insertNoteMstTag(MuNoteMstVerTagVO noteMstVerTagVO);
}
