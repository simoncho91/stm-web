package com.mybeaker.app.makeup.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class MayContainSearchVO {

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vContCd")
	private String vContCd;
	
	@JsonProperty("vContNm")
	private String vContNm;
	
	@JsonProperty("vPlantCd")
	private String vPlantCd;
	
	@JsonProperty("vSuccessionContCd")
	private String vSuccessionContCd;
	
	@JsonProperty("vSuccessionContNm")
	private String vSuccessionContNm;
}
