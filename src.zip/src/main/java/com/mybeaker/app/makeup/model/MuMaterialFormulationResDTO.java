package com.mybeaker.app.makeup.model;

import java.util.List;

import com.mybeaker.app.labnote.model.ElabNoteMstSetVO;
import com.mybeaker.app.skincare.model.MaterialLotVO;
import com.mybeaker.app.skincare.model.MaterialMateRateVO;
import com.mybeaker.app.skincare.model.MaterialMateSumVO;
import com.mybeaker.app.skincare.model.MaterialMateVO;
import com.mybeaker.app.skincare.model.MaterialMdlVO;
import com.mybeaker.app.skincare.model.MaterialNoteContVO;
import com.mybeaker.app.skincare.model.MaterialNoteVersionVO;
import com.mybeaker.app.skincare.model.MaterialNumberVO;
import com.mybeaker.app.skincare.model.MaterialOtherResDTO;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class MuMaterialFormulationResDTO {

	private MakeupNoteInfoDTO rvo;
	
	private List<MuMaterialNotePlantVO> plantList;
	
	private List<MuMaterialNotePlantVO> contList;
	
	private MaterialNoteContVO contVO;
	
	private List<MaterialNoteVersionVO> verList;
	
	private MaterialNoteVersionVO verVO;
	
	private List<MaterialLotVO> lotAllList;
	
	private List<MaterialLotVO> lotList;
	
	private List<MaterialMateVO> mateList;
	
	private List<MaterialMdlVO> mdlList;
	
	private int deno;
	
	private List<MaterialNumberVO> numberList;
	
	private List<MaterialMateRateVO> rateList;
	
	private List<MaterialMateSumVO> matePriceList;
	
	private MaterialOtherResDTO otherVO;
	
	private List<ElabNoteMstSetVO> mstSetVO;
}
