package com.mybeaker.app.makeup.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class InsertMuNoteMayContainRegDTO {

	@JsonProperty("vConcd")
	private String vConcd;

	@JsonProperty("vConnmEn")
	private String vConnmEn;
	
	@JsonProperty("vConnmKo")
	private String vConnmKo;
	
	@JsonProperty("vCiNumber")
	private String vCiNumber;
	
	@JsonProperty("vRegUserid")
	private String vRegUserid;
	
	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;
	
	@JsonProperty("vFlagAction")
	private String vFlagAction;
	
	@JsonProperty("concdList")
	private List<String> concdList;
}
