package com.mybeaker.app.makeup.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class MakeupCounterMapDTO {
	@JsonProperty("vId")
	private String vId;

	@JsonProperty("vParent")
	private String vParent;

	@JsonProperty("vText")
	private String vText;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vBrdCd")
	private String vBrdCd;

	@JsonProperty("vBrdNm")
	private String vBrdNm;

	@JsonProperty("vContCd")
	private String vContCd;
}
