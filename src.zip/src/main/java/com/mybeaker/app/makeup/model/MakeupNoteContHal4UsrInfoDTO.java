package com.mybeaker.app.makeup.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MakeupNoteContHal4UsrInfoDTO {
	
	@JsonProperty("vColorUserid")
	private String vColorUserid;
	
	@JsonProperty("vColorUsernm")
	private String vColorUsernm;
	
	@JsonProperty("vColorDeptnm")
	private String vColorDeptnm;
	
}
