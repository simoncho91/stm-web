package com.mybeaker.app.makeup.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.mybeaker.app.makeup.model.MakeupNoteInfoRegDTO;
import com.mybeaker.app.makeup.model.MakeupNoteRequestContDTO;

@Mapper
public interface MakeupBrandManageMapper {

	int updateReqPrdMstInfo(MakeupNoteInfoRegDTO makeupNoteInfoRegDTO);

	void deleteLabNoteMstTag(MakeupNoteInfoRegDTO makeupNoteInfoRegDTO);

	void updateNoteContEtc(MakeupNoteRequestContDTO dto);
}
