package com.mybeaker.app.makeup.controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mybeaker.app.common.model.MessageDTO;
import com.mybeaker.app.labnote.model.CompleteCounterSearchReqDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonReq4MRawSearchDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonReqSAPSyncDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonResSAPSyncDTO;
import com.mybeaker.app.labnote.model.Mat4MMstVO;
import com.mybeaker.app.makeup.model.MakeupCounterDTO;
import com.mybeaker.app.makeup.model.MuNoteLotVO;
import com.mybeaker.app.makeup.service.MakeupCommonService;
import com.mybeaker.app.model.dto.PagingDTO;
import com.mybeaker.app.model.dto.ReqCommSearchInfoDTO;
import com.mybeaker.app.model.dto.ResCommSearchInfoDTO;
import com.mybeaker.app.model.enums.CommonResultCode;
import com.mybeaker.app.model.enums.LabNoteResultCode;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.skincare.model.DecideCancelRegDTO;
import com.mybeaker.app.skincare.model.LatestBomRegDTO;
import com.mybeaker.app.skincare.model.MateRateReqVO;
import com.mybeaker.app.utils.CommonUtil;
import com.mybeaker.app.utils.ConvertUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Tag(name = "메이크업 공통 팝업 및 모듈 api", description="메이크업 공통 팝업 및 모듈 api")
@RestController
@RequestMapping("/api/makeup/common")
@RequiredArgsConstructor
public class MakeupCommonController {
	private final MakeupCommonService makeupCommonService;

	@Operation(summary = "자사 카운터 검색 - 실험노트 탭", description = "자사 카운터 검색 - 실험노트 탭 리스트를 조회한다. (화면ID : SC-PO-119)")
	@GetMapping("/select-lab-note-counter-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteCouterList (
			ReqCommSearchInfoDTO reqCommSearchInfoDTO
			) {
		ResponseVO responseVO = new ResponseVO();

		log.debug("MakeupCommonController.selectLabNoteCounterList : {}", reqCommSearchInfoDTO);

		int totalCnt = makeupCommonService.selectLabNoteCounterListCount(reqCommSearchInfoDTO);
		List<MakeupCounterDTO> list = null;
		CommonUtil.setPaging(reqCommSearchInfoDTO, totalCnt);

		if (totalCnt > 0) {
			list = makeupCommonService.selectLabNoteCounterList(reqCommSearchInfoDTO);
		}

		PagingDTO page = ConvertUtil.convert(reqCommSearchInfoDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
						.page(page)
						.list(list)
						.build();

		responseVO.setOk(res);
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "자사 카운터 검색 - 인벤토리 탭", description = "자사 카운터 검색 - 인벤토리 탭 리스트를 조회한다. (화면 ID : SC-PO-119)")
	@GetMapping("/select-lab-note-inventory-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteInventoryList (
			ReqCommSearchInfoDTO reqCommSearchInfoDTO
			) {
		ResponseVO responseVO = new ResponseVO();

		log.debug("MakeupCommonController.selectLabNoteInventoryList : {}", reqCommSearchInfoDTO);

		int totalCnt = makeupCommonService.selectLabNoteInventoryListCount(reqCommSearchInfoDTO);
		List<MakeupCounterDTO> list = null;
		CommonUtil.setPaging(reqCommSearchInfoDTO, totalCnt);

		if (totalCnt > 0) {
			list = makeupCommonService.selectLabNoteInventoryList(reqCommSearchInfoDTO);
		}

		PagingDTO page = ConvertUtil.convert(reqCommSearchInfoDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
									.page(page)
									.list(list)
									.build();

		responseVO.setOk(res);
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "자사 카운터 검색 - SAP SYNC 탭", description = "자사 카운터 검색 - SAP SYNC (화면 ID : SC-PO-119)")
	@PostMapping("/insert-counter-sap-sync")
	public @ResponseBody ResponseEntity<ResponseVO> insertCounterSapSync (
			@RequestBody LabNoteCommonReqSAPSyncDTO reqSAPSyncDTO
			) {
		ResponseVO responseVO = new ResponseVO();

		if (StringUtils.isEmpty(reqSAPSyncDTO.getVContCd()) || StringUtils.isEmpty(reqSAPSyncDTO.getVPlantCd())) {
			responseVO.setOk(CommonResultCode.NO_ESSENTIAL_DATA, null);
			return ResponseEntity.ok(responseVO);
		} else if (!(reqSAPSyncDTO.getVContCd().startsWith("3") || reqSAPSyncDTO.getVContCd().startsWith("4") || reqSAPSyncDTO.getVContCd().startsWith("J"))) {
			responseVO.setOk(LabNoteResultCode.WRONG_CONTCD, null);
			return ResponseEntity.ok(responseVO);
		}

		LabNoteCommonResSAPSyncDTO resSAPSyncDTO = makeupCommonService.insertCounterSapSync(reqSAPSyncDTO);

		if (CommonResultCode.SAVE_SUCC.getCode().equals(resSAPSyncDTO.getVResultCode())) {
			responseVO.setCreateOk(resSAPSyncDTO);
		} else {
			responseVO.setOkWithCode(resSAPSyncDTO.getVResultCode(), "", null);
		}

		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "자사 카운터 선택 - 카운터 원료 플랜트 체크", description = "자사 카운터 선택 - 카운터 적용 버튼 클릭 (화면 ID : SC-PO-119)")
	@GetMapping("/select-lab-note-mate-plant-check-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteMatePlantCheckList (
			@RequestParam(value="vPlantCd") String vPlantCd,
			@RequestParam(value="vContPkCd") String vContPkCd,
			@RequestParam(value="vLotCd") String vLotCd
			) {
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(makeupCommonService.selectLabNoteMatePlantCheckList(vPlantCd, vContPkCd, vLotCd));

		return ResponseEntity.ok(responseVO);
	}

//	elab/experiment/lab_note_check_sap_bom_ajax
	@Operation(summary = "BOM 동일여부 판단(확정 처방 저장)", description = "확정 처방 저장시 실험노트 LOT의 BOM과 SAP의 BOM이 동일한지 판단한다.")
	@PostMapping("/insert-elab-note-latest-bom-info")
	public @ResponseBody ResponseEntity<ResponseVO> insertElabNoteLatestBomInfo (
			@RequestBody @Valid LatestBomRegDTO regDTO) {
		log.debug("insert-elab-note-latest-bom-info Start!");
		log.debug("LatestBomRegDTO : {}", regDTO.toString());

		return ResponseEntity.ok(makeupCommonService.insertElabNoteLatestBomInfo(regDTO.getVLotCd()));
	}

	@Operation(summary = "완료 카운터 리스트 조회", description = "출시완료 팝업 - 완료 카운터 리스트를 조회한다.")
	@GetMapping("/select-complete-counter-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectCompleteCounterList (
			CompleteCounterSearchReqDTO completeCounterSearchReqDTO
			) {
		log.debug("MakeupCommonController.selectCompleteCounterList => completeCounterSearchReqDTO : {}", completeCounterSearchReqDTO);

		return ResponseEntity.ok(makeupCommonService.selectCompleteCounterList(completeCounterSearchReqDTO));
	}


//	elab/experiment/lab_note_decide_cancel_ajax
	@Operation(summary = "확정 처방 해제", description = "확정 처방 해제한다.")
	@PostMapping("/update-decide-cancel")
	public @ResponseBody ResponseEntity<ResponseVO> updateDecideCancel (
			@RequestBody @Valid DecideCancelRegDTO regDTO) {
		log.debug("update-decide-cancel Start!");
		log.debug("DecideCancelRegDTO : {}", regDTO.toString());

		return ResponseEntity.ok(makeupCommonService.updateDecideCancel(regDTO));
	}

//	SAVE_TEST_DECIDE
	/* 프로세스 변경으로 인해, 처방 확정을 단독으로 하는 경우가 없음. 처방확정 + Gate 2 진행 같이 하기 때문에 주석처리 함
	 * @Operation(summary = "확정 처방 저장", description = "확정 처방 저장한다.")
	 *
	 * @PostMapping("/update-lab-note-lot-decide") public @ResponseBody
	 * ResponseEntity<ResponseVO> updateLabNoteLotDecide (
	 *
	 * @RequestBody @Valid LotDecideRegDTO regDTO) {
	 * log.debug("update-lab-note-lot-decide Start!");
	 * log.debug("LotDecideRegDTO : {}", regDTO.toString());
	 *
	 * return ResponseEntity.ok(makeupCommonService.updateLabNoteLotDecide(regDTO));
	 * }
	 */

	@Operation(summary = "LOT별 BOM 리스트 조회", description = "LOT별 BOM 리스트를 조회한다.")
	@GetMapping("/select-lab-note-mate-rate-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteMateRateInfo (MateRateReqVO mateRateVO) {
		log.debug("MakeupCommonController.selectLabNoteMateRateInfo => MateRateReqVO : {}", mateRateVO);
		return ResponseEntity.ok(makeupCommonService.selectLabNoteMateRateInfo(mateRateVO));
	}

	@Operation(summary = "실험노트 마스터 정보 조회", description = "실험노트 마스터 정보를 조회한다.")
	@GetMapping("/select-lab-note-info-check-auth")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteInfoCheckAuth (
			@RequestParam(value = "vLabNoteCd") String vLabNoteCd
			) {
		log.debug("MakeupCommonController.selectLabNoteInfoCheckAuth => vLabNoteCd : {}", vLabNoteCd);
		return ResponseEntity.ok(makeupCommonService.selectLabNoteInfoCheckAuth(vLabNoteCd));
	}

	@Operation(summary = "4M 원료 검색", description = "4M 원료를 조회한다.")
	@GetMapping("/select-mat-4m-mst-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectMat4MMstList (
			LabNoteCommonReq4MRawSearchDTO reqDTO
			) {
		ResponseVO responseVO = new ResponseVO();

		log.debug("MakeupCommonController.selectMat4MMstList : {}", reqDTO);

		int totalCnt = makeupCommonService.selectMat4MMstListCount(reqDTO);
		List<Mat4MMstVO> list = null;
		CommonUtil.setPaging(reqDTO, totalCnt);

		if (totalCnt > 0) {
			list = makeupCommonService.selectMat4MMstList(reqDTO);
		}

		PagingDTO page = ConvertUtil.convert(reqDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
									.page(page)
									.list(list)
									.build();

		responseVO.setOk(res);
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "comment 등록", description = "comment를 등록한다.")
	@PostMapping("/insert-message")
	public @ResponseBody ResponseEntity<ResponseVO> insertMessage (
			@RequestBody MessageDTO messageDTO
			) {
		ResponseVO responseVO = new ResponseVO();
		int result = makeupCommonService.labNoteInsertMessage(messageDTO);

		if (result > 0) {
			responseVO.setCreateOk(null);
		} else {
			responseVO.setOkWithCode("C9999", CommonResultCode.SAVE_FAIL, null);
		}

		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "실험노트 마스터 정보 조회(3자 코드 채번 팝업)", description = "실험노트 마스터 정보를 조회한다.")
	@GetMapping("/select-lab-note-mst-basic-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteMstBaseInfo (
			@RequestParam(value = "vLabNoteCd") String vLabNoteCd
			) {
		log.debug("MakeupCommonController.selectLabNoteMstBaseInfo");

		return ResponseEntity.ok(makeupCommonService.selectLabNoteMstBaseInfo(vLabNoteCd));
	}

	@Operation(summary = "마케팅 송부 체크/체크 해제", description = "LOT별 마케팅 송부 체크/체크 해제")
	@PostMapping("/update-lot-flag-send")
	public @ResponseBody ResponseEntity<ResponseVO> updateLotFlagSend (
			@RequestBody MuNoteLotVO muNoteLotVO
			) {
		log.debug("MakeupCommonController.updateLotFlagSend => muNoteLotVO : {}", muNoteLotVO);

		return ResponseEntity.ok(makeupCommonService.updateLotFlagSend(muNoteLotVO));
	}

	@Operation(summary = "LOT 숨김/해제", description = "LOT별 숨김/해제")
	@PostMapping("/update-lot-flag-exposure")
	public @ResponseBody ResponseEntity<ResponseVO> updateLotFlagExposure (
			@RequestBody MuNoteLotVO muNoteLotVO
			) {
		log.debug("MakeupCommonController.updateLotFlagSend => muNoteLotVO : {}", muNoteLotVO);

		return ResponseEntity.ok(makeupCommonService.updateLotFlagExposure(muNoteLotVO));
	}

	@Operation(summary = "노트 마스터 버전 리스트 조회", description = "노트별 마스터 버전 리스트를 조회한다.")
	@GetMapping("/select-note-mst-ver-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteMstVerList (
			@RequestParam(value = "vLabNoteCd") String vLabNoteCd
			) {
		log.debug("MakeupCommonController.selectLabNoteMstVerList => vLabNoteCd : {}", vLabNoteCd);

		ResponseVO responseVO = new ResponseVO();
		responseVO.setOk(makeupCommonService.selectLabNoteMstVerList(vLabNoteCd));
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "실험노트 리스트(과제 상세 > 참여 인벤토리)", description = "실험노트 리스트를 조회한다.")
	@GetMapping("/select-exhibit-add-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectExhibitAddList (
			@RequestParam(value = "vSpCode") String vSpCode
			) {
		ResponseVO responseVO = new ResponseVO();

		log.debug("MakeupCommonController.selectExhibitAddList");

		int totalCnt = makeupCommonService.selectSpCodeNoteListCount(vSpCode);
		List<MakeupCounterDTO> list = null;

		if (totalCnt > 0) {
			list = makeupCommonService.selectSpCodeNoteList(vSpCode);
		}

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
									.list(list)
									.build();

		responseVO.setOk(res);
		return ResponseEntity.ok(responseVO);
	}
}
