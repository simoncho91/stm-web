package com.mybeaker.app.makeup.model;

import java.util.List;

import com.mybeaker.app.labnote.model.VersionListVO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class MuBomResDTO {
	
	private List<MuMaterialNotePlantVO> contList;
	
	private List<VersionListVO> verList;
}
