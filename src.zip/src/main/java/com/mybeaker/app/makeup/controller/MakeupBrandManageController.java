package com.mybeaker.app.makeup.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mybeaker.app.makeup.model.MakeupNoteInfoRegDTO;
import com.mybeaker.app.makeup.service.MakeupBrandManageService;
import com.mybeaker.app.model.vo.ResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Tag(name = "브랜드 매니저 내용물 개요 수정 api", description = "브랜드 매니저 내용물 개요 수정 api")
@RestController
@RequestMapping("/api/brand-manage-makeup")
@RequiredArgsConstructor
public class MakeupBrandManageController {
	private final MakeupBrandManageService makeupBrandManageService;

	@Operation(summary = "내용물 개요 상세 조회", description = "내용물 개요 상세 내용을 조회한다.")
	@GetMapping("/select-req-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectReqInfo (
			@RequestParam(value="vLabNoteCd", defaultValue = "") String vLabNoteCd
			) {
		log.debug("MakeupBrandManageController.selectReqInfo => params : { vLabNoteCd: {} }", vLabNoteCd);

		return ResponseEntity.ok(makeupBrandManageService.selectReqInfo(vLabNoteCd));
	}

	@Operation(summary = "내용물 등록 의뢰 - 버전 정보 조회", description = "내용물 등록 의뢰 - 버전 정보를 조회한다.")
	@GetMapping("/select-lab-note-mst-ver-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteMstVerInfo (
			@RequestParam(value="vLabNoteCd") String vLabNoteCd,
			@RequestParam(value="nVersion", defaultValue = "0") int nVersion
			) {
		log.debug("MakeupBrandManageController.selectLabNoteMstVerInfo => params : { vLabNoteCd: {}, nVersion: {} }", vLabNoteCd, nVersion);

		ResponseVO responseVO = new ResponseVO();
		responseVO.setOk(makeupBrandManageService.selectLabNoteMstVerInfo(vLabNoteCd, nVersion));
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "내용물 개요 수정", description = "내용물 개요 내용을 수정한다.")
	@PostMapping("/update-req-prd-info")
	public @ResponseBody ResponseEntity<ResponseVO> updateReqPrdInfo (
			@RequestBody MakeupNoteInfoRegDTO makeupNoteInfoRegDTO
			) {
		log.debug("MakeupBrandManageController.updateReqPrdInfo => makeupNoteInfoRegDTO : {}", makeupNoteInfoRegDTO);

		return ResponseEntity.ok(makeupBrandManageService.updateReqPrdInfo(makeupNoteInfoRegDTO));
	}
}

