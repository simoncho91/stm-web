package com.mybeaker.app.makeup.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.mybeaker.app.makeup.model.MakeupCounterMapDTO;
import com.mybeaker.app.makeup.model.MakeupCounterMapKeywordDTO;
import com.mybeaker.app.makeup.model.MakeupContentDetailReqDTO;
import com.mybeaker.app.makeup.model.MakeupMateRateDTO;
import com.mybeaker.app.makeup.model.MakeupContentDetailDTO;
import com.mybeaker.app.makeup.model.MakeupMstSearchDTO;
import com.mybeaker.app.model.dto.ReqCommSearchInfoDTO;

@Mapper
public interface MakeupSearchMapper {

	int selectMstSearchListCount(ReqCommSearchInfoDTO reqCommSearchInfoDTO);
	
	List<MakeupMstSearchDTO> selectMstSearchList(ReqCommSearchInfoDTO reqCommSearchInfoDTO);
	
	List<MakeupContentDetailDTO> selectContentDetail(MakeupContentDetailReqDTO contentDetailReqDTO);
	
	int selectCounterMapKeywordListCount(String vKeyword);
	
	List<MakeupCounterMapKeywordDTO> selectCounterMapKeywordList(String vKeyword);
	
	MakeupCounterMapKeywordDTO selectCounterMapKeyword(String vCompleteCounterCd);
	
	List<MakeupCounterMapDTO> selectCounterMapList(List<String> contPkCdList);
	
	List<MakeupMateRateDTO> selectMateRateInfo(MakeupContentDetailReqDTO contentDetailReqDTO);
}
