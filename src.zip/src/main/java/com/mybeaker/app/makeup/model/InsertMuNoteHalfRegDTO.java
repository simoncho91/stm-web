package com.mybeaker.app.makeup.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.common.model.UploadTempDTO;
import com.mybeaker.app.labnote.model.LabNoteRequestPjtDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class InsertMuNoteHalfRegDTO {

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vPjtCd")
	private String vPjtCd;

	@JsonProperty("vLabTypeCd")
	private String vLabTypeCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vStatusCd")
	private String vStatusCd;

	@JsonProperty("vBrdCd")
	private String vBrdCd;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vDeptCd")
	private String vDeptCd;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vLabContCd")
	private String vLabContCd;

	@JsonProperty("vNote")
	private String vNote;

	@JsonProperty("vLabNoteYear")
	private String vLabNoteYear;

	@JsonProperty("vFlagDel")
	private String vFlagDel;

	@JsonProperty("vRegUserid")
	private String vRegUserid;

	@JsonProperty("vRegDtm")
	private String vRegDtm;

	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;

	@JsonProperty("vUpdateDtm")
	private String vUpdateDtm;

	@JsonProperty("v4mMatCd")
	private String v4mMatCd;

	@JsonProperty("vBenefit")
	private String vBenefit;

	@JsonProperty("vShapeFeature")
	private String vShapeFeature;

	@JsonProperty("vProdType1Cd")
	private String vProdType1Cd;

	@JsonProperty("vProdType2Cd")
	private String vProdType2Cd;

	@JsonProperty("vMaterialGroupCd")
	private String vMaterialGroupCd;

	@JsonProperty("vFlagSecurity")
	private String vFlagSecurity;

	@JsonProperty("nVersion")
	private int nVersion;
	
	@JsonProperty("vVersionNm")
	private String vVersionNm;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("vContNmCn")
	private String vContNmCn;

	@JsonProperty("vContNmEn")
	private String vContNmEn;

	@JsonProperty("vFlagRepresent")
	private String vFlagRepresent;

	@JsonProperty("vCodeType")
	private String vCodeType;

	@JsonProperty("vCounterCd")
	private String vCounterCd;

	@JsonProperty("vFlagPriceHide")
	private String vFlagPriceHide;

	@JsonProperty("vFlagReqHide")
	private String vFlagReqHide;

	@JsonProperty("vFlagMaxmixHide")
	private String vFlagMaxmixHide;

	@JsonProperty("vFlagExistHide")
	private String vFlagExistHide;

	@JsonProperty("vFlagAerosol")
	private String vFlagAerosol;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("nContNum")
	private int nContNum;
	
	@JsonProperty("vFlagAction")
	private String vFlagAction;
	
	@JsonProperty("vUploadCd")
	private String vUploadCd;
	
	@JsonProperty("fileList")
	private List<UploadTempDTO> fileList;
	
	private List<LabNoteRequestPjtDTO> pjtList;
	
	@JsonProperty("v4mHisNum")
	private String v4mHisNum;
	
	@JsonProperty("vType")
	private String vType;
	
	@JsonProperty("vContNmChi")
	private String vContNmChi;
	
	@JsonProperty("vContNmEng")
	private String vContNmEng;
}
