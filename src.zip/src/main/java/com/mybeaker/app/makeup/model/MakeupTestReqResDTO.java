package com.mybeaker.app.makeup.model;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.common.model.CodeDTO;
import com.mybeaker.app.labnote.model.ElabNoteLastTrInfoDTO;
import com.mybeaker.app.labnote.model.LabNoteTestReqContVO;
import com.mybeaker.app.labnote.model.LabNoteTestReqLotVO;
import com.mybeaker.app.labnote.model.MusoguInfoVO;
import com.mybeaker.app.labnote.model.MusoguRateVO;
import com.mybeaker.app.labnote.model.MusoguTagVO;
import com.mybeaker.app.labnote.model.TestReqCounterDTO;
import com.mybeaker.app.labnote.model.TestReqCounterMrq011DTO;
import com.mybeaker.app.labnote.model.VersionListVO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class MakeupTestReqResDTO {

	private List<LabNoteTestReqContVO> contList;
	
	private List<LabNoteTestReqLotVO> lotList;
	
	private ElabNoteLastTrInfoDTO lastTrVo;
	
	private MakeupNoteInfoDTO noteVo;
	
	private List<MusoguTagVO> mtr01List;
	
	private List<MusoguTagVO> mtr03List;
	
	private List<MusoguTagVO> mtr04List;

	private List<MusoguTagVO> mtr05List;

	private List<MusoguTagVO> mtr06List;
	
	private Map<String, List<CodeDTO>> dfList;
	
	private Map<String, List<CodeDTO>> tmkCdList;
	
	private Map<String, List<CodeDTO>> tmeCdList;
	
	private String vFlagZmBbNote;
	
	@JsonProperty("vTrMrqTypeCd")
	private String vTrMrqTypeCd;
	
	@JsonProperty("vTrGoalCd")
	private String vTrGoalCd;
	
	private MusoguInfoVO rvo;
	
	private List<CodeDTO> list;
	
	private List<MusoguRateVO> musoguYnList;
	
	private String vFlagMultiple;
	
	private List<VersionListVO> verList;
	
	@JsonProperty("mrq011CheckSapCd")
	private String mrq011CheckSapCd;
	
	@JsonProperty("vTrComment2")
	private String vTrComment2;
	
	@JsonProperty("counterVo")
	private TestReqCounterDTO counterVo;

	@JsonProperty("counterList")
	private List<TestReqCounterMrq011DTO> counterList;
}
