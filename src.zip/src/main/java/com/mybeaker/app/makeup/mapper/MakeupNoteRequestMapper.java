package com.mybeaker.app.makeup.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.mybeaker.app.labnote.model.ElabChgLogDTO;
import com.mybeaker.app.labnote.model.ElabChgLogSearchReqDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonRequestMateDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonTagDTO;
import com.mybeaker.app.labnote.model.LabNoteRequestMateRegDTO;
import com.mybeaker.app.labnote.model.LabNoteRequestPjtDTO;
import com.mybeaker.app.labnote.model.LabNoteVersionDTO;
import com.mybeaker.app.labnote.model.LabNoteVersionModifyReqDTO;
import com.mybeaker.app.labnote.model.LabNoteVersionRegDTO;
import com.mybeaker.app.labnote.model.LaunchCompleteContDTO;
import com.mybeaker.app.labnote.model.PlantChangeReqDTO;
import com.mybeaker.app.labnote.model.PlantExtendDTO;
import com.mybeaker.app.labnote.model.PlantExtendReqDTO;
import com.mybeaker.app.labnote.model.ThisInventoryVO;
import com.mybeaker.app.makeup.model.InsertMuNoteHalfRegDTO;
import com.mybeaker.app.makeup.model.InsertMuNoteMayContainRegDTO;
import com.mybeaker.app.makeup.model.MakeupCounterDTO;
import com.mybeaker.app.makeup.model.MakeupNoteContDTO;
import com.mybeaker.app.makeup.model.MakeupNoteContHal4UsrInfoDTO;
import com.mybeaker.app.makeup.model.MakeupNoteInfoRegDTO;
import com.mybeaker.app.makeup.model.MakeupNoteRequestContDTO;
import com.mybeaker.app.makeup.model.MuLabNoteExperimentVO;
import com.mybeaker.app.makeup.model.MuNoteLotDTO;
import com.mybeaker.app.makeup.model.MuNoteMayContainInfoVO;
import com.mybeaker.app.makeup.model.MuNoteVersionDTO;
import com.mybeaker.app.skincare.model.BookmarkVO;
import com.mybeaker.app.skincare.model.LabNoteExperimentReqDTO;
import com.mybeaker.app.skincare.model.LabNoteHal4VO;
import com.mybeaker.app.skincare.model.LabNoteNonPrdVO;
import com.mybeaker.app.skincare.model.VersionContVO;

@Mapper
public interface MakeupNoteRequestMapper {

	int selectMuRequstListCount(LabNoteExperimentReqDTO schVO);

	List<MuLabNoteExperimentVO> selectMuRequstList(LabNoteExperimentReqDTO schVO);

	int selectHal4RequstListCount(LabNoteExperimentReqDTO schVO);

	List<LabNoteHal4VO> selectHal4RequstList(LabNoteExperimentReqDTO schVO);

	int selectNonPrdRequstListCount(LabNoteExperimentReqDTO schVO);

	List<LabNoteNonPrdVO> selectNonPrdRequstList(LabNoteExperimentReqDTO schVO);

	List<PlantExtendDTO> selectLabNoteContPlantInfoList(String vLabNoteCd, String vCodeType);

	List<VersionContVO> selectLabNotePlantExpansionList(String vLabNoteCd, String vCodeType, String vContCd);

	List<BookmarkVO> selectLabNotePlantExpansionBookmarkList(PlantExtendReqDTO plantExtendReqDTO);

	List<VersionContVO> selectLabNoteSavePlantList(String vLabNoteCd);

	int updatePlantAndSiteType(PlantChangeReqDTO plantChangeDTO);

	void updateCopyPrdCd(PlantChangeReqDTO plantChangeDTO);

	void updateFlagRepresentN(String vLabNoteCd);

	void updateFlagRepresentY(PlantChangeReqDTO plantChangeDTO);

	List<String> selectContList(String vLabNoteCd);

	int selectLabNoteChgLogListCount(ElabChgLogSearchReqDTO elabChgLogSearchReqDTO);

	List<ElabChgLogDTO> selectLabNoteChgLogList(ElabChgLogSearchReqDTO elabChgLogSearchReqDTO);

	List<LabNoteCommonTagDTO> selectLabNoteMstVerTagList(String tag1Cd, String vLabNoteCd, int nVersion,
			String localLanguage);

	List<LabNoteRequestPjtDTO> selectLabNotePjtList(String vLabNoteCd);

	String selectSubCodeBuffer2(String vMstCode, String vSubCode);

	String selectLabNoteFlagMassAppr(String vLabNoteCd);

	List<MakeupNoteContDTO> selectLabNoteDecideContInfoList(String vLabNoteCd, String vCodeType, String localLanguage);

	String checkFlagAllDecide(String vLabNoteCd);

	int insertLabNoteMst(MakeupNoteInfoRegDTO makeupNoteInfoRegDTO);

	void insertLabNotePjt(MakeupNoteInfoRegDTO makeupNoteInfoRegDTO);

	void insertLabNoteMstVer(LabNoteVersionRegDTO versionInfo);

	void insertLabNoteCont(MakeupNoteRequestContDTO makeupNoteRequestContDTO);

	void insertLabNoteVersion(LabNoteVersionRegDTO versionInfo);

	List<LabNoteCommonRequestMateDTO> selectLabNoteRequestMateListForRegister(
			LabNoteRequestMateRegDTO labNoteRequestMateRegDTO);

	void insertLabNoteMate(LabNoteCommonRequestMateDTO dto);

	void updateLabNoteMate(LabNoteCommonRequestMateDTO dto);

	int updateContFlagDevelopment(MakeupNoteRequestContDTO makeupNoteRequestContDTO);

	int updateLabNoteMst(MakeupNoteInfoRegDTO makeupNoteInfoRegDTO);

	void deleteLabNoteMstTag(MakeupNoteInfoRegDTO makeupNoteInfoRegDTO);

	void deleteLabNotePjt(String vLabNoteCd);

	void updateLabNoteMstVer(LabNoteVersionRegDTO versionInfo);

	void deleteLabNoteMstVerTag(LabNoteVersionRegDTO versionInfo);

	void insertHal4Mst(MakeupNoteRequestContDTO dto);

	void insertHal4MstVer(MakeupNoteRequestContDTO dto);

	void insertHal4Cont(MakeupNoteRequestContDTO dto);

	void insertHal4Version(MakeupNoteRequestContDTO dto);

	void insertElabContHal4Map(MakeupNoteRequestContDTO dto);

	void insertLabNoteMstVerTag(LabNoteVersionRegDTO versionInfo);

	void updateNoteContName(MakeupNoteRequestContDTO dto);

	void updateNoteContEtc(MakeupNoteRequestContDTO dto);

	void updateHal4Mst(MakeupNoteInfoRegDTO makeupNoteInfoRegDTO);

	void updateHal4Cont(MakeupNoteInfoRegDTO hal4dto);

	void deleteElabContHal4Map(String vHal4ContPkCd);

	String selectRepresentContPkCode(String vLabNoteCd);

	void deleteContAllMate(String vContPkCd, String vUpdateUserid);

	void updateContVerCounter(LabNoteVersionRegDTO versionInfo);

	LabNoteVersionDTO selectLabNoteCounterInfo(String vLabNoteCd, int nVersion);

	void deleteLabNoteMate(String vLabNoteCd, String vContPkCd, int nVersion, String vAddTypeCd);

	void insertLabNoteCounterRate(LabNoteVersionDTO dto);

	void insertSAPMaterialReq(MakeupNoteInfoRegDTO mstInfo);

	void updateSAPMaterialReqNameChange(MakeupNoteInfoRegDTO mstInfo);

	int updateLabNoteVerModify(LabNoteVersionModifyReqDTO labNoteVersionModifyReqDTO);

	void deleteLabNoteVerModifyMate(LabNoteCommonRequestMateDTO labNoteCommonRequestMateDTO);

	List<MakeupCounterDTO> selectLabNoteThisCounterList(String vLabNoteCd, String vContPkCd, String localLanguage);

	void updateLabNoteMstCopyNoteContNm(String vLabNoteCd);

	void updateLabNoteContCopyNoteContNm(String vLabNoteCd);

	List<MakeupNoteRequestContDTO> selectElabContHal4MapList(String vLabNoteCd, int nVersion);

	List<LabNoteCommonTagDTO> selectEvMaterialFunctionTagList(String vLabNoteCd, String localLanguage);

	List<LaunchCompleteContDTO> selectLabNoteVerLaunchCompleteContList(String vLabNoteCd, String vFlagCompleteModify);

	void updateLabNoteFinalCont(LaunchCompleteContDTO vo);

	List<MuNoteLotDTO> selectLabNoteAllLotList(String vLabNoteCd);

	List<MakeupNoteContDTO> selectLabNoteContInfoList(String vLabNoteCd);

	List<MuNoteVersionDTO> selectLabNoteAllVersionList(String vLabNoteCd);

	void insertVersionHistoryMst(LabNoteVersionModifyReqDTO labNoteVersionModifyReqDTO);

	void insertVersionHistoryMate(LabNoteVersionModifyReqDTO labNoteVersionModifyReqDTO);

	List<LabNoteCommonRequestMateDTO> selectProductVersionHistoryMateList(String vLabNoteCd, String vContPkCd,
			String localLanguage);

	int updateFlagNotAdd(MakeupNoteInfoRegDTO makeupNoteInfoRegDTO);

	void deleteNotAddMstTag(String vLabNoteCd);

	//반제품 4자[S]

	void insertOtherPrdNoteMst(InsertMuNoteHalfRegDTO regDTO);

	void insertOtherPrdNoteMstVer(InsertMuNoteHalfRegDTO regDTO);

	void insertOtherPrdNoteCont(InsertMuNoteHalfRegDTO regDTO);

	void insertOtherPrdNoteVersion(InsertMuNoteHalfRegDTO regDTO);

	public int updateOtherPrdNoteMst(InsertMuNoteHalfRegDTO regDTO);

	void updateOtherPrdNoteCont(InsertMuNoteHalfRegDTO regDTO);

	MakeupNoteContHal4UsrInfoDTO selectElabContHal4UserInfo(String vLabNoteCd, String language);

	//반제품 4자[E]
	public List<ThisInventoryVO> selectLabNoteThisInventoryList(String vLabNoteCd, String language);

	List<String> selectNoteCancelAlarmReceiveUserList(String vLabNoteCd, String vUserid);

	int updateELabNoteBrandAndPlant(InsertMuNoteHalfRegDTO regDTO);

	int updateELabNoteContInfo(InsertMuNoteHalfRegDTO regDTO);

	int selectMatrDbListCount(LabNoteExperimentReqDTO reqDTO);

	List<MuNoteMayContainInfoVO> selectMatrDbList(LabNoteExperimentReqDTO reqDTO);

	MuNoteMayContainInfoVO selectMuNoteMayContainMatrDbInfo(String vConcd);

	int insertMuNoteMayContainMatrDbSave(InsertMuNoteMayContainRegDTO regDTO);

	int updateMuNoteMayContainMatrDbSave(InsertMuNoteMayContainRegDTO regDTO);

	int deleteMuNoteMayContainMatrDbDel(String vConcd);

	int selectMatrDbSearchListCount(LabNoteExperimentReqDTO reqDTO);

	List<MuNoteMayContainInfoVO> selectMatrDbSearchList(LabNoteExperimentReqDTO reqDTO);
}
