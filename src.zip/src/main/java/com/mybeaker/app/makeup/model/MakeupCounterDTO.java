package com.mybeaker.app.makeup.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class MakeupCounterDTO {
	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("vLotNm")
	private String vLotNm;

	@JsonProperty("vVersionNm")
	private String vVersionNm;

	@JsonProperty("nVersion")
	private String nVersion;

	@JsonProperty("vStatusNm")
	private String vStatusNm;

	@JsonProperty("vInventoryCd")
	private String vInventoryCd;

	@JsonProperty("vInventoryNm")
	private String vInventoryNm;

	@JsonProperty("vInvenJoinCd")
	private String vInvenJoinCd;

	@JsonProperty("vSubmitInvenNm")
	private String vSubmitInvenNm;

	@JsonProperty("vInvenJoinPjtCd")
	private String vInvenJoinPjtCd;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vLabTypeCd")
	private String vLabTypeCd;

	@JsonProperty("vLabTypeNm")
	private String vLabTypeNm;
	
	@JsonProperty("vBrdNm")
	private String vBrdNm;
	
	@JsonProperty("vUsernm")
	private String vUsernm;
	
	@JsonProperty("vPilotDt")
	private String vPilotDt;
	
	@JsonProperty("vMassProdDt")
	private String vMassProdDt;
}
