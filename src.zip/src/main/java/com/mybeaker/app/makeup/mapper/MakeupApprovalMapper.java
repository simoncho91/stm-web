package com.mybeaker.app.makeup.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.mybeaker.app.labnote.model.LabNoteLotDTO;

@Mapper
public interface MakeupApprovalMapper {

	List<LabNoteLotDTO> selectLabNoteApprovalLotList(String vApprCd);
	
	int updateLabNoteLotApprCdClear(String vLotCd);
	
}
