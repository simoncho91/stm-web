package com.mybeaker.app.makeup.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URLEncoder;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mybeaker.app.labnote.model.BrandManagerShareDTO;
import com.mybeaker.app.labnote.model.ElabChgLogSearchReqDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonReqDevelopCancelDTO;
import com.mybeaker.app.labnote.model.LabNoteVersionModifyReqDTO;
import com.mybeaker.app.labnote.model.LaunchCompleteReqDTO;
import com.mybeaker.app.labnote.model.PlantChangeReqDTO;
import com.mybeaker.app.labnote.model.PlantExtendReqDTO;
import com.mybeaker.app.makeup.model.InsertMuNoteHalfRegDTO;
import com.mybeaker.app.makeup.model.InsertMuNoteMayContainRegDTO;
import com.mybeaker.app.makeup.model.MakeupNoteInfoRegDTO;
import com.mybeaker.app.makeup.model.MakeupNoteRequestContDTO;
import com.mybeaker.app.makeup.service.MakeupNoteRequestService;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.skincare.model.LabNoteExperimentReqDTO;
import com.mybeaker.app.utils.CommonUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Tag(name = "메이크업 내용물 등록 의뢰 api", description="메이크업 내용물 등록 의뢰 api")
@RestController
@RequestMapping("/api/makeup/request")
@RequiredArgsConstructor
public class MakeupNoteRequestController {
	private final MakeupNoteRequestService makeupNoteRequestService;

	@Operation(summary = "내용물 리스트", description = "내용물 리스트 조회. (화면ID : SC-PA-002)")
	@GetMapping("/select-req-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectReqList (
			LabNoteExperimentReqDTO reqDTO) {
		log.debug("MakeupNoteRequestController.selectReqList => params : { LabNoteExperimentReqDTO: {} }", reqDTO.toString());
		return ResponseEntity.ok(makeupNoteRequestService.selectReqList(reqDTO));
	}

	@Operation(summary = "내용물 등록 의뢰", description = "내용물 등록 의뢰 조회.")
	@GetMapping("/select-req-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectReqInfo (
			@RequestParam(value="vLabNoteCd", defaultValue = "") String vLabNoteCd,
			@RequestParam(value="vPageFlag", defaultValue = "REG") String vPageFlag
			) {

		log.debug("MakeupNoteRequestController.selectReqInfo => params : { vLabNoteCd: {}, vPageFlag: {} }", vLabNoteCd, vPageFlag);

		return ResponseEntity.ok(makeupNoteRequestService.selectReqInfo(vLabNoteCd, vPageFlag));
	}

	@Operation(summary = "내용물 등록 의뢰 - 버전 정보", description = "내용물 등록 의뢰 - 버전 정보를 조회한다.")
	@GetMapping("/select-lab-note-mst-ver-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteMstVerInfo (
			@RequestParam(value="vLabNoteCd") String vLabNoteCd,
			@RequestParam(value="nVersion", defaultValue = "0") int nVersion
			) {
		log.debug("MakeupNoteRequestController.selectLabNoteMstVerInfo => params : { vLabNoteCd: {}, nVersion: {} }", vLabNoteCd, nVersion);

		ResponseVO responseVO = new ResponseVO();
		responseVO.setOk(makeupNoteRequestService.selectLabNoteMstVerInfo(vLabNoteCd, nVersion));
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "개발 취소", description = "실험노트 개발 취소 상태 변경, 의견 저장")
	@PostMapping("/update-elab-note-cancel-info")
	public @ResponseBody ResponseEntity<ResponseVO> updateElabNoteCancelInfo (
			@RequestBody LabNoteCommonReqDevelopCancelDTO labNoteCommonReqDevelopCancelDTO
			) {
		log.debug("MakeupNoteRequestController.updateElabNoteCancelInfo => labNoteCommonReqDevelopCancelDTO : {}", labNoteCommonReqDevelopCancelDTO);

		return ResponseEntity.ok(makeupNoteRequestService.updateElabNoteCancelInfo(labNoteCommonReqDevelopCancelDTO));
	}

	@Operation(summary = "개발 재개", description = "실험노트 개발 재개")
	@PostMapping("/update-elab-note-restart")
	public @ResponseBody ResponseEntity<ResponseVO> updateElabNoteRestart (
			@RequestBody LabNoteCommonReqDevelopCancelDTO labNoteCommonReqDevelopCancelDTO
			) {
		log.debug("MakeupNoteRequestController.updateElabNoteRestart => labNoteCommonReqDevelopCancelDTO : {}", labNoteCommonReqDevelopCancelDTO);

		return ResponseEntity.ok(makeupNoteRequestService.updateElabNoteRestart(labNoteCommonReqDevelopCancelDTO));
	}

	@Operation(summary = "제품 내용물 등록 의뢰", description = "제품 내용물 등록 의뢰 저장")
	@PostMapping("/save-lab-note-prd-request")
	public @ResponseBody ResponseEntity<ResponseVO> saveLabNotePrdRequest (
			@RequestBody MakeupNoteInfoRegDTO makeupNoteInfoRegDTO
			) {
		log.debug("MakeupNoteRequestController.saveLabNoteRequest => makeupNoteInfoRegDTO : {}", makeupNoteInfoRegDTO);

		return ResponseEntity.ok(makeupNoteRequestService.saveLabNotePrdRequest(makeupNoteInfoRegDTO));
	}

	@Operation(summary = "플랜트 확장 - 내용물 플랜트 정보 리스트 조회", description = "플랜트 확장 - 내용물 플랜트 정보 리스트를 조회한다.")
	@GetMapping("/select-lab-note-cont-plant-info-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteContPlantInfoList (
			@RequestParam(value="vLabNoteCd") String vLabNoteCd,
			@RequestParam(value="vCodeType") String vCodeType
			) {
		log.debug("MakeupNoteRequestController.selectLabNoteContPlantInfoList => params : { vLabNoteCd : {}, vCodeType : {} }", vLabNoteCd, vCodeType);

		return ResponseEntity.ok(makeupNoteRequestService.selectLabNoteContPlantInfoList(vLabNoteCd, vCodeType));
	}

	@Operation(summary = "플랜트 확장 저장", description = "플랜트 확장 내용을 저장한다.")
	@PostMapping("/insert-lab-note-plant-expansion")
	public @ResponseBody ResponseEntity<ResponseVO> insertLabNotePlantExpansion(
			@RequestBody PlantExtendReqDTO plantExtendReqDTO
			) {
		log.debug("MakeupNoteRequestController.insertLabNotePlantExpansion => plantExtendReqDTO : {}", plantExtendReqDTO);

		return ResponseEntity.ok(makeupNoteRequestService.insertLabNotePlantExpansion(plantExtendReqDTO));
	}

	@Operation(summary = "대표 플랜트 변경 - 저장 플랜트 조회", description = "대표 플랜트 변경 - 저장된 플랜트를 조회한다.")
	@GetMapping("/select-lab-note-save-plant-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteSavePlantList (
			@RequestParam(value="vLabNoteCd") String vLabNoteCd
			) {
		log.debug("MakeupNoteRequestController.selectLabNoteSavePlantList => params : { vLabNoteCd : {} }", vLabNoteCd);

		return ResponseEntity.ok(makeupNoteRequestService.selectLabNoteSavePlantList(vLabNoteCd));
	}

	@Operation(summary = "대표 플랜트 변경", description = "대표 플랜트를 업데이트한다.")
	@PostMapping("/update-plant-and-site-type")
	public @ResponseBody ResponseEntity<ResponseVO> updatePlantAndSiteType (
			@RequestBody PlantChangeReqDTO plantChangeReqDTO
			) {
		log.debug("MakeupNoteRequestController.updatePlantAndSiteType => plantChangeReqDTO : {}", plantChangeReqDTO);

		return ResponseEntity.ok(makeupNoteRequestService.updatePlantAndSiteType(plantChangeReqDTO));
	}

	@Operation(summary = "변경 이력 조회", description = "변경 이력을 조회한다.")
	@GetMapping("/select-lab-note-chg-log-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteChgLogList (
			ElabChgLogSearchReqDTO elabChgLogSearchReqDTO
			) {
		log.debug("MakeupNoteRequestController.selectLabNoteChgLogList => elabChgLogSearchReqDTO : {}", elabChgLogSearchReqDTO);

		return ResponseEntity.ok(makeupNoteRequestService.selectLabNoteChgLogList(elabChgLogSearchReqDTO));
	}

	@Operation(summary = "내용물 개발취소, 재개", description = "메이크업 내용물의 개발 취소 / 재개 처리를 한다.")
	@PostMapping("/update-cont-flag-development")
	public @ResponseBody ResponseEntity<ResponseVO> updateContFlagDevelopment (
			@RequestBody MakeupNoteRequestContDTO makeupNoteRequestContDTO
			) {
		log.debug("MakeupNoteRequestController.updateContFlagDevelopment => makeupNoteRequestContDTO : {}", makeupNoteRequestContDTO);

		return ResponseEntity.ok(makeupNoteRequestService.updateContFlagDevelopment(makeupNoteRequestContDTO));
	}

	@Operation(summary = "버전 정보 수정", description = "버전 정보를 수정한다.")
	@PostMapping("/update-lab-note-version-info")
	public @ResponseBody ResponseEntity<ResponseVO> updateLabNoteVersionInfo (
			@RequestBody LabNoteVersionModifyReqDTO labNoteVersionModifyReqDTO
			) {
		log.debug("MakeupNoteRequestController.updateLabNoteVersionInfo => labNoteVersionModifyReqDTO : {}", labNoteVersionModifyReqDTO);

		return ResponseEntity.ok(makeupNoteRequestService.updateLabNoteVersionInfo(labNoteVersionModifyReqDTO));
	}

	@Operation(summary = "출시완료 처리 정보 조회", description = "출시완료 처리를 위한 정보를 조회한다.")
	@GetMapping("/select-lab-note-ver-launch-complete-cont-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteVerLaunchCompleteContList (
			@RequestParam(value="vLabNoteCd") String vLabNoteCd,
			@RequestParam(value="vFlagCompleteModify") String vFlagCompleteModify
			) {
		log.debug("MakeupNoteRequestController.selectReleaseCompleteInfo => vLabNoteCd : {}", vLabNoteCd);

		return ResponseEntity.ok(makeupNoteRequestService.selectLabNoteVerLaunchCompleteContList(vLabNoteCd, vFlagCompleteModify));
	}

	@Operation(summary = "출시완료일 변경", description = "출시완료일을 일괄 변경한다.")
	@PostMapping("/save-launch-complete")
	public @ResponseBody ResponseEntity<ResponseVO> saveLaunchComplete (
			@RequestBody LaunchCompleteReqDTO launchCompleteDTO
			) {
		log.debug("MakeupNoteRequestController.saveLaunchComplete => launchCompleteDTO : {}", launchCompleteDTO);

		return ResponseEntity.ok(makeupNoteRequestService.saveLaunchComplete(launchCompleteDTO));
	}

	@Operation(summary = "이슈 트래커 실험노트 기본 정보 조회", description = "이슈 트래커 실험노트 기본 정보 조회")
	@GetMapping("/select-issue-tracker-note-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectIssueTrackerNoteInfo (
			@RequestParam(value="vLabNoteCd") String vLabNoteCd
			) {
		log.debug("MakeupNoteRequestController.selectIssueTrackerNoteInfo => params : { vLabNoteCd : {} }", vLabNoteCd);
		return ResponseEntity.ok(makeupNoteRequestService.selectIssueTrackerNoteInfo(vLabNoteCd));
	}

	@Operation(summary = "Product 변경이력 조회", description = "Product 변경이력을 조회한다.")
	@GetMapping("/select-product-version-history-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectProductVersionHistoryList (
			@RequestParam(value="vLabNoteCd") String vLabNoteCd,
			@RequestParam(value="vContPkCd") String vContPkCd
			) {
		log.debug("MakeupNoteRequestController.selectProductVersionHistoryList => params : { vLabNoteCd : {}, vContPkCd : {} }", vLabNoteCd, vContPkCd);
		return ResponseEntity.ok(makeupNoteRequestService.selectProductVersionHistoryList(vLabNoteCd, vContPkCd));
	}

	@Operation(summary = "무소구 수정", description = "무소구 정보를 수정한다.")
	@PostMapping("/update-not-add-ingredient-info")
	public @ResponseBody ResponseEntity<ResponseVO> updateNotAddIngredientInfo (
			@RequestBody MakeupNoteInfoRegDTO makeupNoteInfoRegDTO
			) {
		log.debug("MakeupNoteRequestController.updateNotAddIngredientInfo => makeupNoteInfoRegDTO : {}", makeupNoteInfoRegDTO);
		return ResponseEntity.ok(makeupNoteRequestService.updateNotAddIngredientInfo(makeupNoteInfoRegDTO));
	}

	@Operation(summary = "마케터 공유하기 메일 발송", description = "마케터에게 공유, 내용 수정 요청")
	@PostMapping("/send-marketer-share-mail")
	public @ResponseBody ResponseEntity<ResponseVO> sendMarketerShareMail (
			@RequestBody BrandManagerShareDTO brandManagerShareDTO
			) {
		log.debug("MakeupNoteRequestController.sendMarketerShareMail => brandManagerShareDTO : {}", brandManagerShareDTO);
		return ResponseEntity.ok(makeupNoteRequestService.sendMarketerShareMail(brandManagerShareDTO));
	}

	// 반제품 [S]
	//
	@Operation(summary = "반제품 내용물 개요 상세", description = "반제품 내용물 개요 상세 정보. (화면ID : SC-PA-050)")
	@GetMapping("/select-halfreq-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectHalfReqInfo (
			@RequestParam(value="vLabNoteCd", defaultValue = "") String vLabNoteCd
			) {
		log.debug("MakeupNoteRequestController.selectHalfReqInfo => params : { vLabNoteCd: {} }", vLabNoteCd);
		
		return ResponseEntity.ok(makeupNoteRequestService.selectHalfReqInfo(vLabNoteCd));
	}

//	/elab/common/lab_request_save
	@Operation(summary = "반제품, 과제 저장", description = "반제품, 과제 저장한다.")
	@PostMapping("/save-lab-request-info")
	public @ResponseBody ResponseEntity<ResponseVO> insertElabNoteRequestInfo (
			@RequestBody InsertMuNoteHalfRegDTO regDTO) {
		log.debug("insert-elab-note-request-infoStart!");
		log.debug("InsertLabNoteHalfRegDTO : {}", regDTO.toString());
		
		return ResponseEntity.ok(makeupNoteRequestService.insertElabNoteRequestInfo(regDTO));
	}
	//
	//반제품 [E]

	@Operation(summary = "과제 내용물 개요 상세", description = "과제 내용물 개요 상세 정보. (화면ID : SC-PA-065)")
	@GetMapping("/select-nonreq-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectNonReqInfo (
			@RequestParam(value="vLabNoteCd", defaultValue = "") String vLabNoteCd
			) {
		log.debug("MakeupNoteRequestController.selectNonReqInfo => params : { vLabNoteCd: {} }", vLabNoteCd);

		return ResponseEntity.ok(makeupNoteRequestService.selectNonReqInfo(vLabNoteCd));
	}
	
	@Operation(summary = "May Contain 원료DB 리스트", description = "May Contain 원료DB 리스트 조회. (화면ID : MU-PA-058)")
	@GetMapping("/select-may-contain-matr-db-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectMayContainMatrDbList (
			LabNoteExperimentReqDTO reqDTO) {
		log.debug("MakeupNoteRequestController.selectMayContainMatrDbList => params : { LabNoteExperimentReqDTO: {} }", reqDTO.toString());
		return ResponseEntity.ok(makeupNoteRequestService.selectMayContainMatrDbList(reqDTO));
	}
	
	@Operation(summary = "May Contain 원료DB 리스트 엑셀다운", description = "May Contain 원료DB 리스트 엑셀다운")
	@GetMapping("/select-may-contain-matr-db-list-excel")
//	local 환경에서 작업시 주석해제 및 WebMvcConfig 의 allowedOrigins("*") 주석해제 후 사용. 작업 후 다시 주석처리 요망.
//	@CrossOrigin(value= {"*"}, exposedHeaders = { HttpHeaders.CONTENT_DISPOSITION, "filename" })
	public @ResponseBody ResponseEntity<byte[]> selectMayContainMatrDbListExcel (LabNoteExperimentReqDTO reqDTO){
		log.debug("MakeupNoteRequestController.selectMayContainMatrDbListExcel => reqDTO : {}", reqDTO);
		HttpHeaders headers = new HttpHeaders();
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		HSSFWorkbook wb = null;

		try {
			String excelFileName = new StringBuilder()
					.append("May Contain 원료 DB 목록_")
					.append(CommonUtil.getNowDate("yyyyMMdd"))
					.toString();

			// 파일명에 들어갈 수 없는 특수문자를 제거합니다.
			excelFileName = CommonUtil.convertFileName(excelFileName);
			excelFileName = URLEncoder.encode(excelFileName , "UTF-8").replaceAll("\\+", "%20");

			wb = makeupNoteRequestService.selectMayContainMatrDbListExcel(reqDTO);
			try {
				wb.write(os);
				os.close();
			} catch (IOException e) {
				log.error("selectMayContainMatrDbListExcel : {} " + e);
			}

			headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.ms-excel");
			headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + excelFileName + ".xls");
			headers.add("filename", excelFileName+ ".xls");
			headers.add("Content-Transfer-Encoding", "binary");

		}catch(Exception e) {
			log.error("Error : ", e);
		}

		return ResponseEntity.ok()
				.contentLength(os.toByteArray().length)
				.contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
				.headers(headers)
				.body(os.toByteArray());
	}
	
	@Operation(summary = "May Contain 원료DB 상세", description = "May Contain 원료DB 상세 조회. (화면ID : MU-PA-059)")
	@GetMapping("/select-may-contain-matr-db-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectMayContainMatrDbInfo (
			@RequestParam(value="vConcd", defaultValue = "") String vConcd
			) {
		log.debug("MakeupNoteRequestController.selectMayContainMatrDbInfo");
		return ResponseEntity.ok(makeupNoteRequestService.selectMayContainMatrDbInfo(vConcd));
	}
	
	@Operation(summary = "May Contain 원료DB 저장", description = "May Contain 원료DB 저장")
	@PostMapping("/save-may-contain-matr-db-info")
	public @ResponseBody ResponseEntity<ResponseVO> saveMayContainMatrDbInfo (
			@RequestBody InsertMuNoteMayContainRegDTO regDTO
			) {
		log.debug("MakeupNoteRequestController.saveMayContainMatrDbInfo => regDTO : {}", regDTO);
		return ResponseEntity.ok(makeupNoteRequestService.saveMayContainMatrDbInfo(regDTO));
	}
	
	@Operation(summary = "May Contain 원료DB 성분코드 삭제", description = "May Contain 원료DB 성분코드 삭제")
	@PostMapping("/delete-may-contain-matr-db-info")
	public @ResponseBody ResponseEntity<ResponseVO> deleteMayContainMatrDbInfo (
			@RequestBody InsertMuNoteMayContainRegDTO regDTO
			) {
		log.debug("MakeupNoteRequestController.deleteMayContainMatrDbInfo => regDTO : {}", regDTO);
		return ResponseEntity.ok(makeupNoteRequestService.deleteMayContainMatrDbInfo(regDTO));
	}
	
	@Operation(summary = "May Contain 원료DB 성분검색 리스트", description = "May Contain 원료DB 성분검색 리스트 조회")
	@GetMapping("/select-matr-db-search-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectMatrDbSearchList (
			LabNoteExperimentReqDTO reqDTO) {
		log.debug("MakeupNoteRequestController.selectMatrDbSearchList => params : { LabNoteExperimentReqDTO: {} }", reqDTO.toString());
		return ResponseEntity.ok(makeupNoteRequestService.selectMatrDbSearchList(reqDTO));
	}
}
