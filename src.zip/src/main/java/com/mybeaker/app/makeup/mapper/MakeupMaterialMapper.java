package com.mybeaker.app.makeup.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.mybeaker.app.common.model.CodeDTO;
import com.mybeaker.app.labnote.model.ElabHisPreRateVO;
import com.mybeaker.app.labnote.model.ElabStats01VO;
import com.mybeaker.app.labnote.model.ElabStats02VO;
import com.mybeaker.app.labnote.model.ElabStats03VO;
import com.mybeaker.app.labnote.model.MusoguInfoVO;
import com.mybeaker.app.labnote.model.MusoguRateVO;
import com.mybeaker.app.labnote.model.MusoguReqDTO;
import com.mybeaker.app.makeup.model.MuLabNoteInfoVO;
import com.mybeaker.app.makeup.model.MuMaterialNotePlantVO;
import com.mybeaker.app.makeup.model.MuMaterialSaveRegDTO;
import com.mybeaker.app.makeup.model.MuNoteContVO;
import com.mybeaker.app.makeup.model.MuNoteGramTrVO;
import com.mybeaker.app.makeup.model.MuNoteGramVO;
import com.mybeaker.app.makeup.model.MuNoteGroupVO;
import com.mybeaker.app.makeup.model.MuNoteLotExpoureYVO;
import com.mybeaker.app.makeup.model.MuNoteLotVO;
import com.mybeaker.app.makeup.model.MuNoteMateVO;
import com.mybeaker.app.makeup.model.MuNoteMemoVO;
import com.mybeaker.app.makeup.model.MuNoteMstVO;
import com.mybeaker.app.makeup.model.MuNoteMstVerTagVO;
import com.mybeaker.app.makeup.model.MuNoteMstVerVO;
import com.mybeaker.app.makeup.model.MuNoteRateVO;
import com.mybeaker.app.makeup.model.MuNoteStabilityTitleVO;
import com.mybeaker.app.makeup.model.MuNoteStabilityValueVO;
import com.mybeaker.app.makeup.model.MuNoteVersionVO;
import com.mybeaker.app.skincare.model.BomReqDTO;
import com.mybeaker.app.skincare.model.BookmarkApplyVO;
import com.mybeaker.app.skincare.model.BookmarkReqDTO;
import com.mybeaker.app.skincare.model.BookmarkVO;
import com.mybeaker.app.skincare.model.CounterSAPRegDTO;
import com.mybeaker.app.skincare.model.ElabLotMemoVO;
import com.mybeaker.app.skincare.model.GramReqDTO;
import com.mybeaker.app.skincare.model.GramTrPlanVO;
import com.mybeaker.app.skincare.model.IngredientDataVO;
import com.mybeaker.app.skincare.model.IngredientExistsConcdVO;
import com.mybeaker.app.skincare.model.IngredientMateVO;
import com.mybeaker.app.skincare.model.IngredientReqDTO;
import com.mybeaker.app.skincare.model.IngredientVO;
import com.mybeaker.app.skincare.model.MaterialGradeSumVO;
import com.mybeaker.app.skincare.model.MaterialLotVO;
import com.mybeaker.app.skincare.model.MaterialMateRateVO;
import com.mybeaker.app.skincare.model.MaterialMateSumVO;
import com.mybeaker.app.skincare.model.MaterialMateVO;
import com.mybeaker.app.skincare.model.MaterialNoteContVO;
import com.mybeaker.app.skincare.model.MaterialNoteVersionVO;
import com.mybeaker.app.skincare.model.MaterialNumberVO;
import com.mybeaker.app.skincare.model.MaterialQrInfoVO;
import com.mybeaker.app.skincare.model.MaterialSearchVO;
import com.mybeaker.app.skincare.model.MaterialVersionRegDTO;
import com.mybeaker.app.skincare.model.MemoReqDTO;
import com.mybeaker.app.skincare.model.PlantRatePriceReqVO;
import com.mybeaker.app.skincare.model.PlantRatePriceVO;
import com.mybeaker.app.skincare.model.ScmTCodeRegDTO;
import com.mybeaker.app.skincare.model.StabilityTitleVO;
import com.mybeaker.app.skincare.model.SubMateReqDTO;
import com.mybeaker.app.skincare.model.SubMateVO;
import com.mybeaker.app.skincare.model.VersionContVO;
import com.mybeaker.app.skincare.model.VersionReqDTO;

@Mapper
public interface MakeupMaterialMapper {

	public MaterialQrInfoVO selectElabNoteInfoVerLotCd(MaterialQrInfoVO materialQrInfoVO);
	
	public MuLabNoteInfoVO selectElabContHal4UserInfo(MuLabNoteInfoVO materialLabNoteInfoVO);
	
	public List<MuMaterialNotePlantVO> selectLabNoteContOrPlantList(MaterialSearchVO materialSearchVO);
	
	public MaterialNoteContVO selectLabNoteContInfo(MaterialSearchVO materialSearchVO);
	
	public List<MaterialNoteVersionVO> selectLabNoteVersion(MaterialSearchVO materialSearchVO);
	
	public String selectLabNoteCheckVersion(MaterialSearchVO materialSearchVO);
	
	public List<MaterialLotVO> selectLabNoteLotGramList(MaterialSearchVO materialSearchVO);
	
	public String selectLabNoteExistsLotExposure(MaterialSearchVO materialSearchVO);
	
	public int selectHal4MateDenominator(MaterialSearchVO materialSearchVO);
	
	public List<MaterialNumberVO> selectHal4MateNumerator(MaterialSearchVO materialSearchVO);
	
	public List<MaterialMateRateVO> selectLabNoteMateRateMap(MaterialSearchVO materialSearchVO);
	
	public List<MaterialMateSumVO> selectLabNoteMatePriceSum(MaterialSearchVO materialSearchVO);
	
	public int deleteLabNoteGroup(MuNoteGroupVO muNoteGroupVO);
	
	public int insertLabNoteGroup(MuNoteGroupVO muNoteGroupVO);
	
	public int updateLabNoteGroup(MuNoteGroupVO muNoteGroupVO);
	
	public int insertLabNoteMate(MuNoteMateVO muNoteMateVO);
	
	public int updateLabNoteMate(MuNoteMateVO muNoteMateVO);
	
	public List<MuNoteLotVO> selectElabNoteLotList(MuMaterialSaveRegDTO regDTO);
	
	public int insertLabNoteLot(MuNoteLotVO muNoteLotVO);
	
	public int updateLabNoteLot(MuNoteLotVO muNoteLotVO);
	
	public int insertLabNoteGram(MuNoteGramVO muNoteGramVO);
	
	public int updateLabNoteGram(MuNoteGramVO muNoteGramVO);
	
	public int insertLabNoteRate(MuNoteRateVO muNoteRateVO);
	
	public int insertELabHisPreRate(ElabHisPreRateVO elabHisPreRateVO);
	
	public int updateLabNoteAllLotExposureN(MuNoteLotVO muNoteLotVO);
	
	public int updateLabNoteLotExposureY(MuNoteLotExpoureYVO muNoteLotExpoureYVO);
	
	public int updateLabNoteVersion(MuNoteVersionVO muNoteVersionVO);
	
	public int updateStatusCd_LNC06_22(MuNoteMstVO muNoteMstVO);
	
	public int updateStatusCd_LNC06_31(MuNoteMstVO muNoteMstVO);
	
	public int updateLabNoteMateCheckSharing(MuNoteMateVO muNoteMateVO);
	
	public int updateLabNoteCheckNewVersion(MuNoteVersionVO muNoteVersionVO);
	
	public String selectLabNoteFlagAllLaunchComplete(String vLabNoteCd);
	
	public int updateLabNoteStats01(ElabStats01VO elabStats01VO);
	
	public int updateLabNoteStats02(ElabStats02VO elabStats02VO);
	
	public int updateLabNoteStats03(ElabStats03VO elabStats03VO);
	
	public int deleteFinalVersionToLot(MuNoteLotVO muNoteLotVO);
	
	public int deleteFinalVersion(MuNoteVersionVO muNoteVersionVO);
	
	public int updateLabNoteResetHistory(MaterialVersionRegDTO regDTO);
	
	public int selectLabNoteMstLastVersion(MaterialVersionRegDTO regDTO);
	
	public int insertLabNoteMstNewVersion(MuNoteMstVerVO muNoteMstVerVO);
	
	public int insertLabNoteNewVersion(MuNoteVersionVO muNoteVersionVO);
	
	public int insertLabNotePreMstVerTag(MuNoteMstVerTagVO muNoteMstVerTagVO);
	
	public int insertLabNotePreVerMate(MuNoteMateVO muNoteMateVO);
	
	public int updateLabNoteLotFlagDecideN(String vLabNoteCd);
	
	public int updateLabNoteResCostReset(String vLabNoteCd);
	
	public int updateLabNoteContReset(MuNoteContVO muNoteContVO);
	
	public int updateLabNoteVersionReset(String vLabNoteCd);
	
	public List<String> selectLabNoteCompleteDtList(List<String> labNoteCdList);
	
	public int procElabSustainabilityStatsPr(String vDt);
	
	public int updateLabNoteLotBookmark(String vLotCd);

	public int deleteLabNoteLotBookmark(String vLotCd);
	
	public int updateLabNoteApplyMstPlant(MuNoteMstVO muNoteMstVO);
	
	public int updateLabNoteApplyContPlant(MuNoteContVO muNoteContVO);
	
	public int updateLabNoteLotBaseN(MuNoteContVO muNoteContVO);
	
	public int updateLabNoteLotBase(MuNoteLotVO muNoteLotVO);
	
	public int updateLabNoteTestResLot(MuNoteLotVO muNoteLotVO);
	
	public int insertLabNoteGramTr(MuNoteGramTrVO muNoteLotVO);
	
	public int updateLabNoteGramTr(MuNoteGramTrVO muNoteLotVO);
	
	public int deleteLabNoteGramTr(MuNoteGramTrVO muNoteLotVO);
	
	public int insertLabNoteStabilityValue(MuNoteStabilityValueVO muNoteStabilityValueVO);
	
	public List<MuNoteGramTrVO> selectLabNoteGramTrList(String vGramCd);

	public List<MuNoteContVO> selectCheckSubPlantList(MuNoteContVO muNoteContVO);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public List<MaterialGradeSumVO> selectLabNoteMateGradeSum(MaterialGradeSumVO materialGradeSumVO);
	
	public List<MaterialGradeSumVO> selectLabNoteMateGradeLotSum(MaterialGradeSumVO materialGradeSumVO);
	
	public List<SubMateVO> selectLabNoteSubMateRateInfoVerNotNote(SubMateReqDTO reqDTO);
	
	public String selectLabNoteLotState(SubMateReqDTO reqDTO);
	
	public List<SubMateVO> selectLabNoteSubMateRateInfo(SubMateReqDTO reqDTO);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//	POPUP - 처방 불러오기
	public int selectLabNoteBookmarkListCount(BookmarkReqDTO bookmarkReqDTO);
	
	public List<BookmarkVO> selectLabNoteBookmarkList(BookmarkReqDTO reqDTO);
	
	public List<String> selectLabNoteMatePlantCheck(BookmarkReqDTO reqDTO);
	
	public List<BookmarkApplyVO> selectLabNoteBookmarkApplyList(BookmarkReqDTO reqDTO);
	
	public String selectLabNoteExistsContInfo(CounterSAPRegDTO regDTO);
	
	public String selectZqmtExistsMatnrInfo(CounterSAPRegDTO regDTO);
	
	public int insertLabNoteMstCounterSAPInfo(MuNoteMstVO muNoteMstVO);
	
	public int insertLabNoteMstVerCounterSAPInfo(MuNoteMstVerVO muNoteMstVerVO);
	
	public String selectZqmtContNm(MuNoteContVO muNoteContVO);
	
	public int insertLabNoteContCounterSAPInfo(MuNoteContVO muNoteContVO);
	
	public int insertLabNoteVersionCounterSAPInfo(MuNoteVersionVO muNoteVersionVO);
	
	public int insertLabNoteFinalVersion(MuNoteVersionVO muNoteVersionVO);
	
	public int insertLabNoteFinalLot(MuNoteLotVO muNoteLotVO);
	
//	POPUP - 버전관리
//	getLabNoteContOrPlantList - reqVo.put("i_sSearchType", "CONT");
	public List<VersionContVO> selectLabNoteContList(VersionReqDTO reqDTO);
	
	public int updateVersionView(MuNoteVersionVO muNoteVersionVO);
	
	public int updateLotAddType(MuNoteMstVO muNoteMstVO);
	
//	POPUP - 무소구가능항목
	public MusoguInfoVO selectMusoguInfo(MusoguReqDTO reqDTO);
	
	public List<CodeDTO> selectMusoguList(MusoguInfoVO musoguInfoVO);
	
	public List<MusoguRateVO> selectMusoguRate(MusoguReqDTO reqDTO);
	
	public List<CodeDTO> selectLabNoteTagListAll(MusoguReqDTO reqDTO);
	
	public List<String> selectLabNoteMusoguGroup();
	
//	POPUP - 글로벌금지
	public int updateLabNoteMateCheck(ScmTCodeRegDTO regDTO);
	
//	POPUP - 플랜트 단가
	public MuNoteLotVO selectLabNoteLot(PlantRatePriceReqVO reqVO);
	
	public List<MuNoteLotVO> selectLabNoteLotList(MuNoteLotVO muNoteLotVO);
	
	public List<MuNoteMateVO> selectLabNoteMateList(PlantRatePriceReqVO reqDTO);
	
	public List<PlantRatePriceVO> selectLabNoteAllPlantRateAndPriceMap(PlantRatePriceReqVO reqDTO);
	
//	POPUP - BOM 임시전송
	public List<MuNoteLotVO> selectLabNoteBomLotList(BomReqDTO reqDTO);
	
//	POPUP - 실험결과
	public int updateLabNoteGramDt(MuNoteGramVO muNoteGramVO);
	
	public List<StabilityTitleVO> selectLabNoteStabilityTitleList(GramReqDTO reqDTO);
	
	public List<StabilityTitleVO> selectLabNoteStabilityDefaultTitleList(String vLabNoteCd);
	
	public List<MuNoteStabilityValueVO> selectLabNoteStabilityValueListMap(GramReqDTO reqDTO);
	
	public MuNoteGramVO selectLabNoteGram(GramReqDTO reqDTO);
	
	public List<MuNoteGramVO> selectLabNoteGramList(GramReqDTO reqDTO);
	
	public List<GramTrPlanVO> selectLabNoteGramTrPlanList(GramReqDTO reqDTO);
	
//	POPUP - 전성분
	public IngredientDataVO selectLabNoteDefaultIngredientData(IngredientReqDTO reqDTO);
	
	public List<IngredientExistsConcdVO> selectLabNoteNotExistsConcdList(IngredientReqDTO reqDTO);
	
	public String selectFlagZplmt74(String vMatnr);
	
	public List<IngredientVO> selectLabNoteIngredientVerAllergenListMap(IngredientVO ingredientVO);
	
	public List<IngredientVO> selectLabNoteIngredientListMap(IngredientVO ingredientVO);
	
	public List<IngredientMateVO> selectLabNoteIngredientMateInfoList(IngredientMateVO ingredientMateVO);
	
//	POPUP - 안정도 설정
	public List<StabilityTitleVO> selectLabNoteStabilityTitleAllList();
	
	public int insertLabNoteStabilityTitle(MuNoteStabilityTitleVO muNoteStabilityTitleVO);
	
	public int deleteLabNoteStabilityTitle(MuNoteStabilityTitleVO muNoteStabilityTitleVO);
	
//	POPUP - 메모
	public int selectLabNoteMemoListCount(MemoReqDTO reqDTO);
	
	public List<MuNoteMemoVO> selectLabNoteMemoList(MemoReqDTO reqDTO);
	
	public MuNoteMemoVO selectLabNoteMemo(MemoReqDTO reqDTO);
	
	public int insertLabNoteMemo(MuNoteMemoVO muNoteMemoVO);
	
	public int updateLabNoteMemo(MuNoteMemoVO muNoteMemoVO);
	
	public int deleteLabNoteMemo(MuNoteMemoVO muNoteMemoVO);

//	Lot Side
	public List<ElabLotMemoVO> selectElabLotMemoList(String vLotCd);

//	순서 바꾸기
	public List<MaterialMateVO> selectLabNoteMateAndGrpSimpleList(String vContPkCd, int nVersion);

	public int updateLabNoteOrderGroup(MuNoteGroupVO muNoteGroupVO);
	
	public int updateLabNoteOrderMate(MuNoteMateVO muNoteMateVO);
	
//	Excel Upload
	public int deleteLabNoteExcelGroup(MuNoteGroupVO muNoteGroupVO);
	
	public int deleteLabNoteExcelMate(MuNoteMateVO muNoteMateVO);
	
	public int deleteLabNoteExcelGram(MuNoteLotVO muNoteLotVO);
	
	public int deleteLabNoteExcelLot(MuNoteLotVO muNoteLotVO);
	
	public int selectLabNoteExcelLotCnt(MuNoteLotVO muNoteLotVO);
	
//	조색설정
	public int updateLabNoteToning(MuNoteMstVO muNoteMstVO);
}
