package com.mybeaker.app.makeup.model;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class MaterialLotBaseRegDTO {

	@NotEmpty
	@JsonProperty("vContPkCd")
	private String vContPkCd;
	
	@NotEmpty
	@JsonProperty("vLotCd")
	private String vLotCd;
}
