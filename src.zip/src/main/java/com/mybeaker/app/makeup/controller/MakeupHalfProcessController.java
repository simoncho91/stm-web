package com.mybeaker.app.makeup.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mybeaker.app.labnote.model.BomApprovalReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessPqcCheckApprReqDTO;
import com.mybeaker.app.labnote.model.PilotRequestDetailReqDTO;
import com.mybeaker.app.labnote.model.PilotRequestRegInfoReqDTO;
import com.mybeaker.app.labnote.model.PilotRequestReqDTO;
import com.mybeaker.app.makeup.service.MakeupHalfProcessService;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.skincare.model.LotPilotRegDTO;
import com.mybeaker.app.skincare.model.SkincareDecideRegDTO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Tag(name = "메이크업 반제품 실험노트 프로세스", description="메이크업 반제품 실험노트 프로세스")
@RestController
@RequestMapping("/api/makeup/half/process")
@RequiredArgsConstructor
public class MakeupHalfProcessController {

	private final MakeupHalfProcessService makeupHalfProcessService;

	@Operation(summary = "실험노트의 현재 상태 및 개발프로세스 Bar", description = "프로세스 Bar 가져오기")
	@GetMapping("/select-progress-bar")
	public @ResponseBody ResponseEntity<ResponseVO> selectProgressBar (@RequestParam("vLabNoteCd") String vLabNoteCd) {

		log.debug("MakeupProcessController.selectProgressBar");
		return ResponseEntity.ok(makeupHalfProcessService.selectProgressBar(vLabNoteCd));
	}

	@Operation(summary = "실험노트의 현재 상태 및 개발프로세스 내용 가져오기", description = "프로세스 기본 정보 가져오기")
	@GetMapping("/select-progress-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectProgressInfo (@RequestParam("vLabNoteCd") String vLabNoteCd) {
		log.debug("MakeupProcessController.selectProgressInfo");
		return ResponseEntity.ok(makeupHalfProcessService.selectProgressInfo(vLabNoteCd));
	}

	@Operation(summary = "TIME LINE 탭 알림 목록 가져오기", description = "TIME LINE")
	@GetMapping("/select-timeline-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectTimeLineList (@RequestParam("vLabNoteCd") String vLabNoteCd) {

		log.debug("MakeupProcessController.selectTimeLineList");
		return ResponseEntity.ok(makeupHalfProcessService.selectTimeLineList(vLabNoteCd));
	}

	@Operation(summary = "BOM 요청 목록", description = "실험중 > BOM 요청 목록을 조회한다.")
	@GetMapping("/select-lab-note-bom-req-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteBomReqList (
			PilotRequestReqDTO pilotRequestReqDTO
			) {
		log.debug("MakeupProcessController.selectLabNoteBomReqList => pilotRequestReqDTO : {}", pilotRequestReqDTO);
		return ResponseEntity.ok(makeupHalfProcessService.selectLabNoteBomReqList(pilotRequestReqDTO));
	}

	@Operation(summary = "실험중 > 파일럿 목록", description = "실험중 > 파일럿 목록을 조회한다.")
	@GetMapping("/select-lab-note-pilot-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNotePilotList (
			PilotRequestReqDTO pilotRequestReqDTO
			) {
		log.debug("MakeupProcessController.selectLabNotePilotList => pilotRequestReqDTO : {}", pilotRequestReqDTO);
		return ResponseEntity.ok(makeupHalfProcessService.selectLabNotePilotList(pilotRequestReqDTO));
	}

	@Operation(summary = "파일럿 GATE01 승인 요청 등록 초기 정보 조회", description = "실험중 > 파일럿 GATE01 승인 요청 등록 초기 정보를 조회한다.")
	@GetMapping("/select-lab-note-pilot-reg-init-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNotePilotRegInitInfo (
			PilotRequestReqDTO pilotRequestReqDTO
			) {
		log.debug("MakeupProcessController.selectLabNotePilotRegInitInfo => pilotRequestReqDTO : {}", pilotRequestReqDTO);
		return ResponseEntity.ok(makeupHalfProcessService.selectLabNotePilotRegInitInfo(pilotRequestReqDTO));
	}

	@Operation(summary = "파일럿 GATE01 승인 요청 등록 정보 조회", description = "실험중 > 파일럿 GATE01 승인 요청 등록 정보를 조회한다.")
	@GetMapping("/select-lab-note-pilot-reg-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNotePilotRegInfo (
			PilotRequestRegInfoReqDTO pilotRequestRegInfoReqDTO
			) {
		log.debug("MakeupProcessController.selectLabNotePilotRegInfo => pilotRequestDetailReqDTO : {}", pilotRequestRegInfoReqDTO);
		return ResponseEntity.ok(makeupHalfProcessService.selectLabNotePilotRegInfo(pilotRequestRegInfoReqDTO));
	}

	@Operation(summary = "파일럿 GATE01 승인 요청 버전별 LOT 목록 조회", description = "실험중 > 파일럿 GATE01 승인 요청 버전별 LOT 목록을 조회한다.")
	@GetMapping("/select-lab-note-pilot-reg-version-lot-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNotePilotRegVersionLotList (
			@RequestParam(value="vLabNoteCd") String vLabNoteCd,
			@RequestParam(value="nVersion") int nVersion
			) {
		log.debug("MakeupProcessController.selectLabNoteBomRegVersionLotList => params : { vLabNoteCd: {}, nVersion: {} }", vLabNoteCd, nVersion);
		return ResponseEntity.ok(makeupHalfProcessService.selectLabNotePilotRegVersionLotList(vLabNoteCd, nVersion));
	}

	@Operation(summary = "파일럿 GATE01 승인 요청 상세 정보 조회", description = "실험중 > 파일럿 GATE01 승인 요청 상세 정보를 조회한다.")
	@GetMapping("/select-lab-note-pilot-req-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNotePilotReqInfo (
			PilotRequestDetailReqDTO pilotRequestDetailReqDTO
			) {
		log.debug("MakeupProcessController.selectLabNoteBomReqInfo => pilotRequestDetailReqDTO : {}", pilotRequestDetailReqDTO);
		return ResponseEntity.ok(makeupHalfProcessService.selectLabNotePilotReqInfo(pilotRequestDetailReqDTO));
	}

	@Operation(summary = "LOT별 BOM 리스트 조회", description = "실험중 > BOM 승인 상세 > LOT별 BOM 리스트를 조회한다.")
	@GetMapping("/select-lab-note-bom-mate-rate-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteBomMateRateInfo (
			PilotRequestDetailReqDTO pilotRequestDetailReqDTO
			) {
		log.debug("MakeupProcessController.selectLabNoteBomMateRateInfo => pilotRequestDetailReqDTO : {}", pilotRequestDetailReqDTO);
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(makeupHalfProcessService.selectLabNoteBomMateRateInfo(pilotRequestDetailReqDTO));
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "프로세스 > BOM 전송 리스트 조회", description = "프로세스 > BOM 전송 리스트를 조회한다.(BOM 탭)")
	@GetMapping("/select-lab-note-bom-send-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteBomSendList (
			PilotRequestReqDTO pilotRequestReqDTO
			) {
		log.debug("MakeupProcessController.selectLabNoteBomSendList => pilotRequestReqDTO : {}", pilotRequestReqDTO);
		return ResponseEntity.ok(makeupHalfProcessService.selectLabNoteBomSendList(pilotRequestReqDTO));
	}

	@Operation(summary = "프로세스 > 파일럿 GATE01 저장", description = "프로세스 > 파일럿 GATE01 저장")
	@PostMapping("/save-lab-note-gate01")
	public @ResponseBody ResponseEntity<ResponseVO> saveLabNoteGate01 (
			@RequestBody LabNoteProcessPqcCheckApprReqDTO labNoteProcessPqcCheckApprReqDTO
			) {
		log.debug("MakeupProcessController.saveLabNoteGate01 => labNoteProcessPqcCheckApprReqDTO : {}", labNoteProcessPqcCheckApprReqDTO);
		return ResponseEntity.ok(makeupHalfProcessService.saveLabNoteGate01(labNoteProcessPqcCheckApprReqDTO));
	}

	@Operation(summary = "프로세스 > 처방확정 가능 리스트 조회", description = "프로세스 > 처방확정 가능 리스트를 조회한다.")
	@GetMapping("/select-lab-note-formula-decide-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectHal4FormulaDecideList (
			PilotRequestReqDTO pilotRequestReqDTO
			) {
		log.debug("MakeupProcessController.selectHal4FormulaDecideList => pilotRequestReqDTO : {}", pilotRequestReqDTO);
		return ResponseEntity.ok(makeupHalfProcessService.selectHal4FormulaDecideList(pilotRequestReqDTO));
	}

	@Operation(summary = "프로세스 > 결재 pass BOM SAP 전송", description = "프로세스 > 결재 pass BOM SAP 전송")
	@PostMapping("/send-bom-free-pass")
	public @ResponseBody ResponseEntity<ResponseVO> sendBomFreePass (
			@RequestBody BomApprovalReqDTO bomApprovalReqDTO
			) {
		log.debug("MakeupProcessController.sendBomFreePass => bomApprovalReqDTO : {}", bomApprovalReqDTO);
		return ResponseEntity.ok(makeupHalfProcessService.sendBomFreePass(bomApprovalReqDTO));
	}

	@Operation(summary = "파일럿 저장 가능 여부 체크", description = "파일럿 저장 가능 여부 체크")
	@PostMapping("/check-validation-pilot")
	public @ResponseBody ResponseEntity<ResponseVO> checkValidationPilot (
			@RequestBody LotPilotRegDTO regDTO
			) {
		log.debug("MakeupProcessController.checkValidationPilot => regDTO : {}", regDTO);
		return ResponseEntity.ok(makeupHalfProcessService.checkValidationPilot(regDTO));
	}
	
	@Operation(summary = "프로세스 > 파일럿 GATE01 BOM 자동승인", description = "프로세스 > 파일럿 GATE01 BOM 자동승인(메이크업&반제품만)")
	@PostMapping("/save-lab-note-hal4-bom-process")
	public @ResponseBody ResponseEntity<ResponseVO> saveLabNoteHal4BomProcess (
			@RequestBody LabNoteProcessPqcCheckApprReqDTO labNoteProcessPqcCheckApprReqDTO
			) {
		log.debug("MakeupProcessController.saveLabNoteHal4BomProcess => labNoteProcessPqcCheckApprReqDTO : {}", labNoteProcessPqcCheckApprReqDTO);
		return ResponseEntity.ok(makeupHalfProcessService.saveLabNoteHal4BomProcess(labNoteProcessPqcCheckApprReqDTO));
	}
	
	@Operation(summary = "반제품 처방확정", description = "반제품 처방확정 저장")
	@PostMapping("/save-prescribe-confirm")
	public @ResponseBody ResponseEntity<ResponseVO> savePrescribeConfirm (
			@RequestBody SkincareDecideRegDTO regDTO
			) {
		log.debug("makeupHalfProcessService.savePrescribeConfirm => regDTO : {}", regDTO);
		return ResponseEntity.ok(makeupHalfProcessService.savePrescribeConfirm(regDTO));
	}
	
	@Operation(summary = "GATE1 결재 상세 정보 조회", description = "GATE1 결재 의뢰 > 메일 링크로 진입 시 정보를 조회, PILOT 상세 조회 화면으로 이동시키기 위해 추가.")
	@GetMapping("/select-gate1-appr-detail-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectGate1ApprDetailInfo (
			@RequestParam(value="vLabNoteCd") String vLabNoteCd,
			@RequestParam(value="vApprCd") String vApprCd
			) {
		log.debug("MakeupHalfProcessController.selectGate1ApprDetailInfo => vLabNoteCd : {}, vApprCd : {}", vLabNoteCd, vApprCd);
		return ResponseEntity.ok(makeupHalfProcessService.selectGate1ApprDetailInfo(vLabNoteCd, vApprCd));
	}

	@Operation(summary = "LOT별 BOM 상세 조회", description = "실험중 > BOM 승인 상세 > LOT별 BOM 상세를 조회한다.")
	@GetMapping("/select-lab-note-bom-mate-view")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteBomMateView (
			PilotRequestDetailReqDTO pilotRequestDetailReqDTO
			) {
		log.debug("MakeupHalfProcessController.selectLabNoteBomMateView => pilotRequestDetailReqDTO : {}", pilotRequestDetailReqDTO);
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(makeupHalfProcessService.selectLabNoteBomMateView(pilotRequestDetailReqDTO));
		return ResponseEntity.ok(responseVO);
	}
}
