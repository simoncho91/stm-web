package com.mybeaker.app.makeup.controller;

import javax.validation.Valid;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.mybeaker.app.labnote.model.MusoguReqDTO;
import com.mybeaker.app.makeup.model.MaterialLotBaseRegDTO;
import com.mybeaker.app.makeup.model.MuMaterialSaveRegDTO;
import com.mybeaker.app.makeup.model.MuToningDTO;
import com.mybeaker.app.makeup.service.MakeupMaterialService;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.skincare.model.BomReqDTO;
import com.mybeaker.app.skincare.model.BookmarkReqDTO;
import com.mybeaker.app.skincare.model.CounterSAPRegDTO;
import com.mybeaker.app.skincare.model.ElabLotMemoRegDTO;
import com.mybeaker.app.skincare.model.GramReqDTO;
import com.mybeaker.app.skincare.model.IngredientReqDTO;
import com.mybeaker.app.skincare.model.MateRateReqVO;
import com.mybeaker.app.skincare.model.MaterialFormulationReqDTO;
import com.mybeaker.app.skincare.model.MaterialLotBookmarkRegDTO;
import com.mybeaker.app.skincare.model.MaterialPlantRegDTO;
import com.mybeaker.app.skincare.model.MaterialQrInfoVO;
import com.mybeaker.app.skincare.model.MaterialSearchVO;
import com.mybeaker.app.skincare.model.MaterialSumReqDTO;
import com.mybeaker.app.skincare.model.MaterialUploadDTO;
import com.mybeaker.app.skincare.model.MaterialVersionRegDTO;
import com.mybeaker.app.skincare.model.MemoRegDTO;
import com.mybeaker.app.skincare.model.MemoReqDTO;
import com.mybeaker.app.skincare.model.PlantRatePriceReqVO;
import com.mybeaker.app.skincare.model.ScmTCodeRegDTO;
import com.mybeaker.app.skincare.model.SendBomRegDTO;
import com.mybeaker.app.skincare.model.StabilityReqDTO;
import com.mybeaker.app.skincare.model.SubMateReqDTO;
import com.mybeaker.app.skincare.model.TestResultRegDTO;
import com.mybeaker.app.skincare.model.VersionRegDTO;
import com.mybeaker.app.skincare.model.VersionReqDTO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Tag(name = "메이크업 원료배합", description = "메이크업 원료배합")
@RestController
@RequestMapping("/api/makeup/material")
public class MakeupMaterialController {

	private final MakeupMaterialService makeupMaterialService;
	
//	/elab/mu/note/mu_note_experiment_view
	@Operation(summary = "원료배합 상세", description = "원료배합 상세를 조회한다.")
	@GetMapping("/select-material-formulation-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectMaterialFormulationInfo (
			@Valid MaterialFormulationReqDTO reqDTO) {
		log.debug("select-material-formulation-info Start!");
		log.debug("MaterialFormulationReqDTO : {}", reqDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.selectMaterialFormulationInfo(reqDTO));
	}
	
//	elab/experiment/lab_note_rate_sum_ajax
	@Operation(summary = "원료배합 합계 계산", description = "원료배합 합계 계산한다.")
	@PostMapping("/select-material-formulation-sum")
	public @ResponseBody ResponseEntity<ResponseVO> selectMaterialFormulationSum (
			@RequestBody @Valid MaterialSumReqDTO reqDTO) {
		log.debug("select-material-formulation-sum Start!");
		log.debug("MaterialSumReqDTO : {}", reqDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.selectMaterialFormulationSum(reqDTO));
	}
	
//	elab/experiment/lab_note_experiment_save
//	SAVE_MATE_LIST
	@Operation(summary = "원료배합 저장", description = "원료배합 저장한다.")
	@PostMapping("/insert-lab-note-list")
	public @ResponseBody ResponseEntity<ResponseVO> insertLabNoteList (
			@RequestBody @Valid MuMaterialSaveRegDTO regDTO) {
		log.debug("insert-lab-note-list Start!");
		log.debug("MuMaterialSaveRegDTO : {}", regDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.insertLabNoteList(regDTO));
	}
	
//	SAVE_NEW_VERSION
	@Operation(summary = "신규 버전 저장", description = "신규 버전 저장한다.")
	@PostMapping("/insert-lab-note-new-version")
	public @ResponseBody ResponseEntity<ResponseVO> insertLabNoteNewVersion (
			@RequestBody @Valid MaterialVersionRegDTO regDTO) {
		log.debug("insert-lab-note-new-version Start!");
		log.debug("MaterialVersionRegDTO : {}", regDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.insertLabNoteNewVersion(regDTO));
	}
	
//	SAVE_SIMILAR
	@Operation(summary = "기존 처방 등록", description = "기존 처방 등록한다.")
	@PostMapping("/update-lab-note-bookmark")
	public @ResponseBody ResponseEntity<ResponseVO> updateLabNoteLotBookmark (
			@RequestBody @Valid MaterialLotBookmarkRegDTO regDTO) {
		log.debug("update-lab-note-bookmark Start!");
		log.debug("MaterialLotBookmarkRegDTO : {}", regDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.updateLabNoteLotBookmark(regDTO));
	}
	
//	SAVE_SIMILAR_DELETE
	@Operation(summary = "기존 처방 삭제", description = "기존 처방 삭제한다.")
	@PostMapping("/delete-lab-note-bookmark")
	public @ResponseBody ResponseEntity<ResponseVO> deleteLabNoteLotBookmark (
			@RequestBody @Valid MaterialLotBookmarkRegDTO regDTO) {
		log.debug("delete-lab-note-bookmark Start!");
		log.debug("MaterialLotBookmarkRegDTO : {}", regDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.deleteLabNoteLotBookmark(regDTO));
	}
	
//	SAVE_APPLY_PLANT
	@Operation(summary = "과제 플랜트 적용", description = "과제 플랜트 적용한다.")
	@PostMapping("/update-lab-note-apply-plan")
	public @ResponseBody ResponseEntity<ResponseVO> updateLabNoteApplyPlant (
			@RequestBody @Valid MaterialPlantRegDTO regDTO) {
		log.debug("update-lab-note-apply-plan Start!");
		log.debug("MaterialPlantRegDTO : {}", regDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.updateLabNoteApplyPlant(regDTO));
	}

//	SAVE_TRANSFER_BASE
	@Operation(summary = "베이스 처방 등록", description = "베이스 처방 등록한다.")
	@PostMapping("/update-lab-note-lot-base")
	public @ResponseBody ResponseEntity<ResponseVO> updateLabNoteLotBase (
			@RequestBody @Valid MaterialLotBaseRegDTO regDTO) {
		log.debug("update-lab-note-lot-base Start!");
		log.debug("MaterialLotBaseRegDTO : {}", regDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.updateLabNoteLotBase(regDTO));
	}

//	SAVE_TEST_RESULT
	@Operation(summary = "시험결과 저장", description = "시험결과 저장한다.")
	@PostMapping("/insert-lab-note-test-result")
	public @ResponseBody ResponseEntity<ResponseVO> insertLabNoteTestResult (
			@RequestBody @Valid TestResultRegDTO regDTO) {
		log.debug("insert-lab-note-test-result Start!");
		log.debug("TestResultRegDTO : {}", regDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.insertLabNoteTestResult(regDTO));
	}

//	SAVE_SEND_BOM
	@Operation(summary = "BOM 임시전송 전송", description = "BOM 임시전송 전송한다.")
	@PostMapping("/update-lab-note-lot-send-bom")
	public @ResponseBody ResponseEntity<ResponseVO> updateLabNoteLotSendBom (
			@RequestBody @Valid SendBomRegDTO regDTO) {
		log.debug("update-lab-note-lot-send-bom Start!");
		log.debug("SendBomRegDTO : {}", regDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.updateLabNoteLotSendBom(regDTO));
	}
	
	
	
	
	
	
	
	
	
	
	
	
//	elab/experiment/lab_note_mate_rate_list_ajax
	@Operation(summary = "lot 선택 조회", description = "lot 선택 조회한다.")
	@GetMapping("/select-lab-note-lot-gram-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteLotGramInfo (
			@RequestParam String vLabNoteCd, @RequestParam String vContPkCd, @RequestParam int nVersion, @RequestParam String vLotCd) {
		log.debug("select-lab-note-lot-gram-info Start!");
		log.debug("vLabNoteCd : {}", vLabNoteCd);
		log.debug("vContPkCd : {}", vContPkCd);
		log.debug("nVersion : {}", nVersion);
		log.debug("vLotCd : {}", vLotCd);
		
		return ResponseEntity.ok(makeupMaterialService.selectLabNoteLotGramInfo(MaterialSearchVO.builder()
				.vLabNoteCd(vLabNoteCd)
				.vContPkCd(vContPkCd)
				.nVersion(nVersion)
				.vLotCd(vLotCd)
				.build()));
	}
	
//	elab/experiment/lab_note_sub_mate_list_ajax
	@Operation(summary = "SUB 원료정보 조회", description = "SUB 원료정보 조회한다.")
	@GetMapping("/select-lab-note-sub-mate-rate-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteSubMateRateInfo (
			@Valid SubMateReqDTO reqDTO) {
		log.debug("select-lab-note-sub-mate-rate-info Start!");
		log.debug("SubMateReqDTO : {}", reqDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.selectLabNoteSubMateRateInfo(reqDTO));
	}

//	--------------------------------------------------------------------------------
//	POPUP - 처방 불러오기
//	elab/experiment/lab_note_bookmark_list_pop
	@Operation(summary = "처방 불러오기 리스트", description = "처방 불러오기 리스트를 조회한다.")
	@GetMapping("/select-lab-note-bookmark-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteBookmarkList (
			BookmarkReqDTO reqDTO) {
		log.debug("select-lab-note-bookmark-list Start!");
		log.debug("BookmarkReqDTO : {}", reqDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.selectLabNoteBookmarkList(reqDTO));
	}

//	elab/experiment/lab_note_mate_plant_check_ajax
	@Operation(summary = "처방 적용 체크(plant)", description = "처방 적용 체크한다.(plant 있을 경우)")
	@GetMapping("/select-lab-note-mate-plant-check")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteMatePlantCheck (
			BookmarkReqDTO reqDTO) {
		log.debug("select-lab-note-mate-plant-check Start!");
		log.debug("BookmarkReqDTO : {}", reqDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.selectLabNoteMatePlantCheck(reqDTO));
	}
	
//	elab/experiment/lab_note_bookmark_apply_list_ajax
	@Operation(summary = "처방 적용(apply)", description = "처방 적용한다.(plant 없을 경우)")
	@GetMapping("/select-lab-note-bookmark-apply-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteBookmarkApplyList (
			@Valid BookmarkReqDTO reqDTO) {
		log.debug("select-lab-note-bookmark-apply-list Start!");
		log.debug("BookmarkReqDTO : {}", reqDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.selectLabNoteBookmarkApplyList(reqDTO));
	}

//	elab/common/lab_note_counter_sap_sync_ajax
	@Operation(summary = "SAP Sync", description = "SAP Sync 등록한다.")
	@PostMapping("/insert-lab-note-counter-sap-info")
	public @ResponseBody ResponseEntity<ResponseVO> insertLabNoteCounterSAPInfo (
			@RequestBody @Valid CounterSAPRegDTO regDTO) {
		log.debug("insert-lab-note-counter-sap-info Start!");
		log.debug("CounterSAPReqDTO : {}", regDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.insertLabNoteCounterSAPInfo(regDTO));
	}
	
//	elab/experiment/lab_note_mate_rate_info_pop
	@Operation(summary = "내용물 상세보기", description = "내용물 상세보기 조회한다.")
	@GetMapping("/select-lab-note-mate-rate-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteMateRateInfo (
			@RequestParam String vLabNoteCd
			, @RequestParam String vContPkCd
			, @RequestParam int nVersion
			, @RequestParam String vLotCd) {
		log.debug("select-lab-note-mate-rate-info Start!");
		log.debug("vLabNoteCd : {}", vLabNoteCd);
		log.debug("vContPkCd : {}", vContPkCd);
		log.debug("nVersion : {}", nVersion);
		log.debug("vLotCd : {}", vLotCd);
		
		return ResponseEntity.ok(makeupMaterialService.selectLabNoteMateRateInfo(MateRateReqVO.builder()
				.vLabNoteCd(vLabNoteCd)
				.vContPkCd(vContPkCd)
				.nVersion(nVersion)
				.vLotCd(vLotCd)
				.build()));
	}

//	POPUP - 버전관리
//	elab/common/lab_note_version_manage_pop
	@Operation(summary = "버전관리 조회", description = "버전관리 조회한다.")
	@GetMapping("/select-lab-note-version-list")
	public @ResponseBody ResponseEntity<ResponseVO> selcetLabNoteVersionList (
			@Valid VersionReqDTO reqDTO) {
		log.debug("select-lab-note-version-list Start!");
		log.debug("MateRateReqDTO : {}", reqDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.selcetLabNoteVersionList(reqDTO));
	}
	
//	elab/common/lab_note_version_manage_ajax
	@Operation(summary = "버전관리 저장", description = "버전관리 저장한다.")
	@PostMapping("/update-version-view")
	public @ResponseBody ResponseEntity<ResponseVO> updateVersionView (
			@RequestBody @Valid VersionRegDTO regDTO) {
		log.debug("update-version-view Start!");
		log.debug("VersionRegDTO : {}", regDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.updateVersionView(regDTO));
	}

//	POPUP - 무소구가능항목
//	elab/common/lab_note_experiment_musogu_view
	@Operation(summary = "무소구가능항목 조회", description = "무소구가능항목 조회한다.")
	@GetMapping("/select-musogu-list")
	public @ResponseBody ResponseEntity<ResponseVO> selcetMusoguList (
			@Valid MusoguReqDTO reqDTO) {
		log.debug("select-musogu-list Start!");
		log.debug("MusoguReqDTO : {}", reqDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.selcetMusoguList(reqDTO));
	}

//	POPUP - 글로벌금지
//	elab/experiment/lab_note_mate_alert_view_pop_save_ajax
	@Operation(summary = "글로벌 금지항목 확인 저장", description = "글로벌 금지항목 확인 저장한다.")
	@PostMapping("/update-lab-note-mate-check")
	public @ResponseBody ResponseEntity<ResponseVO> updateLabNoteMateCheck (
			@RequestBody @Valid ScmTCodeRegDTO regDTO) {
		log.debug("update-lab-note-mate-check Start!");
		log.debug("ScmTCodeRegDTO : {}", regDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.updateLabNoteMateCheck(regDTO));
	}

//	POPUP - 플랜트별 단가
//	elab/experiment/lab_note_all_plant_price_list_pop
	@Operation(summary = "플랜트별 단가 조회", description = "플랜트별 단가 조회한다.")
	@GetMapping("/select-lab-note-all-plant-rate-and-price")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteAllPlantRateAndPrice (
			@RequestParam String vLabNoteCd
			, @RequestParam String vContPkCd
			, @RequestParam int nVersion
			, @RequestParam String vLotCd
			, @RequestParam(required = false, defaultValue = "100") int nCapacity) {
		log.debug("select-lab-note-all-plant-rate-and-price Start!");
		log.debug("vLabNoteCd : {}", vLabNoteCd);
		log.debug("vContPkCd : {}", vContPkCd);
		log.debug("nVersion : {}", nVersion);
		log.debug("vLotCd : {}", vLotCd);
		log.debug("nCapacity : {}", nCapacity);
		
		return ResponseEntity.ok(makeupMaterialService.selectLabNoteAllPlantRateAndPrice(PlantRatePriceReqVO.builder()
				.vLabNoteCd(vLabNoteCd)
				.vContPkCd(vContPkCd)
				.nVersion(nVersion)
				.vLotCd(vLotCd)
				.nCapacity(nCapacity)
				.build()));
	}

//	POPUP - QR코드 조회
//	cm/qr/cm_make_note_lot_qr_code_pop
	@Operation(summary = "QR코드 조회", description = "QR코드 조회한다.")
	@GetMapping("/select-qr-code-elab-note-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectQrCodeElabNoteInfo (
			@RequestParam String vLotCd,
			@RequestParam String vFlagStandard) {
		log.debug("select-qr-code-elab-note-info Start!");
		log.debug("vLotCd : {}", vLotCd);
		log.debug("vFlagStandard : {}", vFlagStandard);
		
		return ResponseEntity.ok(makeupMaterialService.selectQrCodeElabNoteInfo(MaterialQrInfoVO.builder()
				.vLotCd(vLotCd)
				.vFlagStandard(vFlagStandard)
				.build()));
	}

//	POPUP - BOM 임시전송
//	elab/experiment/lab_note_send_bom_pop
	@Operation(summary = "BOM 임시전송 조회", description = "BOM 임시전송 조회한다.")
	@GetMapping("/select-lab-note-bom-lot-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteBomLotList (
			@Valid BomReqDTO reqDTO) {
		log.debug("select-lab-note-bom-lot-list Start!");
		log.debug("BomReqDTO : {}", reqDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.selectLabNoteBomLotList(reqDTO));
	}

//	POPUP - 실험결과
//	/elab/experiment/lab_note_gram_test_result_html
	@Operation(summary = "실험결과 조회", description = "실험결과 조회한다.")
	@GetMapping("/select-lab-note-gram-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteGramList (
			@Valid GramReqDTO reqDTO) {
		log.debug("select-lab-note-gram-list Start!");
		log.debug("GramReqDTO : {}", reqDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.selectLabNoteGramList(reqDTO));
	}
	
//	POPUP - 전성분
//	elab/common/lab_note_choice_ingredient_data_pop
	@Operation(summary = "전성분 조회(조회 전 기본정보 선택)", description = "전성분 조회 전 기본정보 조회한다.")
	@GetMapping("/select-lab-note-default-ingredient-data")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteDefaultIngredientData (
			@Valid IngredientReqDTO reqDTO) {
		log.debug("select-lab-note-default-ingredient-data Start!");
		log.debug("IngredientReqDTO : {}", reqDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.selectLabNoteDefaultIngredientData(reqDTO));
	}
	
//	elab/experiment/lab_note_ingredient_view_pop
	@Operation(summary = "전성분 조회", description = "전성분 조회한다.")
	@GetMapping("/select-lab-note-ingredient-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteIngredientList (
			@Valid IngredientReqDTO reqDTO) {
		log.debug("select-lab-note-ingredient-list Start!");
		log.debug("IngredientReqDTO : {}", reqDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.selectLabNoteIngredientList(reqDTO));
	}

//	POPUP - 안정도 설정
//	elab/experiment/lab_note_stability_setting_pop
	@Operation(summary = "안정도 설정 조회", description = "안정도 설정 조회한다.")
	@GetMapping("/select-lab-note-stability-title-all-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteStabilityTitleAllList (
			@RequestParam String vLabNoteCd,
			@RequestParam String vLotCd) {
		log.debug("select-lab-note-stability-title-all-list Start!");
		log.debug("vLabNoteCd : {}", vLabNoteCd);
		log.debug("vLotCd : {}", vLotCd);
		
		return ResponseEntity.ok(makeupMaterialService.selectLabNoteStabilityTitleAllList(vLabNoteCd, vLotCd));
	}
	
//	elab/experiment/lab_note_stability_apply_ajax
	@Operation(summary = "안정도 설정 저장", description = "안정도 설정 저장한다.")
	@PostMapping("/insert-lab-note-stability-title")
	public @ResponseBody ResponseEntity<ResponseVO> insertLabNoteStabilityTitle (
			@RequestBody @Valid StabilityReqDTO reqDTO) {
		log.debug("insert-lab-note-stability-title Start!");
		log.debug("StabilityReqDTO : {}", reqDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.insertLabNoteStabilityTitle(reqDTO));
	}

//	POPUP - 메모
//	elab/experiment/lab_note_memo_view_pop
	@Operation(summary = "메모 조회", description = "메모 조회한다.")
	@GetMapping("/select-lab-note-memo-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteMemoList (
			@Valid MemoReqDTO reqDTO) {
		log.debug("select-lab-note-memo-list Start!");
		log.debug("MemoReqDTO : {}", reqDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.selectLabNoteMemoList(reqDTO));
	}
	
//	elab/experiment/lab_note_memo_reg_pop
	@Operation(summary = "메모 상세 조회", description = "메모 상세 조회한다.")
	@GetMapping("/select-lab-note-memo")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteMemo (
			@Valid MemoReqDTO reqDTO) {
		log.debug("select-lab-note-memo Start!");
		log.debug("MemoReqDTO : {}", reqDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.selectLabNoteMemo(reqDTO));
	}

//	elab/experiment/lab_note_memo_save
//	i_sFlagAction=R
	@Operation(summary = "메모 등록", description = "메모 등록한다.")
	@PostMapping("/insert-lab-note-memo")
	public @ResponseBody ResponseEntity<ResponseVO> insertLabNoteMemo (
			@RequestBody @Valid MemoRegDTO regDTO) {
		log.debug("insert-lab-note-memo Start!");
		log.debug("MemoRegDTO : {}", regDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.insertLabNoteMemo(regDTO));
	}
	
//	i_sFlagAction=M
	@Operation(summary = "메모 수정", description = "메모 수정한다.")
	@PostMapping("/update-lab-note-memo")
	public @ResponseBody ResponseEntity<ResponseVO> updateLabNoteMemo (
			@RequestBody @Valid MemoRegDTO regDTO) {
		log.debug("update-lab-note-memo Start!");
		log.debug("MemoRegDTO : {}", regDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.updateLabNoteMemo(regDTO));
	}
	
//	i_sFlagAction=D
	@Operation(summary = "메모 삭제", description = "메모 삭제한다.")
	@PostMapping("/delete-lab-note-memo")
	public @ResponseBody ResponseEntity<ResponseVO> deleteLabNoteMemo (
			@RequestBody @Valid MemoRegDTO regDTO) {
		log.debug("delete-lab-note-memo Start!");
		log.debug("MemoRegDTO : {}", regDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.deleteLabNoteMemo(regDTO));
	}

//	elab/experiment/lab_note_select_hal4_lot_pop
	@Operation(summary = "반제품 버전 조회", description = "반제품 버전 조회한다.")
	@GetMapping("/select-lab-note-cont-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteContInfo (
			@RequestParam String vLabNoteCd
			, @RequestParam String vContPkCd) {
		log.debug("select-lab-note-cont-info Start!");
		log.debug("vLabNoteCd : {}", vLabNoteCd);
		log.debug("vContPkCd : {}", vContPkCd);
		
		return ResponseEntity.ok(makeupMaterialService.selectLabNoteContInfo(MaterialSearchVO.builder()
				.vLabNoteCd(vLabNoteCd)
				.vContPkCd(vContPkCd)
				.build()));
	}
	
//	elab/experiment/lab_note_lot_list_ajax
	@Operation(summary = "반제품 Lot 조회", description = "반제품 Lot 조회한다.")
	@GetMapping("/select-lab-note-lot-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteLotList (
			@RequestParam String vContPkCd
			, @RequestParam int nVersion) {
		log.debug("select-lab-note-lot-list Start!");
		log.debug("vLabNoteCd : {}", vContPkCd);
		log.debug("nVersion : {}", nVersion);
		
		return ResponseEntity.ok(makeupMaterialService.selectLabNoteLotList(MaterialSearchVO.builder()
				.vContPkCd(vContPkCd)
				.nVersion(nVersion)
				.build()));
	}
	
	@Operation(summary = "Lot Side 정보 조회", description = "Lot Side 정보 조회한다.")
	@GetMapping("/select-elab-lot-memo-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectElabLotMemoList (
			@RequestParam String vLotCd) {
		log.debug("select-elab-lot-memo-list Start!");
		log.debug("vLotCd : {}", vLotCd);
		
		return ResponseEntity.ok(makeupMaterialService.selectElabLotMemoList(vLotCd));
	}

	@Operation(summary = "Lot Side 정보 저장", description = "Lot Side 정보 저장한다.")
	@PostMapping("/insert-elab-lot-memo")
	public @ResponseBody ResponseEntity<ResponseVO> insertElabLotMemo (
			@RequestBody @Valid ElabLotMemoRegDTO regDTO) {
		log.debug("insert-elab-lot-memo Start!");
		log.debug("ElabLotMemoRegDTO : {}", regDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.insertElabLotMemo(regDTO));
	}

	@Operation(summary = "원료배합 순서바꾸기 조회", description = "원료배합 순서바꾸기 조회한다.")
	@GetMapping("/select-material-formulation-change")
	public @ResponseBody ResponseEntity<ResponseVO> selectMaterialFormulationChange (
			@RequestParam String vContPkCd,
			@RequestParam int nVersion,
			@RequestParam String vLotCd) {
		log.debug("select-material-formulation-change Start!");
		log.debug("vContPkCd : {}", vContPkCd);
		log.debug("nVersion : {}", nVersion);
		log.debug("vLotCd : {}", vLotCd);
		
		return ResponseEntity.ok(makeupMaterialService.selectMaterialFormulationChange(vContPkCd, nVersion, vLotCd));
	}
	
	@Operation(summary = "원료배합 순서바꾸기 저장", description = "원료배합 순서바꾸기 저장한다.")
	@PostMapping("/update-material-formulation-change")
	public @ResponseBody ResponseEntity<ResponseVO> updateMaterialFormulationChange (
			@RequestBody @Valid MuMaterialSaveRegDTO regDTO) {
		log.debug("update-material-formulation-change Start!");
		log.debug("MuMaterialSaveRegDTO : {}", regDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.updateMaterialFormulationChange(regDTO));
	}
	
	@Operation(summary = "엑셀 업로드", description = "원료배합 엑셀 업로드한다.")
	@PostMapping(value = "/update-material-formulation-excel", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public @ResponseBody ResponseEntity<ResponseVO> updateMaterialFormulationExcel (
			MaterialUploadDTO regDTO,
			@RequestPart(value = "file") MultipartFile file) {
		log.debug("update-material-formulation-excel Start!");
		log.debug("MaterialUploadDTO : {}", regDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.updateMaterialFormulationExcel(regDTO, file));
	}

	@Operation(summary = "조색 설정 저장", description = "조색 설정 저장한다.")
	@PostMapping("/update-lab-note-toning")
	public @ResponseBody ResponseEntity<ResponseVO> updateLabNoteToning (
			@RequestBody @Valid MuToningDTO regDTO) {
		log.debug("update-lab-note-toning Start!");
		log.debug("MuToningDTO : {}", regDTO.toString());
		
		return ResponseEntity.ok(makeupMaterialService.updateLabNoteToning(regDTO));
	}
}
