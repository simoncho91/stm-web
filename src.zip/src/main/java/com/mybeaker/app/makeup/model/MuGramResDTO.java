package com.mybeaker.app.makeup.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.skincare.model.GramTrPlanVO;
import com.mybeaker.app.skincare.model.MaterialNoteContVO;
import com.mybeaker.app.skincare.model.MaterialNoteVersionVO;
import com.mybeaker.app.skincare.model.StabilityTitleVO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class MuGramResDTO {
	
	private List<StabilityTitleVO> titleList;
	
	private List<MuNoteStabilityValueVO> valueList;
	
	private MaterialNoteContVO contVO;
	
	private MaterialNoteVersionVO verVO;
	
	private MuNoteLotVO lotVO;
	
	private List<MuNoteGramVO> gramList;
	
	private MuNoteGramVO gramVO;
	
	private List<GramTrPlanVO> gramTrList;
	
	@JsonProperty("vGramCd")
	private String vGramCd;
}
