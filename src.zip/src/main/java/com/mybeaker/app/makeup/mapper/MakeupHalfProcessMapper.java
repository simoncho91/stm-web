package com.mybeaker.app.makeup.mapper;

import java.util.List;

import javax.validation.Valid;

import org.apache.ibatis.annotations.Mapper;

import com.mybeaker.app.labnote.model.BomShelfLifeDTO;
import com.mybeaker.app.labnote.model.LabNotePqcGateCheckListDTO;
import com.mybeaker.app.labnote.model.LabNotePqcGateCheckReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessPqcCheckApprReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessProgressDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessReqDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessTabListDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessTimeLineDTO;
import com.mybeaker.app.labnote.model.PilotRequestDTO;
import com.mybeaker.app.labnote.model.PilotRequestDetailReqDTO;
import com.mybeaker.app.labnote.model.PilotRequestMateDTO;
import com.mybeaker.app.labnote.model.PilotRequestReqDTO;
import com.mybeaker.app.skincare.model.ScNoteLotDTO;
import com.mybeaker.app.skincare.model.VersionContVO;

@Mapper
public interface MakeupHalfProcessMapper {

	List<LabNoteProcessProgressDTO> selectProgressInfo(String vLabNoteCd);

	List<LabNoteProcessTabListDTO> selectProgressTabList(LabNoteProcessReqDTO reqDTO);

	List<LabNoteProcessTimeLineDTO> selectTimeLineList(String vLabNoteCd);

	int selectLabNoteBomReqListCount(PilotRequestReqDTO pilotRequestReqDTO);

	List<PilotRequestDTO> selectLabNoteBomReqList(PilotRequestReqDTO pilotRequestReqDTO);

	public int selectSafetyCtCount(String vLabNoteCd);

	public int selectElabGlobalBanCheck(LabNotePqcGateCheckReqDTO checkDTO);

	int selectLabNoteBomSendListCount(PilotRequestReqDTO pilotRequestReqDTO);

	List<PilotRequestDTO> selectLabNoteBomSendList(PilotRequestReqDTO pilotRequestReqDTO);

	List<PilotRequestDTO> selectLabNoteApprBomLotList(PilotRequestDetailReqDTO pilotRequestDetailReqDTO);

	List<PilotRequestMateDTO> selectLabNoteBomMateRateInfo(PilotRequestDetailReqDTO pilotRequestDetailReqDTO);

	List<BomShelfLifeDTO> selectLabNoteShelfLifePqcList(String vApprCd);

	List<LabNotePqcGateCheckListDTO> selectPqcGateResItemList(String vPqcResCd);

	void updateLabContPqcRes(@Valid LabNoteProcessPqcCheckApprReqDTO reqDTO);

	void updateLabContVerPqcRes(@Valid LabNoteProcessPqcCheckApprReqDTO reqDTO);

	List<VersionContVO> selectLabNoteContPlantAllList(String vLabNoteCd, String localLanguage);

	List<ScNoteLotDTO> selectLabNoteContLotAllList(String vLabNoteCd, int nVersion);

	void insertLabNoteApprBomInfo(LabNoteProcessPqcCheckApprReqDTO params);

	void updateLabNoteLotApprCd(LabNoteProcessPqcCheckApprReqDTO params);

	List<PilotRequestDTO> selectHal4FormulaDecideList(PilotRequestReqDTO pilotRequestReqDTO);

	String selectLabNoteActiveStatus(String vStatusCd);
	
	PilotRequestDTO selectGate1ApprDetailInfo(String vLabNoteCd, String vApprCd);
}
