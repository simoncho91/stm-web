package com.mybeaker.app.makeup.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.labnote.model.LabNoteCommonTagDTO;
import com.mybeaker.app.labnote.model.LabNoteMstVersionDTO;
import com.mybeaker.app.labnote.model.LabNoteRequestPjtDTO;
import com.mybeaker.app.labnote.model.LabNoteVersionDTO;
import com.mybeaker.app.labnote.model.RcvFirstSaleDateDTO;
import com.mybeaker.app.labnote.model.ThisInventoryVO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MakeupNoteInfoDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vLabTypeCd")
	private String vLabTypeCd;

	@JsonProperty("vLabTypeNm")
	private String vLabTypeNm;

	@JsonProperty("vStatusCd")
	private String vStatusCd;

	@JsonProperty("vStatusNm")
	private String vStatusNm;

	@JsonProperty("vBrdCd")
	private String vBrdCd;

	@JsonProperty("vBrdNm")
	private String vBrdNm;

	@JsonProperty("vLabTypeCtgCd")
	private String vLabTypeCtgCd;

	@JsonProperty("vLabTypePrdCd")
	private String vLabTypePrdCd;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vPlantNm")
	private String vPlantNm;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vPrdCd")
	private String vPrdCd;

	@JsonProperty("vLabContCd")
	private String vLabContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vNoteContNm")
	private String vNoteContNm;

	@JsonProperty("vCodeType")
	private String vCodeType;

	@JsonProperty("vDecideContNm")
	private String vDecideContNm;

	@JsonProperty("vFlagDecide")
	private String vFlagDecide;

	@JsonProperty("vDeptCd")
	private String vDeptCd;

	@JsonProperty("vDeptNm")
	private String vDeptNm;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vUsernm")
	private String vUsernm;

	@JsonProperty("vUsrDeptnm")
	private String vUsrDeptnm;

	@JsonProperty("vUsrDeptcd")
	private String vUsrDeptcd;

	@JsonProperty("vPerfUserid")
	private String vPerfUserid;

	@JsonProperty("vPerfUsernm")
	private String vPerfUsernm;

	@JsonProperty("vPerfDeptnm")
	private String vPerfDeptnm;

	@JsonProperty("vPerfDeptcd")
	private String vPerfDeptcd;

	@JsonProperty("vCtcUserid")
	private String vCtcUserid;

	@JsonProperty("vCtcUsernm")
	private String vCtcUsernm;

	@JsonProperty("vCtcDeptnm")
	private String vCtcDeptnm;

	@JsonProperty("vCtcDeptcd")
	private String vCtcDeptcd;

	@JsonProperty("vPilotDt")
	private String vPilotDt;

	@JsonProperty("vMeetingDt")
	private String vMeetingDt;

	@JsonProperty("vMassProdDt")
	private String vMassProdDt;

	@JsonProperty("vProdType1Cd")
	private String vProdType1Cd;

	@JsonProperty("vProdType1Nm")
	private String vProdType1Nm;

	@JsonProperty("vProdType2Cd")
	private String vProdType2Cd;

	@JsonProperty("vProdType2Nm")
	private String vProdType2Nm;

	@JsonProperty("vTddProdType1Cd")
	private String vTddProdType1Cd;

	@JsonProperty("vTddProdType1Nm")
	private String vTddProdType1Nm;

	@JsonProperty("vTddProdType2Cd")
	private String vTddProdType2Cd;

	@JsonProperty("vTddProdType2Nm")
	private String vTddProdType2Nm;

	@JsonProperty("nPrice")
	private String nPrice;

	@JsonProperty("nTargetCost")
	private String nTargetCost;

	@JsonProperty("nCapacity")
	private String nCapacity;

	@JsonProperty("vCapacityCd")
	private String vCapacityCd;

	@JsonProperty("vCapacityNm")
	private String vCapacityNm;

	@JsonProperty("vNote")
	private String vNote;

	@JsonProperty("vFlagNew")
	private String vFlagNew;

	@JsonProperty("vFlagNotAdd")
	private String vFlagNotAdd;

	@JsonProperty("vNotAddNote")
	private String vNotAddNote;

	@JsonProperty("vFlagApPromise")
	private String vFlagApPromise;

	@JsonProperty("vApPromiseNote")
	private String vApPromiseNote;

	@JsonProperty("nProductCapacity")
	private String nProductCapacity;

	@JsonProperty("vProductCapacityCd")
	private String vProductCapacityCd;

	@JsonProperty("vProductCapacityNm")
	private String vProductCapacityNm;

	@JsonProperty("vTargetCustomer")
	private String vTargetCustomer;

	@JsonProperty("vLabNoteYear")
	private String vLabNoteYear;

	@JsonProperty("vCompleteDt")
	private String vCompleteDt;

	@JsonProperty("vProdTypeNote")
	private String vProdTypeNote;

	@JsonProperty("vOnePoint")
	private String vOnePoint;

	@JsonProperty("vOnePointTech")
	private String vOnePointTech;

	@JsonProperty("nEffTestDcnt")
	private String nEffTestDcnt;

	@JsonProperty("vEffTestDcntUnit")
	private String vEffTestDcntUnit;

	@JsonProperty("vEffTestDcntUnitTxt")
	private String vEffTestDcntUnitTxt;

	@JsonProperty("vPartCd")
	private String vPartCd;

	@JsonProperty("vPartNm")
	private String vPartNm;

	@JsonProperty("vFlagReleaseASIA")
	private String vFlagReleaseAsia;

	@JsonProperty("vFlagReleaseASEAN")
	private String vFlagReleaseAsean;

	@JsonProperty("vFlagReleaseETC")
	private String vFlagReleaseEtc;

	@JsonProperty("vEffCompTypeCd")
	private String vEffCompTypeCd;

	@JsonProperty("vEffCompTypeNm")
	private String vEffCompTypeNm;

	@JsonProperty("vEffTestSogooMemo")
	private String vEffTestSogooMemo;

	@JsonProperty("vEffTestItemDt")
	private String vEffTestItemDt;

	@JsonProperty("vTestItemDt")
	private String vTestItemDt;

	@JsonProperty("vFlagBomComplete")
	private String vFlagBomComplete;

	@JsonProperty("vFlagDecideLot")
	private String vFlagDecideLot;

	@JsonProperty("vFlagTestReq")
	private String vFlagTestReq;

	@JsonProperty("vFlagFuncTest")
	private String vFlagFuncTest;

	@JsonProperty("vFlagPilotTest")
	private String vFlagPilotTest;

	@JsonProperty("vFlagIngredientComplete")
	private String vFlagIngredientComplete;

	@JsonProperty("vFlagReset")
	private String vFlagReset;

	@JsonProperty("vFlagPilotGenerate")
	private String vFlagPilotGenerate;

	@JsonProperty("vBenefit")
	private String vBenefit;

	@JsonProperty("vShapeFeature")
	private String vShapeFeature;

	@JsonProperty("vSpContNm")
	private String vSpContNm;

	@JsonProperty("vFlagOem")
	private String vFlagOem;

	@JsonProperty("vOemManufacturer")
	private String vOemManufacturer;

	@JsonProperty("vSiteType")
	private String vSiteType;

	@JsonProperty("vSiteTypeNm")
	private String vSiteTypeNm;

	@JsonProperty("vRegUserid")
	private String vRegUserid;

	@JsonProperty("vRegDtm")
	private String vRegDtm;

	@JsonProperty("nMaxVersion")
	private int nMaxVersion;

	@JsonProperty("nContNum")
	private int nContNum;

	@JsonProperty("v4mMatCd")
	private String v4mMatCd;

	@JsonProperty("v4mHisNum")
	private String v4mHisNum;

	@JsonProperty("vFlagExistMatnr")
	private String vFlagExistMatnr;

	@JsonProperty("vContainerNm")
	private String vContainerNm;

	@JsonProperty("vContainerCd")
	private String vContainerCd;

	@JsonProperty("vContainerEtc")
	private String vContainerEtc;

	@JsonProperty("vShelfLife")
	private String vShelfLife;

	@JsonProperty("vShelflifeStatus")
	private String vShelflifeStatus;

	@JsonProperty("vFlagOpenBom")
	private String vFlagOpenBom;

	@JsonProperty("vFlagSecurity")
	private String vFlagSecurity;

	@JsonProperty("vIsLabNoteAdmin")
	private String vIsLabNoteAdmin;

	@JsonProperty("vIsLabNoteStatus")
	private String vIsLabNoteStatus;

	@JsonProperty("vFlagAllDecide")
	private String vFlagAllDecide;

	@JsonProperty("vFlagMassAppr")
	private String vFlagMassAppr;

	@JsonProperty("vMaterialGroupCd")
	private String vMaterialGroupCd;

	@JsonProperty("vMaterialGroupNm")
	private String vMaterialGroupNm;

	private LabNoteVersionDTO versionInfo;

	private List<LabNoteCommonTagDTO> mti01List; // V_MST_CODE = 'MTI01'

	private List<LabNoteCommonTagDTO> effectList; // V_MST_CODE = 'LNC15'

	private List<LabNoteCommonTagDTO> tuserList; // V_MST_CODE = 'LNC12'

	private List<LabNoteCommonTagDTO> reqEtcList; // V_MST_CODE = 'LNC13'

	private List<LabNoteCommonTagDTO> releaseList; // V_MST_CODE = 'LNC02'

	private List<LabNoteCommonTagDTO> mtr04List; // V_MST_CODE = 'MTR04'

	private List<LabNoteCommonTagDTO> mtr05List; // V_MST_CODE = 'MTR05'

	private List<LabNoteCommonTagDTO> mtr06List; // V_MST_CODE = 'MTR06'

	private List<LabNoteCommonTagDTO> mgList;

	private List<LabNoteRequestPjtDTO> pjtList;

	private List<LabNoteMstVersionDTO> verList;

	private List<MakeupNoteRequestContDTO> contList;

	private List<MakeupNoteContDTO> compContList;

	private List<MakeupCounterDTO> counterList;

	private List<LabNoteCommonTagDTO> funcTagList;

	private List<RcvFirstSaleDateDTO> releaseDateList;

	@JsonProperty("vColorUserid")
	private String vColorUserid;

	@JsonProperty("vColorUsernm")
	private String vColorUsernm;

	@JsonProperty("vColorDeptnm")
	private String vColorDeptnm;

	@JsonProperty("vSlUserid")
	private String vSlUserid;

	@JsonProperty("vSlUsernm")
	private String vSlUsernm;

	@JsonProperty("vBrdUserid")
	private String vBrdUserid;

	@JsonProperty("vBrdUsernm")
	private String vBrdUsernm;

	@JsonProperty("vBrdDeptcd")
	private String vBrdDeptcd;

	@JsonProperty("vBrdDeptnm")
	private String vBrdDeptnm;

	@JsonProperty("vBrdUsermail")
	private String vBrdUsermail;

	@JsonProperty("vContAllUserids")
	private String vContAllUserids;

	@JsonProperty("vLabPageType")
	private String vLabPageType;

	@JsonProperty("vLotAddType")
	private String vLotAddType;

	@JsonProperty("vTctnBynmNm")
	private String vTctnBynmNm;

	@JsonProperty("vGate0ApprCd")
	private String vGate0ApprCd;

	@JsonProperty("vToningType")
	private String vToningType;

	@JsonProperty("nToning")
	private int nToning;

	@JsonProperty("vToningLotCd")
	private String vToningLotCd;

	@JsonProperty("vLeaveType")
	private String vLeaveType;

	@JsonProperty("vHarmfulCd")
	private String vHarmfulCd;
	
	@JsonProperty("vFlagContUserYn")
	private String vFlagContUserYn;

	private List<ThisInventoryVO> inventoryList;
}
