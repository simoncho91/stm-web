package com.mybeaker.app.dlab.model;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class DiscussionCommentDTO {
	@NotEmpty
	@JsonProperty("vSubRecordid")
	private String vSubRecordid;

	@NotEmpty
	@JsonProperty("vCmntRecordid")
	private String vCmntRecordid;

	@JsonProperty("vComments")
	private String vComments;

	@JsonProperty("vRegUserid")
	private String vRegUserid;

	@JsonProperty("vRegUsernm")
	private String vRegUsernm;

	@JsonProperty("vRegDtm")
	private String vRegDtm;

	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;

	@JsonProperty("vUpdateDtm")
	private String vUpdateDtm;
}
