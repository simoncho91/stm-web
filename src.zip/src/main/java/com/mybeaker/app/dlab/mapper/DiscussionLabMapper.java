package com.mybeaker.app.dlab.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.mybeaker.app.dlab.model.DiscussionAnswerDTO;
import com.mybeaker.app.dlab.model.DiscussionCommentDTO;
import com.mybeaker.app.dlab.model.DiscussionLabDTO;
import com.mybeaker.app.dlab.model.DiscussionLabRegDTO;
import com.mybeaker.app.dlab.model.DiscussionLabTagDTO;
import com.mybeaker.app.model.dto.ReqCommSearchInfoDTO;

@Mapper
public interface DiscussionLabMapper {
	public int selectDiscussionLabListCount(ReqCommSearchInfoDTO reqCommSearchInfoDTO);

	public List<DiscussionLabDTO> selectDiscussionLabList(ReqCommSearchInfoDTO reqCommSearchInfoDTO);

	public DiscussionLabDTO selectDiscussionDetailInfo(String vRecordid, String localLanguage);

	public List<DiscussionAnswerDTO> selectDiscussionAnswerList(String vRecordid, String localLanguage);

	public int selectDiscussionDetailCommentListCount(String vSubRecordid);
	
	public List<DiscussionCommentDTO> selectDiscussionDetailCommentList(String vSubRecordid, String localLanguage);

	public int updateDiscussionLabInfo(DiscussionLabRegDTO discussionLabRegDTO);

	public void deleteDiscussionTagInfo(DiscussionLabRegDTO discussionLabRegDTO);

	public void insertDiscussionLabTag(DiscussionLabTagDTO tagDTO);

	public int insertDiscussionLabInfo(DiscussionLabRegDTO discussionLabRegDTO);

	public int insertDiscussionLabAnswer(DiscussionAnswerDTO answerDTO);
	
	public int updateDiscussionLabAnswer(DiscussionAnswerDTO answerDTO);

	public int insertDiscussionLabComment(DiscussionCommentDTO commentDTO);

	public int deleteDiscussionInfo(DiscussionLabRegDTO regDTO);

	public int deleteDiscussionLabAnswer(DiscussionAnswerDTO answerDTO);

	// 답변 삭제 전 답변에 달린 댓글 전부 V_FLAG_DEL = 'Y' 처리
	public int deleteDiscussionLabCommentAll(DiscussionAnswerDTO answerDTO);
	
	// 낱개 댓글 삭제 처리
	public int deleteDiscussionLabComment(DiscussionCommentDTO commentDTO);

	public int selectDiscussionTagListCount(String vRecordid);
	
	public List<DiscussionLabTagDTO> selectDiscussionTagList(String vRecordid);
	
	public int updateViewCount(String vRecordid);
}
