package com.mybeaker.app.dlab.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class DiscussionLabDTO {
	@JsonProperty("vRecordid")
	private String vRecordid;

	@JsonProperty("vTitle")
	private String vTitle;

	@JsonProperty("vContents")
	private String vContents;

	@JsonProperty("nViewCount")
	private int nViewCount;

	@JsonProperty("vRegUserid")
	private String vRegUserid;

	@JsonProperty("vRegUsernm")
	private String vRegUsernm;

	@JsonProperty("vRegDtm")
	private String vRegDtm;

	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;

	@JsonProperty("vUpdateDtm")
	private String vUpdateDtm;
	
	@JsonProperty("nAnswerCount")
	private String nAnswerCount;
	
	@JsonProperty("tagList")
	private List<DiscussionLabTagDTO> tagList;
}
