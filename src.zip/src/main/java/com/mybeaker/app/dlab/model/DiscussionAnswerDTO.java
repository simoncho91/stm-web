package com.mybeaker.app.dlab.model;

import java.util.List;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class DiscussionAnswerDTO {
	@NotEmpty
	@JsonProperty("vMstRecordid")
	private String vMstRecordid;

	@NotEmpty
	@JsonProperty("vSubRecordid")
	private String vSubRecordid;

	@JsonProperty("vContents")
	private String vContents;

	@JsonProperty("vRegUserid")
	private String vRegUserid;

	@JsonProperty("vRegUsernm")
	private String vRegUsernm;

	@JsonProperty("vRegDtm")
	private String vRegDtm;

	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;

	@JsonProperty("vUpdateDtm")
	private String vUpdateDtm;
	
	@JsonProperty("commentList")
	private List<DiscussionCommentDTO> commentList;
}
