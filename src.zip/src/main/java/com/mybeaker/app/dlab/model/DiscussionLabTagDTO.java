package com.mybeaker.app.dlab.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DiscussionLabTagDTO {
	@JsonProperty("vMstRecordid")
	private String vMstRecordid;

	@JsonProperty("vTagRecordid")
	private String vTagRecordid;

	@JsonProperty("vTagTxt")
	private String vTagTxt;
}
