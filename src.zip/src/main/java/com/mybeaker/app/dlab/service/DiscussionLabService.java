package com.mybeaker.app.dlab.service;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Service;

import com.mybeaker.app.dlab.mapper.DiscussionLabMapper;
import com.mybeaker.app.dlab.model.DiscussionAnswerDTO;
import com.mybeaker.app.dlab.model.DiscussionCommentDTO;
import com.mybeaker.app.dlab.model.DiscussionLabDTO;
import com.mybeaker.app.dlab.model.DiscussionLabRegDTO;
import com.mybeaker.app.dlab.model.DiscussionLabResDTO;
import com.mybeaker.app.dlab.model.DiscussionLabTagDTO;
import com.mybeaker.app.model.Const;
import com.mybeaker.app.model.dto.PagingDTO;
import com.mybeaker.app.model.dto.ReqCommSearchInfoDTO;
import com.mybeaker.app.model.dto.ResCommSearchInfoDTO;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.utils.CommonUtil;
import com.mybeaker.app.utils.ConvertUtil;
import com.mybeaker.app.utils.SessionUtil;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class DiscussionLabService {
	private final SessionUtil sessionUtil;

	private final DiscussionLabMapper discussionLabMapper;

	public ResponseVO selectDiscussionLabList(ReqCommSearchInfoDTO reqCommSearchInfoDTO) {
		ResponseVO responseVO = new ResponseVO();

		int totalCnt = discussionLabMapper.selectDiscussionLabListCount(reqCommSearchInfoDTO);
		List<DiscussionLabDTO> list = null;

		CommonUtil.setPaging(reqCommSearchInfoDTO, totalCnt);

		if (totalCnt > 0) {
			list = discussionLabMapper.selectDiscussionLabList(reqCommSearchInfoDTO);
			
			if (!ObjectUtils.isEmpty(list)) {
				for (DiscussionLabDTO dto : list) {
					String vRecordid = dto.getVRecordid();
					
					dto.setTagList(discussionLabMapper.selectDiscussionTagList(vRecordid));
				}
			}
		}

		PagingDTO page = ConvertUtil.convert(reqCommSearchInfoDTO, PagingDTO.class);

		responseVO.setOk(ResCommSearchInfoDTO.builder()
											.page(page)
											.list(list)
											.build());
		return responseVO;
	}

	@Transactional
	public ResponseVO insertDiscussionLabInfo (DiscussionLabRegDTO discussionLabRegDTO) {
		ResponseVO responseVO = new ResponseVO();

		discussionLabRegDTO.setVRegUserid(sessionUtil.getLoginId());
		discussionLabRegDTO.setVUpdateUserid(sessionUtil.getLoginId());

		int result = discussionLabMapper.insertDiscussionLabInfo(discussionLabRegDTO);

		if (result > 0) {
			if (discussionLabRegDTO.getTagList() != null && !discussionLabRegDTO.getTagList().isEmpty()) {
				for (DiscussionLabTagDTO tagDTO : discussionLabRegDTO.getTagList()) {
					tagDTO.setVMstRecordid(discussionLabRegDTO.getVRecordid());
					discussionLabMapper.insertDiscussionLabTag(tagDTO);
				}
			}
		}

		responseVO.setOk(result > 0 ? Const.SUCC : Const.FAIL);
		return responseVO;
	}

	@Transactional
	public ResponseVO updateDiscussionLabInfo (DiscussionLabRegDTO discussionLabRegDTO) {
		ResponseVO responseVO = new ResponseVO();

		discussionLabRegDTO.setVRegUserid(sessionUtil.getLoginId());
		discussionLabRegDTO.setVUpdateUserid(sessionUtil.getLoginId());

		int result = discussionLabMapper.updateDiscussionLabInfo(discussionLabRegDTO);

		if (result > 0) {
			discussionLabMapper.deleteDiscussionTagInfo(discussionLabRegDTO);

			if (discussionLabRegDTO.getTagList() != null && !discussionLabRegDTO.getTagList().isEmpty()) {
				for (DiscussionLabTagDTO tagDTO : discussionLabRegDTO.getTagList()) {
					tagDTO.setVMstRecordid(discussionLabRegDTO.getVRecordid());
					discussionLabMapper.insertDiscussionLabTag(tagDTO);
				}
			}
		}

		responseVO.setOk(result > 0 ? Const.SUCC : Const.FAIL);
		return responseVO;
	}

	@Transactional
	public ResponseVO insertDiscussionLabAnswer (DiscussionAnswerDTO answerDTO) {
		ResponseVO responseVO = new ResponseVO();

		answerDTO.setVRegUserid(sessionUtil.getLoginId());
		answerDTO.setVUpdateUserid(sessionUtil.getLoginId());

		int result = discussionLabMapper.insertDiscussionLabAnswer(answerDTO);

		responseVO.setOk(result > 0 ? Const.SUCC : Const.FAIL);
		return responseVO;
	}
	
	@Transactional
	public ResponseVO updateDiscussionLabAnswer (DiscussionAnswerDTO answerDTO) {
		ResponseVO responseVO = new ResponseVO();
		
		answerDTO.setVUpdateUserid(sessionUtil.getLoginId());
		
		int result = discussionLabMapper.updateDiscussionLabAnswer(answerDTO);
		
		responseVO.setOk(result > 0 ? Const.SUCC : Const.FAIL);
		return responseVO;
	}

	@Transactional
	public ResponseVO insertDiscussionLabComment (DiscussionCommentDTO commentDTO) {
		ResponseVO responseVO = new ResponseVO();

		commentDTO.setVRegUserid(sessionUtil.getLoginId());
		commentDTO.setVUpdateUserid(sessionUtil.getLoginId());

		int result = discussionLabMapper.insertDiscussionLabComment(commentDTO);

		responseVO.setOk(result > 0 ? Const.SUCC : Const.FAIL);
		return responseVO;
	}

	@Transactional
	public ResponseVO deleteDiscussionInfo(DiscussionLabRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();
		
		regDTO.setVUpdateUserid(sessionUtil.getLoginId());
		
		if (!ObjectUtils.isEmpty(regDTO.getAnswerList())) {
			for (DiscussionAnswerDTO answerDTO : regDTO.getAnswerList()) {
				answerDTO.setVUpdateUserid(sessionUtil.getLoginId());
				
				if (!ObjectUtils.isEmpty(answerDTO.getCommentList())) {
					discussionLabMapper.deleteDiscussionLabCommentAll(answerDTO);
				}
				
				discussionLabMapper.updateDiscussionLabAnswer(answerDTO);
			}
		}
		
		if (!ObjectUtils.isEmpty(regDTO.getTagList())) {
			discussionLabMapper.deleteDiscussionTagInfo(regDTO);
		}

		int result = discussionLabMapper.deleteDiscussionInfo(regDTO);

		responseVO.setOk(result > 0 ? Const.SUCC : Const.FAIL);
		return responseVO;
	}

	@Transactional
	public ResponseVO deleteDiscussionLabAnswer (DiscussionAnswerDTO answerDTO) {
		ResponseVO responseVO = new ResponseVO();
		
		answerDTO.setVUpdateUserid(sessionUtil.getLoginId());
		
		if (!ObjectUtils.isEmpty(answerDTO.getCommentList())) {
			discussionLabMapper.deleteDiscussionLabCommentAll(answerDTO);
		}

		int result = discussionLabMapper.deleteDiscussionLabAnswer(answerDTO);

		responseVO.setOk(result > 0 ? Const.SUCC : Const.FAIL);
		return responseVO;
	}

	@Transactional
	public ResponseVO deleteDiscussionLabComment (DiscussionCommentDTO commentDTO) {
		ResponseVO responseVO = new ResponseVO();
		
		commentDTO.setVUpdateUserid(sessionUtil.getLoginId());

		int result = discussionLabMapper.deleteDiscussionLabComment(commentDTO);

		responseVO.setOk(result > 0 ? Const.SUCC : Const.FAIL);
		return responseVO;
	}

	@Transactional
	public ResponseVO selectDiscussionLabInfo (String vRecordid) {
		ResponseVO responseVO = new ResponseVO();
		
		discussionLabMapper.updateViewCount(vRecordid);

		DiscussionLabDTO mstVo = discussionLabMapper.selectDiscussionDetailInfo(vRecordid, sessionUtil.getLocalLanguage());
		List<DiscussionAnswerDTO> answerList = discussionLabMapper.selectDiscussionAnswerList(vRecordid, sessionUtil.getLocalLanguage());
		
		if(!ObjectUtils.isEmpty(answerList)) {
			String localLanguage = sessionUtil.getLocalLanguage();
			
			for (DiscussionAnswerDTO dto : answerList) {
				String vSubRecordid = dto.getVSubRecordid();
				
				dto.setCommentList(discussionLabMapper.selectDiscussionDetailCommentList(vSubRecordid, localLanguage));
			}
		}
		
		List<DiscussionLabTagDTO> tagList = discussionLabMapper.selectDiscussionTagList(vRecordid);

		responseVO.setOk(DiscussionLabResDTO.builder()
									.mstVo(mstVo)
									.answerList(answerList)
									.tagList(tagList)
									.build());
		return responseVO;
	}

	public ResponseVO selectDiscussionDetailCommentList(String vSubRecordid) {
		ResponseVO responseVO = new ResponseVO();

		List<DiscussionCommentDTO> list = discussionLabMapper.selectDiscussionDetailCommentList(vSubRecordid, sessionUtil.getLocalLanguage());

		responseVO.setOk(list);
		return responseVO;
	}
}
