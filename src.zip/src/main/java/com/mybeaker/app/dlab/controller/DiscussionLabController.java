package com.mybeaker.app.dlab.controller;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mybeaker.app.dlab.model.DiscussionAnswerDTO;
import com.mybeaker.app.dlab.model.DiscussionCommentDTO;
import com.mybeaker.app.dlab.model.DiscussionLabRegDTO;
import com.mybeaker.app.dlab.service.DiscussionLabService;
import com.mybeaker.app.model.dto.ReqCommSearchInfoDTO;
import com.mybeaker.app.model.vo.ResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Tag(name = "Discussion Lab", description = "Discussion Lab")
@RestController
@RequestMapping("/api/labnote/dlab")
public class DiscussionLabController {
	private final DiscussionLabService discussionLabService;

	@Operation(summary = "Discussion lab 게시판 목록", description = "Discussion lab 목록을 조회한다. (화면ID : SC-PA-074)")
	@GetMapping("/select-discussionlab-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectDiscussionList (
			ReqCommSearchInfoDTO reqCommSearchInfoDTO
			) {
		log.debug("DiscussionLabController.selectDiscussionList => params : { ReqCommSearchInfoDTO: {} }", reqCommSearchInfoDTO.toString());
		return ResponseEntity.ok(discussionLabService.selectDiscussionLabList(reqCommSearchInfoDTO));
	}

	@Operation(summary = "Discussion lab 상세", description = "Discussion lab 상세를 조회한다.")
	@GetMapping("/select-discussionlab-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectDiscussionLabInfo (
			@RequestParam(value = "vRecordid") String vRecordid
			) {
		log.debug("DiscussionLabController.selectDiscussionLabInfo => params : { vRecordid: {} }", vRecordid);
		return ResponseEntity.ok(discussionLabService.selectDiscussionLabInfo(vRecordid));
	}

	@Operation(summary = "Discussion lab 질문 저장", description = "Discussion lab 질문 저장한다.")
	@PostMapping("/insert-discussionlab-info")
	public @ResponseBody ResponseEntity<ResponseVO> insertDiscussionLabInfo (
			@RequestBody DiscussionLabRegDTO regDTO
			) {
		log.debug("DiscussionLabController.insertDiscussionLabInfo => params : { DiscussionLabRegDTO: {} }", regDTO);
		return ResponseEntity.ok(discussionLabService.insertDiscussionLabInfo(regDTO));
	}

	@Operation(summary = "Discussion lab 질문 수정", description = "Discussion lab 질문 수정한다.")
	@PostMapping("/update-discussionlab-info")
	public @ResponseBody ResponseEntity<ResponseVO> updatetDiscussionLabInfo (
			@RequestBody DiscussionLabRegDTO regDTO
			) {
		log.debug("DiscussionLabController.selectDiscussionLabInfo => params : { DiscussionLabRegDTO: {} }", regDTO);
		return ResponseEntity.ok(discussionLabService.updateDiscussionLabInfo(regDTO));
	}

	@Operation(summary = "Discussion lab 답변 저장", description = "Discussion lab 답변 저장한다.")
	@PostMapping("/insert-discussionlab-answer")
	public @ResponseBody ResponseEntity<ResponseVO> insertDiscussionLabAnswer (
			@RequestBody DiscussionAnswerDTO answerDTO) {
		log.debug("DiscussionLabController.insertDiscussionLabAnswer => params : { DiscussionAnswerDTO: {} }", answerDTO);
		return ResponseEntity.ok(discussionLabService.insertDiscussionLabAnswer(answerDTO));
	}
	
	@Operation(summary = "Discussion lab 답변 수정", description = "Discussion lab 답변 수정한다.")
	@PostMapping("/update-discussionlab-answer")
	public @ResponseBody ResponseEntity<ResponseVO> updateDiscussionLabAnswer (
			@RequestBody DiscussionAnswerDTO answerDTO) {
		log.debug("DiscussionLabController.updateDiscussionLabAnswer => params : { DiscussionAnswerDTO: {} }", answerDTO);
		return ResponseEntity.ok(discussionLabService.updateDiscussionLabAnswer(answerDTO));
	}

	@Operation(summary = "Discussion lab 댓글 저장", description = "Discussion lab 댓글 저장한다.")
	@PostMapping("/insert-discussionlab-comment")
	public @ResponseBody ResponseEntity<ResponseVO> insertDiscussionLabComment (
			@RequestBody DiscussionCommentDTO commentDTO) {
		log.debug("DiscussionLabController.insertDiscussionLabComment => params : { DiscussionCommentDTO: {} }", commentDTO);
		return ResponseEntity.ok(discussionLabService.insertDiscussionLabComment(commentDTO));
	}

	@Operation(summary = "Discussion lab 질문 삭제", description = "Discussion lab 질문 삭제한다.")
	@PostMapping("/delete-discussionlab-info")
	public @ResponseBody ResponseEntity<ResponseVO> deleteDiscussionInfo (
			@RequestBody @Valid DiscussionLabRegDTO regDTO) {
		log.debug("DiscussionLabController.deleteDiscussionInfo => params : { DiscussionLabRegDTO: {} }", regDTO);
		return ResponseEntity.ok(discussionLabService.deleteDiscussionInfo(regDTO));
	}

	@Operation(summary = "Discussion lab 답변 삭제", description = "Discussion lab 답변 삭제한다.")
	@PostMapping("/delete-discussionlab-answer")
	public @ResponseBody ResponseEntity<ResponseVO> deleteDiscussionLabAnswer (
			@RequestBody @Valid DiscussionAnswerDTO answerDTO) {
		log.debug("DiscussionLabController.deleteDiscussionLabAnswer => params : { DiscussionAnswerDTO: {} }", answerDTO);
		return ResponseEntity.ok(discussionLabService.deleteDiscussionLabAnswer(answerDTO));
	}

	@Operation(summary = "Discussion lab 댓글 삭제", description = "Discussion lab 댓글 삭제한다.")
	@PostMapping("/delete-discussionlab-comment")
	public @ResponseBody ResponseEntity<ResponseVO> deleteDiscussionLabComment (
			@RequestBody @Valid DiscussionCommentDTO commentDTO) {
		log.debug("DiscussionLabController.deleteDiscussionLabComment => params : { DiscussionCommentDTO: {} }", commentDTO);
		return ResponseEntity.ok(discussionLabService.deleteDiscussionLabComment(commentDTO));
	}

	@Operation(summary = "Discussion lab 상세 댓글", description = "Discussion lab 상세 댓글을 조회한다.")
	@GetMapping("/select-disc-detail-comment-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectDiscussionDetailCommentList (
			@RequestParam(value="vSubRecordid") String vSubRecordid) {
		log.debug("DiscussionLabController.selectDiscussionDetailCommentList => params : { vSubRecordid: {} }", vSubRecordid);
		return ResponseEntity.ok(discussionLabService.selectDiscussionDetailCommentList(vSubRecordid));
	}
}
