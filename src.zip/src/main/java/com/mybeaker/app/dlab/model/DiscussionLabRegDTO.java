package com.mybeaker.app.dlab.model;

import java.util.List;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class DiscussionLabRegDTO {

	@NotEmpty
	@JsonProperty("vRecordid")
	private String vRecordid;

	@JsonProperty("vTitle")
	private String vTitle;

	@JsonProperty("vContents")
	private String vContents;

	@JsonProperty("vNoteType")
	private String vNoteType;

	@JsonProperty("nViewCount")
	private int nViewCount;

	@JsonProperty("vRegUserid")
	private String vRegUserid;

	@JsonProperty("vRegDtm")
	private String vRegDtm;

	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;

	@JsonProperty("vUpdateDtm")
	private String vUpdateDtm;
	
	@JsonProperty("answerList")
	private List<DiscussionAnswerDTO> answerList;
	
	@JsonProperty("tagList")
	private List<DiscussionLabTagDTO> tagList;

}
