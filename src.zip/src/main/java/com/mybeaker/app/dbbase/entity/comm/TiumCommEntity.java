package com.mybeaker.app.dbbase.entity.comm;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

import lombok.Getter;

@MappedSuperclass
@Getter
public abstract class TiumCommEntity {
	@Column(name="v_reg_userid")
	private String regUserId;
	
	@Column(name="v_reg_dtm")
	private String regDtm;
	
	@Column(name="v_update_userid")
	private String updUserId;
	
	@Column(name="v_update_dtm")
	private String updDtm;
}
