package com.mybeaker.app.dbbase.repo.user;

import java.sql.Timestamp;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.repository.CrudRepository;

import com.mybeaker.app.dbbase.entity.user.UserTokenEntity;

public interface UserTokenRepo extends CrudRepository<UserTokenEntity, String> {
	List<UserTokenEntity> findByUserCd(String userCd);
	
	@Transactional
	int deleteByExpireDtmLessThan(Timestamp expireDtm);
	
	@Transactional
	int deleteByUserCd(String userCd);
}
