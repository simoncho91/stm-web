package com.mybeaker.app.dbbase.entity.comm;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@Table(name = "cm_mail_file")
@IdClass(MailFileEntity.Pk.class)
@Builder
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class MailFileEntity implements Serializable {

	private static final long serialVersionUID = -5327799511625190154L;

	@Id
	@Column(name="v_mailcd")
	private String mailcd;
	
	@Id
	@Column(name="n_seqno")
	private int seqno;
	
	@Column(name="v_file")
	private String file;
	
	@Column(name="v_file_path")
	private String filePath;

	@Column(name="v_reg_userid", updatable = false)
	private String regUserid;
	
    @Column(name="v_reg_dtm", updatable = false)
    @CreatedDate
    private String regDtm;
    
    @PrePersist
    public void onPrePersist(){
    	this.regDtm = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
    }

    @Data
    @Builder
    @AllArgsConstructor(access = AccessLevel.PACKAGE)
    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class Pk implements Serializable {

		private static final long serialVersionUID = -2806308295050865512L;

		private String mailcd;

        private int seqno;
    }        
}
