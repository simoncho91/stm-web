package com.mybeaker.app.dbbase.repo.comm;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mybeaker.app.dbbase.entity.comm.MailFileEntity;

@Repository
public interface MailFileRepo extends CrudRepository<MailFileEntity, String> {

}
