package com.mybeaker.app.dbbase.repo.user;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mybeaker.app.dbbase.entity.user.UserLoginLogEntity;

@Repository
public interface UserLoginLogRepo extends CrudRepository<UserLoginLogEntity, Long> {

}