package com.mybeaker.app.dbbase.entity.user;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @AllArgsConstructor, @NoArgsConstructor 사용하는 이유
 * jpa에서는 기본적으로 기본 생성자를 필요로 한다. 하지만 데이터를 주입받기 위해서는 모든 값을 받아내는 생성자가 필요하다.
 * AllArgsConstructor 이 부분이 그 역할을 하고 이 생성자 때문에 기본 생성자가 생성되지 않기 때문에 NoArgsConstructor 사용한다.
 * 기본적으로 Entity 와 Builder 안에는 생성자를 만들어주고 있으나 이 부분 역시 AllArgsConstructor 이 때문에 생성되지 않는다.
 * 연속성 컨텍스트 및 객체의 일관성을 유지하기 위해서 최대한 setter는 지향하고 setter 처럼 사용하고 싶으면 method에 의도를 표현해 생성해서 주입시키는 방법을 사용해야 한다.
 */
@Entity
@Getter
@Setter
@Table(name = "user_mst_bkr")
@Builder
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class UserEntity {

	@Id
	@GenericGenerator(name = "user_cd", strategy = "com.mybeaker.app.utils.CustomIdGenerator",
	parameters = {@Parameter(name = "seqName", value = "USER_MST_BKR_SEQ")})
	@GeneratedValue(generator = "user_cd")
	private String userCd;

	private String loginId;
	
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="ASIA/Seoul")
	@CreationTimestamp
	private Timestamp lastLoginDt;
	
	private int pwFailCnt;
}