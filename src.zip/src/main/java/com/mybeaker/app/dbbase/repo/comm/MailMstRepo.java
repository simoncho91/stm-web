package com.mybeaker.app.dbbase.repo.comm;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mybeaker.app.dbbase.entity.comm.MailMstEntity;

@Repository
public interface MailMstRepo extends CrudRepository<MailMstEntity, String> {

}
