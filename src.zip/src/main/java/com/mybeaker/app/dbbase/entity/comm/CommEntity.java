package com.mybeaker.app.dbbase.entity.comm;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;

/**
 * 객체 관점에서 상속하기 위해서 entity에 추가적인 데이터를 상속해 주기 위해서
 * @MappedSuperclass를 사용한다.
 * 데이터베이스의 부모,자식을 사용하기 위해서는 @Inheritance 를 사용해야 한다.
 */
@MappedSuperclass
@Getter
public abstract class CommEntity {
	@Column(updatable = false)
	private String regUserId;

	@Column(updatable = false)
	@CreationTimestamp
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="ASIA/Seoul")
	private Timestamp regDtm;

	private String updUserId;

	@UpdateTimestamp
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="ASIA/Seoul")
	private Timestamp updDtm;
}