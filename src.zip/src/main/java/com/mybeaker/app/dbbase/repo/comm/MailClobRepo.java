package com.mybeaker.app.dbbase.repo.comm;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mybeaker.app.dbbase.entity.comm.MailClobEntity;

@Repository
public interface MailClobRepo extends CrudRepository<MailClobEntity, String> {

}
