package com.mybeaker.app.dbbase.entity.comm;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@Table(name = "cm_mail_mst")
@Builder
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class MailMstEntity {

	@Id
    @GenericGenerator(name = "mailcd", strategy = "com.mybeaker.app.utils.CustomIdGenerator",
    parameters = {@Parameter(name = "seqName", value = "CM_MAIL_MST_SEQ"),
    			  @Parameter(name = "prefix", value = "MA"),
    			  @Parameter(name = "digit", value = "14"),
    			  @Parameter(name = "pad", value = "L")})	
	@GeneratedValue(generator = "mailcd")	
	@Column(name="v_mailcd")
	private String mailcd;
	
	@Column(name="v_langcd")
	private String langcd;
	
	@Column(name="v_status_cd")
	private String statusCd;
	
	@Column(name="v_typecd")
	private String typecd;
	
	@Column(name="v_userid")
	private String userid;
	
	@Column(name="n_err_cnt")
	private int errCnt;
	
	@Column(name="v_title")
	private String title;
	
	@Column(name="v_from_usernm")
	private String fromUsernm;
	
	@Column(name="v_from_email")
	private String fromEmail;
	
	@Column(name="v_cc_email")
	private String ccEmail;
	
	@Column(name="v_mail_st_dtm")
	private String mailStDtm;
	
	@Column(name="v_flag_file")
	private String flagFile;
	
	@Column(name="v_recordid")
	private String recordid;
	
	@Column(name="v_reg_userid", updatable = false)
	private String regUserid;
	
    @Column(name="v_reg_dtm", updatable = false)
    @CreatedDate
    private String regDtm;	
	
	@Column(name="v_update_userid")
    private String updUserid;
    
    @Column(name="v_update_dtm", updatable = false)
    @LastModifiedDate
    private String updDtm;
    
    @PrePersist
    public void onPrePersist(){
    	this.regUserid = this.regUserid == null ? "sysadmin" : this.regUserid;
    	this.updUserid = this.updUserid == null ? "sysadmin" : this.updUserid;
    	this.mailStDtm = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
    	this.regDtm    = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
    	this.updDtm    = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
    }
    
    @PreUpdate
    public void onPreUpdate(){
    	this.updDtm = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
    }     
}
