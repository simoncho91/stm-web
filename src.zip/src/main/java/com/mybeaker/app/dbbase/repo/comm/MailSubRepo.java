package com.mybeaker.app.dbbase.repo.comm;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mybeaker.app.dbbase.entity.comm.MailSubEntity;

@Repository
public interface MailSubRepo extends CrudRepository<MailSubEntity, String> {

}
