package com.mybeaker.app.dbbase.entity.comm;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@Table(name = "cm_mail_clob")
@Builder
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class MailClobEntity {

	@Id
	@Column(name="v_mailcd")
	private String mailcd;

	@Column(name="v_reg_userid", updatable = false)
	private String regUserid;
	
	@Column(name="v_clob")
	private String clob;
	
    @Column(name="v_reg_dtm", updatable = false)
    @CreatedDate
    private String regDtm;
    
    @PrePersist
    public void onPrePersist(){
    	this.regDtm = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
    }
}
