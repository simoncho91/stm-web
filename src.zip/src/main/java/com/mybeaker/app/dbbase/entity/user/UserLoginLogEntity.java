package com.mybeaker.app.dbbase.entity.user;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Getter
@Table(name = "user_login_log_bkr")
@Builder
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class UserLoginLogEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "UserLoginLogSeq")
	@SequenceGenerator(sequenceName = "USER_LOGIN_LOG_BKR_SEQ", name = "UserLoginLogSeq", allocationSize = 1)
	private long seq;

	private String userCd;

	private String loginId;

	private String loginIp;

	private String flag;

	@CreationTimestamp
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="ASIA/Seoul")
	private Timestamp regDtm;

	public void changeFlag(String flag) {
		this.flag = flag;
	}
}
