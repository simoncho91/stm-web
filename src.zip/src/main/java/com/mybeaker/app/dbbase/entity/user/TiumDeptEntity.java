package com.mybeaker.app.dbbase.entity.user;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.mybeaker.app.dbbase.entity.comm.TiumCommEntity;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Getter
@Table(name = "ssm_sigmadept")
@Builder
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class TiumDeptEntity extends TiumCommEntity{

	@Id
	@Column(name="v_sigma_deptcd")
	private String deptCd;
	
	
	@Column(name="v_sigma_deptnm")
	private String deptNm;
	
	@Column(name="v_flag_use")
	private String flagUse;
}
