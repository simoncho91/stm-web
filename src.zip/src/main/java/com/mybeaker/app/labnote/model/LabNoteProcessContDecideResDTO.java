package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LabNoteProcessContDecideResDTO<T>{
	
	@JsonProperty("rvo")
	private T rvo;
	
	@JsonProperty("verList")
	private List<LabNoteMstVersionDTO> verList;
	
	@JsonProperty("contList")
	private List<LabNoteProcessContDecideListDTO> contList;
	
}
