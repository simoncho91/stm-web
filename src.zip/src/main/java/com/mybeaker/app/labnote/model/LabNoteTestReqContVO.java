package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteTestReqContVO {
	
	@JsonProperty("vContPkCd")
	private String vContPkCd;
	
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("vContCd")
	private String vContCd;
	
	@JsonProperty("vPrdCd")
	private String vPrdCd;
	
	@JsonProperty("vContNm")
	private String vContNm;
	
	@JsonProperty("vContNmEn")
	private String vContNmEn;
	
	@JsonProperty("vContNmCn")
	private String vContNmCn;
	
	@JsonProperty("vPlantCd")
	private String vPlantCd;
	
	@JsonProperty("vFlagRepresent")
	private String vFlagRepresent;
	
	@JsonProperty("vTestReqYn")
	private String vTestReqYn;
	
	@JsonProperty("vLotCd")
	private String vLotCd;
	
	@JsonProperty("nVersion")
	private int nVersion;
	
	@JsonProperty("subList")
	private List<LabNoteTestReqLotVO> subList;
	
	private String vLand1;
	
	@JsonProperty("vLotNm")
	private String vLotNm;
}
