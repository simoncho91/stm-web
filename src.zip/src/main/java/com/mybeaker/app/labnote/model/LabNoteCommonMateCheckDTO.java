package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteCommonMateCheckDTO {
	@JsonProperty("vSapCd")
	private String vSapCd;

	@JsonProperty("vMaterialCd")
	private String vMaterialCd;

	@JsonProperty("vResearchSDt")
	private String vResearchSDt;

	@JsonProperty("vResearchEDt")
	private String vResearchEDt;

	@JsonProperty("vTypeList")
	private String vTypeList;
}
