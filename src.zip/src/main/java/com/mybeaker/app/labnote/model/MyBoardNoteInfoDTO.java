package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class MyBoardNoteInfoDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vBrdNm")
	private String vBrdNm;

	@JsonProperty("vLabTypeCd")
	private String vLabTypeCd;

	@JsonProperty("vBsmUserid")
	private String vBsmUserid;

	@JsonProperty("vBsmUsernm")
	private String vBsmUsernm;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vUsernm")
	private String vUsernm;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vStatusCd")
	private String vStatusCd;

	@JsonProperty("vActiveStatus")
	private String vActiveStatus;

	@JsonProperty("vDeptCd")
	private String vDeptCd;
}
