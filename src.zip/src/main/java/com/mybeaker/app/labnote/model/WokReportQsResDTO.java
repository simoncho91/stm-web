package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class WokReportQsResDTO {

	@JsonProperty("vRecordid")
	private String vRecordid;

	@JsonProperty("vQsType")
	private String vQsType;

	@JsonProperty("vManuMethod")
	private String vManuMethod;

	private String vRegUserid;
}
