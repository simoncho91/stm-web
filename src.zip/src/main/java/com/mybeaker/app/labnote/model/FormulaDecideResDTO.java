package com.mybeaker.app.labnote.model;

import java.util.List;

import com.mybeaker.app.model.dto.PagingDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FormulaDecideResDTO<T> {
	private PagingDTO page;

	private List<?> list;

	private List<?> contList;

	private List<LabNoteMstVersionDTO> verList;

	private T noteInfo;
}
