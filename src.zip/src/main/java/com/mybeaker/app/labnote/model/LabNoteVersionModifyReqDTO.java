package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteVersionModifyReqDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vFlagNewItem")
	private String vFlagNewItem;

	@JsonProperty("vFlagPerfumeNew")
	private String vFlagPerfumeNew;

	@JsonProperty("vPerfumeCd")
	private String vPerfumeCd;

	private String vTumnTnpdChgHistNo;

	private String vNoteType;

	private String vRegUserid;

	private String vUpdateUserid;

	private String vFirstSaveFlag;

	private List<LabNoteCommonRequestMateDTO> newMateList;

	private List<LabNoteCommonRequestMateDTO> perfMateList;

	private List<LabNoteCommonRequestMateDTO> requMateList;
}
