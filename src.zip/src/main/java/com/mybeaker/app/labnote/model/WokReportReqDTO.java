package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class WokReportReqDTO {

	@JsonProperty("vRecordid")
	private String vRecordid;

	@JsonProperty("vApprCd")
	private String vApprCd;

	@JsonProperty("vOdmRecordid")
	private String vOdmRecordid;

	@JsonProperty("vRootDocCls")
	private String vRootDocCls;

	@JsonProperty("vReportFlag")
	private String vReportFlag;
	
	private String localLanguage;
	
	@JsonProperty("vOdmFlag")
	private String vOdmFlag;
	
	@JsonProperty("vOdmApprFlag")
	private String vOdmApprFlag;
	
	@JsonProperty("vPageCd")
	private String vPageCd;
	
	@JsonProperty("vViewFlag")
	private String vViewFlag;
	
	@JsonProperty("vAppointType")
	private String vAppointType;
	
	@JsonProperty("vBusinessCd")
	private String vBusinessCd;
	
	@JsonProperty("vLabNoteCd") 
	private String vLabNoteCd;
	  
	@JsonProperty("vNoteType") 
	private String vNoteType;
	
}
