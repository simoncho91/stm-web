package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteCommonReqSAPSyncDTO {
	@JsonProperty("vContCd")
	private String vContCd;
	
	@JsonProperty("vPlantCd")
	private String vPlantCd;
}
