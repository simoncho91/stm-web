package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class Zplmt12GlbVO {

	@JsonProperty("vConcd")
	private String vConcd;

	@JsonProperty("vCasno")
	private String vCasno;

	@JsonProperty("vGcode")
	private String vGcode;

	@JsonProperty("vGban")
	private String vGban;

	@JsonProperty("vGband")
	private String vGband;

	@JsonProperty("vGlmt")
	private String vGlmt;

	@JsonProperty("vGlmtd")
	private String vGlmtd;

	@JsonProperty("vGlper")
	private String vGlper;

	@JsonProperty("vGctxt")
	private String vGctxt;

	@JsonProperty("vConnm")
	private String vConnm;
}
