package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LabNotePqcResItemListDTO {
	
	@JsonProperty("vPqcResItemCd")
	private String vPqcResItemCd;
	
	@JsonProperty("vPqcResCd")
	private String vPqcResCd;
	
	@JsonProperty("vPqcItemCd")
	private String vPqcItemCd;
	
	@JsonProperty("vChoiceVal01")
	private String vChoiceVal01;
	
	@JsonProperty("vChoiceVal02")
	private String vChoiceVal02;
	
	@JsonProperty("vChoiceVal03")
	private String vChoiceVal03;
	
	@JsonProperty("vChoiceVal04")
	private String vChoiceVal04;
	
	@JsonProperty("vChoiceVal05")
	private String vChoiceVal05;
	
	@JsonProperty("vChoiceVal06")
	private String vChoiceVal06;
	
	@JsonProperty("vChoiceVal07")
	private String vChoiceVal07;
	
	@JsonProperty("vTextVal01")
	private String vTextVal01;
	
	@JsonProperty("vTextVal02")
	private String vTextVal02;
	
	@JsonProperty("vTextVal03")
	private String vTextVal03;
	
	@JsonProperty("vTextVal04")
	private String vTextVal04;
	
	@JsonProperty("vTextVal05")
	private String vTextVal05;
	
	@JsonProperty("vTextVal06")
	private String vTextVal06;
	
	@JsonProperty("vTextVal07")
	private String vTextVal07;
	
	@JsonProperty("vChoiceTextVal01")
	private String vChoiceTextVal01;
	
	@JsonProperty("vChoiceTextVal02")
	private String vChoiceTextVal02;
	
	@JsonProperty("vChoiceTextVal03")
	private String vChoiceTextVal03;
	
	@JsonProperty("vChoiceTextVal04")
	private String vChoiceTextVal04;
	
	@JsonProperty("vChoiceTextVal05")
	private String vChoiceTextVal05;
	
	@JsonProperty("vChoiceTextVal06")
	private String vChoiceTextVal06;
	
	@JsonProperty("vChoiceTextVal07")
	private String vChoiceTextVal07;
	
	@JsonProperty("vBufferVal01")
	private String vBufferVal01;
	
	@JsonProperty("vBufferVal02")
	private String vBufferVal02;
	
	@JsonProperty("vBufferVal03")
	private String vBufferVal03;

	@JsonProperty("vBufferVal04")
	private String vBufferVal04;
	
	@JsonProperty("vBufferVal05")
	private String vBufferVal05;
	
	@JsonProperty("vBufferVal06")
	private String vBufferVal06;
	
	@JsonProperty("vBufferVal07")
	private String vBufferVal07;
	
	@JsonProperty("vFlagObey")
	private String vFlagObey;
	
	@JsonProperty("vKey")
	private String vKey;
	
	@JsonProperty("vFlagDel")
	private String vFlagDel;
	
	@JsonProperty("vRegUserid")
	private String vRegUserid;
	
	@JsonProperty("vRegDtm")
	private String vRegDtm;
	
	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;
	
	@JsonProperty("vUpdateDtm")
	private String vUpdateDtm;
}
