package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class MyBoardStateReqDTO {
	private String localLanguage;

	private String vDeptCd;

	@JsonProperty("vStartYm")
	private String vStartYm;

	@JsonProperty("vEndYm")
	private String vEndYm;
}
