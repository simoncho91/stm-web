package com.mybeaker.app.labnote.model;

import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@Data
public class ElabHisLotChgVO extends ParentDTO {

	private String vLotCd;
	
	private String vNoteType;

	private String vUserAgent;

	@Builder
	public ElabHisLotChgVO(String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm, String vLotCd,
			String vNoteType, String vUserAgent) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.vLotCd = vLotCd;
		this.vNoteType = vNoteType;
		this.vUserAgent = vUserAgent;
	}
}
