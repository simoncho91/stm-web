package com.mybeaker.app.labnote.model;

import java.util.List;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.makeup.model.MuNoteMayContainInfoVO;
import com.mybeaker.app.makeup.model.MuSapBomMayContainConVO;

import lombok.Data;

@Data
public class LabNoteProcessIngrdApprRegDTO {
	@NotEmpty
	@JsonProperty("vLeaveType")
	private String vLeaveType;
	
	@NotEmpty
	@JsonProperty("vContPkCd")
	private String vContPkCd;
	
	@NotEmpty
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
//	@JsonProperty("vLand")
//	private String vLand;
//	
//	@JsonProperty("vNoteType")
//	private String vNoteType;
	
	@JsonProperty("ingrdApprInfo")
	private Zplmt14VO ingrdApprInfo;
	
	@JsonProperty("ingrdRateList")
	private List<Zplmt13VO> ingrdRateList;
	
	@JsonProperty("mcList")
	private List<MuSapBomMayContainConVO> mcList;
	
	@JsonProperty("mvo")
	private MuNoteMayContainInfoVO mvo;
	
	@JsonProperty("vSuccessionCd")
	private String vSuccessionCd;
}
