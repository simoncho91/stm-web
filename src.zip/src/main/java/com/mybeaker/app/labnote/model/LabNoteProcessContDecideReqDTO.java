package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LabNoteProcessContDecideReqDTO{
	
	@JsonProperty("vNoteType")
	private String vNoteType;
	
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("nVersion")
	private int nVersion;
	
	@JsonProperty("arrContPkCd")
	private String[] arrContPkCd;
	
	private String localLanguage;
	
	@JsonProperty("vPqcGate1ResCd")
	private String vPqcGate1ResCd;
	
	@JsonProperty("vFlagEndAppr")
	private String vFlagEndAppr;
	
	@JsonProperty("vApprCd")
	private String vApprCd;
	
	@JsonProperty("arrLotCd")
	private String[] arrLotCd;
	
}
