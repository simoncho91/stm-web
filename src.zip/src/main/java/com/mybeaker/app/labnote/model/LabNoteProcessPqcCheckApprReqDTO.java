package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.approval.model.ReqResApprovalDTO;
import com.mybeaker.app.common.model.OrganizationDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LabNoteProcessPqcCheckApprReqDTO {

	private String localLanguage;

	@JsonProperty("vNoteType")
	private String vNoteType;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vRecordid")
	private String vRecordid;

	@JsonProperty("vRegUserid")
	private String vRegUserid;

	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;

	@JsonProperty("arrContCd")
	private String [] arrContCd;

	@JsonProperty("arrContPkCd")
	private String [] arrContPkCd;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("arrLotCd")
	private String [] arrLotCd;

	@JsonProperty("arrLotNm")
	private String [] arrLotNm;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("vLotNm")
	private String vLotNm;

	@JsonProperty("vPqcGateCd")
	private String vPqcGateCd;

	@JsonProperty("vPqcGate1ResCd")
	private String vPqcGate1ResCd;

	@JsonProperty("vApprovalYn")
	private String vApprovalYn;

	@JsonProperty("vApprCd")
	private String vApprCd;

	@JsonProperty("vApprTypeCd")
	private String vApprTypeCd;

	@JsonProperty("apprReqInfo")
	private ReqResApprovalDTO apprReqInfo;

	@JsonProperty("vPqcResCd")
	private String vPqcResCd;

	@JsonProperty("nPqcObeyPer")
	private double nPqcObeyPer;

	@JsonProperty("vPqcUserComment")
	private String vPqcUserComment;

	@JsonProperty("pqcCheckList")
	private List<LabNotePqcGateCheckListDTO> pqcCheckList;

	@JsonProperty("vPqcLotCd")
	private String vPqcLotCd;

	@JsonProperty("vPqcContPkCd")
	private String vPqcContPkCd;

	private List<ElabShelflifeContVO> shelfLifeList;

	private List<OrganizationDTO> referenceList;
}
