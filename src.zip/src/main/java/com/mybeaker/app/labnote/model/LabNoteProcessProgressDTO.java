package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteProcessProgressDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vStatusCd")
	private String vStatusCd;

	@JsonProperty("vStatusNm")
	private String vStatusNm;

	@JsonProperty("vTimeStDt")
	private String vTimeStDt;

	@JsonProperty("vSchdStDt")
	private String vSchdStDt;

	@JsonProperty("vCurrStatMark")
	private String vCurrStatMark;

	@JsonProperty("vTabId")
	private String vTabId;

	@JsonProperty("vFlagFuncTest")
	private String vFlagFuncTest;
}
