package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteCommonTddProdTypeDTO {
	@JsonProperty("nLevel")
	private int nLevel;

	@JsonProperty("vClassCd")
	private String vClassCd;

	@JsonProperty("vUclassCd")
	private String vUclassCd;

	@JsonProperty("vClassNm")
	private String vClassNm;

	@JsonProperty("nIsleaf")
	private String nIsleaf;

	@JsonProperty("vBuffer1")
	private String vBuffer1;
}
