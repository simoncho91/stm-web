package com.mybeaker.app.labnote.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mybeaker.app.labnote.model.AttachUploadRegDTO;
import com.mybeaker.app.labnote.model.ElabChgLogSearchReqDTO;
import com.mybeaker.app.labnote.model.Hal4MateRegDTO;
import com.mybeaker.app.labnote.model.LabNoteAuthorityReqDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonAuthDeptRegDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonEvalMaterialDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonEvaluationDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonProdSearchDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonProjectDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonRecentDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonReqEvalMateSearchDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonReqProdSearchDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonReqProjectSearchDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonReqSafetyContentsSearchDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonReqSearchEvalDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonReqSearchMateDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonReqShelflifeDTO;
import com.mybeaker.app.labnote.model.LabNoteCommonSearchMateDTO;
import com.mybeaker.app.labnote.model.MaterialMateRegDTO;
import com.mybeaker.app.labnote.model.MaxMixVO;
import com.mybeaker.app.labnote.model.MdlReqDTO;
import com.mybeaker.app.labnote.model.MyBoardMemoDTO;
import com.mybeaker.app.labnote.model.ProductVO;
import com.mybeaker.app.labnote.model.SapRefreshMatnrRegDTO;
import com.mybeaker.app.labnote.model.SapRepeatRegDTO;
import com.mybeaker.app.labnote.model.ScmTCodeReqVO;
import com.mybeaker.app.labnote.model.Zplmt12ReqVO;
import com.mybeaker.app.labnote.service.LabNoteCommonService;
import com.mybeaker.app.model.dto.PagingDTO;
import com.mybeaker.app.model.dto.ResCommSearchInfoDTO;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.skincare.model.ShelfLifeReqDTO;
import com.mybeaker.app.utils.CommonUtil;
import com.mybeaker.app.utils.ConvertUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Tag(name = "myBeaker 공통 팝업 및 모듈 api", description="myBeaker 공통 팝업 및 모듈 api")
@RestController
@RequestMapping("/api/labcommon")
@RequiredArgsConstructor
public class LabNoteCommonController {
	private final LabNoteCommonService labNoteCommonService;

	@Operation(summary = "예산 검색", description = "과제 예산 리스트를 조회한다.(화면ID : SC-PO-004)")
	@GetMapping("/select-pts-pjt-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectPtsProjectList (
			LabNoteCommonReqProjectSearchDTO reqProjectSearchDTO
			) {
		ResponseVO responseVO = new ResponseVO();

		log.debug("LabNoteCommonController.selectPtsProjectList : {}", reqProjectSearchDTO);

		int totalCnt = labNoteCommonService.selectPtsProjectListCount(reqProjectSearchDTO);
		List<LabNoteCommonProjectDTO> list = null;
		CommonUtil.setPaging(reqProjectSearchDTO, totalCnt);

		if (totalCnt > 0) {
			list = labNoteCommonService.selectPtsProjectList(reqProjectSearchDTO);
		}

		PagingDTO page = ConvertUtil.convert(reqProjectSearchDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
									.page(page)
									.list(list)
									.build();

		responseVO.setOk(res);
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "원료 검색 - SAP코드 검색", description = "원료 검색 - SAP 코드 리스트를 조회한다. (화면ID : SC-PO-012)")
	@GetMapping("/select-search-mate-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectSearchMateList (
			LabNoteCommonReqSearchMateDTO labNoteCommonReqSearchMateDTO
			) {
		ResponseVO responseVO = new ResponseVO();

		log.debug("LabNoteCommonController.selectSearchMateList : {}", labNoteCommonReqSearchMateDTO);

		int totalCnt = 0;
		List<LabNoteCommonSearchMateDTO> list = null;
		List<String> keywordList = new ArrayList<>();

		if(StringUtils.isNotEmpty(labNoteCommonReqSearchMateDTO.getArrKeyword())) {
			totalCnt = 1;
			keywordList = Arrays.asList(labNoteCommonReqSearchMateDTO.getArrKeyword().split(",")).stream()
					.map(o -> o.trim())
					.collect(Collectors.toList());
			labNoteCommonReqSearchMateDTO.setKeywordList(keywordList);
		}
		else {
			totalCnt = labNoteCommonService.selectSearchMateListCount(labNoteCommonReqSearchMateDTO);
		}

		CommonUtil.setPaging(labNoteCommonReqSearchMateDTO, totalCnt);

		if (totalCnt > 0) {
			list = labNoteCommonService.selectSearchMateList(labNoteCommonReqSearchMateDTO);
			
			if(!ObjectUtils.isEmpty(keywordList)) {
				List<LabNoteCommonSearchMateDTO> mateList = new ArrayList<>();
				
				for(String key : keywordList) {
					for(LabNoteCommonSearchMateDTO mate : list) {
						if(key.equals(mate.getVMateCd())) {
							mateList.add(mate);
						}
					}
				}
				
				if(!mateList.isEmpty()) {
					list = new ArrayList<>();
					list = mateList;
				}
			}
		}

		PagingDTO page = ConvertUtil.convert(labNoteCommonReqSearchMateDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
										.page(page)
										.list(list)
										.build();

		responseVO.setOk(res);
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "원료 검색 - SAP코드 검색 (자동완성)", description = "원료 검색 - SAP 코드 리스트를 조회한다. (화면ID : SC-PO-012)")
	@GetMapping("/select-search-mate-autocomplete-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectSearchMateAutocompleteList (
			LabNoteCommonReqSearchMateDTO labNoteCommonReqSearchMateDTO
			) {
		ResponseVO responseVO = new ResponseVO();

		log.debug("LabNoteCommonController.selectSearchMateAutocompleteList : {}", labNoteCommonReqSearchMateDTO);

		responseVO.setOk(labNoteCommonService.selectSearchMateAutocompleteList(labNoteCommonReqSearchMateDTO));
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "원료 검색 - 임시코드 검색", description = "원료 검색 - 임시코드 리스트를 조회한다. (화면ID : SC-PO-012)")
	@GetMapping("/select-search-mate-temp-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectSearchMateTempList (
			LabNoteCommonReqSearchMateDTO labNoteCommonReqSearchMateDTO
			) {
		ResponseVO responseVO = new ResponseVO();

		log.debug("LabNoteCommonController.selectSearchMateTempList : {}", labNoteCommonReqSearchMateDTO);

		int totalCnt = labNoteCommonService.selectSearchMateTempListCount(labNoteCommonReqSearchMateDTO);
		List<LabNoteCommonSearchMateDTO> list = null;
		CommonUtil.setPaging(labNoteCommonReqSearchMateDTO, totalCnt);

		if (totalCnt > 0) {
			list = labNoteCommonService.selectSearchMateTempList(labNoteCommonReqSearchMateDTO);
		}

		PagingDTO page = ConvertUtil.convert(labNoteCommonReqSearchMateDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
											.page(page)
											.list(list)
											.build();

		responseVO.setOk(res);
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "원료 검색 - 즐겨찾기 원료 검색", description = "원료 검색 - 즐겨찾기 원료 리스트를 조회한다. (화면ID : SC-PO-012)")
	@GetMapping("/select-search-my-mate-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectSearchMyMateList (
			LabNoteCommonReqSearchMateDTO labNoteCommonReqSearchMateDTO
			) {
		ResponseVO responseVO = new ResponseVO();

		log.debug("LabNoteCommonController.selectSearchMyMateList : {}", labNoteCommonReqSearchMateDTO);

		int totalCnt = labNoteCommonService.selectSearchMyMateListCount(labNoteCommonReqSearchMateDTO);
		List<LabNoteCommonSearchMateDTO> list = null;
		CommonUtil.setPaging(labNoteCommonReqSearchMateDTO, totalCnt);

		if (totalCnt > 0) {
			list = labNoteCommonService.selectSearchMyMateList(labNoteCommonReqSearchMateDTO);
		}

		PagingDTO page = ConvertUtil.convert(labNoteCommonReqSearchMateDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
											.page(page)
											.list(list)
											.build();

		responseVO.setOk(res);
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "원료 검색 선택 적용 - 일시적 금지 해제 원료 체크", description = "원료 검색 선택 적용 시 일시적으로 금지 해제된 원료인지 체크한다. (화면ID : SC-PO-012)")
	@GetMapping("/select-check-clear-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectCheckClearList (
			@RequestParam(value="arrMaterialCd") List<String> arrMaterialCd,
			@RequestParam(value="vType") String vType
			) {
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(labNoteCommonService.selectCheckClearList(arrMaterialCd, vType));
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "심사번호 검색", description="심사번호 리스트를 조회한다. 조회 조건 추가 필요. 미완료")
	@GetMapping("/select-evaluation-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectEvaluationList (
			LabNoteCommonReqSearchEvalDTO labNoteCommonReqSearchEvalDTO
			) {
		ResponseVO responseVO = new ResponseVO();

		log.debug("LabNoteCommonController.selectEvaluationList : {}", labNoteCommonReqSearchEvalDTO);

		int totalCnt = labNoteCommonService.selectEvaluationListCount(labNoteCommonReqSearchEvalDTO);
		List<LabNoteCommonEvaluationDTO> list = null;
		CommonUtil.setPaging(labNoteCommonReqSearchEvalDTO, totalCnt);

		if (totalCnt > 0) {
			list = labNoteCommonService.selectEvaluationList(labNoteCommonReqSearchEvalDTO);
		}

		PagingDTO page = ConvertUtil.convert(labNoteCommonReqSearchEvalDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
										.page(page)
										.list(list)
										.build();

		responseVO.setOk(res);
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "심사번호 검색 - 주성분 원료 리스트", description="심사번호 검색 - 주성분 원료 리스트를 조회한다.")
	@GetMapping("/select-evaluation-material-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectEvaluationMaterialList (
			LabNoteCommonReqEvalMateSearchDTO labNoteCommonReqEvalMateSearchDTO
			) {
		ResponseVO responseVO = new ResponseVO();

		log.debug("LabNoteCommonController.selectEvaluationMaterialList : {}", labNoteCommonReqEvalMateSearchDTO);

		int totalCnt = labNoteCommonService.selectEvaluationMaterialListCount(labNoteCommonReqEvalMateSearchDTO);
		List<LabNoteCommonEvalMaterialDTO> list = null;
		CommonUtil.setPaging(labNoteCommonReqEvalMateSearchDTO, totalCnt);

		if (totalCnt > 0) {
			list = labNoteCommonService.selectEvaluationMaterialList(labNoteCommonReqEvalMateSearchDTO);
		}

		PagingDTO page = ConvertUtil.convert(labNoteCommonReqEvalMateSearchDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
									.page(page)
									.list(list)
									.build();

		responseVO.setOk(res);
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "TDD 제품유형", description = "TDD 제품유형 전체 조회. where절 조건은 front에서 컨트롤")
	@GetMapping("/select-tdd-prod-type-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectTddProdTypeList (
			@RequestParam(value="vFlagSub", defaultValue="N") String vFlagSub,
			@RequestParam(value="vNoteType", required=false) String vNoteType,
			@RequestParam(value="vClassCd", defaultValue="S000001") String vClassCd
			) {
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(labNoteCommonService.selectTddProdTypeList(vFlagSub, vNoteType, vClassCd));
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "제품코드 검색", description = "제품코드를 조회한다.")
	@GetMapping("/select-search-prod-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectSearchProdList (
			LabNoteCommonReqProdSearchDTO labNoteCommonReqProdSearchDTO
			) {
		ResponseVO responseVO = new ResponseVO();

		log.debug("LabNoteCommonController.selectSearchProdList : {}", labNoteCommonReqProdSearchDTO);

		int totalCnt = labNoteCommonService.selectSearchProdListCount(labNoteCommonReqProdSearchDTO);
		List<LabNoteCommonProdSearchDTO> list = null;
		CommonUtil.setPaging(labNoteCommonReqProdSearchDTO, totalCnt);

		if (totalCnt > 0) {
			list = labNoteCommonService.selectSearchProdList(labNoteCommonReqProdSearchDTO);
		}

		PagingDTO page = ConvertUtil.convert(labNoteCommonReqProdSearchDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
										.page(page)
										.list(list)
										.build();

		responseVO.setOk(res);
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "검색 > 원료 검색 > 검색부서 권한관리 팝업", description = "검색부서 권한관리 정보를 조회한다. (화면 ID : CO-PO-118)")
	@GetMapping("/select-auth-dept-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectAuthDeptInfo () {
		log.debug("LabNoteCommonController.selectAuthDeptInfo");

		return ResponseEntity.ok(labNoteCommonService.selectAuthDeptInfo());
	}

	@Operation(summary = "검색 > 원료 검색 > 검색부서 권한관리 팝업", description = "검색부서 권한관리 정보를 저장한다. (화면 ID : CO-PO-118)")
	@PostMapping("/insert-auth-dept-info")
	public @ResponseBody ResponseEntity<ResponseVO> insertAuthDeptInfo (
			@RequestBody @Valid LabNoteCommonAuthDeptRegDTO regDTO
			) {
		log.debug("LabNoteCommonController.insertAuthDeptInfo");
		log.debug("LabNoteCommonAuthDeptRegDTO : {}", regDTO);

		return ResponseEntity.ok(labNoteCommonService.insertAuthDeptInfo(regDTO));
	}

//	원료배합 start
//	elab/experiment/lab_note_matnr_sap_repeat_ajax
	@Operation(summary = "SAP 구성성분 연동(table update)", description = "SAP 구성성분 연동한다.(table update)")
	@PostMapping("/update-sap-repeat")
	public @ResponseBody ResponseEntity<ResponseVO> updateSAPRepeat (
			@RequestBody @Valid SapRepeatRegDTO regDTO) {
		log.debug("update-sap-repeat Start!");
		log.debug("SapRepeatRegDTO : {}", regDTO.toString());

		return ResponseEntity.ok(labNoteCommonService.updateSAPRepeat(regDTO));
	}

//	elab/experiment/lab_note_matnr_refresh_ajax
	@Operation(summary = "SAP 구성성분없음 연동", description = "SAP 구성성분없음 연동한다.")
	@PostMapping("/update-refresh-matnr")
	public @ResponseBody ResponseEntity<ResponseVO> updateRefreshMatnr (
			@RequestBody @Valid SapRefreshMatnrRegDTO regDTO) {
		log.debug("update-refresh-matnr Start!");
		log.debug("SapRefreshMatnrRegDTO : {}", regDTO.toString());

		return ResponseEntity.ok(labNoteCommonService.updateRefreshMatnr(regDTO));
	}

//	skt/mdl/skt_mdl_note_required_max_ajax
	@Operation(summary = "효능모듈 모델 조회", description = "효능모듈 모델 조회한다.")
	@GetMapping("/select-mdl-required-max-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectMdlRequiredMaxList (
			MdlReqDTO reqDTO) {
		log.debug("select-mdl-required-max-list Start!");
		log.debug("MdlReqDTO : {}", reqDTO.toString());

		return ResponseEntity.ok(labNoteCommonService.selectMdlRequiredMaxList(reqDTO));
	}

//	elab/experiment/lab_note_mate_hal4cd_load_ajax
	@Operation(summary = "무소구 4자코드 SAP 전송", description = "무소구 4자코드 SAP 전송한다.")
	@PostMapping("/insert-hal4-mate")
	public @ResponseBody ResponseEntity<ResponseVO> insertHal4Mate (
			@RequestBody @Valid Hal4MateRegDTO regDTO) {
		log.debug("insert-hal4-mate Start!");
		log.debug("Hal4MateRegDTO : {}", regDTO.toString());

		return ResponseEntity.ok(labNoteCommonService.insertHal4Mate(regDTO));
	}

//	POPUP - 글로벌금지
//	elab/experiment/lab_note_mate_alert_view_pop
	@Operation(summary = "글로벌 금지항목 조회", description = "글로벌 금지항목 조회한다.")
	@GetMapping("/select-scm-tcode-list")
	public @ResponseBody ResponseEntity<ResponseVO> selcetScmTcodeList (
			@RequestParam String vLabNoteCd
			, @RequestParam String vMateCd
			, @RequestParam String vLand1) {
		log.debug("select-scm-tcode-list Start!");
		log.debug("vLabNoteCd : {}", vLabNoteCd);
		log.debug("vMateCd : {}", vMateCd);
		log.debug("vLand1 : {}", vLand1);

		return ResponseEntity.ok(labNoteCommonService.selcetScmTcodeList(ScmTCodeReqVO.builder()
				.vLabNoteCd(vLabNoteCd)
				.vMateCd(vMateCd)
				.vLand1(vLand1)
				.build()));
	}

//	elab/common/lab_note_zplmt12_pop
	@Operation(summary = "제한 여부 내용(전성분 배합한도) 조회", description = "제한 여부 내용(전성분 배합한도) 조회한다.")
	@GetMapping("/select-zplmt12-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectZplmt12List (
			@RequestParam String vLabNoteCd
			, @RequestParam String vSearchType
			, @RequestParam String vConcd
			, @RequestParam String vLand1
			, @RequestParam(required = false) String vGcode) {
		log.debug("select-zplmt12-list Start!");
		log.debug("vLabNoteCd : {}", vLabNoteCd);
		log.debug("vSearchType : {}", vSearchType);
		log.debug("vConcd : {}", vConcd);
		log.debug("vLand1 : {}", vLand1);
		log.debug("vGcode : {}", vGcode);

		return ResponseEntity.ok(labNoteCommonService.selectZplmt12List(Zplmt12ReqVO.builder()
				.vLabNoteCd(vLabNoteCd)
				.vSearchType(vSearchType)
				.vConcd(vConcd)
				.vLand1(vLand1)
				.vGcode(vGcode)
				.build()));
	}

//	POPUP - 배합한도
//	lab/note/lab_note_maxmix_pop
	@Operation(summary = "배합한도 상세 조회", description = "배합한도 상세 조회한다.")
	@GetMapping("/select-lab-note-max-mix-mrq-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteMaxMixMrqList (
			@RequestParam(required = false) String vLabNoteCd,
			@RequestParam String vMateCd,
			@RequestParam(required = false) int nVersion) {
		log.debug("select-lab-note-max-mix-mrq-list Start!");
		log.debug("vLabNoteCd : {}", vLabNoteCd);
		log.debug("vMateCd : {}", vMateCd);
		log.debug("nVersion : {}", nVersion);

		return ResponseEntity.ok(labNoteCommonService.selectLabNoteMaxMixMrqList(MaxMixVO.builder()
				.vLabNoteCd(vLabNoteCd)
				.vMateCd(vMateCd)
				.nVersion(nVersion)
				.build()));
	}

//	POPUP - SHELF LIFE
//	elab/experiment/lab_note_shelflife_check_html
	@Operation(summary = "SHELF LIFE 조회", description = "SHELF LIFE 조회한다.")
	@GetMapping("/select-one-shelf-life-cont-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectOneShelfLifeContList (
			@Valid ShelfLifeReqDTO reqDTO) {
		log.debug("select-one-shelf-life-cont-list Start!");
		log.debug("ShefLifeReqDTO : {}", reqDTO.toString());

		return ResponseEntity.ok(labNoteCommonService.selectOneShelfLifeContList(reqDTO));
	}
//	원료배합 end

	@Operation(summary = "최근 조회 실험노트 정보 저장", description = "최근 조회한 실험노트 정보를 저장한다.")
	@PostMapping("/save-note-recent-log")
	public @ResponseBody ResponseEntity<ResponseVO> saveNoteRecentLog (
			@RequestBody LabNoteCommonRecentDTO labNoteCommonRecentDTO
			) {
		return ResponseEntity.ok(labNoteCommonService.saveNoteRecentLog(labNoteCommonRecentDTO));
	}

	@Operation(summary = "최근 조회 실험노트 목록 조회", description = "최근 조회한 실험노트 목록을 조회한다.")
	@GetMapping("/select-note-recent-log-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectNoteRecentLogList (
			@RequestParam(name="vNoteType") String vNoteType
			) {
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(labNoteCommonService.selectNoteRecentLogList(vNoteType));
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "최근 조회 실험노트 정보 삭제", description = "최근 조회 실험노트 정보를 삭제한다.")
	@PostMapping("/delete-note-recent-log-cont")
	public @ResponseBody ResponseEntity<ResponseVO> deleteNoteRecentLogCont (
			@RequestBody LabNoteCommonRecentDTO labNoteCommonRecentDTO
			) {
		return ResponseEntity.ok(labNoteCommonService.deleteNoteRecentLogCont(labNoteCommonRecentDTO));
	}

	@Operation(summary = "부서 LAB 과제 조회", description = "부서 LAB 과제 조회")
	@GetMapping("/select-lab-code-required")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabCodeRequired (
			@RequestParam(name="vDeptCd") String vDeptCd
			) {
		return ResponseEntity.ok(labNoteCommonService.selectLabCodeRequiredInfo(vDeptCd));
	}

	@Operation(summary = "실험노트 열람권한 조회", description = "실험노트별 열람권한을 조회한다.")
	@GetMapping("/select-lab-note-authority-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteAuthorityList (
			ElabChgLogSearchReqDTO searchReqDTO
			) {
		return ResponseEntity.ok(labNoteCommonService.selectLabNoteAuthorityList(searchReqDTO));
	}

	@Operation(summary = "실험노트 열람권한 삭제", description = "선택한 사용자의 열람권한을 삭제한다.")
	@PostMapping("/delete-lab-note-authority")
	public @ResponseBody ResponseEntity<ResponseVO> deleteLabNoteAuthority (
			@RequestBody LabNoteAuthorityReqDTO reqDTO
			) {
		log.debug("LabNoteCommonController.deleteLabNoteAuthority => LabNoteAuthorityReqDTO : {}", reqDTO);
		return ResponseEntity.ok(labNoteCommonService.deleteLabNoteAuthority(reqDTO));
	}

	@Operation(summary = "실험노트 열람권한 등록", description = "실험노트별 열람권한을 추가한다.")
	@PostMapping("/insert-lab-note-authority")
	public @ResponseBody ResponseEntity<ResponseVO> insertLabNoteAuthority (
			@RequestBody LabNoteAuthorityReqDTO reqDTO
			) {
		log.debug("LabNoteCommonController.insertLabNoteAuthority => LabNoteAuthorityReqDTO : {}", reqDTO);
		return ResponseEntity.ok(labNoteCommonService.insertLabNoteAuthority(reqDTO));
	}

	@Operation(summary = "실험노트 사용기한 정보 조회", description = "실험노트 사용기한 정보를 조회한다.")
	@GetMapping("/select-lab-note-shelf-life-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectLabNoteShelfLifeInfo (
			LabNoteCommonReqShelflifeDTO reqDTO
			) {
		log.debug("LabNoteCommonController.selectLabNoteShelfLifeInfo => LabNoteCommonReqShelflifeDTO : {}", reqDTO);
		return ResponseEntity.ok(labNoteCommonService.selectLabNoteShelfLifeInfo(reqDTO));
	}

	@Operation(summary = "실험노트 사용기한 정보 수정", description = "실험노트 사용기한 정보를 수정한다.")
	@PostMapping("/update-lab-note-shelf-life-info")
	public @ResponseBody ResponseEntity<ResponseVO> updateLabNoteShelfLifeInfo (
			@RequestBody LabNoteCommonReqShelflifeDTO reqDTO
			) {
		log.debug("LabNoteCommonController.updateLabNoteShelfLifeInfo => LabNoteCommonReqShelflifeDTO : {}", reqDTO);
		return ResponseEntity.ok(labNoteCommonService.updateLabNoteShelfLifeInfo(reqDTO));
	}

	@Operation(summary = "배합규제 상세 조회", description = "배합규제 상세 조회")
	@GetMapping("/select-matr-mixre-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectMatrMixreInfo (@RequestParam(name="vConcd") String vConcd) {
		return ResponseEntity.ok(labNoteCommonService.selectMatrMixreInfo(vConcd));
	}

	@Operation(summary = "SHELF LIFE 목록 조회", description = "SHELF LIFE 목록을 조회한다.")
	@GetMapping("/select-one-shelf-life-cont-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectOneShelfLifeContInfo (
			@Valid ShelfLifeReqDTO reqDTO
			) {
		log.debug("LabNoteCommonController.selectOneShelfLifeContInfo => ShelfLifeReqDTO : {}", reqDTO);
		return ResponseEntity.ok(labNoteCommonService.selectOneShelfLifeContInfo(reqDTO));
	}

	@Operation(summary = "마이보드 > 알림 리스트 조회", description = "마이보드 > 알림 리스트를 조회한다.")
	@GetMapping("/select-my-board-alarm-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectMyBoardAlarmList () {
		return ResponseEntity.ok(labNoteCommonService.selectMyBoardAlarmList());
	}

	@Operation(summary = "모제품 검색", description = "모제품 리스트를 조회한다.(화면ID : SC-PO-110)")
	@GetMapping("/select-safety-contents-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectSafetyContentsList (
			LabNoteCommonReqSafetyContentsSearchDTO reqDTO
			) {
		ResponseVO responseVO = new ResponseVO();

		log.debug("LabNoteCommonController.selectSafetyContentsList : {}", reqDTO);

		int totalCnt = labNoteCommonService.selectSafetyContentsListCount(reqDTO);
		List<ProductVO> list = null;
		CommonUtil.setPaging(reqDTO, totalCnt);

		if (totalCnt > 0) {
			list = labNoteCommonService.selectSafetyContentsList(reqDTO);
		}

		PagingDTO page = ConvertUtil.convert(reqDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
									.page(page)
									.list(list)
									.build();

		responseVO.setOk(res);
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "마이보드 > 결재함 리스트 조회", description = "마이보드 > 결재함 리스트를 조회한다.")
	@GetMapping("/select-my-board-approval-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectMyBoardApprovalList () {
		return ResponseEntity.ok(labNoteCommonService.selectMyBoardApprovalList());
	}

	@Operation(summary = "마이보드 > 메모 리스트 조회", description = "마이보드 > 메모 리스트를 조회한다.")
	@GetMapping("/select-my-board-memo-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectMyBoardMemoList () {
		return ResponseEntity.ok(labNoteCommonService.selectMyBoardMemoList());
	}

	@Operation(summary = "마이보드 > 메모 저장", description = "마이보드 > 메모 정보를 저장한다.")
	@PostMapping("/save-my-board-memo")
	public @ResponseBody ResponseEntity<ResponseVO> saveMyBoardMemo (
			@RequestBody MyBoardMemoDTO myboardMemoDTO
			) {
		return ResponseEntity.ok(labNoteCommonService.saveMyBoardMemo(myboardMemoDTO));
	}

	@Operation(summary = "마이보드 > 메모 삭제", description = "마이보드 > 메모 정보를 삭제한다.")
	@PostMapping("/delete-my-board-memo")
	public @ResponseBody ResponseEntity<ResponseVO> deleteMyBoardMemo (
			@RequestBody MyBoardMemoDTO myboardMemoDTO
			) {
		return ResponseEntity.ok(labNoteCommonService.deleteMyBoardMemo(myboardMemoDTO));
	}

	@Operation(summary = "TDD 제품유형", description = "TDD 제품유형 리스트를 조회한다.")
	@GetMapping("/select-tdd-product-class-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectTddProductClassList (
		@RequestParam(value="vPid") String vPid
			) {
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(labNoteCommonService.selectTddProductClassList(vPid));
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "comment 가져오기", description = "comment 리스트를 가져온다.")
	@GetMapping("/select-message-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectMessageList (
			@RequestParam(value="vRecordid") String vRecordid
			) {
		return ResponseEntity.ok(labNoteCommonService.selectMessageList(vRecordid));
	}

	@Operation(summary = "원료 문제이력 조회", description = "원료 문제이력을 조회한다.")
	@GetMapping("/select-material-issue-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectMaterialIssueList (
			@RequestParam(value="vSapCd") String vSapCd
			) {
		return ResponseEntity.ok(labNoteCommonService.selectMaterialIssueList(vSapCd));
	}

	@Operation(summary = "나의 즐겨찾기 원료 추가", description = "나의 즐겨찾기 원료 추가한다.")
	@PostMapping("/insert-lab-note-my-mate")
	public @ResponseBody ResponseEntity<ResponseVO> insertLabNoteMyMate (
			@RequestBody MaterialMateRegDTO regDTO) {
		log.debug("insert-lab-note-my-mate Start!");
		log.debug("MaterialRegDTO : {}", regDTO.toString());

		return ResponseEntity.ok(labNoteCommonService.insertLabNoteMyMate(regDTO));
	}

	@Operation(summary = "나의 즐겨찾기 원료 삭제", description = "나의 즐겨찾기 원료 삭제한다.")
	@PostMapping("/delete-lab-note-my-mate")
	public @ResponseBody ResponseEntity<ResponseVO> deleteLabNoteMyMate (
			@RequestBody MaterialMateRegDTO regDTO) {
		log.debug("delete-lab-note-my-mate Start!");
		log.debug("MaterialRegDTO : {}", regDTO.toString());

		return ResponseEntity.ok(labNoteCommonService.deleteLabNoteMyMate(regDTO));
	}

	@Operation(summary = "최근 조회 원료 목록", description = "최근 조회 원료 목록을 조회한다.")
	@GetMapping("/select-recent-mate-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectRecentMateList (
			@RequestParam(value="arrKey") List<String> arrKey
			) {
		log.debug("LabNoteCommonController.selectRecentMateList : {}", arrKey);
		return ResponseEntity.ok(labNoteCommonService.selectRecentMateList(arrKey));
	}

	@Operation(summary = "첨부파일 저장", description = "첨부파일 저장한다.")
	@PostMapping("/insert-attach-file")
	public @ResponseBody ResponseEntity<ResponseVO> insertAttachFile (
			@RequestBody AttachUploadRegDTO regDTO) {
		log.debug("insert-attach-file Start!");
		log.debug("AttachUploadRegDTO : {}", regDTO.toString());

		return ResponseEntity.ok(labNoteCommonService.insertAttachFile(regDTO));
	}

	@Operation(summary = "Right Menu > Status 정보 조회", description = "Right Menu > Status 정보 리스트를 조회한다.")
	@GetMapping("/select-lot-status-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectLotStatusList (
			@RequestParam(value = "vLabNoteCd") String vLabNoteCd
			) {
		log.debug("LabNoteCommonController.selectLotStatusList => vLabNoteCd : {}", vLabNoteCd);

		return ResponseEntity.ok(labNoteCommonService.selectLotStatusList(vLabNoteCd));
	}
	
	@Operation(summary = "시험의뢰 > 안전성 중복 등록 여부 조회", description = "안전성 중복 등록 여부를 조회한다.")
	@GetMapping("/select-safety-sap-chk")
	public @ResponseBody ResponseEntity<ResponseVO> selectSafetySapChk (
			@RequestParam String vSapCd
			, @RequestParam String vLabNoteCd
			, @RequestParam String vLotCd) {
		log.debug("select-safety-sap-chk Start!");
		log.debug("vSapCd : {}", vSapCd);
		log.debug("vLabNoteCd : {}", vLabNoteCd);
		log.debug("vLotCd : {}", vLotCd);

		return ResponseEntity.ok(labNoteCommonService.selectSafetySapChk(vSapCd, vLabNoteCd, vLotCd));
	}
	
	@Operation(summary = "기능성 심사번호 > 원료 리스트 조회", description="기능성 심사번호의 원료 리스트를 조회한다.")
	@GetMapping("/select-func-mate-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectFuncMateList (
			@RequestParam(value="arrFunctionCd") List<String> arrFunctionCd,
			@RequestParam(value="vEvaluateCd") String vEvaluateCd
			) {
		return ResponseEntity.ok(labNoteCommonService.selectFuncMateList(vEvaluateCd, arrFunctionCd));
	}
}
