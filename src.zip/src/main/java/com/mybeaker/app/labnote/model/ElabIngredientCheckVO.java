package com.mybeaker.app.labnote.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ElabIngredientCheckVO {

	private String vMatnr;
	
	private String vWerks;
	
	private String vFlagOrganization;
	
	private String vLand1;
	
	private List<String> mateCdList;
	
	private String vFlagRefresh;
}
