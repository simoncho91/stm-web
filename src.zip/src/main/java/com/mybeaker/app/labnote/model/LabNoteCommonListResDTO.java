package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.PagingDTO;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LabNoteCommonListResDTO {
	private PagingDTO page;

	private List<?> list;

	@JsonProperty("vFlagMyLabNote")
	private String vFlagMyLabNote;
}
