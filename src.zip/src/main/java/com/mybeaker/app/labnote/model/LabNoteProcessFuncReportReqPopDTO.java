package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.common.model.UploadTempDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LabNoteProcessFuncReportReqPopDTO {

	@JsonProperty("vNoteType")
	private String vNoteType;
	
	@JsonProperty("vNoteTypeNm")
	private String vNoteTypeNm;
	
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("nVersion")
	private int nVersion;
	
	@JsonProperty("nSeqno")
	private int nSeqno;
	
	@JsonProperty("vRecordid")
	private String vRecordid;
	
	@JsonProperty("vRefTypeCd")
	private String vRefTypeCd;
	
	@JsonProperty("vFlagSelf")
	private String vFlagSelf;
	
	@JsonProperty("vFlagDirect")
	private String vFlagDirect;
	
	@JsonProperty("vUploadCd")
	private String vUploadCd;
	
	@JsonProperty("fileList")
	private List<UploadTempDTO> fileList;
	
	@JsonProperty("vDocClass")
	private String vDocClass;
	
	@JsonProperty("vDocType")
	private String vDocType;
	
	@JsonProperty("vStorageCd")
	private String vStorageCd;
	
	@JsonProperty("vApprStatus")
	private String vApprStatus;
	
	@JsonProperty("vStatusCd")
	private String vStatusCd;
	
	@JsonProperty("vContent")
	private String vContent;
	
	@JsonProperty("vSort")
	private String vSort;
	
	@JsonProperty("vTag")
	private String vTag;
	
	@JsonProperty("vRegUserid")
	private String vRegUserid;
	
	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;
	
	@JsonProperty("vSenderId")
	private String vSenderId;
	
	private String sigma_deptcd;
	
	@JsonProperty("vSenderDeptCd")
	private String vSenderDeptCd;
	
	@JsonProperty("targetCd")
	private String targetCd;
	
	@JsonProperty("vFlagPif")
	private String vFlagPif;
	
	@JsonProperty("vTitle")
	private String vTitle;
	
	@JsonProperty("vContPkCd")
	private String vContPkCd;
	
	@JsonProperty("vHboRepresentContCd")
	private String vHboRepresentContCd;
}
