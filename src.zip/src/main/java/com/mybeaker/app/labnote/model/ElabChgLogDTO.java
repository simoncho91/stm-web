package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ElabChgLogDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vChgFieldCd")
	private String vChgFieldCd;

	@JsonProperty("vChgBefore")
	private String vChgBefore;

	@JsonProperty("vChgAfter")
	private String vChgAfter;

	@JsonProperty("vRegUserid")
	private String vRegUserid;

	@JsonProperty("vUsernm")
	private String vUsernm;

	@JsonProperty("vRegDtm")
	private String vRegDtm;
}
