package com.mybeaker.app.labnote.model;

import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LabNoteTestReqRegDTO {
	
	@JsonProperty("vTrCompleteReqDt")
	private String vTrCompleteReqDt;
	
	@JsonProperty("vDosageFormCd")
	private String vDosageFormCd;
	
	@JsonProperty("vTrPh")
	private String vTrPh;
	
	@JsonProperty("vTrTestGoal")
	private String vTrTestGoal;
	
	@JsonProperty("vTrSampleKeepCd")
	private String vTrSampleKeepCd;
	
	@JsonProperty("vTrSampleAmt")
	private String vTrSampleAmt;
	
	@JsonProperty("vTrTestEndCd")
	private String vTrTestEndCd;
	
	@JsonProperty("vTrComment")
	private String vTrComment;
	
	@NotEmpty
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("vContPkCd")
	private String vContPkCd;
	
	@JsonProperty("vRepContPkCd")
	private String vRepContPkCd;
	
	@JsonProperty("nVersion")
	private int nVersion;
	
	@JsonProperty("vLotCd")
	private String vLotCd;
	
	@JsonProperty("vPlantCd")
	private String vPlantCd;
	
	@JsonProperty("vMrqTypeCd")
	private String vMrqTypeCd;
	
	@JsonProperty("vLand1")
	private String vLand1;
	
	@JsonProperty("vContcd")
	private String vContcd;
	
	@JsonProperty("vFlagAction")
	private String vFlagAction;
	
	@JsonProperty("vTestCd")
	private String vTestCd;
	
	@JsonProperty("vDeptCd1")
	private String vDeptCd1;
	
	@JsonProperty("vTitle")
	private String vTitle;
	
	@JsonProperty("vRequestTeamcd")
	private String vRequestTeamcd;
	
	@JsonProperty("vRequestid")
	private String vRequestid;
	
	@JsonProperty("vTestRequestDocno")
	private String vTestRequestDocno;
	
	@JsonProperty("vDeptCd")
	private String vDeptCd;
	
	@JsonProperty("vRegUserid")
	private String vRegUserid;
	
	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;
	
	@JsonProperty("vGateCd")
	private String vGateCd;
	
	@JsonProperty("vTrPrdCd")
	private String vTrPrdCd;
	
	@JsonProperty("vTrMrqTypeCd")
	private String vTrMrqTypeCd;
	
	@JsonProperty("vTrGoalCd")
	private String vTrGoalCd;
	
	@JsonProperty("vTrRelationProductCd")
	private String vTrRelationProductCd;
	
	@JsonProperty("vPrescUserid")
	private String vPrescUserid;
	
	@JsonProperty("vCreateNo")
	private String vCreateNo;
	
	@JsonProperty("vTrTestTypeCd")
	private String vTrTestTypeCd;
	
	@JsonProperty("vRepContCd")
	private String vRepContCd;
	
	@JsonProperty("vTrPrdNm")
	private String vTrPrdNm;
	
	@JsonProperty("vTrPrdEngNm")
	private String vTrPrdEngNm;
	
	@JsonProperty("vTrSapCd")
	private String vTrSapCd;
	
	@JsonProperty("vUserid")
	private String vUserid;
	
	@JsonProperty("vAmoreProdYn")
	private String vAmoreProdYn;
	
	@JsonProperty("vInnerPlant")
	private String vInnerPlant;
	
	@JsonProperty("vMakerNm")
	private String vMakerNm;
	
	@JsonProperty("vLot")
	private String vLot;
	
	@JsonProperty("vTypeCd")
	private String vTypeCd;
	
	@JsonProperty("vTypeCd2")
	private String vTypeCd2;
	
	@JsonProperty("vTddProdType1Cd")
	private String vTddProdType1Cd;
	
	@JsonProperty("vTddProdType2Cd")
	private String vTddProdType2Cd;
	
	@JsonProperty("vCont1Cd")
	private String vCont1Cd;
	
	@JsonProperty("vCont2Cd")
	private String vCont2Cd;
	
	@JsonProperty("vRpmsCd")
	private String vRpmsCd;
	
	@JsonProperty("vBrdCd")
	private String vBrdCd;
	
	@JsonProperty("vMeetingDt")
	private String vMeetingDt;
	
	@JsonProperty("vWerks")
	private String vWerks;
	
	@JsonProperty("vFlagReleaseAsia")
	private String vFlagReleaseAsia;
	
	@JsonProperty("vFlagReleaseAsean")
	private String vFlagReleaseAsean;
	
	@JsonProperty("vFlagReleaseEtc")
	private String vFlagReleaseEtc;
	
	@JsonProperty("vPartCd")
	private String vPartCd;
	
	@JsonProperty("vKosmetikCd")
	private String vKosmetikCd;
	
	@JsonProperty("vContainerCd")
	private String vContainerCd;
	
	@JsonProperty("vContainerEtc")
	private String vContainerEtc;
	
	@JsonProperty("vTrSiteType")
	private String vTrSiteType;
	
	@JsonProperty("vTrPilotDt")
	private String vTrPilotDt;
	
	@JsonProperty("vTrComment2")
	private String vTrComment2;
	
	@JsonProperty("vTrComment2Dft")
	private String vTrComment2Dft;
	
	@JsonProperty("vFlagTmt1")
	private String vFlagTmt1;
	
	@JsonProperty("vFlagMuColorless")
	private String vFlagMuColorless;
	
	@JsonProperty("vTestReqTable")
	private String vTestReqTable;
	
	@JsonProperty("vFeature")
	private String vFeature;
	
	@JsonProperty("vRepLotCd")
	private String vRepLotCd;
	
	@JsonProperty("vTrFlagNoFragrance")
	private String vTrFlagNoFragrance;
	
	@JsonProperty("vTrFlagNoAntiseptic")
	private String vTrFlagNoAntiseptic;
	
	@JsonProperty("vChinaGoYn")
	private String vChinaGoYn;
	
	@JsonProperty("vChinaSafeYn")
	private String vChinaSafeYn;
	
	@JsonProperty("vTrVersion")
	private String vTrVersion;
	
	@JsonProperty("vSapCd")
	private String vSapCd;
	
	@JsonProperty("vLanguage")
	private String vLanguage;
	
	@JsonProperty("nMessageNo")
	private int nMessageNo;
	
	@JsonProperty("vGroupId")
	private String vGroupId;
	
	@JsonProperty("vAppromise")
	private String vAppromise;
	
	@JsonProperty("vApPromiseTxt")
	private String vApPromiseTxt;
	
	@JsonProperty("vMtr04")
	private String vMtr04;
	
	@JsonProperty("vMtr05")
	private String vMtr05;
	
	@JsonProperty("vMtr06")
	private String vMtr06;
	
	@JsonProperty("vMusoTxt")
	private String vMusoTxt;
	
	@JsonProperty("vReqDiv")
	private String vReqDiv;
	
	@JsonProperty("vTrMusoguProductNm")
	private String vTrMusoguProductNm;
	
	@JsonProperty("arrContPkCd")
	private String [] arrContPkCd;
	
	private List<LabNoteTestReqContPkVO> contPkCdList;

	@Size(min = 1)
	@JsonProperty("contList")
	private List<LabNoteTestReqContVO> contList;
	
	@JsonProperty("vRepPlantCd")
	private String vRepPlantCd;
	
	@JsonProperty("nRepVersion")
	private int nRepVersion;
	
	@JsonProperty("sameList")
	private List<SupTrProductSameVO> sameList;
	
	@JsonProperty("vTrContNmEn")
	private String vTrContNmEn;
	
	@JsonProperty("vFlagNoColorBase")
	private String vFlagNoColorBase;
	
	@JsonProperty("testItemCdList")
	private List<String> testItemCdList;
	
	private String vReqMethod;
	
	@JsonProperty("vProductClass")
	private String vProductClass;
	
	@JsonProperty("vLeaveOnYn")
	private String vLeaveOnYn;
	
	@JsonProperty("vNewContYn")
	private String vNewContYn;
	
	@JsonProperty("vSiteType")
	private String vSiteType;
	
	@JsonProperty("vContNm")
	private String vContNm;
	
	@JsonProperty("vLotNm")
	private String vLotNm;
	
	@JsonProperty("nTrVersion")
	private int nTrVersion;
	
	@JsonProperty("vMethodEtc")
	private String vMethodEtc;
}
	
	
	
