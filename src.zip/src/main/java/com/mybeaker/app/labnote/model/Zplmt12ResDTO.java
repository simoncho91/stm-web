package com.mybeaker.app.labnote.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Zplmt12ResDTO {
	
	private List<Zplmt12GlbDescVO> list;
	
	private Zplmt12MstVO vo;
}
