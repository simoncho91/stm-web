package com.mybeaker.app.labnote.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Positive;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ReportApprovalReqDTO {

	@NotEmpty
	@JsonProperty("vApprCd")
	private String vApprCd;

	@Positive
	@JsonProperty("nCurRegseq")
	private int nCurRegseq;

	@Positive
	@JsonProperty("nCurApprseq")
	private int nCurApprseq;

	@NotEmpty
	@JsonProperty("vApprStatus")
	private String vApprStatus;

	@JsonProperty("vApprSubStatus")
	private String vApprSubStatus;

	@JsonProperty("vApprOpinion")
	private String vApprOpinion;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("vLotNm")
	private String vLotNm;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vUserid")
	private String vUserid;
	
	@JsonProperty("vRecordid")
	private String vRecordid;
	
	@JsonProperty("vFinishYn")
	private String vFinishYn;
	
	@JsonProperty("vDocStatus")
	private String vDocStatus;
	
}
