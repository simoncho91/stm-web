package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class LaunchCompleteReqDTO extends ParentDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vCompleteDt")
	private String vCompleteDt;

	@JsonProperty("vFlagAllComplete")
	private String vFlagAllComplete;

	private String vSignType;

	private String vLaunchCompleteType;

	private String localLanguage;

	private List<LaunchCompleteContDTO> contList;
}
