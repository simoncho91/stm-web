package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ElabNoteLastTrInfoDTO {
	@JsonProperty("vM011TestTypeCd")
	private String vM011TestTypeCd;
	
	@JsonProperty("vM011ProductionCd")
	private String vM011ProductionCd;
	
	@JsonProperty("vM011ProductionTxt")
	private String vM011ProductionTxt;
	
	@JsonProperty("vM011FlagNoWater")
	private String vM011FlagNoWater;
	
	@JsonProperty("vM011FlagNoFragrance")
	private String vM011FlagNoFragrance;
	
	@JsonProperty("vM011ProdSign")
	private String vM011ProdSign;
	
	@JsonProperty("vM040GoalCd")
	private String vM040GoalCd;
	
	@JsonProperty("vM040TestGoal")
	private String vM040TestGoal;
	
	@JsonProperty("vM040SampleKeepCd")
	private String vM040SampleKeepCd;
	
	@JsonProperty("vM040SampleAmt")
	private String vM040SampleAmt;
	
	@JsonProperty("vM040TestEndCd")
	private String vM040TestEndCd;
	
	@JsonProperty("vProductCd")
	private String vProductCd;
	
	@JsonProperty("nVersion")
	private int nVersion;
	
	@JsonProperty("vProductNm")
	private String vProductNm;
	
	@JsonProperty("vProductEngNm")
	private String vProductEngNm;
	
	@JsonProperty("vStatusCd")
	private String vStatusCd;
	
	@JsonProperty("vObjTypeCd")
	private String vObjTypeCd;
	
	@JsonProperty("vSapCd")
	private String vSapCd;
	
	@JsonProperty("vDocNo")
	private String vDocNo;
	
	@JsonProperty("vUserid")
	private String vUserid;
	
	@JsonProperty("vDeptCd")
	private String vDeptCd;
	
	@JsonProperty("vDeptTempNm")
	private String vDeptTempNm;
	
	@JsonProperty("vAmoreProdYn")
	private String vAmoreProdYn;
	
	@JsonProperty("vMakerNm")
	private String vMakerNm;
	
	@JsonProperty("vLot")
	private String vLot;
	
	@JsonProperty("vPh")
	private String vPh;
	
	@JsonProperty("vTypeCd")
	private String vTypeCd;
	
	@JsonProperty("vDosageFormCd")
	private String vDosageFormCd;
	
	@JsonProperty("vFeature")
	private String vFeature;
	
	@JsonProperty("vCompareSampleNm")
	private String vCompareSampleNm;
	
	@JsonProperty("vPrddayDt")
	private String vPrddayDt;
	
	@JsonProperty("vStdayDt")
	private String vStdayDt;
	
	@JsonProperty("vRegUserid")
	private String vRegUserid;
	
	@JsonProperty("vRegDtm")
	private String vRegDtm;
	
	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;
	
	@JsonProperty("vUpdateDtm")
	private String vUpdateDtm;
	
	@JsonProperty("vFlagDel")
	private String vFlagDel;
	
	@JsonProperty("vLabCd")
	private String vLabCd;
	
	@JsonProperty("vCont1Cd")
	private String vCont1Cd;
	
	@JsonProperty("vCont2Cd")
	private String vCont2Cd;
	
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("vLotCd")
	private String vLotCd;
	
	@JsonProperty("vTypeCd2")
	private String vTypeCd2;
	
	@JsonProperty("vPartCd")
	private String vPartCd;
	
	@JsonProperty("n_lab_note_ver")
	private int n_lab_note_ver;
	
	@JsonProperty("vRpmsCd")
	private String vRpmsCd;
	
	@JsonProperty("vInnerPlant")
	private String vInnerPlant;
	
	@JsonProperty("vOrijinProductCd")
	private String vOrijinProductCd;
	
	@JsonProperty("vTag")
	private String vTag;
	
	@JsonProperty("vBrdCd")
	private String vBrdCd;
	
	@JsonProperty("vPilotDt")
	private String vPilotDt;
	
	@JsonProperty("vMeetingDt")
	private String vMeetingDt;
	
	@JsonProperty("vWerks")
	private String vWerks;
	
	@JsonProperty("vKosmetikCd")
	private String vKosmetikCd;
	
	@JsonProperty("vKosmetikTxt")
	private String vKosmetikTxt;
	
	@JsonProperty("vFlagReleaseAsia")
	private String vFlagReleaseAsia;
	
	@JsonProperty("vFlagReleaseAsean")
	private String vFlagReleaseAsean;
	
	@JsonProperty("vFlagReleaseEtc")
	private String vFlagReleaseEtc;
	
	@JsonProperty("vLabReqDtm")
	private String vLabReqDtm;
	
	@JsonProperty("vLabGateCd")
	private String vLabGateCd;
	
	@JsonProperty("vLabMrqTypeCd")
	private String vLabMrqTypeCd;
	
	@JsonProperty("vFeature2")
	private String vFeature2;
	
	@JsonProperty("vFlagNoFragrance")
	private String vFlagNoFragrance;
	
	@JsonProperty("vFlagNoAntiseptic")
	private String vFlagNoAntiseptic;
	
	@JsonProperty("vCreateNo")
	private String vCreateNo;
	
	@JsonProperty("vTddProdType1Cd")
	private String vTddProdType1Cd;
	
	@JsonProperty("vTddProdType2Cd")
	private String vTddProdType2Cd;
	
	@JsonProperty("vContainerCd")
	private String vContainerCd;
	
	@JsonProperty("vContainerEtc")
	private String vContainerEtc;
	
	@JsonProperty("arrProdSignListCd")
	private List<String> arrProdSignListCd;
}
