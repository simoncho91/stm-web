package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ThisInventoryVO {
	@JsonProperty("vInvenJoinCd")
	private String vInvenJoinCd;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vInventoryCd")
	private String vInventoryCd;

	@JsonProperty("vFlagChoose")
	private String vFlagChoose;

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("vRegUserid")
	private String vRegUserid;

	@JsonProperty("vRegDtm")
	private String vRegDtm;

	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;

	@JsonProperty("vUpdateDtm")
	private String vUpdateDtm;

	@JsonProperty("vExhibitionCd")
	private String vExhibitionCd;

	@JsonProperty("vExhibitionNm")
	private String vExhibitionNm;

	@JsonProperty("vYear")
	private String vYear;

	@JsonProperty("vBrdCd")
	private String vBrdCd;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vUsernm")
	private String vUsernm;

	@JsonProperty("vBrdNm")
	private String vBrdNm;

	@JsonProperty("vInventoryNm")
	private String vInventoryNm;

	@JsonProperty("vInventoryDesc")
	private String vInventoryDesc;

	@JsonProperty("vReferPrd")
	private String vReferPrd;

	@JsonProperty("nFileCnt")
	private int nFileCnt;

	@JsonProperty("vLotNm")
	private String vLotNm;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("nSortLot")
	private int nSortLot;

	@JsonProperty("vVersionNm")
	private String vVersionNm;
}
