package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.skincare.model.VersionContVO;

import lombok.Data;

@Data
public class PlantExtendDTO {
	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vContNmEn")
	private String vContNmEn;

	@JsonProperty("vContNmCn")
	private String vContNmCn;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vLabContCd")
	private String vLabContCd;

	@JsonProperty("vPlantInfo")
	private String vPlantInfo;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vMaterialGroupCd")
	private String vMaterialGroupCd;

	private List<VersionContVO> plantList;
}
