package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteProcessFuncReportVerLotVO {
	
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vLotCd")
	private String vLotCd;
	
	@JsonProperty("vFlagQmsLotCheck")
	private String vFlagQmsLotCheck;
	
}
