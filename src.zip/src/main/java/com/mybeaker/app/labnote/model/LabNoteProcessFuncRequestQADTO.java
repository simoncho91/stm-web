package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LabNoteProcessFuncRequestQADTO {
	
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("nVersion")
	private int nVersion;
	
	@JsonProperty("nSeqno")
	private int nSeqno;
	
	@JsonProperty("vReqContent")
	private String vReqContent;
	
	@JsonProperty("vTitle")
	private String vTitle;
	
	@JsonProperty("vStatusCd")
	private String vStatusCd;
	
	@JsonProperty("vSenderId")
	private String vSenderId;
	
	@JsonProperty("vSenderDeptcd")
	private String vSenderDeptcd;
	
	@JsonProperty("vRecordid")
	private String vRecordid;
	
	@JsonProperty("vRequestDtm")
	private String vRequestDtm;
	
	@JsonProperty("vNumberNm")
	private String vNumberNm;
	
	@JsonProperty("nTioTwoRate")
	private int nTioTwoRate;
	
	@JsonProperty("nZnoRate")
	private int nZnoRate;
	
	@JsonProperty("vTioTwoNote")
	private String vTioTwoNote;
	
	@JsonProperty("vFlagOverEthanol")
	private String vFlagOverEthanol;
	
	@JsonProperty("vFlagOverEthanolNm")
	private String vFlagOverEthanolNm;
	
	@JsonProperty("vPh")
	private String vPh;
	
	@JsonProperty("vMaker")
	private String vMaker;
	
	@JsonProperty("vEvaluateNum")
	private String vEvaluateNum;
	
	@JsonProperty("vChangeProduct")
	private String vChangeProduct;
	
	@JsonProperty("vChangeCd")
	private String vChangeCd;
	
	@JsonProperty("vChangeNote")
	private String vChangeNote;
	
	@JsonProperty("vEffect")
	private String vEffect;
	
	@JsonProperty("vUsageCapacity")
	private String vUsageCapacity;
	
	@JsonProperty("vMakePlace")
	private String vMakePlace;
	
	@JsonProperty("vTwoLiqYn")
	private String vTwoLiqYn;		//SC일때만 가져옴
	
	@JsonProperty("vTwoLiqTxt")
	private String vTwoLiqTxt;		//SC일때만 가져옴
	
	@JsonProperty("vDecideContNm")
	private String vDecideContNm;
	
	private String localLanguage;
}
