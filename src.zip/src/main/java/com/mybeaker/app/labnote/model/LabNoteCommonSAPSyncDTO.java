package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class LabNoteCommonSAPSyncDTO extends ParentDTO {
	@JsonProperty("vContCd")
	private String vContCd;
	
	@JsonProperty("vPlantCd")
	private String vPlantCd;
	
	private String vLabNoteCd;
	
	private String vContPkCd;
	
	private String vContNm;
	
	@Builder.Default
	private String vCodeType = "HAL3";
	
	private String vLotCd;
	
	private int nVersion;
	
	private String vNoteType;
}
