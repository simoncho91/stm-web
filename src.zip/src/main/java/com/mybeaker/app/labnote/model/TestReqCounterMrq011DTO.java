package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TestReqCounterMrq011DTO {
	
	@JsonProperty("vProductCd")
	private String vProductCd;

	@JsonProperty("nVersion")
	private int nVersion;
	
	@JsonProperty("nSeq")
	private int nSeq;
	
	@JsonProperty("vCounterCd")
	private String vCounterCd;
	
	@JsonProperty("vCounterNm")
	private String vCounterNm;
	
	@JsonProperty("vWerks")
	private String vWerks;
	
	@JsonProperty("vType")
	private String vType;
	
}
