package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class Zplmt12MstVO {

	@JsonProperty("vConcd")
	private String vConcd;

	@JsonProperty("vCasno")
	private String vCasno;

	@JsonProperty("vZgubcl")
	private String vZgubcl;

	@JsonProperty("vZabcde")
	private String vZabcde;

	@JsonProperty("vZconcd")
	private String vZconcd;

	@JsonProperty("vZchina")
	private String vZchina;

	@JsonProperty("vZchinaText")
	private String vZchinaText;

	@JsonProperty("vZglobal")
	private String vZglobal;

	@JsonProperty("vZglbtxt")
	private String vZglbtxt;

	@JsonProperty("vMixre")
	private String vMixre;

	@JsonProperty("vMixreTxt")
	private String vMixreTxt;

	@JsonProperty("vZgllim")
	private String vZgllim;

	@JsonProperty("vZgllimTxt")
	private String vZgllimTxt;

	@JsonProperty("vZinper")
	private String vZinper;

	@JsonProperty("vZgrd")
	private String vZgrd;

	@JsonProperty("vCode")
	private String vCode;

	@JsonProperty("vQacycle")
	private String vQacycle;

	@JsonProperty("vRefid")
	private String vRefid;

	@JsonProperty("vZobli")
	private String vZobli;

	@JsonProperty("vZcert")
	private String vZcert;

	@JsonProperty("vZarjcd")
	private String vZarjcd;

	@JsonProperty("vZdisplayLt")
	private String vZdisplayLt;

	@JsonProperty("vZnotice")
	private String vZnotice;

	@JsonProperty("vZnoticeEn")
	private String vZnoticeEn;

	@JsonProperty("vZnoticeZh")
	private String vZnoticeZh;

	@JsonProperty("vZwarningLt")
	private String vZwarningLt;

	@JsonProperty("vZwarningLtEn")
	private String vZwarningLtEn;

	@JsonProperty("vZwarningLtZh")
	private String vZwarningLtZh;

	@JsonProperty("vConnm")
	private String vConnm;
}
