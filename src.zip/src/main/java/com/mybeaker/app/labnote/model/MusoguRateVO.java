package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class MusoguRateVO {

	@JsonProperty("nLv1Num")
	private int nLv1Num;

	@JsonProperty("nLv2Num")
	private int nLv2Num;

	@JsonProperty("vMateCd")
	private String vMateCd;

	@JsonProperty("vMateTempCd")
	private String vMateTempCd;

	@JsonProperty("vMateNm")
	private String vMateNm;

	@JsonProperty("nRate")
	private Double nRate;

	@JsonProperty("vHal4Cd")
	private String vHal4Cd;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vCode0")
	private String vCode0;

	@JsonProperty("vCode1")
	private String vCode1;

	@JsonProperty("vCode2")
	private String vCode2;

	@JsonProperty("vCode3")
	private String vCode3;

	@JsonProperty("vCode4")
	private String vCode4;

	@JsonProperty("vCode5")
	private String vCode5;

	@JsonProperty("vCode6")
	private String vCode6;

	@JsonProperty("vCode7")
	private String vCode7;

	@JsonProperty("vCode8")
	private String vCode8;

	@JsonProperty("vCode9")
	private String vCode9;

	@JsonProperty("vCode10")
	private String vCode10;

	@JsonProperty("vCode11")
	private String vCode11;

	@JsonProperty("vCode12")
	private String vCode12;

	@JsonProperty("vCode13")
	private String vCode13;

	@JsonProperty("vCode14")
	private String vCode14;

	@JsonProperty("vCode15")
	private String vCode15;

	@JsonProperty("vCode16")
	private String vCode16;

	@JsonProperty("vCode17")
	private String vCode17;

	@JsonProperty("vCode18")
	private String vCode18;
	
	@JsonProperty("vColor0")
	private String vColor0;
	
	@JsonProperty("vColor1")
	private String vColor1;
	
	@JsonProperty("vColor2")
	private String vColor2;
	
	@JsonProperty("vColor3")
	private String vColor3;
	
	@JsonProperty("vColor4")
	private String vColor4;
	
	@JsonProperty("vColor5")
	private String vColor5;
	
	@JsonProperty("vColor6")
	private String vColor6;
	
	@JsonProperty("vColor7")
	private String vColor7;
	
	@JsonProperty("vColor8")
	private String vColor8;
	
	@JsonProperty("vColor9")
	private String vColor9;
	
	@JsonProperty("vColor10")
	private String vColor10;
	
	@JsonProperty("vColor11")
	private String vColor11;
	
	@JsonProperty("vColor12")
	private String vColor12;
	
	@JsonProperty("vColor13")
	private String vColor13;
	
	@JsonProperty("vColor14")
	private String vColor14;
	
	@JsonProperty("vColor15")
	private String vColor15;
	
	@JsonProperty("vColor16")
	private String vColor16;
	
	@JsonProperty("vColor17")
	private String vColor17;
	
	@JsonProperty("vColor18")
	private String vColor18;
	
	@JsonProperty("vFlagRequest")
	private String vFlagRequest;
}
