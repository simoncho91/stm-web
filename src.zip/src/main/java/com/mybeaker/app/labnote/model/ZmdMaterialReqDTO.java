package com.mybeaker.app.labnote.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ZmdMaterialReqDTO {
	private String vLabNoteCd;

	private String mtart;

	private String hal1t;

	private String maktxEn;

	private String maktxKo;

	private String maktxZh;

	private String meins;

	private String brand;

	private String labor;

	private String manft;

	private String matnrC;

	private String pflag;

	private String werks;

	private String flag;

	private String vNoteType;

	private String vRegUserid;

	private String originalContPkCd;

	private String matkl;
}
