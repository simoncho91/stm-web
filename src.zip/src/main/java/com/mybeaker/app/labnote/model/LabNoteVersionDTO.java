package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LabNoteVersionDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("vVersionTxt")
	private String vVersionTxt;

	@JsonProperty("vCounterTypeCd")
	private String vCounterTypeCd;

	@JsonProperty("vCounterTypeNm")
	private String vCounterTypeNm;

	@JsonProperty("vCounterCd")
	private String vCounterCd;

	@JsonProperty("vCounterContPkCd")
	private String vCounterContPkCd;

	@JsonProperty("vCounterContCd")
	private String vCounterContCd;

	@JsonProperty("vCounterContNm")
	private String vCounterContNm;

	@JsonProperty("vCounterInvenCd")
	private String vCounterInvenCd;

	@JsonProperty("vCounterInvenJoinCd")
	private String vCounterInvenJoinCd;

	@JsonProperty("vCounterInvenNm")
	private String vCounterInvenNm;

	@JsonProperty("vCounterSpCd")
	private String vCounterSpCd;

	@JsonProperty("vCounterNote")
	private String vCounterNote;

	@JsonProperty("vCounterBrdNm")
	private String vCounterBrdNm;

	@JsonProperty("vCounterPrdNm")
	private String vCounterPrdNm;

	@JsonProperty("vCounterSpInfo")
	private String vCounterSpInfo;

	@JsonProperty("vPrePilotDt")
	private String vPrePilotDt;

	@JsonProperty("vFlagNewItem")
	private String vFlagNewItem;

	@JsonProperty("vPerfumeCd")
	private String vPerfumeCd;

	@JsonProperty("vPerfumeNm")
	private String vPerfumeNm;

	@JsonProperty("vFlagPerfumeNew")
	private String vFlagPerfumeNew;

	@JsonProperty("vRefTypeCd")
	private String vRefTypeCd;

	@JsonProperty("vRefTypeNm")
	private String vRefTypeNm;

	@JsonProperty("vRefContCd")
	private String vRefContCd;

	@JsonProperty("vEvaluateCd")
	private String vEvaluateCd;

	@JsonProperty("vEvaluateGosiCd")
	private String vEvaluateGosiCd;

	@JsonProperty("vSsrid")
	private String vSsrid;

	@JsonProperty("vSsrPrdnm")
	private String vSsrPrdnm;

	@JsonProperty("vSsrContentcd")
	private String vSsrContentcd;

	@JsonProperty("vEvaluateno")
	private String vEvaluateno;

	@JsonProperty("vEvaluateGosiNo")
	private String vEvaluateGosiNo;

	@JsonProperty("vShape")
	private String vShape;

	@JsonProperty("vRefNote")
	private String vRefNote;

	@JsonProperty("vRegUserid")
	private String vRegUserid;

	@JsonProperty("vRegDtm")
	private String vRegDtm;

	@JsonProperty("vFlagModify")
	private String vFlagModify;

	@JsonProperty("vG1PqcCd")
	private String vG1PqcCd;

	@JsonProperty("vG1StatusCd")
	private String vG1StatusCd;

	@JsonProperty("nG1ObeyPer")
	private double nG1ObeyPer;

	@JsonProperty("vG1Comment")
	private String vG1Comment;

	@JsonProperty("vG2PqcCd")
	private String vG2PqcCd;

	@JsonProperty("vG2StatusCd")
	private String vG2StatusCd;

	@JsonProperty("nG2ObeyPer")
	private double nG2ObeyPer;

	@JsonProperty("vG2Comment")
	private String vG2Comment;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vLotCd")
	private String vLotCd;

	private List<LabNoteCommonTagDTO> funcList;

	private List<LabNoteCommonRequestMateDTO> newMateList;

	private List<LabNoteCommonRequestMateDTO> perfMateList;

	private List<LabNoteCommonRequestMateDTO> funcMateList;

	private List<LabNoteCommonRequestMateDTO> requMateList;
	
	@JsonProperty("vEvaluateGosiNm")
	private String vEvaluateGosiNm;
	
	@JsonProperty("vDosageCd")
	private String vDosageCd;
	
	@JsonProperty("vDosageCdList")
	private String vDosageCdList;
	
	@JsonProperty("vDosageNmList")
	private String vDosageNmList;
	
	@JsonProperty("vFlagDecide")
	private String vFlagDecide;
	
	@JsonProperty("vDecideContNm")
	private String vDecideContNm;
	
}
