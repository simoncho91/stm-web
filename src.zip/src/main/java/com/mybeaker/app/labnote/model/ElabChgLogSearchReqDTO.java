package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentPagingDTO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class ElabChgLogSearchReqDTO extends ParentPagingDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vChgLogTypeAll")
	private String vChgLogTypeAll;

	@JsonProperty("vStartDt")
	private String vStartDt;

	@JsonProperty("vEndDt")
	private String vEndDt;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("arrChgLogTypeCd")
	private List<String> arrChgLogTypeCd;

	private String localLanguage;
}
