package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class PilotRequestRegInfoReqDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("vNoteType")
	private String vNoteType;
	
	private String[] arrLotCd;

	private String[] arrContCd;

	private String[] arrPlantCd;
}
