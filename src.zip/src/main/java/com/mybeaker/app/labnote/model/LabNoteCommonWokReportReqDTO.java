package com.mybeaker.app.labnote.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LabNoteCommonWokReportReqDTO {

	private String vRecordid;
	
	private String vTitle;
	
	private String vApprCd;
	
	private String vApprStatus;
	
	private String vDocType;
	
	private String vDocClass;
	
	private String vStorageCd;
	
	private String vFinishCd;
	
	private String vKeyword;
	
	private String vRegUserid;
	
	private String vUpdateUserid;
	
	private String sigma_deptcd;
	
	private String vBusinessCd;
	
	private String vPjtOrder;
	
	private String vNewsNo;
	
	private String vBasicDay;
	
	private String vNewsExecuter;
	
	private String vNewsHomePage;
	
	private String vFlagContact;
	
	private String vPurpose;
	
	private String vSort;
	
	private String vReceiptStatus;
	
	private String vPLMYn;
	
	private String vPlmCd;
	
	private String vProductRefcd;
	
	private String vProductRefNm;
	
	private String vProductRefNmEn;
	
	private String vBrandRefNm;
	
	private String vBrandRefNmEn;
	
	private String vLaborUserId;
	
	private String vLaborUserId2;
	
	private String vProductClass;
	
	private String vConfirm;
	
	private String vLimitDate;
	
	private String vProductShelfLife;
	
	private String vProductPao;
	
	private String vWerks;
	
	private String vContent;
	
	private String vTotExpense;
	
	private String vUtilityId;
	
	private String vFlagReportDel;
	
	private String vLabNoteCd;
	
	private String vContCd;
	
	private int nVersion;
	
	private String vFlagChina;
	
	private String vProductType;
	
	private String vProductArea;

	private String vOdmRecordId;
	
	private String vKfdaDocType;
	
	private String vReportType;
	
	private String vTag;
	
	private String vSecurityReason;
	
	private String vTempUvCode;
	
	private String vTmpRegUserid;
	
	private String vApprovalYn;
	
	private String vFinishDtm;
	
	private String vUpdateFinalDtm;
	
	private String vBuffer1;
	
}
