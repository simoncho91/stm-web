package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteTestQrCodeInfoDTO {
	
	@JsonProperty("vProductCd")
	private String vProductCd;
	
	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vProductNm")
	private String vProductNm;

	@JsonProperty("vSapCd")
	private String vSapCd;
	
	@JsonProperty("vDocNo")
	private String vDocNo;

	@JsonProperty("nLabNoteVer")
	private int nLabNoteVer;

	@JsonProperty("vLabNoteVerNm")
	private String vLabNoteVerNm;

	@JsonProperty("vLotNm")
	private String vLotNm;

	@JsonProperty("vUsernm")
	private String vUsernm;
	
	@JsonProperty("vDeptNm")
	private String vDeptNm;
	
	@JsonProperty("vReqDtm")
	private String vReqDtm;
	
	@JsonProperty("vLabMrqTypeCd")
	private String vLabMrqTypeCd;
	
	@JsonProperty("vMrqTypeCd")
	private String vMrqTypeCd;
	
	@JsonProperty("vLabMrqTypeNm")
	private String vLabMrqTypeNm;
	
	@JsonProperty("vLabMrqTypeColor")
	private String vLabMrqTypeColor;
	
	@JsonProperty("vQrDivCode")
	private String vQrDivCode;
	
}
