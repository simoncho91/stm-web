package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.common.model.UploadTempDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LabNoteProcessFuncReportReqSaveDTO {

	private String localLanguage;
	
	@JsonProperty("vNoteType")
	private String vNoteType;
	
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("nVersion")
	private int nVersion;
	
	@JsonProperty("vSenderId")
	private String vSenderId;
	
	@JsonProperty("vReqContent")
	private String vReqContent;
	
	@JsonProperty("vTitle")
	private String vTitle;
	
	@JsonProperty("nSeqno")
	private int nSeqno;
	
	@JsonProperty("vRecordid")
	private String vRecordid;
	
	@JsonProperty("vRegUserid")
	private String vRegUserid;
	
	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;
	
	@JsonProperty("vNumberNm")
	private String vNumberNm;
	
	@JsonProperty("nTioTwoRate")
	private double nTioTwoRate;
	
	@JsonProperty("nZnoRate")
	private double nZnoRate;
	
	@JsonProperty("vTioTwoNote")
	private String vTioTwoNote;
	
	@JsonProperty("vZnoNote")
	private String vZnoNote;
	
	@JsonProperty("vFlagOverEthanol")
	private String vFlagOverEthanol;
	
	@JsonProperty("vPh")
	private String vPh;
	
	@JsonProperty("vMaker")
	private String vMaker;
	
	@JsonProperty("vEvaluateNum")
	private String vEvaluateNum;
	
	@JsonProperty("vChangeProduct")
	private String vChangeProduct;
	
	@JsonProperty("vChangeCd")
	private String vChangeCd;
	
	@JsonProperty("vChangeNote")
	private String vChangeNote;
	
	@JsonProperty("vEffect")
	private String vEffect;
	
	@JsonProperty("vUsageCapacity")
	private String vUsageCapacity;
	
	@JsonProperty("vMakePlace")
	private String vMakePlace;
	
	@JsonProperty("vTwoLiq")
	private String vTwoLiq;
	
	@JsonProperty("vTwoLiqTxt")
	private String vTwoLiqTxt;
	
	@JsonProperty("arrContCd")
	private String [] arrContCd;
	
	@JsonProperty("arrLotCd")
	private String [] arrLotCd;
	
	@JsonProperty("arrQaUserId")
	private String [] arrQaUserId;
	
	@JsonProperty("vUploadCd")
	private String vUploadCd;
	
	@JsonProperty("fileList")
	private List<UploadTempDTO> fileList;
	
	@JsonProperty("vRepresentCd")
	private String vRepresentCd;
	
	@JsonProperty("vMakerTxt")
	private String vMakerTxt;
	
	@JsonProperty("vRefNote")
	private String vRefNote;
	
	@JsonProperty("arrQmsLotInfo")
	private String [] arrQmsLotInfo;
	
	@JsonProperty("arrQmsContNm")
	private String [] arrQmsContNm;
	
	@JsonProperty("vQmsPlantCd")
	private String vQmsPlantCd;
	
	@JsonProperty("vContCd")
	private String vContCd;
	
	@JsonProperty("vContNm")
	private String vContNm;
	
	@JsonProperty("vLotCd")
	private String vLotCd;
	
	@JsonProperty("vUserId")
	private String vUserId;
	
	@JsonProperty("nQmsSeq")
	private int nQmsSeq;
	
	@JsonProperty("vQmsDate")
	private String vQmsDate;
	
	@JsonProperty("vQmsLot")
	private String vQmsLot;
	
}
