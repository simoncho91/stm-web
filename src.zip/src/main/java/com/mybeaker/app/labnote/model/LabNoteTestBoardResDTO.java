package com.mybeaker.app.labnote.model;

import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LabNoteTestBoardResDTO<T> {

	private T noteInfo;

	private List<?> contList;

	private List<?> verLotList;

	private List<?> list;

	private Map<String, ?> resultMap;

}
