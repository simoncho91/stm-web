package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class WokReportResDTO {

	@JsonProperty("vRecordid")
	private String vRecordid;

	@JsonProperty("vTitle")
	private String vTitle;

	@JsonProperty("vApprCd")
	private String vApprCd;

	@JsonProperty("vApprStatus")
	private String vApprStatus;

	@JsonProperty("vDeptnm")
	private String vDeptnm;
	
	@JsonProperty("cContent")
	private String cContent;
	
	@JsonProperty("vDocClass")
	private String vDocClass;
	
	@JsonProperty("vDocClass1Cd")
	private String vDocClass1Cd;
	
	@JsonProperty("vDocClassnm")
	private String vDocClassnm;
	
	@JsonProperty("vFullClassnm")
	private String vFullClassnm;
	
	@JsonProperty("vDocClassnmEn")
	private String vDocClassnmEn;
	
	@JsonProperty("vFullClassnmEn")
	private String vFullClassnmEn;
	
	@JsonProperty("vFlagShare")
	private String vFlagShare;
	
	@JsonProperty("nReqShareCnt")
	private String nReqShareCnt;
	
	@JsonProperty("vDocType")
	private String vDocType;
	
	@JsonProperty("vDocTypenm")
	private String vDocTypenm;
	
	@JsonProperty("vStorageCd")
	private String vStorageCd;
	
	@JsonProperty("vStorageNm")
	private String vStorageNm;
	
	@JsonProperty("vFinishYear")
	private String vFinishYear;
	
	@JsonProperty("vFinishCd")
	private String vFinishCd;
	
	@JsonProperty("vKeyword")
	private String vKeyword;
	
	@JsonProperty("vYearReg")
	private String vYearReg;
	
	@JsonProperty("vPositnm")
	private String vPositnm;
	
	@JsonProperty("vFlagnm")
	private String vFlagnm;
	
	@JsonProperty("vReceiptStatus")
	private String vReceiptStatus;
	
	@JsonProperty("vReceiptStatusnm")
	private String vReceiptStatusnm;
	
	@JsonProperty("vPurpose")
	private String vPurpose;
	
	@JsonProperty("vPhoneno")
	private String vPhoneno;
	
	@JsonProperty("vEmail")
	private String vEmail;
	
	@JsonProperty("vRegDtm")
	private String vRegDtm;
	
	@JsonProperty("vRegUserid")
	private String vRegUserid;
	
	@JsonProperty("vRegUserNm")
	private String vRegUserNm;
	
	@JsonProperty("vUpdateDtm")
	private String vUpdateDtm;
	
	@JsonProperty("vPjtNm")
	private String vPjtNm;
	
	@JsonProperty("vPjtCd")
	private String vPjtCd;
	
	@JsonProperty("nNewsNo")
	private int nNewsNo;
	
	@JsonProperty("vBasicDay")
	private String vBasicDay;
	
	@JsonProperty("vNewsExecuter")
	private String vNewsExecuter;
	
	@JsonProperty("vBusinessCd")
	private String vBusinessCd;
	
	@JsonProperty("vNewsHomepage")
	private String vNewsHomepage;
	
	@JsonProperty("vFlagPlm")
	private String vFlagPlm;
	
	@JsonProperty("vPlmType")
	private String vPlmType;
	
	@JsonProperty("vType")
	private String vType;
	
	@JsonProperty("vBuffer1")
	private String vBuffer1;
	
	@JsonProperty("vNewsYn")
	private String vNewsYn;
	
	@JsonProperty("vApprStatus2")
	private String vApprStatus2;
	
	@JsonProperty("vApprStatus2nm")
	private String vApprStatus2nm;
	
	@JsonProperty("vStudyDtm")
	private String vStudyDtm;
	
	@JsonProperty("vKfdaReceiveDtm")
	private String vKfdaReceiveDtm;
	
	@JsonProperty("vKfdaCompleteDtm")
	private String vKfdaCompleteDtm;
	
	@JsonProperty("vEndDtm")
	private String vEndDtm;
	
	@JsonProperty("vReportDtm")
	private String vReportDtm;
	
	@JsonProperty("vStatus02Cd")
	private String vStatus02Cd;
	
	@JsonProperty("vStatus03Cd")
	private String vStatus03Cd;
	
	@JsonProperty("vStatus04Cd")
	private String vStatus04Cd;
	
	@JsonProperty("vStatus05Cd")
	private String vStatus05Cd;
	
	@JsonProperty("vProductCd")
	private String vProductCd;
	
	@JsonProperty("vProductCdCnt")
	private int vProductCdCnt;
	
	@JsonProperty("vProductNm")
	private String vProductNm;
	
	@JsonProperty("vProductNmEn")
	private String vProductNmEn;
	
	@JsonProperty("vBrandNm")
	private String vBrandNm;
	
	@JsonProperty("vBrandNmEn")
	private String vBrandNmEn;
	
	@JsonProperty("vLaborUserid")
	private String vLaborUserid;
	
	@JsonProperty("vLaborUserid2")
	private String vLaborUserid2;
	
	@JsonProperty("vLaborUsernm")
	private String vLaborUsernm;
	
	@JsonProperty("vLaborUsernm2")
	private String vLaborUsernm2;
	
	@JsonProperty("vLaborEmail")
	private String vLaborEmail;
	
	@JsonProperty("vLaborEmail2")
	private String vLaborEmail2;
	
	@JsonProperty("vProductType")
	private String vProductType;
	
	@JsonProperty("vProductTypeNm")
	private String vProductTypeNm;
	
	@JsonProperty("vFlagPao")
	private String vFlagPao;
	
	@JsonProperty("nLife")
	private int nLife;
	
	@JsonProperty("nPao")
	private int nPao;
	
	@JsonProperty("vFlagConfirm")
	private String vFlagConfirm;
	
	@JsonProperty("vLimitDate")
	private String vLimitDate;
	
	@JsonProperty("vShelfLife")
	private String vShelfLife;
	
	@JsonProperty("vPao")
	private String vPao;
	
	@JsonProperty("vWerks")
	private String vWerks;
	
	@JsonProperty("nExpense")
	private int nExpense;
	
	@JsonProperty("vManagerid")
	private String vManagerid;
	
	@JsonProperty("vUtilityUserid")
	private String vUtilityUserid;
	
	@JsonProperty("vUtilityUsernm")
	private String vUtilityUsernm;
	
	@JsonProperty("vUtilityEmail")
	private String vUtilityEmail;
	
	@JsonProperty("vUtilityPeriod")
	private String vUtilityPeriod;
	
	@JsonProperty("vUtilityResult")
	private String vUtilityResult;
	
	@JsonProperty("nViewCnt")
	private int nViewCnt;
	
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("vContCd")
	private String vContCd;
	
	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vFinishDt")
	private String vFinishDt;
	
	@JsonProperty("vPifProductType")
	private String vPifProductType;
	
	@JsonProperty("vPifProductArea")
	private String vPifProductArea;

	@JsonProperty("vPifProductTypeNm")
	private String vPifProductTypeNm;
	
	@JsonProperty("vPifProductAreaNm")
	private String vPifProductAreaNm;
	
	@JsonProperty("vOdmRecordid")
	private String vOdmRecordid;
	
	@JsonProperty("vKfdaChrgerid")
	private String vKfdaChrgerid;
	
	@JsonProperty("vKfdaChrgernm")
	private String vKfdaChrgernm;
	
	@JsonProperty("vKfdaDocType")
	private String vKfdaDocType;

	@JsonProperty("vReportFinishno")
	private String vReportFinishno;
	
	@JsonProperty("vLinkageType")
	private String vLinkageType;
	
	@JsonProperty("vLinkageRecordid")
	private String vLinkageRecordid;
	
	@JsonProperty("vTag")
	private String vTag;
	
	@JsonProperty("vSecurityReason")
	private String vSecurityReason;
	
	@JsonProperty("vSecurityPeriod")
	private String vSecurityPeriod;
	
	@JsonProperty("vRepType")
	private String vRepType;
	
	@JsonProperty("vTempUvCode")
	private String vTempUvCode;
	
}
