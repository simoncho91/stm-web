package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
public class LabNoteCommonAuthDeptDTO extends ParentDTO {
	@JsonProperty("vSubCode")
	private String vSubCode;

	@JsonProperty("vSubCodenm")
	private String vSubCodenm;

	@JsonProperty("vNoteType")
	private String vNoteType;

	@JsonProperty("vDeptCd")
	private String vDeptCd;

	@JsonProperty("vSigmaDeptnm")
	private String vSigmaDeptnm;
	
	@Builder
	public LabNoteCommonAuthDeptDTO(
			String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm,
			String vSubCode, String vSubCodenm, String vNoteType, String vDeptCd, String vSigmaDeptnm) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.vSubCode = vSubCode;
		this.vSubCodenm = vSubCodenm;
		this.vNoteType = vNoteType;
		this.vDeptCd = vDeptCd;
		this.vSigmaDeptnm = vSigmaDeptnm;
	}
}
