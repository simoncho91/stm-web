package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.approval.model.ApprovalDetailDTO;
import com.mybeaker.app.skincare.model.IngredientContVO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LabNoteProcessFuncDecideResDTO{

	@JsonProperty("resVo")
	LabNoteProcessFuncResDTO resVo;
	
	@JsonProperty("nameList")
	List<IngredientContVO> nameList;
	
	@JsonProperty("apprList")
    List<ApprovalDetailDTO> apprList;

	@JsonProperty("savedNameList")
	List<FuncDecideContNameVO> savedNameList;
}
