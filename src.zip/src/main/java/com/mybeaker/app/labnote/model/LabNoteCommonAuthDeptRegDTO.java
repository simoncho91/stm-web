package com.mybeaker.app.labnote.model;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteCommonAuthDeptRegDTO {
	@JsonProperty("authDeptMap")
	private Map<String, List<LabNoteCommonAuthDeptDTO>> authDeptMap;
}
