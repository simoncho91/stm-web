package com.mybeaker.app.labnote.model;

import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@Data
public class ElabHisPreRateVO extends ParentDTO {

	private String vLotCd;

	private String vMatePkCd;

	private String vMateCd;

	private int nRate;

	private String vFlagRateRest;

	private String vMateDbLotCd;

	private int nSort;

	@Builder
	public ElabHisPreRateVO(String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm,
			String vLotCd, String vMatePkCd, String vMateCd, int nRate, String vFlagRateRest, String vMateDbLotCd,
			int nSort) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.vLotCd = vLotCd;
		this.vMatePkCd = vMatePkCd;
		this.vMateCd = vMateCd;
		this.nRate = nRate;
		this.vFlagRateRest = vFlagRateRest;
		this.vMateDbLotCd = vMateDbLotCd;
		this.nSort = nSort;
	}
}
