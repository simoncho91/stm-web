package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LabNoteProcessFuncMateResDTO {

	@JsonProperty("vMatePkCd")
	private String vMatePkCd;
	
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("vContPkCd")
	private String vContPkCd;
	
	@JsonProperty("nVersion")
	private int nVersion;
	
	@JsonProperty("vGrpCd")
	private String vGrpCd;
	
	@JsonProperty("vMateCd")
	private String vMateCd;
	
	@JsonProperty("vMateDbTypeCd")
	private String vMateDbTypeCd;
	
	@JsonProperty("vMateDbMstCd")
	private String vMateDbMstCd;
	
	@JsonProperty("vMateNm")
	private String vMateNm;
	
	@JsonProperty("nReqRate")
	private int nReqRate;
	
	@JsonProperty("vFlagRequired")
	private String vFlagRequired;
	
	@JsonProperty("vFlagRateFixed")
	private String vFlagRateFixed;
	
	@JsonProperty("vFlagReq")
	private String vFlagReq;
	
	@JsonProperty("vNote")
	private String vNote;
	
	@JsonProperty("nSortReq")
	private int nSortReq;
	
	@JsonProperty("nSort")
	private int nSort;
	
	@JsonProperty("vFlagDel")
	private String vFlagDel;
	
	@JsonProperty("vRegUserid")
	private String vRegUserid;
	
	@JsonProperty("vRegDtm")
	private String vRegDtm;
	
	@JsonProperty("vUpdateDtm")
	private String vUpdateDtm;
	
	@JsonProperty("vFlagTo100")
	private String vFlagTo100;
	
	@JsonProperty("vMateTempCd")
	private String vMateTempCd;
	
	@JsonProperty("vMatePermitNm")
	private String vMatePermitNm;
	
}
