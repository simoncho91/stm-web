package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ChinaSafetyMstVO {

	@JsonProperty("vRecordid")
	private String vRecordid;

	@JsonProperty("vStatusCd")
	private String vStatusCd;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vLeaveonyn")
	private String vLeaveonyn;

	@JsonProperty("vVer")
	private String vVer;

	@JsonProperty("vLot")
	private String vLot;

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("vReqUserid")
	private String vReqUserid;

	@JsonProperty("vReviewUserid")
	private String vReviewUserid;

	@JsonProperty("vBrand")
	private String vBrand;

	@JsonProperty("vTddProdType")
	private String vTddProdType;

	@JsonProperty("vDivFlag")
	private String vDivFlag;

	@JsonProperty("vPrdct")
	private String vPrdct;

	@JsonProperty("vTgpol")
	private String vTgpol;

	@JsonProperty("vZpqew")
	private String vZpqew;

	@JsonProperty("vUsep")
	private String vUsep;

	@JsonProperty("vGday")
	private String vGday;

	@JsonProperty("vMgday")
	private String vMgday;

	@JsonProperty("vRfdt")
	private String vRfdt;

	@JsonProperty("vMkday")
	private String vMkday;

	@JsonProperty("vExcelFlag")
	private String vExcelFlag;

	@JsonProperty("vRegUserid")
	private String vRegUserid;

	@JsonProperty("vRegDtm")
	private String vRegDtm;
}
