package com.mybeaker.app.labnote.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class SapCallLogMdi0005VO {

	private String vLogCd;

	private String vMatnr;

	private String vMhdhb;
	
	private String vErsda;
	
	private String vLaeda;
	
	private String vCudCi;
	
	private String vMatFlag;
	
	private String vIprkz;
	
	private String vEmsgty;
	
	private String vEmsg;
	
	private String vRegUserid;
	
	private String vDtm;
}
