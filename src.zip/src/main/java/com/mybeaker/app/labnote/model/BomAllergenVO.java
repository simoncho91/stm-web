package com.mybeaker.app.labnote.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class BomAllergenVO {

	private String hal4Cd;
	
	private String rawCd;
	
	private String rawPer;
	
	private String concd;
	
	private String conPer;
	
	private String lvl;
	
	private String concdO;
}
