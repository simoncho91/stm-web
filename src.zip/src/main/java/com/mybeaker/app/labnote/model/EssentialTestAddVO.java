package com.mybeaker.app.labnote.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class EssentialTestAddVO {

	private String vProductCd;
	
	private int nVersion;
	
	private String vTypeCd;
	
	private String vTypeCd2;
	
	private String vRegUserid;
	
	private String vLabNoteCd;
}
