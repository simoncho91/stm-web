package com.mybeaker.app.labnote.service;

import java.text.DecimalFormat;
//import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.mybeaker.app.approval.model.ApprovalDTO;
import com.mybeaker.app.approval.model.ReqReferenceDTO;
import com.mybeaker.app.common.form.MailForm;
import com.mybeaker.app.common.model.AlarmRegDTO;
import com.mybeaker.app.common.model.CodeDTO;
import com.mybeaker.app.common.model.CommUserDesSearchInfoDTO;
import com.mybeaker.app.common.model.MessageDTO;
import com.mybeaker.app.common.service.CommonService;
import com.mybeaker.app.labnote.mapper.LabNoteCommonMapper;
import com.mybeaker.app.labnote.model.*;
import com.mybeaker.app.model.Const;
import com.mybeaker.app.model.dto.PagingDTO;
import com.mybeaker.app.model.dto.ResCommSearchInfoDTO;
import com.mybeaker.app.model.enums.ApprovalResultCode;
import com.mybeaker.app.model.enums.CommonResultCode;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.skincare.model.BookmarkVO;
import com.mybeaker.app.skincare.model.ElabLotMemoVO;
import com.mybeaker.app.skincare.model.ShelfLifeReqDTO;
import com.mybeaker.app.skincare.model.ShelfLifeResDTO;
import com.mybeaker.app.utils.CommonUtil;
import com.mybeaker.app.utils.ConvertUtil;
import com.mybeaker.app.utils.MailUtil;
import com.mybeaker.app.utils.PropertyUtil;
import com.mybeaker.app.utils.SessionUtil;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class LabNoteCommonService {
	private final LabNoteCommonMapper labNoteCommonMapper;

	private final SessionUtil sessionUtil;

	private final LabNoteSAPInterfaceService labNoteSAPInterfaceService;

	private final CommonService commonService;

	public int selectPtsProjectListCount(LabNoteCommonReqProjectSearchDTO reqProjectSearchDTO) {
		reqProjectSearchDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
		reqProjectSearchDTO.setArrStatusCd(Arrays.asList("PJT_S010", "PJT_S020", "PJT_S021", "PJT_S030", "PJT_S035", "PJT_S036", "PJT_S040"));
		reqProjectSearchDTO.setArrPjtType1Cd(Arrays.asList("PTS01_T010", "PTS01_T020"));
		return labNoteCommonMapper.selectPtsProjectListCount(reqProjectSearchDTO);
	}

	public List<LabNoteCommonProjectDTO> selectPtsProjectList(LabNoteCommonReqProjectSearchDTO reqProjectSearchDTO) {
		reqProjectSearchDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
		reqProjectSearchDTO.setArrStatusCd(Arrays.asList("PJT_S010", "PJT_S020", "PJT_S021", "PJT_S030", "PJT_S035", "PJT_S036", "PJT_S040"));
		reqProjectSearchDTO.setArrPjtType1Cd(Arrays.asList("PTS01_T010", "PTS01_T020"));
		return labNoteCommonMapper.selectPtsProjectList(reqProjectSearchDTO);
	}

	public String selectZqmtExistsMatnrInfo(LabNoteCommonReqSAPSyncDTO reqSAPSyncDTO) {
		return labNoteCommonMapper.selectZqmtExistsMatnrInfo(reqSAPSyncDTO);
	}

	public String selectZqmtContNm(LabNoteCommonReqSAPSyncDTO reqSAPSyncDTO) {
		return labNoteCommonMapper.selectZqmtContNm(reqSAPSyncDTO);
	}

	public int insertElabNoteFinalLotSAPInfo(LabNoteCommonSAPSyncDTO sapSyncDTO) {
		return labNoteCommonMapper.insertElabNoteFinalLotSAPInfo(sapSyncDTO);
	}

	public int selectSearchMateListCount(LabNoteCommonReqSearchMateDTO labNoteCommonReqSearchMateDTO) {
		return labNoteCommonMapper.selectSearchMateListCount(labNoteCommonReqSearchMateDTO);
	}

	public List<LabNoteCommonSearchMateDTO> selectSearchMateList(
			LabNoteCommonReqSearchMateDTO labNoteCommonReqSearchMateDTO) {
		labNoteCommonReqSearchMateDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
		List<LabNoteCommonSearchMateDTO> list = labNoteCommonMapper.selectSearchMateList(labNoteCommonReqSearchMateDTO);

		if(StringUtils.isNotEmpty(labNoteCommonReqSearchMateDTO.getVNoteType()) && "MU".equals(labNoteCommonReqSearchMateDTO.getVNoteType())) {
			Map<String, List<CodeDTO>> codeMap = commonService.selectCodeListMap(List.of("TONING_LIST"));
			List<CodeDTO> toningList = !ObjectUtils.isEmpty(codeMap) ? codeMap.get("TONING_LIST") : null;

			list.forEach(o -> {
				if(!ObjectUtils.isEmpty(toningList)) {
					if(toningList.stream()
							.filter(t -> t.getVSubCode().equals(o.getVMateCd()))
							.count() > 0) {
						o.setVFlagColorMate("Y");
					}
				}
			});
		}
		return list;
	}

	public List<LabNoteCommonMateCheckDTO> selectCheckClearList(List<String> arrMaterialCd, String vType) {
		return labNoteCommonMapper.selectCheckClearList(arrMaterialCd, vType);
	}

	public int selectSearchMateTempListCount(LabNoteCommonReqSearchMateDTO labNoteCommonReqSearchMateDTO) {
		return labNoteCommonMapper.selectSearchMateTempListCount(labNoteCommonReqSearchMateDTO);
	}

	public List<LabNoteCommonSearchMateDTO> selectSearchMateTempList(
			LabNoteCommonReqSearchMateDTO labNoteCommonReqSearchMateDTO) {
		return labNoteCommonMapper.selectSearchMateTempList(labNoteCommonReqSearchMateDTO);
	}

	public int selectSearchMyMateListCount(LabNoteCommonReqSearchMateDTO labNoteCommonReqSearchMateDTO) {
		labNoteCommonReqSearchMateDTO.setVUserid(sessionUtil.getLoginId());
		return labNoteCommonMapper.selectSearchMyMateListCount(labNoteCommonReqSearchMateDTO);
	}

	public List<LabNoteCommonSearchMateDTO> selectSearchMyMateList(
			LabNoteCommonReqSearchMateDTO labNoteCommonReqSearchMateDTO) {
		labNoteCommonReqSearchMateDTO.setVUserid(sessionUtil.getLoginId());

		return labNoteCommonMapper.selectSearchMyMateList(labNoteCommonReqSearchMateDTO);
	}

	private LabNoteCommonReqSearchEvalDTO setEvaluationCondition (LabNoteCommonReqSearchEvalDTO labNoteCommonReqSearchEvalDTO) {
		labNoteCommonReqSearchEvalDTO.setLocalLanguage(sessionUtil.getLocalLanguage());

		if (StringUtils.isNotEmpty(labNoteCommonReqSearchEvalDTO.getVMateKeyword())) {
			labNoteCommonReqSearchEvalDTO.setArrPriorContent(Arrays.asList(labNoteCommonReqSearchEvalDTO.getVMateKeyword().split(",")));
		}

		if (StringUtils.isNotEmpty(labNoteCommonReqSearchEvalDTO.getVSrcSpf())) {
			String[] arrSpf = labNoteCommonReqSearchEvalDTO.getVSrcSpf().split("_");
			labNoteCommonReqSearchEvalDTO.setVStSpf(arrSpf[0]);

			if (arrSpf.length > 1) {
				labNoteCommonReqSearchEvalDTO.setVEnSpf(arrSpf[1]);
			}
		}

		if (labNoteCommonReqSearchEvalDTO.getArrPa() != null && !labNoteCommonReqSearchEvalDTO.getArrPa().isEmpty()) {
			labNoteCommonReqSearchEvalDTO.setVSrcPaVal("Y");

			Optional<String> firstPAValue = labNoteCommonReqSearchEvalDTO.getArrPa().stream().findFirst();

			labNoteCommonReqSearchEvalDTO.getArrPa().forEach(item -> {
				if ("PA+".equals(item)) {
					labNoteCommonReqSearchEvalDTO.setVPa1("Y");
				} else if ("PA++".equals(item)) {
					labNoteCommonReqSearchEvalDTO.setVPa2("Y");
					if (item.equals(firstPAValue.get())) {
						labNoteCommonReqSearchEvalDTO.setVPa2First("Y");
					}
				} else if ("PA+++".equals(item)) {
					labNoteCommonReqSearchEvalDTO.setVPa3("Y");
					if (item.equals(firstPAValue.get())) {
						labNoteCommonReqSearchEvalDTO.setVPa3First("Y");
					}
				} else if ("PA++++".equals(item)) {
					labNoteCommonReqSearchEvalDTO.setVPa4("Y");
					if (item.equals(firstPAValue.get())) {
						labNoteCommonReqSearchEvalDTO.setVPa4First("Y");
					}
				}
			});
		}

		return labNoteCommonReqSearchEvalDTO;
	}

	public int selectEvaluationListCount(LabNoteCommonReqSearchEvalDTO labNoteCommonReqSearchEvalDTO) {
		labNoteCommonReqSearchEvalDTO = this.setEvaluationCondition(labNoteCommonReqSearchEvalDTO);
		return labNoteCommonMapper.selectEvaluationListCount(labNoteCommonReqSearchEvalDTO);
	}

	public List<LabNoteCommonEvaluationDTO> selectEvaluationList(
			LabNoteCommonReqSearchEvalDTO labNoteCommonReqSearchEvalDTO) {

		labNoteCommonReqSearchEvalDTO = this.setEvaluationCondition(labNoteCommonReqSearchEvalDTO);
		return labNoteCommonMapper.selectEvaluationList(labNoteCommonReqSearchEvalDTO);
	}

	public List<LabNoteCommonTddProdTypeDTO> selectTddProdTypeList(String vFlagSub, String vNoteType, String vClassCd) {
		return labNoteCommonMapper.selectTddProdTypeList(vFlagSub, vNoteType, vClassCd);
	}

	public int selectSearchProdListCount(LabNoteCommonReqProdSearchDTO labNoteCommonReqProdSearchDTO) {
		String vKeyword = labNoteCommonReqProdSearchDTO.getVKeyword();
		List<String> arrKeyword = null;

		if (StringUtils.isNotEmpty(vKeyword) && vKeyword.indexOf(" ") > -1) {
			vKeyword = vKeyword.replaceAll("\\s+", " ");
			arrKeyword = Arrays.asList(vKeyword.split("\\s"));
		}

		labNoteCommonReqProdSearchDTO.setArrKeyword(arrKeyword);

		return labNoteCommonMapper.selectSearchProdListCount(labNoteCommonReqProdSearchDTO);
	}

	public List<LabNoteCommonProdSearchDTO> selectSearchProdList(LabNoteCommonReqProdSearchDTO labNoteCommonReqProdSearchDTO) {
		String vKeyword = labNoteCommonReqProdSearchDTO.getVKeyword();
		List<String> arrKeyword = null;

		if (StringUtils.isNotEmpty(vKeyword) && vKeyword.indexOf(" ") > -1) {
			vKeyword = vKeyword.replaceAll("\\s+", " ");
			arrKeyword = Arrays.asList(vKeyword.split("\\s"));
		}

		labNoteCommonReqProdSearchDTO.setArrKeyword(arrKeyword);

		return labNoteCommonMapper.selectSearchProdList(labNoteCommonReqProdSearchDTO);
	}

	public ResponseVO selectAuthDeptInfo() {
		ResponseVO responseVO = new ResponseVO();

		List<LabNoteCommonAuthDeptDTO> list = labNoteCommonMapper.selectAuthDeptInfo();
		Map<String, List<LabNoteCommonAuthDeptDTO>> authDeptMap = new HashMap<>();

		if (!ObjectUtils.isEmpty(list)) {
			authDeptMap = list.stream().collect(Collectors.groupingBy(LabNoteCommonAuthDeptDTO::getVSubCode));
		}

		responseVO.setOk(authDeptMap);
		return responseVO;
	}

	@Transactional
	public ResponseVO insertAuthDeptInfo(LabNoteCommonAuthDeptRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();

		labNoteCommonMapper.deleteLabNoteAuthDept();

		if (!ObjectUtils.isEmpty(regDTO.getAuthDeptMap())) {
			String vUserid = sessionUtil.getLoginId();

			Map<String, List<LabNoteCommonAuthDeptDTO>> authDeptMap = regDTO.getAuthDeptMap();

			Iterator<String> keys = authDeptMap.keySet().iterator();
			while (keys.hasNext()) {
				String strKey = keys.next();

				List<LabNoteCommonAuthDeptDTO> list = authDeptMap.get(strKey);

				if (!ObjectUtils.isEmpty(list)) {
					for (LabNoteCommonAuthDeptDTO dto : list) {
						dto.setVRegUserid(vUserid);
						dto.setVUpdateUserid(vUserid);

						labNoteCommonMapper.insertLabNoteAuthDept(dto);
					}
				}
			}
		}

		responseVO.setOk(Const.SUCC);
		return responseVO;
	}

	public int selectEvaluationMaterialListCount(LabNoteCommonReqEvalMateSearchDTO labNoteCommonReqEvalMateSearchDTO) {
		labNoteCommonReqEvalMateSearchDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
		return labNoteCommonMapper.selectEvaluationMaterialListCount(labNoteCommonReqEvalMateSearchDTO);
	}

	public List<LabNoteCommonEvalMaterialDTO> selectEvaluationMaterialList(
			LabNoteCommonReqEvalMateSearchDTO labNoteCommonReqEvalMateSearchDTO) {
		labNoteCommonReqEvalMateSearchDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
		return labNoteCommonMapper.selectEvaluationMaterialList(labNoteCommonReqEvalMateSearchDTO);
	}

//	원료배합 start
	@Transactional
	public ResponseVO updateSAPRepeat(SapRepeatRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();

		labNoteCommonMapper.updateSAPRepeat(ElabIngredientCheckVO.builder()
				.vWerks(regDTO.getVPlantCd())
				.mateCdList(regDTO.getMateCdList())
				.build());

		responseVO.setOk(Const.SUCC);
		return responseVO;
	}

	@Transactional
	public ResponseVO updateRefreshMatnr(SapRefreshMatnrRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();

		List<BomInfoVO> rfcList = null;
		String flag = "N";

		String matnr = regDTO.getVMatnr();
		String land1 = regDTO.getVLand1();
		String werks = regDTO.getVWerks();

		if(matnr.startsWith("4")) {
			rfcList = labNoteSAPInterfaceService.getT_ZPLMS013(werks, matnr, land1);
		}
		else {
			rfcList = labNoteSAPInterfaceService.getT_ZPLMS017(matnr, land1);
		}

		flag = !ObjectUtils.isEmpty(rfcList) ? "Y" : "N";

		if(matnr.startsWith("4") && "Y".equals(flag)) { // 4자코드 원료처방 저장
//			regDTO.put("i_sPlantCd", werks);
//			regDTO.put("i_sMateCd", matnr);
//			regDTO.put("i_sLand1", land1);

			this.insertHal4Mate(Hal4MateRegDTO.builder()
					.vMateCd(matnr)
					.vPlantCd(werks)
					.vLand1(land1)
					.build());
		}

//		regDTO.put("i_sFlagOrganization", flag);
//		this.cmDao.insert("LabNoteExperiment.insertElabIngredientCheck", regDTO);
		this.insertElabIngredientCheck(ElabIngredientCheckVO.builder()
				.vMatnr(matnr)
				.vWerks(werks)
				.vFlagOrganization(flag)
				.vLand1(land1)
				.build());

		responseVO.setOk(flag);
		return responseVO;
	}

	public String selectZplmt13Tx(String vMatnr, String vLand1) {
		return labNoteCommonMapper.selectZplmt13Tx(ElabIngredientCheckVO.builder()
				.vMatnr(vMatnr)
				.vLand1(vLand1)
				.build());
	}

	public ElabIngredientCheckVO selectElabIngredientCheck(String vMatnr, String vWerks, String vLand1) {
		return labNoteCommonMapper.selectElabIngredientCheck(ElabIngredientCheckVO.builder()
				.vMatnr(vMatnr)
				.vWerks(vWerks)
				.vLand1(vLand1)
				.build());
	}

	public int insertElabIngredientCheck(ElabIngredientCheckVO elabIngredientCheckVO) {
		return labNoteCommonMapper.insertElabIngredientCheck(elabIngredientCheckVO);
	}

	public ResponseVO selectMdlRequiredMaxList(MdlReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		List<MdlRequiredMaxVO> list = null;

		String sExceptMdlid = reqDTO.getVExceptMdlid();
		List<String> mdlidList = Optional.ofNullable(reqDTO.getMdlidList())
				.orElseGet(() -> List.of());

		if(StringUtils.isNotEmpty(sExceptMdlid) && !mdlidList.isEmpty()) {
			reqDTO.setMdlidList(mdlidList.stream()
					.filter(o -> !sExceptMdlid.equals(o))
					.collect(Collectors.toList()));

			list = labNoteCommonMapper.selectMdlRequiredMaxList(reqDTO);
		}

		responseVO.setOk(Optional.ofNullable(list)
				.orElseGet(() -> List.of()));
		return responseVO;
	}

	@Transactional
	public ResponseVO insertHal4Mate(Hal4MateRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();

		List<BomInfoVO> result = null;
		List<Mat3VO> bomList = null;

		//SAP호출
		result = labNoteSAPInterfaceService.getT_ZPLMS013_BOM(regDTO.getVPlantCd(), regDTO.getVMateCd(), regDTO.getVLand1());
		bomList	= labNoteSAPInterfaceService.selectMat3List(BomListVO.builder()
				.bomList(result)
				.build());

		// insert전에  전에 저장된 데이터가 있는지 확인 -> 있으면 삭제
		labNoteCommonMapper.deleteElabHal4Mate(ElabHal4MateVO.builder()
				.vHal4Cd(regDTO.getVMateCd())
				.vPlantCd(regDTO.getVPlantCd())
				.vLandCd(regDTO.getVLand1())
				.build());

		int i = 1;
		for(Mat3VO mat3VO : bomList){
			labNoteCommonMapper.insertElabHal4Mate(ElabHal4MateVO.builder()
					.vHal4Cd(regDTO.getVMateCd())
					.vPlantCd(regDTO.getVPlantCd())
					.vLandCd(regDTO.getVLand1())
					.vMateCd(mat3VO.getVMatCd()) //6자코드
					.vMateNm(mat3VO.getVMatNm()) //원료명
					.nRate(mat3VO.getNMatPer()) // 함량
					.nSeq(i++)
					.build());
		}

		responseVO.setOk(Const.SUCC);
		return responseVO;
	}

	public ResponseVO selcetScmTcodeList(ScmTCodeReqVO reqVO) {
		ResponseVO responseVO = new ResponseVO();

		List<Zplmt12MstVO> mstList = null;
		List<Zplmt12GlbVO> glbList = null;

		if("KR".equals(reqVO.getVLand1())) {
			mstList = labNoteCommonMapper.selectZplmt12MstList(reqVO);
		}
		else {
			glbList = labNoteCommonMapper.selectZplmt12GlbList(reqVO);
		}

		reqVO.setLanguage(sessionUtil.getLangCd());
		List<ElabTroubleHisVO> tcodeList = labNoteCommonMapper.selectScmTcodeList(reqVO);

		responseVO.setOk(ScmTCodeResDTO.builder()
				.mstList(mstList)
				.glbList(glbList)
				.tcodeList(tcodeList)
				.build());
		return responseVO;
	}

	public ResponseVO selectZplmt12List(Zplmt12ReqVO reqVO) {
		ResponseVO responseVO = new ResponseVO();

		String searchType = reqVO.getVSearchType();
		List<Zplmt12GlbDescVO> list = null;
		Zplmt12MstVO vo = null;

		if("UN".equals(reqVO.getVLand1()) && ("BAN".equals(searchType) || "LIMIT".equals(searchType))) {
			list = labNoteCommonMapper.selectZplmt12GlbDesc(reqVO);
		}
		else {
			vo = labNoteCommonMapper.selectZplmt12MstInfo(reqVO);
		}

		responseVO.setOk(Zplmt12ResDTO.builder()
				.list(list)
				.vo(vo)
				.build());
		return responseVO;
	}

	public ResponseVO selectLabNoteMaxMixMrqList(MaxMixVO reqVO) {
		ResponseVO responseVO = new ResponseVO();

		List<MaxMixResDTO> list = labNoteCommonMapper.selectLabNoteMaxMixMrqList(reqVO);

		responseVO.setOk(Optional.ofNullable(list)
				.orElseGet(() -> List.of()));
		return responseVO;
	}

	@Transactional
	public int insertELabHisLotChg(ElabHisLotChgVO elabHisLotChgVO) {
		return labNoteCommonMapper.insertELabHisLotChg(elabHisLotChgVO);
	}

	@Transactional
	public int deleteElabNoteLatestBomInfo(LabNoteLatestBomInfoVO labNoteLatestBomInfoVO) {
		return labNoteCommonMapper.deleteElabNoteLatestBomInfo(labNoteLatestBomInfoVO);
	}

	@Transactional
	public int insertElabNoteLatestBomInfo(LabNoteLatestBomInfoVO labNoteLatestBomInfoVO) {
		return labNoteCommonMapper.insertElabNoteLatestBomInfo(labNoteLatestBomInfoVO);
	}

	@Transactional
	public int updateLabNoteSendContToCpc(ProcCpcVO procCpcVO) {
		return labNoteCommonMapper.updateLabNoteSendContToCpc(procCpcVO);
	}

	@Transactional
	public int updateLabNoteSendBomToCpc(ProcCpcVO procCpcVO) {
		return labNoteCommonMapper.updateLabNoteSendBomToCpc(procCpcVO);
	}

	@Transactional
	public int insertLabNotePrecedeBomHeader(ElabPrecedeBomHeaderVO elabPrecedeBomHeaderVO) {
		return labNoteCommonMapper.insertLabNotePrecedeBomHeader(elabPrecedeBomHeaderVO);
	}

	@Transactional
	public int insertElabBomLotVer(ElabBomLotVerVO elabBomLotVerVO) {
		return labNoteCommonMapper.insertElabBomLotVer(elabBomLotVerVO);
	}

	@Transactional
	public int updateElabBomLotVerType(ElabBomLotVerVO elabBomLotVerVO) {
		return labNoteCommonMapper.updateElabBomLotVerType(elabBomLotVerVO);
	}

	public List<ShelfLifeVO> selectOneShelfLifeContInfo(ShelfLifeVO shelfLifeVO) {
		return labNoteCommonMapper.selectOneShelfLifeContInfo(shelfLifeVO);
	}

	@Transactional
	public int insertShelfLifeCont(ElabShelflifeContVO elabShelflifeContVO) {
		return labNoteCommonMapper.insertShelfLifeCont(elabShelflifeContVO);
	}

	public ResponseVO selectOneShelfLifeContList(ShelfLifeReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		List<ShelfLifeVO> shelfLifeList = new ArrayList<>();

		String language = sessionUtil.getLangCd();

		reqDTO.getContCdList().forEach(o -> {
			List<ShelfLifeVO> list = this.selectOneShelfLifeContInfo(ShelfLifeVO.builder()
					.vContCd(o)
					.language(language)
					.build());

			ShelfLifeVO shelfLifeVO = new ShelfLifeVO();
			shelfLifeVO.setVContCd(o);
			shelfLifeVO.setVPlantCd(reqDTO.getVPlantCd());

			if(list.isEmpty()) {
				shelfLifeVO.setVFlagLife("N");
			}
			else {
				for(ShelfLifeVO subVO : list) {
					shelfLifeVO.setVShelfLife(subVO.getVShelfLife());
					shelfLifeVO.setVFlagLife("Y");
				}
			}

			shelfLifeList.add(shelfLifeVO);
		});

		responseVO.setOk(ShelfLifeResDTO.builder()
				.list(shelfLifeList)
				.vFlagMsg(shelfLifeList.stream()
						.filter(o -> "N".equals(o.getVFlagLife()))
						.count() > 0 ? "Y" : "N")
				.build());
		return responseVO;
	}
//	원료배합 end

	@Transactional
	public void updateShelfLifeStatus(String contCd, String statusCd) {
		labNoteCommonMapper.updateShelfLifeStatus(ShelfLifeVO.builder()
															.vContCd(contCd)
															.vStatusCd(statusCd)
															.build());

		this.setElabShelfLifeSendSap(contCd); // SAP
	}

	public ShelfLifeVO selectElabShelfLifeInfoVerSap(String contCd) {
		return labNoteCommonMapper.selectElabShelfLifeInfoVerSap(contCd);
	}

	@Transactional
	public void setElabShelfLifeSendSap(String contCd) {
		ShelfLifeVO tempVo = this.selectElabShelfLifeInfoVerSap(contCd);

		if (!ObjectUtils.isEmpty(tempVo)) {
			String vContCd = tempVo.getVContCd();
			String vShelfLife = tempVo.getVShelfLife();
			String vUpdateUserid = tempVo.getVUpdateUserid();

			//내용물, shelfLife, 유저정보가 있어야지 전송
			if (StringUtils.isNotEmpty(vContCd) && StringUtils.isNotEmpty(vShelfLife) && StringUtils.isNotEmpty(vUpdateUserid)) {
				String sapShelfLife = labNoteSAPInterfaceService.getZmdMhdhbInfo(vContCd, vUpdateUserid);

				//SAP 저장되어 있는 값과 비교하여 동일하지 않은 경우에만 SAP에 전송
				if(!vShelfLife.equals(sapShelfLife)) {
					labNoteSAPInterfaceService.send_MDI00005_mat_flag_Y(vContCd, vShelfLife, vUpdateUserid);
				}
			}
		}
	}

	public String selectStringElabBomLotVer(String vLotCd, String vApprCd) {
		return labNoteCommonMapper.selectStringElabBomLotVer(vLotCd, vApprCd);
	}

	@Transactional
	public void deleteShelfLifeStatus(String vContCd) {
		labNoteCommonMapper.deleteShelfLifeInfoSubBContCd(vContCd);
		labNoteCommonMapper.deleteShelfLifeInfoCont(vContCd);
	}


	public PgcGqteResVO selectPqcGqteResInfo(String vApprCd) {
		return labNoteCommonMapper.selectPqcGqteResInfo(vApprCd);
	}

	public FuncDecideNameVO selectLabNoteFuncDecideNameInfoVerAppr(String vApprCd) {
		return labNoteCommonMapper.selectLabNoteFuncDecideNameInfoVerAppr(vApprCd);
	}

	@Transactional
	public void updateLabNoteFuncDecideName(FuncDecideNameVO funcDecideNameVO) {
		//MST 수정
		labNoteCommonMapper.updateLabNoteFuncDecideName(funcDecideNameVO);

		// 실험노트 제품명 확정 처리(SkincareApprovalService - updateFuncDecideName - 473 line)
		// 에서는 사용하지 않는 로직이므로 주석처리 함.
		// 추후에 사용된다면 구현 필요.
		//확장명 수정
//		String[] arrContPkCd = reqVo.getStringArray("i_arrContPkCd");
//		String[] arrDecideContNm = reqVo.getStringArray("i_arrDecideContNm");
//		String[] arrFlagNmDel = reqVo.getStringArray("i_arrFlagNmDel");
//
//		int len = arrContPkCd == null ? 0 : arrContPkCd.length;
//
//		if(len > 0 ) {
//			CmMap tempVo = new CmMap();
//
//			tempVo.put("i_sLabNoteCd", reqVo.getString("i_sLabNoteCd"));
//			tempVo.put("i_iFdnVer", reqVo.getString("i_iFdnVer"));
//			tempVo.put("i_sNoteType", reqVo.getString("i_sNoteType"));
//			tempVo.put("i_sRegUserId", reqVo.getString("i_sRegUserId"));
//			tempVo.put("i_sUpdateUserId", reqVo.getString("i_sUpdateUserId"));
//
//			for(int i =0 ; i<len; i++) {
//				tempVo.put("i_sContPkCd", arrContPkCd[i]);
//				tempVo.put("i_sDecideContNm", arrDecideContNm[i]);
//
//				if("N".equals(arrFlagNmDel[i])) {
//					this.cmDao.update("LabNoteCommon.updateLabNoteFuncDecideContName", tempVo);
//				}else {
//					this.cmDao.update("LabNoteCommon.deleteLabNoteFuncDecideContName", tempVo);
//				}
//			}
//		}
	}

	public String checkLabNoteAdmin (String noteType, String flagAuthCheckNonprd) {
		List<String> groupidList = sessionUtil.getGroups();
		String deptCd = sessionUtil.getSigmaDeptcd();

		if (sessionUtil.isSysadmin()) {
			return "Y";
		} else if (groupidList.contains("S000118") || groupidList.contains("S000246")) {
			if ("SC".equals(noteType) && "12912;20147;70451;50080409;76911;50071235;".indexOf(deptCd) > -1) {
				if ("Y".equals(flagAuthCheckNonprd)) {
					return "N";
				} else {
					return "Y";
				}
			} else if ("MU".equals(noteType) && "75181;20154;70452;72626;".indexOf(deptCd) > -1) {
				return "Y";
			} else if ("HBO".equals(noteType) && "76341;77215;77216;77217;".indexOf(deptCd) > -1) {
				return "Y";
			} else if ("SA".equals(noteType) && "76341;77215;77216;77217;".indexOf(deptCd) > -1) {
				return "Y";
			} else {
				return "F";
			}
		} else {
			return "F";
		}
	}

	public String checkLabNoteAuth (String noteType, String statusCd, String noteDeptCd) {
		String deptCd = sessionUtil.getSigmaDeptcd();
		if (sessionUtil.isSysadmin()) {
			return "Y";
		} else {
			if ("SC".equals(noteType)) {
				if ("12912;20147;70451;50080409;76911;50071235;".indexOf(deptCd) > -1 && "LNC06_50".equals(statusCd)) {
					return "Y";
				} else if (!"LNC06_50".equals(statusCd) && noteDeptCd.equals(deptCd)){
					return "Y";
				}
			} else if ("MU".equals(noteType)) {
				if ("75181;20154;70452;72626;".indexOf(deptCd) > -1 && "LNC06_50".equals(statusCd)) {
					return "Y";
				} else if (!"LNC06_50".equals(statusCd) && noteDeptCd.equals(deptCd)){
					return "Y";
				}
			} else if ("HBO".equals(noteType) || "SA".equals(noteType)) {
				if ("76341;77215;77216;77217;".indexOf(deptCd) > -1 && "LNC06_50".equals(statusCd)) {
					return "Y";
				} else if (!"LNC06_50".equals(statusCd) && noteDeptCd.equals(deptCd)){
					return "Y";
				}
			}
		}

		return "F";
	}

	public ElabShelflifeMstVO selectDOCShelflifeMSTView(ElabShelflifeMstVO elabShelflifeMstVO) {
		return labNoteCommonMapper.selectDOCShelflifeMSTView(elabShelflifeMstVO);
	}

	@Transactional
	public int updateShelfListMstStatus(String vStatusCd, String vRecordId) {
		return labNoteCommonMapper.updateShelfListMstStatus(vStatusCd, vRecordId);
	}

	public List<ElabShelflifeSubVO> selectBeforeShelfLife(String vRecordId) {
		return labNoteCommonMapper.selectBeforeShelfLife(vRecordId);
	}

	@Transactional
	public int updateShelfListContStatus(ElabShelflifeContVO elabShelflifeContVO) {
		return labNoteCommonMapper.updateShelfListContStatus(elabShelflifeContVO);
	}

	@Transactional
	public int insertChangeInfo(ElabShelflifeHisVO elabShelflifeHisVO) {
		return labNoteCommonMapper.insertChangeInfo(elabShelflifeHisVO);
	}

	//TDD 처리 완료 된 사용기한 수정시 결재 완료가 진행 되면 해당 내용물의 TDD 사용기한을 모두 변경 (차이나 TDD, TDD2.0, TDD3.0)
	//TDD완료 변경(SLS040)
	@Transactional
	public void updateTddShelfLifeVerSLS040(String contCd) {
		//TDD 리스트 정보
		List<ElabShelflifeTddInfoVO> list = labNoteCommonMapper.selectElabShelfLifeTddInfoList(ElabShelflifeTddInfoVO.builder()
																													 .vContCd(contCd)
																													 .build());

		//사용기한 게시판 관리 정보
		ShelfLifeVO slVo = this.selectElabShelfLifeInfoVerSap(contCd);

		int iShelfLife = Integer.parseInt(slVo.getVShelfLife());

		if (!ObjectUtils.isEmpty(list) && iShelfLife != 0) {
			String userid = slVo.getVUpdateUserid();

			int iSapShelfLife = 0;
			int iContCount = 0;

			boolean bUpdate = false;

			for (ElabShelflifeTddInfoVO listVo : list) {
				iContCount = Integer.parseInt(listVo.getVContCount());

				if(iContCount > 1) {
					//제품코드에 연결된 내용물이 여러개 일 경우 ShelfLife값이 최소값일 경우만 업로드 진행
					String sapResult = "";
					List <ElabShelflifeTddContVO> contList = labNoteCommonMapper.selectElabShelfLifeTddContList(ElabShelflifeTddContVO.builder()
																																	  .vRecordid(listVo.getVRecordid())
																																	  .vProductCd(listVo.getVProductCd())
																																	  .vContCd(contCd)
																																	  .vFlagNotCont("Y")
																																	  .build());

					if (!ObjectUtils.isEmpty(contList)) {
						for(int i = 0; i< contList.size(); i++) {
							sapResult = labNoteSAPInterfaceService.getZmdMhdhbInfo(contList.get(i).getVContCd(), userid);
							iSapShelfLife = Integer.parseInt(sapResult);

							if(iSapShelfLife == 0) {
								bUpdate = true;
							}else {
								if(iShelfLife < iSapShelfLife){
									bUpdate = true;
								}else {
									bUpdate = false;
								}
							}
						}
					}
				}else {
					//제품코드의 연결된 내용물이 한개일 경우 업로드 진행
					bUpdate = true;
				}

				if(bUpdate){
					String vRecordid = listVo.getVRecordid();
					String vFlagTdd = listVo.getVFlagTdd();

					String vShelfLife = slVo.getVShelfLife();

					if (StringUtils.isNotEmpty(vFlagTdd)) {
						//TDD 사용기한 변경
						if ("TDD3".equals(vFlagTdd)) {
							labNoteCommonMapper.updateTdd3ShelfLife(vShelfLife, vRecordid);
						} else if ("TDD2".equals(vFlagTdd)) {
							labNoteCommonMapper.updateTdd2ShelfLife(vShelfLife, vRecordid);
						} else if ("TDDCN".equals(vFlagTdd)) {
							labNoteCommonMapper.updateTddCnShelfLife(vShelfLife, vRecordid);
						}
					}

					//허가지원 사용기한 변경
					String vProductCd = listVo.getVProductCd();
					List<SupGlobalMailUserVO> supList = labNoteCommonMapper.selectElabShelfLifeGlobalSupList(vProductCd);

					int num = 0;

					if(!ObjectUtils.isEmpty(supList)) {
						for (SupGlobalMailUserVO supVo : supList){
							SupGlobalMailUserVO tempVo = SupGlobalMailUserVO.builder()
																			.vShelfLife(vShelfLife)
																			.vGlobalCd(supVo.getVGlobalCd())
																			.vProductCd(vProductCd)
																			.build();

							if ("CN".equals(supVo.getVCountryFlag())) {
								num = labNoteCommonMapper.updateGlobalSupShelfLifeCn(tempVo);
							} else {
								num = labNoteCommonMapper.updateGlobalSupShelfLife(tempVo);
							}

							//허가지원 담당자에게 사용기한 변경되었다고 메일 전송
							if (num > 0) {
								List<SupGlobalMailUserVO> userList = labNoteCommonMapper.selectElabShelfLifeGlobalSupSendMailUserList(SupGlobalMailUserVO.builder()
																																						 .vGlobalCd(supVo.getVGlobalCd())
																																						 .vProductCd(vProductCd)
																																						 .vCountryFlag(supVo.getVCountryFlag())
																																						 .build());

								//메일 전송부분 구현
								if (!ObjectUtils.isEmpty(userList)) {
									HashMap<String, String> params = new HashMap<>();

									params.put("apprContCdList", contCd);
									params.put("apprBeforeLifeList", supVo.getVShelfLife());
									params.put("apprAfterLifeList", Integer.toString(iShelfLife));
									params.put("productNm", supVo.getVProductNmEn());
									params.put("contCd", contCd);

									commonService.sendMailShelfLifeTDD(userList.stream().map(SupGlobalMailUserVO::getVEmail).collect(Collectors.toList()), params);
								}
							}
						}
					}

					bUpdate = false;
				}
			}
		}
	}

	//확정된 사용기한 변경시  TDD완료로 되지 않은 내용물만 포함된 TDD가 존재하면 변경 진행 (차이나 TDD, TDD2.0, TDD3.0)
	//확정 변경(SLS020)
	@Transactional
	public void updateTddShelfLifeVerSLS020(String contCd) {
		//TDD 리스트 정보
		List<ElabShelflifeTddInfoVO> list = labNoteCommonMapper.selectElabShelfLifeTddInfoList(ElabShelflifeTddInfoVO.builder()
																											 		 .vContCd(contCd)
																											 		 .vFlagSaveStatus("SLS020")
																											 		 .build());

		//사용기한 게시판 관리 정보
		ShelfLifeVO slVo = this.selectElabShelfLifeInfoVerSap(contCd);

		int iShelfLife = Integer.parseInt(slVo.getVShelfLife());

		if (!ObjectUtils.isEmpty(list) && iShelfLife != 0) {
			String userid = slVo.getVUpdateUserid();

			int iSapShelfLife = 0;
			int iContCount = 0;

			boolean bUpdate = false;

			for (ElabShelflifeTddInfoVO listVo : list) {
				iContCount = Integer.parseInt(listVo.getVContCount());

				if(iContCount > 1) {
					//제품코드에 연결된 내용물이 여러개 일 경우 ShelfLife값이 최소값일 경우만 업로드 진행
					String sapResult = "";
					List <ElabShelflifeTddContVO> contList = labNoteCommonMapper.selectElabShelfLifeTddContList(ElabShelflifeTddContVO.builder()
																																	  .vRecordid(listVo.getVRecordid())
																																	  .vProductCd(listVo.getVProductCd())
																																	  .vContCd(contCd)
																																	  .vFlagNotCont("Y")
																																	  .build());

					if (!ObjectUtils.isEmpty(contList)) {
						for(int i = 0; i< contList.size(); i++) {
							sapResult = labNoteSAPInterfaceService.getZmdMhdhbInfo(contList.get(i).getVContCd(), userid);
							iSapShelfLife = Integer.parseInt(sapResult);

							if(iSapShelfLife == 0) {
								bUpdate = true;
							}else {
								if(iShelfLife < iSapShelfLife){
									bUpdate = true;
								}else {
									bUpdate = false;
								}
							}
						}
					}
				}else {
					//제품코드의 연결된 내용물이 한개일 경우 업로드 진행
					bUpdate = true;
				}

				if(bUpdate){
					String vRecordid = listVo.getVRecordid();
					String vFlagTdd = listVo.getVFlagTdd();

					String vShelfLife = slVo.getVShelfLife();

					if (StringUtils.isNotEmpty(vFlagTdd)) {
						//TDD 사용기한 변경
						if ("TDD3".equals(vFlagTdd)) {
							labNoteCommonMapper.updateTdd3ShelfLife(vShelfLife, vRecordid);
						} else if ("TDD2".equals(vFlagTdd)) {
							labNoteCommonMapper.updateTdd2ShelfLife(vShelfLife, vRecordid);
						} else if ("TDDCN".equals(vFlagTdd)) {
							labNoteCommonMapper.updateTddCnShelfLife(vShelfLife, vRecordid);
						}
					}

					bUpdate = false;
				}
			}
		}
	}

	@Transactional
	public void updateShelfLife(ShelfLifeVO shelfLifeVO) {
		//MST테이블 상태값변경
		labNoteCommonMapper.updateBackShelfLifeMST(shelfLifeVO);

		//CONT테이블 상태값 변경
		List<String> StrMatrCd = new ArrayList<>();
		List<ElabShelflifeSubVO> list = labNoteCommonMapper.selectDOCShelflifeCONTView(shelfLifeVO.getVRecordid(), sessionUtil.getLocalLanguage());

		if (!ObjectUtils.isEmpty(list)) {
			for (ElabShelflifeSubVO rvo : list) {
				shelfLifeVO.setVContCd(rvo.getVContCd());
				StrMatrCd.add(rvo.getVContCd());
				labNoteCommonMapper.updateBackShelfLifeCONT(shelfLifeVO);
			}
			shelfLifeVO.setVApprMatrCd(StrMatrCd.stream().collect(Collectors.joining(",")));
		}
	}

	public List<LabNoteCommonRequestMateDTO> sapInterfaceMateList (String plantCd, String contentCd) {
		if (StringUtils.isEmpty(plantCd) || StringUtils.isEmpty(contentCd)) {
			return null;
		}

		List<BomInfoVO> inciList = labNoteSAPInterfaceService.getT_ZPLMS013(plantCd, contentCd, "UN");

		List<LabNoteCommonRequestMateDTO> rawList = null;
		if (!ObjectUtils.isEmpty(inciList)) {
			LabNoteCommonRequestMateDTO tempVo = null;

			rawList = new ArrayList<>();
			String hal4Cd = "";
			String hal4Per = "";
			String rawCd = "";
			String rawPer = "";
			int cnt = 0;

			for (BomInfoVO inciVo : inciList) {
				tempVo = new LabNoteCommonRequestMateDTO();

				if(StringUtils.isNotEmpty(inciVo.getHal4Cd())) {
					if(hal4Cd.equals(inciVo.getHal4Cd()) && hal4Per.equals(inciVo.getHal4Per())) {
						continue;
					}

					cnt ++;
					hal4Cd = inciVo.getHal4Cd();
					hal4Per = inciVo.getHal4Per();

					tempVo.setNSort(cnt);
					tempVo.setVMateCd(hal4Cd);
					tempVo.setVMateNm(inciVo.getHal4Nm());
					double t1 = Double.parseDouble(hal4Per);
					tempVo.setNCounterRate(t1);
				} else {
					if(rawCd.equals(inciVo.getRawCd()) && rawPer.equals(inciVo.getRawPer())) {
						continue;
					}

					cnt ++;
					rawCd = inciVo.getRawCd();
					rawPer = inciVo.getRawPer();

					tempVo.setNSort(cnt);
					tempVo.setVMateCd(rawCd);
					tempVo.setVMateNm(inciVo.getRawNm());
					double t1 = Double.parseDouble(rawPer);
					tempVo.setNCounterRate(t1);
				}

				rawList.add(tempVo);
			}
		}

		return rawList;
	}

	public String getElabContLogText(Map<String, Object> info, String str) {
		if (info == null || StringUtils.isEmpty(str)) {
			return "";
		}

		Pattern p = Pattern.compile("\\$\\{(.*?)\\}");
		Matcher m = p.matcher(str);

		String grp, key, val;

		while (m.find()) {
			for (int i = 0; i < m.groupCount(); i++) {
				grp = m.group(i);
				key = grp.substring(2, grp.length()-1);
				val = info.get(key) == null ? "" : String.valueOf(info.get(key));
				if ((key.lastIndexOf("Dt") > -1 && key.substring(key.lastIndexOf("Dt")).equals("Dt"))
						|| (key.lastIndexOf("Dtm") > -1 && key.substring(key.lastIndexOf("Dtm")).equals("Dtm"))
					) {
					if (val.length() == 6) {
						val = CommonUtil.getStrDateToString(val, "yyyy.MM");
					}
					else if (val.length() == 8) {
						val = CommonUtil.getStrDateToString(val, "yyyy.MM.dd");
					}
					else if (val.length() == 14) {
						val = CommonUtil.getStrDateToString(val, "yyyy.MM.dd HH:mm:ss");
					}
				}
				str = str.replaceAll("\\$\\{(" + key + ")\\}", val);
			}
		}

		return str;
	}

	public String getElabFieldLogText (Map<String, Object> info, String[] arrChg) {
		String str = arrChg.length > 2 ? arrChg[2] : "";

		if ("".equals(str)) {
			String key = info.get(arrChg[1]) == null ? "" : String.valueOf(info.get(arrChg[1]));
			String val = info.get(arrChg[0]) == null ? "" : String.valueOf(info.get(arrChg[0]));
			if ((key.lastIndexOf("Dt") > -1 && key.substring(key.lastIndexOf("Dt")).equals("Dt"))
					|| (key.lastIndexOf("Dtm") > -1 && key.substring(key.lastIndexOf("Dtm")).equals("Dtm"))
				) {

				if (val.length() == 6) {
					return CommonUtil.getStrDateToString(val, "yyyy.MM");
				}
				else if (val.length() == 8) {
					return CommonUtil.getStrDateToString(val, "yyyy.MM.dd");
				}
				else if (val.length() == 14) {
					return CommonUtil.getStrDateToString(val, "yyyy.MM.dd HH:mm:ss");
				}
			}

			return val;
		}

		Pattern p = Pattern.compile("\\$\\{(.*?)\\}");
		Matcher m = p.matcher(str);

		String grp, key, val;

		while (m.find()) {
			for (int i = 0; i < m.groupCount(); i++) {
				grp = m.group(i);
				key = grp.substring(2, grp.length()-1);
				val = info.get(key) == null ? "" : String.valueOf(info.get(key));
				if ((key.lastIndexOf("Dt") > -1 && key.substring(key.lastIndexOf("Dt")).equals("Dt"))
						|| (key.lastIndexOf("Dtm") > -1 && key.substring(key.lastIndexOf("Dtm")).equals("Dtm"))
					) {
					if (val.length() == 6) {
						val = CommonUtil.getStrDateToString(val, "yyyy.MM");
					}
					else if (val.length() == 8) {
						val = CommonUtil.getStrDateToString(val, "yyyy.MM.dd");
					}
					else if (val.length() == 14) {
						val = CommonUtil.getStrDateToString(val, "yyyy.MM.dd HH:mm:ss");
					}
				}
				str = str.replaceAll("\\$\\{(" + key + ")\\}", val);
			}
		}

		return str;
	}

	public String getElabTagLogText (Map<String, Object> info, List<LabNoteCommonTagDTO> tagList, String[] arrChg) {
		String str = arrChg.length > 2 ? arrChg[2] : "";

		if (StringUtils.isEmpty(str)) {
			String tag1Cd = arrChg[1];
			String[] arrTag1Cd;

			if (tag1Cd.indexOf("|") > -1) {
				arrTag1Cd = tag1Cd.split("\\|");
			} else {
				arrTag1Cd = new String[] {tag1Cd};
			}

			StringBuilder sb = new StringBuilder();

			for (int i = 0; i <arrTag1Cd.length; i++) {
				if (i > 0) {
					sb.append("\n");
				}

				sb.append("#{").append(arrTag1Cd[i]).append("}");
			}

			str = sb.toString();
		}

		Pattern p = Pattern.compile("\\$\\{(.*?)\\}");
		Matcher m = p.matcher(str);

		String grp, key, val;

		while (m.find()) {
			for (int i = 0; i < m.groupCount(); i++) {
				grp = m.group(i);
				key = grp.substring(2, grp.length()-1);
				val = info.get(key) == null ? "" : String.valueOf(info.get(key));
				if ((key.lastIndexOf("Dt") > -1 && key.substring(key.lastIndexOf("Dt")).equals("Dt"))
						|| (key.lastIndexOf("Dtm") > -1 && key.substring(key.lastIndexOf("Dtm")).equals("Dtm"))
					) {
					if (val.length() == 6) {
						val = CommonUtil.getStrDateToString(val, "yyyy.MM");
					}
					else if (val.length() == 8) {
						val = CommonUtil.getStrDateToString(val, "yyyy.MM.dd");
					}
					else if (val.length() == 14) {
						val = CommonUtil.getStrDateToString(val, "yyyy.MM.dd HH:mm:ss");
					}
				}
				str = str.replaceAll("\\$\\{(" + key + ")\\}", val);
			}
		}

		p = Pattern.compile("\\#\\{(.*?)\\}");
		m = p.matcher(str);

		Map<String, LabNoteCommonTagDTO> tagMap = tagList == null
												? new HashMap<>()
												: tagList.stream().collect(Collectors.toMap(LabNoteCommonTagDTO::getVTag1Cd, entity -> entity));

		while (m.find()) {
			for (int i = 0; i < m.groupCount(); i++) {

				grp = m.group(i);
				key = grp.substring(2, grp.length()-1);
				val = tagMap.get(key) == null ? "" : tagMap.get(key).getVSubCodenm();

				str = str.replaceAll("\\#\\{(" + key + ")\\}", val);
			}
		}

		return str;
	}

	public List<ElabSafeTestDTO> selectLabNoteSafeTestInfoList(String vLabNoteCd, String vSapCd) {
		return labNoteCommonMapper.selectLabNoteSafeTestInfoList(vLabNoteCd, vSapCd);
	}

	public void updateLabNoteSafeTestProductNm(ElabSafeTestDTO safeDTO) {
		labNoteCommonMapper.updateLabNoteSafeTestProductNm(safeDTO);
	}

	public void updateLabNoteSafeTestProductVerNm(ElabSafeTestDTO safeDTO) {
		labNoteCommonMapper.updateLabNoteSafeTestProductVerNm(safeDTO);
	}

	public void insertLabNoteSafeTestHist(ElabSafeTestDTO saveDTO) {
		labNoteCommonMapper.insertLabNoteSafeTestHist(saveDTO);
	}

	public boolean isElabNoteFieldChange(Map<String, Object> beforeMap, Map<String, Object> afterMap, String[] arrChg) {
		String chgFieldKey = arrChg[0];
		String addChgFieldkey = arrChg.length > 3 ? arrChg[3] : "";

		if (beforeMap == null || afterMap == null || StringUtils.isEmpty(chgFieldKey)) {
			return false;
		}

		if (!String.valueOf(afterMap.get(chgFieldKey)).equals(String.valueOf(beforeMap.get(chgFieldKey)))) {
			return true;
		}

		if (StringUtils.isNotEmpty(addChgFieldkey)) {
			if (addChgFieldkey.indexOf("|") > -1) {
				String[] arrKey = addChgFieldkey.split("\\|");
				int len = arrKey.length;

				for (int i = 0; i < len; i++) {
					if (!String.valueOf(afterMap.get(arrKey[i])).equals(String.valueOf(beforeMap.get(arrKey[i])))) {
						return true;
					}
				}
			} else {
				if (!String.valueOf(afterMap.get(addChgFieldkey)).equals(String.valueOf(beforeMap.get(addChgFieldkey)))) {
					return true;
				}
			}
		}

		return false;
	}

	public boolean isElabNoteTagChange(Map<String, Object> beforeMap, Map<String, Object> afterMap,
			List<LabNoteCommonTagDTO> beforeMstTagList, List<LabNoteCommonTagDTO> afterMstTagList, String[] arrChg) {
		String[] arrKey;
		String addChgFieldKey = arrChg.length > 3 ? arrChg[3] : "";

		if (StringUtils.isNotEmpty(addChgFieldKey)) {
			if (addChgFieldKey.indexOf("|") > -1) {
				arrKey = addChgFieldKey.split("\\|");
			} else {
				arrKey = new String[] {addChgFieldKey};
			}

			for (int i = 0; i < arrKey.length; i++) {
				if (!String.valueOf(afterMap.get(arrKey[i])).equals(String.valueOf(beforeMap.get(arrKey[i])))) {
					return true;
				}
			}
		}

		String[] arrTag1Cd;
		String tag1Cd = arrChg.length > 1 ? arrChg[1] : "";

		Map<String, LabNoteCommonTagDTO> beforeMstTagMap = beforeMstTagList == null
											? new HashMap<>()
											: beforeMstTagList.stream().collect(Collectors.toMap(LabNoteCommonTagDTO::getVTag1Cd, entity -> entity));

		Map<String, LabNoteCommonTagDTO> afterMstTagMap = afterMstTagList == null
											? new HashMap<>()
											: afterMstTagList.stream().collect(Collectors.toMap(LabNoteCommonTagDTO::getVTag1Cd, entity -> entity));
		if (StringUtils.isNotEmpty(tag1Cd)) {
			if (tag1Cd.indexOf("|") > -1) {
				arrTag1Cd = tag1Cd.split("\\|");
			} else {
				arrTag1Cd = new String[] {tag1Cd};
			}

			String beforeSubCodenm = "";
			String afterSubCodenm = "";

			for (int i = 0; i < arrTag1Cd.length; i++) {
				beforeSubCodenm = beforeMstTagMap.get(arrTag1Cd[i]) != null && StringUtils.isNotEmpty(beforeMstTagMap.get(arrTag1Cd[i]).getVSubCodenm()) ? beforeMstTagMap.get(arrTag1Cd[i]).getVSubCodenm() : "";
				afterSubCodenm = afterMstTagMap.get(arrTag1Cd[i]) != null && StringUtils.isNotEmpty(afterMstTagMap.get(arrTag1Cd[i]).getVSubCodenm()) ? afterMstTagMap.get(arrTag1Cd[i]).getVSubCodenm() : "";
				if (!beforeSubCodenm.equals(afterSubCodenm)) {
					return true;
				}
			}
		}

		return false;
	}

	@Transactional
	public ResponseVO saveNoteRecentLog(LabNoteCommonRecentDTO recentDTO) {
		ResponseVO responseVO = new ResponseVO();

		if (StringUtils.isEmpty(recentDTO.getVNoteType())
				|| StringUtils.isEmpty(recentDTO.getVLabNoteCd())
				) {
			responseVO.setOk(CommonResultCode.NO_ESSENTIAL_DATA, null);
			return responseVO;
		}

		recentDTO.setVUserid(sessionUtil.getLoginId());
		labNoteCommonMapper.deleteNoteRecentLogCont(recentDTO); // 동일 note 조회 기존 데이터 삭제
		labNoteCommonMapper.deleteNoteRecentLog(recentDTO); // 5개 이상일 때 가장 오래된 데이터 삭제
		labNoteCommonMapper.insertNoteRecentLog(recentDTO);

		responseVO.setCreateOk(this.selectNoteRecentLogList(recentDTO.getVNoteType()));

		return responseVO;
	}

	public List<LabNoteCommonRecentDTO> selectNoteRecentLogList(String vNoteType) {
		if (StringUtils.isEmpty(vNoteType)) {
			return null;
		}

		List<LabNoteCommonRecentDTO> list = null;
		LabNoteCommonRecentDTO reqVO = LabNoteCommonRecentDTO.builder()
				.vUserid(sessionUtil.getLoginId())
				.vNoteType(vNoteType)
				.build();

		if ("SC".equals(vNoteType)) {
			list = labNoteCommonMapper.selectSkincareNoteRecentLogList(reqVO);
		} else if ("MU".equals(vNoteType)) {
			list = labNoteCommonMapper.selectMakeupNoteRecentLogList(reqVO);
		} else if ("HBO".equals(vNoteType)) {
			list = labNoteCommonMapper.selectHbdNoteRecentLogList(reqVO);
		} else if ("SA".equals(vNoteType)) {
			list = labNoteCommonMapper.selectQdrugNoteRecentLogList(reqVO);
		}

		return list;
	}

	@Transactional
	public ResponseVO deleteNoteRecentLogCont(LabNoteCommonRecentDTO recentDTO) {
		ResponseVO responseVO = new ResponseVO();

		if (StringUtils.isEmpty(recentDTO.getVNoteType())
				|| StringUtils.isEmpty(recentDTO.getVLabNoteCd())
				) {
			responseVO.setOk(CommonResultCode.NO_ESSENTIAL_DATA, null);
			return responseVO;
		}

		recentDTO.setVUserid(sessionUtil.getLoginId());
		labNoteCommonMapper.deleteNoteRecentLogCont(recentDTO);

		responseVO.setCreateOk(this.selectNoteRecentLogList(recentDTO.getVNoteType()));
		return responseVO;
	}

	public ResponseVO selectLabCodeRequiredInfo(String vDeptCd) {
		ResponseVO responseVO = new ResponseVO();

		responseVO.setCreateOk(this.selectLabCodeRequired(vDeptCd));
		return responseVO;
	}

	public List<LabNoteCommonProjectDTO> selectLabCodeRequired(String vDeptCd) {
		return labNoteCommonMapper.selectLabCodeRequired(vDeptCd);
	}

	public List<ElabNoteMstSetVO> selectNoteMstSetList(String vLabNoteCd) {
		return labNoteCommonMapper.selectNoteMstSetList(vLabNoteCd);
	}

	public String checkPlantExpansionBookmark(List<BookmarkVO> bookmarkList, String contCd) {
		String resultContCd = "";

		if (StringUtils.isNotEmpty(contCd)) {
			for (BookmarkVO vo : bookmarkList) {
				if (contCd.equals(vo.getVContCd())) {
					resultContCd = vo.getVContCd();
					break;
				}
			}
		}

		return resultContCd;
	}

	public void insertSAPMaterialReqVerPlantExp(ZmdMaterialReqDTO zmdDTO) {
		labNoteCommonMapper.insertSAPMaterialReqVerPlantExp(zmdDTO);
	}

	public int selectShelfLifePlantCount(String vContCd) {
		return labNoteCommonMapper.selectShelfLifePlantCount(vContCd);
	}

	public void updateSubPlantFlag(String vContCd) {
		labNoteCommonMapper.updateSubPlantFlag(vContCd);
	}

	public void insertShelfLifeSubPlant(String vContCd, String vPlantCd) {
		labNoteCommonMapper.insertShelfLifeSubPlant(vContCd, vPlantCd, sessionUtil.getLoginId());
	}

	public void insertShelfListHis(String vContCd, String vChangeReason) {
		labNoteCommonMapper.insertShelfListHis(vContCd, vChangeReason, sessionUtil.getLoginId());
	}

	public List<ElabShelflifeContVO> selectShelfLifePlant(PlantChangeReqDTO plantChangeReqDTO) {
		return labNoteCommonMapper.selectShelfLifePlant(plantChangeReqDTO);
	}

	public String selectShelfOldPlantCd(String contCd) {
		return labNoteCommonMapper.selectShelfOldPlantCd(contCd);
	}

	public void updateShelfLifeContPlant(String plantCd, String contCd) {
		labNoteCommonMapper.updateShelfLifeContPlant(plantCd, contCd);
	}

	public void deleteShelfLifeSubPlant(String vContCd) {
		labNoteCommonMapper.deleteShelfLifeSubPlant(vContCd);
	}

	public ResponseVO selectLabNoteAuthorityList(ElabChgLogSearchReqDTO searchReqDTO) {
		ResponseVO responseVO = new ResponseVO();

		searchReqDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
		int totalCnt = labNoteCommonMapper.selectLabNoteAuthorityListCount(searchReqDTO);
		List<CommUserDesSearchInfoDTO> list = null;
		CommonUtil.setPaging(searchReqDTO, totalCnt);

		if (totalCnt > 0) {
			list = labNoteCommonMapper.selectLabNoteAuthorityList(searchReqDTO);
		}

		PagingDTO page = ConvertUtil.convert(searchReqDTO, PagingDTO.class);
		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
											.page(page)
											.list(list)
											.build();
		responseVO.setOk(res);
		return responseVO;
	}

	public ResponseVO deleteLabNoteAuthority(LabNoteAuthorityReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();
		int result = 0;

		if (reqDTO.getArrUserList() != null && !reqDTO.getArrUserList().isEmpty()) {
			reqDTO.setVRegUserid(sessionUtil.getLoginId());
			reqDTO.setVUpdateUserid(sessionUtil.getLoginId());
			result = labNoteCommonMapper.deleteLabNoteAuthority(reqDTO);
		}

		if (result > 0) {
			responseVO.setCreateOk(null);
		} else {
			responseVO.setOkWithCode("C9999", CommonResultCode.SAVE_FAIL, null);
		}

		return responseVO;
	}

	public ResponseVO insertLabNoteAuthority(LabNoteAuthorityReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();
		int result = 0;

		if (StringUtils.isNotEmpty(reqDTO.getVUserid())) {
			int authCount = labNoteCommonMapper.selectLabNoteAuthorityCount(reqDTO);

			if (authCount > 0) {
				responseVO.setCreateOk(null);
				return responseVO;
			}

			reqDTO.setVRegUserid(sessionUtil.getLoginId());
			reqDTO.setVUpdateUserid(sessionUtil.getLoginId());
			result = labNoteCommonMapper.insertLabNoteAuthority(reqDTO);
		}

		if (result > 0) {
			String pageUrl = new StringBuilder()
								.append("/")
								.append(reqDTO.getVNoteTypeNm())
								.append("/all-lab-note-")
								.append(reqDTO.getVPageType())
								.append("-view?vLabNoteCd=")
								.append(reqDTO.getVLabNoteCd())
								.toString();
			commonService.sendAlarm(AlarmRegDTO.builder()
										.vLabNoteCd(reqDTO.getVLabNoteCd())
										.vStatusCd("AL_NOTE0")
										.vAlrTypeCd("AL_NOTE0_12")
										.vTypeCd(Const.ALARM)
										.vContCd(reqDTO.getVContCd())
										.vContNm(reqDTO.getVContNm())
										.userList(Arrays.asList(reqDTO.getVUserid()))
										.vMoveUrl(pageUrl)
										.build());

			responseVO.setCreateOk(null);
		} else {
			responseVO.setOkWithCode("C9999", CommonResultCode.SAVE_FAIL, null);
		}

		return responseVO;
	}

	@Transactional
	public void updateLabNoteMstSet(List<ElabNoteMstSetVO> mstSetList) {
		if(ObjectUtils.isEmpty(mstSetList)) {
			return;
		}

		String userid = sessionUtil.getLoginId();
		mstSetList.forEach(o -> {
			o.setVRegUserid(userid);
			o.setVUpdateUserid(userid);
			labNoteCommonMapper.updateLabNoteMstSet(o);
		});
	}

	public void updateLabNoteFuncDecideNameAllLastN(LabNoteProcessFuncReqDTO reqDTO) {
		labNoteCommonMapper.updateLabNoteFuncDecideNameAllLastN(reqDTO);
	}

	public void insertLabNoteFuncDecideName(LabNoteProcessFuncReqDTO reqDTO) {
		labNoteCommonMapper.insertLabNoteFuncDecideName(reqDTO);
	}

	public void insertLabNoteFuncDecideContName(LabNoteProcessFuncDecideReqDTO decideCont) {
		labNoteCommonMapper.insertLabNoteFuncDecideContName(decideCont);
	}

	public void updateLabNoteFuncDecideContName(LabNoteProcessFuncDecideReqDTO decideCont) {
		labNoteCommonMapper.updateLabNoteFuncDecideContName(decideCont);
	}

	public void deleteLabNoteFuncDecideContName(LabNoteProcessFuncDecideReqDTO decideCont) {
		labNoteCommonMapper.deleteLabNoteFuncDecideContName(decideCont);
	}

	public void deleteLabNoteFuncDecideName(LabNoteProcessFuncReqDTO reqDTO) {
		labNoteCommonMapper.deleteLabNoteFuncDecideName(reqDTO);
	}

	public int selectLabNoteFuncDecideNameMaxVer(LabNoteProcessFuncReqDTO reqDTO) {
		return labNoteCommonMapper.selectLabNoteFuncDecideNameMaxVer(reqDTO);
	}

	public String selectLabNoteDecideContNm(String vLabNoteCd) {
		return labNoteCommonMapper.selectLabNoteDecideContNm(vLabNoteCd);
	}

	public int insertEpReport(@Valid LabNoteCommonWokReportReqDTO reqDTO) {
		return labNoteCommonMapper.insertEpReport(reqDTO);
	}

	public List<ElabContQmsVO> selectElabContQmsInfo(LabNoteProcessFuncReportResPopDTO funcReqVo) {
		return labNoteCommonMapper.selectElabContQmsInfo(funcReqVo);
	}

	public String selectEpReportSeq() {
		return labNoteCommonMapper.selectEpReportSeq();
	}

	public SupGlobalMailUserVO selectUserEmail(String vSenderId) {
		return labNoteCommonMapper.selectUserEmail(vSenderId);
	}

//	LabNoteCommonController - lab_note_shelf_life_code_reg - 5910 line 부터 참조
	public ResponseVO selectLabNoteShelfLifeInfo(LabNoteCommonReqShelflifeDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		String localLanguage = sessionUtil.getLocalLanguage();

		String recordId = reqDTO.getVRecordid();

		ElabShelflifeMstVO mstVo = null;
		List<?> list = null;
		List<ElabShelflifeSubVO> finalSubPlantList = new ArrayList<>();

		if (StringUtils.isNotEmpty(recordId)) {
			mstVo = this.selectDOCShelflifeMSTView(ElabShelflifeMstVO.builder()
																	 .localLanguage(localLanguage)
																	 .vApprCd(reqDTO.getVApprCd())
																	 .vRecordid(recordId)
																	 .build());

			list = labNoteCommonMapper.selectDOCShelflifeCONTView(recordId, localLanguage);
		} else {
			list = this.selectOneShelfLifeContInfo(ShelfLifeVO.builder()
															  .language(localLanguage)
															  .contCdList(reqDTO.getContCdList())
															  .vContCd(reqDTO.getVContCd())
															  .build());

			if (!ObjectUtils.isEmpty(list)) {
				Object obj = list.get(0);

				if (obj instanceof ShelfLifeVO) {

					ShelfLifeVO tempVo = (ShelfLifeVO) obj;

					mstVo = ElabShelflifeMstVO.builder()
											  .vStatusCdNm(tempVo.getVStatusCdNm())
											  .vNoteType(tempVo.getVNoteType())
											  .vDocKind(tempVo.getVDocKind())
											  .vDocKindNm(tempVo.getVDocKindNm())
											  .vShelfLife(tempVo.getVShelfLife())
											  .vUpdateUserid(tempVo.getVUpdateUserid())
											  .build();
				}

				//SUB PLANT 확인
				for (Object rvo : list) {
					if (rvo instanceof ShelfLifeVO) {
						ShelfLifeVO svo = (ShelfLifeVO) rvo;

						if ("Y".equals(svo.getVFlagSubPlant())) {
							List<ElabShelflifeSubVO> subPlantList = labNoteCommonMapper.selectSubPlantList(svo.getVContCd(), localLanguage);

							if (!ObjectUtils.isEmpty(subPlantList)) {
								finalSubPlantList.addAll(subPlantList);
							}
						}
					}
				}
			}
		}

		responseVO.setOk(LabNoteCommonResShelflifeDTO.builder()
													 .map(mstVo)
													 .list(list)
													 .finalSubPlantList(finalSubPlantList)
													 .build());

		return responseVO;
	}

	public List<ElabShelflifeSubVO> selectSubPlantList(String vContCd, String localLanguage) {
		return labNoteCommonMapper.selectSubPlantList(vContCd, localLanguage);
	}

//	LabNoteCommonController - lab_note_shelf_life_code_save - 6159 line 부터 참조
	@Transactional
	public ResponseVO updateLabNoteShelfLifeInfo(LabNoteCommonReqShelflifeDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		String vRecordid = reqDTO.getVRecordid();

		if (StringUtils.isNotEmpty(vRecordid)) {
			// 기본정보 및 내용물정보 삭제
			this.deleteShelfLifeInfo(vRecordid);
		}
		// 새로운 기본정보 및 내용물정보 입력
		this.insertShelfLifeInfo(reqDTO);

		if (!"SLK010".equals(reqDTO.getVDocKind()) && "SLS070".equals(reqDTO.getVSaveStatus())) {
			this.shelflifeAppr(reqDTO);
		}

		responseVO.setOk(Const.SUCC);
		return responseVO;
	}

	@Transactional
	public void deleteShelfLifeInfo(String vRecordId) {
		//기본정보 삭제
		labNoteCommonMapper.deleteShelfLifeInfo(vRecordId);
		//SUB테이블 삭제
		labNoteCommonMapper.deleteShelfLifeInfoSUB(vRecordId);
	}

	@Transactional
	public void insertShelfLifeInfo(LabNoteCommonReqShelflifeDTO reqDTO) {
		List<ShelfLifeVO> contInfoList = reqDTO.getContInfoList();

		String userId = sessionUtil.getLoginId();

		String vDocKind = reqDTO.getVDocKind();

		StringBuilder titleSb = new StringBuilder();
		titleSb.append(contInfoList.get(0).getVMaktx());

		if (contInfoList.size() > 1) {
			titleSb.append(" 외 ")
				   .append(contInfoList.size() - 1)
				   .append("건");
		}

		ElabShelflifeMstVO mstVo = ElabShelflifeMstVO.builder()
													 .vStatusCd(reqDTO.getVSaveStatus())
													 .vDocKind(vDocKind)
													 .vNoteType(reqDTO.getVNoteType())
													 .vFlagAll(!"SLK010".equals(vDocKind) ? StringUtils.defaultIfEmpty(reqDTO.getVChkAll(), "N") : "")
													 .vChangeReason(reqDTO.getVChangeReason())
													 .vApprCd(reqDTO.getVApprCd())
													 .vRegUserid(userId)
													 .vUpdateUserid(userId)
													 .vTitle(titleSb.toString())
													 .build();

		// 기본정보 입력
		labNoteCommonMapper.insertShelfLifeInfoMst(mstVo);

		// 내용물정보 입력 및 비어있는 정보 거르기
//		int num = 0;
		for (int i = 0; i < contInfoList.size(); i++) {
			ShelfLifeVO cvo = contInfoList.get(i);

			ElabShelflifeSubVO subVO = new ElabShelflifeSubVO();
			ElabShelflifeContVO contVO = new ElabShelflifeContVO();

			String vContCd = cvo.getVContCd();
			String vPlantCd = cvo.getVPlantCd();

			subVO.setVContCd(vContCd);
			contVO.setVContCd(vContCd);

//			if ("SLK010".equals(vDocKind)) { // 생성일떄만 플랜트 정보 입력
//				if (StringUtils.isEmpty(cvo.getVPlantCd())) {
//					String vPlantSelected = contInfoList.get(num).getVPlantSelected();
//
//					subVO.setVPlantCd(vPlantSelected);
//					contVO.setVPlantCd(vPlantSelected);
//
//					num++;
//				} else {
//					subVO.setVPlantCd(vPlantCd);
//					contVO.setVPlantCd(vPlantCd);
//				}
//			} else { // 확정변경 및 TDD완료 변경일 떄, 기존값 그대로 사용
//				subVO.setVPlantCd(vPlantCd);
//				contVO.setVPlantCd(vPlantCd);
//			}

			subVO.setVPlantCd(vPlantCd);
			contVO.setVPlantCd(vPlantCd);

			if(vContCd.startsWith("3")){
				subVO.setVContType("HAL3");
				contVO.setVContType("HAL3");
			}
			else{
				subVO.setVContType("HAL4");
				contVO.setVContType("HAL4");
			}

			if (!"SLK010".equals(vDocKind) && "TEMP".equals(reqDTO.getVContFlag())) {
				subVO.setVShelfLife(cvo.getVOriginShelfLife());
				contVO.setVShelfLife(cvo.getVOriginShelfLife());
			} else {
				subVO.setVShelfLife(cvo.getVShelfLife());
				contVO.setVShelfLife(cvo.getVShelfLife());

				if (!"SLK010".equals(vDocKind)) {
					subVO.setVChShelfLife(cvo.getVOriginShelfLife());
//					contVO.setVStatusCd("SLS030");
				}

				// CONT테이블 상태변경
				labNoteCommonMapper.updateShelfLifeInfoCont(vContCd);
			}

			if(!"ETC".equals(cvo.getVShelfLife())){
				subVO.setVShelfLifeTxt("");
//				contVO.setVShelfLife("");

			} else {
				subVO.setVShelfLifeTxt(cvo.getVEtcLife());
				contVO.setVShelfLife(cvo.getVEtcLife());
			}

			subVO.setVRecordid(mstVo.getVRecordid());
			subVO.setVNoteType(reqDTO.getVNoteType());
			subVO.setVRegUserid(userId);
			subVO.setVUpdateUserid(userId);

//			contVO.setVNoteType(reqDTO.getVNoteType());
//			contVO.setVUpdateUserid(userId);

			labNoteCommonMapper.insertShelfLifeInfoSUB(subVO);

			// CONT테이블 입력
			if ("SLK010".equals(vDocKind) && "SAVE".equals(reqDTO.getVContFlag())) {
				labNoteCommonMapper.deleteShelfLifeInfoCont(vContCd);
				labNoteCommonMapper.insertShelfLifeInfoCont(contVO);
				this.setElabShelfLifeSendSap(vContCd); // SAP
			};
		}

		reqDTO.setVRecordid(mstVo.getVRecordid());
		reqDTO.setVApprTitle(titleSb.toString());
		reqDTO.setVApprMatrCd(contInfoList.stream().filter(vo -> StringUtils.isNotEmpty(vo.getVMaktx()))
												   .map(ShelfLifeVO::getVContCd)
												   .collect(Collectors.joining(",")));
	}

	@Transactional
	public void insertShelfLifeInfoCont (ElabShelflifeContVO shelfVO) {
		shelfVO.setVRegUserid(sessionUtil.getLoginId());
		shelfVO.setVUpdateUserid(sessionUtil.getLoginId());
		labNoteCommonMapper.insertShelfLifeInfoCont(shelfVO);
	}

	@Transactional
	private void shelflifeAppr(LabNoteCommonReqShelflifeDTO reqDTO) {

		String recordid = reqDTO.getVRecordid();

		commonService.insertReference(ReqReferenceDTO.builder()
												     .vRecordid(recordid)
												     .referenceList(reqDTO.getReferenceList())
												     .build());

		String draftTitle = new StringBuilder().append("결재의뢰-")
											   .append(reqDTO.getVApprTitle())
											   .append("(")
											   .append(reqDTO.getVApprMatrCd())
											   .append(")")
											   .toString();

		String apprCd = commonService.handlingOfApprovalEp(
					"SAVE".equals(reqDTO.getVContFlag()) ? "APS030" : "APS999",
					draftTitle,
					reqDTO.getApprParams()
				);

		labNoteCommonMapper.insertShelfLifeApprCd(apprCd, recordid);

		if ("SAVE".equals(reqDTO.getVContFlag())) {
			commonService.sendMailApproval(ApprovalDTO.builder()
													  .vApprCd(apprCd)
													  .vResultStatus(ApprovalResultCode.APPR_SUCC.getCode())
													  .vTitle(draftTitle)
													  .build());
		}
	}

	public List<ElabContQmsVO> selectElabQmsLotInfo(ElabContQmsReqVO qmsReqDTO) {
		return labNoteCommonMapper.selectElabQmsLotInfo(qmsReqDTO);
	}

	public List<CommUserDesSearchInfoDTO> selectGroupUserRetireList(LabNoteProcessFuncReportUserReqDTO reqDTO) {
		return labNoteCommonMapper.selectGroupUserRetireList(reqDTO);
	}

	public void insertRequestQaCont(@Valid LabNoteProcessFuncReportReqSaveDTO reqDTO) {
		labNoteCommonMapper.insertRequestQaCont(reqDTO);
	}

	public void insertLabNoteFuncQaUser(@Valid LabNoteProcessFuncReportReqSaveDTO reqDTO) {
		labNoteCommonMapper.insertLabNoteFuncQaUser(reqDTO);
	}

	public List<String> selectLabNoteFuncQaUserList(@Valid LabNoteProcessFuncReportReqSaveDTO saveReqDTO) {
		return labNoteCommonMapper.selectLabNoteFuncQaUserList(saveReqDTO);
	}

	public int insertQmsReportIF(LabNoteProcessFuncReportDataDTO fvo) {
		return labNoteCommonMapper.insertQmsReportIF(fvo);
	}

	public void insertQmsRawInfoIF(LabNoteProcessFuncReportDataDTO fvo) {
		labNoteCommonMapper.insertQmsRawInfoIF(fvo);
	}

	public String selectApplyPqcCd(LabNotePqcGateCheckReqDTO checkDTO) {
		return labNoteCommonMapper.selectApplyPqcCd(checkDTO);
	}

	public List<LabNotePqcGateCheckListDTO> selectPqcGateCheckList(LabNotePqcGateCheckReqDTO checkDTO) {
		return labNoteCommonMapper.selectPqcGateCheckList(checkDTO);
	}

	public List<LabNotePqcResItemListDTO> selectElabPqcResItemList(LabNotePqcGateCheckReqDTO checkDTO) {
		return labNoteCommonMapper.selectElabPqcResItemList(checkDTO);
	}

	public int selectLabNoteIngrtCautionListCnt(String contCd) {
		return labNoteCommonMapper.selectLabNoteIngrtCautionListCnt(contCd);
	}

	public LabNotePqcResItemListDTO selectLabNoteG1gqmsInfo(String vPqcGate1ResCd) {
		return labNoteCommonMapper.selectLabNoteG1gqmsInfo(vPqcGate1ResCd);
	}

	public ResponseVO selectMatrMixreInfo(String vConCd) {
		ResponseVO responseVO = new ResponseVO();

		LabNoteMatrMixreInfoVO rvo = labNoteCommonMapper.selectMatrMixreInfo(vConCd);

		if (ObjectUtils.isEmpty(rvo)) {
			responseVO.setOkWithCode(Const.FAIL, "잘못된 접근입니다.", null);
			return responseVO;
		}

		responseVO.setOk(rvo);

		return responseVO;
	}

	public int insertSAPIngredientApproval(Zplmt14VO vo) {
		return labNoteCommonMapper.insertSAPIngredientApproval(vo);
	}

	public int insertSAPIngredientRate(Zplmt13VO vo) {
		return labNoteCommonMapper.insertSAPIngredientRate(vo);
	}

	public String checkFlagFreePass(PilotRequestDetailReqDTO pilotRequestDetailReqDTO) {
		return labNoteCommonMapper.checkFlagFreePass(pilotRequestDetailReqDTO);
	}

	public List<LabNotePqcGateCheckListDTO> selectPqcGateResItemList(String vPqcResCd) {
		return labNoteCommonMapper.selectPqcGateResItemList(vPqcResCd);
	}

	public List<PgcGqteResVO> selectElabPqcResLotList(String vPqcResCd){
		return labNoteCommonMapper.selectElabPqcResLotList(vPqcResCd);
	}

	@Transactional
	public void insertElabPqcRes(@Valid LabNoteProcessPqcCheckApprReqDTO reqDTO) {
		labNoteCommonMapper.insertElabPqcRes(reqDTO);
	}

	@Transactional
	public void updateElabPqcResItem(LabNotePqcGateCheckListDTO tvo) {
		labNoteCommonMapper.updateElabPqcResItem(tvo);
	}

	@Transactional
	public void insertElabPqcResItem(LabNotePqcGateCheckListDTO tvo) {
		labNoteCommonMapper.insertElabPqcResItem(tvo);
	}

	@Transactional
	public void deleteElabPqcResItem(LabNotePqcResItemListDTO itemDTO) {
		labNoteCommonMapper.deleteElabPqcResItem(itemDTO);
	}

	@Transactional
	public void updateElabPqcRes(@Valid LabNoteProcessPqcCheckApprReqDTO reqDTO) {
		labNoteCommonMapper.updateElabPqcRes(reqDTO);
	}

	@Transactional
	public void insertElabPqcResLot(@Valid LabNoteProcessPqcCheckApprReqDTO reqDTO) {
		labNoteCommonMapper.insertElabPqcResLot(reqDTO);
	}

	public String selectLabNoteExistsAerosolDecide(String vContPkCd) {
		return labNoteCommonMapper.selectLabNoteExistsAerosolDecide(vContPkCd);
	}

	public List<BomInfoVO> selectMat6CodeList(List<BomInfoVO> arrCodeList) {
		return labNoteCommonMapper.selectMat6CodeList(arrCodeList);
	}

	public List<BomInfoVO> selectMat4CodeList(List<BomInfoVO> arrCodeList) {
		return labNoteCommonMapper.selectMat4CodeList(arrCodeList);
	}

	public List<BomInfoVO> setSaIngrHal4Check(List<BomInfoVO> bomList) {
		if (!ObjectUtils.isEmpty(bomList)) {
			List<BomInfoVO> hal4List = labNoteCommonMapper.setSaIngrHal4Check(bomList);

			if (!ObjectUtils.isEmpty(hal4List)) {
				for (BomInfoVO vo : bomList) {
					String v_mat_cd = vo.getRawCd();

					for (BomInfoVO hal4Vo : hal4List) {
						String v_matnr =  hal4Vo.getRawCd();

						if(v_matnr.equals(v_mat_cd))
						{
							vo.setVMatNum("4");
							break;
						}
					}
				}
			}
		}

		return bomList;
	}

	public int selectVersionHistoryMstCount(LabNoteVersionModifyReqDTO labNoteVersionModifyReqDTO) {
		return labNoteCommonMapper.selectVersionHistoryMstCount(labNoteVersionModifyReqDTO);
	}

	public List<ProductVersionHistoryDTO> selectProductVersionHistoryMstList(String vLabNoteCd) {
		return labNoteCommonMapper.selectProductVersionHistoryMstList(vLabNoteCd, sessionUtil.getLocalLanguage());
	}

	public ResponseVO selectOneShelfLifeContInfo(@Valid ShelfLifeReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();

		reqDTO.setLanguage(sessionUtil.getLocalLanguage());
		List<ShelfLifeVO> list = labNoteCommonMapper.selectOneShelfLifeContInfo(reqDTO);

		responseVO.setOk(list);
		return responseVO;
	}

	public String selectLabNoteApprBomInfoApprCdTemp() {
		return labNoteCommonMapper.selectLabNoteApprBomInfoApprCdTemp();
	}

	@Transactional
	public int insertElabLotMemo(ElabLotMemoVO regVO) {
		return labNoteCommonMapper.insertElabLotMemo(regVO);
	}

	public ResponseVO selectMyBoardAlarmList() {
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(labNoteCommonMapper.selectMyBoardAlarmList(sessionUtil.getLoginId()));
		return responseVO;
	}

	public int selectSafetyContentsListCount(LabNoteCommonReqSafetyContentsSearchDTO reqDTO) {
		reqDTO.setLocalLanguage(sessionUtil.getLocalLanguage());

		int result = 0;
		String type = reqDTO.getVTypecd();

		if ("SAP".equals(type)) {
			result = labNoteCommonMapper.selectProductListCount(reqDTO);
		} else if ("ODM".equals(type)) {
			result = labNoteCommonMapper.selectOdmProductListCount(reqDTO);
		} else {
			result = labNoteCommonMapper.selectSafetyElabNoteListCount(reqDTO);
		}

		return result;
	}

	public List<ProductVO> selectSafetyContentsList(LabNoteCommonReqSafetyContentsSearchDTO reqDTO) {
		reqDTO.setLocalLanguage(sessionUtil.getLocalLanguage());

		List<ProductVO> result = null;
		String type = reqDTO.getVTypecd();

		if ("SAP".equals(type)) {
			result = labNoteCommonMapper.selectProductList(reqDTO);
		} else if ("ODM".equals(type)) {
			result = labNoteCommonMapper.selectOdmProductList(reqDTO);
		} else {
			result = labNoteCommonMapper.selectSafetyElabNoteList(reqDTO);
		}

		return result;
	}

	public ResponseVO selectMyBoardApprovalList() {
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(labNoteCommonMapper.selectMyBoardApprovalList(sessionUtil.getLoginId()));
		return responseVO;
	}

	public ResponseVO selectMyBoardMemoList() {
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(labNoteCommonMapper.selectMyBoardMemoList(sessionUtil.getLoginId()));
		return responseVO;
	}

	@Transactional
	public ResponseVO saveMyBoardMemo(MyBoardMemoDTO myboardMemoDTO) {
		ResponseVO responseVO = new ResponseVO();

		myboardMemoDTO.setVRegUserid(sessionUtil.getLoginId());
		if (StringUtils.isNotEmpty(myboardMemoDTO.getVTumnTsntUserMemoNo())) {
			labNoteCommonMapper.updateMyBoardMemo(myboardMemoDTO);
		} else {
			labNoteCommonMapper.insertMyBoardMemo(myboardMemoDTO);
		}

		responseVO.setOk(myboardMemoDTO.getVTumnTsntUserMemoNo());
		return responseVO;
	}

	public ResponseVO deleteMyBoardMemo(MyBoardMemoDTO myboardMemoDTO) {
		ResponseVO responseVO = new ResponseVO();

		labNoteCommonMapper.deleteMyBoardMemo(myboardMemoDTO);
		responseVO.setCreateOk(null);
		return responseVO;
	}

	public void updateEpReport(LabNoteCommonWokReportReqDTO wokReportVo) {
		labNoteCommonMapper.updateEpReport(wokReportVo);
	}

	@Transactional
	public void getZplm013MosAjax(Zplm013MosAjaxVO mosAjaxVO) {

//		reqVo.putDefault("i_sContCd", reqVo.getString("i_sSapCd"));
//		reqVo.putAnullB("i_sContCd", reqVo.getString("i_sContCd"), "-");

//		reqVo.putDefault("i_sWerks", "1110");

		List<SupTrComponentVO> list = this.selectMosMatnrTempList(SupTrComponentVO.builder()
				.vProductCd(mosAjaxVO.getVProductCd())
				.nVersion(mosAjaxVO.getNVersion())
				.vContCd(mosAjaxVO.getVContCd())
				.build());

		if (!ObjectUtils.isEmpty(list)) {

			int size = list.size();

//			StringBuffer str  = new StringBuffer();

			String product_cd = mosAjaxVO.getVProductCd();
			int version	  	  = mosAjaxVO.getNVersion();
			String cont_cd	  = mosAjaxVO.getVContCd();
			String werks	  = mosAjaxVO.getVWerks();

			String[] arrMatnr 	  = new String[size];
			String[] arrMatnr_per = new String[size];

			for(int i=0; i<size; i++){

				SupTrComponentVO rvo = list.get(i);
				arrMatnr[i] 	= rvo.getVMatnr();
				arrMatnr_per[i] = Double.toString(rvo.getNMatnrInPer());
			}

			String tddPrdCd1 = mosAjaxVO.getVTddProdType1Cd();
			String tddPrdCd2 = mosAjaxVO.getVTddProdType2Cd();

			MosInfoVO standardVo = null;

			if (StringUtils.isEmpty(tddPrdCd2)) {
				standardVo = this.selectMosCalCulInfo(MosInfoVO.builder()
						.vType01Cd(tddPrdCd1)
						.vType02Cd(tddPrdCd2)
						.build());
			} else {
				standardVo = this.selectTddProdMosInfo(MosInfoVO.builder()
						.vTddProdType2Cd(mosAjaxVO.getVTddProdType2Cd())
						.build());
			}

			if (!ObjectUtils.isEmpty(standardVo)) {

				//시퀀스
//				int n_seqno = 0;
				List<SupTrMosComponentVO> mosCompList = null;

				//카테고리 값 저장
				SupTrMosStandardVO tempVo = SupTrMosStandardVO.builder()
						.vProductCd(product_cd)
						.nVersion(version)
						.vContentCd(cont_cd)
						.vLandCd("UN")
						.vWerks(werks)
						.vPrdct(standardVo.getVPrdct())
						.vGday(standardVo.getVGday())
						.vMgday(standardVo.getVMgday())
						.vRfdt(standardVo.getVRfdt())
						.vUsep(standardVo.getVUsep())
						.vMkday(standardVo.getVMkday())
						.vZpgew(standardVo.getVZpgew())
						.vZrect("")
						.vZptnt("")
						.vRegUserid(sessionUtil.getLoginId())
						.build();

				this.insertMosStandard(tempVo);

				Zplms0332ListVO mosVo = labNoteSAPInterfaceService.getRawListToZPLM34E_SingleFomula_MOS(arrMatnr, arrMatnr_per);

				if (!ObjectUtils.isEmpty(mosVo)) {
					List<Zplms0332VO> formulaList  = mosVo.getTmpZplm34eSingleFormulaList();
					List<Zplms0332VO> allergenList = mosVo.getTmpZplm34eSingleFormulaAllergenList();

					double n_mkday = Double.parseDouble(standardVo.getVMkday());

//					this.cmDao.delete("ZmSafeTestReqProduct.deleteMosComponent", reqVo);
					labNoteCommonMapper.deleteMosComponent(SupTrMosComponentVO.builder()
							.vProductCd(product_cd)
							.nVersion(version)
							.vContentCd(cont_cd)
							.build());

//					n_seqno = this.mosCalculQuery(tempVo, formulaList, n_mkday, "N");
					mosCompList = this.mosCalculQuery(tempVo, formulaList, n_mkday, "N");

					//SUCC면 StringBuffer와 n_seqnop 초기화 시킴
//					if(n_seqno > 1){
					if (!ObjectUtils.isEmpty(mosCompList)) {
						this.insertMosComponent(mosCompList);
					}

//					n_seqno = this.mosCalculQuery(tempVo, allergenList, n_mkday, "Y");
					mosCompList = this.mosCalculQuery(tempVo, allergenList, n_mkday, "Y");

//					if(n_seqno > 1){
					if (!ObjectUtils.isEmpty(mosCompList)) {
						this.insertMosComponent(mosCompList);
					}
				}
			}
		}
	}

//	public List<CmMap> getMosMatnrTempList(CmMap reqVo) {
	public List<SupTrComponentVO> selectMosMatnrTempList(SupTrComponentVO supTrComponentVO) {
//		return this.cmDao.getList("ZmSafeTestReqProduct.getMosMatnrTempList", reqVo);
		return labNoteCommonMapper.selectMosMatnrTempList(supTrComponentVO);
	}

	public MosInfoVO selectMosCalCulInfo(MosInfoVO mosInfoVO) {

		if (StringUtils.isNotEmpty(mosInfoVO.getVType01Cd())) {
			mosInfoVO.setVType(mosInfoVO.getVType01Cd());
			mosInfoVO.setVType2(mosInfoVO.getVType02Cd());
		}

		return labNoteCommonMapper.selectMosCalCulInfo(mosInfoVO);
	}

	public MosInfoVO selectTddProdMosInfo(MosInfoVO mosInfoVO) {
		// TDD 제품유형 MOS 정보 조회
		if (StringUtils.isNotEmpty(mosInfoVO.getVTddProdType2Cd())) {
			return labNoteCommonMapper.selectTddProdMosInfo(mosInfoVO);
		} else {
			return null;
		}
	}

	@Transactional
	public void insertMosStandard(SupTrMosStandardVO supTrMosStandardVO) {
		labNoteCommonMapper.deleteMosStandard(supTrMosStandardVO);
		labNoteCommonMapper.insertMosStandard(supTrMosStandardVO);
	}

	private List<SupTrMosComponentVO> mosCalculQuery(SupTrMosStandardVO reqVo, List<Zplms0332VO> list, double n_mgday, String allergen_yn){

		//시퀀스
//		int n_suuc  = 0;
		List<SupTrMosComponentVO> mosCompList = new ArrayList<>();
//		int n_seqno = reqVo.getInt("i_MosSeqno");
		int n_seqno = 0;

		if (!ObjectUtils.isEmpty(list)) {

			for(int i=0; i<list.size(); i++){

				Zplms0332VO subVo = list.get(i);

				double n_conper = Double.parseDouble(subVo.getConper());
				double n_enva1  = Double.parseDouble(subVo.getEnva1());
				double n_znoel  = Double.parseDouble(subVo.getZnoel());
				double n_sed    = 0.0;

				String n_zmos	 = "N/A";
				String n_znoel_s = "N/A";

				if(n_conper != 0.0 && n_enva1 != 0.0){

					double n_digit = Math.pow(10, 10);

					n_sed = Math.floor(((n_conper * n_enva1 * n_mgday) / 10000) * n_digit) / n_digit;

					if(n_znoel != 0.0){

						double n_mos = 0;

						if(n_sed !=0.0){

							n_mos = Math.round((n_znoel/n_sed) * 1000)/1000;

							if(n_mos > 10000) {
								n_zmos = "> 10000";
							}else{
								n_zmos = Double.toString(Math.floor(n_mos * 1000)/1000);
							}
						}else{
							n_zmos = "N/A";
						}

						n_znoel_s = Double.toString(n_znoel);

					}else{
						n_zmos 	  = "N/A";
						n_znoel_s = "N/A";
					}

				}else{
					n_sed = 0.0;
				}

//				NumberFormat f 	 = NumberFormat.getInstance();
//				f.setGroupingUsed(false);
				DecimalFormat df = new DecimalFormat("##.##########");

//				n_suuc++;
				n_seqno++;

				mosCompList.add(SupTrMosComponentVO.builder()
						.vProductCd(reqVo.getVProductCd())
						.nVersion(reqVo.getNVersion())
						.nSeqno(n_seqno)
						.vContentCd(reqVo.getVContentCd())
						.vConcd(subVo.getConcd())
						.nConInPer(n_conper)
						.vCasNo(subVo.getCasno())
						.vZnoel(n_znoel_s)
						.vEnva1(Double.toString(n_enva1))
						.vZsed(df.format(n_sed))
						.vZmos(n_zmos)
						.vAllergenYn(allergen_yn)
						.vRegUserid(reqVo.getVRegUserid())
						.build());
			}
		}

//		reqVo.put("i_MosSeqno",n_seqno);
//		return n_suuc;
		return mosCompList;
	}

	@Transactional
	public void insertMosComponent(List<SupTrMosComponentVO> mosCompList) {
		labNoteCommonMapper.insertMosComponent(mosCompList);
	}

	@Transactional
	public void essentialTestAdd(EssentialTestAddVO essentialTestAddVO){

		List<SupTrCategoryAccVO> cessenList = this.selectCategoryEssenList(SupTrCategoryAccVO.builder()
				.vType01Cd(essentialTestAddVO.getVTypeCd())
				.vType02Cd(essentialTestAddVO.getVTypeCd2())
				.build());

		if (!ObjectUtils.isEmpty(cessenList)) {

			for(int i=0; i<cessenList.size(); i++) {
//				tempVo.put("i_sRecType02Cd", cessenList.get(i).getString("v_rec_type02_cd"));
				this.insertEssentialTest(SupTrEssentialTestVO.builder()
						.vTargetCd(essentialTestAddVO.getVProductCd())
						.nVersion(essentialTestAddVO.getNVersion())
						.vRecType02Cd(cessenList.get(i).getVRecType02Cd())
						.vRegUserid(essentialTestAddVO.getVRegUserid())
						.build());
			}
		}

		if (StringUtils.isNotEmpty(essentialTestAddVO.getVLabNoteCd())) {

//			tempVo.put("i_sLabNoteCd", essentialTestAddVO.getString("i_sLabNoteCd"));

			List<SupTrLabNoteTagVO> tagList = labNoteCommonMapper.selectNoteEssenList(essentialTestAddVO.getVLabNoteCd());

			if (!ObjectUtils.isEmpty(tagList)) {

				for(int i=0; i<tagList.size(); i++) {
//					tempVo.put("i_sRecType02Cd", tagList.get(i).getString("v_rec_type02_cd"));
					this.insertEssentialTest(SupTrEssentialTestVO.builder()
							.vTargetCd(essentialTestAddVO.getVProductCd())
							.nVersion(essentialTestAddVO.getNVersion())
							.vRecType02Cd(tagList.get(i).getVRecType02Cd())
							.vRegUserid(essentialTestAddVO.getVRegUserid())
							.build());
				}
			}
		}
	}

	public int deleteTrComponent(SupTrComponentVO supTrComponentVO) {
		return labNoteCommonMapper.deleteTrComponent(supTrComponentVO);
	}

	public List<LabNoteComponentVerVO> selectLabNoteComponentVer2(LabNoteComponentVerVO labNoteComponentVerVO) {
		return labNoteCommonMapper.selectLabNoteComponentVer2(labNoteComponentVerVO);
	}

	public int insertTrLabNoteComponent2(List<LabNoteComponentVerVO> labNoteList) {
		return labNoteCommonMapper.insertTrLabNoteComponent2(labNoteList);
	}

	public List<SupTrCategoryAccVO> selectCategoryEssenList(SupTrCategoryAccVO supTrCategoryAccVO) {
		return labNoteCommonMapper.selectCategoryEssenList(supTrCategoryAccVO);
	}

	public void insertEssentialTest(SupTrEssentialTestVO supTrEssentialTestVO) {
		labNoteCommonMapper.insertEssentialTest(supTrEssentialTestVO);
	}

	public List<CodeDTO> selectReqTestMethodList(List<String> testItemCdList) {
		return labNoteCommonMapper.selectReqTestMethodList(testItemCdList);
	}

	public TddProductClassVO selectTddProductValue(String vTargetTddProduct) {
		return labNoteCommonMapper.selectTddProductValue(vTargetTddProduct);
	}

	public String selectChinaSafetyElabBrandSubCode(String vBrandCd) {
		return labNoteCommonMapper.selectChinaSafetyElabBrandSubCode(vBrandCd);
	}

	public CpsrTesterUserVO selectChinaSafetyReviewUser(String vBrandCd) {
		return labNoteCommonMapper.selectChinaSafetyReviewUser(vBrandCd);
	}

	public int insertChinaSafetyEv(ChinaSafetyMstVO chinaSafetyMstVO) {
		return labNoteCommonMapper.insertChinaSafetyEv(chinaSafetyMstVO);
	}

	public int insertChinaSafetyMsgLog(ChinaSafetyMsgVO chinaSafetyMsgVO) {
		return labNoteCommonMapper.insertChinaSafetyMsgLog(chinaSafetyMsgVO);
	}

	public List<TddProductClassVO> selectTddProductClassList(String vPid) {
		return labNoteCommonMapper.selectTddProductClassList(vPid);
	}

	@Transactional
	public void savePilotCompleteCpc (BomApprovalReqDTO regDTO) {
		ProcCpcVO procCpcVO = ProcCpcVO.builder()
				.vLabNoteCd(regDTO.getVLabNoteCd())
				.vContPkCd(regDTO.getVContPkCd())
				.nVersion(regDTO.getNVersion() )
				.vLotCd(regDTO.getVLotCd())
				.vSendActionFlag("P")
				.vNoteType("SC")
				.build();
		this.updateLabNoteSendContToCpc(procCpcVO);		// CPC로 내용물 개요 정보 전송
		this.updateLabNoteSendBomToCpc(procCpcVO);		// CPC로 BOM 정보 전송
	}

	public void checkPQCShelfLife(String apprCd) {
		labNoteCommonMapper.checkPQCShelfLife(apprCd);
	}


	public List<TestReqCounterMrq011DTO> selectCounterMrq011List(String vTrProductCd, int nTrVersion) {
		return labNoteCommonMapper.selectCounterMrq011List(vTrProductCd, nTrVersion);
	}

	public String selectStringMrq011CheckSapCd(@Valid LabNoteTestReqDTO reqDTO) {
		return labNoteCommonMapper.selectStringMrq011CheckSapCd(reqDTO);
	}

	public ResponseVO selectMessageList(String vRecordid) {
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(labNoteCommonMapper.selectMessageList(vRecordid, sessionUtil.getLocalLanguage()));
		return responseVO;
	}

	public int insertMessage(MessageDTO messageDTO) {
		if (StringUtils.isEmpty(messageDTO.getVRecordid()) || StringUtils.isEmpty(messageDTO.getVMessage())) {
			return 0;
		}

		messageDTO.setVRegUserid(sessionUtil.getLoginId());
		messageDTO.setVUpdateUserid(sessionUtil.getLoginId());

		return labNoteCommonMapper.insertMessage(messageDTO);
	}

	public List<LabNoteProcessProgressDTO> selectProgressInfo(String vLabNoteCd, String vPageType) {
		return labNoteCommonMapper.selectProgressInfo(vLabNoteCd, vPageType);
	}

	public List<ScheduleDTO> selectNoteDetailScheduleList(String vLabNoteCd) {
		return labNoteCommonMapper.selectNoteDetailScheduleList(vLabNoteCd);
	}

	public String selectLabNoteActiveStatus(String vStatusCd) {
		return labNoteCommonMapper.selectLabNoteActiveStatus(vStatusCd);
	}

	public List<LabNoteProcessProgressDTO> selectMyboardScheduleStatusList() {
		return labNoteCommonMapper.selectMyboardScheduleStatusList();
	}

	public ResponseVO selectMaterialIssueList(String vSapCd) {
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(MaterialIssueResDTO.builder()
								.issueList(labNoteCommonMapper.selectMaterialIssueList(vSapCd))
								.scmIssueList(labNoteCommonMapper.selectMaterialScmIssueList(vSapCd))
								.build());
		return responseVO;
	}

	public ResponseVO insertLabNoteMyMate(MaterialMateRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();

		regDTO.setVUserid(sessionUtil.getLoginId());
		regDTO.setVRegUserid(sessionUtil.getLoginId());
		int result = labNoteCommonMapper.insertLabNoteMyMate(regDTO);

		if (result > 0) {
			responseVO.setOk(null);
		} else {
			responseVO.setOkWithCode("C9999", CommonResultCode.SAVE_FAIL, null);
		}

		return responseVO;
	}

	public ResponseVO deleteLabNoteMyMate(MaterialMateRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();

		regDTO.setVUserid(sessionUtil.getLoginId());
		int result = labNoteCommonMapper.deleteLabNoteMyMate(regDTO);

		if (result > 0) {
			responseVO.setOk(null);
		} else {
			responseVO.setOkWithCode("C9999", CommonResultCode.SAVE_FAIL, null);
		}
		return responseVO;
	}

	public List<LabNoteCommonSearchMateDTO> selectSearchMateAutocompleteList(LabNoteCommonReqSearchMateDTO mateReqDTO) {
		mateReqDTO.setVUserid(sessionUtil.getLoginId());
		return labNoteCommonMapper.selectSearchMateAutocompleteList(mateReqDTO);
	}

	public ResponseVO selectRecentMateList(List<String> arrKey) {
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(labNoteCommonMapper.selectRecentMateList(arrKey, sessionUtil.getLoginId()));
		return responseVO;
	}

	@Transactional
	public ResponseVO insertAttachFile(AttachUploadRegDTO regDTO) {
		ResponseVO responseVO = new ResponseVO();

		commonService.saveCommAttach(regDTO.getFileList(), regDTO.getVUploadCd(), regDTO.getVRecordid());

		responseVO.setOk(Const.SUCC);
		return responseVO;
	}

	public ResponseVO selectLotStatusList(String vLabNoteCd) {
		ResponseVO responseVO = new ResponseVO();
		responseVO.setOk(labNoteCommonMapper.selectLotStatusList(vLabNoteCd));
		return responseVO;
	}

	public List<SupTrProductVO> selectDupleNoteCheckList(String vSapCd, String vLabNoteCd, String vLotCd) {
		return labNoteCommonMapper.selectDupleNoteCheckList(vSapCd, vLabNoteCd, vLotCd);
	}

	public ResponseVO selectSafetySapChk(String vSapCd, String vLabNoteCd, String vLotCd) {
		ResponseVO responseVO = new ResponseVO();
		responseVO.setOk(this.selectDupleNoteCheckList(vSapCd, vLabNoteCd, vLotCd));
		return responseVO;
	}

	public LabNoteCommonSearchMateDTO selectLabNoteExcelHal4Mate(String vMateCd) {
		return labNoteCommonMapper.selectLabNoteExcelHal4Mate(vMateCd);
	}

	public WokReportResDTO selectEpReport(WokReportReqDTO wokReqDTO) {
		String vRootDocCls = labNoteCommonMapper.selectEpReportRootDocCls(wokReqDTO);
		wokReqDTO.setVRootDocCls(vRootDocCls);

		if("view".equals(wokReqDTO.getVViewFlag())) {
			labNoteCommonMapper.updateReportViewCount(wokReqDTO);
		}

		return labNoteCommonMapper.selectEpReport(wokReqDTO);
	}

	public int updateEpReportStatus(@Valid ReportApprovalReqDTO reportReqDTO, WokReportResDTO rvo) {

		if(rvo != null) {
			if("Y".equals(rvo.getVFlagPlm())) {
				List<WokReportMatResDTO> contentsList = this.selectEpReportMat(WokReportReqDTO.builder()
						.vRecordid(reportReqDTO.getVRecordid())
						.localLanguage(sessionUtil.getLangCd())
						.build());

				if(contentsList != null) {
					String TIUM_WEB_URL	 	= PropertyUtil.getProperty("tium.web.url");
					for(WokReportMatResDTO mstVo : contentsList) {
						labNoteCommonMapper.insertTrProductIf(SupTrPrdIFDTO.builder()
								.vProductCd(mstVo.getVRecordid())
								.vSapCd(mstVo.getVMatnr())
								.vDocClass("DCL20270")
								.vObjectDesc("기시법 변경 시험 성적서")
								.vUrl(TIUM_WEB_URL + "wo/ep/wo_ep_report_view.do?i_sRecordId=" + mstVo.getVRecordid())
								.vRegUserid(sessionUtil.getLoginId())
								.vUpdateUserid(sessionUtil.getLoginId())
								.build());
					}
				}
			}
		}

		int result = labNoteCommonMapper.updateEpReportStatus(reportReqDTO);

		if("Y".equals(reportReqDTO.getVFinishYn())) {
			String reportFinishno = labNoteCommonMapper.selectReportFinishNo(reportReqDTO.getVRecordid());
			labNoteCommonMapper.updateReportFinishNo(reportReqDTO.getVRecordid(), reportFinishno);
		}

		return result;
	}

	public List<WokReportMatResDTO> selectEpReportMat(WokReportReqDTO wokReqDTO){
		return labNoteCommonMapper.selectEpReportMat(wokReqDTO);
	}

	public List<RcvFirstSaleDateDTO> selectSingleContReleaseDateList(String vContCd) {
		return labNoteCommonMapper.selectSingleContReleaseDateList(vContCd);
	}

	public List<RcvFirstSaleDateDTO> selectMultiContReleaseDateList(List<?> contList) {
		return labNoteCommonMapper.selectMultiContReleaseDateList(contList);
	}

	public List<WokReportSecretResDTO> selectEpReportSecret(String vRecordid) {
		return labNoteCommonMapper.selectEpReportSecret(vRecordid);
	}

	public List<BatchStatusProcessVO> selectStockProcessTargetList() {
		return labNoteCommonMapper.selectStockProcessTargetList();
	}

	public List<BatchStatusProcessVO> selectReleaseProcessTargetList() {
		return labNoteCommonMapper.selectReleaseProcessTargetList();
	}

	public void sendCompleteAlarm(List<BatchStatusProcessVO> list, String mailType, String pageTypeNm, String noteType) {
		Map<String, List<BatchStatusProcessVO>> noteList = list.stream().collect(Collectors.groupingBy(BatchStatusProcessVO::getVLabNoteCd));
		Map<String, List<BatchStatusProcessVO>> userNoteList = list.stream().collect(Collectors.groupingBy(BatchStatusProcessVO::getVUserid));
		String pageUrl = "/" + pageTypeNm + "/all-lab-note-prd-view?vLabNoteCd=";

		if (!ObjectUtils.isEmpty(noteList)) {
			Iterator<String> labNoteCd = noteList.keySet().iterator();
			
			String statusCd = "STOCK".equals(mailType) ? "AL_NOTE7" : "AL_NOTE11";
			String alrTypeCd = "STOCK".equals(mailType) ? "AL_NOTE7_01" : "AL_NOTE11_01";

			while(labNoteCd.hasNext()) {
				List<BatchStatusProcessVO> alarmNoteList = noteList.get(labNoteCd.next());

				if (!ObjectUtils.isEmpty(alarmNoteList)) {
					BatchStatusProcessVO lotInfo = alarmNoteList.get(0);

					if (lotInfo != null) {
						commonService.sendAlarmBatch(AlarmRegDTO.builder()
													.vLabNoteCd(lotInfo.getVLabNoteCd())
													.vStatusCd(statusCd)
													.vAlrTypeCd(alrTypeCd)
													.typeList(Arrays.asList(Const.ALARM, Const.MAIL, Const.TIMELINE, Const.SCHEDULE))
													.vContCd(lotInfo.getVContCd())
													.vContNm(lotInfo.getVContNm())
													.nVerNo(lotInfo.getNVersion() < 10 ? "0" + lotInfo.getNVersion() : "" + lotInfo.getNVersion())
													.vLotNm(lotInfo.getVLotNm() + (lotInfo.getNLotCnt() > 1 ? (" 외 " + (lotInfo.getNLotCnt() - 1) + "건") : ""))
													.vNoteType(noteType)
													.userList(Arrays.asList(lotInfo.getVUserid()))
													.vMoveUrl(pageUrl + lotInfo.getVLabNoteCd())
													.build());
					}
				}
			}
		}

		if (!ObjectUtils.isEmpty(userNoteList)) {
			MailForm mailForm = new MailForm();
			Iterator<String> users = userNoteList.keySet().iterator();
			while(users.hasNext()) {
				List<BatchStatusProcessVO> mailNoteList = userNoteList.get(users.next());

				if (!ObjectUtils.isEmpty(mailNoteList)) {

					String mailContent = mailForm.getBatchMailContent(mailNoteList, mailType, pageUrl);
					String contInfo = mailNoteList.get(0).getVContCd() + (mailNoteList.size() > 1 ? " 외 " + (mailNoteList.size() - 1) + "건" : "");
					String title = new StringBuilder()
										.append(contInfo)
										.append("STOCK".equals(mailType) ? " 내용물 개발이 완료되었습니다. (입고완료)" : " 내용물 출시가 완료되었습니다.")
										.toString();

					MailUtil.send(mailNoteList.get(0).getVEmail(), null, title, mailContent);
				}
			}
		}
	}

	public String selectLabNoteLaborCd (String vUserid) {
		return labNoteCommonMapper.selectLabNoteLaborCd(vUserid);
	}

	public ResponseVO selectFuncMateList(String vEvaluateCd, List<String> arrFunctionCd) {
		ResponseVO responseVO = new ResponseVO();
		
		responseVO.setOk(labNoteCommonMapper.selectFuncMateList(vEvaluateCd, arrFunctionCd));
		return responseVO;
	}

	public void insertBrandManagerGroupUser(BrandManagerGroupDTO dto) {
		labNoteCommonMapper.insertBrandManagerGroupUser(dto);
	}

	public List<SapBiodRsltPerDTO> selectBiodRsltValueUpdateList() {
		return labNoteCommonMapper.selectBiodRsltValueUpdateList();
	}

	public void updateSapBiodRsltValue(SapBiodRsltPerDTO bioVo) {
		labNoteCommonMapper.updateSapBiodRsltValue(bioVo);
	}
}