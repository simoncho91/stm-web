package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class WokReportMatResDTO {

	@JsonProperty("vMaktx")
	private String vMaktx;
	
	@JsonProperty("vMatnr")
	private String vMatnr;
	
	@JsonProperty("vMtart")
	private String vMtart;
	
	@JsonProperty("vRecordid")
	private String vRecordid;

	@JsonProperty("vRegDtm")
	private String vRegDtm;
	
	@JsonProperty("vRegUserid")
	private String vRegUserid;
	
	@JsonProperty("vUpdateDtm")
	private String vUpdateDtm;
	
	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;
	
	@JsonProperty("vContentType")
	private String vContentType;
	
	@JsonProperty("vPlantCd")
	private String vPlantCd;
	
	@JsonProperty("vContentTypeNm")
	private String vContentTypeNm;
	
	@JsonProperty("vLockStatusFlag")
	private String vLockStatusFlag;
	
	@JsonProperty("vZuname")
	private String vZuname;

}
