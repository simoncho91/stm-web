package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LabNoteTestReqBoardVo {

	@JsonProperty("vProductCd")
	private String vProductCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vProductNm")
	private String vProductNm;

	@JsonProperty("vStatusCd")
	private String vStatusCd;

	@JsonProperty("vSapCd")
	private String vSapCd;

	@JsonProperty("vDocNo")
	private String vDocNo;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vDeptCd")
	private String vDeptCd;

	@JsonProperty("vTrLotNm")
	private String vTrLotNm;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("nLabNoteVer")
	private int nLabNoteVer;

	@JsonProperty("vLabReqDtm")
	private String vLabReqDtm;

	@JsonProperty("vLabGateCd")
	private String vLabGateCd;

	@JsonProperty("vLabMrqTypeCd")
	private String vLabMrqTypeCd;

	@JsonProperty("vRegDtm")
	private String vRegDtm;

	@JsonProperty("vFinalResult")
	private String vFinalResult;

	@JsonProperty("vUsernm")
	private String vUsernm;
	
	@JsonProperty("vLotNm")
	private String vLotNm;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vTargetContCd")
	private String vTargetContCdContCd;

	@JsonProperty("vStatusNm")
	private String vStatusNm;

	@JsonProperty("nLineCnt")
	private int nLineCnt;
	
	@JsonProperty("nRowNum")
	private int nRowNum;
	
	@JsonProperty("nRowOrderNum")
	private int nRowOrderNum;

	@JsonProperty("vTrResMrq010Txt")
	private String vTrResMrq010Txt;

	@JsonProperty("vTrResMrq011Txt")
	private String vTrResMrq011Txt;

	@JsonProperty("vTrResMrq040FuncTxt")
	private String vTrResMrq040FuncTxt;

	@JsonProperty("vTrResMrq040HarmTxt")
	private String vTrResMrq040HarmTxt;

	@JsonProperty("vTrResMrq050Txt")
	private String vTrResMrq050Txt;

	@JsonProperty("vTrResMrq060Txt")
	private String vTrResMrq060Txt;

	@JsonProperty("vTrResMrq070Txt")
	private String vTrResMrq070Txt;

	@JsonProperty("vTrResClinicalTxt")
	private String vTrResClinicalTxt;
	
	@JsonProperty("vTrResMrq010Color")
	private String vTrResMrq010Color;
	
	@JsonProperty("vTrResMrq011Color")
	private String vTrResMrq011Color;
	
	@JsonProperty("vTrResMrq040FuncColor")
	private String vTrResMrq040FuncColor;
	
	@JsonProperty("vTrResMrq040HarmColor")
	private String vTrResMrq040HarmColor;
	
	@JsonProperty("vTrResMrq050Color")
	private String vTrResMrq050Color;
	
	@JsonProperty("vTrResMrq060Color")
	private String vTrResMrq060Color;
	
	@JsonProperty("vTrResMrq070Color")
	private String vTrResMrq070Color;
	
	@JsonProperty("vTrResClinicalColor")
	private String vTrResClinicalColor;

}
