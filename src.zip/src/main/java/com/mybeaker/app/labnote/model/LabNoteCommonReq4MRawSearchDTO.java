package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentPagingDTO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class LabNoteCommonReq4MRawSearchDTO extends ParentPagingDTO {
	@JsonProperty("vKeyword")
	private String vKeyword;
	
	@JsonProperty("vLabDeptCd")
	private String vLabDeptCd;
	
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("vMaterialCd")
	private String vMaterialCd;
	
	@JsonProperty("vSearchType")
	private String vSearchType;
	
	private String localLanguage;
}
