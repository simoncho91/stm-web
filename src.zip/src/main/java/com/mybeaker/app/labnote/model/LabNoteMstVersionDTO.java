package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteMstVersionDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vVersionKey")
	private String vVersionKey;

	@JsonProperty("vVersionTxt")
	private String vVersionTxt;

	@JsonProperty("vCounterTypeCd")
	private String vCounterTypeCd;

	@JsonProperty("vCounterTypeNm")
	private String vCounterTypeNm;

	@JsonProperty("vCounterCd")
	private String vCounterCd;

	@JsonProperty("vCounterContPkCd")
	private String vCounterContPkCd;

	@JsonProperty("vCounterInvenCd")
	private String vCounterInvenCd;

	@JsonProperty("vCounterInvenJoinCd")
	private String vCounterInvenJoinCd;

	@JsonProperty("vCounterNote")
	private String vCounterNote;

	@JsonProperty("vCounterBrdNm")
	private String vCounterBrdNm;

	@JsonProperty("vCounterPrdNm")
	private String vCounterPrdNm;

	@JsonProperty("vCounterSpInfo")
	private String vCounterSpInfo;

	@JsonProperty("vPrePilotDt")
	private String vPrePilotDt;

	@JsonProperty("vFlagNewItem")
	private String vFlagNewItem;

	@JsonProperty("vPerfumeCd")
	private String vPerfumeCd;

	@JsonProperty("vFlagPerfumeNew")
	private String vFlagPerfumeNew;

	@JsonProperty("vRefTypeCd")
	private String vRefTypeCd;

	@JsonProperty("vRefContCd")
	private String vRefContCd;

	@JsonProperty("vEvaluateCd")
	private String vEvaluateCd;

	@JsonProperty("vSsrid")
	private String vSsrid;

	@JsonProperty("vRefNote")
	private String vRefNote;

	@JsonProperty("vFlagModify")
	private String vFlagModify;
}
