package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class VersionListVO {

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vCounterCd")
	private String vCounterCd;

	@JsonProperty("vCounterContPkCd")
	private String vCounterContPkCd;

	@JsonProperty("vFlagPriceHide")
	private String vFlagPriceHide;

	@JsonProperty("vFlagReqHide")
	private String vFlagReqHide;

	@JsonProperty("vFlagMaxmixHide")
	private String vFlagMaxmixHide;

	@JsonProperty("vFlagExistHide")
	private String vFlagExistHide;
	
	@JsonProperty("vFlagBaseHide")
	private String vFlagBaseHide;

	@JsonProperty("vFlagInpMethod")
	private String vFlagInpMethod;

	@JsonProperty("vFlagAppMode")
	private String vFlagAppMode;

	@JsonProperty("vVersionNm")
	private String vVersionNm;

	@JsonProperty("vVersionTxt")
	private String vVersionTxt;

	@JsonProperty("vScVsersionTxt")
	private String vScVsersionTxt;

	@JsonProperty("nMaxVersion")
	private int nMaxVersion;

	@JsonProperty("vCounterContCd")
	private String vCounterContCd;

	@JsonProperty("vCounterContNm")
	private String vCounterContNm;

	@JsonProperty("vFlagExistsComplete")
	private String vFlagExistsComplete;

	@JsonProperty("vFlagView")
	private String vFlagView;

	@JsonProperty("vCounterNoteType")
	private String vCounterNoteType;
}
