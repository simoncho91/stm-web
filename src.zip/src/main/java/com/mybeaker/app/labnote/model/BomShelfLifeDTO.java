package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class BomShelfLifeDTO {
	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vShelfLife")
	private String vShelfLife;
}
