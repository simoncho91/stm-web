package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ElabContQmsVO {

	@JsonProperty("vContCd")
	private String vContCd;
	
	@JsonProperty("vContNm")
	private String vContNm;
	
	@JsonProperty("vSeq")
	private String vSeq;

	@JsonProperty("vDate")
	private String vDate;
	
	@JsonProperty("vLot")
	private String vLot;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vPlantNm")
	private String vPlantNm;

	@JsonProperty("vQmsLotInfo")
	private String vQmsLotInfo;
	
}
