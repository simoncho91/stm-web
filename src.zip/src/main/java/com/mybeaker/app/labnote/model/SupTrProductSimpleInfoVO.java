package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SupTrProductSimpleInfoVO {

	@JsonProperty("vProductCd")
	private String vProductCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vProductNm")
	private String vProductNm;

	@JsonProperty("vProductEngNm")
	private String vProductEngNm;

	@JsonProperty("vStatusCd")
	private String vStatusCd;

	@JsonProperty("vObjTypeCd")
	private String vObjTypeCd;

	@JsonProperty("vSapCd")
	private String vSapCd;
	
	@JsonProperty("vDocNo")
	private String vDocNo;
	
	@JsonProperty("vLot")
	private String vLot;
	
	@JsonProperty("vLabGateCd")
	private String vLabGateCd;
	
	@JsonProperty("vLabMrqTypeCd")
	private String vLabMrqTypeCd;
	
	
	
	
}
