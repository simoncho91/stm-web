package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@Data
public class ElabNoteMstSetVO extends ParentDTO {

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vColumnSetCd")
	private String vColumnSetCd;
	
	@JsonProperty("vColumnSetCdnm")
	private String vColumnSetCdnm;

	@JsonProperty("vColumn")
	private String vColumn;
	
	@JsonProperty("vFlagHide")
	private String vFlagHide;

	@Builder
	public ElabNoteMstSetVO(String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm,
			String vLabNoteCd, String vColumnSetCd, String vColumnSetCdnm, String vColumn, String vFlagHide) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.vLabNoteCd = vLabNoteCd;
		this.vColumnSetCd = vColumnSetCd;
		this.vColumnSetCdnm = vColumnSetCdnm;
		this.vColumn = vColumn;
		this.vFlagHide = vFlagHide;
	}
}
