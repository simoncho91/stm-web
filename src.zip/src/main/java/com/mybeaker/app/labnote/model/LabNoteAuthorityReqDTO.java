package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class LabNoteAuthorityReqDTO extends ParentDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vNoteTypeNm")
	private String vNoteTypeNm;

	@JsonProperty("vPageType")
	private String vPageType;

	private List<String> arrUserList;
}
