package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LotStatusDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vAlrTypeCd")
	private String vAlrTypeCd;

	@JsonProperty("vMessage")
	private String vMessage;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("nVersion")
	private String nVersion;

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("vRegDtm")
	private String vRegDtm;
}
