package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class LabNoteTestQrCodeCheckVO {
	
	@JsonProperty("vProductCd")
	private String vProductCd;
	
	@JsonProperty("nVersion")
	private int nVersion;
	
	@JsonProperty("vType")
	private String vType;
	
	@Builder
	public LabNoteTestQrCodeCheckVO(String vProductCd, int nVersion, String vType) {
		this.vProductCd = vProductCd;
		this.nVersion = nVersion;
		this.vType = vType;
	}
}
