package com.mybeaker.app.labnote.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LabNoteRequestMateRegDTO {
	private String vLabNoteCd;

	private String vContPkCd;

	private int nVersion;

	private String vAddTypeCd;

	private List<LabNoteCommonRequestMateDTO> mateList;
}
