package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LabNoteMusoguTemp2DTO {

	@JsonProperty("vTrPrdCd")
	private String vTrPrdCd;
	
	@JsonProperty("nTrVersion")
	private int nVersion;
	
	@JsonProperty("vRegUserid")
	private String vRegUserid;
	
	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;
	
	@JsonProperty("vRepLotCd")
	private String vRepLotCd;
	
	@JsonProperty("vPlantCd")
	private String vPlantCd;
	
	@JsonProperty("vLand")
	private String vLand;
	
	@JsonProperty("vMatTypeNm")
	private String vMatTypeNm;
	
	@JsonProperty("vInci")
	private String vInci;
	
	@JsonProperty("vMuso")
	private String vMuso;
	
	
}
