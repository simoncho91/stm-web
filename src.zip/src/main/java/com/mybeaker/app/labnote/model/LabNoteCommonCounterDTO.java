package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteCommonCounterDTO {
	@JsonProperty("vContPkCd")
	private String vContPkCd;
	
	@JsonProperty("vContNm")
	private String vContNm;
	
	@JsonProperty("vLotCd")
	private String vLotCd;
	
	@JsonProperty("vLotNm")
	private String vLotNm;
	
	@JsonProperty("vVersionNm")
	private String vVersionNm;
	
	@JsonProperty("vStatusNm")
	private String vStatusNm;
	
	@JsonProperty("vInventoryCd")
	private String vInventoryCd;
	
	@JsonProperty("vInventoryNm")
	private String vInventoryNm;
	
	@JsonProperty("vInvenJoinCd")
	private String vInvenJoinCd;
	
	@JsonProperty("vSubmitInvenNm")
	private String vSubmitInvenNm;
	
	@JsonProperty("vInvenJoinPjtCd")
	private String vInvenJoinPjtCd;
}
