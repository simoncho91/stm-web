package com.mybeaker.app.labnote.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MyBoardNoteInfoReqDTO {
	private String vUserid;

	private String vDeptCd;

	private String localLanguage;

	private String isAdmin;

	private int endRownum;

	private String isMaster;
}
