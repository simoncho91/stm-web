package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentPagingDTO;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Builder
@Data
@EqualsAndHashCode(callSuper=false)
public class LabNoteTestRequestProductReqDTO extends ParentPagingDTO{
		
	private String localLanguage;
	
	@JsonProperty("vFlagExcelAll")
	private String vFlagExcelAll;
	
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("vFromDt")
	private String vFromDt;
	
	@JsonProperty("vToDt")
	private String vToDt;
	
	@JsonProperty("vKeyword")
	private String vKeyword;
	
	@JsonProperty("vTrTypeAllYn")
	private String vTrTypeAllYn;
	
	@JsonProperty("arrTrTypeCd")
	private String [] arrTrTypeCd;

}
