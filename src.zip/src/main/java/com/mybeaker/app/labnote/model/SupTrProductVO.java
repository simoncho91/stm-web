package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class SupTrProductVO {

	@JsonProperty("vProductCd")
	private String vProductCd;
	
	@JsonProperty("nVersion")
	private int nVersion;
	
	@JsonProperty("vProductNm")
	private String vProductNm;
	
	@JsonProperty("vSapCd")
	private String vSapCd;
	
	@JsonProperty("vDocNo")
	private String vDocNo;
	
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("vLotCd")
	private String vLotCd;
}
