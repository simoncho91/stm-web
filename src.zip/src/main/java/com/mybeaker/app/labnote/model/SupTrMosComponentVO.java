package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class SupTrMosComponentVO {

	@JsonProperty("vProductCd")
	private String vProductCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("nSeqno")
	private int nSeqno;

	@JsonProperty("vContentCd")
	private String vContentCd;

	@JsonProperty("vConcd")
	private String vConcd;

	@JsonProperty("nConInPer")
	private double nConInPer;

	@JsonProperty("vCasNo")
	private String vCasNo;

	@JsonProperty("vZnoel")
	private String vZnoel;

	@JsonProperty("vEnva1")
	private String vEnva1;

	@JsonProperty("vZsed")
	private String vZsed;

	@JsonProperty("vZmos")
	private String vZmos;

	@JsonProperty("vAllergenYn")
	private String vAllergenYn;

	@JsonProperty("vRegUserid")
	private String vRegUserid;

	@JsonProperty("vRegDtm")
	private String vRegDtm;
}
