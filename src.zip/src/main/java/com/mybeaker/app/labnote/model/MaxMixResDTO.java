package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class MaxMixResDTO {
	
	@JsonProperty("vMrqNm")
	private String vMrqNm;

	@JsonProperty("nMaxMix")
	private String nMaxMix;

	@JsonProperty("vTesterComment")
	private String vTesterComment;
}
