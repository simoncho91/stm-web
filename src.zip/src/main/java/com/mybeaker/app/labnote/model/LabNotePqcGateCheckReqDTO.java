package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LabNotePqcGateCheckReqDTO {
	
	@JsonProperty("vPqcCd")
	private String vPqcCd;
	
	@JsonProperty("vPqcGateCd")
	private String vPqcGateCd;
	
	@JsonProperty("vNoteType")
	private String vNoteType;
	
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("nVersion")
	private int nVersion;
	
	@JsonProperty("vPqcType")
	private String vPqcType;

	@JsonProperty("vFlagG2Buffer3")
	private String vFlagG2Buffer3;
	
	@JsonProperty("vPqcResCd")
	private String vPqcResCd;
	
	@JsonProperty("FLAG_PQC_LAST_RES")
	private String FLAG_PQC_LAST_RES;
	
	@JsonProperty("nTargetGram")
	private int nTargetGram;
	
	@JsonProperty("vPqcGate1ResCd")
	private String vPqcGate1ResCd;
	
	@JsonProperty("arrLotCd")
	private String [] arrLotCd;
	
	@JsonProperty("vGetType")
	private String vGetType;
	
	@JsonProperty("vContPkCd")
	private String vContPkCd;
	
	@JsonProperty("vConditionField")
	private String vConditionField;
	
	@JsonProperty("vLotCd")
	private String vLotCd;
	
}
