package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LabNoteProcessContDecideListDTO{

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vG1PqcResCd")
	private String vG1PqcResCd;

	@JsonProperty("vG1PqcLotCd")
	private String vG1PqcLotCd;

	@JsonProperty("vG1PqcLotNm")
	private String vG1PqcLotNm;

	@JsonProperty("nG1ObeyPer")
	private double nG1ObeyPer;

	@JsonProperty("vG2PqcResCd")
	private String vG2PqcResCd;

	@JsonProperty("vG2PqcLotCd")
	private String vG2PqcLotCd;

	@JsonProperty("vG2PqcLotNm")
	private String vG2PqcLotNm;

	@JsonProperty("nG2ObeyPer")
	private double nG2ObeyPer;

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("vLotNm")
	private String vLotNm;

	@JsonProperty("vApprStatus")
	private String vApprStatus;

	@JsonProperty("vApprStatusnm")
	private String vApprStatusnm;

	@JsonProperty("vG2ApprCd")
	private String vG2ApprCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vVersionTxt")
	private String vVersionTxt;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vPlantNm")
	private String vPlantNm;

	@JsonProperty("vFlagRepresent")
	private String vFlagRepresent;

	@JsonProperty("vEffectDtm")
	private String vEffectDtm;
}
