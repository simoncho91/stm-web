package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteTestReqLotVO {
	
	@JsonProperty("vLotCd")
	private String vLotCd;
	
	@JsonProperty("vContPkCd")
	private String vContPkCd;
	
	@JsonProperty("nVersion")
	private int nVersion;
	
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("vLotNm")
	private String vLotNm;
	
	@JsonProperty("vFlagDecide")
	private String vFlagDecide;
	
	@JsonProperty("vFlagNotice")
	private String vFlagNotice;
	
	@JsonProperty("vFlagComplete")
	private String vFlagComplete;
	
	@JsonProperty("vFlagLotHide")
	private String vFlagLotHide;
	
	@JsonProperty("nGramOpenNum")
	private String nGramOpenNum;
	
	@JsonProperty("nPilotTestSeqno")
	private String nPilotTestSeqno;
	
	@JsonProperty("vPilotTestDtm")
	private String vPilotTestDtm;
	
	@JsonProperty("vApprCd")
	private String vApprCd;
	
	@JsonProperty("vFlagBomReq")
	private String vFlagBomReq;
	
	@JsonProperty("vFlagIngredientReq")
	private String vFlagIngredientReq;
	
	@JsonProperty("vEffectDtm")
	private String vEffectDtm;
	
	@JsonProperty("vTrPrdCd")
	private String vTrPrdCd;
	
	@JsonProperty("vTestType")
	private String vTestType;
	
	@JsonProperty("vTestTypeNm")
	private String vTestTypeNm;
	
	@JsonProperty("vTestValue")
	private String vTestValue;
	
	@JsonProperty("vPh")
	private String vPh;
	
	@JsonProperty("vLotMemo")
	private String vLotMemo;
	
	@JsonProperty("vFlagExposure")
	private String vFlagExposure;
	
	@JsonProperty("vFlagStability")
	private String vFlagStability;
	
	@JsonProperty("vFlagUse")
	private String vFlagUse;
	
	@JsonProperty("vFlagSend")
	private String vFlagSend;
	
	@JsonProperty("vSort")
	private String vSort;
	
	@JsonProperty("vFlagBookmark")
	private String vFlagBookmark;
	
	@JsonProperty("vLotTestMemo")
	private String vLotTestMemo;
	
	@JsonProperty("vFlagFinal")
	private String vFlagFinal;
	
	@JsonProperty("vFlagNoFragrance")
	private String vFlagNoFragrance;
	
	
}
