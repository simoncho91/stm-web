package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class MosInfoVO {

	@JsonProperty("vCategoryCd1")
	private String vCategoryCd1;

	@JsonProperty("vCategoryCd2")
	private String vCategoryCd2;

	@JsonProperty("vPrdct")
	private String vPrdct;

	@JsonProperty("vGday")
	private String vGday;

	@JsonProperty("vMgday")
	private String vMgday;

	@JsonProperty("vRfdt")
	private String vRfdt;

	@JsonProperty("vMkday")
	private String vMkday;

	@JsonProperty("vZpgew")
	private String vZpgew;

	@JsonProperty("vRegDtm")
	private String vRegDtm;

	@JsonProperty("vUpdateDtm")
	private String vUpdateDtm;

	@JsonProperty("nSeqno")
	private int nSeqno;

	@JsonProperty("vClassCd")
	private String vClassCd;

	@JsonProperty("vUclassCd")
	private String vUclassCd;
	
	private String language;
	
	private String vType;
	
	private String vType2;
	
	private String vType01Cd;
	
	private String vType02Cd;
	
	private String vTddProdType2Cd;
	
	@JsonProperty("vUsep")
	private String vUsep;
}
