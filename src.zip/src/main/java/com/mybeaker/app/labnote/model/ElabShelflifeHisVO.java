package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ElabShelflifeHisVO {

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("nSeqno")
	private int nSeqno;

	@JsonProperty("vBeforeShelfLife")
	private String vBeforeShelfLife;

	@JsonProperty("vAfterShelfLife")
	private String vAfterShelfLife;

	@JsonProperty("vChangeReason")
	private String vChangeReason;

	@JsonProperty("vRegUserid")
	private String vRegUserid;

	@JsonProperty("vRegDtm")
	private String vRegDtm;

}
