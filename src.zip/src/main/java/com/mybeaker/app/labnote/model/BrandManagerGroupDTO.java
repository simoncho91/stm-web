package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class BrandManagerGroupDTO extends ParentDTO {
	@JsonProperty("vUserid")
	private String vUserid;
	
	@JsonProperty("vDeptCd")
	private String vDeptCd;
	
	@Builder
	public BrandManagerGroupDTO(String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm,
									String vUserid, String vDeptCd) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.vUserid = vUserid;
		this.vDeptCd = vDeptCd;
	}
	
	
}
