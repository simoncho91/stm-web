package com.mybeaker.app.labnote.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class SapCallLogMdi0010VO {

	private String vLogCd;

	private String vMatnr;

	private String vMhdhb;
	
	private String vEmsgty;
	
	private String vEmsg;
	
	private String vRegUserid;
}
