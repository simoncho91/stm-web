package com.mybeaker.app.labnote.model;

import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@Data
public class ElabHal4MateVO extends ParentDTO {

	private String vHal4Cd;

	private String vPlantCd;

	private String vLandCd;

	private String vMateCd;

	private int nSeq;

	private String vMateNm;
	
	private String nRate;

	@Builder
	public ElabHal4MateVO(String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm, String vHal4Cd,
			String vPlantCd, String vLandCd, String vMateCd, int nSeq, String vMateNm, String nRate) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.vHal4Cd = vHal4Cd;
		this.vPlantCd = vPlantCd;
		this.vLandCd = vLandCd;
		this.vMateCd = vMateCd;
		this.nSeq = nSeq;
		this.vMateNm = vMateNm;
		this.nRate = nRate;
	}
}
