package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ShelfLifeVO {

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vNoteType")
	private String vNoteType;

	@JsonProperty("vNoteTypeNm")
	private String vNoteTypeNm;

	@JsonProperty("vContType")
	private String vContType;

	@JsonProperty("vStatusCd")
	private String vStatusCd;

	@JsonProperty("vStatusCdNm")
	private String vStatusCdNm;

	@JsonProperty("vDocKind")
	private String vDocKind;

	@JsonProperty("vShelfLife")
	private String vShelfLife;
	
	@JsonProperty("vOriginShelfLife")
	private String vOriginShelfLife;
	
	@JsonProperty("vEtcLife")
	private String vEtcLife;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vPlantNm")
	private String vPlantNm;

	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;

	@JsonProperty("vUsernm")
	private String vUsernm;

	@JsonProperty("vUpdateDtm")
	private String vUpdateDtm;

	@JsonProperty("vMaktx")
	private String vMaktx;

	@JsonProperty("vFlagSubPlant")
	private String vFlagSubPlant;

	@JsonProperty("vDocKindNm")
	private String vDocKindNm;
	
	@JsonProperty("vFlagLife")
	private String vFlagLife;
	
	private String language;
	
	private List<String> contCdList;
	
	@JsonProperty("vRecordid")
	private String vRecordid;
	
	private String vBeforeStatusCd;
	
	private String vApprMatrCd;
}
