package com.mybeaker.app.labnote.model;

import java.util.List;

import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.approval.model.ReqResApprovalDTO;
import com.mybeaker.app.common.model.OrganizationDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LabNoteCommonReqShelflifeDTO {
	@JsonProperty("vRecordid")
	private String vRecordid;
	
	@JsonProperty("vApprCd")
	private String vApprCd;
	
	@JsonProperty("vContCd")
	private String vContCd;
	
	@JsonProperty("contCdList")
	private List<String> contCdList;
	
	private String localLanguage;
	
//	SAVE - 필요없으면 추후 삭제
	@JsonProperty("vContFlag")
	private String vContFlag;
	
//	M - 필요없으면 추후 삭제
//	@JsonProperty("vFlagSave")
//	private String vFlagSave;
	
//	문서종류 ex) SLK020
	@JsonProperty("vDocKind")
	private String vDocKind;
	
//	상태 ex) SLS070
	@JsonProperty("vSaveStatus")
	private String vSaveStatus;
	
//	구분
	@JsonProperty("vNoteType")
	private String vNoteType;
	
//	변경사유
	@JsonProperty("vChangeReason")
	private String vChangeReason;
	
//	일괄적용
	@JsonProperty("vChkAll")
	@Builder.Default
	private String vChkAll = "N";
	
//	내용물 정보
	@Size(min = 1)
	@JsonProperty("contInfoList")
	private List<ShelfLifeVO> contInfoList;
	
	private String vApprTitle;
	
	private String vApprMatrCd;
	
	@JsonProperty("referenceList")
	private List<OrganizationDTO> referenceList;
	
	@JsonProperty("apprParams")
	ReqResApprovalDTO apprParams;
}
