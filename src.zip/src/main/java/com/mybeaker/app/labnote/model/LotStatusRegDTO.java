package com.mybeaker.app.labnote.model;

import com.mybeaker.app.model.dto.ParentDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class LotStatusRegDTO extends ParentDTO {
	private String vLabNoteCd;

	private String vStatusCd;

	private String vLabStatusCd;

	private String vAlrTypeCd;

	private String vMessage;

	private String vContPkCd;

	private int nVersion;

	private String nPilotNo;

	private String vLotCd;

	@Builder.Default
	private String vFlagBatch = "N";
}
