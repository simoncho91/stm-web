package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class WokReportSecretResDTO {
	
	@JsonProperty("vRecordid")
	private String vRecordid;

	@JsonProperty("vSecretNm")
	private String vSecretNm;
	
	@JsonProperty("vSecret")
	private String vSecret;
	
	@JsonProperty("nSeq")
	private int nSeq;
	
	@JsonProperty("nSecretLevel")
	private int nSecretLevel;
	
	@JsonProperty("vSecretRoom")
	private String vSecretRoom;
	
	@JsonProperty("vRegDtm")
	private String vRegDtm;
	
	@JsonProperty("vRegUserid")
	private String vRegUserid;
	
	@JsonProperty("vUpdateDtm")
	private String vUpdateDtm;
	
	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;

}
