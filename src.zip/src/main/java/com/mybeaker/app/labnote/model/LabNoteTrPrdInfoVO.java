package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteTrPrdInfoVO {

	@JsonProperty("vProductCd")
	private String vProductCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vProductNm")
	private String vProductNm;

	@JsonProperty("vProductEngNm")
	private String vProductEngNm;

	@JsonProperty("vStatusCd")
	private String vStatusCd;

	@JsonProperty("vStatusNm")
	private String vStatusNm;

	@JsonProperty("vSapCd")
	private String vSapCd;

	@JsonProperty("vDocNo")
	private String vDocNo;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vUserNm")
	private String vUserNm;

	@JsonProperty("vEmail")
	private String vEmail;

	@JsonProperty("vUserDeptNm")
	private String vUserDeptNm;

	@JsonProperty("vDeptCd")
	private String vDeptCd;

	@JsonProperty("vDeptNm")
	private String vDeptNm;

	@JsonProperty("vMakerNm")
	private String vMakerNm;

	@JsonProperty("vLot")
	private String vLot;

	@JsonProperty("vPh")
	private String vPh;

	@JsonProperty("vTypeCd")
	private String vTypeCd;

	@JsonProperty("vTypeCd2")
	private String vTypeCd2;

	@JsonProperty("vTypeNm")
	private String vTypeNm;

	@JsonProperty("vTypeNm2")
	private String vTypeNm2;

	@JsonProperty("vDosageFormCd")
	private String vDosageFormCd;

	@JsonProperty("vDosageFormNm")
	private String vDosageFormNm;

	@JsonProperty("vFeature")
	private String vFeature;

	@JsonProperty("vCompareSampleNm")
	private String vCompareSampleNm;

	@JsonProperty("vRegUserid")
	private String vRegUserid;

	@JsonProperty("vRegDtm")
	private String vRegDtm;

	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;

	@JsonProperty("vUpdateDtm")
	private String vUpdateDtm;

	@JsonProperty("vFlagDel")
	private String vFlagDel;

	@JsonProperty("vAmoreProdYn")
	private String vAmoreProdYn;

	@JsonProperty("vLabCd")
	private String vLabCd;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("nLabNoteVer")
	private int nLabNoteVer;

	@JsonProperty("vCont1Cd")
	private String vCont1Cd;

	@JsonProperty("vCont1Nm")
	private String vCont1Nm;

	@JsonProperty("vCont2Cd")
	private String vCont2Cd;

	@JsonProperty("vCont2Nm")
	private String vCont2Nm;

	@JsonProperty("vFlagMrq010")
	private String vFlagMrq010;

	@JsonProperty("vFlagMrq011")
	private String vFlagMrq011;

	@JsonProperty("vFlagMrq030")
	private String vFlagMrq030;

	@JsonProperty("vFlagMrq040")
	private String vFlagMrq040;

	@JsonProperty("vFlagMrq050")
	private String vFlagMrq050;

	@JsonProperty("vFlagMrq060")
	private String vFlagMrq060;

	@JsonProperty("vMrq010StatusCd")
	private String vMrq010StatusCd;

	@JsonProperty("vMrq011StatusCd")
	private String vMrq011StatusCd;

	@JsonProperty("vMrq030StatusCd")
	private String vMrq030StatusCd;

	@JsonProperty("vMrq040StatusCd")
	private String vMrq040StatusCd;

	@JsonProperty("vMrq050StatusCd")
	private String vMrq050StatusCd;

	@JsonProperty("vMrq060StatusCd")
	private String vMrq060StatusCd;

	@JsonProperty("vMrq010StatusNm")
	private String vMrq010StatusNm;

	@JsonProperty("vMrq011StatusNm")
	private String vMrq011StatusNm;

	@JsonProperty("vMrq030StatusNm")
	private String vMrq030StatusNm;

	@JsonProperty("vMrq040StatusNm")
	private String vMrq040StatusNm;

	@JsonProperty("vMrq050StatusNm")
	private String vMrq050StatusNm;

	@JsonProperty("vMrq060StatusNm")
	private String vMrq060StatusNm;

	@JsonProperty("vMrq010Userid")
	private String vMrq010Userid;

	@JsonProperty("vMrq011Userid")
	private String vMrq011Userid;

	@JsonProperty("vMrq030Userid")
	private String vMrq030Userid;

	@JsonProperty("vMrq040Userid")
	private String vMrq040Userid;

	@JsonProperty("vMrq050Userid")
	private String vMrq050Userid;

	@JsonProperty("vMrq060Userid")
	private String vMrq060Userid;

	@JsonProperty("vMrq010Tester")
	private String vMrq010Tester;

	@JsonProperty("vMrq011Tester")
	private String vMrq011Tester;

	@JsonProperty("vMrq030Tester")
	private String vMrq030Tester;

	@JsonProperty("vMrq040Tester")
	private String vMrq040Tester;

	@JsonProperty("vMrq050Tester")
	private String vMrq050Tester;

	@JsonProperty("vMrq060Tester")
	private String vMrq060Tester;

	@JsonProperty("vMrq010ResultCd")
	private String vMrq010ResultCd;

	@JsonProperty("vMrq011ResultCd")
	private String vMrq011ResultCd;

	@JsonProperty("vMrq030ResultCd")
	private String vMrq030ResultCd;

	@JsonProperty("vMrq040ResultCd")
	private String vMrq040ResultCd;

	@JsonProperty("vMrq050ResultCd")
	private String vMrq050ResultCd;

	@JsonProperty("vMrq060ResultCd")
	private String vMrq060ResultCd;

	@JsonProperty("vMrq010ResultNm")
	private String vMrq010ResultNm;

	@JsonProperty("vMrq011ResultNm")
	private String vMrq011ResultNm;

	@JsonProperty("vMrq030ResultNm")
	private String vMrq030ResultNm;

	@JsonProperty("vMrq040ResultNm")
	private String vMrq040ResultNm;

	@JsonProperty("vMrq050ResultNm")
	private String vMrq050ResultNm;

	@JsonProperty("vMrq060ResultNm")
	private String vMrq060ResultNm;

	@JsonProperty("vMrq010StartDt")
	private String vMrq010StartDt;

	@JsonProperty("vMrq011StartDt")
	private String vMrq011StartDt;

	@JsonProperty("vMrq030StartDt")
	private String vMrq030StartDt;

	@JsonProperty("vMrq040StartDt")
	private String vMrq040StartDt;

	@JsonProperty("vMrq050StartDt")
	private String vMrq050StartDt;

	@JsonProperty("vMrq060StartDt")
	private String vMrq060StartDt;

	@JsonProperty("vMrq010EndDt")
	private String vMrq010EndDt;

	@JsonProperty("vMrq011EndDt")
	private String vMrq011EndDt;

	@JsonProperty("vMrq030EndDt")
	private String vMrq030EndDt;

	@JsonProperty("vMrq040EndDt")
	private String vMrq040EndDt;

	@JsonProperty("vMrq050EndDt")
	private String vMrq050EndDt;

	@JsonProperty("vMrq060EndDt")
	private String vMrq060EndDt;

	@JsonProperty("vMrq010AcceptDtm")
	private String vMrq010AcceptDtm;

	@JsonProperty("vMrq011AcceptDtm")
	private String vMrq011AcceptDtm;

	@JsonProperty("vMrq030AcceptDtm")
	private String vMrq030AcceptDtm;

	@JsonProperty("vMrq040AcceptDtm")
	private String vMrq040AcceptDtm;

	@JsonProperty("vMrq050AcceptDtm")
	private String vMrq050AcceptDtm;

	@JsonProperty("vMrq060AcceptDtm")
	private String vMrq060AcceptDtm;

	@JsonProperty("vLotNm")
	private String vLotNm;

	@JsonProperty("vRpmsCd")
	private String vRpmsCd;

	@JsonProperty("vPjtNm")
	private String vPjtNm;

	@JsonProperty("vMngTmpCd")
	private String vMngTmpCd;
	
	
	
	
}
