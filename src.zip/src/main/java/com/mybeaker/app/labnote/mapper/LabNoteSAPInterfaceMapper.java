package com.mybeaker.app.labnote.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.mybeaker.app.labnote.model.BomListVO;
import com.mybeaker.app.labnote.model.ElabShelflifeContVO;
import com.mybeaker.app.labnote.model.Mat3VO;
import com.mybeaker.app.labnote.model.SapCallLogMdi0005VO;
import com.mybeaker.app.labnote.model.SapCallLogMdi0010VO;
import com.mybeaker.app.labnote.model.SapCallLogVO;
import com.mybeaker.app.labnote.model.TmpZplmt13ContentInfoVO;

@Mapper
public interface LabNoteSAPInterfaceMapper {

	public int insertSapCallLogMDI0005(SapCallLogMdi0005VO sapCallLogMdi0005VO);
	
	public int insertSapCallLogMDI0010(SapCallLogMdi0010VO sapCallLogMdi0010VO);
	
	public int insertSapCallLog(SapCallLogVO sapCallLogVO);
	
	public SapCallLogMdi0005VO selectErsda(SapCallLogMdi0005VO sapCallLogMdi0005VO);
	
	public List<Mat3VO> selectMat3List(BomListVO bomListVO);
	
	public int updateElabShelfLifeLogCd(ElabShelflifeContVO elabShelflifeContVO);
	
	public String selectAllergenYn(String conCd);
	
	public String selectTmpContentCd();
	
	public int deleteTmpZplmt13ContentInfo(String vTmpContentCd);
	
	public int insertTmpZplmt13ContentInfo(TmpZplmt13ContentInfoVO tmpZplmt13ContentInfoVO);
	
	public int insertTmpZplmt13ContentInfo2(TmpZplmt13ContentInfoVO tmpZplmt13ContentInfoVO);
	
	public String select4HalWrek(String vHal4Cd);
	
	public List<TmpZplmt13ContentInfoVO> selectTmpZplm34eSingleFormulaList(String vTmpContentCd);
	
	public List<TmpZplmt13ContentInfoVO> selectTmpZplm34eSingleFormulaAllergenList(String vTmpContentCd);
}
