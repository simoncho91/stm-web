package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteProcessTimeLineDTO {
	
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("vStatusCd")
	private String vStatusCd;
	
	@JsonProperty("nSeqno")
	private int nSeqno;
	
	@JsonProperty("vMessage")
	private String vMessage;
	
	@JsonProperty("vRegDtm")
	private String vRegDtm;
	
}
