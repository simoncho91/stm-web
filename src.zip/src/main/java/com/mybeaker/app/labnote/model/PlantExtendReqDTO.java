package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class PlantExtendReqDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vNoteType")
	private String vNoteType;

	@JsonProperty("vBrdCd")
	private String vBrdCd;

	@JsonProperty("vCodeType")
	private String vCodeType;

	List<PlantExtendDTO> extendContList;
}
