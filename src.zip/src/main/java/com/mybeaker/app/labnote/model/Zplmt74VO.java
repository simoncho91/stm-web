package com.mybeaker.app.labnote.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Zplmt74VO {

	private String matnr;

	private String concdO;

	private String lvl;

	private String concd;

	private String inPer;
}
