package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class PgcGqteResVO {

	@JsonProperty("vPqcResCd")
	private String vPqcResCd;

	@JsonProperty("vApprCd")
	private String vApprCd;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vGateCd")
	private String vGateCd;

	@JsonProperty("nObeyPer")
	private double nObeyPer;

	@JsonProperty("vComment")
	private String vComment;

	@JsonProperty("vFlagDel")
	private String vFlagDel;

	@JsonProperty("vRegUserid")
	private String vRegUserid;

	@JsonProperty("vRegDtm")
	private String vRegDtm;

	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;

	@JsonProperty("vUpdateDtm")
	private String vUpdateDtm;

	@JsonProperty("vShelflifeYn")
	private String vShelflifeYn;
	
	@JsonProperty("vLotCd")
	private String vLotCd;
	
	@JsonProperty("vKey")
	private String vKey;

}
