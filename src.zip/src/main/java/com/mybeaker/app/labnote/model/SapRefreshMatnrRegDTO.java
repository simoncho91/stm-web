package com.mybeaker.app.labnote.model;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SapRefreshMatnrRegDTO {
	
	@NotEmpty
	@JsonProperty("vMatnr")
	private String vMatnr;
	
	@NotEmpty
	@JsonProperty("vLand1")
	private String vLand1;
	@NotEmpty
	
	@NotEmpty
	@JsonProperty("vWerks")
	private String vWerks;
	
	@JsonProperty("vMaktx")
	private String vMaktx;
}
