package com.mybeaker.app.labnote.model;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.common.model.CodeDTO;
import com.mybeaker.app.skincare.model.IngredientContVO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LabNoteProcessFuncReportRegResDTO<T> {

	@JsonProperty("basicInfo")
	private LabNoteProcessFuncReportVerLotVO basicInfo;
	
	@JsonProperty("contList")
	private List<IngredientContVO> contList;
	
	@JsonProperty("verList")
	private List<LabNoteMstVersionDTO> verList;
	
	@JsonProperty("mateList")
	private List<LabNoteProcessFuncMateResDTO> mateList;
	
	@JsonProperty("funcList")
	private List<LabNoteCommonTagDTO> funcList;
	
	@JsonProperty("releaseDt")
	private List<MusoguTagVO> releaseDt;
	
	@JsonProperty("qmsLotInfoList")
	private List<ElabContQmsVO> qmsLotInfoList;
	
	@JsonProperty("rvo")
	private T rvo;
	
	@JsonProperty("verVo")
	private LabNoteVersionDTO verVo;
	
	@JsonProperty("makerList")
	private Map<String, List<CodeDTO>> makerList;
	
	private List<LabNoteProcessFuncReportDecideContDTO> decideNmList;
	
	private LabNoteProcessFuncReportResPopDTO qaVo;
	
}
