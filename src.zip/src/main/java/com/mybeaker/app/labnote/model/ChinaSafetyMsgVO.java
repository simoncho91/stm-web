package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ChinaSafetyMsgVO {

	@JsonProperty("vRecordid")
	private String vRecordid;

	@JsonProperty("nSeq")
	private int nSeq;

	@JsonProperty("vMessage")
	private String vMessage;

	@JsonProperty("vRegDtm")
	private String vRegDtm;

	@JsonProperty("vRegUserid")
	private String vRegUserid;
}
