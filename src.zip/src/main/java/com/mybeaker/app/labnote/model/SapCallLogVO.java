package com.mybeaker.app.labnote.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class SapCallLogVO {

	private String vLogCd;

	private String vServiceCd;

	private String vWerks;

	private String vMatnr;

	private String vContentCd;

	private String vRawCd;

	private String vCallDtm;

	private String vIfId;

	private String vRtnType;

	private String vRtnMsg;

	private String vResult;

	private String vMessage;

	private String vRegUserid;

	private String vLand;
}
