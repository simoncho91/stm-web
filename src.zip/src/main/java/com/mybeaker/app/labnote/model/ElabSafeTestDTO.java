package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class ElabSafeTestDTO extends ParentDTO {
	@JsonProperty("vProductCd")
	private String vProductCd;

	@JsonProperty("vProductNm")
	private String vProductNm;

	@JsonProperty("vNewProductNm")
	private String vNewProductNm;

	@JsonProperty("vProductEngNm")
	private String vProductEngNm;

	@JsonProperty("vNewProductEngNm")
	private String vNewProductEngNm;

	@JsonProperty("vType")
	private String vType;

	@JsonProperty("vHistCd")
	private String vHistCd;


	@Builder
	public ElabSafeTestDTO(String vProductCd, String vProductNm, String vProductEngNm, String vType,
							String vNewProductNm, String vNewProductEngNm, String vHistCd,
							String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.vProductCd = vProductCd;
		this.vProductNm = vProductNm;
		this.vNewProductNm = vNewProductNm;
		this.vNewProductEngNm = vNewProductEngNm;
		this.vProductEngNm = vProductEngNm;
		this.vHistCd = vHistCd;
		this.vType = vType;
	}
}
