package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class SupTrPrdIFDTO {

	@JsonProperty("vProductCd")
	private String vProductCd;

	@JsonProperty("vSapCd")
	private String vSapCd;

	@JsonProperty("vDocClass")
	private String vDocClass;

	@JsonProperty("vObjectDesc")
	private String vObjectDesc;

	@JsonProperty("vUrl")
	private String vUrl;
	
	@JsonProperty("vRegUserid")
	private String vRegUserid;
	
	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;
	
}
