package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ElabShelflifeSubVO {

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vChShelfLife")
	private String vChShelfLife;

	@JsonProperty("vShelfLife")
	private String vShelfLife;

	@JsonProperty("vShelfLifeTxt")
	private String vShelfLifeTxt;

	@JsonProperty("vChangeReason")
	private String vChangeReason;

	@JsonProperty("vRegUserid")
	private String vRegUserid;

	@JsonProperty("vMaktx")
	private String vMaktx;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vPlantNm")
	private String vPlantNm;

	@JsonProperty("vFlagSubPlant")
	private String vFlagSubPlant;
	
	@JsonProperty("vRecordid")
	private String vRecordid;

	@JsonProperty("vNoteType")
	private String vNoteType;

	@JsonProperty("vContType")
	private String vContType;

	@JsonProperty("vRegDtm")
	private String vRegDtm;

	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;

	@JsonProperty("vUpdateDtm")
	private String vUpdateDtm;

}
