package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class TddProductClassVO {

	@JsonProperty("nLevel")
	private int nLevel;

	@JsonProperty("vClassCd")
	private String vClassCd;

	@JsonProperty("vUclassCd")
	private String vUclassCd;

	@JsonProperty("nIsleaf")
	private int nIsleaf;

	@JsonProperty("vFlagAppr")
	private String vFlagAppr;

	@JsonProperty("vPrdct")
	private String vPrdct;

	@JsonProperty("vTgpol")
	private String vTgpol;

	@JsonProperty("vGday")
	private String vGday;

	@JsonProperty("vMgday")
	private String vMgday;

	@JsonProperty("vRfdt")
	private String vRfdt;

	@JsonProperty("vMkday")
	private String vMkday;

	@JsonProperty("nLife")
	private int nLife;

	@JsonProperty("vFlagPao")
	private String vFlagPao;

	@JsonProperty("nPao")
	private int nPao;

	@JsonProperty("vAmount")
	private String vAmount;

	@JsonProperty("vExpsRoute")
	private String vExpsRoute;

	@JsonProperty("vExpsText")
	private String vExpsText;

	@JsonProperty("vZpgew")
	private String vZpgew;

	@JsonProperty("vReferCategory")
	private String vReferCategory;

	@JsonProperty("vFlagUse")
	private String vFlagUse;

	@JsonProperty("nSeqno")
	private int nSeqno;
	
	@JsonProperty("vCid")
	private String vCid;
	
	@JsonProperty("vTitle")
	private String vTitle;
	
	@JsonProperty("vPid")
	private String vPid;
	
	@JsonProperty("vUsenode")
	private String vUsenode;
}
