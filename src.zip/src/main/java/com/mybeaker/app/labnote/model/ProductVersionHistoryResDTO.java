package com.mybeaker.app.labnote.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductVersionHistoryResDTO {
	private List<ProductVersionHistoryDTO> mstList;

	private List<LabNoteCommonRequestMateDTO> mateList;
}
