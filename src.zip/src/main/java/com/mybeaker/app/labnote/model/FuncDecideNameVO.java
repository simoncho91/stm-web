package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class FuncDecideNameVO {

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("nFdnVer")
	private int nFdnVer;

	@JsonProperty("vNoteType")
	private String vNoteType;

	@JsonProperty("vTitle")
	private String vTitle;
	
	private String vStatusCd;
	
	private String vFlagComplete;
	
	private String vUpdateUserid;
	
	private String localLanguage;
	
	private String vContPkCd;
	
	private String vDecideContNm;
	
	private String vFlagDecide;
	
	private String vApprCd;
	
	private String vFlagCompleteDtmDel;
	
	private String vFlagNameModAuth;
	
}
