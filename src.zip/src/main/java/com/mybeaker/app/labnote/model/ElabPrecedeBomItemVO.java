package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@Data
public class ElabPrecedeBomItemVO extends ParentDTO {

	@JsonProperty("vPrecedePkCd")
	private String vPrecedePkCd;

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("nSeqno")
	private int nSeqno;

	@JsonProperty("vMatePkCd")
	private String vMatePkCd;
	
	@Builder
	public ElabPrecedeBomItemVO(String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm,
			String vPrecedePkCd, String vLotCd, int nSeqno, String vMatePkCd) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.vPrecedePkCd = vPrecedePkCd;
		this.vLotCd = vLotCd;
		this.nSeqno = nSeqno;
		this.vMatePkCd = vMatePkCd;
	}
}
