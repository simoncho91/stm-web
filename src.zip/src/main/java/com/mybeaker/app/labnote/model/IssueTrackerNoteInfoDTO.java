package com.mybeaker.app.labnote.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IssueTrackerNoteInfoDTO<T> {
	private T noteInfo;

	private List<?> verList;

	private List<?> contList;

	private List<?> lotList;
}