package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LabNoteCommonResShelflifeDTO {
	@JsonProperty("map")
	private ElabShelflifeMstVO map;
	
	@JsonProperty("list")
	private List<?> list;
	
	@JsonProperty("finalSubPlantList")
	private List<ElabShelflifeSubVO> finalSubPlantList;
}
