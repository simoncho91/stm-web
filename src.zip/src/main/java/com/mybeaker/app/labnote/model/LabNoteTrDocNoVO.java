package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteTrDocNoVO {

	@JsonProperty("vTrDocTypeCd")
	private String vTrDocTypeCd;

	@JsonProperty("vYear")
	private String vYear;
	
	@JsonProperty("nSeqno")
	private int nSeqno;
	
	@JsonProperty("vDocText")
	private String vDocText;
	
	
	
	
}
