package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteCommonProdSearchDTO {
	@JsonProperty("nNum")
	private int nNum;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vPrdCd")
	private String vPrdCd;

	@JsonProperty("vPrdNm")
	private String vPrdNm;

	@JsonProperty("vPrdNmEn")
	private String vPrdNmEn;
}
