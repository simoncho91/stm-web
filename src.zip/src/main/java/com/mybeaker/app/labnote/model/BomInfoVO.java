package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class BomInfoVO {

	private String hal4Cd;
	
	private String hal4Nm;
	
	private String hal4Per;
	
	private String rawCd;
	
	private String rawPer;
	
	private String rawNm;
	
	private String concd;
	
	private String conPer;
	
	private String conInPer;
	
	private String connameKo;
	
	private String connameEn;
	
	private String connameCd;
	
	private String connameCn;
	
	private String connameJa;
	
	private String fcnameKo;
	
	private String fcnameEn;
	
	private String casno;
	
	private String mixre;
	
	private String zglobal;
	
	private String zgubcl;
	
	private String zgllim;
	
	private String zgrd1;
	
	private String zgrd2;
	
	private String werks;
	
	private String contentsCd;
	
	private String contentsNmKo;
	
	private String contentsNmEn;
	
	private String contentsPer;
	
	private String aicsno;
	
	private String matnrR;
	
	private String maktxR;
	
	private int nSort;
	
	private String matNum;
	
	@JsonProperty("vMatNum")
	private String vMatNum;
	
	@JsonProperty("vPermissionKr")
	private String vPermissionKr;
	
	@JsonProperty("vStandard")
	private String vStandard;
	
	@JsonProperty("vIngrTxt")
	private String vIngrTxt;
	
	@JsonProperty("vCmbCode")
	private String vCmbCode;
	
	@JsonProperty("vCmbCodeNm")
	private String vCmbCodeNm;
}
