package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SupTrProdMarkDTO {
	
	@JsonProperty("vTrPrdCd")
	private String vTrPrdCd;
	
	@JsonProperty("nVersion")
	private int nVersion;
	
	@JsonProperty("nSeqno")
	private int nSeqno;
	
	@JsonProperty("vProdSignCd")
	private String vProdSignCd;
	
	@JsonProperty("vRegUserid")
	private String vRegUserid;
	
}