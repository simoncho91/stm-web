package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteCommonEvalMaterialDTO {
	@JsonProperty("vMaterialCd")
	private String vMaterialCd;

	@JsonProperty("vFunctionCd")
	private String vFunctionCd;

	@JsonProperty("vFunctionNm")
	private String vFunctionNm;

	@JsonProperty("vMaterialNm")
	private String vMaterialNm;

	@JsonProperty("vMaterialNmK")
	private String vMaterialNmK;

	@JsonProperty("vInvenYn")
	private String vInvenYn;
}
