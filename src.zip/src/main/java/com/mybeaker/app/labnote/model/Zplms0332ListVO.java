package com.mybeaker.app.labnote.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Zplms0332ListVO {

	private List<Zplms0332VO> tmpZplm34eSingleFormulaList;
	
	private List<Zplms0332VO> tmpZplm34eSingleFormulaAllergenList;
}
