package com.mybeaker.app.labnote.model;

import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PilotRequestResDTO<T> {
	private T noteInfo;

	private List<?> contList;

	private List<?> lotList;

	private List<PilotRequestMateDTO> bomList;

	private String flagFreePass;

	private PgcGqteResVO pqcVO;

	private LabNoteMstVersionPqcDTO versionPqcInfo;

	private List<BomShelfLifeDTO> shelfLifeList;

	private List<LabNotePqcGateCheckListDTO> pqcList;

	private Map<String, List<LabNoteTestRequestProductDTO>> trMap;
}
