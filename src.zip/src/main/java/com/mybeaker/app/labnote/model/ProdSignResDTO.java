package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProdSignResDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vTag1Cd")
	private String vTag1Cd;
	
	@JsonProperty("vTag2Cd")
	private String vTag2Cd;
	
	@JsonProperty("vTag2Nm")
	private String vTag2Nm;
}
