package com.mybeaker.app.labnote.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LabNoteValidateDTO {

	private String vLotCd;
	
	private int nCntUnusableMate;
	
	private int nCntNotExistsMate;
	
	private int nCntBanMate;
	
	private int nCntTempMate;
	
	private Double nSumRate;
	
	private String vFlagExistsBom;
	
}
