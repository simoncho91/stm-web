package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ElabTroubleHisVO {

	@JsonProperty("vRecordid")
	private String vRecordid;

	@JsonProperty("vMateCd")
	private String vMateCd;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vConInPer")
	private String vConInPer;

	@JsonProperty("vTcode")
	private String vTcode;

	@JsonProperty("vTcodeDesc")
	private String vTcodeDesc;

	@JsonProperty("vEtc")
	private String vEtc;

	@JsonProperty("vDeptCd")
	private String vDeptCd;

	@JsonProperty("vDeptNm")
	private String vDeptNm;

	@JsonProperty("vPack1Cd")
	private String vPack1Cd;

	@JsonProperty("vPack2Cd")
	private String vPack2Cd;

	@JsonProperty("vPack3Cd")
	private String vPack3Cd;

	@JsonProperty("vAftProcCd")
	private String vAftProcCd;

	@JsonProperty("vIfType")
	private String vIfType;

	@JsonProperty("vIfPkCd")
	private String vIfPkCd;
}
