package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.makeup.model.MuNoteMayContainInfoVO;
import com.mybeaker.app.makeup.model.MuSapBomMayContainConVO;
import com.mybeaker.app.qdrug.model.QdrugMatIngrMstVO;
import com.mybeaker.app.qdrug.model.QdrugMatIngrSubVO;
import com.mybeaker.app.qdrug.model.QdrugMatrPmVO;
import com.mybeaker.app.qdrug.model.QdrugMatrDbVO;
import com.mybeaker.app.qdrug.model.QdrugNoteInfoDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class LabNoteProcessIngrdApprResDTO {

	@JsonProperty("contList")
	List<LabNoteContInfoVO> contList;
	
	@JsonProperty("allergenList")
	List<LabNoteSapBomToConInfoVO> allergenList;
	
	@JsonProperty("noAllergenList")
	List<LabNoteSapBomToConInfoVO> noAllergenList;
	
	@JsonProperty("vKidtab06")
	@Builder.Default
	private String vKidtab06 = "N";
	
	@JsonProperty("vFlagCaution")
	@Builder.Default
	private String vFlagCaution = "N";
	
	@JsonProperty("vSumRate")
	private String vSumRate;
	
	@JsonProperty("vFlagExistsDecide")
	private String vFlagExistsDecide;
	
	@JsonProperty("mvo")
	private MuNoteMayContainInfoVO mvo;
	
	@JsonProperty("mcList")
	private List<MuSapBomMayContainConVO> mcList;
	
	@JsonProperty("ingrMstVo")
	private QdrugMatIngrMstVO ingrMstVo;
	
	@JsonProperty("bomList")
	private List<BomInfoVO> bomList;
	
	@JsonProperty("ingrSubList")
	private List<QdrugMatIngrSubVO> ingrSubList;
	
	@JsonProperty("permissionList")
	private List<QdrugMatrPmVO> permissionList;
	
	@JsonProperty("codeList")
	private List<QdrugMatrDbVO> codeList;
	
	@JsonProperty("rvo")
	private QdrugNoteInfoDTO rvo;
	
	@JsonProperty("contentsList")
	List<LabNoteSapBomToConInfoVO> contentsList;
	
	@JsonProperty("vZversion")
	private String vZversion;
}
