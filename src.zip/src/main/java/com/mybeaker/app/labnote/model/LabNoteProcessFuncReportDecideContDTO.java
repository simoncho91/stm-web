package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LabNoteProcessFuncReportDecideContDTO{

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("nVersion")
	private String nVersion;
	
	@JsonProperty("vPlantCd")
	private String vPlantCd;
	
	@JsonProperty("vFlagRepresent")
	private String vFlagRepresent;
	
	@JsonProperty("vContPkCd")
	private String vContPkCd;
	
	@JsonProperty("vContCd")
	private String vContCd;
	
	@JsonProperty("vContNm")
	private String vContNm;
	
	@JsonProperty("nFdnVer")
	private int nFdnVer;
	
	@JsonProperty("vStatusCd")
	private String vStatusCd;
	
	@JsonProperty("vStatusNm")
	private String vStatusNm;
	
	@JsonProperty("vApprCd")
	private String vApprCd;
	
	@JsonProperty("vDecideContNm")
	private String vDecideContNm;
	
	@JsonProperty("vRegUserid")
	private String vRegUserid;
	
	@JsonProperty("vRegUsernm")
	private String vRegUsernm;
	
	@JsonProperty("vFlagDel")
	private String vFlagDel;
	
	@JsonProperty("vRegDtm")
	private String vRegDtm;
	
	@JsonProperty("vCompleteDtm")
	private String vCompleteDtm;
	
	@JsonProperty("vLotCdList")
	private String vLotCdList;
	
	@JsonProperty("vLotNmList")
	private String vLotNmList;
	
	@JsonProperty("vLotCd")
	private String vLotCd;
	
	@JsonProperty("nDecNameNum")
	private int nDecNameNum;
	
}
