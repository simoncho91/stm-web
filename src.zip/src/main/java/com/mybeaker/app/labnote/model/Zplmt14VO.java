package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Zplmt14VO {

	@JsonProperty("matnr")
	private String matnr;
	
	@JsonProperty("werks")
	private String werks;
	
	@JsonProperty("zversion")
	private String zversion;
	
	@JsonProperty("psnameNa")
	private String psnameNa;
	
	@JsonProperty("psnameK")
	private String psnameK;
	
	@JsonProperty("zlvorm")
	private String zlvorm;  
	
	@JsonProperty("zchange")
	private String zchange;    
	
	@JsonProperty("datuv")
	private String datuv;      
	
	@JsonProperty("erdat")
	private String erdat;      
	
	@JsonProperty("ernam")
	private String ernam;      
	
	@JsonProperty("arjart")
	private String arjart;     
	
	@JsonProperty("land1")
	private String land1;      
	
	@JsonProperty("lotCd")
	private String lotCd;      
	
	@JsonProperty("flag")
	private String flag;   
	
	@JsonProperty("approvalNote")
	private String approvalNote;
	
	@JsonProperty("ztext")
	private String ztext; 
	
	@JsonProperty("ztextEn")
	private String ztextEn; 
	
	@JsonProperty("ztextCn")
	private String ztextCn; 
	
	@JsonProperty("ztextKcp")
	private String ztextKcp;
	
	@JsonProperty("ztextEcp")
	private String ztextEcp;
	
	@JsonProperty("displayLt")
	private String displayLt;  
	
	@JsonProperty("warningLt")
	private String warningLt;  
	
	@JsonProperty("warningLtEn")
	private String warningLtEn;
	
	@JsonProperty("warningLtZh")
	private String warningLtZh;
}
