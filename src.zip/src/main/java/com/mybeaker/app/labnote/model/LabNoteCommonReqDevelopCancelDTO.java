package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LabNoteCommonReqDevelopCancelDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vRecordid")
	private String vRecordid;

	@JsonProperty("vMessage")
	private String vMessage;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vNotePageType")
	@Builder.Default
	private String vNotePageType = "prd";
}
