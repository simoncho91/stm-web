package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class InsertSupTrPrdInfoDTO {

	@JsonProperty("vProductCd")
	private String vProductCd;
	
	@JsonProperty("nVersion")
	private int nVersion;
	
	@JsonProperty("vProductNm")
	private String vProductNm;
	
	@JsonProperty("vProductEngNm")
	private String vProductEngNm;
	
	@JsonProperty("vStatusCd")
	private String vStatusCd;
	
	@JsonProperty("vObjTypeCd")
	private String vObjTypeCd;
	
	@JsonProperty("vSapCd")
	private String vSapCd;
	
	@JsonProperty("vDocNo")
	private String vDocNo;
	
	@JsonProperty("vUserId")
	private String vUserId;
	
	@JsonProperty("vDeptCd")
	private String vDeptCd;
	
	@JsonProperty("vDeptTempNm")
	private String vDeptTempNm;
	
	@JsonProperty("vAmoreProdYn")
	private String vAmoreProdYn;
	
	@JsonProperty("vMakerNm")
	private String vMakerNm;
	
	@JsonProperty("vLot")
	private String vLot;
	
	@JsonProperty("vPh")
	private String vPh;
	
	@JsonProperty("vTypeCd")
	private String vTypeCd;
	
	@JsonProperty("vDosageFormCd")
	private String vDosageFormCd;
	
	@JsonProperty("vFeature")
	private String vFeature;
	
	@JsonProperty("vCompareSampleNm")
	private String vCompareSampleNm;
	
	@JsonProperty("vPrddayDt")
	private String vPrddayDt;
	
	@JsonProperty("vStdayDt")
	private String vStdayDt;
	
	@JsonProperty("vLabCd")
	private String vLabCd;
	
	@JsonProperty("vCont1Cd")
	private String vCont1Cd;
	
	@JsonProperty("vCont2Cd")
	private String vCont2Cd;
	
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("vLotCd")
	private String vLotCd;
	
	@JsonProperty("vTypeCd2")
	private String vTypeCd2;
	
	@JsonProperty("vPartCd")
	private String vPartCd;
	
	@JsonProperty("nLabNoteVer")
	private int nLabNoteVer;
	
	@JsonProperty("vRpmsCd")
	private String vRpmsCd;
	
	@JsonProperty("vInnerPlant")
	private String vInnerPlant;
	
	@JsonProperty("vOrijinProductCd")
	private String vOrijinProductCd;
	
	@JsonProperty("vTag")
	private String vTag;
	
	@JsonProperty("vBrdCd")
	private String vBrdCd;
	
	@JsonProperty("vPilotDt")
	private String vPilotDt;
	
	@JsonProperty("vMeetingDt")
	private String vMeetingDt;
	
	@JsonProperty("vWerks")
	private String vWerks;
	
	@JsonProperty("vKosmetikCd")
	private String vKosmetikCd;
	
	@JsonProperty("vKosmetikTxt")
	private String vKosmetikTxt;
	
	@JsonProperty("vFlagReleaseAsia")
	private String vFlagReleaseAsia;
	
	@JsonProperty("vFlagReleaseAsean")
	private String vFlagReleaseAsean;
	
	@JsonProperty("vFlagReleaseEtc")
	private String vFlagReleaseEtc;
	
	@JsonProperty("nLineContCnt")
	private int nLineContCnt;
	
}
