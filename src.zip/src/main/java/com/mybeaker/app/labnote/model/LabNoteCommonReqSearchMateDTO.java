package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentPagingDTO;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@NoArgsConstructor(access = AccessLevel.PRIVATE)
@EqualsAndHashCode(callSuper = true)
public class LabNoteCommonReqSearchMateDTO extends ParentPagingDTO {
	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vLand1")
	@Builder.Default
	private String vLand1 = "UN";

	@JsonProperty("vLabNoteCd")
	@Builder.Default
	private String vLabNoteCd = "";

	@JsonProperty("vNoteType")
	private String vNoteType;

	@JsonProperty("vKeyword")
	private String vKeyword;

	@JsonProperty("vSiteType")
	@Builder.Default
	private String vSiteType = "";

	@JsonProperty("vFlagAutoComplete")
	@Builder.Default
	private String vFlagAutoComplete = "N";

	private String vUserid;

	private String localLanguage;

	// [s] 원료배합 paste 기능 추가
	private String arrKeyword;

	private List<String> keywordList;
	// [e] 원료배합 paste 기능 추가
}
