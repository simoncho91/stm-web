package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentPagingDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper = true)
public class LabNoteProcessFuncReportResDTO extends ParentPagingDTO{

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("nVersion")
	private int nVersion;
	
	@JsonProperty("nSeqno")
	private int nSeqno;
	
	@JsonProperty("nNum")
	private int nNum;
	
	@JsonProperty("vTitle")
	private String vTitle;
	
	@JsonProperty("vSenderId")
	private String vSenderId;
	
	@JsonProperty("vRecordid")
	private String vRecordid;
	
	@JsonProperty("vRequestDtm")
	private String vRequestDtm;
	
	@JsonProperty("vApprCd")
	private String vApprCd;
	
	@JsonProperty("vApprStatus")
	private String vApprStatus;
	
	@JsonProperty("vTag")
	private String vTag;
	
	@JsonProperty("vFlagNew")
	private String vFlagNew;
	
	@JsonProperty("vReportDtm")
	private String vReportDtm;
	
	@JsonProperty("vSenderUserNm")
	private String vSenderUserNm;
	
	@JsonProperty("vQaUserNm")
	private String vQaUserNm;
	
	@JsonProperty("vRefTypeCd")
	private String vRefTypeCd;
	
	@JsonProperty("vApprStatusNm")
	private String vApprStatusNm;
	
	@JsonProperty("vRefTypeNm")
	private String vRefTypeNm;
	
	@JsonProperty("vVersionTxt")
	private String vVersionTxt;
	
}
