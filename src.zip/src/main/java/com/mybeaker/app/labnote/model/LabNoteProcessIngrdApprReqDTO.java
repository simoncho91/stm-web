package com.mybeaker.app.labnote.model;

import java.util.List;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.makeup.model.MuSapBomMayContainConVO;
import com.mybeaker.app.model.dto.ParentPagingDTO;
import com.mybeaker.app.qdrug.model.QdrugNoteIngrMstVO;
import com.mybeaker.app.qdrug.model.QdrugNoteIngrSubVO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper = true)
public class LabNoteProcessIngrdApprReqDTO extends ParentPagingDTO{

	@JsonProperty("vKeyword")
	private String vKeyword;
	
	private String localLanguage;
	
	@NotEmpty
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("vEffectStDT")
	private String vEffectStDT;
	
	@JsonProperty("vEffectEdDT")
	private String vEffectEdDT;
	
	@JsonProperty("vUserId")
	private String vUserId;
	
	@JsonProperty("vContPkCd")
	private String vContPkCd;
	
	@JsonProperty("vLand")
	private String vLand;
	
	@JsonProperty("vLeaveType")
	private String vLeaveType;
	
	@JsonProperty("vMatnr")
	private String vMatnr;
	
	@JsonProperty("vWerks")
	private String vWerks;
	
	@JsonProperty("vZversion")
	private String vZversion;
	
	@JsonProperty("nMaxZversion")
	private int nMaxZversion;

	// TI01 => 화장품 전성분 목록
	// TI02 => 의약외품 전성분 목록
	@JsonProperty("vTabIngr")
	@Builder.Default
	private String vTabIngr = "TI02";
	
	//     Y 	 => (국내) 의약외품 전성분 등록
	// null or N => (수출) 화장품 전성분 등록
	@JsonProperty("vFlagSAIngr")
	private String vFlagSAIngr;
	
	// TI_INGR => Raw Data
	// TI_RAW  => 전성분승인
	@JsonProperty("vTabIngrReg")
	@Builder.Default
	private String vTabIngrReg = "TI_INGR";
	
	@JsonProperty("vFlagIngr")
	private String vFlagIngr;
	
	@JsonProperty("vIngrStatusCd")
	private String vIngrStatusCd;
	
	@JsonProperty("ingrMstVo")
	private QdrugNoteIngrMstVO ingrMstVo;
	
	@JsonProperty("ingrSubList")
	private List<QdrugNoteIngrSubVO> ingrSubList;
	
	@JsonProperty("vNoteStatusCd")
	private String vNoteStatusCd;
	
	@JsonProperty("vFlagTempReg")
	private String vFlagTempReg;
	
	@JsonProperty("vFlagUpdateYn")
	private String vFlagUpdateYn;
	
	@JsonProperty("mcList")
	private List<MuSapBomMayContainConVO> mcList;
}
