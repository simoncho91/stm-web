package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class PilotRequestDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vLabNoteType")
	private String vLabNoteType;

	@JsonProperty("vStatusCd")
	private String vStatusCd;

	@JsonProperty("vDeptCd")
	private String vDeptCd;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vUsernm")
	private String vUsernm;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vVersionNm")
	private String vVersionNm;

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("vLotNm")
	private String vLotNm;

	@JsonProperty("nPilotTestSeqno")
	private String nPilotTestSeqno;

	@JsonProperty("vEffectDtm")
	private String vEffectDtm;

	@JsonProperty("vApprCd")
	private String vApprCd;

	@JsonProperty("vRegDtm")
	private String vRegDtm;

	@JsonProperty("vStatusNm")
	private String vStatusNm;

	@JsonProperty("vSapStatusnm")
	private String vSapStatusnm;

	@JsonProperty("vSapType")
	private String vSapType;

	@JsonProperty("vSapMessage")
	private String vSapMessage;

	@JsonProperty("vFlagApprBom")
	private String vFlagApprBom;

	@JsonProperty("vLabTypeNm")
	private String vLabTypeNm;

	@JsonProperty("vPlantNm")
	private String vPlantNm;

	@JsonProperty("vPlantMstCd")
	private String vPlantMstCd;

	@JsonProperty("vFlagRepresent")
	private String vFlagRepresent;

	@JsonProperty("vFlagDecide")
	private String vFlagDecide;

	@JsonProperty("vCodeType")
	private String vCodeType;

	@JsonProperty("vDeptNm")
	private String vDeptNm;

	@JsonProperty("vBrdNm")
	private String vBrdNm;

	@JsonProperty("vVersionTxt")
	private String vVersionTxt;
	
	@JsonProperty("vVersionKey")
	private String vVersionKey;

	@JsonProperty("nRowCnt")
	private int nRowCnt;

	@JsonProperty("nSort")
	private int nSort;

	@JsonProperty("vPilotTestSeqnoNm")
	private String vPilotTestSeqnoNm;

	@JsonProperty("vPqcResCd")
	private String vPqcResCd;

	@JsonProperty("vG1PqcResCd")
	private String vG1PqcResCd;

	@JsonProperty("vApprStatus")
	private String vApprStatus;

	@JsonProperty("vApprStatusnm")
	private String vApprStatusnm;

	@JsonProperty("nSendSeq")
	private int nSendSeq;
}
