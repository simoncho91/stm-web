package com.mybeaker.app.labnote.model;

import java.util.List;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class MusoguReqDTO {

	@NotEmpty
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@NotEmpty
	@JsonProperty("vLotCd")
	private String vLotCd;
	
	@JsonProperty("vLand1")
	private String vLand1;
	
	@JsonProperty("vCodeType")
	private String vCodeType;
	
	@JsonProperty("vPlantCd")
	private String vPlantCd;
	
	@JsonProperty("vContPkCd")
	private String vContPkCd;
	
	@JsonProperty("vTempTag1Cd")
	private String vTempTag1Cd;
	
	@JsonProperty("vGetListType")
	private String vGetListType;
	
	@JsonProperty("vMstCode")
	private String vMstCode;
	
	@JsonProperty("vProdType1Cd")
	private String vProdType1Cd;

	@JsonProperty("vProdType2Cd")
	private String vProdType2Cd;
	
	private List<String> contList;
	
	private String language;
	
	@JsonProperty("vBuffer1")
	private String vBuffer1;
	
	@JsonProperty("vBuffer2")
	private String vBuffer2;
	
	@JsonProperty("vBuffer3")
	private String vBuffer3;
	
	@JsonProperty("vBuffer1SearchType")
	private String vBuffer1SearchType;
	
	@JsonProperty("vBuffer2SearchType")
	private String vBuffer2SearchType;
	
	@JsonProperty("vBuffer3SearchType")
	private String vBuffer3SearchType;
}
