package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@EqualsAndHashCode(callSuper=false)
@Data
public class ElabShelflifeContVO extends ParentDTO {
	@JsonProperty("vLogCd")
	private String vLogCd;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vFlag")
	private String vFlag;

	@JsonProperty("vStatusCd")
	private String vStatusCd;

	@JsonProperty("vShelfLife")
	private String vShelfLife;

	@JsonProperty("vEtcLife")
	private String vEtcLife;

	@JsonProperty("vNoteType")
	private String vNoteType;

	@JsonProperty("vContType")
	private String vContType;

	@JsonProperty("vFlagDel")
	private String vFlagDel;

	@Builder
	public ElabShelflifeContVO(String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm,
			String vLogCd, String vContCd, String vPlantCd, String vFlag, String vStatusCd, String vShelfLife,
			String vEtcLife, String vNoteType, String vContType, String vFlagDel) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.vLogCd = vLogCd;
		this.vContCd = vContCd;
		this.vPlantCd = vPlantCd;
		this.vFlag = vFlag;
		this.vStatusCd = vStatusCd;
		this.vShelfLife = vShelfLife;
		this.vEtcLife = vEtcLife;
		this.vNoteType = vNoteType;
		this.vContType = vContType;
		this.vFlagDel = vFlagDel;
	}
}
