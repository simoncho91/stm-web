package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class SupGlobalMailUserVO {

	@JsonProperty("vGlobalCd")
	private String vGlobalCd;

	@JsonProperty("vProductCd")
	private String vProductCd;

	@JsonProperty("vProductNm")
	private String vProductNm;

	@JsonProperty("vProductNmEn")
	private String vProductNmEn;

	@JsonProperty("vCountryFlag")
	private String vCountryFlag;

	@JsonProperty("vShelfLife")
	private String vShelfLife;

	@JsonProperty("vUserType")
	private String vUserType;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vUsernm")
	private String vUsernm;

	@JsonProperty("vEmail")
	private String vEmail;
	
}
