package com.mybeaker.app.labnote.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.mybeaker.app.labnote.mapper.LabNoteSAPInterfaceMapper;
import com.mybeaker.app.labnote.model.BomAllerenListVO;
import com.mybeaker.app.labnote.model.BomAllergenVO;
import com.mybeaker.app.labnote.model.BomInfoVO;
import com.mybeaker.app.labnote.model.BomListVO;
import com.mybeaker.app.labnote.model.ElabShelflifeContVO;
import com.mybeaker.app.labnote.model.Mat3VO;
import com.mybeaker.app.labnote.model.SapCallLogMdi0005VO;
import com.mybeaker.app.labnote.model.SapCallLogMdi0010VO;
import com.mybeaker.app.labnote.model.SapCallLogVO;
import com.mybeaker.app.labnote.model.TmpZplmt13ContentInfoVO;
import com.mybeaker.app.labnote.model.Zplms0332ListVO;
import com.mybeaker.app.labnote.model.Zplms0332VO;
import com.mybeaker.app.labnote.model.Zplmt74VO;
import com.mybeaker.app.model.Const;
import com.mybeaker.app.utils.CommonUtil;
import com.wm.app.b2b.client.Context;
import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataFactory;
import com.wm.data.IDataUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Service
public class LabNoteSAPInterfaceService {

	@Value("${sap.sap-server}")
	private String SAP_SERVER;
	
	@Value("${sap.sap-server-5570}")
	private String SAP_SERVER_5570;
	
	@Value("${sap.sap-user}")
	private String SAP_USER;
	
	@Value("${sap.sap-password}")
	private String SAP_PASSWORD;
	
	@Value("${spring.profiles.active}")
	private String ACTIVE;
	
	private final LabNoteSAPInterfaceMapper labNoteSAPInterfaceMapper;
	
	// 문서명		/	서비스폴더명								/	서비스명					/	기존서비스명				/	테이블명		/	시스템명
	// PPI2037	/	AP_PP_02.ZPP_PORTAL_BOM_EXPLOSION_MAT4	/	svcPPI2037_TIUMNET_SAP	/	svcPPI1709_TIUMNET_SAP	/	T_ZPLMS014	/	마이비커
	// PPI2036	/	AP_PP_02.ZPP_PORTAL_BOM_EXPLOSION_MAT3	/	svcPPI2036_TIUMNET_SAP	/	svcPPI0066_TIUMNET_SAP	/	T_ZPLMS013	/	마이비커
	
	// QMI0080	/	AP_QM_01.Z_PORTAL_BOM_EXPLOSION_MAT5	/	svcQMI0080_TIUMNET_SAP	/							/				/	티움넷
	// QMI1706	/	AP_QM_02.ZPLM_CHEMT_CONCDDATA_SEND_TDD	/	svcQMI1706_TIUMNET_SAP	/							/				/	티움넷
	// QMI6017	/	AP_QM_02.ZPLM_IF_EXP_ZPLMT74			/	svcQMI6017_TIUMNET_SAP	/							/				/	티움넷
	
	// MDI0005	/	AP_MD_01.ZMD_MHDHB_RECEIVE				/	svcMDI0005_TIUMNET_SAP	/							/				/	티움넷
	// MDI0010	/	AP_MD_01.ZMD_GET_MHDHB_INFO				/	svcMDI0010_TIUMNET_SAP	/							/				/	티움넷
	
	public List<BomInfoVO> getT_ZPLMS014(String werks, String contentCd) {
		Context context = null;
		
		List<BomInfoVO> bomList = null;
		SapCallLogVO logVo = new SapCallLogVO();
		BomInfoVO BomInfo = null;
		
		IData input = null;
		IDataCursor inputCursor = null;
		IData REQUEST = null;
		IDataCursor REQUESTCursor = null;
		IData HEADER = null;
		IDataCursor HEADERCursor = null;
		IData INPUT = null;
		IDataCursor INPUTCursor = null;
		IData[] T_ZPLMS015 = null;
		IDataCursor T_ZPLMS015Cursor = null;
		IData output = null;
		IDataCursor outputCursor = null;
		IData RESPONSE = null;
		IDataCursor RESPONSECursor = null;
		IData HEADER_1 = null;
		IDataCursor HEADER_1Cursor = null;
		IData OUTPUT = null;
		IDataCursor OUTPUTCursor = null;
		IData[] T_ZPLMS016 = null;
		IDataCursor T_ZPLMS016Cursor = null;
		
		try {
			context = this.setSAPConnection();
			
			// input
			input = IDataFactory.create();
			inputCursor = input.getCursor();
			
			// REQUEST
			REQUEST = IDataFactory.create();
			REQUESTCursor = REQUEST.getCursor();
			
			// REQUEST.HEADER
			HEADER = IDataFactory.create();
			HEADERCursor = HEADER.getCursor();
			
			// 시스템 코드
			IDataUtil.put( HEADERCursor, "SOURCE", "L1050");
			HEADERCursor.destroy();
			IDataUtil.put( REQUESTCursor, "HEADER", HEADER);
			
			// REQUEST.INPUT
			INPUT = IDataFactory.create();
			INPUTCursor = INPUT.getCursor();
			
			// REQUEST.INPUT.T_ZPLMS015
			T_ZPLMS015 = new IData[1];
			T_ZPLMS015[0] = IDataFactory.create();
			T_ZPLMS015Cursor = T_ZPLMS015[0].getCursor();
			// 운영서버에서 검색되는 플랜트와 제품코드값입니다.
			
			IDataUtil.put( T_ZPLMS015Cursor, "WERKS", werks);
			IDataUtil.put( T_ZPLMS015Cursor, "MATNR", contentCd);
			
			T_ZPLMS015Cursor.destroy();
			IDataUtil.put(INPUTCursor, "T_ZPLMS015", T_ZPLMS015);
			INPUTCursor.destroy();
			IDataUtil.put(REQUESTCursor, "INPUT", INPUT);
			REQUESTCursor.destroy();
			IDataUtil.put(inputCursor, "REQUEST", REQUEST);
			inputCursor.destroy();
			
			// output
			output = IDataFactory.create();
			
			try{
				output = context.invoke("AP_PP_02.ZPP_PORTAL_BOM_EXPLOSION_MAT4", "svcPPI1709_TIUMNET_SAP", input);
			}catch( Exception e){
				log.error("getT_ZPLMS014 - AP_PP_02.ZPP_PORTAL_BOM_EXPLOSION_MAT4 Error ", e);
			}
			
			outputCursor = output.getCursor();
			
			// RESPONSE
			RESPONSE = IDataUtil.getIData( outputCursor, "RESPONSE");
			if (RESPONSE != null)
			{
				logVo.setVServiceCd("ZPP_PORTAL_BOM_EXPLOSION_MAT4");
				
				logVo.setVWerks(werks);
				logVo.setVContentCd(contentCd);
				
				RESPONSECursor = RESPONSE.getCursor();
				
				// i.HEADER
				HEADER_1 = IDataUtil.getIData(RESPONSECursor, "HEADER");
				if (HEADER_1 != null)
				{
					HEADER_1Cursor = HEADER_1.getCursor();
					String IF_ID = IDataUtil.getString(HEADER_1Cursor, "IF_ID");
					String RTN_TYPE = IDataUtil.getString(HEADER_1Cursor, "RTN_TYPE");
					String RTN_MSG = IDataUtil.getString(HEADER_1Cursor, "RTN_MSG");
					HEADER_1Cursor.destroy();
					
					logVo.setVIfId(IF_ID);
					logVo.setVRtnType(RTN_TYPE);
					logVo.setVRtnMsg(RTN_MSG);
				}
				
				// i.OUTPUT
				OUTPUT = IDataUtil.getIData(RESPONSECursor, "OUTPUT");
				if (OUTPUT != null)
				{
					OUTPUTCursor = OUTPUT.getCursor();
					String O_MESSAGE = IDataUtil.getString(OUTPUTCursor, "O_MESSAGE");
					String O_RESULT = IDataUtil.getString(OUTPUTCursor, "O_RESULT");
					
					logVo.setVMessage(O_MESSAGE);
					logVo.setVResult(O_RESULT);
					
					// i.T_ZPLMS016
					T_ZPLMS016 = IDataUtil.getIDataArray(OUTPUTCursor, "T_ZPLMS016");
					if (T_ZPLMS016 != null)
					{
						bomList = new ArrayList<>();
						for (int i = 0; i < T_ZPLMS016.length; i++)
						{
							T_ZPLMS016Cursor = T_ZPLMS016[i].getCursor();
							
							BomInfo = new BomInfoVO();
							BomInfo.setWerks(IDataUtil.getString(T_ZPLMS016Cursor, "WERKS"));
							BomInfo.setContentsCd(this.removeLeftZero(IDataUtil.getString(T_ZPLMS016Cursor, "CONTENTS_CD")));
							BomInfo.setContentsNmKo(IDataUtil.getString(T_ZPLMS016Cursor, "CONTENTS_NM_KO"));
							BomInfo.setContentsNmEn(IDataUtil.getString(T_ZPLMS016Cursor, "CONTENTS_NM_EN"));
							BomInfo.setContentsPer(IDataUtil.getString(T_ZPLMS016Cursor, "CONTENTS_PER"));
							BomInfo.setRawCd(this.removeLeftZero(IDataUtil.getString(T_ZPLMS016Cursor, "RAW_CD")));
							BomInfo.setRawNm(IDataUtil.getString(T_ZPLMS016Cursor, "RAW_NM"));
							BomInfo.setRawPer(IDataUtil.getString(T_ZPLMS016Cursor, "RAW_PER"));
							
							bomList.add(BomInfo);
							
							T_ZPLMS016Cursor.destroy();
						}
					}
					OUTPUTCursor.destroy();
				}
				RESPONSECursor.destroy();
			}
			outputCursor.destroy();
		} catch (Exception e) {
		} finally{
			// 연결해제
			this.SAPDisconnection(context);
			
			// 로그 기록
			this.insertSapCallLog(logVo);
			
			// 메모리 누수 방지
			logVo = null;
			BomInfo = null;
			
			input = null;
			inputCursor = null;
			REQUEST = null;
			REQUESTCursor = null;
			HEADER = null;
			HEADERCursor = null;
			INPUT = null;
			INPUTCursor = null;
			T_ZPLMS015 = null;
			T_ZPLMS015Cursor = null;
			output = null;
			outputCursor = null;
			RESPONSE = null;
			RESPONSECursor = null;
			HEADER_1 = null;
			HEADER_1Cursor = null;
			OUTPUT = null;
			OUTPUTCursor = null;
			T_ZPLMS016 = null;
			T_ZPLMS016Cursor = null;
		}
		
		return bomList;
	}
	
	public List<BomInfoVO> getT_ZPLMS013(String werks, String contentCd) {
		return this.getT_ZPLMS013(werks, contentCd, "KR", null);
	}
	
	public List<BomInfoVO> getT_ZPLMS013(String werks, String contentCd, String land) {
		return this.getT_ZPLMS013(werks, contentCd, land, null);
	}
	
	public List<BomInfoVO> getT_ZPLMS013(String werks, String contentCd, String land, Context context) {
		List<BomInfoVO> bomList = null;
		SapCallLogVO logVo = new SapCallLogVO();
		String flagContinueContext = "";
		
		try {
			if(context == null){
				context = this.setSAPConnection();
			}else{
				flagContinueContext = "Y";
			}
			
			// input
			IData input = IDataFactory.create();
			IDataCursor inputCursor = input.getCursor();
			
			// REQUEST
			IData	REQUEST = IDataFactory.create();
			IDataCursor REQUESTCursor = REQUEST.getCursor();
			
			// REQUEST.HEADER
			IData	HEADER = IDataFactory.create();
			IDataCursor HEADERCursor = HEADER.getCursor();
			// 시스템 코드
			IDataUtil.put( HEADERCursor, "SOURCE", "L1050" );
			HEADERCursor.destroy();
			IDataUtil.put( REQUESTCursor, "HEADER", HEADER );
			
			// REQUEST.INPUT
			IData	INPUT = IDataFactory.create();
			IDataCursor INPUTCursor = INPUT.getCursor();
			// 아래 4개의 코드의 의미를 모르겠습니다.
			//IDataUtil.put( INPUTCursor, "PI_CAPID", "" );
			//IDataUtil.put( INPUTCursor, "PI_MEHRS", "" );
			//IDataUtil.put( INPUTCursor, "PI_STLAL", "" );
			//IDataUtil.put( INPUTCursor, "PI_STLAN", "" );
			
			// REQUEST.INPUT.T_ZPLMS009
			IData[]	T_ZPLMS009 = new IData[1];
			T_ZPLMS009[0] = IDataFactory.create();
			IDataCursor T_ZPLMS009Cursor = T_ZPLMS009[0].getCursor();
			// 운영서버에서 검색되는 플랜트와 제품코드값입니다.
			
			IDataUtil.put( T_ZPLMS009Cursor, "WERKS", werks);
			IDataUtil.put( T_ZPLMS009Cursor, "MATNR", contentCd);
			IDataUtil.put( T_ZPLMS009Cursor, "LAND", land);
			//IDataUtil.put( T_ZPLMS009Cursor, "DATUV", toDay);
			
			T_ZPLMS009Cursor.destroy();
			IDataUtil.put( INPUTCursor, "T_ZPLMS009", T_ZPLMS009 );
			INPUTCursor.destroy();
			IDataUtil.put( REQUESTCursor, "INPUT", INPUT );
			REQUESTCursor.destroy();
			IDataUtil.put( inputCursor, "REQUEST", REQUEST );
			inputCursor.destroy();
			
			// output
			IData 	output = IDataFactory.create();
			
			try{
				output = context.invoke("AP_PP_02.ZPP_PORTAL_BOM_EXPLOSION_MAT3", "svcPPI0066_TIUMNET_SAP", input);
			}catch( Exception e){
				log.error("getT_ZPLMS013 - AP_PP_02.ZPP_PORTAL_BOM_EXPLOSION_MAT3 Error ", e);
			}
			
			IDataCursor outputCursor = output.getCursor();
			
			// RESPONSE
			IData	RESPONSE = IDataUtil.getIData( outputCursor, "RESPONSE" );
			if ( RESPONSE != null)
			{
				
				logVo.setVServiceCd("ZPP_PORTAL_BOM_EXPLOSION_MAT3");
				
				logVo.setVWerks(werks);
				logVo.setVContentCd(contentCd);
				logVo.setVLand(land);
				
				IDataCursor RESPONSECursor = RESPONSE.getCursor();
				
				// i.HEADER
				IData	HEADER_1 = IDataUtil.getIData( RESPONSECursor, "HEADER" );
				if ( HEADER_1 != null)
				{
					IDataCursor HEADER_1Cursor = HEADER_1.getCursor();
						String	IF_ID = IDataUtil.getString( HEADER_1Cursor, "IF_ID" );
						String	RTN_TYPE = IDataUtil.getString( HEADER_1Cursor, "RTN_TYPE" );
						String	RTN_MSG = IDataUtil.getString( HEADER_1Cursor, "RTN_MSG" );
					HEADER_1Cursor.destroy();
					
					logVo.setVIfId(IF_ID);
					logVo.setVRtnType(RTN_TYPE);
					logVo.setVRtnMsg(RTN_MSG);
				}
				
				// i.OUTPUT
				IData	OUTPUT = IDataUtil.getIData( RESPONSECursor, "OUTPUT" );
				if ( OUTPUT != null)
				{
					IDataCursor OUTPUTCursor = OUTPUT.getCursor();
					String	O_MESSAGE = IDataUtil.getString( OUTPUTCursor, "O_MESSAGE" );
					String	O_RESULT = IDataUtil.getString( OUTPUTCursor, "O_RESULT" );
					
					logVo.setVMessage(O_MESSAGE);
					logVo.setVResult(O_RESULT);
					
					// i.T_ZPLMS013
					IData[]	T_ZPLMS013 = IDataUtil.getIDataArray( OUTPUTCursor, "T_ZPLMS013" );
					if ( T_ZPLMS013 != null)
					{
						bomList = new ArrayList<>();
						BomInfoVO BomInfo = null;
						for ( int i = 0; i < T_ZPLMS013.length; i++ )
						{
							IDataCursor T_ZPLMS013Cursor = T_ZPLMS013[i].getCursor();
							
							BomInfo	=	new BomInfoVO();
							
							BomInfo.setWerks(IDataUtil.getString(T_ZPLMS013Cursor, "WERKS"));
							BomInfo.setContentsCd(this.removeLeftZero(IDataUtil.getString(T_ZPLMS013Cursor, "CONTENTS_CD")));
							BomInfo.setContentsNmKo(IDataUtil.getString(T_ZPLMS013Cursor, "CONTENTS_NM_KO"));
							BomInfo.setContentsNmEn(IDataUtil.getString(T_ZPLMS013Cursor, "CONTENTS_NM_EN"));
							BomInfo.setContentsPer(IDataUtil.getString(T_ZPLMS013Cursor, "CONTENTS_PER"));
							BomInfo.setHal4Cd(this.removeLeftZero(IDataUtil.getString(T_ZPLMS013Cursor, "HAL4_CD")));
							BomInfo.setHal4Nm(IDataUtil.getString(T_ZPLMS013Cursor, "HAL4_NM"));
							BomInfo.setHal4Per(IDataUtil.getString(T_ZPLMS013Cursor, "HAL4_PER"));
							BomInfo.setRawCd(this.removeLeftZero(IDataUtil.getString(T_ZPLMS013Cursor, "RAW_CD")));
							BomInfo.setRawNm(IDataUtil.getString(T_ZPLMS013Cursor, "RAW_NM"));
							BomInfo.setRawPer(IDataUtil.getString(T_ZPLMS013Cursor, "RAW_PER"));
							BomInfo.setConcd(IDataUtil.getString(T_ZPLMS013Cursor, "CONCD"));
							BomInfo.setConPer(IDataUtil.getString(T_ZPLMS013Cursor, "CON_PER"));
							BomInfo.setConInPer(IDataUtil.getString(T_ZPLMS013Cursor, "CON_IN_PER"));
							BomInfo.setConnameKo(IDataUtil.getString(T_ZPLMS013Cursor, "CONNAME_KO"));
							BomInfo.setConnameEn(IDataUtil.getString(T_ZPLMS013Cursor, "CONNAME_EN"));
							BomInfo.setConnameCn(IDataUtil.getString(T_ZPLMS013Cursor, "CONNAME_CN"));
							BomInfo.setConnameJa(IDataUtil.getString(T_ZPLMS013Cursor, "CONNAME_JA"));
							BomInfo.setFcnameKo(IDataUtil.getString(T_ZPLMS013Cursor, "FCNAME_KO"));
							BomInfo.setFcnameEn(IDataUtil.getString(T_ZPLMS013Cursor, "FCNAME_EN"));
							BomInfo.setCasno(IDataUtil.getString(T_ZPLMS013Cursor, "CASNO"));
							BomInfo.setMixre(IDataUtil.getString(T_ZPLMS013Cursor, "MIXRE"));
							BomInfo.setZglobal(IDataUtil.getString(T_ZPLMS013Cursor, "ZGLOBAL"));
							BomInfo.setZgubcl(IDataUtil.getString(T_ZPLMS013Cursor, "ZGUBCL"));
							BomInfo.setZgllim(IDataUtil.getString(T_ZPLMS013Cursor, "ZGLLIM"));
							BomInfo.setZgrd1(IDataUtil.getString(T_ZPLMS013Cursor, "ZGRD_1"));
							BomInfo.setZgrd2(IDataUtil.getString(T_ZPLMS013Cursor, "ZGRD_2"));
							BomInfo.setAicsno(IDataUtil.getString(T_ZPLMS013Cursor, "AICSNO"));
							
							BomInfo.setFcnameKo(BomInfo.getFcnameKo().replaceAll("(외(\\s*)[0-9](\\s*)건)", "").trim());
							BomInfo.setFcnameEn(BomInfo.getFcnameEn().replaceAll("(외(\\s*)[0-9](\\s*)건)", "").trim());
							
							bomList.add(BomInfo);
							
							T_ZPLMS013Cursor.destroy();
						}
					}
					OUTPUTCursor.destroy();
				}
				RESPONSECursor.destroy();
			}
			outputCursor.destroy();
		} catch (Exception e) {
			log.error("Error : ", e);
		} finally{
			if(!"Y".equals(flagContinueContext)){
				this.SAPDisconnection(context);
			}
			
			// 로그 기록
			this.insertSapCallLog(logVo);
		}
		
		return bomList;
	}
	
	// 실험노트 전성분 호출
	public List<BomInfoVO> getT_ZPLMS013_BOM(String werks, String rawCd) {
		return getT_ZPLMS013_BOM(werks, rawCd, "KR");
	}
	
	// 실험노트 전성분 호출
	public List<BomInfoVO> getT_ZPLMS013_BOM(String werks, String rawCd, String land) {
		Context context = null;
		List<BomInfoVO> bomList = null;
		SapCallLogVO logVo = new SapCallLogVO();
		
		try {
			
			context	=	this.setSAPConnection();
			
			// input
			IData input = IDataFactory.create();
			IDataCursor inputCursor = input.getCursor();
			
			// REQUEST
			IData	REQUEST = IDataFactory.create();
			IDataCursor REQUESTCursor = REQUEST.getCursor();
			
			// REQUEST.HEADER
			IData	HEADER = IDataFactory.create();
			IDataCursor HEADERCursor = HEADER.getCursor();
			// 시스템 코드
			IDataUtil.put( HEADERCursor, "SOURCE", "L1050" );
			HEADERCursor.destroy();
			IDataUtil.put( REQUESTCursor, "HEADER", HEADER );
			
			// REQUEST.INPUT
			IData	INPUT = IDataFactory.create();
			IDataCursor INPUTCursor = INPUT.getCursor();
			// 아래 4개의 코드의 의미를 모르겠습니다.
			//IDataUtil.put( INPUTCursor, "PI_CAPID", "" );
			//IDataUtil.put( INPUTCursor, "PI_MEHRS", "" );
			//IDataUtil.put( INPUTCursor, "PI_STLAL", "" );
			//IDataUtil.put( INPUTCursor, "PI_STLAN", "" );
			
			// REQUEST.INPUT.T_ZPLMS009
			IData[]	T_ZPLMS009 = new IData[1];
			T_ZPLMS009[0] = IDataFactory.create();
			IDataCursor T_ZPLMS009Cursor = T_ZPLMS009[0].getCursor();
			// 운영서버에서 검색되는 플랜트와 제품코드값입니다.
			
			IDataUtil.put( T_ZPLMS009Cursor, "WERKS", werks);
			IDataUtil.put( T_ZPLMS009Cursor, "MATNR", rawCd);
			IDataUtil.put( T_ZPLMS009Cursor, "LAND", land);
			//IDataUtil.put( T_ZPLMS009Cursor, "DATUV", toDay);
			
			T_ZPLMS009Cursor.destroy();
			IDataUtil.put( INPUTCursor, "T_ZPLMS009", T_ZPLMS009 );
			INPUTCursor.destroy();
			IDataUtil.put( REQUESTCursor, "INPUT", INPUT );
			REQUESTCursor.destroy();
			IDataUtil.put( inputCursor, "REQUEST", REQUEST );
			inputCursor.destroy();
			
			// output
			IData 	output = IDataFactory.create();
			try{
				output = context.invoke("AP_PP_02.ZPP_PORTAL_BOM_EXPLOSION_MAT3", "svcPPI0066_TIUMNET_SAP", input);
			}catch( Exception e){
				log.error("getT_ZPLMS013_BOM - AP_PP_02.ZPP_PORTAL_BOM_EXPLOSION_MAT3 Error ", e);
			}
			
			IDataCursor outputCursor = output.getCursor();
			
			// RESPONSE
			IData	RESPONSE = IDataUtil.getIData( outputCursor, "RESPONSE" );
			if ( RESPONSE != null)
			{
				
				logVo.setVServiceCd("ZPP_PORTAL_BOM_EXPLOSION_MAT3");
				
				logVo.setVWerks(werks);
				logVo.setVRawCd(rawCd);
				
				IDataCursor RESPONSECursor = RESPONSE.getCursor();
				
				// i.HEADER
				IData	HEADER_1 = IDataUtil.getIData( RESPONSECursor, "HEADER" );
				if ( HEADER_1 != null)
				{
					IDataCursor HEADER_1Cursor = HEADER_1.getCursor();
						String	IF_ID = IDataUtil.getString( HEADER_1Cursor, "IF_ID" );
						String	RTN_TYPE = IDataUtil.getString( HEADER_1Cursor, "RTN_TYPE" );
						String	RTN_MSG = IDataUtil.getString( HEADER_1Cursor, "RTN_MSG" );
					HEADER_1Cursor.destroy();
					
					logVo.setVIfId(IF_ID);
					logVo.setVRtnType(RTN_TYPE);
					logVo.setVRtnMsg(RTN_MSG);
				}
				
				// i.OUTPUT
				IData	OUTPUT = IDataUtil.getIData( RESPONSECursor, "OUTPUT" );
				if ( OUTPUT != null)
				{
					IDataCursor OUTPUTCursor = OUTPUT.getCursor();
					String	O_MESSAGE = IDataUtil.getString( OUTPUTCursor, "O_MESSAGE" );
					String	O_RESULT = IDataUtil.getString( OUTPUTCursor, "O_RESULT" );
					
					logVo.setVMessage(O_MESSAGE);
					logVo.setVResult(O_RESULT);
					
					// i.T_ZPLMS013
					IData[]	T_ZPLMS013 = IDataUtil.getIDataArray( OUTPUTCursor, "T_ZPLMS013" );
					if ( T_ZPLMS013 != null)
					{
						bomList = new ArrayList<>();
						BomInfoVO BomInfo = null;
						for ( int i = 0; i < T_ZPLMS013.length; i++ )
						{
							IDataCursor T_ZPLMS013Cursor = T_ZPLMS013[i].getCursor();
							 
							BomInfo = new BomInfoVO();
							
							BomInfo.setHal4Cd(this.removeLeftZero(IDataUtil.getString(T_ZPLMS013Cursor, "HAL4_CD")));
							BomInfo.setRawCd(this.removeLeftZero(IDataUtil.getString(T_ZPLMS013Cursor, "RAW_CD")));
							BomInfo.setRawPer(CommonUtil.replace(IDataUtil.getString(T_ZPLMS013Cursor, "RAW_PER"), "'", ""));
							BomInfo.setRawNm(CommonUtil.replace(IDataUtil.getString(T_ZPLMS013Cursor, "RAW_NM"), "'", ""));
							BomInfo.setConcd(CommonUtil.replace(IDataUtil.getString(T_ZPLMS013Cursor, "CONCD"), "'", ""));
							BomInfo.setConPer(CommonUtil.replace(IDataUtil.getString(T_ZPLMS013Cursor, "CON_PER"), "'", ""));
							BomInfo.setConnameKo(CommonUtil.replace(IDataUtil.getString(T_ZPLMS013Cursor, "CONNAME_KO"), "'", ""));
							BomInfo.setConnameEn(CommonUtil.replace(IDataUtil.getString(T_ZPLMS013Cursor, "CONNAME_EN"), "'", ""));
							BomInfo.setConnameCn(CommonUtil.replace(IDataUtil.getString(T_ZPLMS013Cursor, "CONNAME_CN"), "'", ""));
							BomInfo.setFcnameKo(CommonUtil.replace(IDataUtil.getString(T_ZPLMS013Cursor, "FCNAME_KO"), "'", ""));
							BomInfo.setCasno(CommonUtil.replace(IDataUtil.getString(T_ZPLMS013Cursor, "CASNO"), "'", ""));
							BomInfo.setMixre(CommonUtil.replace(IDataUtil.getString(T_ZPLMS013Cursor, "MIXRE"), "'", ""));
							BomInfo.setZglobal(CommonUtil.replace(IDataUtil.getString(T_ZPLMS013Cursor, "ZGLOBAL"), "'", ""));
							BomInfo.setZgubcl(CommonUtil.replace(IDataUtil.getString(T_ZPLMS013Cursor, "ZGUBCL"), "'", ""));
							BomInfo.setZgllim(CommonUtil.replace(IDataUtil.getString(T_ZPLMS013Cursor, "ZGLLIM"), "'", ""));
							
							bomList.add(BomInfo);
							
							T_ZPLMS013Cursor.destroy();
						}
					}
					OUTPUTCursor.destroy();
				}
				RESPONSECursor.destroy();
			}
			outputCursor.destroy();
		} catch (Exception e) {
			log.error("Error : ", e);
		}finally{
			this.SAPDisconnection(context);
			
			// 로그 기록
			//this.insertSapCallLog(logVo);
		}
		
//		if(CmFunction.isEmpty(temp)){
//			result.put("flagNoData"	, "Y");
//		}
		
		return bomList;
	}
	
	// 실험노트 전성분 호출 신규 (향알러젠 포함)
	public BomAllerenListVO getT_ZPLMS013_BOM_NEW(String werks, String rawCd, String land) {
		List<BomAllergenVO> allergenList = new ArrayList<>();
		
		List<BomInfoVO> bomVo	= this.getT_ZPLMS013_BOM(werks, rawCd, land);
		
		List<Mat3VO> mateList = this.selectMat3List(BomListVO.builder()
				.bomList(bomVo)
				.build());
		int mateSize = mateList != null ? mateList.size() : 0;
		
		String mateCd = "";
		List<Zplmt74VO> zplmt74List = null;	
		int size =0;
		
		String sZplmt74MatCds = "";
		
		for(int i =0; i < mateSize; i++) {
			mateCd = mateList.get(i).getVMatCd();
			zplmt74List = this.getT_ZPLMT74(mateCd);
			
			size = zplmt74List.size();
			if(zplmt74List.size() > 0) {
				sZplmt74MatCds += mateCd + ",";
				
				for(int j=0; j < size; j++) {
//					allergenSql.append("	SELECT");
//					allergenSql.append("		'' AS HAL4_CD");
//					allergenSql.append("		, '").append(mateCd).append("' AS RAW_CD");
//					allergenSql.append("		, '").append(mateList.get(i).getString("n_mat_per")).append("' AS RAW_PER");
//					allergenSql.append("		, '").append(zplmt74List.get(j).getString("CONCD")).append("' AS CONCD");
//					allergenSql.append("		, '").append(zplmt74List.get(j).getString("IN_PER")).append("' AS CON_PER");
//					allergenSql.append("		, '").append(zplmt74List.get(j).getString("LVL")).append("' AS LVL");
//					allergenSql.append("		, '").append(zplmt74List.get(j).getString("CONCD_O")).append("' AS CONCD_O");
//					allergenSql.append("	FROM DUAL");
//					allergenSql.append("	UNION ALL");
					
					allergenList.add(BomAllergenVO.builder()
							.hal4Cd("")
							.rawCd(mateCd)
							.rawPer(mateList.get(i).getNMatPer())
							.concd(zplmt74List.get(i).getConcd())
							.conPer(zplmt74List.get(i).getInPer())
							.lvl(zplmt74List.get(i).getLvl())
							.concdO(zplmt74List.get(i).getConcdO())
							.build());
				}
			}
		}
				
		List<BomInfoVO>	bomList = this.getT_ZPLMS013(werks, rawCd, land);
		size = bomList != null ? bomList.size() : 0;
		
		for(int i =0; i < size; i++) {
			mateCd = bomList.get(i).getRawCd();
			String sAllergenYn = "";
			if(sZplmt74MatCds.indexOf(mateCd) <= -1) {
				
//				allergenSql.append("	SELECT");
//				allergenSql.append("		  '").append(bomList.get(i).getString("HAL4_CD")).append("' AS HAL4_CD");
//				allergenSql.append("		, '").append(mateCd).append("' AS RAW_CD");
//				allergenSql.append("		, '").append(bomList.get(i).getString("RAW_PER")).append("' AS RAW_PER");
//				allergenSql.append("		, '").append(bomList.get(i).getString("CONCD")).append("' AS CONCD");
//				allergenSql.append("		, '").append(bomList.get(i).getString("CON_PER")).append("' AS CON_PER");
//				allergenSql.append("		, '' AS LVL");
//				allergenSql.append("		, '' AS CONCD_O");
//				allergenSql.append("	FROM DUAL");
//				allergenSql.append("	UNION ALL");
				
				allergenList.add(BomAllergenVO.builder()
						.hal4Cd(bomList.get(i).getHal4Cd())
						.rawCd(mateCd)
						.rawPer(bomList.get(i).getRawPer())
						.concd(bomList.get(i).getConcd())
						.conPer(bomList.get(i).getConPer())
						.lvl("")
						.concdO("")
						.build());
				
				// 알러지착향료 여부를 배합규제 텍스트가 아닌, ZPLMT12의 V_ZARJCD로 체크하도록 변경
				sAllergenYn = labNoteSAPInterfaceMapper.selectAllergenYn(bomList.get(i).getConcd());
				
				if("Y".equals(sAllergenYn)){
//					allergenSql.append("	SELECT");
//					allergenSql.append("		  '' AS HAL4_CD");
//					allergenSql.append("		, '' AS RAW_CD");
//					allergenSql.append("		, '").append(bomList.get(i).getString("RAW_PER")).append("' AS RAW_PER");
//					allergenSql.append("		, '10093' AS CONCD");
//					allergenSql.append("		, '").append("-").append(bomList.get(i).getString("CON_PER")).append("' AS CON_PER");
//					allergenSql.append("		, '' AS LVL");
//					allergenSql.append("		, '' AS CONCD_O");
//					allergenSql.append("	FROM DUAL");
//					allergenSql.append("	UNION ALL");
					
					allergenList.add(BomAllergenVO.builder()
							.hal4Cd("")
							.rawCd("")
							.rawPer(bomList.get(i).getRawPer())
							.concd("10093")
							.conPer("-".concat(bomList.get(i).getConPer()))
							.lvl("")
							.concdO("")
							.build());
				}
			}
		}
		
//		allergenSql.append("	SELECT");
//		allergenSql.append("		  '' AS HAL4_CD");
//		allergenSql.append("		, '' AS RAW_CD");
//		allergenSql.append("		, '' AS RAW_PER");
//		allergenSql.append("		, '' AS CONCD");
//		allergenSql.append("		, '' AS CON_PER");
//		allergenSql.append("		, '' AS LVL");
//		allergenSql.append("		, '' AS CONCD_O");
//		allergenSql.append("	FROM DUAL");
		
		allergenList.add(BomAllergenVO.builder()
				.hal4Cd("")
				.rawCd("")
				.rawPer("")
				.concd("")
				.conPer("")
				.lvl("")
				.concdO("")
				.build());
		
		return BomAllerenListVO.builder()
				.noAllergenList(bomVo)
				.allergenList(allergenList)
				.build();
	}
	
	public List<BomInfoVO> getT_ZPLMS017(String rawCd) {
		return getT_ZPLMS017(rawCd, "KR", null);
	}
	
	public List<BomInfoVO> getT_ZPLMS017(String rawCd, String land) {
		return getT_ZPLMS017(rawCd, land, null);
	}
	
	// 2번째로 호출이 많이 되는 함수
	// 메모리 누수 방지를 위해서 선언된 객체를 모두 null 처리합니다.
	public List<BomInfoVO> getT_ZPLMS017(String rawCd, String land, Context context) {
		String flagContinueContext = "";
		List<BomInfoVO> bomList = null;
	
		SapCallLogVO logVo = new SapCallLogVO();
		BomInfoVO BomInfo = null;
		
		IData input = null;
		IDataCursor inputCursor = null;
		IData	REQUEST = null;
		IDataCursor REQUESTCursor = null;
		IData	HEADER = null;
		IDataCursor HEADERCursor = null;
		IData	INPUT = null;
		IDataCursor INPUTCursor = null;
		IData 	output = null;
		IDataCursor outputCursor = null;
		IData	RESPONSE = null;
		IDataCursor RESPONSECursor = null;
		IData	HEADER_1 = null;
		IDataCursor HEADER_1Cursor = null;
		IData	OUTPUT = null;
		IDataCursor OUTPUTCursor = null;
		IData[]	T_ZPLS9310 = null;
		IDataCursor T_ZPLS9310Cursor = null;
		
		try {
			logVo.setVServiceCd("Z_PORTAL_BOM_EXPLOSION_MAT5");
			
			if(context == null){
				context = this.setSAPConnection();
			}else{
				flagContinueContext = "Y";
			}
			
			// input
			input = IDataFactory.create();
			inputCursor = input.getCursor();
			
			// REQUEST
			REQUEST = IDataFactory.create();
			REQUESTCursor = REQUEST.getCursor();
			
			// REQUEST.HEADER
			HEADER = IDataFactory.create();
			HEADERCursor = HEADER.getCursor();
			
			// 시스템 코드
			IDataUtil.put( HEADERCursor, "SOURCE", "L1050" );
			HEADERCursor.destroy();
			IDataUtil.put( REQUESTCursor, "HEADER", HEADER );
			
			// REQUEST.INPUT
			INPUT = IDataFactory.create();
			INPUTCursor = INPUT.getCursor();
			
			IDataUtil.put( INPUTCursor, "MATNR", rawCd);
			IDataUtil.put( INPUTCursor, "LAND", land);
			INPUTCursor.destroy();
			IDataUtil.put( REQUESTCursor, "INPUT", INPUT );
			REQUESTCursor.destroy();
			IDataUtil.put( inputCursor, "REQUEST", REQUEST );
			inputCursor.destroy();
			
			// output
			output = IDataFactory.create();
			try{
				output = context.invoke("AP_QM_01.Z_PORTAL_BOM_EXPLOSION_MAT5", "svcQMI0080_TIUMNET_SAP", input);
			}catch( Exception e){
				log.error("getT_ZPLMS017 - AP_QM_01.Z_PORTAL_BOM_EXPLOSION_MAT5 Error ", e);
			}
			
			outputCursor = output.getCursor();
			
			// RESPONSE
			RESPONSE = IDataUtil.getIData( outputCursor, "RESPONSE" );
			if ( RESPONSE != null)
			{
				logVo.setVRawCd(rawCd);
				logVo.setVLand(land);
				
				RESPONSECursor = RESPONSE.getCursor();
				
				// i.HEADER
				HEADER_1 = IDataUtil.getIData( RESPONSECursor, "HEADER" );
				if ( HEADER_1 != null)
				{
					HEADER_1Cursor = HEADER_1.getCursor();
						String	IF_ID = IDataUtil.getString( HEADER_1Cursor, "IF_ID" );
						String	RTN_TYPE = IDataUtil.getString( HEADER_1Cursor, "RTN_TYPE" );
						String	RTN_MSG = IDataUtil.getString( HEADER_1Cursor, "RTN_MSG" );
					HEADER_1Cursor.destroy();
					
					logVo.setVIfId(IF_ID);
					logVo.setVRtnType(RTN_TYPE);
					logVo.setVRtnMsg(RTN_MSG);
				}
				
				// i.OUTPUT
				OUTPUT = IDataUtil.getIData( RESPONSECursor, "OUTPUT" );
				if ( OUTPUT != null)
				{
					OUTPUTCursor = OUTPUT.getCursor();
					String	O_MESSAGE = IDataUtil.getString( OUTPUTCursor, "O_MESSAGE" );
					String	O_RESULT = IDataUtil.getString( OUTPUTCursor, "O_RESULT" );
					
					logVo.setVMessage(O_MESSAGE);
					logVo.setVResult(O_RESULT);
					
					// i.T_ZPLMS013
					T_ZPLS9310 = IDataUtil.getIDataArray( OUTPUTCursor, "T_ZPLS9310" );
					if ( T_ZPLS9310 != null)
					{
						bomList			=	new ArrayList<>();
						for ( int i = 0; i < T_ZPLS9310.length; i++ )
						{
							T_ZPLS9310Cursor = T_ZPLS9310[i].getCursor();
							
							BomInfo	=	new BomInfoVO();
							
							BomInfo.setMatnrR(this.removeLeftZero(IDataUtil.getString(T_ZPLS9310Cursor, "MATNR_R")));
							BomInfo.setMaktxR(IDataUtil.getString(T_ZPLS9310Cursor, "MAKTX_R"));
							BomInfo.setConcd(this.removeLeftZero(IDataUtil.getString(T_ZPLS9310Cursor, "CONCD")));
							BomInfo.setConInPer(IDataUtil.getString(T_ZPLS9310Cursor, "CON_IN_PER"));
							BomInfo.setConnameKo(IDataUtil.getString(T_ZPLS9310Cursor, "CONNAME_KO"));
							BomInfo.setConnameEn(IDataUtil.getString(T_ZPLS9310Cursor, "CONNAME_EN"));
							BomInfo.setConnameCn(IDataUtil.getString(T_ZPLS9310Cursor, "CONNAME_CN"));
							BomInfo.setConnameJa(IDataUtil.getString(T_ZPLS9310Cursor, "CONNAME_JA"));
							BomInfo.setFcnameKo(IDataUtil.getString(T_ZPLS9310Cursor, "FCNAME_KO"));
							BomInfo.setFcnameEn(IDataUtil.getString(T_ZPLS9310Cursor, "FCNAME_EN"));
							BomInfo.setCasno(IDataUtil.getString(T_ZPLS9310Cursor, "CASNO"));
							BomInfo.setAicsno(IDataUtil.getString(T_ZPLS9310Cursor, "AICSNO"));
							BomInfo.setMixre(IDataUtil.getString(T_ZPLS9310Cursor, "MIXRE"));
							BomInfo.setZglobal(IDataUtil.getString(T_ZPLS9310Cursor, "ZGLOBAL"));
							BomInfo.setZgubcl(IDataUtil.getString(T_ZPLS9310Cursor, "ZGUBCL"));
							BomInfo.setZgllim(IDataUtil.getString(T_ZPLS9310Cursor, "ZGLLIM"));
							
							BomInfo.setFcnameKo(BomInfo.getFcnameKo().replaceAll("(외(\\s*)[0-9](\\s*)건)", "").trim());
							BomInfo.setFcnameEn(BomInfo.getFcnameEn().replaceAll("(외(\\s*)[0-9](\\s*)건)", "").trim());
							
							bomList.add(BomInfo);
							
							T_ZPLS9310Cursor.destroy();
						}
					}
					OUTPUTCursor.destroy();
				}
				RESPONSECursor.destroy();
			}
			outputCursor.destroy();
		} catch (Exception e) {
			log.error("Error : ", e);
		}finally{
			if(!"Y".equals(flagContinueContext)){
				this.SAPDisconnection(context);
			}
			
			// 로그 기록
			this.insertSapCallLog(logVo);
			
			//메모리 누수 방지
			logVo	=	null;
			BomInfo	=	null;
			
			input = null;
			inputCursor = null;
			REQUEST = null;
			REQUESTCursor = null;
			HEADER = null;
			HEADERCursor = null;
			INPUT = null;
			INPUTCursor = null;
			output = null;
			outputCursor = null;
			RESPONSE = null;
			RESPONSECursor = null;
			HEADER_1 = null;
			HEADER_1Cursor = null;
			OUTPUT = null;
			OUTPUTCursor = null;
			T_ZPLS9310 = null;
			T_ZPLS9310Cursor = null;
		}
		
		return bomList;
	}
	
	public List<Zplmt74VO> getT_ZPLMT74(String rawCd) {
		List<Zplmt74VO> OT_DATA_LIST = null;
		List<Zplmt74VO> result = new ArrayList<>();
		
		SapCallLogVO logVo = new SapCallLogVO();
		Zplmt74VO tempVo	= null;
		
		Context context = null;
		
		IData input = null;
		IDataCursor inputCursor = null;
		IData REQUEST = null;
		IDataCursor REQUESTCursor = null;
		IData HEADER = null;
		IDataCursor HEADERCursor = null;
		IData INPUT = null;
		IDataCursor INPUTCursor = null;
		IData[] T_ZPLMT74 = null;
		IDataCursor T_ZPLMT74Cursor = null;
		IData output = null;
		IDataCursor outputCursor = null;
		IData RESPONSE = null;
		IDataCursor RESPONSECursor = null;
		IData HEADER_1 = null;
		IDataCursor HEADER_1Cursor = null;
		IData OUTPUT = null;
		IDataCursor OUTPUTCursor = null;
		IData[] OT_DATA = null;
		IDataCursor OT_TABCursor = null;
		
		try {
			context = this.setSAPConnection();
			
			// input
			input = IDataFactory.create();
			inputCursor = input.getCursor();
			
			// REQUEST
			REQUEST = IDataFactory.create();
			REQUESTCursor = REQUEST.getCursor();
			
			// REQUEST.HEADER
			HEADER = IDataFactory.create();
			HEADERCursor = HEADER.getCursor();
			// 시스템 코드
			IDataUtil.put( HEADERCursor, "SOURCE", "L1050");
			HEADERCursor.destroy();
			IDataUtil.put( REQUESTCursor, "HEADER", HEADER);
			
			// REQUEST.INPUT
			INPUT = IDataFactory.create();
			INPUTCursor = INPUT.getCursor();
			
			T_ZPLMT74 = new IData[1];
			T_ZPLMT74[0] = IDataFactory.create();
			T_ZPLMT74Cursor = T_ZPLMT74[0].getCursor();
			IDataUtil.put( T_ZPLMT74Cursor, "MATNR", rawCd);
			T_ZPLMT74Cursor.destroy();
			
			IDataUtil.put(INPUTCursor, "IT_DATA", T_ZPLMT74);
			INPUTCursor.destroy();
			IDataUtil.put(REQUESTCursor, "INPUT", INPUT);
			REQUESTCursor.destroy();
			IDataUtil.put(inputCursor, "REQUEST", REQUEST);
			inputCursor.destroy();
			
			// output
			output = IDataFactory.create();
			
			try{
				output = context.invoke("AP_QM_02.ZPLM_IF_EXP_ZPLMT74", "svcQMI6017_TIUMNET_SAP", input);
			}catch( Exception e){
				System.out.println(e);
			}
			
			outputCursor = output.getCursor();
			
			// RESPONSE
			RESPONSE = IDataUtil.getIData( outputCursor, "RESPONSE");
			if (RESPONSE != null)
			{
				logVo.setVServiceCd("AP_QM_02.ZPLM_IF_EXP_ZPLMT74");
				
				logVo.setVWerks("없음");
				logVo.setVContentCd("없음");
				logVo.setVRawCd(rawCd);
				
				RESPONSECursor = RESPONSE.getCursor();
				
				// i.HEADER
				HEADER_1 = IDataUtil.getIData(RESPONSECursor, "HEADER");
				if (HEADER_1 != null)
				{
					HEADER_1Cursor = HEADER_1.getCursor();
						String TYPE = IDataUtil.getString(HEADER_1Cursor, "TYPE");
						String MESSAGE = IDataUtil.getString(HEADER_1Cursor, "MESSAGE");
						
					HEADER_1Cursor.destroy();
					
					logVo.setVIfId("");
					logVo.setVRtnType(TYPE);
					logVo.setVRtnMsg(MESSAGE);
					logVo.setVMessage("");
					logVo.setVResult("");
				}
				
				// i.OUTPUT
				OUTPUT = IDataUtil.getIData(RESPONSECursor, "OUTPUT");
				if (OUTPUT != null)
				{
					OUTPUTCursor = OUTPUT.getCursor();
					
					// i.OT_DATA
					OT_DATA = IDataUtil.getIDataArray(OUTPUTCursor, "OT_DATA");
					if (OT_DATA != null)
					{
						OT_DATA_LIST = new ArrayList<Zplmt74VO>();
						for (int i = 0; i < OT_DATA.length; i++)
						{
							OT_TABCursor = OT_DATA[i].getCursor();
							
							tempVo = new Zplmt74VO();
							
							tempVo.setMatnr(IDataUtil.getString(OT_TABCursor, "MATNR").trim());		// 원료코드
							tempVo.setConcdO(IDataUtil.getString(OT_TABCursor, "CONCD_O").trim());	// 부모 성분코드
							tempVo.setLvl(IDataUtil.getString(OT_TABCursor, "LVL").trim());			// 레벨
							tempVo.setConcd(IDataUtil.getString(OT_TABCursor, "CONCD").trim());		// 알러젠 성분코드
							tempVo.setInPer(IDataUtil.getString(OT_TABCursor, "IN_PER").trim());	// 알러젠 함량
							OT_DATA_LIST.add(tempVo);
							
							OT_TABCursor.destroy();
						}
						result.addAll(OT_DATA_LIST);
					}
					OUTPUTCursor.destroy();
				}
				RESPONSECursor.destroy();
			}
			outputCursor.destroy();
		} catch (Exception e) {
			log.error("Error : ", e);
		} finally{
			this.SAPDisconnection(context);
			// 로그 기록
			this.insertSapCallLog(logVo);
			
			//메모리 누수 방지
			logVo	= null;
			tempVo	= null;
			
			input = null;
			inputCursor = null;
			REQUEST = null;
			REQUESTCursor = null;
			HEADER = null;
			HEADERCursor = null;
			INPUT = null;
			INPUTCursor = null;
			T_ZPLMT74 = null;
			T_ZPLMT74Cursor = null;
			output = null;
			outputCursor = null;
			RESPONSE = null;
			RESPONSECursor = null;
			HEADER_1 = null;
			HEADER_1Cursor = null;
			OUTPUT = null;
			OUTPUTCursor = null;
			OT_DATA = null;
			OT_TABCursor = null;
			OT_DATA_LIST = null;
		}
		
		return result;
	}
	
	public void send_MDI00005(String matnr, String mhdhb, String s_userid) {
		this.new_send_MDI00005(matnr, mhdhb, s_userid, "N");
	}
	
	public void send_MDI00005_mat_flag_Y(String matnr, String mhdhb, String s_userid) {
		this.new_send_MDI00005(matnr, mhdhb, s_userid, "Y");
	}
	
	public void new_send_MDI00005(String matnr, String mhdhb, String s_userid, String matFlag) {
		Context context = null;
		SapCallLogMdi0005VO logVo = new SapCallLogMdi0005VO();
		
		try {
			
			context	=	this.setSAPConnection_5570();
			
			// input
			IData input = IDataFactory.create();
			IDataCursor inputCursor = input.getCursor();
			
			// REQUEST
			IData	REQUEST = IDataFactory.create();
			IDataCursor REQUESTCursor = REQUEST.getCursor();
			
			// REQUEST.HEADER
			IData	HEADER = IDataFactory.create();
			IDataCursor HEADERCursor = HEADER.getCursor();
			// 시스템 코드
			IDataUtil.put( HEADERCursor, "SOURCE", "L1050" );
			HEADERCursor.destroy();
			IDataUtil.put( REQUESTCursor, "HEADER", HEADER );
			
			// REQUEST.INPUT
			IData	INPUT = IDataFactory.create();
			IDataCursor INPUTCursor = INPUT.getCursor();
			
			logVo.setVMatnr(matnr);
			SapCallLogMdi0005VO	rvo	=	labNoteSAPInterfaceMapper.selectErsda(logVo);
			
			String ersda	=	null;
			String laeda	=	null;
			String cud_ci	=	null;
			
			if(StringUtils.isEmpty(rvo.getVErsda())){
				ersda	=	rvo.getVDtm();
				laeda	=	rvo.getVDtm();
				cud_ci	=	"C";
			}else{
				ersda	=	rvo.getVErsda();
				laeda	=	rvo.getVDtm();
				cud_ci	=	"U";
			}
			
			IDataUtil.put( INPUTCursor, "MATNR"		, matnr);
			IDataUtil.put( INPUTCursor, "MHDHB"		, mhdhb);
			IDataUtil.put( INPUTCursor, "ERSDA"		, ersda);
			IDataUtil.put( INPUTCursor, "LAEDA"		, laeda);
			IDataUtil.put( INPUTCursor, "CUD_CI"	, cud_ci);
			IDataUtil.put( INPUTCursor, "MATFLAG"	, matFlag);
			// 2021.3.29 기간지시자는 M(월)로 고정
			// 추후에 기간지시자를 다중으로 사용 시 수정해야함
			IDataUtil.put( INPUTCursor, "IPRKZ"		, "M");
			
			logVo.setVRegUserid(s_userid);
			logVo.setVMatnr(matnr);
			logVo.setVMhdhb(mhdhb);
			logVo.setVErsda(ersda);
			logVo.setVLaeda(laeda);
			logVo.setVCudCi(cud_ci);
			logVo.setVMatFlag(matFlag);
			// 2021.3.29 기간지시자는 M(월)로 고정
			// 추후에 기간지시자를 다중으로 사용 시 수정해야함
			logVo.setVIprkz("M");
			
			
			INPUTCursor.destroy();
			IDataUtil.put( REQUESTCursor, "INPUT", INPUT );
			REQUESTCursor.destroy();
			IDataUtil.put( inputCursor, "REQUEST", REQUEST );
			inputCursor.destroy();
			
			// output
			IData 	output = IDataFactory.create();
			try{
				output = context.invoke("AP_MD_01.ZMD_MHDHB_RECEIVE", "svcMDI0005_TIUMNET_SAP", input);
			}catch( Exception e){
				log.error("new_send_MDI00005 - AP_MD_01.ZMD_MHDHB_RECEIVE Error ", e);
			}
			
			IDataCursor outputCursor = output.getCursor();
			
			// RESPONSE
			IData	RESPONSE = IDataUtil.getIData( outputCursor, "RESPONSE" );
			if ( RESPONSE != null)
			{
				
				IDataCursor RESPONSECursor = RESPONSE.getCursor();
				
				// i.HEADER
				IData	HEADER_1 = IDataUtil.getIData( RESPONSECursor, "HEADER" );
				if ( HEADER_1 != null)
				{
					IDataCursor HEADER_1Cursor = HEADER_1.getCursor();
						String	E_MSGTY	=	IDataUtil.getString( HEADER_1Cursor, "E_MSGTY" );
						String	E_MSG	=	IDataUtil.getString( HEADER_1Cursor, "E_MSG" );
					HEADER_1Cursor.destroy();
					
					logVo.setVEmsgty(E_MSGTY);
					logVo.setVEmsg(E_MSG);
				}
				
				RESPONSECursor.destroy();
			}else{
				log.info("new_send_MDI00005 RESPONSE is Null");
			}
			
			outputCursor.destroy();
		} catch (Exception e) {
			log.error("Error : ", e);
		}finally{
			this.SAPDisconnection(context);
			
			// 로그 기록
			this.insertSapCallLogMDI0005(logVo);
			
			// 실험노트 ShelfLife에 로그 기록 정보 저장
			this.updateElabShelfLifeLogCd(logVo);
		}
	}
	
	public String getZmdMhdhbInfo(String matnr, String s_userid) {
		Context context = null;
		SapCallLogMdi0010VO logVo = new SapCallLogMdi0010VO();
		String result = null;
		
		try {
			
			context	=	this.setSAPConnection_5570();
			
			// input
			IData input = IDataFactory.create();
			IDataCursor inputCursor = input.getCursor();
			
			// REQUEST
			IData	REQUEST = IDataFactory.create();
			IDataCursor REQUESTCursor = REQUEST.getCursor();
			
			// REQUEST.HEADER
			IData	HEADER = IDataFactory.create();
			IDataCursor HEADERCursor = HEADER.getCursor();
			// 시스템 코드
			IDataUtil.put( HEADERCursor, "SOURCE", "L1050" );
			HEADERCursor.destroy();
			IDataUtil.put( REQUESTCursor, "HEADER", HEADER );
			
			// REQUEST.INPUT
			IData	INPUT = IDataFactory.create();
			IDataCursor INPUTCursor = INPUT.getCursor();
			
			IDataUtil.put( INPUTCursor, "MATNR"		, matnr);
			logVo.setVMatnr(matnr);
			logVo.setVRegUserid(s_userid);
			
			INPUTCursor.destroy();
			IDataUtil.put( REQUESTCursor, "INPUT", INPUT );
			REQUESTCursor.destroy();
			IDataUtil.put( inputCursor, "REQUEST", REQUEST );
			inputCursor.destroy();
			
			// output
			IData 	output = IDataFactory.create();
			try{
				output = context.invoke("AP_MD_01.ZMD_GET_MHDHB_INFO", "svcMDI0010_TIUMNET_SAP", input);
			}catch( Exception e){
				log.error("getZmdMhdhbInfo - AP_MD_01.ZMD_GET_MHDHB_INFO Error ", e);
			}
			
			IDataCursor outputCursor = output.getCursor();
			
			// RESPONSE
			IData	RESPONSE = IDataUtil.getIData( outputCursor, "RESPONSE" );
			if ( RESPONSE != null)
			{
				
				IDataCursor RESPONSECursor = RESPONSE.getCursor();
				IData OUTPUT = IDataUtil.getIData(RESPONSECursor, "OUTPUT");
				
				if(OUTPUT != null) {
					IDataCursor OUTPUTCursor = OUTPUT.getCursor();
					
					IData esReturn = IDataUtil.getIData(OUTPUTCursor, "ES_RETURN");
					IDataCursor esReturnCursor = esReturn.getCursor();
					
					String	MHDHB	=	IDataUtil.getString( esReturnCursor, "MHDHB" );
					String	E_MSGTY	=	IDataUtil.getString( esReturnCursor, "E_MSGTY" );
					String	E_MSG	=	IDataUtil.getString( esReturnCursor, "E_MSG" );
					
					logVo.setVMhdhb(MHDHB);
					logVo.setVEmsgty(E_MSGTY);
					logVo.setVEmsg(E_MSG);
					
					
					result = MHDHB;
					
					// 개발서버일 경우에는 MHDHB 값이 NULL일 경우에 기본값을 채워줍니다.
					if(!Const.ACTIVE_PROD.equals(ACTIVE)) { 
						if(StringUtils.isEmpty(MHDHB) || "0".equals(MHDHB)){
							result = "36";
						}
					}
					
					esReturnCursor.destroy();
					outputCursor.destroy();
				}
				RESPONSECursor.destroy();
			}
		} catch (Exception e) {
			log.error("Error : ", e);
		}finally{
			this.SAPDisconnection(context);
			
			// 로그 기록
			this.insertSapCallLogMDI0010(logVo);
		}
		
		return result; 
	}
	
	@Transactional
	public int insertSapCallLogMDI0005(SapCallLogMdi0005VO sapCallLogMdi0005VO) {
		return labNoteSAPInterfaceMapper.insertSapCallLogMDI0005(sapCallLogMdi0005VO);
	}
	
	@Transactional
	public int insertSapCallLogMDI0010(SapCallLogMdi0010VO sapCallLogMdi0010VO) {
		return labNoteSAPInterfaceMapper.insertSapCallLogMDI0010(sapCallLogMdi0010VO);
	}
	
	@Transactional
	public int insertSapCallLog(SapCallLogVO sapCallLogVO) {
		return labNoteSAPInterfaceMapper.insertSapCallLog(sapCallLogVO);
	}
	
	public List<Mat3VO> selectMat3List(BomListVO bomListVO) {
		return labNoteSAPInterfaceMapper.selectMat3List(bomListVO);
	}
	
	public Zplms0332ListVO getRawListToZPLM34E_SingleFomula_MOS(String[] rawcd,String[] rawper) {
		Context context = null;
		Zplms0332ListVO resultVo = new Zplms0332ListVO();
		
		try {
			if(rawcd != null && rawper != null){
				
				int size = rawcd.length;
				
				if(size > 0){
					
					List<BomInfoVO> tmpZplm34eRawInfoList	=	null;	// 6자 하위 구성성분 저장 객체
					List<BomInfoVO> tmpZplm34e4HalInfoList	=	null;	// 4자 하위 구성 원료 저장 객체
					
					// 임시 내용물코드 생성
					String tmpContentCd = labNoteSAPInterfaceMapper.selectTmpContentCd();
					
					// 혹시 시퀸스가 한바퀴 돌았을 경우를 대비해서 삭제 수행
					labNoteSAPInterfaceMapper.deleteTmpZplmt13ContentInfo(tmpContentCd);
					
					context = this.setSAPConnection();
					
					//원료하위 1자 성분구성 정보를 임시 테이블에 저장
					for(int i = 0; i < size; i++){
						
						if(rawcd[i].indexOf("6") == 0){
							tmpZplm34eRawInfoList	=	this.getT_ZPLMS017(rawcd[i], "UN", context);
							for(int j=0; j < tmpZplm34eRawInfoList.size(); j++){
								labNoteSAPInterfaceMapper.insertTmpZplmt13ContentInfo(TmpZplmt13ContentInfoVO.builder()
										.vRawCd(rawcd[i])
										.vConCd(tmpZplm34eRawInfoList.get(j).getConcd())
										.vRawInPer(rawper[i])
										.vConInPer(tmpZplm34eRawInfoList.get(j).getConInPer())
										.vCasNo(tmpZplm34eRawInfoList.get(j).getCasno())
										.build());
							}
						}else if(StringUtils.isNotEmpty(rawcd[i])){
							tmpZplm34e4HalInfoList	=	this.getT_ZPLMS013(labNoteSAPInterfaceMapper.select4HalWrek(rawcd[i]), rawcd[i], "UN", context);
							
							for(int j=0; j < tmpZplm34e4HalInfoList.size(); j++){
								labNoteSAPInterfaceMapper.insertTmpZplmt13ContentInfo2(TmpZplmt13ContentInfoVO.builder()
										.vRawCd(tmpZplm34e4HalInfoList.get(j).getRawCd())
										.vConCd(tmpZplm34e4HalInfoList.get(j).getConcd())
										.vHal4InPer(rawper[i])
										.vRawInPer(tmpZplm34e4HalInfoList.get(j).getRawPer())
										.vConInPer(tmpZplm34e4HalInfoList.get(j).getConInPer())
										.vCasNo(tmpZplm34e4HalInfoList.get(j).getCasno())
										.build());
							}
						}
					}
					
					List<TmpZplmt13ContentInfoVO> tmpZplm34eSingleFormulaList			=	labNoteSAPInterfaceMapper.selectTmpZplm34eSingleFormulaList(tmpContentCd);
					List<TmpZplmt13ContentInfoVO> tmpZplm34eSingleFormulaAllergenList	=	labNoteSAPInterfaceMapper.selectTmpZplm34eSingleFormulaAllergenList(tmpContentCd);
					
					if(tmpZplm34eSingleFormulaList.size() > 0){
						String[] concd	=	new String[tmpZplm34eSingleFormulaList.size()];
						String[] casno	=	new String[tmpZplm34eSingleFormulaList.size()];
						String[] conper	=	new String[tmpZplm34eSingleFormulaList.size()];
						
						for(int i=0; i < tmpZplm34eSingleFormulaList.size(); i++){
							concd[i]	=	tmpZplm34eSingleFormulaList.get(i).getVConCd();
							casno[i]	=	tmpZplm34eSingleFormulaList.get(i).getVCasNo();
							conper[i]	=	tmpZplm34eSingleFormulaList.get(i).getNConper();
						}
						
						resultVo.setTmpZplm34eSingleFormulaList(this.getT_ZPLMS0332(concd, casno, conper, context));
					}
					
					if(tmpZplm34eSingleFormulaAllergenList.size() > 0){
						String[] concd	=	new String[tmpZplm34eSingleFormulaAllergenList.size()];
						String[] casno	=	new String[tmpZplm34eSingleFormulaAllergenList.size()];
						String[] conper	=	new String[tmpZplm34eSingleFormulaAllergenList.size()];
						
						for(int i=0; i < tmpZplm34eSingleFormulaAllergenList.size(); i++){
							concd[i]	=	tmpZplm34eSingleFormulaAllergenList.get(i).getVConCd();
							casno[i]	=	tmpZplm34eSingleFormulaAllergenList.get(i).getVCasNo();
							conper[i]	=	tmpZplm34eSingleFormulaAllergenList.get(i).getNConper();
						}
						
						resultVo.setTmpZplm34eSingleFormulaAllergenList(this.getT_ZPLMS0332(concd, casno, conper, context));
					}
					
					// 혹시 시퀸스가 한바퀴 돌았을 경우를 대비해서 삭제 수행
					labNoteSAPInterfaceMapper.deleteTmpZplmt13ContentInfo(tmpContentCd);
					
					return	resultVo;
				}else{
					return null;
				}
			}else{
				return null;
			}
		} catch (Exception e) {
			log.error("Error : ", e);
		} finally{
			this.SAPDisconnection(context);
		}
		return	resultVo;
	}
	
	public List<Zplms0332VO> getT_ZPLMS0332(String[] concd, String[] casno, String[] conper) {
		return this.getT_ZPLMS0332(concd, casno, conper, null);
	}
	
	public List<Zplms0332VO> getT_ZPLMS0332(String[] concd, String[] casno, String[] conper, Context context) {
		List<Zplms0332VO> ZPLMS0332List = null;
		SapCallLogVO logVo = new SapCallLogVO();
		String flagContinueContext = "";
		try {
			if(context == null){
				context = this.setSAPConnection();
			}else{
				flagContinueContext = "Y";
			}
			
			// input
			IData input = IDataFactory.create();
			IDataCursor inputCursor = input.getCursor();
			
			// REQUEST
			IData REQUEST = IDataFactory.create();
			IDataCursor REQUESTCursor = REQUEST.getCursor();
			
			// REQUEST.HEADER
			IData HEADER = IDataFactory.create();
			IDataCursor HEADERCursor = HEADER.getCursor();
			// 시스템 코드
			IDataUtil.put( HEADERCursor, "SOURCE", "L1050");
			HEADERCursor.destroy();
			IDataUtil.put( REQUESTCursor, "HEADER", HEADER);
			
			// REQUEST.INPUT
			IData INPUT = IDataFactory.create();
			IDataCursor INPUTCursor = INPUT.getCursor();
			
			int size = concd.length;
			
			// REQUEST.INPUT.T_ZPLMS015
			IData[] T_CON_LIST = new IData[size];
			
			for(int i=0;i< size;i++){
				T_CON_LIST[i] = IDataFactory.create();
				IDataCursor T_CON_LISTCursor = T_CON_LIST[i].getCursor();
				
				IDataUtil.put( T_CON_LISTCursor, "CONCD", concd[i].trim());
				IDataUtil.put( T_CON_LISTCursor, "CASNO", casno[i].trim());
				T_CON_LISTCursor.destroy();
			}
			
			
			IDataUtil.put(INPUTCursor, "T_CON_LIST", T_CON_LIST);
			INPUTCursor.destroy();
			IDataUtil.put(REQUESTCursor, "INPUT", INPUT);
			REQUESTCursor.destroy();
			IDataUtil.put(inputCursor, "REQUEST", REQUEST);
			inputCursor.destroy();
			
			// output
			IData output = IDataFactory.create();
			
			try{
				output = context.invoke("AP_QM_02.ZPLM_CHEMT_CONCDDATA_SEND_TDD", "svcQMI1706_TIUMNET_SAP", input);
			}catch( Exception e){
				log.error("Error : ", e);
			}
			
			IDataCursor outputCursor = output.getCursor();
			
			// RESPONSE
			IData RESPONSE = IDataUtil.getIData( outputCursor, "RESPONSE");
			if (RESPONSE != null)
			{
				logVo.setVServiceCd("ZPLM_CHEMT_CONCDDATA_SEND_TDD");
				
				logVo.setVWerks("없음");
				logVo.setVContentCd("없음");
				
				IDataCursor RESPONSECursor = RESPONSE.getCursor();
				
				// i.HEADER
				IData HEADER_1 = IDataUtil.getIData(RESPONSECursor, "HEADER");
				if (HEADER_1 != null)
				{
					IDataCursor HEADER_1Cursor = HEADER_1.getCursor();
						String IF_ID = IDataUtil.getString(HEADER_1Cursor, "IF_ID");
						String RTN_TYPE = IDataUtil.getString(HEADER_1Cursor, "RTN_TYPE");
						String RTN_MSG = IDataUtil.getString(HEADER_1Cursor, "RTN_MSG");
					HEADER_1Cursor.destroy();
					
					logVo.setVIfId(IF_ID);
					logVo.setVRtnType(RTN_TYPE);
					logVo.setVRtnMsg(RTN_MSG);
				}
				
				// i.OUTPUT
				IData OUTPUT = IDataUtil.getIData(RESPONSECursor, "OUTPUT");
				if (OUTPUT != null)
				{
					IDataCursor OUTPUTCursor = OUTPUT.getCursor();
					String O_MESSAGE = IDataUtil.getString(OUTPUTCursor, "O_MESSAGE");
					String O_RESULT = IDataUtil.getString(OUTPUTCursor, "O_RESULT");
					
					logVo.setVMessage(O_MESSAGE);
					logVo.setVResult(O_RESULT);
					
					// i.T_ZPLMS0332
					IData[] T_ZPLMS0332 = IDataUtil.getIDataArray(OUTPUTCursor, "T_ZPLMS0332");
					if (T_ZPLMS0332 != null)
					{
						ZPLMS0332List = new ArrayList<>();
						Zplms0332VO ZPLMS0332 = null;
						for (int i = 0; i < T_ZPLMS0332.length; i++)
						{
							IDataCursor T_ZPLMS0332Cursor = T_ZPLMS0332[i].getCursor();
							
							ZPLMS0332 = new Zplms0332VO();
							
							ZPLMS0332.setConcd(IDataUtil.getString(T_ZPLMS0332Cursor, "CONCD").trim());		// 성분코드
							ZPLMS0332.setCasno(IDataUtil.getString(T_ZPLMS0332Cursor, "CASNO").trim());		// 카스번호
							ZPLMS0332.setEnva1(IDataUtil.getString(T_ZPLMS0332Cursor, "ENVA1").trim());
							ZPLMS0332.setZnoel(IDataUtil.getString(T_ZPLMS0332Cursor, "ZNOEL").trim());
							ZPLMS0332.setToxicokinetics(IDataUtil.getString(T_ZPLMS0332Cursor, "TOXICOKINETICS").trim());
							ZPLMS0332.setConper(conper[i]);
							
							ZPLMS0332List.add(ZPLMS0332);
							
							T_ZPLMS0332Cursor.destroy();
						}
					}
					OUTPUTCursor.destroy();
				}
				RESPONSECursor.destroy();
			}
			outputCursor.destroy();
		} catch (Exception e) {
			log.error("Error : ", e);
		} finally{
			if(!"Y".equals(flagContinueContext)){
				this.SAPDisconnection(context);
			}
			// 로그 기록
			this.insertSapCallLog(logVo);
		}
		
		return ZPLMS0332List;
	}
	
	// SAP Connection
	public	Context setSAPConnection() {
		Context context = null;
		String		sap_server		= "";
		String		sap_user		= "";
		String		sap_password	= "";
		try {
			context = new Context();
			
			sap_server		= SAP_SERVER;
			sap_user		= SAP_USER;
			sap_password	= SAP_PASSWORD;
			
			context.connect(sap_server, sap_user, sap_password);
			
		} catch (Exception e) {
			log.error("Cannot connect to server {} - {}", sap_server, e.getMessage());
		}

		return context;
	}
	
	// SAP Connection
	public	Context setSAPConnection_5570() {
		Context context = null;
		String		sap_server		= "";
		String		sap_user		= "";
		String		sap_password	= "";
		try {
			context = new Context();
			
			sap_server		= SAP_SERVER_5570;
			sap_user		= SAP_USER;
			sap_password	= SAP_PASSWORD;
			
			context.connect(sap_server, sap_user, sap_password);
			
		} catch (Exception e) {
			log.error("Cannot connect to server5570 {} - {}", sap_server, e.getMessage());
		}

		return context;
	}
	
	// SAP Disconnection
	public void SAPDisconnection(Context context) {
		if (context != null) { 
			context.disconnect();
			context=null;
		}
	}
	
	// 왼쪽 0을 제거한다.
	public String removeLeftZero(String temp){
		int length = temp.length();
		int idx	=	0;
		for(int i = 0; i < length; i++){
			if("0".equals(temp.charAt(i)+"")){
				idx +=1;
			}else{
				break;
			}
		}
		
		temp = temp.substring(0+idx);
		
		return temp;
	}
	
	@Transactional
	public int updateElabShelfLifeLogCd(SapCallLogMdi0005VO sapCallLogMdi0005VO) {
		return labNoteSAPInterfaceMapper.updateElabShelfLifeLogCd(ElabShelflifeContVO.builder()
				.vLogCd(sapCallLogMdi0005VO.getVLogCd())
				.vContCd(sapCallLogMdi0005VO.getVMatnr())
				.build());
	}
}
