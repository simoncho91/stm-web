package com.mybeaker.app.labnote.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LabNoteProcessFuncReportDataDTO {

	private String vNoteType;
	
	private String vContCd;
	
	private String vContNm;
	
	private String vRealDecideContNm;
	
	private String vUserid;
	
	private String vUsernm;
	
	private String vPlantCd;
	
	private String vUserInfo;
	
	private String vBrdUserid;
	
	private String vBrdUsernm;
	
	private String vBrdUserInfo;
	
	private String vFlagReleaseAsia;
	
	private String vFlagReleaseAsean;
	
	private String vFlagReleaseEtc;
	
	private String vFlagFuncTest;
	
	private String vPilotDt;
	
	private String vMassProdDt;
	
	private String vMeetingDt;
	
	private String vDecideContNm;
	
	private String vFlagDecide;
	
	private String vEvaluateCd;
	
	private String vEvalueteNo;
	
	private String vEvalueteGosiCd;
	
	private String vEvalueteGosiNo;
	
	private String vEvalueteGosiNm;
	
	private String vShape;
	
	private String vDosageCd;
	
	private String vDosageCdList;
	
	private String vRefTypeCd;
	
	private String vRefTypeNm;
	
	private String vRefTypeInfo;
	
	private String vDosageNm;
	
	private String vLabNoteCd;
	
	private int nVersion;
	
	private String vTitle;
	
	private String vReqContent;
	
	private String vNumberNm;
	
	private String vFlagOverEthanol;
	
	private String vFlagOverEthanolNm;
	
	private String vPh;
	
	private String vMaker;
	
	private int nTioTwoRate;
	
	private int nZnoRate;
	
	private String vTioTwoNote;
	
	private String vZnoNote;
	
	private String vEvaluateNum;
	
	private String vChangeProduct;
	
	private String vChangeCd;
	
	private String vChangeNote;
	
	private String vEffect;
	
	private String vUsageCapacity;
	
	private String vMakePlace;
	
	private String vQmsLotInfo;
	
	private String vTwoLiqYn;
	
	private String vTwoLiqTxt;
	
	private String vBaseItem;
	
	private String vMateCdList;
	
	private String vMateCdNmList;
	
	private String vMateCdPerList;
	
	private String vReleaseDt;
	
	private String vFuncTypeInfo;
	
	private String vFuncMateInfo;
	
	private String vFuncMatePermitNmInfo;
	
	private String vManagementNum;
	
	private Object releaseMap;
	
	private int nSeqno;
	
	private String vDosageNm1;
	
	private String vDosageNm2;
	
	private String vDosageNm3;
	
	private String vLot;
	
	private String vSeq;
	
	private String vQmsPlantCd;
	
	private int seqno;
	
	private String vMateCd;
	
	private String vMateCdNm;
	
	private String vMateCdPer;
	
	private int nIfCode;
	
}
