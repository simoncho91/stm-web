package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class LabNoteDecideDTO extends ParentDTO {
	@JsonProperty("vMatePkCd")
	private String vMatePkCd;

	@JsonProperty("vMateCd")
	private String vMateCd;

	@JsonProperty("vMateNm")
	private String vMateNm;

	@JsonProperty("nSort")
	private int nSort;

	@JsonProperty("nRate")
	private int nRate;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vLotCd")
	private String vLotCd;
}
