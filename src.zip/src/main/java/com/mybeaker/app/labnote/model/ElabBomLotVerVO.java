package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@Data
public class ElabBomLotVerVO extends ParentDTO {

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("vBomLotVer")
	private String vBomLotVer;

	@JsonProperty("vBomType")
	private String vBomType;
	
	@JsonProperty("vBomSendType")
	private String vBomSendType;
	
	@JsonProperty("vBomSendMessage")
	private String vBomSendMessage;

	@JsonProperty("vTempPkCd")
	private String vTempPkCd;

	@Builder
	public ElabBomLotVerVO(String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm,
			String vLabNoteCd, String vLotCd, String vBomLotVer, String vBomType, String vBomSendType,
			String vBomSendMessage, String vTempPkCd) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.vLabNoteCd = vLabNoteCd;
		this.vLotCd = vLotCd;
		this.vBomLotVer = vBomLotVer;
		this.vBomType = vBomType;
		this.vBomSendType = vBomSendType;
		this.vBomSendMessage = vBomSendMessage;
		this.vTempPkCd = vTempPkCd;
	}
}
