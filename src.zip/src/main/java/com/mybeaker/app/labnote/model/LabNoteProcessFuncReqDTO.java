package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.approval.model.ReqResApprovalDTO;
import com.mybeaker.app.model.dto.ParentPagingDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper = true)
public class LabNoteProcessFuncReqDTO extends ParentPagingDTO{

	@JsonProperty("vNoteType")
	private String vNoteType;
	
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("vRequestStDt")
	private String vRequestStDt;
	
	@JsonProperty("vRequestEdDt")
	private String vRequestEdDt;
	
	@JsonProperty("vFinishStDt")
	private String vFinishStDt;
	
	@JsonProperty("vFinishEdDt")
	private String vFinishEdDt;
	
	@JsonProperty("vApprStatus")
	private String vApprStatus;
	
	@JsonProperty("vApprCd")
	private String vApprCd;
	
	@JsonProperty("vKeyword")
	private String vKeyword;
	
	private String localLanguage;
	
	@JsonProperty("vFlagReport")
	private String vFlagReport;
	
	@JsonProperty("vLabNoteVer")
	private String vLabNoteVer;
	
	@JsonProperty("vLabNoteSeqno")
	private String vLabNoteSeqno;
	
	@JsonProperty("vRecordid")
	private String vRecordid;
	
	@JsonProperty("vFlagSaveAction")
	private String vFlagSaveAction;
	
	@JsonProperty("nFdnVer")
	private int nFdnVer;
	
	@JsonProperty("nVersion")
	private int nVersion;
	
	@JsonProperty("nLatestVersion")
	private int nLatestVersion;
	
	@JsonProperty("vFlagLotDecide")
	private String vFlagLotDecide;
	
	@JsonProperty("vStatusCd")
	private String vStatusCd;
	
	@JsonProperty("vContPkCd")
	private String vContPkCd;
	
	@JsonProperty("vFlagCompleteDtmDel")
	private String vFlagCompleteDtmDel;
	
	@JsonProperty("vFlagComplete")
	private String vFlagComplete;
	
	@JsonProperty("vRegUserid")
	private String vRegUserid;
	
	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;

	@JsonProperty("vFlagNameModAuth")
	private String vFlagNameModAuth;
	
	@JsonProperty("arrDecideContList")
	private List<LabNoteProcessFuncDecideReqDTO> arrDecideContList;
	
	@JsonProperty("vApprTypeCd")
	private String vApprTypeCd;
	
	@JsonProperty("apprReqInfo")
	private ReqResApprovalDTO apprReqInfo;
}
