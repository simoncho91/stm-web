package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ProductVO {
	
	// 모제품 검색 > E-LABNOTE
	@JsonProperty("vContCd")
	private String vContCd;
	
	@JsonProperty("vContNm")
	private String vContNm;
	
	@JsonProperty("vLotCd")
	private String vLotCd;
	
	@JsonProperty("vLotNm")
	private String vLotNm;
	
	@JsonProperty("vInnerPlant")
	private String vInnerPlant;
	
	@JsonProperty("nNoteVersion")
	private String nNoteVersion;
	
	@JsonProperty("vMakerNm")
	private String vMakerNm;
	
	@JsonProperty("vCompanynm")
	private String vCompanynm;
	
	@JsonProperty("vType")
	private String vType;
	
	// 모제품 검색 > SAP
//	@JsonProperty("vWerks")
//	private String vWerks;
//
//	@JsonProperty("vMatnr")
//	private String vMatnr;
//
//	@JsonProperty("vMaktx")
//	private String vMaktx;
	
	// 모제품 검색 > ODM
//	@JsonProperty("vProductCd")
//	private String vProductCd;
//	
//	@JsonProperty("vProductNm")
//	private String vProductNm;
}
