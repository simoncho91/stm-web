package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class FuncDecideContNameVO {

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vFlagRepresent")
	private String vFlagRepresent;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("nVer")
	private int nVer;

	@JsonProperty("vStatusCd")
	private String vStatusCd;

	@JsonProperty("vStatusNm")
	private String vStatusNm;

	@JsonProperty("vApprCd")
	private String vApprCd;

	@JsonProperty("vDecideContNm")
	private String vDecideContNm;

	@JsonProperty("vRegUserid")
	private String vRegUserid;

	@JsonProperty("vRegUsernm")
	private String vRegUsernm;

	@JsonProperty("vFlagDel")
	private String vFlagDel;

	@JsonProperty("vRegDtm")
	private String vRegDtm;

	@JsonProperty("vCompleteDtm")
	private String vCompleteDtm;

	@JsonProperty("vDecNameNum")
	private String vDecNameNum;
	
}
