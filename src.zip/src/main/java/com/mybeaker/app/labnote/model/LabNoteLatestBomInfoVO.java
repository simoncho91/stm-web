package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LabNoteLatestBomInfoVO {

	@JsonProperty("vSendDatetime")
	private String vSendDatetime;

	@JsonProperty("nSendSeq")
	private int nSendSeq;

	@JsonProperty("vMatnr")
	private String vMatnr;

	@JsonProperty("vPosnr")
	private String vPosnr;

	@JsonProperty("vIdnrk")
	private String vIdnrk;

	@JsonProperty("nMenge")
	private int nMenge;

	@JsonProperty("vFlagDel")
	private String vFlagDel;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vWerks")
	private String vWerks;

	@JsonProperty("vContPkCd")
	private String vContPkCd;
	
	@JsonProperty("vRawPer")
	private String vRawPer;
}
