package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentPagingDTO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class CompleteCounterSearchReqDTO extends ParentPagingDTO {
	@JsonProperty("vKeyword")
	private String vKeyword;

	@JsonProperty("vCodeType")
	private String vCodeType;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("vFlagNp")
	private String vFlagNp;

	private String vUserid;

	private String localLanguage;
}
