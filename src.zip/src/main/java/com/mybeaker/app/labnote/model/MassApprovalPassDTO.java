package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MassApprovalPassDTO {
	@JsonProperty("vApprCd")
	private String vApprCd;
	
	@JsonProperty("nCurRegseq")
	private int nCurRegseq;
	
	@JsonProperty("nCurApprseq")
	private int nCurApprseq;
	
	@JsonProperty("vApprClass")
	private String vApprClass;
	
	@JsonProperty("vApprStatus")
	private String vApprStatus;
	
	@JsonProperty("vApprStatusnm")
	private String vApprStatusnm;
	
	@JsonProperty("vDraftUserid")
	private String vDraftUserid;
	
	@JsonProperty("vDraftUsernm")
	private String vDraftUsernm;
	
	@JsonProperty("vDraftDeptnm")
	private String vDraftDeptnm;
	
	@JsonProperty("vDraftOffinm")
	private String vDraftOffinm;
	
	@JsonProperty("vDraftPositcd")
	private String vDraftPositcd;
	
	@JsonProperty("vDraftPositnm")
	private String vDraftPositnm;
	
	@JsonProperty("vDraftDutynm")
	private String vDraftDutynm;
	
	@JsonProperty("vDraftTitle")
	private String vDraftTitle;
	
	@JsonProperty("vDraftDtm")
	private String vDraftDtm;
	
	@JsonProperty("vDraftOpinion")
	@Builder.Default
	private String vDraftOpinion = "";
	
	@JsonProperty("nApprStatusCnt")
	private int nApprStatusCnt;
	
	@JsonProperty("vDraftPhoneno")
	private String vDraftPhoneno;
	
	@JsonProperty("vDraftEmail")
	private String vDraftEmail;
	
	@JsonProperty("vApprSubStatus")
	private String vApprSubStatus;

	@JsonProperty("vApprType")
	private String vApprType;

	@JsonProperty("vApprTypenm")
	private String vApprTypenm;

	@JsonProperty("vApprUsernm")
	private String vApprUsernm;

	@JsonProperty("vApprUserid")
	private String vApprUserid;

	@JsonProperty("vApprDtm")
	private String vApprDtm;

	@JsonProperty("vApprOpinion")
	private String vApprOpinion;

	@JsonProperty("vApprUserType")
	private String vApprUserType;

	@JsonProperty("vApprClassnm")
	private String vApprClassnm;

	@JsonProperty("vUrl")
	private String vUrl;

	@JsonProperty("vEmail")
	private String vEmail;

	@JsonProperty("vDraftUserEmail")
	private String vDraftUserEmail;
	
	@JsonProperty("vResultStatus")
	private String vResultStatus;
	
	@JsonProperty("vTitle")
	private String vTitle;
	
	@JsonProperty("vApprTitle")
	private String vApprTitle;

	@JsonProperty("nTotCnt")
	private int nTotCnt;
	
	@JsonProperty("nMassApprCnt")
	private int nMassApprCnt;
}
