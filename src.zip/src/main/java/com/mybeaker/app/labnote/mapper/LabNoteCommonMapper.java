package com.mybeaker.app.labnote.mapper;

import java.util.List;

import javax.validation.Valid;

import org.apache.ibatis.annotations.Mapper;

import com.mybeaker.app.approval.model.ApprovalDTO;
import com.mybeaker.app.common.model.AlarmDTO;
import com.mybeaker.app.common.model.CodeDTO;
import com.mybeaker.app.common.model.CommUserDesSearchInfoDTO;
import com.mybeaker.app.common.model.MessageDTO;
import com.mybeaker.app.labnote.model.*;
import com.mybeaker.app.model.dto.ReqCommSearchInfoDTO;
import com.mybeaker.app.skincare.model.ElabLotMemoVO;
import com.mybeaker.app.skincare.model.ShelfLifeReqDTO;

@Mapper
public interface LabNoteCommonMapper {

	int selectPtsProjectListCount(LabNoteCommonReqProjectSearchDTO reqProjectSearchDTO);

	List<LabNoteCommonProjectDTO> selectPtsProjectList(LabNoteCommonReqProjectSearchDTO reqProjectSearchDTO);

	String selectZqmtExistsMatnrInfo(LabNoteCommonReqSAPSyncDTO reqSAPSyncDTO);

	String selectZqmtContNm(LabNoteCommonReqSAPSyncDTO reqSAPSyncDTO);

	int insertElabNoteFinalLotSAPInfo(LabNoteCommonSAPSyncDTO sapSyncDTO);

	int selectSearchMateListCount(LabNoteCommonReqSearchMateDTO labNoteCommonReqSearchMateDTO);

	List<LabNoteCommonSearchMateDTO> selectSearchMateList(LabNoteCommonReqSearchMateDTO labNoteCommonReqSearchMateDTO);

	List<LabNoteCommonMateCheckDTO> selectCheckClearList(List<String> arrMaterialCd, String vType);

	int selectSearchMateTempListCount(LabNoteCommonReqSearchMateDTO labNoteCommonReqSearchMateDTO);

	List<LabNoteCommonSearchMateDTO> selectSearchMateTempList(
			LabNoteCommonReqSearchMateDTO labNoteCommonReqSearchMateDTO);

	int selectSearchMyMateListCount(LabNoteCommonReqSearchMateDTO labNoteCommonReqSearchMateDTO);

	List<LabNoteCommonSearchMateDTO> selectSearchMyMateList(
			LabNoteCommonReqSearchMateDTO labNoteCommonReqSearchMateDTO);

	int selectEvaluationListCount(LabNoteCommonReqSearchEvalDTO labNoteCommonReqEvaluationDTO);

	List<LabNoteCommonEvaluationDTO> selectEvaluationList(LabNoteCommonReqSearchEvalDTO labNoteCommonReqSearchEvalDTO);

	List<LabNoteCommonTddProdTypeDTO> selectTddProdTypeList(String vFlagSub, String vNoteType, String vClassCd);

	int selectSearchProdListCount(LabNoteCommonReqProdSearchDTO labNoteCommonReqProdSearchDTO);

	List<LabNoteCommonProdSearchDTO> selectSearchProdList(LabNoteCommonReqProdSearchDTO labNoteCommonReqProdSearchDTO);

	List<LabNoteCommonAuthDeptDTO> selectAuthDeptInfo();

	int deleteLabNoteAuthDept();

	int insertLabNoteAuthDept(LabNoteCommonAuthDeptDTO labNoteCommonAuthDeptDTO);

	int selectEvaluationMaterialListCount(LabNoteCommonReqEvalMateSearchDTO labNoteCommonReqEvalMateSearchDTO);

	List<LabNoteCommonEvalMaterialDTO> selectEvaluationMaterialList(
			LabNoteCommonReqEvalMateSearchDTO labNoteCommonReqEvalMateSearchDTO);

//	원료배합 start
	public int updateSAPRepeat(ElabIngredientCheckVO elabIngredientCheckVO);

	public String selectZplmt13Tx(ElabIngredientCheckVO elabIngredientCheckVO);

	public ElabIngredientCheckVO selectElabIngredientCheck(ElabIngredientCheckVO elabIngredientCheckVO);

	public int insertElabIngredientCheck(ElabIngredientCheckVO elabIngredientCheckVO);

	public List<MdlRequiredMaxVO> selectMdlRequiredMaxList(MdlReqDTO reqDTO);

	public int deleteElabHal4Mate(ElabHal4MateVO elabHal4MateVO);

	public int insertElabHal4Mate(ElabHal4MateVO elabHal4MateVO);

	public List<Zplmt12MstVO> selectZplmt12MstList(ScmTCodeReqVO reqVO);

	public List<Zplmt12GlbVO> selectZplmt12GlbList(ScmTCodeReqVO reqVO);

	public List<ElabTroubleHisVO> selectScmTcodeList(ScmTCodeReqVO reqVO);

	public List<Zplmt12GlbDescVO> selectZplmt12GlbDesc(Zplmt12ReqVO reqVO);

	public Zplmt12MstVO selectZplmt12MstInfo(Zplmt12ReqVO reqVO);

	public List<MaxMixResDTO> selectLabNoteMaxMixMrqList(MaxMixVO reqVO);

	public int insertELabHisLotChg(ElabHisLotChgVO elabHisLotChgVO);

	public int deleteElabNoteLatestBomInfo(LabNoteLatestBomInfoVO labNoteLatestBomInfoVO);

	public int insertElabNoteLatestBomInfo(LabNoteLatestBomInfoVO labNoteLatestBomInfoVO);

	public int updateLabNoteSendContToCpc(ProcCpcVO procCpcVO);

	public int updateLabNoteSendBomToCpc(ProcCpcVO procCpcVO);

	public int insertLabNotePrecedeBomHeader(ElabPrecedeBomHeaderVO elabPrecedeBomHeaderVO);

	public int insertElabBomLotVer(ElabBomLotVerVO elabBomLotVerVO);

	public int updateElabBomLotVerType(ElabBomLotVerVO elabBomLotVerVO);

	public List<ShelfLifeVO> selectOneShelfLifeContInfo(ShelfLifeVO shelfLifeVO);
//	원료배합 end

	public int updateShelfLifeStatus(ShelfLifeVO shelfLifeVO);

	public ShelfLifeVO selectElabShelfLifeInfoVerSap(String vContCd);

	public String selectStringElabBomLotVer(String vLotCd, String vApprCd);

	public int deleteShelfLifeInfoSubBContCd(String vContCd);

	public int deleteShelfLifeInfoCont(String vContCd);

	public PgcGqteResVO selectPqcGqteResInfo(String vApprCd);

	public FuncDecideNameVO selectLabNoteFuncDecideNameInfoVerAppr(String vApprCd);

	public int updateLabNoteFuncDecideName(FuncDecideNameVO funcDecideNameVO);

	public ElabShelflifeMstVO selectDOCShelflifeMSTView(ElabShelflifeMstVO elabShelflifeMstVO);

	public int updateShelfListMstStatus(String vStatusCd, String vRecordId);

	public List<ElabShelflifeSubVO> selectBeforeShelfLife(String vRecordId);

	public int updateShelfListContStatus(ElabShelflifeContVO elabShelflifeContVO);

	public int insertChangeInfo(ElabShelflifeHisVO elabShelflifeHisVO);

	public List<ElabShelflifeTddInfoVO> selectElabShelfLifeTddInfoList(ElabShelflifeTddInfoVO elabShelflifeTddInfoVO);

	public List<ElabShelflifeTddContVO> selectElabShelfLifeTddContList(ElabShelflifeTddContVO elabShelflifeTddContVO);

	public int updateTdd3ShelfLife(String vShelfLife, String vRecordId);

	public int updateTdd2ShelfLife(String vShelfLife, String vRecordId);

	public int updateTddCnShelfLife(String vShelfLife, String vRecordId);

	public List<SupGlobalMailUserVO> selectElabShelfLifeGlobalSupList(String vProductCd);

	public int updateGlobalSupShelfLife(SupGlobalMailUserVO globalMailUserVO);

	public int updateGlobalSupShelfLifeCn(SupGlobalMailUserVO globalMailUserVO);

	public List<SupGlobalMailUserVO> selectElabShelfLifeGlobalSupSendMailUserList(SupGlobalMailUserVO globalMailUserVO);

	public int updateBackShelfLifeMST(ShelfLifeVO shelfLifeVO);

	public int updateBackShelfLifeCONT(ShelfLifeVO shelfLifeVO);

	public List<ElabShelflifeSubVO> selectDOCShelflifeCONTView(String vRecordId, String localLanguage);

	List<ElabSafeTestDTO> selectLabNoteSafeTestInfoList(String vLabNoteCd, String vSapCd);

	void updateLabNoteSafeTestProductNm(ElabSafeTestDTO safeDTO);

	void updateLabNoteSafeTestProductVerNm(ElabSafeTestDTO safeDTO);

	void insertLabNoteSafeTestHist(ElabSafeTestDTO saveDTO);

	void deleteNoteRecentLog(LabNoteCommonRecentDTO recentDTO);

	void deleteNoteRecentLogCont(LabNoteCommonRecentDTO recentDTO);

	void insertNoteRecentLog(LabNoteCommonRecentDTO recentDTO);

	List<LabNoteCommonRecentDTO> selectSkincareNoteRecentLogList(LabNoteCommonRecentDTO recentDTO);

	List<LabNoteCommonRecentDTO> selectMakeupNoteRecentLogList(LabNoteCommonRecentDTO recentDTO);

	List<LabNoteCommonRecentDTO> selectHbdNoteRecentLogList(LabNoteCommonRecentDTO recentDTO);

	List<LabNoteCommonRecentDTO> selectQdrugNoteRecentLogList(LabNoteCommonRecentDTO recentDTO);

	List<LabNoteCommonProjectDTO> selectLabCodeRequired(String vDeptCd);

	public List<ElabNoteMstSetVO> selectNoteMstSetList(String vLabNoteCd);

	int selectLabNoteZmdMaterialMaxSeqno(String vLabNoteCd);

	void insertSAPMaterialReqVerPlantExp(ZmdMaterialReqDTO zmdDTO);

	int selectShelfLifePlantCount(String vContCd);

	void updateSubPlantFlag(String vContCd);

	void insertShelfLifeSubPlant(String vContCd, String vPlantCd, String vRegUserid);

	void insertShelfListHis(String vContCd, String vChangeReason, String vRegUserid);

	List<ElabShelflifeContVO> selectShelfLifePlant(PlantChangeReqDTO plantChangeDTO);

	String selectShelfOldPlantCd(String vContCd);

	void updateShelfLifeContPlant(String vPlantCd, String vContCd);

	void deleteShelfLifeSubPlant(String vContCd);

	int selectLabNoteAuthorityListCount(ElabChgLogSearchReqDTO searchReqDTO);

	List<CommUserDesSearchInfoDTO> selectLabNoteAuthorityList(ElabChgLogSearchReqDTO searchReqDTO);

	int deleteLabNoteAuthority(LabNoteAuthorityReqDTO reqDTO);

	int insertLabNoteAuthority(LabNoteAuthorityReqDTO reqDTO);

	public void updateLabNoteFuncDecideNameAllLastN(LabNoteProcessFuncReqDTO reqDTO);

	public void insertLabNoteFuncDecideName(LabNoteProcessFuncReqDTO reqDTO);

	public void updateLabNoteMstSet(ElabNoteMstSetVO mstSetVO);

	public void updateLabNoteFuncDecideName(LabNoteProcessFuncReqDTO reqDTO);

	public void insertLabNoteFuncDecideContName(LabNoteProcessFuncDecideReqDTO decideCont);

	public void updateLabNoteFuncDecideContName(LabNoteProcessFuncDecideReqDTO decideCont);

	public void deleteLabNoteFuncDecideContName(LabNoteProcessFuncDecideReqDTO decideCont);

	public void deleteLabNoteFuncDecideName(LabNoteProcessFuncReqDTO reqDTO);

	public int selectLabNoteFuncDecideNameMaxVer(LabNoteProcessFuncReqDTO reqDTO);

	public String selectLabNoteDecideContNm(String vLabNoteCd);

	public int insertEpReport(@Valid LabNoteCommonWokReportReqDTO reqDTO);

	public void insertLabFuncToNewFunc(@Valid LabNoteProcessFuncReportReqPopDTO reqDTO);

	public List<ElabContQmsVO> selectElabContQmsInfo(LabNoteProcessFuncReportResPopDTO funcReqVo);

	public String selectEpReportSeq();

	public SupGlobalMailUserVO selectUserEmail(String vSenderId);

	public List<ElabShelflifeSubVO> selectSubPlantList(String vContCd, String localLanguage);

	int deleteShelfLifeInfo(String vRecordId);

	int deleteShelfLifeInfoSUB(String vRecordId);

	int insertShelfLifeInfoMst(ElabShelflifeMstVO mstVO);

	int updateShelfLifeInfoCont(String vContCd);

	int insertShelfLifeInfoSUB(ElabShelflifeSubVO subVO);

	int insertShelfLifeInfoCont(ElabShelflifeContVO contVO);

	int insertShelfLifeApprCd(String vApprCd, String vRecordid);

	public List<ElabContQmsVO> selectElabQmsLotInfo(ElabContQmsReqVO qmsReqDTO);

	List<CommUserDesSearchInfoDTO> selectGroupUserRetireList(LabNoteProcessFuncReportUserReqDTO reqDTO);

	void insertRequestQaCont(@Valid LabNoteProcessFuncReportReqSaveDTO reqDTO);

	void insertLabNoteFuncQaUser(@Valid LabNoteProcessFuncReportReqSaveDTO reqDTO);

	List<String> selectLabNoteFuncQaUserList(@Valid LabNoteProcessFuncReportReqSaveDTO saveReqDTO);

	int insertQmsReportIF(LabNoteProcessFuncReportDataDTO fvo);

	void insertQmsRawInfoIF(LabNoteProcessFuncReportDataDTO fvo);

	String selectApplyPqcCd(LabNotePqcGateCheckReqDTO checkDTO);

	List<LabNotePqcGateCheckListDTO> selectPqcGateCheckList(LabNotePqcGateCheckReqDTO checkDTO);

	List<LabNotePqcResItemListDTO> selectElabPqcResItemList(LabNotePqcGateCheckReqDTO checkDTO);

	int selectLabNoteIngrtCautionListCnt(String contCd);

	LabNotePqcResItemListDTO selectLabNoteG1gqmsInfo(String vPqcGate1ResCd);

	LabNoteMatrMixreInfoVO selectMatrMixreInfo(String vConcd);

	int insertSAPIngredientApproval(Zplmt14VO vo);

	int insertSAPIngredientRate(Zplmt13VO vo);

	String checkFlagFreePass(PilotRequestDetailReqDTO ppilotRequestDetailReqDTO);

	List<LabNotePqcGateCheckListDTO> selectPqcGateResItemList(String vPqcResCd);

	List<PgcGqteResVO> selectElabPqcResLotList(String vPqcResCd);

	void insertElabPqcRes(@Valid LabNoteProcessPqcCheckApprReqDTO reqDTO);

	void updateElabPqcResItem(LabNotePqcGateCheckListDTO tvo);

	void insertElabPqcResItem(LabNotePqcGateCheckListDTO tvo);

	void deleteElabPqcResItem(LabNotePqcResItemListDTO itemDTO);

	void updateElabPqcRes(@Valid LabNoteProcessPqcCheckApprReqDTO reqDTO);

	void insertElabPqcResLot(@Valid LabNoteProcessPqcCheckApprReqDTO reqDTO);

	String selectLabNoteExistsAerosolDecide(String vContPkCd);

	List<BomInfoVO> selectMat6CodeList(List<BomInfoVO> arrCodeList);

	List<BomInfoVO> selectMat4CodeList(List<BomInfoVO> arrCodeList);

	List<BomInfoVO> setSaIngrHal4Check(List<BomInfoVO> bomList);

	int selectVersionHistoryMstCount(LabNoteVersionModifyReqDTO labNoteVersionModifyReqDTO);

	List<ProductVersionHistoryDTO> selectProductVersionHistoryMstList(String vLabNoteCd, String localLanguage);

	List<ShelfLifeVO> selectOneShelfLifeContInfo(@Valid ShelfLifeReqDTO reqDTO);

	String selectLabNoteApprBomInfoApprCdTemp();

	public int insertElabLotMemo(ElabLotMemoVO elabLotMemoVO);

	int selectMyBoardAlarmListCount(ReqCommSearchInfoDTO reqDTO);

	List<AlarmDTO> selectMyBoardAlarmList(String vUserid);

	// 모제품 검색 > E-LABNOTE
	public int selectSafetyElabNoteListCount(LabNoteCommonReqSafetyContentsSearchDTO reqDTO);

	public List<ProductVO> selectSafetyElabNoteList(LabNoteCommonReqSafetyContentsSearchDTO reqDTO);

	// 모제품 검색 > SAP
	public int selectProductListCount(LabNoteCommonReqSafetyContentsSearchDTO reqDTO);

	public List<ProductVO> selectProductList(LabNoteCommonReqSafetyContentsSearchDTO reqDTO);

	// 모제품 검색 > ODM
	public int selectOdmProductListCount(LabNoteCommonReqSafetyContentsSearchDTO reqDTO);

	public List<ProductVO> selectOdmProductList(LabNoteCommonReqSafetyContentsSearchDTO reqDTO);

	List<ApprovalDTO> selectMyBoardApprovalList(String vUserid);

	List<MyBoardMemoDTO> selectMyBoardMemoList(String loginId);

	void updateMyBoardMemo(MyBoardMemoDTO myboardMemoDTO);

	void insertMyBoardMemo(MyBoardMemoDTO myboardMemoDTO);

	void deleteMyBoardMemo(MyBoardMemoDTO myboardMemoDTO);

	void updateEpReport(LabNoteCommonWokReportReqDTO wokReportVo);

	public int deleteTrComponent(SupTrComponentVO supTrComponentVO);

	public List<LabNoteComponentVerVO> selectLabNoteComponentVer2(LabNoteComponentVerVO labNoteComponentVerVO);

	public int insertTrLabNoteComponent2(List<LabNoteComponentVerVO> labNoteList);

	public List<SupTrComponentVO> selectMosMatnrTempList(SupTrComponentVO supTrComponentVO);

	public MosInfoVO selectMosCalCulInfo(MosInfoVO mosInfoVO);

	public MosInfoVO selectTddProdMosInfo(MosInfoVO mosInfoVO);

	public int deleteMosStandard(SupTrMosStandardVO supTrMosStandardVO);

	public int insertMosStandard(SupTrMosStandardVO supTrMosStandardVO);

	public int deleteMosComponent(SupTrMosComponentVO supTrMosComponentVO);

	public int insertMosComponent(List<SupTrMosComponentVO> mosCompList);

	public List<SupTrCategoryAccVO> selectCategoryEssenList(SupTrCategoryAccVO supTrCategoryAccVO);

	public int insertEssentialTest(SupTrEssentialTestVO supTrEssentialTestVO);

	public List<SupTrLabNoteTagVO> selectNoteEssenList(String vLabNoteCd);

	public List<CodeDTO> selectReqTestMethodList(List<String> testItemCdList);

	public TddProductClassVO selectTddProductValue(String vTargetTddProduct);

	public String selectChinaSafetyElabBrandSubCode(String vBrandCd);

	public CpsrTesterUserVO selectChinaSafetyReviewUser(String vBrandCd);

	public int insertChinaSafetyEv(ChinaSafetyMstVO chinaSafetyMstVO);

	public int insertChinaSafetyMsgLog(ChinaSafetyMsgVO chinaSafetyMsgVO);

	public List<TddProductClassVO> selectTddProductClassList(String vPid);

	public void checkPQCShelfLife(String vApprCd);

	public List<TestReqCounterMrq011DTO> selectCounterMrq011List(String vTrProductCd, int nTrVersion);

	public String selectStringMrq011CheckSapCd(@Valid LabNoteTestReqDTO reqDTO);

	List<MessageDTO> selectMessageList(String vRecordid, String localLanguage);

	int insertMessage(MessageDTO messageDTO);

	List<LabNoteProcessProgressDTO> selectProgressInfo(String vLabNoteCd, String vPageType);

	List<ScheduleDTO> selectNoteDetailScheduleList(String vLabNoteCd);

	String selectLabNoteActiveStatus(String vStatusCd);

	public int insertShelfLifeCont(ElabShelflifeContVO elabShelflifeContVO);

	List<LabNoteProcessProgressDTO> selectMyboardScheduleStatusList();

	List<String> selectMaterialIssueList(String vSapCd);

	List<String> selectMaterialScmIssueList(String vSapCd);

	int insertLabNoteMyMate(MaterialMateRegDTO regDTO);

	int deleteLabNoteMyMate(MaterialMateRegDTO regDTO);

	List<LabNoteCommonSearchMateDTO> selectSearchMateAutocompleteList(LabNoteCommonReqSearchMateDTO mateReqDTO);

	List<LabNoteCommonSearchMateDTO> selectRecentMateList(List<String> arrKey, String vUserid);

	List<LotStatusDTO> selectLotStatusList(String vLabNoteCd);

	List<SupTrProductVO> selectDupleNoteCheckList(String vSapCd, String vLabNoteCd, String vLotCd);

	public LabNoteCommonSearchMateDTO selectLabNoteExcelHal4Mate(String vMateCd);

	public String selectEpReportRootDocCls(WokReportReqDTO wokReqDTO);

	public void updateReportViewCount(WokReportReqDTO wokReqDTO);

	public WokReportResDTO selectEpReport(WokReportReqDTO wokReqDTO);

	public int selectLabNoteAuthorityCount(LabNoteAuthorityReqDTO reqDTO);

	public List<WokReportMatResDTO> selectEpReportMat(WokReportReqDTO wokReqDTO);

	public void insertTrProductIf(SupTrPrdIFDTO trIfDTO);

	public int updateEpReportStatus(@Valid ReportApprovalReqDTO reportReqDTO);

	public String selectReportFinishNo(String vRecordid);

	public void updateReportFinishNo(String vRecordid, String vReportFinishno);

	List<RcvFirstSaleDateDTO> selectSingleContReleaseDateList(String vContCd);

	List<RcvFirstSaleDateDTO> selectMultiContReleaseDateList(List<?> contList);

	public List<WokReportSecretResDTO> selectEpReportSecret(String vRecordid);

	List<BatchStatusProcessVO> selectStockProcessTargetList();

	List<BatchStatusProcessVO> selectReleaseProcessTargetList();

	public String selectLabNoteLaborCd(String vUserid);

	List<LabNoteCommonRequestMateDTO> selectFuncMateList(String vEvaluateCd, List<String> arrFunctionCd);

	void insertBrandManagerGroupUser(BrandManagerGroupDTO dto);

	List<SapBiodRsltPerDTO> selectBiodRsltValueUpdateList();

	void updateSapBiodRsltValue(SapBiodRsltPerDTO bioVo);
}
