package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ElabShelflifeMstVO {

	@JsonProperty("vRecordid")
	private String vRecordid;

	@JsonProperty("vStatusCd")
	private String vStatusCd;

	@JsonProperty("vStatusCdNm")
	private String vStatusCdNm;

	@JsonProperty("vDocKind")
	private String vDocKind;

	@JsonProperty("vDocKindNm")
	private String vDocKindNm;

	@JsonProperty("vNoteType")
	private String vNoteType;

	@JsonProperty("vNoteTypeNm")
	private String vNoteTypeNm;

	@JsonProperty("vShelfLife")
	private String vShelfLife;

	@JsonProperty("vFlagAll")
	private String vFlagAll;

	@JsonProperty("vChangeReason")
	private String vChangeReason;

	@JsonProperty("vApprCd")
	private String vApprCd;

	@JsonProperty("vRegUserid")
	private String vRegUserid;
	
	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;

	@JsonProperty("vUsernm")
	private String vUsernm;

	@JsonProperty("vUpdateDtm")
	private String vUpdateDtm;

	@JsonProperty("vShelfLifeTxt")
	private String vShelfLifeTxt;

	@JsonProperty("vTitle")
	private String vTitle;

	private String localLanguage;

}
