package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteMatrMixreInfoVO {

	@JsonProperty("vConcd")
	private String vConcd;

	@JsonProperty("vZconcd")
	private String vZconcd;

	@JsonProperty("vZabcde")
	private String vZabcde;

	@JsonProperty("vMixre")
	private String vMixre;

	@JsonProperty("vTdline")
	private String vTdline;

	@JsonProperty("vZglobal")
	private String vZglobal;

	@JsonProperty("vZglbtxt")
	private String vZglbtxt;

	@JsonProperty("vZcertTxt")
	private String vZcertTxt;

	@JsonProperty("vZcertTxtEn")
	private String vZcertTxtEn;

}
