package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LabNoteSapBomToConInfoVO {

	@JsonProperty("vConcd")
	private String vConcd;

	@JsonProperty("nConPer")
	private String nConPer;

	@JsonProperty("nSumPer")
	private String nSumPer;

	@JsonProperty("vCasno")
	private String vCasno;

	@JsonProperty("vPsnameKo")
	private String vPsnameKo;

	@JsonProperty("vPsnameEn")
	private String vPsnameEn;

	@JsonProperty("vPsnameCh")
	private String vPsnameCh;

	@JsonProperty("vFcnameKo")
	private String vFcnameKo;

	@JsonProperty("vFcnameEn")
	private String vFcnameEn;

	@JsonProperty("vZabcde")
	private String vZabcde;

	@JsonProperty("vZconcd")
	private String vZconcd;

	@JsonProperty("vMixre")
	private String vMixre;

	@JsonProperty("vZglobal")
	private String vZglobal;

	@JsonProperty("vZgubcl")
	private String vZgubcl;

	@JsonProperty("vZgllim")
	private String vZgllim;

	@JsonProperty("vZobli")
	private String vZobli;

	@JsonProperty("vZnotice")
	private String vZnotice;

	@JsonProperty("vZnoticeEn")
	private String vZnoticeEn;

	@JsonProperty("vZnoticeZh")
	private String vZnoticeZh;

	@JsonProperty("vZdisplayLt")
	private String vZdisplayLt;

	@JsonProperty("vZwarningLt")
	private String vZwarningLt;

	@JsonProperty("vZwarningLtEn")
	private String vZwarningLtEn;

	@JsonProperty("vZwarningLtZh")
	private String vZwarningLtZh;

	@JsonProperty("vZarjcd")
	private String vZarjcd;

	@JsonProperty("vGcode")
	private String vGcode;

	@JsonProperty("vGctxt")
	private String vGctxt;

	@JsonProperty("vGban")
	private String vGban;

	@JsonProperty("vGband")
	private String vGband;

	@JsonProperty("vGlmt")
	private String vGlmt;

	@JsonProperty("vGlmtd")
	private String vGlmtd;

	@JsonProperty("vGlper")
	private String vGlper;

	@JsonProperty("nCntGban")
	private int nCntGban;

	@JsonProperty("nCntGlmt")
	private int nCntGlmt;

	@JsonProperty("vGbanGctxt")
	private String vGbanGctxt;

	@JsonProperty("vGlmtGctxt")
	private String vGlmtGctxt;

	@JsonProperty("vGbanTxt")
	private String vGbanTxt;

	@JsonProperty("vGlmtTxt")
	private String vGlmtTxt;

	@JsonProperty("vLegalYn")
	private String vLegalYn;

	@JsonProperty("vEwgGrade")
	private String vEwgGrade;

	@JsonProperty("nEwgGradeNum")
	private int nEwgGradeNum;

	@JsonProperty("nConPerA")
	private String nConPerA;

}
