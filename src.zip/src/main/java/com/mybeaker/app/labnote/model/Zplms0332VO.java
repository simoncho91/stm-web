package com.mybeaker.app.labnote.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Zplms0332VO {

	private String concd;
	
	private String casno;
	
	private String enva1;
	
	private String znoel;
	
	private String toxicokinetics;
	
	private String conper;
}
