package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class MaterialMateRegDTO {

	@JsonProperty("vType")
	private String vType;

	@JsonProperty("vMateCd")
	private String vMateCd;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vRegUserid")
	private String vRegUserid;
}
