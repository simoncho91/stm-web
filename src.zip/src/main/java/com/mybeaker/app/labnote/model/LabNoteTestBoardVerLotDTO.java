package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LabNoteTestBoardVerLotDTO {
	
	@JsonProperty("vSapCd")
	private String vSapCd;
	
	@JsonProperty("nLabNoteVer")
	private int nLabNoteVer;
	
	@JsonProperty("vLotNm")
	private String vLotNm;
	
	@JsonProperty("vClinicalTestYn")
	private String vClinicalTestYn;
	
	
}
