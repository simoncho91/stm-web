package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LabNoteProcessFuncDecideReqDTO{
	
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("nFdnVer")
	private int nFdnVer;
	
	@JsonProperty("vNoteType")
	private String vNoteType;
	
	@JsonProperty("vRegUserid")
	private String vRegUserid;
	
	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;
	
	@JsonProperty("vContPkCd")
	private String vContPkCd;
	
	@JsonProperty("vDecideContNm")
	private String vDecideContNm;
	
	@JsonProperty("vFlagNmDel")
	private String vFlagNmDel;
	
	
}
