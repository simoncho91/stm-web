package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteTestReqTodoRegDTO {

	@JsonProperty("vRegUserid")
	private String vRegUserid;
	
	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;
	
	@JsonProperty("vMstTableNm")
	private String vMstTableNm;
	
	@JsonProperty("vRecordCd")
	private String vRecordCd;
	
	@JsonProperty("vTitle")
	private String vTitle;
	
	@JsonProperty("vOwnerCd")
	private String vOwnerCd;
	
	@JsonProperty("vOwnerType")
	private String vOwnerType;
	
	@JsonProperty("vTodoType")
	private String vTodoType;
	
	@JsonProperty("vTodoListCd")
	private String vTodoListCd;
	
	@JsonProperty("vFlagComplete")
	private String vFlagComplete;
	
	@JsonProperty("vFlagCompleteYn")
	private String vFlagCompleteYn;
	
	@JsonProperty("vGroupId")
	private String vGroupId;
	
	@JsonProperty("vUserid")
	private String vUserid;
	
	@JsonProperty("vStrDt")
	private String vStrDt;
	
	@JsonProperty("vEndDt")
	private String vEndDt;
	
	@JsonProperty("vFlagAllDay")
	private String vFlagAllDay;
	
	@JsonProperty("vBuffer1")
	private String vBuffer1;
	
	@JsonProperty("vBuffer2")
	private String vBuffer2;
	
	@JsonProperty("vBuffer3")
	private String vBuffer3;
	
	@JsonProperty("vBuffer4")
	private String vBuffer4;


}


