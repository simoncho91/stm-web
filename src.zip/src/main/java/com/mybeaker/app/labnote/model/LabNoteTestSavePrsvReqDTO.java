package com.mybeaker.app.labnote.model;

import java.util.List;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.testreq.model.TestRequestPrsvReqDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LabNoteTestSavePrsvReqDTO {
	
	@NotEmpty
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("vMrqTypeCd")
	private String vMrqTypeCd;
	
	@JsonProperty("vContPkCd")
	private String vContPkCd;
	
	@JsonProperty("vGateCd")
	private String vGateCd;
	
	@JsonProperty("vRepContPkCd")
	private String vRepContPkCd;
	
	@JsonProperty("vTrCompleteReqDt")
	private String vTrCompleteReqDt;
	
	@JsonProperty("vDosageFormCd")
	private String vDosageFormCd;
	
	@JsonProperty("vTestType")
	private String vTestType;
	
	@JsonProperty("vTestTypeNm")
	private String vTestTypeNm;
	
	@JsonProperty("vTestValue")
	private String vTestValue;
	
	@JsonProperty("vTrPh")
	private String vTrPh;

	@JsonProperty("vTrFlagNoFragrance")
	private String vTrFlagNoFragrance;
	
	@JsonProperty("vTrComment")
	private String vTrComment;
	
	@JsonProperty("vTrPrdCd")
	private String vTrPrdCd;
	
	@JsonProperty("vTddProdType1Cd")
	private String vTddProdType1Cd;
	
	@JsonProperty("vTddProdType2Cd")
	private String vTddProdType2Cd;

	@JsonProperty("vContainerCd")
	private String vContainerCd;
	
	@JsonProperty("vContainerEtc")
	private String vContainerEtc;
	
	@JsonProperty("vTrPilotDt")
	private String vTrPilotDt;
	
	@JsonProperty("vTrTestTypeCd")
	private String vTrTestTypeCd;
	
	@JsonProperty("vCreateNo")
	private String vCreateNo;
	
	@JsonProperty("vTrProductionCd")
	private String vTrProductionCd;
	
	@JsonProperty("vTrProductionTxt")
	private String vTrProductionTxt;
	
	@JsonProperty("arrProdSignListCd")
	private String [] arrProdSignListCd;
	
	@JsonProperty("vTrFlagNoWater")
	private String vTrFlagNoWater;
	
	@JsonProperty("vKosmetikCd")
	private String vKosmetikCd;
	
	@JsonProperty("vKosmetikTxt")
	private String vKosmetikTxt;
	
	@JsonProperty("vFeature")
	private String vFeature;
	
	@JsonProperty("vCounterNote")
	private String vCounterNote;

	@JsonProperty("vTrComment2")
	private String vTrComment2;

	@JsonProperty("arrContPkCd")
	private String [] arrContPkCd;

	@JsonProperty("contList")
	private List<LabNoteTestReqContVO> contList;
	
	@JsonProperty("dataPrsvList")
	private List<TestRequestPrsvReqDTO> dataPrsvList;
	
	@JsonProperty("vDeptCd")
	private String vDeptCd;
	
	@JsonProperty("vTrPrdNm")
	private String vTrPrdNm;
	
	@JsonProperty("vTrPrdEngNm")
	private String vTrPrdEngNm;
	
	@JsonProperty("vSapCd")
	private String vSapCd;
	
	@JsonProperty("vUserid")
	private String vUserid;
	
	@JsonProperty("vAmoreProdYn")
	private String vAmoreProdYn;
	
	@JsonProperty("vInnerPlant")
	private String vInnerPlant;
	
	@JsonProperty("vMakerNm")
	private String vMakerNm;
	
	@JsonProperty("vLot")
	private String vLot;
	
	@JsonProperty("vTypeCd")
	private String vTypeCd;
	
	@JsonProperty("vTypeCd2")
	private String vTypeCd2;
	
	@JsonProperty("vRpmsCd")
	private String vRpmsCd;
	
	@JsonProperty("vBrdCd")
	private String vBrdCd;
	
	@JsonProperty("vMeetingDt")
	private String vMeetingDt;
	
	@JsonProperty("vWerks")
	private String vWerks;
	
	@JsonProperty("vFlagReleaseAsia")
	private String vFlagReleaseAsia;
	
	@JsonProperty("vFlagReleaseAsean")
	private String vFlagReleaseAsean;
	
	@JsonProperty("vFlagReleaseEtc")
	private String vFlagReleaseEtc;
	
	@JsonProperty("vPartCd")
	private String vPartCd;
	
	@JsonProperty("vSiteType")
	private String vSiteType;
	
	@JsonProperty("vRegUserid")
	private String vRegUserid;
	
	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;
	
	@JsonProperty("vPrescUserid")
	private String vPrescUserid;
	
	@JsonProperty("nVersion")
	private int nVersion;
	
	@JsonProperty("vRepContCd")
	private String vRepContCd;
	
	@JsonProperty("vRepLotCd")
	private String vRepLotCd;
	
	@JsonProperty("vTrMrqTypeCd")
	private String vTrMrqTypeCd;
	
	@JsonProperty("vLand1")
	private String vLand1;
	
	@JsonProperty("counterList")
	private List<TestReqCounterMrq011DTO> counterList;
	
	@JsonProperty("vFlagTmt1")
	private String vFlagTmt1;
	
	@JsonProperty("vFlagModifyComment2")
	private String vFlagModifyComment2;
	
	@JsonProperty("vBaseFlag")
	private String vBaseFlag;

	@JsonProperty("vFlagPrdLabor")
	private String vFlagPrdLabor;	
	
	@JsonProperty("vHisid")
	private String vHisid;
	
	@JsonProperty("nTrVersion")
	private int nTrVersion;
}