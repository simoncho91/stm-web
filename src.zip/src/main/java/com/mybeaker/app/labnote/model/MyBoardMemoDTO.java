package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MyBoardMemoDTO {
	@JsonProperty("vTumnTsntUserMemoNo")
	private String vTumnTsntUserMemoNo;

	@JsonProperty("nMemoSn")
	private int nMemoSn;

	@JsonProperty("vMemoBgClrNm")
	private String vMemoBgClrNm;

	@JsonProperty("vMemoTtl")
	private String vMemoTtl;

	@JsonProperty("vMemoTxt")
	private String vMemoTxt;

	@JsonProperty("vMemoRegEmpId")
	private String vMemoRegEmpId;

	@JsonProperty("vRegUserid")
	private String vRegUserid;
}
