package com.mybeaker.app.labnote.model;

import lombok.Data;

@Data
public class AlarmUserDTO {
	private String vUserid;

	private String vUsernm;

	private String vEmail;

	private String vResearcherType;
}
