package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ElabStats02VO {

	@JsonProperty("vDt")
	private String vDt;

	@JsonProperty("vProdType1Cd")
	private String vProdType1Cd;

	@JsonProperty("vProdType2Cd")
	private String vProdType2Cd;

	@JsonProperty("vDeptCd")
	private String vDeptCd;

	@JsonProperty("vNoteType")
	private String vNoteType;

	@JsonProperty("nNewAp")
	private int nNewAp;

	@JsonProperty("nNewRt")
	private int nNewRt;

	@JsonProperty("nNewTot")
	private int nNewTot;

	@JsonProperty("nNewApNote")
	private int nNewApNote;

	@JsonProperty("nNewRtNote")
	private int nNewRtNote;

	@JsonProperty("nNewTotNote")
	private int nNewTotNote;

	@JsonProperty("nAdAp")
	private int nAdAp;

	@JsonProperty("nAdRt")
	private int nAdRt;

	@JsonProperty("nAdTot")
	private int nAdTot;

	@JsonProperty("nAdApNote")
	private int nAdApNote;

	@JsonProperty("nAdRtNote")
	private int nAdRtNote;

	@JsonProperty("nAdTotNote")
	private int nAdTotNote;
	
	@JsonProperty("vLaunchCompleteType")
	private String vLaunchCompleteType;
	
	@JsonProperty("vSignType")
	private String vSignType;
	
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("vContPkCd")
	private String vContPkCd;
}
