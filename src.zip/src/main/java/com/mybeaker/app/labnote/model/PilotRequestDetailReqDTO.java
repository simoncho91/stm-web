package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class PilotRequestDetailReqDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("vApprCd")
	private String vApprCd;

	@JsonProperty("vFlagApprBom")
	private String vFlagApprBom;

	@JsonProperty("vNoteType")
	private String vNoteType;

	@JsonProperty("vPqcResCd")
	private String vPqcResCd;
}
