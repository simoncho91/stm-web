package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Zplmt12ReqVO {
	
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("vSearchType")
	private String vSearchType;
	
	@JsonProperty("vConcd")
	private String vConcd;
	
	@JsonProperty("vLand1")
	private String vLand1;
	
	@JsonProperty("vGcode")
	private String vGcode;
}
