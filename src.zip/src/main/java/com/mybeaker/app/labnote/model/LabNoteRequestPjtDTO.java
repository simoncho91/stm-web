package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteRequestPjtDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vPjtCd")
	private String vPjtCd;

	@JsonProperty("vRpmsCd")
	private String vRpmsCd;

	@JsonProperty("vPjtNm")
	private String vPjtNm;

	@JsonProperty("vPjtType2Nm")
	private String vPjtType2Nm;

	@JsonProperty("vPjtTag")
	private String vPjtTag;
}
