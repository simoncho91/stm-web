package com.mybeaker.app.labnote.model;

import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Positive;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BomApprovalReqDTO {

	@NotEmpty
	@JsonProperty("vApprCd")
	private String vApprCd;

	@Positive
	@JsonProperty("nCurRegseq")
	private int nCurRegseq;

	@Positive
	@JsonProperty("nCurApprseq")
	private int nCurApprseq;

	@NotEmpty
	@JsonProperty("vApprStatus")
	private String vApprStatus;

	@JsonProperty("vApprSubStatus")
	private String vApprSubStatus;

	@JsonProperty("vApprOpinion")
	private String vApprOpinion;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vLotNm")
	private String vLotNm;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vPageType")
	private String vPageType;

	@JsonProperty("nPilotTestSeqno")
	private int nPilotTestSeqno;

	private String vContPkCd;

	private String vLotCd;

	private String vTumnTsntLotStCd;

	private List<String> contPkCdList;

	private List<Integer> versionList;

	private List<String> lotCdList;

	private List<String> contCdList;

	private String vFlagPrecede;
}
