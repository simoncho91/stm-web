package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.common.model.UploadTempDTO;

import lombok.Data;

@Data
public class AttachUploadRegDTO {
	
	@JsonProperty("vRecordid")
	private String vRecordid;
	
	@JsonProperty("vUploadCd")
	private String vUploadCd;
	
	private List<UploadTempDTO> fileList;
}
