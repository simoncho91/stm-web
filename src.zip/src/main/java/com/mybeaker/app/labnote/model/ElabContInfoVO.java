package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ElabContInfoVO {
	
//	내용물코드
	@JsonProperty("vKeyword")
	private String vKeyword;
	
//	내용물 명
	@JsonProperty("vMatrNm")
	private String vMatrNm;
	
//	사용기한
	@JsonProperty("vMatruseDate")
	private String vMatruseDate;

//	이전에 등록한 사용기한
	@JsonProperty("vBeforeLife")
	private String vBeforeLife;
	
//	사용기한 기타선택 시, 입력한 사용기한
	@JsonProperty("vEtcLifeV2")
	private String vEtcLifeV2;

//	SELECT BOX 플랜트
	@JsonProperty("vPlantSelected")
	private String vPlantSelected;
	
//	INPUT 플랜트
	@JsonProperty("vPlantCd")
	private String vPlantCd;
	
}
