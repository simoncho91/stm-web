package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteTestReqApprContVO {
	
	@JsonProperty("vContPkCd")
	private String vContPkCd;
	
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("vContCd")
	private String vContCd;
	
	@JsonProperty("vContNm")
	private String vContNm;
	
	@JsonProperty("vPrdCd")
	private String vPrdCd;
	
	@JsonProperty("vPlantCd")
	private String vPlantCd;
	
	
}
