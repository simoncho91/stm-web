package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteTestReqTagListVO {

	@JsonProperty("vMstCode")
	private String vMstCode;

	@JsonProperty("vSubCode")
	private String vSubCode;
	
	@JsonProperty("vBuffer1")
	private String vBuffer1;
	
	@JsonProperty("vBuffer2")
	private String vBuffer2;
	
	@JsonProperty("vBuffer3")
	private String vBuffer3;
	
	@JsonProperty("vContent1")
	private String vContent1;
	
	@JsonProperty("vContent2")
	private String vContent2;
	
	@JsonProperty("vSubCodenm")
	private String vSubCodenm;
	
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("vTag1Cd")
	private String vTag1Cd;
	
	@JsonProperty("vTag2Cd")
	private String vTag2Cd;
	
	@JsonProperty("vTagBuffer1")
	private String vTagBuffer1;
	
	@JsonProperty("vTagBuffer2")
	private String vTagBuffer2;
	
	@JsonProperty("vTagBuffer3")
	private String vTagBuffer3;
	
	
	
}
