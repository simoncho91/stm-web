package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class ElabContQmsReqVO {

	@JsonProperty("vQmsPlantCd")
	private String vQmsPlantCd;
	
	@JsonProperty("arrQmsContCd")
	private String [] arrQmsContCd;
	
}
