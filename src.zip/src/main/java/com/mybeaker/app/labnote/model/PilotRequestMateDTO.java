package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class PilotRequestMateDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vSiteType")
	private String vSiteType;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("nVersion")
	private String nVersion;

	@JsonProperty("vVersionTxt")
	private String vVersionTxt;

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("vLotNm")
	private String vLotNm;

	@JsonProperty("vMateCd")
	private String vMateCd;

	@JsonProperty("vMateNm")
	private String vMateNm;

	@JsonProperty("nRate")
	private double nRate;

	@JsonProperty("nRateSum")
	private double nRateSum;

	@JsonProperty("nMateSimplePrice")
	private double nMateSimplePrice;

	@JsonProperty("vMateMaxMix")
	private String vMateMaxMix;

	@JsonProperty("vMaterialCd")
	private String vMaterialCd;

	@JsonProperty("vMateBanInfo")
	private String vMateBanInfo;

	@JsonProperty("vFlagUsableMate")
	private String vFlagUsableMate;

	@JsonProperty("vFlagExistsMate")
	private String vFlagExistsMate;

	@JsonProperty("vFlagFreeBanMate")
	private String vFlagFreeBanMate;

	@JsonProperty("vFlagGlbBanMate")
	private String vFlagGlbBanMate;

	@JsonProperty("vFlagGlbLimitMate")
	private String vFlagGlbLimitMate;

	@JsonProperty("vFlagTarMate")
	private String vFlagTarMate;

	@JsonProperty("vFlagTcodeMate")
	private String vFlagTcodeMate;

	@JsonProperty("vFlagNotIngrYn")
	private String vFlagNotIngrYn;

	@JsonProperty("vFlagMrq030Mate")
	private String vFlagMrq030Mate;
}
