package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class PlantChangeReqDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vOldPlantCd")
	private String vOldPlantCd;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vSiteType")
	private String vSiteType;

	@JsonProperty("vContCd")
	private String vContCd;
}
