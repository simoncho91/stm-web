package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LabNoteProcessResDTO {

	@JsonProperty("progressInfo")
	private List<LabNoteProcessProgressDTO> progressInfo;

	@JsonProperty("tabList")
	private List<LabNoteProcessTabListDTO> tabList;

	@JsonProperty("vFlagCancel")
	private String vFlagCancel;

	List<ScheduleDTO> scheduleList;
}
