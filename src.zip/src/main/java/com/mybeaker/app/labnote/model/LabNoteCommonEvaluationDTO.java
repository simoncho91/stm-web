package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteCommonEvaluationDTO {
	@JsonProperty("vEvaluateno")
	private String vEvaluateno;

	@JsonProperty("vEvaluateCd")
	private String vEvaluateCd;

	@JsonProperty("vEvaluateNm")
	private String vEvaluateNm;

	@JsonProperty("vSpfVal")
	private String vSpfVal;

	@JsonProperty("vSpfError")
	private String vSpfError;

	@JsonProperty("vPaVal")
	private String vPaVal;

	@JsonProperty("vPaError")
	private String vPaError;

	@JsonProperty("vProductionNm")
	private String vProductionNm;

	@JsonProperty("vMaterialNm")
	private String vMaterialNm;

	@JsonProperty("vFlagNew")
	private String vFlagNew;

	@JsonProperty("vAddress")
	private String vAddress;

	@JsonProperty("vDosage")
	private String vDosage;

	@JsonProperty("vDosageNm")
	private String vDosageNm;

	@JsonProperty("vEthanol")
	private String vEthanol;

	@JsonProperty("vNote")
	private String vNote;

	@JsonProperty("vPh")
	private String vPh;

	@JsonProperty("vFunction")
	private String vFunction;

	@JsonProperty("vFunctionCd")
	private String vFunctionCd;

	@JsonProperty("vUvCd")
	private String vUvCd;

	@JsonProperty("vWresisting")
	private String vWresisting;

	@JsonProperty("vUvWresisting")
	private String vUvWresisting;

	@JsonProperty("vFunctionNm")
	private String vFunctionNm;

	@JsonProperty("vMinSpf")
	private String vMinSpf;

	@JsonProperty("vMaxSpf")
	private String vMaxSpf;

	@JsonProperty("vStatus")
	private String vStatus;

	@JsonProperty("vWresistingYn")
	private String vWresistingYn;

	@JsonProperty("vLwresistingYn")
	private String vLwresistingYn;

	@JsonProperty("vFlagPa4plus")
	private String vFlagPa4plus;

	@JsonProperty("vBaseYnName")
	private String vBaseYnName;

	@JsonProperty("vCompDtm")
	private String vCompDtm;

	@JsonProperty("vEvaluateClassNm")
	private String vEvaluateClassNm;

	@JsonProperty("vEvaluateFlagNm")
	private String vEvaluateFlagNm;
	
	@JsonProperty("vEffect")
	private String vEffect;
	
	@JsonProperty("vUsage")
	private String vUsage;
	
	@JsonProperty("vUseWarning")
	private String vUseWarning;
	
	@JsonProperty("vTimeLimit")
	private String vTimeLimit;
}
