package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LabNoteIngrdApprSaveInfoVO {

	@JsonProperty("vZchange")
	private String vZchange;

	@JsonProperty("vArjart")
	private String vArjart;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vLeaveType")
	private String vLeaveType;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("vLotNm")
	private String vLotNm;

	@JsonProperty("vZversion")
	private String vZversion;

	@JsonProperty("vErnam")
	private String vErnam;

	@JsonProperty("vErdat")
	private String vErdat;

	@JsonProperty("nVersion")
	private int nVersion;

}
