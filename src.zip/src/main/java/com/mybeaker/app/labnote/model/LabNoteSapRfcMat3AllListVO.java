package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LabNoteSapRfcMat3AllListVO {

	@JsonProperty("noAllergenList")
	private List<LabNoteSapBomToConInfoVO> noAllergenList;
	
	@JsonProperty("allergenList")
	private List<LabNoteSapBomToConInfoVO> allergenList;
	
}
