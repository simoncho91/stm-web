package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LabNoteComponentVerVO {

	@JsonProperty("vProductCd")
	private String vProductCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("nSeqno")
	private int nSeqno;

	@JsonProperty("vContCd")
	private String vContCd;
	
	@JsonProperty("vContentCd")
	private String vContentCd;

	@JsonProperty("vMatnr")
	private String vMatnr;

	@JsonProperty("vMatnr2")
	private String vMatnr2;

	@JsonProperty("vMaktx")
	private String vMaktx;

	@JsonProperty("nMatnrInPer")
	private double nMatnrInPer;

	@JsonProperty("vConcd")
	private String vConcd;

	@JsonProperty("vConnameKo")
	private String vConnameKo;

	@JsonProperty("vConnameEn")
	private String vConnameEn;

	@JsonProperty("vConnameCh")
	private String vConnameCh;

	@JsonProperty("nConInPer")
	private double nConInPer;

	@JsonProperty("nInPer")
	private double nInPer;

	@JsonProperty("vCasNo")
	private String vCasNo;

	@JsonProperty("vFunctionKo")
	private String vFunctionKo;

	@JsonProperty("vFunctionEn")
	private String vFunctionEn;

	@JsonProperty("vFunctionCh")
	private String vFunctionCh;

	@JsonProperty("vMixre")
	private String vMixre;

	@JsonProperty("vZgllim")
	private String vZgllim;

	@JsonProperty("vZglobal")
	private String vZglobal;

	@JsonProperty("vPerAmount")
	private String vPerAmount;

	@JsonProperty("vRestrictSafety")
	private String vRestrictSafety;

	@JsonProperty("vColorYn")
	private String vColorYn;

	@JsonProperty("vRegUserid")
	private String vRegUserid;

	@JsonProperty("vRegDtm")
	private String vRegDtm;

	@JsonProperty("vLangCd")
	private String vLangCd;

	@JsonProperty("vAllergenYn")
	private String vAllergenYn;

	@JsonProperty("vSubAllergenYn")
	private String vSubAllergenYn;
	
	@JsonProperty("vLotCd")
	private String vLotCd;
	
	@JsonProperty("vFlagMuColorless")
	private String vFlagMuColorless;
}
