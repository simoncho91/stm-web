package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class SupTrProductSameVO {

	@JsonProperty("vSameCd")
	private String vSameCd;
	
	@JsonProperty("vProductCd")
	private String vProductCd;
	
	@JsonProperty("nVersion")
	private int nVersion;
	
	@JsonProperty("nRegSeqno")
	private int nRegSeqno;
	
	@JsonProperty("vContCd")
	private String vContCd;
	
	@JsonProperty("vPlantCd")
	private String vPlantCd;
	
	@JsonProperty("vLotCd")
	private String vLotCd;
	
	@JsonProperty("vRegUserid")
	private String vRegUserid;
	
	@JsonProperty("vRegDtm")
	private String vRegDtm;
	
	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;
	
	@JsonProperty("vUpdateDtm")
	private String vUpdateDtm;
	
	@JsonProperty("vUseYn")
	private String vUseYn;
	
	@JsonProperty("vType")
	private String vType;
}
