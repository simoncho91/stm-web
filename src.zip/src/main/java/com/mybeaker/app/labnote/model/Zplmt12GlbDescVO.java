package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class Zplmt12GlbDescVO {

	@JsonProperty("vGlbDescTxt")
	private String vGlbDescTxt;

	@JsonProperty("vGlbTxt")
	private String vGlbTxt;
}
