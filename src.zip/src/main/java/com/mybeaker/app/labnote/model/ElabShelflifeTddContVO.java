package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ElabShelflifeTddContVO {

	@JsonProperty("vRecordid")
	private String vRecordid;

	@JsonProperty("vProductCd")
	private String vProductCd;

	@JsonProperty("vContCd")
	private String vContCd;

	private String vFlagNotCont;
	
}
