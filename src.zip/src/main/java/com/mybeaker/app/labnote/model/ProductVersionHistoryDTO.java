package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ProductVersionHistoryDTO {
	@JsonProperty("nNum")
	private int nNum;

	@JsonProperty("vTumnTnpdChgHistNo")
	private String vTumnTnpdChgHistNo;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vFlagNewItem")
	private String vFlagNewItem;

	@JsonProperty("vPerfumeCd")
	private String vPerfumeCd;

	@JsonProperty("vPerfumeNm")
	private String vPerfumeNm;

	@JsonProperty("vRegUsernm")
	private String vRegUsernm;

	@JsonProperty("vRegDtm")
	private String vRegDtm;
}
