package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ElabShelflifeTddInfoVO {

	@JsonProperty("vRecordid")
	private String vRecordid;

	@JsonProperty("vProductCd")
	private String vProductCd;

	@JsonProperty("vFlagTdd")
	private String vFlagTdd;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContCount")
	private String vContCount;
	
	private String vFlagSaveStatus;

}
