package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteCommonSearchMateDTO {
	@JsonProperty("vMateCd")
	private String vMateCd;

	@JsonProperty("vMateNm")
	private String vMateNm;

	@JsonProperty("vMateDbTypeCd")
	private String vMateDbTypeCd;

	@JsonProperty("vMateDbMstCd")
	private String vMateDbMstCd;

	@JsonProperty("vMateBanInfo")
	private String vMateBanInfo;

	@JsonProperty("nMateSimplePrice")
	private double nMateSimplePrice;

	@JsonProperty("vMateMaxMix")
	private String vMateMaxMix;

	@JsonProperty("vMaterialCd")
	private String vMaterialCd;

	@JsonProperty("vMaterialNm")
	private String vMaterialNm;

	@JsonProperty("vMateLabNoteCd")
	private String vMateLabNoteCd;

	@JsonProperty("vFlagUsableMate")
	private String vFlagUsableMate;

	@JsonProperty("vFlagExistsMate")
	private String vFlagExistsMate;

	@JsonProperty("vFlagFreeBanMate")
	private String vFlagFreeBanMate;

	@JsonProperty("vFlagFuncMate")
	private String vFlagFuncMate;

	@JsonProperty("vFlagGlbBanMate")
	private String vFlagGlbBanMate;

	@JsonProperty("vFlagGlbLimitMate")
	private String vFlagGlbLimitMate;

	@JsonProperty("vFlagTarMate")
	private String vFlagTarMate;

	@JsonProperty("vFlagTcodeMate")
	private String vFlagTcodeMate;

	@JsonProperty("vFlagNotIngrYn")
	private String vFlagNotIngrYn;

	@JsonProperty("vFlagMrq030Mate")
	private String vFlagMrq030Mate;

	@JsonProperty("vSapCd")
	private String vSapCd;

	@JsonProperty("vSapCdTmp")
	private String vSapCdTmp;

	@JsonProperty("vMyMateType")
	private String vMyMateType;

	@JsonProperty("vMyMateTypeNm")
	private String vMyMateTypeNm;

	@JsonProperty("vMateTempCd")
	private String vMateTempCd;

	@JsonProperty("vPlantNm")
	private String vPlantNm;

	@JsonProperty("vKey")
	private String vKey;

	@JsonProperty("nReqRate")
	private String nReqRate;

	@JsonProperty("vFlagColorMate")
	private String vFlagColorMate;

	@JsonProperty("nFavorCnt")
	private int nFavorCnt;

	@JsonProperty("vType")
	private String vType;
	
	@JsonProperty("vEvaluateCd")
	private String vEvaluateCd;
	
	@JsonProperty("vFunctionCd")
	private String vFunctionCd;
}
