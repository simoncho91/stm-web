package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class WokAppointRefDTO {

	@JsonProperty("vAppointType")
	private String vAppointType;

	@JsonProperty("vRefUserid")
	private String vRefUserid;

	@JsonProperty("vRefUsernm")
	private String vRefUsernm;

	@JsonProperty("vRefPositnm")
	private String vRefPositnm;

	@JsonProperty("vRefDeptnm")
	private String vRefDeptnm;
	
	@JsonProperty("vRegDtm")
	private String vRegDtm;
	
	@JsonProperty("vRegUserid")
	private String vRegUserid;
	
}
