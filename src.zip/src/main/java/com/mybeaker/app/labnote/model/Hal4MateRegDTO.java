package com.mybeaker.app.labnote.model;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Hal4MateRegDTO {

	@NotEmpty
	@JsonProperty("vMateCd")
	private String vMateCd;
	
	@NotEmpty
	@JsonProperty("vPlantCd")
	private String vPlantCd;
	
	@NotEmpty
	@JsonProperty("vLand1")
	private String vLand1;
}
