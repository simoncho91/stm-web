package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteMstVersionPqcDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vVersionTxt")
	private String vVersionTxt;

	@JsonProperty("vCounterTypeCd")
	private String vCounterTypeCd;

	@JsonProperty("vCounterTypeNm")
	private String vCounterTypeNm;

	@JsonProperty("vCounterCd")
	private String vCounterCd;

	@JsonProperty("vCounterContPkCd")
	private String vCounterContPkCd;
	
	@JsonProperty("vCounterContCd")
	private String vCounterContCd;
	
	@JsonProperty("vCounterContNm")
	private String vCounterContNm;

	@JsonProperty("vCounterInvenCd")
	private String vCounterInvenCd;

	@JsonProperty("vCounterInvenJoinCd")
	private String vCounterInvenJoinCd;

	@JsonProperty("vCounterNote")
	private String vCounterNote;

	@JsonProperty("vCounterBrdNm")
	private String vCounterBrdNm;

	@JsonProperty("vCounterPrdNm")
	private String vCounterPrdNm;

	@JsonProperty("vCounterSpInfo")
	private String vCounterSpInfo;

	@JsonProperty("vPrePilotDt")
	private String vPrePilotDt;

	@JsonProperty("vFlagNewItem")
	private String vFlagNewItem;
	
	@JsonProperty("vFlagNotNewItem")
	private String vFlagNotNewItem;

	@JsonProperty("vPerfumeCd")
	private String vPerfumeCd;
	
	@JsonProperty("vPerfumeNm")
	private String vPerfumeNm;

	@JsonProperty("vFlagPerfumeNew")
	private String vFlagPerfumeNew;

	@JsonProperty("vRefTypeCd")
	private String vRefTypeCd;
	
	@JsonProperty("vRefTypeNm")
	private String vRefTypeNm;

	@JsonProperty("vRefContCd")
	private String vRefContCd;

	@JsonProperty("vEvaluateCd")
	private String vEvaluateCd;

	@JsonProperty("vSsrid")
	private String vSsrid;

	@JsonProperty("vRefNote")
	private String vRefNote;

	@JsonProperty("vRegUserid")
	private String vRegUserid;
	
	@JsonProperty("vRegDtm")
	private String vRegDtm;
	
	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;
	
	@JsonProperty("vUpdateDtm")
	private String vUpdateDtm;
	
	@JsonProperty("vFlagGatePerfume")
	private String vFlagGatePerfume;
	
	@JsonProperty("vFlagGateRefNew")
	private String vFlagGateRefNew;
	
	@JsonProperty("vFlagGateRefRpt")
	private String vFlagGateRefRpt;
	
}
