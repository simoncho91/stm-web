package com.mybeaker.app.labnote.model;

import java.util.List;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class MdlReqDTO {
	
	@NotEmpty
	@JsonProperty("vExceptMdlid")
	private String vExceptMdlid;
	
	private List<String> mdlidList;
}
