package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class BatchStatusProcessVO {

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vNoteType")
	private String vNoteType;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vEmail")
	private String vEmail;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("matnr")
	private String matnr;

	@JsonProperty("vStockDt")
	private String vStockDt;

	@JsonProperty("vCompleteDt")
	private String vCompleteDt;

	@JsonProperty("vPrdCd")
	private String vPrdCd;

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("vLotNm")
	private String vLotNm;

	@JsonProperty("nLotCnt")
	private int nLotCnt;
}
