package com.mybeaker.app.labnote.model;

import java.util.List;
import java.util.Map;

import com.mybeaker.app.approval.model.ApprovalDetailDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PilotRequestDetailResDTO<T1, T2, T3> {
	private T1 noteInfo;

	private List<?> verList;

	private List<?> contList;

	private List<?> lotList;

	private Map<String, List<T2>> plantMap;

	private Map<String, List<T3>> lotMap;

	List<ApprovalDetailDTO> userList;
}
