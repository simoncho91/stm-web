package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteTestRequestProductCntDTO {
	
	@JsonProperty("nCnt")
	private int nCnt;
	
	@JsonProperty("nMrq010Cnt")
	private int nMrq010Cnt;
	
	@JsonProperty("nMrq011Cnt")
	private int nMrq011Cnt;
	
	@JsonProperty("nMrq040FuncCnt")
	private int nMrq040FuncCnt;
	
	@JsonProperty("nMrq040HarmCnt")
	private int nMrq040HarmCnt;
	
	@JsonProperty("nMrq050Cnt")
	private int nMrq050Cnt;
	
	@JsonProperty("nMrq060Cnt")
	private int nMrq060Cnt;
	
	@JsonProperty("nMrq070Cnt")
	private int nMrq070Cnt;
	
	@JsonProperty("nClinicalCnt")
	private int nClinicalCnt;
}
