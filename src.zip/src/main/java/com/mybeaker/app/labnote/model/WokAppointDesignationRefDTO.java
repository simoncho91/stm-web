package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class WokAppointDesignationRefDTO {

	@JsonProperty("vAppointType")
	private String vAppointType;
	
	@JsonProperty("vReferenceType")
	private String vReferenceType;
	
	@JsonProperty("vReferenceTypeNm")
	private String vReferenceTypeNm;

	@JsonProperty("vReferenceId")
	private String vReferenceId;
	
	@JsonProperty("vReferenceNm")
	private String vReferenceNm;
	
	@JsonProperty("vRefUserid")
	private String vRefUserid;
	
	@JsonProperty("vRefUsernm")
	private String vRefUsernm;

	@JsonProperty("vSigmaDeptcd")
	private String vSigmaDeptcd;
	
	@JsonProperty("vUserDeptNm")
	private String vUserDeptNm;
	
	@JsonProperty("vRefPositnm")
	private String vRefPositnm;
	
	@JsonProperty("vReferenceInfo")
	private String vReferenceInfo;
	
	@JsonProperty("vRefInfo")
	private String vRefInfo;
	
	@JsonProperty("vRegDtm")
	private String vRegDtm;
	
	@JsonProperty("vRegUserid")
	private String vRegUserid;
	
	@JsonProperty("vUserid")
	private String vUserid;
	
	@JsonProperty("vUsernm")
	private String vUsernm;
	
	@JsonProperty("vEmail")
	private String vEmail;
	
}
