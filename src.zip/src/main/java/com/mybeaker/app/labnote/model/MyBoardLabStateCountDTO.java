package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class MyBoardLabStateCountDTO {
	@JsonProperty("vBrdCd")
	private String vBrdCd;

	@JsonProperty("vBrdNm")
	private String vBrdNm;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vUsernm")
	private String vUsernm;

	@JsonProperty("nIngCnt")
	private int nIngCnt;

	@JsonProperty("nCancelCnt")
	private int nCancelCnt;

	@JsonProperty("nReleaseCnt")
	private int nReleaseCnt;

	@JsonProperty("nCompleteCnt")
	private int nCompleteCnt;
}
