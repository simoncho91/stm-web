package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteLotDTO {

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vLotNm")
	private String vLotNm;

	@JsonProperty("vFlagDecide")
	private String vFlagDecide;

	@JsonProperty("vFlagNotice")
	private String vFlagNotice;

	@JsonProperty("vFlagComplete")
	private String vFlagComplete;

	@JsonProperty("vFlagLotHide")
	private String vFlagLotHide;

	@JsonProperty("nGramOpenNum")
	private int nGramOpenNum;

	@JsonProperty("nPilotTestSeqno")
	private int nPilotTestSeqno;

	@JsonProperty("vPilotTestDtm")
	private String vPilotTestDtm;

	@JsonProperty("vApprCd")
	private String vApprCd;

	@JsonProperty("vFlagBomReq")
	private String vFlagBomReq;

	@JsonProperty("vFlagIngredientReq")
	private String vFlagIngredientReq;

	@JsonProperty("vEffectDtm")
	private String vEffectDtm;

	@JsonProperty("vTrPrdCd")
	private String vTrPrdCd;

	@JsonProperty("vTestType")
	private String vTestType;

	@JsonProperty("vTestValue")
	private String vTestValue;

	@JsonProperty("vPh")
	private String vPh;

	@JsonProperty("vLotMemo")
	private String vLotMemo;

	@JsonProperty("vFlagExposure")
	private String vFlagExposure;

	@JsonProperty("vFlagStability")
	private String vFlagStability;

	@JsonProperty("vFlagUse")
	private String vFlagUse;

	@JsonProperty("vFlagSend")
	private String vFlagSend;

	@JsonProperty("nSort")
	private int nSort;

	@JsonProperty("vFlagBookmark")
	private String vFlagBookmark;

	@JsonProperty("vLotTestMemo")
	private String vLotTestMemo;

	@JsonProperty("vFlagFinal")
	private String vFlagFinal;
	
	@JsonProperty("vConCd")
	private String vConCd;

	@JsonProperty("nNum")
	private int nNum;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;
}
