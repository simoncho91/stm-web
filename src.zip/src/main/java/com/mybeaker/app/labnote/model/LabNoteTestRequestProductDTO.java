package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteTestRequestProductDTO {

	@JsonProperty("nNum")
	private int nNum;

	@JsonProperty("vProductCd")
	private String vProductCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vProductNm")
	private String vProductNm;

	@JsonProperty("vStatusCd")
	private String vStatusCd;

	@JsonProperty("vSapCd")
	private String vSapCd;

	@JsonProperty("vDocNo")
	private String vDocNo;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vDeptCd")
	private String vDeptCd;

	@JsonProperty("vTrLotNm")
	private String vTrLotNm;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vLotCd")
	private String vLotCd;

	@JsonProperty("nLabNoteVer")
	private int nLabNoteVer;

	@JsonProperty("vLabReqDtm")
	private String vLabReqDtm;

	@JsonProperty("vLabGateCd")
	private String vLabGateCd;

	@JsonProperty("vLabMrqTypeCd")
	private String vLabMrqTypeCd;

	@JsonProperty("vLabMrqTypeNm")
	private String vLabMrqTypeNm;

	@JsonProperty("vRegDtm")
	private String vRegDtm;

	@JsonProperty("vFinalResult")
	private String vFinalResult;

	@JsonProperty("vUsernm")
	private String vUsernm;
	
	@JsonProperty("vLotNm")
	private String vLotNm;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vTargetContCd")
	private String vTargetContCd;

	@JsonProperty("vStatusNm")
	private String vStatusNm;

	@JsonProperty("nLineCnt")
	private int nLineCnt;

	@JsonProperty("vTrResMRQ010Txt")
	private String vTrResMrq010Txt;

	@JsonProperty("vTrResMRQ011Txt")
	private String vTrResMrq011Txt;

	@JsonProperty("vTrResMRQ040FuncTxt")
	private String vTrResMrq040FuncTxt;

	@JsonProperty("vTrResMRQ040HarmTxt")
	private String vTrResMrq040HarmTxt;

	@JsonProperty("vTrResMRQ050Txt")
	private String vTrResMrq050Txt;

	@JsonProperty("vTrResMRQ060Txt")
	private String vTrResMrq060Txt;

	@JsonProperty("vTrResMRQ070Txt")
	private String vTrResMrq070Txt;

	@JsonProperty("vTrResClinicalTxt")
	private String vTrResClinicalTxt;

	@JsonProperty("vLabTypeCd")
	private String vLabTypeCd;
}
