package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Zplmt13VO {

	@JsonProperty("matnr")
	private String matnr;
	
	@JsonProperty("concd")
	private String concd;
	
	@JsonProperty("zversion")
	private String zversion;
	
	@JsonProperty("land1")
	private String land1;
	
	@JsonProperty("inSeq")
	private String inSeq;
	
	@JsonProperty("inPer")
	private String inPer;
	
	@JsonProperty("inPerA")
	private String inPerA;
	
	@JsonProperty("erdat")
	private String erdat;      
	
	@JsonProperty("ernam")
	private String ernam;      
	
	@JsonProperty("casno")
	private String casno;     
}
