package com.mybeaker.app.labnote.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Zplm013MosAjaxVO {

	private String vProductCd;
	
	private int nVersion;
	
	private String vContCd;
	
	private String vWerks;
	
	private String vTddProdType1Cd;
	
	private String vTddProdType2Cd;
	
	private String vType01Cd;
	
	private String vType02Cd;
}
