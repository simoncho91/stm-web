package com.mybeaker.app.labnote.model;

import lombok.Data;

@Data
public class RcvFirstSaleDateDTO {
	private String prdCd;

	private String contCd;

	private String zzfsdat;
}
