package com.mybeaker.app.labnote.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class TmpZplmt13ContentInfoVO {

	private String vRawCd;
	
	private String vConCd;
	
	private String vHal4InPer;
	
	private String vRawInPer;
	
	private String vConInPer;
	
	private String vCasNo;
	
	private String nConper;
}
