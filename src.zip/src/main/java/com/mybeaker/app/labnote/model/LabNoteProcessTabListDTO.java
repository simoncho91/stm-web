package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteProcessTabListDTO {
	@JsonProperty("tabId")
	private String tabId;
	
	@JsonProperty("tabNm")
	private String tabNm;
}
