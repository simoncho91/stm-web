package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteTestReqTodoVO {

	@JsonProperty("vTodoListCd")
	private String vTodoListCd;
	
	@JsonProperty("vTodoType")
	private String vTodoType;
	
	@JsonProperty("vOwnerType")
	private String vOwnerType;
	
	@JsonProperty("vOwnerCd")
	private String vOwnerCd;
	
	@JsonProperty("vFlagComplete")
	private String vFlagComplete;
	
	@JsonProperty("vFlagAllDay")
	private String vFlagAllDay;
	
	@JsonProperty("nCnt")
	private int nCnt;
	
	@JsonProperty("vRecordCd")
	private String vRecordCd;
	
	@JsonProperty("vTitle")
	private String vTitle;
	
	@JsonProperty("vStrDt")
	private String vStrDt;
	
	@JsonProperty("vEndDt")
	private String vEndDt;
	
	@JsonProperty("vBuffer1")
	private String vBuffer1;
	
	@JsonProperty("vBuffer2")
	private String vBuffer2;
	
	@JsonProperty("vBuffer3")
	private String vBuffer3;
	
	
}
	
