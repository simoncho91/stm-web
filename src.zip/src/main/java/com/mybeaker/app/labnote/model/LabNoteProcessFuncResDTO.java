package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentPagingDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper = true)
public class LabNoteProcessFuncResDTO extends ParentPagingDTO{

	@JsonProperty("vRowCnt")
	private String vRowCnt;
	
	@JsonProperty("nNum")
	private String nNum;
	
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("vPlantCd")
	private String vPlantCd;
	
	@JsonProperty("vFlagRepresent")
	private String vFlagRepresent;
	
	@JsonProperty("vContPkCd")
	private String vContPkCd;
	
	@JsonProperty("vContCd")
	private String vContCd;
	
	@JsonProperty("vContNm")
	private String vContNm;
	
	@JsonProperty("nFdnVer")
	private int nFdnVer;
	
	@JsonProperty("vStatusCd")
	private String vStatusCd;
	
	@JsonProperty("vDecideContNm")
	private String vDecideContNm;
	
	@JsonProperty("vRegUserid")
	private String vRegUserid;
	
	@JsonProperty("vRegDtm")
	private String vRegDtm;
	
	@JsonProperty("vCompleteDtm")
	private String vCompleteDtm;
	
	@JsonProperty("vStatusNm")
	private String vStatusNm;
	
	@JsonProperty("vRegUsernm")
	private String vRegUsernm;
	
	@JsonProperty("vNoteType")
	private String vNoteType;
	
	@JsonProperty("vTitle")
	private String vTitle;
	
	@JsonProperty("vFlagNameModAuth")
	private String vFlagNameModAuth;
	
	@JsonProperty("vFdnStatusCd")
	private String vFdnStatusCd;
	
	@JsonProperty("vFlagSaveAction")
	private String vFlagSaveAction;
	
	@JsonProperty("vApprCd")
	private String vApprCd;
}
