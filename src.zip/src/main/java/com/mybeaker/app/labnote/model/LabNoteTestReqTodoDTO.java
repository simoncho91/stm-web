package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteTestReqTodoDTO {

	@JsonProperty("vRegUserid")
	private String vRegUserid;
	
	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;
	
	@JsonProperty("vMstTableNm")
	private String vMstTableNm;
	
	@JsonProperty("vRecordCd")
	private String vRecordCd;
	
	@JsonProperty("vTitle")
	private String vTitle;
	
	@JsonProperty("vGroupId")
	private String vGroupId;
	
	@JsonProperty("vUserid")
	private String vUserid;
	
	@JsonProperty("vStrDt")
	private String vStrDt;
	
	@JsonProperty("vEndDt")
	private String vEndDt;
	
	@JsonProperty("vFlagAllDay")
	private String vFlagAllDay;
	
	@JsonProperty("vTodoListCd")
	private String vTodoListCd;
	
	@JsonProperty("vBuffer1")
	private String vBuffer1;
	
	@JsonProperty("vBuffer2")
	private String vBuffer2;
	
	@JsonProperty("vBuffer3")
	private String vBuffer3;
	
	
}
	
	
	
