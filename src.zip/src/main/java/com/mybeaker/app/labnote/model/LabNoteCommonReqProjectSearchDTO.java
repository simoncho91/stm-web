package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentPagingDTO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class LabNoteCommonReqProjectSearchDTO extends ParentPagingDTO {
	@JsonProperty("vKeyword")
	private String vKeyword;
	
	@JsonProperty("vYear")
	private String vYear;
	
	@JsonProperty("vDeptCd")
	private String vDeptCd;
	
	private String localLanguage;
	
	private List<String> arrStatusCd;
	
	private List<String> arrPjtType1Cd;
}
