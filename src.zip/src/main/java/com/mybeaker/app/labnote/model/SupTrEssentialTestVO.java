package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class SupTrEssentialTestVO {

	@JsonProperty("vTargetCd")
	private String vTargetCd;
	
	@JsonProperty("nVersion")
	private int nVersion;
	
	@JsonProperty("vRecType02Cd")
	private String vRecType02Cd;
	
	@JsonProperty("vRegUserid")
	private String vRegUserid;
}
