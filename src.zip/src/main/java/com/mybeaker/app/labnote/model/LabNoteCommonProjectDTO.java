package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteCommonProjectDTO {
	@JsonProperty("vPjtCd")
	private String vPjtCd;

	@JsonProperty("vPjtNm")
	private String vPjtNm;

	@JsonProperty("vRpmsCd")
	private String vRpmsCd;

	@JsonProperty("vSYear")
	private String vSYear;

	@JsonProperty("vEYear")
	private String vEYear;

	@JsonProperty("vDeptCd")
	private String vDeptCd;

	@JsonProperty("vStatusCd")
	private String vStatusCd;

	@JsonProperty("vDeptNm")
	private String vDeptNm;

	@JsonProperty("vUserNm")
	private String vUserNm;

	@JsonProperty("vUserDeptcd")
	private String vUserDeptcd;

	@JsonProperty("vTagCd")
	private String vTagCd;

	@JsonProperty("vPoUsernm")
	private String vPoUsernm;

	@JsonProperty("vGaUsernm")
	private String vGaUsernm;

	@JsonProperty("vPjtType2Nm")
	private String vPjtType2Nm;

	@JsonProperty("vStatusNm")
	private String vStatusNm;

	@JsonProperty("vPjtTag")
	private String vPjtTag;
}
