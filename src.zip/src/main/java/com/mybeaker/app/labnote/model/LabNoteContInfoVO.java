package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LabNoteContInfoVO {

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vPrdCd")
	private String vPrdCd;

	@JsonProperty("vPlantCd")
	private String vPlantCd;

	@JsonProperty("vPlantNm")
	private String vPlantNm;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vContNmCn")
	private String vContNmCn;

	@JsonProperty("vContNmEn")
	private String vContNmEn;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vFlagRepresent")
	private String vFlagRepresent;

	@JsonProperty("vCodeType")
	private String vCodeType;

	@JsonProperty("vFlagExistsDecide")
	private String vFlagExistsDecide;

	private String localLanguage;

}
