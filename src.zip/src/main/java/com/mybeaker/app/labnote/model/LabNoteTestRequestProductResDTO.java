package com.mybeaker.app.labnote.model;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.approval.model.ApprovalDetailDTO;
import com.mybeaker.app.approval.model.ReqResApprovalDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LabNoteTestRequestProductResDTO<T>{
		
	@JsonProperty("vPqcGate1ResCd")
	private String vPqcGate1ResCd;
	
	@JsonProperty("vPqcGateCd")
	private String vPqcGateCd;
	
	@JsonProperty("trGate1List")
	private List<LabNoteTestRequestProductDTO> trGate1List;
	
	@JsonProperty("trMap")
	private Map<String, List<LabNoteTestRequestProductDTO>> trMap;
	
	@JsonProperty("pqcList")
	private List<LabNotePqcGateCheckListDTO> pqcList;
	
	@JsonProperty("contList")
	List<LabNoteProcessContDecideListDTO> contList;

	@JsonProperty("userList")
	List<ApprovalDetailDTO> userList;
	
	@JsonProperty("rvo")
	T rvo;

	@JsonProperty("apprVo")
	ReqResApprovalDTO apprVo;
	
	@JsonProperty("pqcResVo")
	PgcGqteResVO pqcResVo;
}
