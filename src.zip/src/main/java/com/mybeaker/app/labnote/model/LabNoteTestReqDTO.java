package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.testreq.model.TestRequestPreservPerDTO;

import lombok.Data;

@Data
public class LabNoteTestReqDTO {
	
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("vContPkCd")
	private String vContPkCd;
	
	@JsonProperty("vOtherContPkCd")
	private String vOtherContPkCd;
	
	@JsonProperty("nVersion")
	private int nVersion;
	
	@JsonProperty("vMrqTypeCd")
	private String vMrqTypeCd;
	
	@JsonProperty("vTrMrqTypeCd")
	private String vTrMrqTypeCd;
	
	@JsonProperty("vTrGoalCd")
	private String vTrGoalCd;
	
	@JsonProperty("vPlantCd")
	private String vPlantCd;
	
	@JsonProperty("vLotCompleteYn")
	private String vLotCompleteYn;
	
	@JsonProperty("vGateCd")
	private String vGateCd;
	
	@JsonProperty("vLanguage")
	private String vLanguage;
	
	@JsonProperty("vFlagAllLast")
	private String vFlagAllLast;
	
	@JsonProperty("vFlagUseGate")
	private String vFlagUseGate;
	
	@JsonProperty("vTempTag1Cd")
	private String vTempTag1Cd;
	
	@JsonProperty("vGetListType")
	private String vGetListType;
	
	@JsonProperty("vTestTypecd")
	private String vTestTypecd;
	
	@JsonProperty("vLand1")
	private String vLand1;
	
	@JsonProperty("vLotCd")
	private String vLotCd;
	
	@JsonProperty("perList")
	private List<TestRequestPreservPerDTO> perList;
}
