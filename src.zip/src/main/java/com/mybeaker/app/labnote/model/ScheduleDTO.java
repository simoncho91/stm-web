package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ScheduleDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vStatusCd")
	private String vStatusCd;

	@JsonProperty("vTimeStDt")
	private String vTimeStDt;

	@JsonProperty("vSchdStDt")
	private String vSchdStDt;

	@JsonProperty("vTypeCd")
	private String vTypeCd;

	@JsonProperty("nSeqno")
	private int nSeqno;

	@JsonProperty("vAlrTypeCd")
	private String vAlrTypeCd;

	@JsonProperty("vAlrTypeNm")
	private String vAlrTypeNm;

	@JsonProperty("vFlagAlarm")
	private String vFlagAlarm;

	@JsonProperty("vFlagMail")
	private String vFlagMail;

	@JsonProperty("vMessage")
	private String vMessage;

	@JsonProperty("vRegDtm")
	private String vRegDtm;

	@Builder
	public ScheduleDTO(String vLabNoteCd, String vStatusCd, String vTimeStDt,
			String vSchdStDt, String vTypeCd, int nSeqno, String vAlrTypeCd,
			String vAlrTypeNm, String vFlagAlarm, String vFlagMail, String vMessage, String vRegDtm
			) {
		this.vLabNoteCd = vLabNoteCd;
		this.vStatusCd = vStatusCd;
		this.vTimeStDt = vTimeStDt;
		this.vSchdStDt = vSchdStDt;
		this.vTypeCd = vTypeCd;
		this.nSeqno = nSeqno;
		this.vAlrTypeCd = vAlrTypeCd;
		this.vAlrTypeNm = vAlrTypeNm;
		this.vFlagAlarm = vFlagAlarm;
		this.vFlagMail = vFlagMail;
		this.vMessage = vMessage;
		this.vRegDtm = vRegDtm;
	}
}
