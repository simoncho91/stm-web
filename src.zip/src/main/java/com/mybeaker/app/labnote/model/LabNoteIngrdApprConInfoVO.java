package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LabNoteIngrdApprConInfoVO {

	@JsonProperty("vContPkCd")
	private String vContPkCd;
	
	@JsonProperty("vMatnr")
	private String vMatnr;

	@JsonProperty("vWerks")
	private String vWerks;

	@JsonProperty("vZversion")
	private String vZversion;

	@JsonProperty("vZtext")
	private String vZtext;

	@JsonProperty("vZtextKcp")
	private String vZtextKcp;

	@JsonProperty("vZtextEn")
	private String vZtextEn;

	@JsonProperty("vZtextEcp")
	private String vZtextEcp;

	@JsonProperty("vZtextZh")
	private String vZtextZh;

	@JsonProperty("vPsnameNa")
	private String vPsnameNa;

	@JsonProperty("vPsnameK")
	private String vPsnameK;

	@JsonProperty("vZlvorm")
	private String vZlvorm;

	@JsonProperty("vZchange")
	private String vZchange;

	@JsonProperty("vDatuv")
	private String vDatuv;

	@JsonProperty("vErdat")
	private String vErdat;

	@JsonProperty("vErnam")
	private String vErnam;

	@JsonProperty("vDisplayLt")
	private String vDisplayLt;

	@JsonProperty("vWarningLt")
	private String vWarningLt;

	@JsonProperty("vWarningLtEn")
	private String vWarningLtEn;

	@JsonProperty("vWarningLtZh")
	private String vWarningLtZh;

	@JsonProperty("vArjart")
	private String vArjart;

	@JsonProperty("vLand")
	private String vLand;

	@JsonProperty("vApprovalNote")
	private String vApprovalNote;

	@JsonProperty("vErnamNm")
	private String vErnamNm;

	@JsonProperty("vMatnrNm")
	private String vMatnrNm;

}
