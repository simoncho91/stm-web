package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LabNoteCommonRequestMateDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vMatePkCd")
	private String vMatePkCd;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vGrpCd")
	private String vGrpCd;

	@JsonProperty("vMateCd")
	private String vMateCd;

	@JsonProperty("vAddTypeCd")
	private String vAddTypeCd;

	@JsonProperty("vMateDbTypeCd")
	private String vMateDbTypeCd;

	@JsonProperty("vMateDbMstCd")
	private String vMateDbMstCd;

	@JsonProperty("vMateNm")
	private String vMateNm;

	@JsonProperty("nReqRate")
	private double nReqRate;

	@JsonProperty("vMateEvalCd")
	private String vMateEvalCd;

	@JsonProperty("vMateFuncCd")
	private String vMateFuncCd;

	@JsonProperty("vFlagRequired")
	@Builder.Default
	private String vFlagRequired = "N";

	@JsonProperty("vFlagRateFixed")
	@Builder.Default
	private String vFlagRateFixed = "N";

	@JsonProperty("vFlagReq")
	@Builder.Default
	private String vFlagReq = "N";

	@JsonProperty("vFlagLv")
	private String vFlagLv;

	@JsonProperty("vNote")
	private String vNote;

	@JsonProperty("nSortReq")
	private int nSortReq;

	@JsonProperty("nSort")
	private int nSort;

	@JsonProperty("vFlagCounter")
	@Builder.Default
	private String vFlagCounter = "N";

	@JsonProperty("nCounterRate")
	private double nCounterRate;

	@JsonProperty("vFlagMateHide")
	private String vFlagMateHide;

	@JsonProperty("vFlagTo100")
	private String vFlagTo100;

	@JsonProperty("vFlagSelect")
	private String vFlagSelect;

	@JsonProperty("vFlagMateOpen")
	private String vFlagMateOpen;

	@JsonProperty("nGlimCnt")
	private int nGlimCnt;

	@JsonProperty("vFlagGlim")
	private String vFlagGlim;

	@JsonProperty("vMatePutDt")
	private String vMatePutDt;

	@JsonProperty("vMateUserid")
	private String vMateUserid;

	@JsonProperty("vMateUsernm")
	private String vMateUsernm;

	@JsonProperty("vMateTempCd")
	private String vMateTempCd;

	@JsonProperty("vMateBanInfo")
	private String vMateBanInfo;

	@JsonProperty("vFlagFreeBanMate")
	private String vFlagFreeBanMate;

	@JsonProperty("vFlagGlbBanMate")
	private String vFlagGlbBanMate;

	@JsonProperty("vFlagGlbLimitMate")
	private String vFlagGlbLimitMate;

	@JsonProperty("vFlagTarMate")
	private String vFlagTarMate;

	@JsonProperty("vFlagTcodeMate")
	private String vFlagTcodeMate;

	@JsonProperty("vFlagMrq030Mate")
	private String vFlagMrq030Mate;

	@JsonProperty("vFlagMainIngredientMate")
	private String vFlagMainIngredientMate;

	@JsonProperty("vFlagPermissionMate")
	private String vFlagPermissionMate;

	@JsonProperty("vTrLv")
	@Builder.Default
	private String vTrLv = "";

	@JsonProperty("vFlagMateNew")
	private String vFlagMateNew;

	@JsonProperty("vTumnTnpdChgHistNo")
	private String vTumnTnpdChgHistNo;

	private String vRegUserid;

	private String vUpdateUserid;
}
