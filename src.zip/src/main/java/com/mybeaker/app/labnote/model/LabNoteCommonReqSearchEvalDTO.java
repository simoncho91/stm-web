package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentPagingDTO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class LabNoteCommonReqSearchEvalDTO extends ParentPagingDTO {
	@JsonProperty("vSearchPrior")
	private String vSearchPrior;

	@JsonProperty("vKeyword")
	private String vKeyword;

	@JsonProperty("vMateKeyword")
	private String vMateKeyword;

	@JsonProperty("vChkWrFlag")
	private String vChkWrFlag;

	@JsonProperty("vChkLwrFlag")
	private String vChkLwrFlag;

	@JsonProperty("vChkWrAllFlag")
	private String vChkWrAllFlag;

	@JsonProperty("vDosageSrcAllYn")
	private String vDosageSrcAllYn;

	@JsonProperty("vTypeSrcAllYn")
	private String vTypeSrcAllYn;

	@JsonProperty("vEffSrcAllYn")
	private String vEffSrcAllYn;

	@JsonProperty("vSrcIncEffYn")
	private String vSrcIncEffYn;

	@JsonProperty("vSrcSpf")
	private String vSrcSpf;

	private String vStSpf;

	private String vEnSpf;

	private String vSrcPaVal;

	private String vPa1;

	private String vPa2;

	private String vPa2First;

	private String vPa3;

	private String vPa3First;

	private String vPa4;

	private String vPa4First;

	private List<String> arrPriorContent;

	private List<String> arrDosageCode;

	private List<String> arrType;

	private List<String> arrEff;

	private List<String> arrPa;

	private String localLanguage;
}
