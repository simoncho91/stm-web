package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LabNoteSapBomConSearchVO {
	
	@JsonProperty("standardPer")
	private String standardPer;
	
	@JsonProperty("vFlagAerosolYn")
	private String vFlagAerosolYn;
	
	@JsonProperty("vContCd")
	private String vContCd;
	
	@JsonProperty("vPlantCd")
	private String vPlantCd;
	
	@JsonProperty("vLand")
	private String vLand;
	
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("nStandardPer")
	private String nStandardPer;

	@JsonProperty("noAllergenList")
	private List<BomInfoVO> noAllergenList;
	
	@JsonProperty("allergenList")
	private List<BomAllergenVO> allergenList;
	
	@JsonProperty("vSumRate")
	private String vSumRate;
	
	@JsonProperty("vLeaveType")
	private String vLeaveType;

	@JsonProperty("vFlagTempReg")
	private String vFlagTempReg;
	
	@JsonProperty("vFinishContent")
	private String vFinishContent;
	
	@JsonProperty("vMainContent")
	private String vMainContent;
	
	@JsonProperty("vContPkCd")
	private String vContPkCd;
}
