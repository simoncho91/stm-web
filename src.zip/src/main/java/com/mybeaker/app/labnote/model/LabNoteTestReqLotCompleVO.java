package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LabNoteTestReqLotCompleVO {
	
	@JsonProperty("vFlagComplete")
	private String vFlagComplete;
	
	@JsonProperty("vLotCompleteDt")
	private String vLotCompleteDt;
	
}
