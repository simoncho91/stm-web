package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LabNoteMusoguTempDTO {

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@JsonProperty("nVersion")
	private int nVersion;
	
	@JsonProperty("vGetListType")
	private String vGetListType;
	
	@JsonProperty("vTempTag1Cd")
	private String vTempTag1Cd;
	
	@JsonProperty("vLanguage")
	private String vLanguage;
	
	
	
}
