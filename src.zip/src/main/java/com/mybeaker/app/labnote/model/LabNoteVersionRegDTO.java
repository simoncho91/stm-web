package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LabNoteVersionRegDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vContPkCd")
	private String vContPkCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vVersionNm")
	private String vVersionNm;

	@JsonProperty("vCounterTypeCd")
	private String vCounterTypeCd;

	@JsonProperty("vCounterCd")
	private String vCounterCd;

	@JsonProperty("vCounterContPkCd")
	private String vCounterContPkCd;

	@JsonProperty("vCounterInvenCd")
	private String vCounterInvenCd;

	@JsonProperty("vCounterInvenJoinCd")
	private String vCounterInvenJoinCd;

	@JsonProperty("vCounterNote")
	private String vCounterNote;

	@JsonProperty("vCounterBrdNm")
	private String vCounterBrdNm;

	@JsonProperty("vCounterPrdNm")
	private String vCounterPrdNm;

	@JsonProperty("vCounterSpInfo")
	private String vCounterSpInfo;

	@JsonProperty("vPrePilotDt")
	private String vPrePilotDt;

	@JsonProperty("vFlagNewItem")
	private String vFlagNewItem;

	@JsonProperty("vPerfumeCd")
	private String vPerfumeCd;

	@JsonProperty("vFlagPerfumeNew")
	private String vFlagPerfumeNew;

	@JsonProperty("vRefTypeCd")
	private String vRefTypeCd;

	@JsonProperty("vRefContCd")
	private String vRefContCd;

	@JsonProperty("vEvaluateCd")
	private String vEvaluateCd;

	@JsonProperty("vEvaluateGosiCd")
	private String vEvaluateGosiCd;

	@JsonProperty("vRefNote")
	private String vRefNote;

	@JsonProperty("vCodeType")
	private String vCodeType;

	private String vRegUserid;

	private String vUpdateUserid;

	private List<LabNoteCommonTagDTO> funcList;

	private List<LabNoteCommonRequestMateDTO> newMateList;

	private List<LabNoteCommonRequestMateDTO> perfMateList;

	private List<LabNoteCommonRequestMateDTO> funcMateList;

	private List<LabNoteCommonRequestMateDTO> requMateList;
}
