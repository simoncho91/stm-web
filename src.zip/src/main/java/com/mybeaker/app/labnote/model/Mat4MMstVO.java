package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Mat4MMstVO {

	@JsonProperty("vCheckNum")
	private String vCheckNum;

	@JsonProperty("vMatCd")
	private String vMatCd;

	@JsonProperty("vSapCd")
	private String vSapCd;

	@JsonProperty("v4mHisNum")
	private String v4mHisNum;

	@JsonProperty("vMatNm")
	private String vMatNm;

	@JsonProperty("vCompNm")
	private String vCompNm;

	@JsonProperty("vModReqDtm")
	private String vModReqDtm;

	@JsonProperty("vStatusCd")
	private String vStatusCd;

	@JsonProperty("vStatusCdnm")
	private String vStatusCdnm;

	@JsonProperty("vResStatusCd")
	private String vResStatusCd;

	@JsonProperty("vResStatusCdnm")
	private String vResStatusCdnm;

	@JsonProperty("vMat4m01nm")
	private String vMat4m01nm;

	@JsonProperty("vMat4m05nm")
	private String vMat4m05nm;

	@JsonProperty("vRmqcnm")
	private String vRmqcnm;
}
