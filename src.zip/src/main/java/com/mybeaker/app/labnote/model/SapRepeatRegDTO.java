package com.mybeaker.app.labnote.model;

import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SapRepeatRegDTO {
	
	@NotEmpty
	@JsonProperty("vPlantCd")
	private String vPlantCd;
	
	@NotEmpty
	@Size(min = 1)
	private List<String> mateCdList;
}
