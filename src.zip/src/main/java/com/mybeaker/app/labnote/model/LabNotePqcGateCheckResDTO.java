package com.mybeaker.app.labnote.model;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LabNotePqcGateCheckResDTO {
	
	@JsonProperty("vPqcItemCd")
	private String vPqcItemCd;
	
	@JsonProperty("vPqcCd")
	private String vPqcCd;
	
	@JsonProperty("vPqcItemNm")
	private String vPqcItemNm;
	
	@JsonProperty("vPqcChkText")
	private String vPqcChkText;
	
	@JsonProperty("vPqcChkDesc")
	private String vPqcChkDesc;
	
	@JsonProperty("vItemTypeCd")
	private String vItemTypeCd;
	
	@JsonProperty("vChkCondDb")
	private String vChkCondDb;
	
	@JsonProperty("vChkCondCol")
	private String vChkCondCol;
	
	@JsonProperty("vChkText")
	private String vChkText;
	
	@JsonProperty("vChkValue")
	private String vChkValue;
	
	@JsonProperty("vChkBeforeText")
	private String vChkBeforeText;
	
	@JsonProperty("vChkAfterText")
	private String vChkAfterText;
	
	@JsonProperty("vItemClearValue")
	private String vItemClearValue;
	
	@JsonProperty("vBeforeText")
	private String vBeforeText;
	
	@JsonProperty("vAfterText")
	private String vAfterText;
	
	@JsonProperty("vBuffer1")
	private String vBuffer1;
	
	@JsonProperty("vBuffer2")
	private String vBuffer2;
	
	@JsonProperty("vBuffer3")
	private String vBuffer3;
	
	@JsonProperty("vChoiceVal01")
	private String vChoiceVal01;
	
	@JsonProperty("vChoiceVal02")
	private String vChoiceVal02;
	
	@JsonProperty("vChoiceVal03")
	private String vChoiceVal03;
	
	@JsonProperty("vChoiceVal04")
	private String vChoiceVal04;
	
	@JsonProperty("vChoiceVal05")
	private String vChoiceVal05;
	
	@JsonProperty("vChoiceVal06")
	private String vChoiceVal06;
	
	@JsonProperty("vChoiceVal07")
	private String vChoiceVal07;
	
	@JsonProperty("vTextVal01")
	private String vTextVal01;
	
	@JsonProperty("vTextVal02")
	private String vTextVal02;
	
	@JsonProperty("vTextVal03")
	private String vTextVal03;
	
	@JsonProperty("vTextVal04")
	private String vTextVal04;
	
	@JsonProperty("vTextVal05")
	private String vTextVal05;
	
	@JsonProperty("vTextVal06")
	private String vTextVal06;
	
	@JsonProperty("vTextVal07")
	private String vTextVal07;
	
	@JsonProperty("vChoiceTextVal01")
	private String vChoiceTextVal01;
	
	@JsonProperty("vChoiceTextVal02")
	private String vChoiceTextVal02;
	
	@JsonProperty("vChoiceTextVal03")
	private String vChoiceTextVal03;
	
	@JsonProperty("vChoiceTextVal04")
	private String vChoiceTextVal04;
	
	@JsonProperty("vChoiceTextVal05")
	private String vChoiceTextVal05;
	
	@JsonProperty("vChoiceTextVal06")
	private String vChoiceTextVal06;
	
	@JsonProperty("vChoiceTextVal07")
	private String vChoiceTextVal07;
	
	@JsonProperty("vBufferVal01")
	private String vBufferVal01;
	
	@JsonProperty("vBufferVal02")
	private String vBufferVal02;
	
	@JsonProperty("vBufferVal03")
	private String vBufferVal03;

	@JsonProperty("vBufferVal04")
	private String vBufferVal04;
	
	@JsonProperty("vBufferVal05")
	private String vBufferVal05;
	
	@JsonProperty("vBufferVal06")
	private String vBufferVal06;
	
	@JsonProperty("vBufferVal07")
	private String vBufferVal07;
	
	@JsonProperty("vEtcHtml")
	private String vEtcHtml;
	
	@JsonProperty("vGateBeforeHtml")
	private String vGateBeforeHtml;
	
	@JsonProperty("codeList")
	private List<Map<String, Object>> codeList;
	
	@JsonProperty("codeType")
	private String codeType;
	
	@JsonProperty("vFlagGateChoice")
	private String vFlagGateChoice;
	
	@JsonProperty("vFlagGateText")
	private String vFlagGateText;
	
}
