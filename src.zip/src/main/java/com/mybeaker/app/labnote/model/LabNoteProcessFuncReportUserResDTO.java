package com.mybeaker.app.labnote.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.common.model.CommUserDesSearchInfoDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LabNoteProcessFuncReportUserResDTO {

	@JsonProperty("vNoteType")
	private String vNoteType;
	
	@JsonProperty("vGroupId")
	private String vGroupId;
	
	@JsonProperty("vChargeUserId")
	private String vChargeUserId;
	
	@JsonProperty("vChargeUserNm")
	private String vChargeUserNm;
	
	@JsonProperty("userList")
	List<CommUserDesSearchInfoDTO> userList;
	
}
