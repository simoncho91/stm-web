package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class SupTrMosStandardVO {

	@JsonProperty("vProductCd")
	private String vProductCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("nSeqno")
	private int nSeqno;

	@JsonProperty("vContentCd")
	private String vContentCd;

	@JsonProperty("vLandCd")
	private String vLandCd;

	@JsonProperty("vWerks")
	private String vWerks;

	@JsonProperty("vPrdct")
	private String vPrdct;

	@JsonProperty("vGday")
	private String vGday;

	@JsonProperty("vMgday")
	private String vMgday;

	@JsonProperty("vRfdt")
	private String vRfdt;

	@JsonProperty("vUsep")
	private String vUsep;

	@JsonProperty("vMkday")
	private String vMkday;

	@JsonProperty("vZpgew")
	private String vZpgew;

	@JsonProperty("vZrect")
	private String vZrect;

	@JsonProperty("vZptnt")
	private String vZptnt;

	@JsonProperty("vRegUserid")
	private String vRegUserid;

	@JsonProperty("vRegDtm")
	private String vRegDtm;
}
