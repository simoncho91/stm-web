package com.mybeaker.app.labnote.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LabNoteTestBoardContDTO {
	
	@JsonProperty("vContPkCd")
	private String vContPkCd;
	
	@JsonProperty("vContCd")
	private String vContCd;
	
	@JsonProperty("vContNm")
	private String vContNm;
	
	@JsonProperty("vFlagRepresent")
	private String vFlagRepresent;
	
	@JsonProperty("vTctnBynmNm")
	private String vTctnBynmNm;
	

}
