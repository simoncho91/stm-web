package com.mybeaker.app.issuetrack.model;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class IssuetrackCommInfoDTO{
	
	@NotEmpty
	@JsonProperty("vNoteType")
	private String vNoteType;
	
	@NotEmpty
	@JsonProperty("vIssueTrackCd")
	private String vIssueTrackCd;
	
	@NotEmpty
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;
	
	@NotEmpty
	@JsonProperty("vContCd")
	private String vContCd;
	
	private String localLanguage;
}
