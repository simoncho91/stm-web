package com.mybeaker.app.issuetrack.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.mybeaker.app.issuetrack.model.IssuetrackCommInfoDTO;
import com.mybeaker.app.issuetrack.model.IssuetrackCommInfoReqDTO;
import com.mybeaker.app.issuetrack.model.IssuetrackCommonRegDTO;

@Mapper
public interface IssuetrackCommonMapper {

	List<IssuetrackCommInfoReqDTO> selectCommIssuetrackList(IssuetrackCommInfoDTO issuetrackCommInfoDTO);
	
	public int insertCommIssuetrack(IssuetrackCommonRegDTO issuetrackCommonRegDTO);
	
}
