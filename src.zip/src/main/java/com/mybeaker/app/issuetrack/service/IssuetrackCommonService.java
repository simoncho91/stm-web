package com.mybeaker.app.issuetrack.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.mybeaker.app.common.model.AlarmRegDTO;
import com.mybeaker.app.common.service.CommonService;
import com.mybeaker.app.issuetrack.mapper.IssuetrackCommonMapper;
import com.mybeaker.app.issuetrack.model.IssuetrackCommInfoDTO;
import com.mybeaker.app.issuetrack.model.IssuetrackCommInfoReqDTO;
import com.mybeaker.app.issuetrack.model.IssuetrackCommonRegDTO;
import com.mybeaker.app.model.Const;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.utils.SessionUtil;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class IssuetrackCommonService {

	private final IssuetrackCommonMapper issuetrackCommonMapper;

	private final CommonService commonService;

	private final SessionUtil sessionUtil;

	public ResponseVO selectCommIssuetrackList(IssuetrackCommInfoDTO issuetrackCommInfoDTO) {
		ResponseVO responseVO = new ResponseVO();

		issuetrackCommInfoDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
		List<IssuetrackCommInfoReqDTO> list = issuetrackCommonMapper.selectCommIssuetrackList(issuetrackCommInfoDTO);

		responseVO.setOk(list);
		return responseVO;
	}


	@Transactional
	public ResponseVO insertCommIssuetrack (IssuetrackCommonRegDTO issuetrackCommonRegDTO) {
		ResponseVO responseVO = new ResponseVO();
		issuetrackCommonRegDTO.setVRegUserid(sessionUtil.getLoginId());
		int result = issuetrackCommonMapper.insertCommIssuetrack(issuetrackCommonRegDTO);

		if (result > 0) {
			commonService.sendAlarm(AlarmRegDTO.builder()
											.vLabNoteCd(issuetrackCommonRegDTO.getVLabNoteCd())
											.vStatusCd("AL_NOTE0")
											.vAlrTypeCd("AL_NOTE0_02")
											.vTypeCd(Const.TIMELINE)
											.vContNm(issuetrackCommonRegDTO.getVContNm())
											.vContCd(issuetrackCommonRegDTO.getVContCd())
											.vNoteType(issuetrackCommonRegDTO.getVNoteType())
											.build());
		}

		responseVO.setCreateOk(null);
		return responseVO;
	}


}
