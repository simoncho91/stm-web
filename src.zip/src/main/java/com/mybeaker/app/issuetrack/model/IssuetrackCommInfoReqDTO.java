package com.mybeaker.app.issuetrack.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class IssuetrackCommInfoReqDTO {

	@JsonProperty("vIssueTrackCd")
	private String vIssueTrackCd;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vLot")
	private String vLot;

	@JsonProperty("vTypeCd")
	private String vTypeCd;

	@JsonProperty("vTypeNm")
	private String vTypeNm;

	@JsonProperty("vContent")
	private String vContent;

	@JsonProperty("vNoteType")
	private String vNoteType;

	@JsonProperty("vTypeColor")
	private String vTypeColor;

	@JsonProperty("vFlagDel")
	private String vFlagDel;

	@JsonProperty("vRegUserid")
	private String vRegUserid;

	@JsonProperty("vRegUsernm")
	private String vRegUsernm;

	@JsonProperty("vRegDtm")
	private String vRegDtm;

	private String localLanguage;

}
