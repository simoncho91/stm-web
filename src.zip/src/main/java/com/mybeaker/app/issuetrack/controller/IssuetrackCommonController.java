package com.mybeaker.app.issuetrack.controller;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mybeaker.app.issuetrack.model.IssuetrackCommInfoDTO;
import com.mybeaker.app.issuetrack.model.IssuetrackCommonRegDTO;
import com.mybeaker.app.issuetrack.service.IssuetrackCommonService;
import com.mybeaker.app.model.vo.ResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Tag(name = "Issue Track 관리", description = "Issue Track 관리")
@RestController
@RequestMapping("/api/issuecommon")
public class IssuetrackCommonController {

	private final IssuetrackCommonService issuetrackCommonService;

	//팝업
	//저장 된 내용 불러오기
	@Operation(summary = "Issue Track 조회", description = "Issue Track 목록 조회한다.")
	@GetMapping("/select-comm-issuetrack-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectCommIssuetrackList (
			IssuetrackCommInfoDTO issuetrackCommInfoDTO
			) {
		log.debug("select-comm-issuetrack-list Start!");
		log.debug("IssuetrackCommInfoDTO : {}", issuetrackCommInfoDTO.toString());

		return ResponseEntity.ok(issuetrackCommonService.selectCommIssuetrackList(issuetrackCommInfoDTO));
	}

	//저장
	@Operation(summary = "Issue Track 저장", description = "Issue Track 저장한다.")
	@PostMapping("/insert-comm-issuetrack")
	public @ResponseBody ResponseEntity<ResponseVO> insertCommIssuetrack (
			@RequestBody @Valid IssuetrackCommonRegDTO issuetrackCommonRegDTO) {
		log.debug("insertCommIssuetrack ");
		log.debug("IssuetrackCommonRegDTO : {}", issuetrackCommonRegDTO.toString());

		return ResponseEntity.ok(issuetrackCommonService.insertCommIssuetrack(issuetrackCommonRegDTO));
	}
}
