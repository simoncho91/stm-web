package com.mybeaker.app.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentPagingDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class CommUserSearchInfoDTO extends ParentPagingDTO {
	@JsonProperty("vKeyword")
	private String vKeyword;
	
	private String localLanguage;
}
