package com.mybeaker.app.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class AlarmDTO {
	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("vStatusCd")
	private String vStatusCd;

	@JsonProperty("vMessage")
	private String vMessage;

	@JsonProperty("vMoveUrl")
	private String vMoveUrl;

	@JsonProperty("vFlagCheck")
	private String vFlagCheck;

	@JsonProperty("vRegDtm")
	private String vRegDtm;
}
