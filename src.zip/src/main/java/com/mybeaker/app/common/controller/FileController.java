package com.mybeaker.app.common.controller;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.mybeaker.app.common.model.UploadDTO;
import com.mybeaker.app.common.model.UploadTempDTO;
import com.mybeaker.app.common.service.AWSService;
import com.mybeaker.app.common.service.CommonService;
import com.mybeaker.app.config.SecurityUser;
import com.mybeaker.app.model.enums.CommonResultCode;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.utils.CommonUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/file")
@RequiredArgsConstructor
public class FileController {
	private final CommonService commonService;

	private final AWSService awsService;

	@PostMapping(value="/upload-temp", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public @ResponseBody ResponseEntity<ResponseVO> saveCommAttachTemp (
			@RequestPart(value = "files", required = false) List<MultipartFile> files,
			@AuthenticationPrincipal SecurityUser securityUser
			) throws IOException {
		log.debug("UploadController.uploadFiles : files size : {}", files != null ? files.size() : 0);
		ResponseVO responseVO = new ResponseVO();
		String availableFileExt = ".png|.gif|.jpg|.jpeg|.xlsx|.xls|.docx|.doc|.pptx|.ppt|.pdf";
		String fileName = "";
		int uploadFailCnt = 0;

		for (MultipartFile file : files) {
			fileName = file.getOriginalFilename();

			if (availableFileExt.indexOf(fileName.substring(fileName.lastIndexOf(".") + 1).toLowerCase()) == -1) {
				uploadFailCnt++;
			}
		}

		if (uploadFailCnt > 0) {
			responseVO.setOk(CommonResultCode.FAIL_EXT, CommonResultCode.FAIL_EXT.getMessage());
			return ResponseEntity.ok(responseVO);
		}

		List<UploadTempDTO> list = commonService.saveCommAttachTemp(files);
		responseVO.setOk(list);

		return ResponseEntity.ok(responseVO);
	}

	@GetMapping()
	public @ResponseBody ResponseEntity<ResponseVO> selectCommAttachList (
			@RequestParam(value="vRecordid") String vRecordid,
			@RequestParam(value="vUploadid") String vUploadid
			) {
		log.debug("ApiFileController.selectCommAttachList => params : { vRecordid: {}, vUploadid: {} }", vRecordid, vUploadid);

		ResponseVO responseVO = new ResponseVO();
		responseVO.setOk(commonService.selectCommAttachList(vRecordid, vUploadid));

		return ResponseEntity.ok(responseVO);
	}

	@GetMapping(value="/download")
//	local 환경에서 작업시 주석해제 및 WebMvcConfig 의 allowedOrigins("*") 주석해제 후 사용. 작업 후 다시 주석처리 요망.
//	@CrossOrigin(value= {"*"}, exposedHeaders = { HttpHeaders.CONTENT_DISPOSITION, "filename" })
	public @ResponseBody Object downloadFile (
		@RequestParam(value="vAttType") String vAttType,
		@RequestParam(value="vAttachid") String vAttachid
			) throws IOException {
		log.debug("ApiFileController.downloadFile => params : { vAttType: {}, vAttachid {} }", vAttType, vAttachid);

		UploadDTO uploadDTO = commonService.selectCommAttachInfo(vAttType, vAttachid);
		HttpHeaders headers = new HttpHeaders();
		headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + URLEncoder.encode(uploadDTO.getVAttachnm(), "UTF-8"));
		headers.add("filename", uploadDTO.getVAttachnm());

		if ("TIUM".equals(vAttType) && uploadDTO != null && StringUtils.isNotEmpty(uploadDTO.getVAttachPath())) {
			uploadDTO.setVKeyPath("UPLOAD/" + CommonUtil.getTiumFilePath(uploadDTO.getVAttachPath()) + uploadDTO.getVAttachid() + uploadDTO.getVAttachExt());
		}

		byte[] fileBytea = null;
		if (uploadDTO != null && StringUtils.isNotEmpty(uploadDTO.getVKeyPath())) {
			if (!"TIUM".equals(vAttType)) {
				fileBytea = awsService.download(uploadDTO.getVKeyPath());
			} else {
				fileBytea = awsService.tiumBucketDownload(uploadDTO.getVKeyPath());
			}
		}

		return ResponseEntity.ok()
					.contentLength(fileBytea == null ? 0 : fileBytea.length)
					.contentType(MediaType.APPLICATION_OCTET_STREAM)
					.headers(headers)
					.body(fileBytea);
	}

	@GetMapping(value="/mail-download")
//	local 환경에서 작업시 주석해제 및 WebMvcConfig 의 allowedOrigins("*") 주석해제 후 사용. 작업 후 다시 주석처리 요망.
//	@CrossOrigin(value= {"*"}, exposedHeaders = { HttpHeaders.CONTENT_DISPOSITION, "filename" })
	public @ResponseBody Object MaildownloadFile (
		@RequestParam(value="vAttachid") String vAttachid
			) throws IOException {
		log.debug("ApiFileController.downloadFile => params : { vAttachid: {}, }", vAttachid);

		UploadDTO uploadDTO = commonService.selectCommAttachInfo("BKR", vAttachid);
		HttpHeaders headers = new HttpHeaders();
		headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + URLEncoder.encode(uploadDTO.getVAttachnm(), "UTF-8"));
		headers.add("filename", uploadDTO.getVAttachnm());

		byte[] fileBytea = null;
		if (StringUtils.isNotEmpty(uploadDTO.getVKeyPath())) {
			fileBytea = awsService.download(uploadDTO.getVKeyPath());
		}

		return ResponseEntity.ok()
					.contentLength(fileBytea == null ? 0 : fileBytea.length)
					.contentType(MediaType.APPLICATION_OCTET_STREAM)
					.headers(headers)
					.body(fileBytea);
	}
}
