package com.mybeaker.app.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class MessageDTO extends ParentDTO {
	@JsonProperty("nMessageNo")
	private long nMessageNo;

	@JsonProperty("vRecordid")
	private String vRecordid;

	@JsonProperty("vMessage")
	private String vMessage;

	@JsonProperty("vUpdateDt")
	private String vUpdateDt;

	@JsonProperty("vUpdateTm")
	private String vUpdateTm;

	@JsonProperty("vUpdateUsernm")
	private String vUpdateUsernm;

	@JsonProperty("vDeptnm")
	private String vDeptnm;

	@JsonProperty("vLaborUserid")
	private String vLaborUserid;

	@Builder
	public MessageDTO(long nMessageNo, String vRecordid, String vMessage, String vLaborUserid,
			String vUpdateDt, String vUpdateTm, String vUpdateUsernm, String vDeptnm,
			String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.nMessageNo = nMessageNo;
		this.vRecordid = vRecordid;
		this.vMessage = vMessage;
		this.vLaborUserid = vLaborUserid;
		this.vUpdateDt = vUpdateDt;
		this.vUpdateTm = vUpdateTm;
		this.vUpdateUsernm = vUpdateUsernm;
		this.vDeptnm = vDeptnm;
	}
}
