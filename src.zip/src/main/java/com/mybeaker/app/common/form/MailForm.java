package com.mybeaker.app.common.form;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;

import com.mybeaker.app.common.model.MailDTO;
import com.mybeaker.app.labnote.model.BatchStatusProcessVO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReportDataDTO;
import com.mybeaker.app.labnote.model.WokReportSecretResDTO;
import com.mybeaker.app.model.enums.ApprovalResultCode;
import com.mybeaker.app.utils.CommonUtil;
import com.mybeaker.app.utils.PropertyUtil;

public class MailForm {

	private String WEB_URL				= PropertyUtil.getProperty("bkr.web.url");

	private String TIUM_WEB_URL	 	= PropertyUtil.getProperty("tium.web.url");

	private String GLOBAL_CSS = new StringBuilder()
			.append("\n").append("@charset \"UTF-8\";")
			.append("\n").append("")
			.append("\n").append("html,")
			.append("\n").append("body,")
			.append("\n").append("pre,")
			.append("\n").append("button,")
			.append("\n").append("select,")
			.append("\n").append("textarea,")
			.append("\n").append("[type='button'],")
			.append("\n").append("[type='submit'],")
			.append("\n").append("[type='text'],")
			.append("\n").append("[type='password'],")
			.append("\n").append("[type='search'],")
			.append("\n").append("[type='email'],")
			.append("\n").append("[type='url'],")
			.append("\n").append("[type='number'],")
			.append("\n").append("[type='tel'],")
			.append("\n").append("[type='file'],")
			.append("\n").append("[type='date'],")
			.append("\n").append("[type='time'] {")
			.append("\n").append("	margin: 0;")
			.append("\n").append("	padding: 0;")
			.append("\n").append("	border: 0;")
			.append("\n").append("	font-size: 14px;")
			.append("\n").append("	font-family: 'notokr', sans-serif;")
			.append("\n").append("	/* font-family: 'Noto Sans CJKR', sans-serif !important; */")
			.append("\n").append("	color: #000000;")
			.append("\n").append("	font-style:normal;")
			.append("\n").append("	line-height: 100%;")
			.append("\n").append("	vertical-align: baseline;")
			.append("\n").append("	letter-spacing: -.5px;")
			.append("\n").append("	-webkit-text-size-adjust : none;")
			.append("\n").append("	/* 크롬, 사파리, 오페라 신버전 */")
			.append("\n").append("	-ms-text-size-adjust : none;")
			.append("\n").append("	/* IE */")
			.append("\n").append("	-moz-text-size-adjust : none;")
			.append("\n").append("	/* 파이어폭스 */")
			.append("\n").append("	-o-text-size-adjust : none;")
			.append("\n").append("	/* 오페라 구버전 */")
			.append("\n").append("}")
			.append("\n").append("")
			.append("\n").append("button:focus,")
			.append("\n").append("[type='button']:focus,")
			.append("\n").append("[type='submit']:focus {")
			.append("\n").append("  outline-width: 1px;")
			.append("\n").append("  outline-style: dotted;")
			.append("\n").append("}")
			.append("\n").append("")
			.append("\n").append("label {")
			.append("\n").append("  cursor: pointer;")
			.append("\n").append("}")
			.append("\n").append("")
			.append("\n").append("")
			.append("\n").append("html, body{")
			.append("\n").append("	height: 100%;")
			.append("\n").append("	font-size: 62.5%;")
			.append("\n").append("}")
			.append("\n").append(".wrap{")
			.append("\n").append("	display: flex;")
			.append("\n").append("  -ms-display: flexbox;")
			.append("\n").append("  display: -moz-box;")
			.append("\n").append("  display: -ms-flexbox;")
			.append("\n").append("  display: -webkit-flex;")
			.append("\n").append("  flex-direction: column;")
			.append("\n").append("  min-width: 152rem;")
			.append("\n").append("  /* overflow-y: scroll; */")
			.append("\n").append("  /* overflow: auto; */")
			.append("\n").append("  min-height: 88rem;")
			.append("\n").append("  height: 100%;")
			.append("\n").append("  font-size: 62.5%;")
			.append("\n").append("}")
			.append("\n").append("div{")
			.append("\n").append("  font-size: 14px;")
			.append("\n").append("}")
			.toString();

	private String STYLE_TOP 		 	= "padding:2% 0;width:100%;height:100%;background-color:#fff;letter-spacing:-1px";

	private String STYLE_TABLE		 	= "max-width:800px;width:100%;background-color:#fff;-webkit-text-size-adjust:100%;text-align:left;border:1px solid #ccd9e6;";

	// 로고 스타일 주는 부분에 헤더 높이 지정하는 부분이 있는데, (height:381px; <- 이 부분)

	// 해당 부분이 동적으로 변해야 하는 상황이 있기 때문에, 메소드로 교체 (getHeaderStyle)

//	private String STYLE_LOGO		 	= "display:block;height:381px;padding:40px 40px 0 40px;box-sizing: border-box;overflow:visible;background:url(" + WEB_URL + "/img/bg-mailForm.png) no-repeat;background-position: 95% 24%;";

	private String STYLE_SHORTCUT_BTN	= "display:block;margin: 30px auto 76px auto;width:200px; height: 40px;padding: 13px 21px;font-size: 1.3rem;font-weight: 400; border-radius: 6px;line-height: 100%; text-decoration: none;text-align:center;color:#fff;background-color:#4b7ae4;box-sizing: border-box;letter-spacing: -0.4px;";

	private String STYLE_BOTTOM 	 	= "color:#fff;font-family:'notokr';font-size:14px;text-align: center;letter-spacing: 0;";

	public MailForm() {}

	public String getMailContent(String type, HashMap<String, String> args) {
		String mailContent = "";

		if (StringUtils.isNotEmpty(type)) {
			switch (type) {
				case MailDTO.MAIL_EXAMPLE:
					mailContent = getExampleMailForm(args);
					break;
				case MailDTO.MAIL_APPROVAL:
					mailContent = getApprovalMailForm(args);
					break;
				case MailDTO.MAIL_SHELFLIFE_CHANGE_INFO:
					mailContent = getShelfListDeptMailForm(args);
					break;
				case MailDTO.MAIL_GATE_APPROVAL_END:
					mailContent = getElabNoteApprovalMailForm(args);
					break;
				case MailDTO.MAIL_REFERENCE:
					mailContent = getReferenceMail(args);
					break;
				case MailDTO.MAIL_ANSWER_FUNC_TEST:
					mailContent = getAnswerFuncTestMail(args);
					break;
				case MailDTO.MAIL_MARKETER_SHARE:
					mailContent = getMarketerShareMail(args);
					break;
				case MailDTO.MAIL_SC_CHARGER:
					mailContent = getScChargerCompleteMail(args);
					break;
				case MailDTO.MAIL_MRQ011_ALARM:
					mailContent = getTrMrq011PrsvAlarmMail(args);
					break;
				case MailDTO.MAIL_SA_REPORT_SUPO:
					mailContent = getOnlyDirectLinkMail(args);
					break;
				default:
					break;
			}
		}

		return mailContent;
	}

	public String getMailContentFromObject(String type, HashMap<String, Object> obj) {
		String mailContent = "";

		if (StringUtils.isNotEmpty(type)) {
			switch (type) {
				case MailDTO.MAIL_REQUEST_FUNC_TEST:
					mailContent = getRequestFuncTestMail(obj);
					break;
				case MailDTO.MAIL_SA_REPORT_SECRET:
					mailContent = getSaReportSecretMail(obj);
					break;
				default:
					break;
			}
		}

		return mailContent;
	}

	private String getHeaderStyle(int headerHeight) {
		return "display:block;height:" + headerHeight + "px;padding:40px 40px 0 40px;box-sizing: border-box;overflow:visible;background:url(" + WEB_URL + "/img/bg-mailForm.png) no-repeat;background-position: 95% 24%;";
	}

	// mail Header
	private String getTop() {
		StringBuilder sb = new StringBuilder();
		sb.append("\n").append("<!DOCTYPE html>");
		sb.append("\n").append("<html lang=\"ko \">");
		sb.append("\n").append("<head>");
		sb.append("\n").append("	<meta charset=\"UTF-8\">");
		sb.append("\n").append("	<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">");
		sb.append("\n").append("	<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">");
		sb.append("\n").append("	<title>myBEAKER</title>");
		sb.append("\n").append("	<style>");
//		sb.append("\n").append("		@import url(").append(WEB_URL).append("/css/reset.css);");
		sb.append("\n").append(GLOBAL_CSS);
		sb.append("\n").append("	</style>");
		sb.append("\n").append("</head>");
		sb.append("\n").append("<body>");
		sb.append("\n").append("	<div>");
		sb.append("\n").append("		<table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"").append(STYLE_TOP).append("\">");
		sb.append("\n").append("			<tbody>");
		sb.append("\n").append("				<tr>");
		sb.append("\n").append("					<td align=\"center\">");
		sb.append("\n").append("						<div style=\"max-width:600px; margin:0 auto\">");
		sb.append("\n").append("							<table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"").append(STYLE_TABLE).append("\">");
		sb.append("\n").append("								<tbody>");
		return sb.toString();
	}

	// mail Bottom
	private String getBottom() {
		StringBuilder sb = new StringBuilder();
		sb.append("\n").append("									<tr style=\"height:46px;background-color:#2f313a;\">");
		sb.append("\n").append("										<td>");
		sb.append("\n").append("											<p style=\"").append(STYLE_BOTTOM).append("\">© AMOREPACIFIC R&D. All rights reserved.</p>");
		sb.append("\n").append("										</td>");
		sb.append("\n").append("									</tr>");
		sb.append("\n").append("								</tbody>");
		sb.append("\n").append("							</table>");
		sb.append("\n").append("						</div>");
		sb.append("\n").append("					 </td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("			</tbody>");
		sb.append("\n").append("		</table>");
		sb.append("\n").append("	</div>");
		sb.append("\n").append("</body>");
		sb.append("\n").append("</html>");
		return sb.toString();
	}

	// Example
	private String getExampleMailForm(HashMap<String, String> args) {
		StringBuilder sb = new StringBuilder();
		sb.append("\n").append(this.getTop());
		sb.append("\n").append("<tr style=\"").append(getHeaderStyle(381)).append("\">");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<img src=\"").append(WEB_URL).append("/img/bg-mailLogo.png\" usemap=\"#Map\" border=\"0\" alt=\"myBEAKER\"/>");
		sb.append("\n").append("		<p style=\"margin:91px 0 0 0;font-size:30px;font-weight:600;letter-spacing: -3.5px;\">마케터 공유시 발송 내용 정리 요청</p>");
		sb.append("\n").append("		<p style=\"margin:61px 0 0 0;font-size:16px;letter-spacing: -1px;\"><span style=\"font-weight:600;letter-spacing: -1px;\">").append(args.get("userNm")).append("</span>님 안녕하세요.</p>");
		sb.append("\n").append("		<p style=\"margin:20px 0 0 0;font-size:16px;font-weight:600;letter-spacing: -1px;\">").append(args.get("contNm")).append("</p>");
		sb.append("\n").append("		<p style=\"margin:20px 0 0 0;font-size:16px;letter-spacing: -1px;\">해당 원료가 공유되었습니다.</p>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr>  ");
		sb.append("\n").append("<tr style=\"display:block;padding:0 40px;box-sizing:border-box;\">");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<table style=\"width: 100%; border-collapse: collapse; border-spacing: 0;table-layout: fixed;border-top: 1px solid #92b7fc;\">");
		sb.append("\n").append("			<colgroup>");
		sb.append("\n").append("				<col style=\"width:19rem\">");
		sb.append("\n").append("				<col style=\"width:auto\">");
		sb.append("\n").append("			</colgroup>");
		sb.append("\n").append("			<tbody style=\"display: table-row-group;vertical-align: middle; border-color: inherit;\">");
		sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;\">");
		sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">신상품 여부");
		sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left;	letter-spacing: -0.5px;\">").append(args.get("newFlag")).append("</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
		sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">신출시 국가/시기");
		sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left;	letter-spacing: -0.5px;\">").append(args.get("originNation")).append("/").append(args.get("originDate")).append("</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
		sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">파일럿");
		sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left;	letter-spacing: -0.5px;\">").append(args.get("pilotDate")).append("</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
		sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">타겟 COST/용량");
		sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left;	letter-spacing: -0.5px;\">").append(args.get("targetCost")).append("/").append(args.get("volume")).append("</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;border-bottom:1px solid #f1f3f8;\">");
		sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">사용고객");
		sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left;	letter-spacing: -0.5px;\">").append(args.get("customer")).append("</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("			</tbody>");
		sb.append("\n").append("		</table>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr> ");
		sb.append("\n").append("<tr>");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<a href=\"").append(WEB_URL).append("\" target=\"_blank\" style=\"").append(STYLE_SHORTCUT_BTN).append("\">myBEAKER 시스템 바로가기</a>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr>");
		sb.append("\n").append(this.getBottom());
		return sb.toString();
	}

	// 결재 메일
	private String getApprovalMailForm(HashMap<String, String> args) {
		String resultStatus = args.get("resultStatus");
		String url = StringUtils.isNotEmpty(args.get("vPageUrl")) ? args.get("vPageUrl") : "";

		StringBuilder sb = new StringBuilder();
		sb.append("\n").append(this.getTop());
//		sb.append("\n").append("<tr style=\"display:block;height:140px;padding:40px 40px 0 40px;box-sizing: border-box;overflow:visible;background:url(\"").append(WEB_URL).append("/img/bg-mailForm.png\") no-repeat;background-position: 95% 24%;\">");
		sb.append("\n").append("<tr style=\"").append(getHeaderStyle(140)).append("\">");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<img src=\"").append(WEB_URL).append("/img/bg-mailLogo.png\" usemap=\"#Map\" border=\"0\" alt=\"myBEAKER\"/>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr>  ");
		sb.append("\n").append("<tr style=\"display:block;padding:0 40px;box-sizing:border-box;\">");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<table style=\"width: 100%; border-collapse: collapse; border-spacing: 0;table-layout: fixed;border-top: 1px solid #92b7fc;\">");
		sb.append("\n").append("			<colgroup>");
		sb.append("\n").append("				<col style=\"width:19rem\">");
		sb.append("\n").append("				<col style=\"width:auto\">");
		sb.append("\n").append("			</colgroup>");
		sb.append("\n").append("			<tbody style=\"display: table-row-group;vertical-align: middle; border-color: inherit;\">");
		if (ApprovalResultCode.ACCEPT_END.getCode().equals(resultStatus)
		 || ApprovalResultCode.APPR_BACK.getCode().equals(resultStatus)) {
			sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;\">");
			sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">결재자");
			sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left;	letter-spacing: -0.5px;\">").append(args.get("user")).append("</td>");
			sb.append("\n").append("				</tr>");
			sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
			sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">결재일시");
			sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left;	letter-spacing: -0.5px;\">").append(args.get("date")).append("</td>");
			sb.append("\n").append("				</tr>");
			sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
			sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">결재의견");
			sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left;	letter-spacing: -0.5px;\">").append(args.get("opinion") == null ? "" : args.get("opinion")).append("</td>");
			sb.append("\n").append("				</tr>");
		} else {
			sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;\">");
			sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">기안자");
			sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left;	letter-spacing: -0.5px;\">").append(args.get("user")).append("</td>");
			sb.append("\n").append("				</tr>");
			sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
			sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">기안일시");
			sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left;	letter-spacing: -0.5px;\">").append(args.get("date")).append("</td>");
			sb.append("\n").append("				</tr>");
			sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
			sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">기안의견");
			sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left;	letter-spacing: -0.5px;\">").append(args.get("opinion") == null ? "" : args.get("opinion")).append("</td>");
			sb.append("\n").append("				</tr>");
		}
		
		sb.append("\n").append("			</tbody>");
		sb.append("\n").append("		</table>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr> ");
		sb.append("\n").append("<tr>");
		sb.append("\n").append("	<td>");
		if (url.indexOf(".do") > -1) {
			sb.append("\n").append("		<a href=\"").append(TIUM_WEB_URL).append(url).append("\"  target=\"_blank\" style=\"").append(STYLE_SHORTCUT_BTN).append("\">티움넷 바로가기</a>");
		} else {
			sb.append("\n").append("		<a href=\"").append(WEB_URL).append(url).append("\"  target=\"_blank\" style=\"").append(STYLE_SHORTCUT_BTN).append("\">myBEAKER 시스템 바로가기</a>");
		}
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr>");
		sb.append("\n").append(this.getBottom());
		return sb.toString();
	}

	// 사용기한 변경안내 메일
	private String getShelfListDeptMailForm(HashMap<String, String> args) {
		String url = StringUtils.isNotEmpty(args.get("url")) ? args.get("url") : "";
		
		List<String> apprContCdList = null;
		List<String> apprBeforeLifeList = null;
		List<String> apprAfterLifeList = null;

		if (StringUtils.isNotEmpty(args.get("apprContCdList"))) {
			apprContCdList = Arrays.asList(args.get("apprContCdList").split(","));
		}
		if (StringUtils.isNotEmpty(args.get("apprBeforeLifeList"))) {
			apprBeforeLifeList = Arrays.asList(args.get("apprBeforeLifeList").split(","));
		}
		if (StringUtils.isNotEmpty(args.get("apprAfterLifeList"))) {
			apprAfterLifeList = Arrays.asList(args.get("apprAfterLifeList").split(","));
		}

		if (apprContCdList == null || apprBeforeLifeList == null || apprAfterLifeList == null) {
			return "";
		}

		int length = apprContCdList.size();

		StringBuilder sb = new StringBuilder();
		sb.append("\n").append(this.getTop());
//		sb.append("\n").append("<tr style=\"display:block;height:140px;padding:40px 40px 0 40px;box-sizing: border-box;overflow:visible;background:url(\"").append(WEB_URL).append("/img/bg-mailForm.png\") no-repeat;background-position: 95% 24%;\">");
		sb.append("\n").append("<tr style=\"").append(getHeaderStyle(140)).append("\">");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<img src=\"").append(WEB_URL).append("/img/bg-mailLogo.png\" usemap=\"#Map\" border=\"0\" alt=\"myBEAKER\"/>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr>  ");
		sb.append("\n").append("<tr style=\"display:block;padding:0 40px;box-sizing:border-box;\">");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<table style=\"width: 100%; border-collapse: collapse; border-spacing: 0;table-layout: fixed;border-top: 1px solid #92b7fc;\">");
		sb.append("\n").append("			<colgroup>");
		sb.append("\n").append("				<col style=\"width:19rem\">");
		sb.append("\n").append("				<col style=\"width:auto\">");
		sb.append("\n").append("			</colgroup>");
		sb.append("\n").append("			<tbody style=\"display: table-row-group;vertical-align: middle; border-color: inherit;\">");
		if (length > 0) {
			for (int i = 0; i < length; i++) {
				String apprContCd = apprContCdList.get(i);
				String apprBeforeLife = apprBeforeLifeList.get(i);
				String apprAfterLife = apprAfterLifeList.get(i);

				sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
				sb.append("\n").append("					<th rowspan=\"2\" style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">내용물 코드 : ").append(apprContCd);
				sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left;	letter-spacing: -0.5px;\">변경 전 사용기한 : ").append(apprBeforeLife).append("M</td>");
				sb.append("\n").append("				</tr>");
				sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
				sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left;	letter-spacing: -0.5px;\">변경 후 사용기한 : ").append(apprAfterLife).append("M</td>");
				sb.append("\n").append("				</tr>");
			}
		}
		sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
		sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">URL");
		sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left;	letter-spacing: -0.5px;\"><a href=\"").append(TIUM_WEB_URL).append(url).append("\">[ LINK ]</a></td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("			</tbody>");
		sb.append("\n").append("		</table>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr> ");
		sb.append("\n").append("<tr>");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<a href=\"").append(WEB_URL).append("\" target=\"_blank\" style=\"").append(STYLE_SHORTCUT_BTN).append("\">myBEAKER 시스템 바로가기</a>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr>");
		sb.append("\n").append(this.getBottom());
		return sb.toString();
	}

	// 결재 완료 메일(GATE0, GATE1, GATE2)
	private String getElabNoteApprovalMailForm(HashMap<String, String> args) {

		List<String> apprUsernmList = Arrays.asList(args.get("vApprUsernm").split(","));
		List<String> apprDtmList = Arrays.asList(args.get("vApprDtm").split(","));
		List<String> apprOpinionList = Arrays.asList(args.get("vApprOpinion").split(","));
		String vPageUrl = WEB_URL + args.get("vPageUrl");

		StringBuilder sb = new StringBuilder();
		sb.append("\n").append(this.getTop());
		sb.append("\n").append("<tr style=\"").append(getHeaderStyle(140)).append("\">");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<img src=\"").append(WEB_URL).append("/img/bg-mailLogo.png\" usemap=\"#Map\" border=\"0\" alt=\"myBEAKER\"/>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr>  ");
		sb.append("\n").append("<tr style=\"display:block;padding:0 40px;box-sizing:border-box;\">");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<table style=\"width: 100%; border-collapse: collapse; border-spacing: 0;table-layout: fixed;border-top: 1px solid #92b7fc;\">");
		sb.append("\n").append("			<colgroup>");
		sb.append("\n").append("				<col style=\"width:13rem\">");
		sb.append("\n").append("				<col style=\"width:13rem\">");
		sb.append("\n").append("				<col style=\"width:13rem\">");
		sb.append("\n").append("				<col style=\"width:auto\">");
		sb.append("\n").append("			</colgroup>");
		sb.append("\n").append("			<tbody style=\"display: table-row-group;vertical-align: middle; border-color: inherit;\">");
		if (!ObjectUtils.isEmpty(apprUsernmList) && !ObjectUtils.isEmpty(apprDtmList) && !ObjectUtils.isEmpty(apprOpinionList)) {
			sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
			sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">기안자</th>");
			sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left;	letter-spacing: -0.5px;\">").append(apprUsernmList.get(0)).append("</td>");
			sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">기안일시</th>");
			sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left;	letter-spacing: -0.5px;\">").append(apprDtmList.get(0)).append("</td>");
			sb.append("\n").append("				</tr>");
			sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
			sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">기안의견</th>");
			sb.append("\n").append("					<td colspan=\"3\" style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left;	letter-spacing: -0.5px;\">").append(apprOpinionList.get(0)).append("</td>");
			sb.append("\n").append("				</tr>");
			for (int i = 0; i < apprUsernmList.size(); i++) {
				String apprUsernm = apprUsernmList.get(i) == null ? "" : apprUsernmList.get(i);
				String apprOpinion = apprOpinionList.get(i) == null ? "" : apprOpinionList.get(i);

				sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
				sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left; line-height:2.3rem;\">").append(apprUsernm).append("<br/>[결재의견]</th>");
				sb.append("\n").append("					<td colspan=\"3\" style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left;	letter-spacing: -0.5px;\">").append(apprOpinion).append("</td>");
				sb.append("\n").append("				</tr>");
			}
		}
		sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
		sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">URL</th>");
		sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left;	letter-spacing: -0.5px;\"><a href=\"").append(vPageUrl).append("\">[ LINK ]</a></td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("			</tbody>");
		sb.append("\n").append("		</table>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr> ");
		sb.append("\n").append("<tr>");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<a href=\"").append(WEB_URL).append("\" target=\"_blank\" style=\"").append(STYLE_SHORTCUT_BTN).append("\">myBEAKER 시스템 바로가기</a>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr>");
		sb.append("\n").append(this.getBottom());
		return sb.toString();
	}

	// 참조 메일
	private String getReferenceMail(HashMap<String, String> args) {
		String url = StringUtils.isNotEmpty(args.get("url")) ? args.get("url") : "";
		
		StringBuilder sb = new StringBuilder();
		sb.append("\n").append(this.getTop());
		sb.append("\n").append("<tr style=\"").append(getHeaderStyle(140)).append("\">");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<img src=\"").append(WEB_URL).append("/img/bg-mailLogo.png\" usemap=\"#Map\" border=\"0\" alt=\"myBEAKER\"/>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr>  ");
		sb.append("\n").append("<tr style=\"display:block;padding:0 40px;box-sizing:border-box;\">");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<table style=\"width: 100%; border-collapse: collapse; border-spacing: 0;table-layout: fixed;border-top: 1px solid #92b7fc;\">");
		sb.append("\n").append("			<colgroup>");
		sb.append("\n").append("				<col style=\"width:19rem\">");
		sb.append("\n").append("				<col style=\"width:auto\">");
		sb.append("\n").append("			</colgroup>");
		sb.append("\n").append("			<tbody style=\"display: table-row-group;vertical-align: middle; border-color: inherit;\">");
		sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
		sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">URL");
		sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left;	letter-spacing: -0.5px;\"><a href=\"").append(WEB_URL).append(url).append("\">[ LINK ]</a></td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("			</tbody>");
		sb.append("\n").append("		</table>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr> ");
		sb.append("\n").append("<tr>");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<a href=\"").append(WEB_URL).append("\" target=\"_blank\" style=\"").append(STYLE_SHORTCUT_BTN).append("\">myBEAKER 시스템 바로가기</a>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr>");
		sb.append("\n").append(this.getBottom());
		return sb.toString();
	}

	private String getAnswerFuncTestMail(HashMap<String, String> args) {
		StringBuilder sb = new StringBuilder();
		String vNoteTypeNm = args.get("vNoteTypeNm");
		String vMybkRegYn = args.get("vMybkRegYn");
		String vNoteType = args.get("vNoteType");
		String vSmNoteType = vNoteType.toLowerCase();
		String link = "";
		if("Y".equals(vMybkRegYn)) {
			link = new StringBuilder()
					.append(WEB_URL).append(vNoteTypeNm).append("/all-lab-note-prd-process")
					.append("?vLabNoteCd=").append(args.get("vLabNoteCd"))
					.append("&vTabId=funcComplete")
					.append("&vSubTabId=testReport")
					.append("&nVersion=").append(args.get("nVersion"))
					.append("&nSeqno=").append(args.get("nSeqno"))
					.toString();
		}else {
			link = new StringBuilder()
					.append(TIUM_WEB_URL).append("elab/").append(vSmNoteType).append("/note/").append(vSmNoteType).append("_note_experiment_view.do")
					.append("?i_sLabNoteCd=").append(args.get("vLabNoteCd"))
					.append("&i_sTabCd=tab08")
					.append("&i_sFuncListTab=FUNC")
					.append("&i_sRecordId=").append(args.get("vRecordid"))
					.toString();
		}

		String content = "항상 수고가 많으십니다. <br> 요청하신 기능성 검사의 첨부파일을 보냈습니다. <br> 확인해 주세요.";
		sb.append("\n").append(this.getTop());
		sb.append("\n").append("<tr style=\"").append(getHeaderStyle(140)).append("\">");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<img src=\"").append(WEB_URL).append("/img/bg-mailLogo.png\" usemap=\"#Map\" border=\"0\" alt=\"myBEAKER\"/>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr>  ");
		sb.append("\n").append("<tr style=\"display:block;padding:0 40px;box-sizing:border-box;\">");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<table style=\"width: 100%; border-collapse: collapse; border-spacing: 0;table-layout: fixed;border-top: 1px solid #92b7fc;\">");
		sb.append("\n").append("			<colgroup>");
		sb.append("\n").append("				<col style=\"width:19rem\">");
		sb.append("\n").append("				<col style=\"width:auto\">");
		sb.append("\n").append("			</colgroup>");
		sb.append("\n").append("			<tbody style=\"display: table-row-group;vertical-align: middle; border-color: inherit;\">");
		sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
		sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">제목</th>");
		sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left; letter-spacing: -0.5px;\">").append(args.get("vTitle")).append("</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
		sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">내용</th>");
		sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left; letter-spacing: -0.5px;\">").append(content).append("</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
		sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">바로가기</th>");
		sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left; letter-spacing: -0.5px;\"><a href=\"").append(link).append("\">[ LINK ]</a></td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("			</tbody>");
		sb.append("\n").append("		</table>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr> ");
		sb.append("\n").append("<tr>");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<a href=\"").append(WEB_URL).append("\" target=\"_blank\" style=\"").append(STYLE_SHORTCUT_BTN).append("\">myBEAKER 시스템 바로가기</a>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr>");
		sb.append("\n").append(this.getBottom());

		return sb.toString();
	}

	private String getRequestFuncTestMail(HashMap<String, Object> obj) {
		StringBuilder sb = new StringBuilder();
		LabNoteProcessFuncReportDataDTO fvo = (LabNoteProcessFuncReportDataDTO) obj.get("fvo");
		String vNoteType = fvo.getVNoteType();
		String vSmNoteType = vNoteType.toLowerCase();
		String url = TIUM_WEB_URL  + "elab/common/" + vSmNoteType +"_note_func_request_list.do";		//실험노트 내 COA 요청함
		StringBuffer param = new StringBuffer();
		param.append("?i_sMailAccess=Y");
		param.append("&i_sLabNoteCd=" + fvo.getVLabNoteCd());
		param.append("&i_iVersion=" + fvo.getNVersion());
		param.append("&i_iSeqno=" + fvo.getNSeqno());
		param.append("&i_sNoteType=" + vNoteType);

		String link = url + param.toString();

		String subThStyle = "color: #777777; padding-bottom: 3px; padding-left: 3px; padding-right: 3px; font-size: 10pt; padding-top: 3px; font-family: 맑은 고딕;";
		String subTdStyle = subThStyle + " color: blue;";
		String subBoxStyle = "line-height: 1.4; margin-top: 0px; margin-bottom: 0px; font-family: 맑은 고딕;";

		sb.append("\n").append(this.getTop());
		sb.append("\n").append("<tr style=\"").append(getHeaderStyle(140)).append("\">");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<img src=\"").append(WEB_URL).append("/img/bg-mailLogo.png\" usemap=\"#Map\" border=\"0\" alt=\"myBEAKER\"/>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr>  ");
		sb.append("\n").append("<tr style=\"display:block;padding:0 40px;box-sizing:border-box;\">");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<table style=\"width: 100%; border-collapse: collapse; border-spacing: 0;table-layout: fixed;border-top: 1px solid #92b7fc;\">");
		sb.append("\n").append("			<colgroup>");
		sb.append("\n").append("				<col style=\"width:19rem\">");
		sb.append("\n").append("				<col style=\"width:auto\">");
		sb.append("\n").append("			</colgroup>");
		sb.append("\n").append("			<tbody style=\"display: table-row-group;vertical-align: middle; border-color: inherit;\">");
		sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
		sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">제목</th>");
		sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left; letter-spacing: -0.5px;\">").append(fvo.getVTitle()).append("</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
		sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">요청자</th>");
		sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left; letter-spacing: -0.5px;\">").append(fvo.getVUserInfo()).append("</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
		sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">요청내용</th>");
		sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left; letter-spacing: -0.5px;\">").append(fvo.getVReqContent()).append("</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
		sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left; letter-spacing: -0.5px;\" colspan=\"2\">");
		//[s] 기능성 정보 table
		sb.append("\n").append("		<div style=\"\">");
		sb.append("\n").append("			<table border=1 cellSpacing=0 borderColorLight=#d8d8d8 borderColorDark=white cellPadding=0 width=500 COLOR=#777777;>");
		sb.append("\n").append("			<colgroup>");
		sb.append("\n").append("				<col width='15%'>");
		sb.append("\n").append("				<col width='35%'>");
		sb.append("\n").append("				<col width='15%'>");
		sb.append("\n").append("				<col width='35%'>");
		sb.append("\n").append("			</colgroup>");
		sb.append("\n").append("			<tbody>");
		sb.append("\n").append("			<tr height=24>");
		sb.append("\n").append("				<th style=\""+subThStyle+"\">관리번호</th>");
		sb.append("\n").append("				<td style=\""+subTdStyle+"\" colspan='3'>");
		sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getVManagementNum()).append("</span>");
		sb.append("\n").append("				</td>");
		sb.append("\n").append("			</tr>");

		if(fvo.getVRefTypeCd().equals("LNC05_04")) {
			sb.append("\n").append("			<tr height=24>");
			sb.append("\n").append("				<th style=\""+subThStyle+"\">심사번호</th>");
			sb.append("\n").append("				<td style=\""+subTdStyle+"\" colspan='3'>");
			sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getVEvaluateNum()).append("</span>");
			sb.append("\n").append("				</td>");
			sb.append("\n").append("			</tr>");
			sb.append("\n").append("			<tr height=24>");
			sb.append("\n").append("				<th style=\""+subThStyle+"\">내용물코드</th>");
			sb.append("\n").append("				<td style=\""+subTdStyle+"\">");
			sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getVContCd()).append("</span>");
			sb.append("\n").append("				</td>");
			sb.append("\n").append("				<th style=\""+subThStyle+"\">변경 내용물코드</th>");
			sb.append("\n").append("				<td style=\""+subTdStyle+"\">");
			sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getVChangeCd()).append("</span>");
			sb.append("\n").append("				</td>");
			sb.append("\n").append("			</tr>");
			sb.append("\n").append("			<tr height=24>");
			sb.append("\n").append("				<th style=\""+subThStyle+"\">제품명</th>");
			sb.append("\n").append("				<td style=\""+subTdStyle+"\">");
			sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getVContNm()).append("</span>");
			sb.append("\n").append("				</td>");
			sb.append("\n").append("				<th style=\""+subThStyle+"\">변경 제품명</th>");
			sb.append("\n").append("				<td style=\""+subTdStyle+"\">");
			sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getVChangeProduct()).append("</span>");
			sb.append("\n").append("				</td>");
			sb.append("\n").append("			</tr>");
		}else {
			if(vNoteType.equals("SC")){
				sb.append("\n").append("			<tr height=24>");
				sb.append("\n").append("				<th style=\""+subThStyle+"\">내용물코드</th>");
				sb.append("\n").append("				<td style=\""+subTdStyle+"\">");
				sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getVContCd()).append("</span>");
				sb.append("\n").append("				</td>");
				sb.append("\n").append("				<th style=\""+subThStyle+"\">QMS 차수/일자/제조번호</th>");
				sb.append("\n").append("				<td style=\""+subTdStyle+"\">");
				sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getVQmsLotInfo()).append("</span>");
				sb.append("\n").append("				</td>");
				sb.append("\n").append("			</tr>");
			}
			else{
				sb.append("\n").append("			<tr height=24>");
				sb.append("\n").append("				<th style=\""+subThStyle+"\">내용물코드</th>");
				sb.append("\n").append("				<td style=\""+subTdStyle+"\" colspan='3'>");
				sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getVContCd()).append("</span>");
				sb.append("\n").append("				</td>");
				sb.append("\n").append("			</tr>");
			}

			sb.append("\n").append("			<tr height=24>");
			sb.append("\n").append("				<th style=\""+subThStyle+"\">제품명</th>");
			sb.append("\n").append("				<td style=\""+subTdStyle+"\" colspan='3'>");
			sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getVContNm()).append("</span>");
			sb.append("\n").append("				</td>");
			sb.append("\n").append("			</tr>");
			sb.append("\n").append("			<tr height=24>");
			sb.append("\n").append("				<th style=\""+subThStyle+"\">확정 제품명</th>");
			sb.append("\n").append("				<td style=\""+subTdStyle+"\" colspan='3'>");
			sb.append("\n").append("					<span style="+subBoxStyle+"\">").append(fvo.getVRealDecideContNm()).append("</span>");
			sb.append("\n").append("				</td>");
			sb.append("\n").append("			</tr>");
		}

		sb.append("\n").append("			<tr height=24>");
		sb.append("\n").append("				<th style=\""+subThStyle+"\">제품연구원</th>");
		sb.append("\n").append("				<td style=\""+subTdStyle+"\">");
		sb.append("\n").append("					 <span style=\""+subBoxStyle+"\">").append(fvo.getVUserInfo()).append("</span>");
		sb.append("\n").append("				</td>");
		sb.append("\n").append("				<th style=\""+subThStyle+"\">담당PM</th>");
		sb.append("\n").append("				<td style=\""+subTdStyle+"\">");
		sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getVBrdUserInfo()).append("</span>");
		sb.append("\n").append("				</td>");
		sb.append("\n").append("			</tr>");
		sb.append("\n").append("			<tr height=24>");
		sb.append("\n").append("				<th style=\""+subThStyle+"\">기능성 유형</th>");
		sb.append("\n").append("				<td style=\""+subTdStyle+"\" colspan='3'>");
		sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getVFuncTypeInfo()).append("</span>");
		sb.append("\n").append("				</td>");
		sb.append("\n").append("			</tr>");
		sb.append("\n").append("			<tr height=24>");
		sb.append("\n").append("				<th style=\""+subThStyle+"\">주성분</th>");
		sb.append("\n").append("				<td style=\""+subTdStyle+"\" colspan='3'>");
		sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(removeHTMLChangeBr(fvo.getVFuncMateInfo())).append("</span>");
		sb.append("\n").append("				</td>");
		sb.append("\n").append("			</tr>");
		sb.append("\n").append("			<tr height=24>");
		sb.append("\n").append("				<th style=\""+subThStyle+"\">파일럿 시기</th>");
		sb.append("\n").append("				<td style=\""+subTdStyle+"\" colspan='3'>");
		sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getVPilotDt()).append("</span>");
		sb.append("\n").append("				</td>");
		sb.append("\n").append("			</tr>");
		sb.append("\n").append("			<tr height=24>");
		sb.append("\n").append("				<th style=\""+subThStyle+"\">양산일</th>");
		sb.append("\n").append("				<td style=\""+subTdStyle+"\" colspan='3'>");
		sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getVMassProdDt()).append("</span>");
		sb.append("\n").append("				</td>");
		sb.append("\n").append("			</tr>");
		sb.append("\n").append("			<tr height=24>");
		sb.append("\n").append("				<th style=\""+subThStyle+"\">출시지역 (출시예정일)</th>");
		sb.append("\n").append("				<td style=\""+subTdStyle+"\" colspan='3'>");
		sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getVReleaseDt()).append("</span>");
		sb.append("\n").append("				</td>");
		sb.append("\n").append("			</tr>");

		if(StringUtils.isNotEmpty(fvo.getVShape())) {
			sb.append("\n").append("			<tr height=24>");
			sb.append("\n").append("				<th style=\""+subThStyle+"\">제형</th>");
			sb.append("\n").append("				<td style=\""+subTdStyle+"\" colspan='3'>");
			sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getVShape()).append("</span>");
			sb.append("\n").append("				</td>");
			sb.append("\n").append("			</tr>");
		}

		if(vNoteType.equals("SC")){
			sb.append("\n").append("			<tr height=24>");
			sb.append("\n").append("				<th style=\""+subThStyle+"\">2액제 여부</th>");
			sb.append("\n").append("				<td style=\""+subTdStyle+"\" colspan='3'>");
			sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getVTwoLiqYn()).append("</span>");
			if(fvo.getVTwoLiqYn().equals("Y")){
				sb.append("\n").append("<span style=\""+subBoxStyle+" margin-left:3px;\">").append(",").append(fvo.getVTwoLiqTxt()).append("</span>");
			}
			sb.append("\n").append("				</td>");
			sb.append("\n").append("			</tr>");
		}

		if(fvo.getVRefTypeCd().equals("LNC05_02") || fvo.getVRefTypeCd().equals("LNC05_05")){

			sb.append("\n").append("			<tr height=24>");
			sb.append("\n").append("				<th style=\""+subThStyle+"\">근거품목</th>");
			sb.append("\n").append("				<td style=\""+subTdStyle+"\" colspan='3'>");
			sb.append("\n").append("					<span style="+subBoxStyle+"\">").append(fvo.getVRefTypeInfo()).append("</span>");
			sb.append("\n").append("				</td>");
			sb.append("\n").append("			</tr>");
			sb.append("\n").append("			<tr height=24>");
			sb.append("\n").append("				<th style=\""+subThStyle+"\">홋수명</th>");
			sb.append("\n").append("				<td style=\""+subTdStyle+"\" colspan='3'>");
			sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(removeHTMLChangeBr(fvo.getVNumberNm())).append("</span>");
			sb.append("\n").append("				</td>");
			sb.append("\n").append("			</tr>");
			sb.append("\n").append("			<tr height=24>");
			sb.append("\n").append("				<th style=\""+subThStyle+"\">TiO₂ 함량</th>");
			sb.append("\n").append("				<td style=\""+subTdStyle+"\">");
			sb.append("\n").append("					 <span style=\""+subBoxStyle+"\">").append(fvo.getNTioTwoRate()).append("</span>");
			sb.append("\n").append("				</td>");
			sb.append("\n").append("				<th style=\""+subThStyle+"\">ZnO 함량</th>");
			sb.append("\n").append("				<td style=\""+subTdStyle+"\">");
			sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getNZnoRate()).append("</span>");
			sb.append("\n").append("				</td>");
			sb.append("\n").append("			</tr>");
			sb.append("\n").append("			<tr height=24>");
			sb.append("\n").append("				<th style=\""+subThStyle+"\">ｐH(기준치±1.0)</th>");
			sb.append("\n").append("				<td style=\""+subTdStyle+"\" colspan='3'>");
			sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getVPh()).append("</span>");
			sb.append("\n").append("				</td>");
			sb.append("\n").append("			</tr>");
			sb.append("\n").append("			<tr height=24>");
			sb.append("\n").append("				<th style=\""+subThStyle+"\">에탄올 4% 초과 여부</th>");
			sb.append("\n").append("				<td style=\""+subTdStyle+"\" colspan='3'>");
			sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getVFlagOverEthanolNm()).append("</span>");
			sb.append("\n").append("				</td>");
			sb.append("\n").append("			</tr>");
			sb.append("\n").append("			<tr height=24>");
			sb.append("\n").append("				<th style=\""+subThStyle+"\">제조원</th>");
			sb.append("\n").append("				<td style=\""+subTdStyle+"\" colspan='3'>");
			sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getVMaker()).append("</span>");
			sb.append("\n").append("				</td>");
			sb.append("\n").append("			</tr>");

		}else if(fvo.getVRefTypeCd().equals("LNC05_03")) {
			sb.append("\n").append("			<tr height=24>");
			sb.append("\n").append("				<th style=\""+subThStyle+"\">효능·효과</th>");
			sb.append("\n").append("				<td style=\""+subTdStyle+"\" colspan='3'>");
			sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getVEffect()).append("</span>");
			sb.append("\n").append("				</td>");
			sb.append("\n").append("			</tr>");
			sb.append("\n").append("			<tr height=24>");
			sb.append("\n").append("				<th style=\""+subThStyle+"\">용법·용량</th>");
			sb.append("\n").append("				<td style=\""+subTdStyle+"\" colspan='3'>");
			sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getVUsageCapacity()).append("</span>");
			sb.append("\n").append("				</td>");
			sb.append("\n").append("			</tr>");
			sb.append("\n").append("			<tr height=24>");
			sb.append("\n").append("				<th style=\""+subThStyle+"\">ｐH(기준치±1.0)</th>");
			sb.append("\n").append("				<td style=\""+subTdStyle+"\" colspan='3'>");
			sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getVPh()).append("</span>");
			sb.append("\n").append("				</td>");
			sb.append("\n").append("			</tr>");
			sb.append("\n").append("			<tr height=24>");
			sb.append("\n").append("				<th style="+subThStyle+">제조 사업장<br>(대전/오산/기타)</th>");
			sb.append("\n").append("				<td style="+subTdStyle+" colspan='3'>");
			sb.append("\n").append("					<span style="+subBoxStyle+">").append(fvo.getVMakePlace()).append("</span>");
			sb.append("\n").append("				</td>");
			sb.append("\n").append("			</tr>");
		}else if(fvo.getVRefTypeCd().equals("LNC05_04")) {
			sb.append("\n").append("			<tr height=24>");
			sb.append("\n").append("				<th style=\""+subThStyle+"\">변경사항</th>");
			sb.append("\n").append("				<td style=\""+subTdStyle+"\" colspan='3'>");
			sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getVChangeNote()).append("</span>");
			sb.append("\n").append("				</td>");
			sb.append("\n").append("			</tr>");
			sb.append("\n").append("			<tr height=24>");
			sb.append("\n").append("				<th style=\""+subThStyle+"\">ｐH(기준치±1.0)</th>");
			sb.append("\n").append("				<td style=\""+subTdStyle+"\" colspan='3'>");
			sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getVPh()).append("</span>");
			sb.append("\n").append("				</td>");
			sb.append("\n").append("			</tr>");
			sb.append("\n").append("			<tr height=24>");
			sb.append("\n").append("				<th style=\""+subThStyle+"\">제조 사업장<br>(대전/오산/기타)</th>");
			sb.append("\n").append("				<td style=\""+subTdStyle+"\" colspan='3'>");
			sb.append("\n").append("					<span style=\""+subBoxStyle+"\">").append(fvo.getVMakePlace()).append("</span>");
			sb.append("\n").append("				</td>");
			sb.append("\n").append("			</tr>");
		}

		sb.append("\n").append("		</tbody>");
		sb.append("\n").append("		</table>");
		sb.append("\n").append("	</div>");
		//[e] 기능성 정보 table
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
		sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">바로가기</th>");
		sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left; letter-spacing: -0.5px;\"><a href=\"").append(link).append("\">[ LINK ]</a></td>");
		sb.append("\n").append("				</tr>");
		//[s] 첨부파일 다운로드 받기
		String [] filePath =  (String[]) obj.get("filePath");
		String [] fileName =  (String[]) obj.get("fileName");
		if(filePath != null) {
			sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
			sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">첨부파일</th>");
			sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left; letter-spacing: -0.5px;\">");
			for(int i = 0; i < filePath.length; i++) {
				sb.append("\n").append("						<a href=\"").append(filePath[i]).append("\">[ ").append(fileName[i]).append(" ]</a>");
			}
			sb.append("\n").append("					</td>");
			sb.append("\n").append("				</tr>");
		}
		//[e] 첨부파일 다운로드 받기
		sb.append("\n").append("			</tbody>");
		sb.append("\n").append("		</table>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr> ");
		sb.append("\n").append("<tr>");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<a href=\"").append(WEB_URL).append("\" target=\"_blank\" style=\"").append(STYLE_SHORTCUT_BTN).append("\">myBEAKER 시스템 바로가기</a>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr>");
		sb.append("\n").append(this.getBottom());

		return sb.toString();
	}

	private String getMarketerShareMail(HashMap<String, String> args) {
		StringBuilder sb = new StringBuilder();
		sb.append("\n").append(this.getTop());
		sb.append("\n").append("<tr style=\"").append(getHeaderStyle(381)).append("\">");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<img src=\"").append(WEB_URL).append("/img/bg-mailLogo.png\" usemap=\"#Map\" border=\"0\" alt=\"myBEAKER\"/>");
		sb.append("\n").append("		<p style=\"margin:50px 0 0 0;font-size:20px;font-weight:600;letter-spacing: -1px; line-height: normal;\">").append("[").append(args.get("vContCdOrigin")).append(", ").append(args.get("vContNm")).append("] 내용물 개요 항목 입력 요청</p>");
		sb.append("\n").append("		<p style=\"margin:30px 0 0 0;font-size:16px;letter-spacing: -1px; line-height: normal;\">")
											.append("<span style=\"font-weight:600;letter-spacing: -1px; line-height: normal;\">").append(args.get("vUserNm")).append("</span>님, ")
											.append("<span style=\"font-weight:600;letter-spacing: -1px; line-height: normal;\">").append(args.get("vFromUsernm")).append("님(").append(args.get("vFromTeamNm")).append(")").append("</span>이 ")
											.append("<span style=\"font-weight:600;letter-spacing: -1px; line-height: normal;\">").append(args.get("vContCd")).append(" ").append(CommonUtil.getPostWord(args.get("vContNm"), "을", "를")).append("</span> 공유하였습니다.</p><br/><br/>");
		sb.append("\n").append("		<p style=\"margin:20px 0 0 0;font-size:16px;letter-spacing: -1px; line-height: normal;\">해당 링크로 들어가서 확인 하시고 필요한 부분은 입력 혹은 수정해주시길 바랍니다.</p>");
		if (args.get("vOpinion") != null && StringUtils.isNotEmpty(String.valueOf(args.get("vOpinion")))) {
			sb.append("\n").append("<br/><br/>");
			sb.append("\n").append("<p style=\"margin:20px 0 0 0;font-size:16px;letter-spacing: -1px; line-height: normal;\">연구원 의견 : ").append(args.get("vOpinion")).append("</p>");
		}
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr>  ");
		sb.append("\n").append("<tr>");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<a href=\"").append(WEB_URL).append(args.get("vPageUrl")).append("\" target=\"_blank\" style=\"").append(STYLE_SHORTCUT_BTN).append("\">myBEAKER 시스템 바로가기</a>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr>");
		sb.append("\n").append(this.getBottom());
		return sb.toString();
	}

	private String getScChargerCompleteMail(HashMap<String, String> args) {
		StringBuilder sb = new StringBuilder();
		sb.append("\n").append(this.getTop());
		sb.append("\n").append("<tr style=\"").append(getHeaderStyle(381)).append("\">");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<img src=\"").append(WEB_URL).append("/img/bg-mailLogo.png\" usemap=\"#Map\" border=\"0\" alt=\"myBEAKER\"/>");
		sb.append("\n").append("		<p style=\"margin:50px 0 0 0;font-size:20px;font-weight:600;letter-spacing: -1px; line-height: normal;\">").append("[").append(args.get("vResearcherType")).append(" 담당자 지정] ")
						.append(args.get("vBrdNm")).append(" ").append(args.get("vContNm")).append("</p>");
		sb.append("\n").append("		<p style=\"margin:30px 0 0 0;font-size:16px;letter-spacing: -1px; line-height: normal;\">")
											.append("<span style=\"font-weight:600;letter-spacing: -1px; line-height: normal;\">").append(args.get("vUsernm")).append("</span>님, ")
											.append("<span style=\"font-weight:600;letter-spacing: -1px; line-height: normal;\">").append(args.get("vFromTeamNm")).append(" ").append(args.get("vFromUsernm")).append("</span>님이 ")
											.append("<span style=\"font-weight:600;letter-spacing: -1px; line-height: normal;\">").append(args.get("vContNm")).append("</span>의 ").append(args.get("vResearcherType")).append(" 담당자로 지정되셨습니다.</p><br/><br/>");
		sb.append("\n").append("		<p style=\"margin:20px 0 0 0;font-size:16px;letter-spacing: -1px; line-height: normal;\">해당 링크로 들어가셔서 실험과제를 확인해 주시기 바랍니다.</p>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr>  ");
		sb.append("\n").append("<tr>");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<a href=\"").append(WEB_URL).append(args.get("vPageUrl")).append("\" target=\"_blank\" style=\"").append(STYLE_SHORTCUT_BTN).append("\">myBEAKER 시스템 바로가기</a>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr>");
		sb.append("\n").append(this.getBottom());
		return sb.toString();
	}

	private String getTrMrq011PrsvAlarmMail(HashMap<String, String> args) {
		StringBuilder sb = new StringBuilder();
		String url = TIUM_WEB_URL + "zm/bb/tr/zm_bb_tr_product_view.do?i_sTestReqCd=MRQ011"+"&i_sProductCd=" + args.get("vProductCd") +"&i_iVersion=" + args.get("nVersion");

		sb.append("\n").append(this.getTop());
		sb.append("\n").append("<tr style=\"").append(getHeaderStyle(140)).append("\">");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<img src=\"").append(WEB_URL).append("/img/bg-mailLogo.png\" usemap=\"#Map\" border=\"0\" alt=\"myBEAKER\"/>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr>  ");
		sb.append("\n").append("<tr style=\"display:block;padding:0 40px;box-sizing:border-box;\">");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<table style=\"width: 100%; border-collapse: collapse; border-spacing: 0;table-layout: fixed;border-top: 1px solid #92b7fc;\">");
		sb.append("\n").append("			<colgroup>");
		sb.append("\n").append("				<col style=\"width:15rem\">");
		sb.append("\n").append("				<col style=\"width:35rem\">");
		sb.append("\n").append("				<col style=\"width:15rem\">");
		sb.append("\n").append("				<col style=\"width:35rem\">");
		sb.append("\n").append("			</colgroup>");
		sb.append("\n").append("			<tbody style=\"display: table-row-group;vertical-align: middle; border-color: inherit;\">");
		sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
		sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">내용물</th>");
		sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left; letter-spacing: -0.5px;\" colspan=\"3\">");
		sb.append("\n").append("						[").append(args.get("vContCd")).append("] ").append(args.get("vContNm"));
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
		sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">Ver.</th>");
		sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left; letter-spacing: -0.5px;\">").append("Ver.").append(args.get("nVersion")).append("</td>");
		sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">LOT</th>");
		sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left; letter-spacing: -0.5px;\">").append(args.get("vLotNm")).append("</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
		sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">내용</th>");
		sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left; letter-spacing: -0.5px;\" colspan=\"3\">").append(args.get("vMailContent")).append("</td>");
		sb.append("\n").append("				</tr>");

		if("Y".equals(args.get("vFlagModifyComment2"))) {
			sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
			sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">처방 메시지</th>");
			sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left; letter-spacing: -0.5px;\" colspan=\"3\">").append(args.get("vTrComment2")).append("</td>");
			sb.append("\n").append("				</tr>");
		}
		sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
		sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">바로가기</th>");
		sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left; letter-spacing: -0.5px;\" colspan=\"3\"><a href=\"").append(url).append("\">[ LINK ]</a></td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("			</tbody>");
		sb.append("\n").append("		</table>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr> ");
		sb.append("\n").append("<tr>");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<a href=\"").append(WEB_URL).append("\" target=\"_blank\" style=\"").append(STYLE_SHORTCUT_BTN).append("\">myBEAKER 시스템 바로가기</a>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr>");
		sb.append("\n").append(this.getBottom());
		return sb.toString();
	}

	public static String removeHTMLChangeBr(String i_sHTML) {
		String	result	= "";

		if ((null == i_sHTML) || "".equals(i_sHTML)) {
			return "";
		}

		result	= i_sHTML.replaceAll("<(/)?([a-zA-Z]*)(\\s[a-zA-Z]*[^>]*)?(\\s)*(/)?>", "").replaceAll("\n", "<br/>");

		result = result.replaceAll("\r", "");

		return result;
	}

	private String getSaReportSecretMail(HashMap<String, Object> obj) {

		StringBuilder sb = new StringBuilder();

		@SuppressWarnings("unchecked")
		List<WokReportSecretResDTO> lstSecret = (List<WokReportSecretResDTO>) obj.get("lstSecret");
		String url = (String) obj.get("url");

		sb.append("\n").append(this.getTop());
		sb.append("\n").append("<tr style=\"").append(getHeaderStyle(140)).append("\">");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<img src=\"").append(WEB_URL).append("/img/bg-mailLogo.png\" usemap=\"#Map\" border=\"0\" alt=\"myBEAKER\"/>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr>  ");
		sb.append("\n").append("<tr style=\"display:block;padding:0 40px;box-sizing:border-box;\">");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<table style=\"width: 100%; border-collapse: collapse; border-spacing: 0;table-layout: fixed;border-top: 1px solid #92b7fc;\">");
		sb.append("\n").append("			<colgroup>");
		sb.append("\n").append("				<col style=\"width:15rem\">");
		sb.append("\n").append("				<col style=\"width:auto\">");
		sb.append("\n").append("			</colgroup>");
		sb.append("\n").append("			<tbody style=\"display: table-row-group;vertical-align: middle; border-color: inherit;\">");
		sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
		sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">영업비밀문서<br/>정보</th>");
		sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left; letter-spacing: -0.5px;\">");
		sb.append("\n").append("						<table style='width: 99%; border:1px solid #d8d8d8; color:#777777;'>");
		sb.append("\n").append("							<colgroup>");
		sb.append("\n").append("								<col width='25%'>");
		sb.append("\n").append("								<col width='auto'>");
		sb.append("\n").append("								<col width='15%'>");
		sb.append("\n").append("								<col width='25%'>");
		sb.append("\n").append("							</colgroup>");
		sb.append("\n").append("							<thead>");
		sb.append("\n").append("								<tr>");
		sb.append("\n").append("									<th>자료명</th>");
		sb.append("\n").append("									<th>자료내용</th>");
		sb.append("\n").append("									<th>영업비밀</th>");
		sb.append("\n").append("									<th>관련자료보관소</th>");
		sb.append("\n").append("								</tr>");
		sb.append("\n").append("							</thead>");
		sb.append("\n").append("							<tbody>");
		for(WokReportSecretResDTO vo : lstSecret) {
			sb.append("\n").append("							<tr class='addSecretTr'>");
			sb.append("\n").append("								<td style='border:1px solid #d8d8d8;height:16px;padding:3px 5px 3px 5px;background:#ffffff;'>").append(vo.getVSecretNm()).append("</td>");
			sb.append("\n").append("								<td style='border:1px solid #d8d8d8;height:16px;padding:3px 5px 3px 5px;background:#ffffff;'>").append(vo.getVSecret()).append("</td>");
			sb.append("\n").append("								<td style='border:1px solid #d8d8d8;height:16px;padding:3px 5px 3px 5px;background:#ffffff;'>").append(vo.getNSecretLevel()).append("</td>");
			sb.append("\n").append("								<td style='border:1px solid #d8d8d8;height:16px;padding:3px 5px 3px 5px;background:#ffffff;'>").append(vo.getVSecretRoom()).append("</td>");
			sb.append("\n").append("							</tr>");
		}
		sb.append("\n").append("							</tbody>");
		sb.append("\n").append("						</table>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
		sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">바로가기</th>");
		sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left; letter-spacing: -0.5px;\"><a href=\"").append(url).append("\">[ LINK ]</a></td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("			</tbody>");
		sb.append("\n").append("		</table>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr> ");
		sb.append("\n").append("<tr>");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<a href=\"").append(WEB_URL).append("\" target=\"_blank\" style=\"").append(STYLE_SHORTCUT_BTN).append("\">myBEAKER 시스템 바로가기</a>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr>");
		sb.append("\n").append(this.getBottom());
		return sb.toString();
	}

	private String getOnlyDirectLinkMail(HashMap<String, String> args) {

		StringBuilder sb = new StringBuilder();
		String url = (String) args.get("url");

		sb.append("\n").append(this.getTop());
		sb.append("\n").append("<tr style=\"").append(getHeaderStyle(140)).append("\">");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<img src=\"").append(WEB_URL).append("/img/bg-mailLogo.png\" usemap=\"#Map\" border=\"0\" alt=\"myBEAKER\"/>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr>  ");
		sb.append("\n").append("<tr style=\"display:block;padding:0 40px;box-sizing:border-box;\">");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<table style=\"width: 100%; border-collapse: collapse; border-spacing: 0;table-layout: fixed;border-top: 1px solid #92b7fc;\">");
		sb.append("\n").append("			<colgroup>");
		sb.append("\n").append("				<col style=\"width:15rem\">");
		sb.append("\n").append("				<col style=\"width:auto\">");
		sb.append("\n").append("			</colgroup>");
		sb.append("\n").append("			<tbody style=\"display: table-row-group;vertical-align: middle; border-color: inherit;\">");
		sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");
		sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">바로가기</th>");
		sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left; letter-spacing: -0.5px;\"><a href=\"").append(url).append("\">[ LINK ]</a></td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("			</tbody>");
		sb.append("\n").append("		</table>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr> ");
		sb.append("\n").append("<tr>");
		sb.append("\n").append("	<td>");
		sb.append("\n").append("		<a href=\"").append(WEB_URL).append("\" target=\"_blank\" style=\"").append(STYLE_SHORTCUT_BTN).append("\">myBEAKER 시스템 바로가기</a>");
		sb.append("\n").append("	</td>");
		sb.append("\n").append("</tr>");
		sb.append("\n").append(this.getBottom());
		return sb.toString();
	}

	public String getBatchMailContent(List<BatchStatusProcessVO> noteList, String mailType, String pageUrl) {
		StringBuilder sb = new StringBuilder();

		if (!ObjectUtils.isEmpty(noteList)) {
			String contInfo = noteList.get(0).getVContCd() + (noteList.size() > 1 ? " 외 " + (noteList.size() - 1) + "건" : "");
			String title = new StringBuilder()
								.append(contInfo)
								.append("STOCK".equals(mailType) ? " 내용물 개발이 완료되었습니다. (입고완료)" : " 내용물 출시가 완료되었습니다.")
								.toString();

			sb.append("\n").append(this.getTop());
			sb.append("\n").append("<tr style=\"").append(getHeaderStyle(200)).append("\">");
			sb.append("\n").append("	<td>");
			sb.append("\n").append("		<img src=\"").append(WEB_URL).append("/img/bg-mailLogo.png\" usemap=\"#Map\" border=\"0\" alt=\"myBEAKER\"/>");
			sb.append("\n").append("		<p style=\"margin:50px 0 0 0;font-size:20px;font-weight:600;letter-spacing: -1px; line-height: normal;\">").append(title).append("</p>");
			sb.append("\n").append("	</td>");
			sb.append("\n").append("</tr>  ");
			sb.append("\n").append("<tr style=\"display:block;padding:40px;box-sizing:border-box;\">");
			sb.append("\n").append("	<td>");
			sb.append("\n").append("		<table style=\"width: 100%; border-collapse: collapse; border-spacing: 0;table-layout: fixed;border-top: 1px solid #92b7fc;\">");
			sb.append("\n").append("			<colgroup>");
			sb.append("\n").append("				<col style=\"width:85%\">");
			sb.append("\n").append("				<col style=\"width:15%\">");
			sb.append("\n").append("			</colgroup>");
			sb.append("\n").append("			<thead>");
			sb.append("\n").append("				<tr style=\"height: 24px;\">");
			sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">내용물 정보</th>");
			sb.append("\n").append("					<th style=\"padding: 0 2rem; font-size: 14px; font-weight: 600; color: #586376; background: #f6f8fd;text-align: left;\">LINK</th>");
			sb.append("\n").append("				</tr>");
			sb.append("\n").append("			</thead>");
			sb.append("\n").append("			<tbody style=\"display: table-row-group;vertical-align: middle; border-color: inherit;\">");

			for (BatchStatusProcessVO note : noteList) {
				sb.append("\n").append("				<tr style=\"display: table-row; vertical-align: inherit;height:40px;border-color: inherit;border-top:1px solid #f1f3f8;\">");

				sb.append("\n").append("					<td style=\"padding: 0.8rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left; letter-spacing: -0.5px;\">")
																.append(note.getVContCd()).append(" ").append(note.getVContNm());
				sb.append("\n").append("					</td>");
				sb.append("\n").append("					<td style=\"padding: 0.2rem 1.5rem;font-size: 14px;color: #545454;box-sizing: border-box;line-height:normal;text-align: left; letter-spacing: -0.5px;\">")
																.append("<a href=\"").append(WEB_URL).append(pageUrl).append(note.getVLabNoteCd()).append("\">[ LINK ]</a>");
				sb.append("\n").append("					</td>");
				sb.append("\n").append("				</tr>");
			}
			sb.append("\n").append("			</tbody>");
			sb.append("\n").append("		</table>");
			sb.append("\n").append("	</td>");
			sb.append("\n").append("</tr> ");
			sb.append("\n").append(this.getBottom());
		}

		return sb.toString();
	}
}
