package com.mybeaker.app.common.model;

import lombok.Data;

@Data
public class ReqSSOLoginDTO {
	
	private String ssoYn;
}
