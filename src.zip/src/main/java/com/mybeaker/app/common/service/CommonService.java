package com.mybeaker.app.common.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mybeaker.app.Exception.CustomException;
import com.mybeaker.app.approval.mapper.ApprovalMapper;
import com.mybeaker.app.approval.model.ApprovalDTO;
import com.mybeaker.app.approval.model.ApprovalDetailDTO;
import com.mybeaker.app.approval.model.ApprovalPrcDTO;
import com.mybeaker.app.approval.model.DesignReferenceDTO;
import com.mybeaker.app.approval.model.NoteApprovalDTO;
import com.mybeaker.app.approval.model.ReferenceDTO;
import com.mybeaker.app.approval.model.ReqApprovalPrcDTO;
import com.mybeaker.app.approval.model.ReqReferenceDTO;
import com.mybeaker.app.approval.model.ReqResApprovalDTO;
import com.mybeaker.app.approval.model.ResApprovalPrcDTO;
import com.mybeaker.app.common.form.MailForm;
import com.mybeaker.app.common.mapper.CommonMapper;
import com.mybeaker.app.common.model.AlarmKeywordDTO;
import com.mybeaker.app.common.model.AlarmRegDTO;
import com.mybeaker.app.common.model.CodeDTO;
import com.mybeaker.app.common.model.CommUserDesSearchInfoDTO;
import com.mybeaker.app.common.model.CommUserDesSearchInfoReqDTO;
import com.mybeaker.app.common.model.CommUserSearchInfoDTO;
import com.mybeaker.app.common.model.CommUserSearchInfoReqDTO;
import com.mybeaker.app.common.model.DeptDTO;
import com.mybeaker.app.common.model.GroupUserInfoDTO;
import com.mybeaker.app.common.model.MailDTO;
import com.mybeaker.app.common.model.OrganizationDTO;
import com.mybeaker.app.common.model.ThumbnailDTO;
import com.mybeaker.app.common.model.UploadDTO;
import com.mybeaker.app.common.model.UploadTempDTO;
import com.mybeaker.app.dbbase.entity.comm.MailClobEntity;
import com.mybeaker.app.dbbase.entity.comm.MailFileEntity;
import com.mybeaker.app.dbbase.entity.comm.MailMstEntity;
import com.mybeaker.app.dbbase.entity.comm.MailSubEntity;
import com.mybeaker.app.dbbase.repo.comm.MailClobRepo;
import com.mybeaker.app.dbbase.repo.comm.MailFileRepo;
import com.mybeaker.app.dbbase.repo.comm.MailMstRepo;
import com.mybeaker.app.dbbase.repo.comm.MailSubRepo;
import com.mybeaker.app.labnote.model.LotStatusRegDTO;
import com.mybeaker.app.labnote.model.WokAppointDesignationRefDTO;
import com.mybeaker.app.model.Const;
import com.mybeaker.app.model.dto.PagingDTO;
import com.mybeaker.app.model.dto.ResCommSearchInfoDTO;
import com.mybeaker.app.model.enums.ApprovalResultCode;
import com.mybeaker.app.model.enums.CommonResultCode;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.utils.CommonUtil;
import com.mybeaker.app.utils.ConvertUtil;
import com.mybeaker.app.utils.MailUtil;
import com.mybeaker.app.utils.SessionUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class CommonService {
	private final CommonMapper commonMapper;

	private final ApprovalMapper approvalMapper;

	private final AWSService awsService;

	private final SessionUtil sessionUtil;

	private final MailMstRepo mailMstRepo;

    private final MailSubRepo mailSubRepo;

    private final MailClobRepo mailClobRepo;

    private final MailFileRepo mailFileRepo;

	@Transactional
	public String handlingOfApprovalEp(String status, String draftTitle, ReqResApprovalDTO reqResApprovalDTO) {
		ApprovalDTO apprInfo = reqResApprovalDTO.getApprInfo();
		List<ApprovalDetailDTO> apprList = reqResApprovalDTO.getApprList();

		if ((apprList == null || apprList.isEmpty()) || apprInfo == null) {
			return ""; // 결재라인 미지정 시 빈값 리턴
		}

		reqResApprovalDTO.getApprInfo().setVAprvDtlUrl(reqResApprovalDTO.getVAprvDtlUrl());
		reqResApprovalDTO.getApprInfo().setNCurRegseq(1);
		status = StringUtils.isNotEmpty(status) ? status : "APS999";
		reqResApprovalDTO.getApprInfo().setVApprStatus(status);
		reqResApprovalDTO.getApprInfo().setVDraftTitle(draftTitle);
		reqResApprovalDTO.getApprInfo().setNCurApprseq(1);

		String apprCd = "";
		ApprovalDTO saveInfo = null;

		if (StringUtils.isNotEmpty(apprInfo.getVApprCd())) {
			saveInfo = approvalMapper.selectApprovalInfo(apprInfo.getVApprCd(), "_ko");
		}

		if (saveInfo == null) {
			apprCd = this.insertApprovalEp(reqResApprovalDTO);
		} else if (saveInfo != null && (
				"APS999".equals(saveInfo.getVApprStatus())
				 || "APS040".equals(saveInfo.getVApprStatus())
				 || "APS020".equals(saveInfo.getVApprStatus())
				)) {
			if (saveInfo.getNApprStatusCnt() > 0) {
				reqResApprovalDTO.getApprInfo().setNCurRegseq(apprInfo.getNCurRegseq() + 1);

				this.updateApprovalEp(reqResApprovalDTO, "RE_APPR");
			} else {
				this.updateApprovalEp(reqResApprovalDTO, "UPDATE");
			}

			apprCd = apprInfo.getVApprCd();
		}

		return apprCd;
	}

	private String insertApprovalEp(ReqResApprovalDTO reqResApprovalDTO) {
		ApprovalDTO apprInfo = reqResApprovalDTO.getApprInfo();
		int result = approvalMapper.insertApprovalMst(apprInfo);

		if (result > 0) {
			reqResApprovalDTO.getApprInfo().setVApprSubStatus("APS030");
			approvalMapper.insertApprovalSub(reqResApprovalDTO);
		}

		return reqResApprovalDTO.getApprInfo().getVApprCd();
	}

	private void updateApprovalEp(ReqResApprovalDTO reqResApprovalDTO, String clsStatus) {
		ApprovalDTO apprInfo = reqResApprovalDTO.getApprInfo();
		int result = approvalMapper.updateApprovalMst(apprInfo);

		if (result > 0) {
			if ("UPDATE".equals(clsStatus) || "RE_APPR".equals(clsStatus)) {
				approvalMapper.deleteApprovalSub(apprInfo.getVApprCd(), apprInfo.getNCurRegseq());
			}

			reqResApprovalDTO.getApprInfo().setVApprSubStatus("APS030");
			approvalMapper.insertApprovalSub(reqResApprovalDTO);
		}
	}

	@Transactional
	public ResApprovalPrcDTO handlingOfApprovalPrcEp (ReqApprovalPrcDTO reqApprovalPrcDTO) {
		ResApprovalPrcDTO resApprovalPrcDTO = ResApprovalPrcDTO.builder().build();
		if (StringUtils.isEmpty(reqApprovalPrcDTO.getVApprCd())
				|| reqApprovalPrcDTO.getNCurRegseq() == 0
				|| reqApprovalPrcDTO.getNCurApprseq() == 0
				) {
			throw new CustomException(CommonResultCode.NO_ESSENTIAL_DATA);
		}

		ApprovalPrcDTO approvalPrcDTO = approvalMapper.selectApprovalPrcInfo(reqApprovalPrcDTO.getVApprCd());

		if (approvalPrcDTO != null) {
			// 결재 상태 체크
			if (!"APS030".equals(approvalPrcDTO.getVApprStatus())) {
				resApprovalPrcDTO.setApprovalResultCode(ApprovalResultCode.APPR_STATUS_FAIL);
				return resApprovalPrcDTO;
			}

			// 결재 순번 체크
			if (approvalPrcDTO.getNCurRegseq() != reqApprovalPrcDTO.getNCurRegseq()
					|| approvalPrcDTO.getNCurApprseq() != reqApprovalPrcDTO.getNCurApprseq()
					) {
				resApprovalPrcDTO.setApprovalResultCode(ApprovalResultCode.APPR_SEQ_FAIL);
				return resApprovalPrcDTO;
			}

			// 결재자 유무 체크(승인, 반려, 합의)
			if (!sessionUtil.getLoginId().equals(approvalPrcDTO.getVApprUserid())) {
				if ("APS010".equals(reqApprovalPrcDTO.getVApprStatus())
						|| "APS020".equals(reqApprovalPrcDTO.getVApprStatus())
						|| "APS050".equals(reqApprovalPrcDTO.getVApprStatus())
						) {
					resApprovalPrcDTO.setApprovalResultCode(ApprovalResultCode.APPR_PERSON_FAIL);
					return resApprovalPrcDTO;
				}
			}

			reqApprovalPrcDTO.setVApprMstStatus(approvalPrcDTO.getVApprStatus());
			approvalMapper.updateApprovalSubPrc(reqApprovalPrcDTO);

			if ("APS010".equals(reqApprovalPrcDTO.getVApprStatus())
					|| "APS050".equals(reqApprovalPrcDTO.getVApprStatus())
					) { // 승인, 합의
				if (approvalPrcDTO.getNNextCurApprseq() > 0) {
					reqApprovalPrcDTO.setNNextCurApprseq(approvalPrcDTO.getNNextCurApprseq());
					approvalMapper.updateApprovalMstPrc(reqApprovalPrcDTO);

					ReqApprovalPrcDTO mstPrcInfo = ConvertUtil.convert(reqApprovalPrcDTO, ReqApprovalPrcDTO.class);

					mstPrcInfo.setNCurApprseq(approvalPrcDTO.getNNextCurApprseq());
					mstPrcInfo.setVApprStatus("APS030");

					approvalMapper.updateApprovalSubStatus(mstPrcInfo);
					resApprovalPrcDTO.setSendMailYn("Y");
					resApprovalPrcDTO.setApprovalResultCode("APS010".equals(reqApprovalPrcDTO.getVApprStatus()) ? ApprovalResultCode.APPR_SUCC : ApprovalResultCode.MUTUAL_SUCC);
				} else {
					reqApprovalPrcDTO.setVApprMstStatus("APS010");
					approvalMapper.updateApprovalMstPrc(reqApprovalPrcDTO);

					resApprovalPrcDTO.setApprovalResultCode(ApprovalResultCode.ACCEPT_END);
				}
			} else if ("APS020".equals(reqApprovalPrcDTO.getVApprStatus())
					|| "APS051".equals(reqApprovalPrcDTO.getVApprStatus())
					) { // 반려, 합의반려
				reqApprovalPrcDTO.setVApprMstStatus("APS020");
				approvalMapper.updateApprovalMstPrc(reqApprovalPrcDTO);

				resApprovalPrcDTO.setApprovalResultCode(ApprovalResultCode.APPR_BACK);
			}

			resApprovalPrcDTO.setDraftTitle(approvalPrcDTO.getVDraftTitle());
		} else {
			resApprovalPrcDTO.setApprovalResultCode(ApprovalResultCode.APPR_ERROR_CODE);
		}

		return resApprovalPrcDTO;
	}

	public List<OrganizationDTO> selectOrgAllList(String keyword) {
		return commonMapper.selectOrgAllList(keyword);
	}

	public void insertReference (ReqReferenceDTO reqReferenceDTO) {
		if (StringUtils.isEmpty(reqReferenceDTO.getVRecordid())
				|| reqReferenceDTO.getReferenceList() == null
				|| reqReferenceDTO.getReferenceList().isEmpty()) {
			return;
		}

		reqReferenceDTO.setVRegUserid(sessionUtil.getLoginId());
		reqReferenceDTO.setVUpdateUserid(sessionUtil.getLoginId());

		approvalMapper.deleteReferenceAll(reqReferenceDTO);
		approvalMapper.insertReference(reqReferenceDTO);
	}

	public Map<String, List<CodeDTO>> selectCodeListMap(List<String> arrMstCode) {
		Map<String, List<CodeDTO>> codeListMap;
		List<CodeDTO> list = commonMapper.selectCodeList(arrMstCode);

		if (list != null) {
			codeListMap = list.stream().collect(Collectors.groupingBy(CodeDTO::getVMstCode));
		} else {
			codeListMap = new HashMap<>();
		}

		return codeListMap;
	}

	public List<UploadTempDTO> saveCommAttachTemp(List<MultipartFile> files) {
		List<UploadTempDTO> list = new ArrayList<>();

		try {
			UploadTempDTO tempDTO = null;
			String filenm = "";
			for (MultipartFile file : files) {
				filenm = file.getOriginalFilename();
				tempDTO = UploadTempDTO.builder()
								.vAttachnm(file.getOriginalFilename())
								.vAttachExt(filenm.indexOf(".") > -1 ? filenm.substring(filenm.lastIndexOf(".")) : "")
								.nAttachSize(file.getSize())
								.vFileBytea(file.getBytes())
								.vRegUserid(sessionUtil.getLoginId())
								.vUpdateUserid(sessionUtil.getLoginId())
								.build();

				commonMapper.insertCommAttachTemp(tempDTO);

				tempDTO.setVRegUserid("");
				tempDTO.setVUpdateUserid("");
				list.add(tempDTO);
			}
		} catch (IOException ioe) {
			log.error("Error : ", ioe);
		}

		return list;
	}

	@Transactional
	public int saveCommAttach(List<UploadTempDTO> tempList, String uploadCd, String recordid) {
		int result = 0;


		List<UploadDTO> prevFiles = this.selectCommAttachList(recordid, uploadCd);

		Map<Long, UploadDTO> map = prevFiles == null
						? new HashMap<>()
						: prevFiles.stream().collect(Collectors.toMap(UploadDTO::getNSeqno, entity -> entity));

		if (tempList != null && !tempList.isEmpty()) {
			List<UploadTempDTO> uploadList = tempList.stream().filter(dto -> uploadCd.equals(dto.getVUploadid())).collect(Collectors.toList());

			if (uploadList != null && !uploadList.isEmpty()) {
				List<UploadTempDTO> fileList = commonMapper.selectCommAttachTempList(uploadList);

				if(!ObjectUtils.isEmpty(fileList)) {
					List<UploadDTO> uploadSuccList = null;
					try {
						uploadSuccList = awsService.fileUpload(fileList, uploadCd);
					} catch(IOException ioe) {
						log.error("Error : ", ioe);
					}

					if (!ObjectUtils.isEmpty(uploadSuccList)) {
						result = commonMapper.insertCommAttach(uploadSuccList, recordid, sessionUtil.getLoginId());

						//commonMapper.insertSsmAttach(uploadSuccList, recordid, sessionUtil.getLoginId());
						commonMapper.deleteCommAttachTemp(uploadSuccList);

						uploadSuccList.forEach(item -> {
							map.remove(item.getNSeqno());
						});
					}
				}

				tempList.forEach(item -> {
					if (!"Y".equals(item.getVNewYn())) {
						map.remove(item.getNSeqno());
					}
				});
			}
		}

		map.forEach((key, item) -> {
			commonMapper.deleteCommAttach(item);
			commonMapper.deleteSsmAttach(item);
		});

		return result;
	}

	public List<UploadDTO> selectCommAttachList(String vRecordid, String vUploadid) {
		List<UploadDTO> list = commonMapper.selectCommAttachList(vRecordid, vUploadid);
		if(!ObjectUtils.isEmpty(list)) {
			list.forEach(o -> {
				o.setVS3Url(awsService.getPreSignedURL(o.getVKeyPath()));
			});
		}
		
		return list;
	}

	public UploadDTO selectCommAttachInfo(String vAttType, String vAttachid) {
		UploadDTO resultDTO = null;
		if (!"TIUM".equals(vAttType)) {
			resultDTO = commonMapper.selectCommAttachInfo(vAttachid);
		} else {
			resultDTO = commonMapper.selectTiumCommAttachInfo(vAttachid);
		}
		return resultDTO;
	}

	public List<DeptDTO> selectDeptTreeList(String vUdeptcd) {
		return commonMapper.selectDeptTreeList(vUdeptcd);
	}

	public List<ThumbnailDTO> selectThumbnailList(String vRecordid, String vFlag) {
		return commonMapper.selectThumbnailList(vRecordid, vFlag);
	}

	public int selectCommUserListCount(CommUserSearchInfoDTO commUsrSrchInfDTO) {
		return commonMapper.selectCommUserListCount(commUsrSrchInfDTO);
	}

	public ResponseVO selectCommUserList(CommUserSearchInfoDTO commUsrSrchInfDTO) {
		ResponseVO responseVO = new ResponseVO();

		commUsrSrchInfDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
		int totalCnt = this.selectCommUserListCount(commUsrSrchInfDTO);

		List<CommUserSearchInfoReqDTO> list = null;
		CommonUtil.setPaging(commUsrSrchInfDTO, totalCnt);

		if (totalCnt > 0) {
			list = commonMapper.selectCommUserList(commUsrSrchInfDTO);
		}

		PagingDTO page = ConvertUtil.convert(commUsrSrchInfDTO, PagingDTO.class);

		responseVO.setOk(ResCommSearchInfoDTO.builder()
				.page(page)
				.list(list)
				.build());
		return responseVO;
	}

	public int selectCommUserDesignationListCount(CommUserDesSearchInfoReqDTO commUserDesSearchInfoDTO) {
		return commonMapper.selectCommUserDesignationListCount(commUserDesSearchInfoDTO);
	}

	public ResponseVO selectCommUserDesignationList(CommUserDesSearchInfoReqDTO commUserDesSearchInfoDTO) {
		ResponseVO responseVO = new ResponseVO();

		commUserDesSearchInfoDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
		int totalCnt = this.selectCommUserDesignationListCount(commUserDesSearchInfoDTO);

		List<CommUserDesSearchInfoDTO> list = null;
		CommonUtil.setPaging(commUserDesSearchInfoDTO, totalCnt);

		if (totalCnt > 0) {
			list = commonMapper.selectCommUserDesignationList(commUserDesSearchInfoDTO);
		}

		PagingDTO page = ConvertUtil.convert(commUserDesSearchInfoDTO, PagingDTO.class);

		responseVO.setOk(ResCommSearchInfoDTO.builder()
				.page(page)
				.list(list)
				.build());
		return responseVO;
	}

	@Transactional
    public void insertSendMail(MailDTO mailDTO) {
        MailMstEntity mstEntity = ConvertUtil.convert(mailDTO, MailMstEntity.class);
        mstEntity.setTypecd("BKR");
        mstEntity.setStatusCd(MailDTO.MAIL_001);
        mailMstRepo.save(mstEntity);

        if(StringUtils.isNotEmpty(mstEntity.getMailcd())) {
            MailSubEntity subEntity = ConvertUtil.convert(mstEntity, MailSubEntity.class);
            if("Y".equals(mailDTO.getFlagMail())) {
                String[] arrToEmail = mailDTO.getToEmail().split(",");
                if(arrToEmail != null) {
                    int len = arrToEmail.length;
                    for(int i=0; i<len; i++) {
                        subEntity.setSeqno((i+1));
                        subEntity.setToEmail(arrToEmail[i].trim());
                        mailSubRepo.save(subEntity);
                    }
                }
            }else {
                subEntity.setToEmail(mailDTO.getToEmail());
                mailSubRepo.save(subEntity);
            }

            if(StringUtils.isNotEmpty(mailDTO.getContent())) {
                MailClobEntity clobEntity = ConvertUtil.convert(subEntity, MailClobEntity.class);
                clobEntity.setClob(mailDTO.getContent());
                mailClobRepo.save(clobEntity);
            }

            //파일이 존재하면 파일 테이블에 저장
            if("Y".equals(mailDTO.getFlagFile())) {
                String[] arrFile      = mailDTO.getFile();
                String[] arrFilePath = mailDTO.getFilePath();
                MailFileEntity fileEntity = ConvertUtil.convert(subEntity, MailFileEntity.class);
                if(arrFilePath != null) {
                    int len      = arrFilePath.length;
                    int file_len = arrFile.length;
                    for(int i=0; i<len; i++) {
                        fileEntity.setSeqno((i+1));
                        fileEntity.setFilePath(arrFilePath[i]);
                        fileEntity.setFile((file_len > i ? arrFilePath[i] : ""));
                        mailFileRepo.save(fileEntity);
                    }
                }
            }
        }
    }

	/**
	 * 결재 메일발송
	 */
	public void sendMailApproval(ApprovalDTO reqVo) {
		String apprCd = reqVo.getVApprCd();
		String resultStatus = reqVo.getVResultStatus();
		List<ApprovalDTO> apprList = null;
		if (StringUtils.isNotEmpty(apprCd) && StringUtils.isNotEmpty(resultStatus)) {
			apprList = approvalMapper.selectApprovalSendMailInfo(apprCd);

			if (!ObjectUtils.isEmpty(apprList)) {
				for (ApprovalDTO vo : apprList) {
					if (StringUtils.isNotEmpty(vo.getVEmail())) {
						String mailTitle = "";

						if (StringUtils.isEmpty(reqVo.getVTitle())) {
							StringBuilder sb = new StringBuilder();

							if (ApprovalResultCode.ACCEPT_END.getCode().equals(resultStatus)) {
								sb.append("결재완료-");
							} else if (ApprovalResultCode.APPR_BACK.getCode().equals(resultStatus)) {
								sb.append("결재반려-");
							} else {
								sb.append("결재의뢰-");
							}

							mailTitle = sb.append(vo.getVDraftTitle()).toString(); // 메일 제목
						} else {
							mailTitle = reqVo.getVTitle();
						}

						String mailContent = "";									  // 메일 내용
						String toEmail = "";							  			  // 보내는 사람

						MailForm mailForm = new MailForm();
						HashMap<String, String> params = new HashMap<>();

						params.put("resultStatus", resultStatus);

						if (ApprovalResultCode.ACCEPT_END.getCode().equals(resultStatus)
						 || ApprovalResultCode.APPR_BACK.getCode().equals(resultStatus)) {
//							toEmail = vo.getVDraftEmail();
							toEmail = vo.getVDraftUserEmail();

							params.put("user", vo.getVApprUsernm());
							params.put("date", CommonUtil.getDatePatten(vo.getVApprDtm(), "."));
							params.put("opinion", vo.getVApprOpinion());
						}
						else {
							toEmail = vo.getVEmail();

							params.put("user", vo.getVDraftUsernm());
							params.put("date", CommonUtil.getDatePatten(vo.getVDraftDtm(), "."));
							params.put("opinion", vo.getVDraftOpinion());
						}

						params.put("vPageUrl", reqVo.getVUrl());

						mailContent = mailForm.getMailContent(MailDTO.MAIL_APPROVAL, params);

						MailUtil.send(toEmail, null, mailTitle, mailContent);
					}
				}
			}
		}
	}

	/**
	 * 실험노트 결재완료 시 전체에게 메일 전송 (결재완료시)
	 *
	 * @param apprCd
	 */
	public List<ApprovalDTO> sendMailELabNoteApproval(NoteApprovalDTO reqVo) {
		List<ApprovalDTO> apprList = null;
		if (StringUtils.isNotEmpty(reqVo.getVApprCd())) {
			StringBuilder toEmailSb = new StringBuilder();

			apprList = approvalMapper.selectELabNoteApprovalSendMailList(reqVo.getVApprCd());

			if (!ObjectUtils.isEmpty(apprList)) {
				for (ApprovalDTO vo : apprList) {
					if (StringUtils.isNotEmpty(vo.getVEmail())){
						toEmailSb.append(vo.getVEmail()).append(",");
					}
				}

				if(StringUtils.isNotEmpty(toEmailSb.toString())) {
					String mailTitle = StringUtils.isNotEmpty(reqVo.getVTitle()) ? reqVo.getVTitle() :  "결재완료-" + apprList.get(0).getVApprTitle();

					HashMap<String, String> params = new HashMap<>();

					params.put("vLabNoteCd", reqVo.getVLabNoteCd());
					params.put("nVersion", String.valueOf(reqVo.getNVersion()));
					params.put("vNoteType", reqVo.getVNoteType());
					params.put("vApprClass", apprList.get(0).getVApprClass());
					params.put("vApprCd", reqVo.getVApprCd());
					params.put("vApprUsernm", apprList.stream().map(ApprovalDTO::getVApprUsernm).collect(Collectors.joining(",")));
					params.put("vApprDtm", apprList.stream().map(ApprovalDTO::getVApprDtm).collect(Collectors.joining(",")));
					params.put("vApprOpinion", apprList.stream().map(ApprovalDTO::getVApprOpinion).collect(Collectors.joining(",")));
					params.put("vPageUrl", reqVo.getVUrl());

					String mailContent = new MailForm().getMailContent(MailDTO.MAIL_GATE_APPROVAL_END, params);

					MailUtil.send(toEmailSb.toString(), null, mailTitle, mailContent);
				}

			}
		}

		return apprList;
	}

	/**
	 * 참조 메일발송
	 *
	 * @param reqVo
	 */
	public void sendMailReference(ReferenceDTO reqVo) {
		if (StringUtils.isNotEmpty(reqVo.getVRecordId())) {
			String recordId = reqVo.getVRecordId();

			List<ReferenceDTO> referenceList = approvalMapper.selectReferenceMailList(recordId);
			StringBuilder toEmailSb = new StringBuilder();

			if (!ObjectUtils.isEmpty(referenceList)) {
				for (ReferenceDTO vo : referenceList) {
					String sMail = vo.getVEmail();

					if (StringUtils.isNotEmpty(sMail)) {
						toEmailSb.append(sMail).append(",");
					}
				}

				if (StringUtils.isNotEmpty(toEmailSb.toString())) {
					String mailTitle = StringUtils.isEmpty(reqVo.getVTitle()) ? "제목없음" : reqVo.getVTitle();

					String mailContent ="";

					if("Y".equals(reqVo.getVFlagContent())) {
						mailContent = reqVo.getVContent();
					} else {
						MailForm mailForm = new MailForm();
						HashMap<String, String> params = new HashMap<>();

						params.put("url", reqVo.getVUrl());

						mailContent = mailForm.getMailContent(MailDTO.MAIL_REFERENCE, params);
					}

//					if("Y".//equals(reqVo.getString("i_sFlagFile"))) {
//						CmMail.send("", "", sToMail, "", sTitle, mailContent, reqVo.getStringArray("arrFileName"), reqVo.getStringArray("arrFilePath"));
//					} else {
//						CmMail.send("", "", sToMail, "", sTitle, mailContent);
//					}

					MailUtil.send(toEmailSb.toString(), null, mailTitle, mailContent);
				}
			}
		}
	}

	public void sendMailShelfLifeTDD(List<String> userEmailList, HashMap<String, String> args) {
		String mailTitle = String.format("%s%s(%s)", "[사용기한 변경 안내]", args.get("productNm"), args.get("contCd"));
		StringBuilder toEmailSb = new StringBuilder();

		if (!ObjectUtils.isEmpty(userEmailList)) {
			for (String userEmail : userEmailList) {
				toEmailSb.append(userEmail).append(",");
			}
		}

		String mailContent = new MailForm().getMailContent(MailDTO.MAIL_SHELFLIFE_CHANGE_INFO, args);

		MailUtil.send(toEmailSb.toString(), null, mailTitle, mailContent);
	}

	public void insertCommAttachTemp (UploadTempDTO tempDTO) {
		commonMapper.insertCommAttachTemp(tempDTO);
	}

	public ResponseVO selectDeptLeader() {
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(commonMapper.selectDeptLeader(sessionUtil.getLoginId(), sessionUtil.getLocalLanguage()));
		return responseVO;
	}

	public ResponseVO selectAlarmList() {
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(commonMapper.selectAlarmList(sessionUtil.getLoginId()));
		return responseVO;
	}

	public ResponseVO updateAlarmCheckFlag() {
		ResponseVO responseVO = new ResponseVO();

		commonMapper.updateAlarmCheckFlag(sessionUtil.getLoginId());

		responseVO.setCreateOk(null);
		return responseVO;
	}

	public ResponseVO selectAlarmCheckCount() {
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(commonMapper.selectAlarmCheckCount(sessionUtil.getLoginId()));
		return responseVO;
	}

	@SuppressWarnings("unchecked")
	private String selectAlarmMessage (AlarmKeywordDTO alarmKeywordDTO, String typeCd, String noteType) {
		String message = "";
		if (StringUtils.isNotEmpty(alarmKeywordDTO.getVMstCode()) && StringUtils.isNotEmpty(alarmKeywordDTO.getVSubCode())) {
			CodeDTO codeInfo = commonMapper.selectCodeInfo(alarmKeywordDTO.getVMstCode(), alarmKeywordDTO.getVSubCode());

			if (codeInfo != null) {
				/*
				if (StringUtils.isNotEmpty(alarmKeywordDTO.getVContNm())) {
					String contNm = alarmKeywordDTO.getVContNm();
					String tempContNm = contNm.replaceAll(" ", "");
					String substr = tempContNm.length() >= 5 ? tempContNm.substring(4, 5) : tempContNm.substring(tempContNm.length() - 1);

					contNm = tempContNm.length() > 5 ? contNm.substring(0, contNm.indexOf(substr) + 1) + "..." : contNm;
					alarmKeywordDTO.setVContNm(contNm);
				}
				*/

				ObjectMapper objectMapper = new ObjectMapper();
				Map<String, String> alarmKeywordMap = objectMapper.convertValue(alarmKeywordDTO, Map.class);
				if (!typeCd.equals(Const.SCHEDULE)) {
					String vContent = codeInfo.getVContent1();

					if (typeCd.equals(Const.TIMELINE) && !"MU".equals(noteType) && !"HBO".equals(noteType)) {
						vContent = vContent.replaceAll("\\[#\\{vContCd\\} #\\{vContNm\\}\\]<br/>", "");
						vContent = vContent.replaceAll("\\[#\\{vContNm\\}\\]<br/>", "");
					}

					if (alarmKeywordMap != null && StringUtils.isNotEmpty(vContent)) {
						for (Map.Entry<String, String> entry : alarmKeywordMap.entrySet()) {
							vContent = vContent.replaceAll("#\\{" + entry.getKey() + "\\}", alarmKeywordMap.get(entry.getKey()));
						}
					}

					message = vContent;
				} else {
					String vBuffer3 = codeInfo.getVBuffer3();

					if (alarmKeywordMap != null && StringUtils.isNotEmpty(vBuffer3)) {
						for (Map.Entry<String, String> entry : alarmKeywordMap.entrySet()) {
							vBuffer3 = vBuffer3.replaceAll("#\\{" + entry.getKey() + "\\}", alarmKeywordMap.get(entry.getKey()));
						}
					}

					message = vBuffer3;
				}
			}
		}

		return message;
	}

	@Transactional
	public void sendAlarm (AlarmRegDTO alarmRegDTO) {
		if (!"Y".equals(alarmRegDTO.getVFlagDupl())) {
			if (commonMapper.selectNoteAlarmHistoryTypeCount(alarmRegDTO) > 0) {
				return;
			}
		}

		alarmRegDTO = ConvertUtil.convertWithSession(alarmRegDTO, AlarmRegDTO.class, sessionUtil);
		alarmRegDTO.setVUsernm(sessionUtil.getUserNm());
		alarmRegDTO.setVTeamNm(sessionUtil.getDeptNm());
		AlarmKeywordDTO keywordDTO = ConvertUtil.convert(alarmRegDTO, AlarmKeywordDTO.class);
		keywordDTO.setVMstCode(alarmRegDTO.getVStatusCd());
		keywordDTO.setVSubCode(alarmRegDTO.getVAlrTypeCd());
		alarmRegDTO.setVMessage(this.selectAlarmMessage(keywordDTO, Const.ALARM, alarmRegDTO.getVNoteType()));

		//해당 알림에 스케줄 있는 상태인지
		if((StringUtils.isNotEmpty(alarmRegDTO.getVTypeCd()) && Const.SCHEDULE.equals(alarmRegDTO.getVTypeCd()))
			|| (alarmRegDTO.getTypeList() != null && !alarmRegDTO.getTypeList().isEmpty() && alarmRegDTO.getTypeList().contains(Const.SCHEDULE))) {
			alarmRegDTO.setVFlagSchedule("Y");
		}

		if((StringUtils.isNotEmpty(alarmRegDTO.getVTypeCd()) && Const.ALARM.equals(alarmRegDTO.getVTypeCd()))
			|| (alarmRegDTO.getTypeList() != null && !alarmRegDTO.getTypeList().isEmpty() && alarmRegDTO.getTypeList().contains(Const.ALARM))) {
			alarmRegDTO.setVFlagAlarm("Y");
		}

		if((StringUtils.isNotEmpty(alarmRegDTO.getVTypeCd()) && Const.MAIL.equals(alarmRegDTO.getVTypeCd()))
			|| (alarmRegDTO.getTypeList() != null && !alarmRegDTO.getTypeList().isEmpty() && alarmRegDTO.getTypeList().contains(Const.MAIL))) {
			alarmRegDTO.setVFlagMail("Y");
		}

		if ("Y".equals(alarmRegDTO.getVFlagSchedule())) {
			alarmRegDTO.setVSchdMessage(this.selectAlarmMessage(keywordDTO, Const.SCHEDULE, alarmRegDTO.getVNoteType()));
		}

		if((StringUtils.isNotEmpty(alarmRegDTO.getVTypeCd()) && Const.TIMELINE.equals(alarmRegDTO.getVTypeCd()))
				|| (alarmRegDTO.getTypeList() != null && !alarmRegDTO.getTypeList().isEmpty() && alarmRegDTO.getTypeList().contains(Const.TIMELINE))) {
				alarmRegDTO.setVTimeMessage(this.selectAlarmMessage(keywordDTO, Const.TIMELINE, alarmRegDTO.getVNoteType()));
			}

		int result = 0;
		int alarmCount = commonMapper.selectNoteAlarmMstCount(alarmRegDTO);
		if (alarmCount > 0) {
			result = alarmCount;
			if("Y".equals(alarmRegDTO.getVFlagSchedule())) {
				int existSchd = commonMapper.selectNoteAlarmMstScheduleCount(alarmRegDTO);
				if(existSchd == 0) {	//스케줄 시작일자 없을때만
					result = commonMapper.updateNoteAlarmMstScheduleDt(alarmRegDTO);
				}
			}
		}else {
			result = commonMapper.insertNoteAlarmMst(alarmRegDTO);
		}

		if (result > 0) {
			if (alarmRegDTO.getTypeList() != null && !alarmRegDTO.getTypeList().isEmpty()) {
				commonMapper.insertNoteAlarmHistoryForTypeList(alarmRegDTO);
			} else {
				commonMapper.insertNoteAlarmHistory(alarmRegDTO);
			}

			// 로그인 유저와 동일 사번 제거
			if (alarmRegDTO.getUserList() != null && !alarmRegDTO.getUserList().isEmpty()) {
				List<String> userList = alarmRegDTO.getUserList()
											.stream()
											.distinct()
											.filter(user -> StringUtils.isNotEmpty(user) && !sessionUtil.getLoginId().equals(user))
											.collect(Collectors.toList());
				if ("N".equals(alarmRegDTO.getVFlagAlarmDupl())) {
					Iterator<String> itr = userList.iterator();

					while(itr.hasNext()) {
						alarmRegDTO.setVUserid(itr.next());

						if (commonMapper.selectNoteAlarmHistoryCount(alarmRegDTO) > 0) {
							itr.remove();
						}
					}
				}
				if (userList != null && !userList.isEmpty()) {
					alarmRegDTO.setUserList(userList);
					commonMapper.insertNoteAlarmSendUser(alarmRegDTO);
				}
			}
		}
	}

	@Transactional
	public void sendAlarmBatch (AlarmRegDTO alarmRegDTO) {
		if (!"Y".equals(alarmRegDTO.getVFlagDupl())) {
			if (commonMapper.selectNoteAlarmHistoryTypeCount(alarmRegDTO) > 0) {
				return;
			}
		}

		alarmRegDTO.setVRegUserid("BATCH");
		alarmRegDTO.setVUpdateUserid("BATCH");

		AlarmKeywordDTO keywordDTO = ConvertUtil.convert(alarmRegDTO, AlarmKeywordDTO.class);
		keywordDTO.setVMstCode(alarmRegDTO.getVStatusCd());
		keywordDTO.setVSubCode(alarmRegDTO.getVAlrTypeCd());
		alarmRegDTO.setVMessage(this.selectAlarmMessage(keywordDTO, Const.ALARM, alarmRegDTO.getVNoteType()));

		//해당 알림에 스케줄 있는 상태인지
		if((StringUtils.isNotEmpty(alarmRegDTO.getVTypeCd()) && Const.SCHEDULE.equals(alarmRegDTO.getVTypeCd()))
			|| (alarmRegDTO.getTypeList() != null && !alarmRegDTO.getTypeList().isEmpty() && alarmRegDTO.getTypeList().contains(Const.SCHEDULE))) {
			alarmRegDTO.setVFlagSchedule("Y");
		}

		if((StringUtils.isNotEmpty(alarmRegDTO.getVTypeCd()) && Const.ALARM.equals(alarmRegDTO.getVTypeCd()))
			|| (alarmRegDTO.getTypeList() != null && !alarmRegDTO.getTypeList().isEmpty() && alarmRegDTO.getTypeList().contains(Const.ALARM))) {
			alarmRegDTO.setVFlagAlarm("Y");
		}

		if((StringUtils.isNotEmpty(alarmRegDTO.getVTypeCd()) && Const.MAIL.equals(alarmRegDTO.getVTypeCd()))
			|| (alarmRegDTO.getTypeList() != null && !alarmRegDTO.getTypeList().isEmpty() && alarmRegDTO.getTypeList().contains(Const.MAIL))) {
			alarmRegDTO.setVFlagMail("Y");
		}

		if ("Y".equals(alarmRegDTO.getVFlagSchedule())) {
			alarmRegDTO.setVSchdMessage(this.selectAlarmMessage(keywordDTO, Const.SCHEDULE, alarmRegDTO.getVNoteType()));
		}

		if((StringUtils.isNotEmpty(alarmRegDTO.getVTypeCd()) && Const.TIMELINE.equals(alarmRegDTO.getVTypeCd()))
				|| (alarmRegDTO.getTypeList() != null && !alarmRegDTO.getTypeList().isEmpty() && alarmRegDTO.getTypeList().contains(Const.TIMELINE))) {
				alarmRegDTO.setVTimeMessage(this.selectAlarmMessage(keywordDTO, Const.TIMELINE, alarmRegDTO.getVNoteType()));
			}

		int result = 0;
		int alarmCount = commonMapper.selectNoteAlarmMstCount(alarmRegDTO);
		if (alarmCount > 0) {
			result = alarmCount;
			if("Y".equals(alarmRegDTO.getVFlagSchedule())) {
				int existSchd = commonMapper.selectNoteAlarmMstScheduleCount(alarmRegDTO);
				if(existSchd == 0) {	//스케줄 시작일자 없을때만
					result = commonMapper.updateNoteAlarmMstScheduleDt(alarmRegDTO);
				}
			}
		}else {
			result = commonMapper.insertNoteAlarmMst(alarmRegDTO);
		}

		if (result > 0) {
			if (alarmRegDTO.getTypeList() != null && !alarmRegDTO.getTypeList().isEmpty()) {
				commonMapper.insertNoteAlarmHistoryForTypeList(alarmRegDTO);
			} else {
				commonMapper.insertNoteAlarmHistory(alarmRegDTO);
			}

			// 로그인 유저와 동일 사번 제거
			if (alarmRegDTO.getUserList() != null && !alarmRegDTO.getUserList().isEmpty()) {
				alarmRegDTO.setUserList(alarmRegDTO.getUserList());
				commonMapper.insertNoteAlarmSendUser(alarmRegDTO);
			}
		}
	}

	/**
	 * ApprovalController 에 있는 /select-approval-info 내용
	 * @param apprCd
	 * @return
	 */
	public ReqResApprovalDTO selectApprovalInfo(String apprCd) {

		ApprovalDTO apprInfo = approvalMapper.selectApprovalInfo(apprCd, sessionUtil.getLocalLanguage());
		List<ApprovalDetailDTO> apprList = null;

		if (apprInfo != null) {
			apprList = approvalMapper.selectApprovalDetailList(apprCd, sessionUtil.getLocalLanguage());
		}

		ReqResApprovalDTO resApprovalDTO = ReqResApprovalDTO.builder()
				.apprInfo(apprInfo)
				.apprList(apprList)
				.build();

		return resApprovalDTO;
	}

	public List<String> selectReferenceUserList(String vRecordId) {
		return approvalMapper.selectReferenceUserList(vRecordId);
	}

	public ResponseVO selectMyApprovalCount() {
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(commonMapper.selectMyApprovalCount(sessionUtil.getLoginId()));
		return responseVO;
	}

	public void deleteCommAttachForRecordid(String vRecordid) {
		commonMapper.deleteCommAttachForRecordid(vRecordid);
	}

	public void deleteSsmAttachForRecordid(String vRecordid) {
		commonMapper.deleteSsmAttachForRecordid(vRecordid);
	}

	public ResponseVO selectUserList(String keyword) {
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(commonMapper.selectUserList(keyword, sessionUtil.getLocalLanguage()));
		return responseVO;
	}

	@Transactional
	public void updateSkyApprovalAprvDtlUrl(String vApprCd, String vAprvDtlUrl) {
		commonMapper.updateSkyApprovalAprvDtlUrl(vApprCd, vAprvDtlUrl);
	}

	public List<ApprovalDTO> selectELabNoteApprovalSendMailList(String vApprCd) {
		return approvalMapper.selectELabNoteApprovalSendMailList(vApprCd);
	}

	public void insertLotStatusHistory (LotStatusRegDTO lotStatusRegDTO) {
		String message = "";
		List<CodeDTO> codeList = commonMapper.selectCodeList(Arrays.asList("AL_NOTE12"));
		List<CodeDTO> bufferList = codeList.stream().filter(dto -> lotStatusRegDTO.getVLabStatusCd().equals(dto.getVBuffer1())).collect(Collectors.toList());
		if (bufferList != null && !bufferList.isEmpty()) {
			message = bufferList.get(0).getVBuffer3();
			message = message.replaceAll("#\\{nPilotNo\\}", lotStatusRegDTO.getNPilotNo());

			lotStatusRegDTO.setVStatusCd("AL_NOTE12");
			lotStatusRegDTO.setVAlrTypeCd(bufferList.get(0).getVSubCode());
			lotStatusRegDTO.setVMessage(message);
			lotStatusRegDTO.setVRegUserid("Y".equals(lotStatusRegDTO.getVFlagBatch()) ? "BATCH" : sessionUtil.getLoginId());
			commonMapper.insertLotStatusHistory(lotStatusRegDTO);
		}

	}

	public String selectLabLeaderid(String vDeptcd) {
		return commonMapper.selectLabLeaderid(vDeptcd);
	}

	//지정참조인 메일 발송
	public void sendMailApReference(DesignReferenceDTO dsRefDTO) {

		if (StringUtils.isNotEmpty(dsRefDTO.getVAppointType())) {
			String appointType = dsRefDTO.getVAppointType();
			List<WokAppointDesignationRefDTO> tempReceiverList = approvalMapper.selectAppointUserMailList(appointType);
			String emailList = tempReceiverList != null
					? tempReceiverList.stream().distinct().map(WokAppointDesignationRefDTO::getVEmail).collect(Collectors.joining(","))
					: null;

			if(StringUtils.isNotEmpty(emailList)) {
				emailList = emailList.replaceAll(" ", "");

				String mailTitle = StringUtils.isNotEmpty(dsRefDTO.getVTitle()) ? dsRefDTO.getVTitle() : "제목없음";
				String mailContent = "";
				MailForm mailForm = new MailForm();
				HashMap<String, String> params = new HashMap<>();

				params.put("url", dsRefDTO.getVUrl());

				mailContent = mailForm.getMailContent(MailDTO.MAIL_REFERENCE, params);

				MailUtil.send(emailList, null, mailTitle, mailContent);
			}
		}
	}

	public List<GroupUserInfoDTO> selectGroupUserList (String vGroupId) {
		return commonMapper.selectGroupUserList(vGroupId, sessionUtil.getLangCd());
	}

	public List<GroupUserInfoDTO> selectGroupMailRcvUserList (String vGroupId) {
		return commonMapper.selectGroupMailRcvUserList(vGroupId);
	}

}
