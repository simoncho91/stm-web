package com.mybeaker.app.common.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mybeaker.app.authority.service.AuthorityService;
import com.mybeaker.app.common.model.CommUserDesSearchInfoReqDTO;
import com.mybeaker.app.common.model.CommUserSearchInfoDTO;
import com.mybeaker.app.common.service.CommonService;
import com.mybeaker.app.model.vo.ResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/common")
@RequiredArgsConstructor
public class CommonController {
	private final CommonService commonService;
	
	private final AuthorityService authorityService;

	@GetMapping("/select-org-all-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectOrgAllList (
			@RequestParam(name="keyword") String keyword
			) {
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(commonService.selectOrgAllList(keyword));
		return ResponseEntity.ok(responseVO);
	}

	@GetMapping("/select-code-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectCodeList (
			@RequestParam(value="arrMstCode") List<String> arrMstCode
			) {
		ResponseVO responseVO = new ResponseVO();
		responseVO.setOk(commonService.selectCodeListMap(arrMstCode));

		return ResponseEntity.ok(responseVO);
	}

	@GetMapping("/select-dept-tree-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectDeptTreeList (
		@RequestParam(value="vUdeptcd") String vUdeptcd
			) {
		ResponseVO responseVO = new ResponseVO();

		responseVO.setOk(commonService.selectDeptTreeList(vUdeptcd));
		return ResponseEntity.ok(responseVO);
	}


	@Operation(summary = "공통 - 사용자 조회", description = "공통 - 사용자 목록을 조회한다. (페이징)")
	@GetMapping("/select-comm-user-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectCommUserList (
			CommUserSearchInfoDTO commUsrSrchInfDTO
			) {
		ResponseVO responseVO = commonService.selectCommUserList(commUsrSrchInfDTO);

		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "공통 - 담당자 지정", description = "공통 - 담당자를 지정한다.")
	@GetMapping("/select-comm-user-designation-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectCommUserDesignationList (
			CommUserDesSearchInfoReqDTO commUserDesSearchInfoReqDTO
			) {
		ResponseVO responseVO = commonService.selectCommUserDesignationList(commUserDesSearchInfoReqDTO);
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "담당자 검색 (페이징 없이)", description = "담당자 검색 (페이징 없이)")
	@GetMapping("/select-user-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectUserList (
			@RequestParam(name="keyword") String keyword
			) {
		ResponseVO responseVO = commonService.selectUserList(keyword);
		return ResponseEntity.ok(responseVO);
	}

	@Operation(summary = "현재 사용자의 부서장 목록 가져오기", description = "현재 사용자의 부서장 목록을 가져온다.")
	@GetMapping("/select-dept-leader")
	public @ResponseBody ResponseEntity<ResponseVO> selectDeptLeader () {
		return ResponseEntity.ok(commonService.selectDeptLeader());
	}

	@Operation(summary = "미확인 알림 카운트 조회", description = "미확인 알림 카운트를 조회한다.")
	@GetMapping("/select-alarm-check-count")
	public @ResponseBody ResponseEntity<ResponseVO> selectAlarmCheckCount () {
		return ResponseEntity.ok(commonService.selectAlarmCheckCount());
	}

	@Operation(summary = "알림 리스트 조회", description = "알림 리스트를 조회한다.")
	@GetMapping("/select-alarm-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectAlarmList () {
		return ResponseEntity.ok(commonService.selectAlarmList());
	}

	@Operation(summary = "알림 전체 읽음 처리", description = "알림 리스트 오픈 시 알림을 전체 읽음 처리한다.")
	@PostMapping("/update-alarm-check-flag")
	public @ResponseBody ResponseEntity<ResponseVO> updateAlarmCheckFlag () {
		return ResponseEntity.ok(commonService.updateAlarmCheckFlag());
	}

	@Operation(summary = "결재함 카운트 조회", description = "헤더 > 미완료 결재함 카운터를 조회한다.")
	@GetMapping("/select-my-approval-count")
	public @ResponseBody ResponseEntity<ResponseVO> selectMyApprovalCount () {
		return ResponseEntity.ok(commonService.selectMyApprovalCount());
	}
	
	@Operation(summary = "대메뉴 접근 권한 조회", description = "대메뉴 접근 권한 조회")
	@GetMapping("/select-menu-auth-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectMenuAuthList () {
		ResponseVO responseVO = new ResponseVO();
		
		responseVO.setOk(authorityService.selectMenuLevelList(null, null, null));
		return ResponseEntity.ok(responseVO);
	}
}
