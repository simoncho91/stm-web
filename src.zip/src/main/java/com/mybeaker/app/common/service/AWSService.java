package com.mybeaker.app.common.service;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.amazonaws.HttpMethod;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;
import com.mybeaker.app.common.model.UploadDTO;
import com.mybeaker.app.common.model.UploadTempDTO;
import com.mybeaker.app.model.Const;
import com.mybeaker.app.utils.CommonUtil;

import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.core.ResponseBytes;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.S3Utilities;
import software.amazon.awssdk.services.s3.model.DeleteObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import software.amazon.awssdk.services.s3.model.GetUrlRequest;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

@Slf4j
@Service
public class AWSService {
	@Value("${aws.bucket}")
	private String BUCKET_NAME;

	@Value("${aws.bucket-tium}")
	private String TIUM_BUCKET;

	private S3Client s3;

	private S3Client tiumS3;
	
	@Value("${spring.profiles.active}")
	private String ACTIVE;
	
	@Qualifier("amazonS3")
	private AmazonS3 amazonS3;

	public AWSService() {
		createS3Client();
	}

	private void createS3Client() {
		this.s3 = S3Client.builder()
					.region(Region.AP_NORTHEAST_2)
					.build();

		this.tiumS3 = S3Client.builder()
						.region(Region.AP_NORTHEAST_2)
						.build();
		
		this.amazonS3 = AmazonS3ClientBuilder
				.standard()
				.withRegion(Regions.AP_NORTHEAST_2)
				.build();
	}

	public List<UploadDTO> fileUpload(List<UploadTempDTO> fileList, String uploadCd) throws IOException {
		LocalDateTime current = LocalDateTime.now();
		DateTimeFormatter fomatter = DateTimeFormatter.ofPattern("yyyyMM");
		String date = current.format(fomatter);
		String attachName = "";
		String key = "";
		String sslPath = "";
		PutObjectRequest request = null;
		RequestBody requestBody = null;

		UploadDTO uploadDTO = null;
		List<UploadDTO> rtnList = new ArrayList<>();

		for (UploadTempDTO dto : fileList) {
			attachName = "BKR" + String.valueOf(Calendar.getInstance().getTimeInMillis()) + CommonUtil.getRandomString(2);
			key = "upload/" + uploadCd + "/" + date + "/" + attachName;
			request = PutObjectRequest.builder().bucket(BUCKET_NAME).key(key).build();

			requestBody = RequestBody.fromBytes(dto.getVFileBytea());

			this.s3.putObject(request, requestBody);
			sslPath = this.findUploadKeyUrl(key);

			uploadDTO = UploadDTO.builder()
							.nSeqno(dto.getNSeqno())
							.vUploadid(uploadCd)
							.vAttachnm(dto.getVAttachnm())
							.vAttachExt(dto.getVAttachExt())
							.nAttachSize(dto.getNAttachSize())
							.vAttachPath(sslPath.replace("https://", "http://"))
							.vSslPath(sslPath)
							.vKeyPath(key)
							.vAttachid(attachName)
							.build();

			rtnList.add(uploadDTO);
		}

		return rtnList;
	}

	public void delete(String key) {
		if (StringUtils.isEmpty(key)) {
			return;
		}
		DeleteObjectRequest request = DeleteObjectRequest.builder().bucket(BUCKET_NAME).key(key).build();
		this.s3.deleteObject(request);
	}

	public byte[] download(String keyName) {
		GetObjectRequest objectRequest = GetObjectRequest.builder()
											.key(keyName)
											.bucket(BUCKET_NAME)
											.build();

		ResponseBytes<GetObjectResponse> objectBytes = this.s3.getObjectAsBytes(objectRequest);
		byte[] data = objectBytes.asByteArray();

		return data;
	}

	public byte[] tiumBucketDownload(String keyName) {
		GetObjectRequest objectRequest = GetObjectRequest.builder()
													.key(keyName)
													.bucket(TIUM_BUCKET)
													.build();

		ResponseBytes<GetObjectResponse> objectBytes = this.tiumS3.getObjectAsBytes(objectRequest);
		byte[] data = objectBytes.asByteArray();

		return data;
	}

	private String findUploadKeyUrl(String key) {
		S3Utilities s3Utilities = this.s3.utilities();
		GetUrlRequest request = GetUrlRequest.builder()
					.bucket(BUCKET_NAME)
					.key(key)
					.build();

		URL url = s3Utilities.getUrl(request);

		return url.toString();
	}
	
	public String getPreSignedURL(String objectKey) {
		if(Const.ACTIVE_LOCAL.equals(ACTIVE)) {
			return null;
		}
		
		URL preSignedURL = null;
		Date expiration = new Date();
		long expTimeMillis = expiration.getTime();
		expTimeMillis += 1000 * 60;
		expiration.setTime(expTimeMillis);
		
		try {
			GeneratePresignedUrlRequest generatePresignedUrlRequest = new GeneratePresignedUrlRequest(BUCKET_NAME, objectKey)
					.withMethod(HttpMethod.GET)
					.withExpiration(expiration);
			preSignedURL = amazonS3.generatePresignedUrl(generatePresignedUrlRequest);
			
			return preSignedURL.toString();
		} catch (Exception e) {
			log.error("getPreSignedURL Error : {}", e.getMessage());
		}
		
		return null;
	}
}
