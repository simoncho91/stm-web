package com.mybeaker.app.common.model;

import lombok.Data;

@Data
public class ResultDTO {
	private String status;

	private String message;

	private Object object;
}
