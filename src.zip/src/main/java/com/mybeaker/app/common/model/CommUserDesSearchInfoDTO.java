package com.mybeaker.app.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CommUserDesSearchInfoDTO  {
	@JsonProperty("nNum")
	private int nNum;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vEmpno")
	private String vEmpno;

	@JsonProperty("vUsernm")
	private String vUsernm;

	@JsonProperty("vUsernmEn")
	private String vUsernmEn;

	@JsonProperty("vPositcd")
	private String vPositcd;

	@JsonProperty("vPositnm")
	private String vPositnm;

	@JsonProperty("vDutynm")
	private String vDutynm;

	@JsonProperty("vDeptcd")
	private String vDeptcd;

	@JsonProperty("vDeptnm")
	private String vDeptnm;

	@JsonProperty("vOffinm")
	private String vOffinm;

	@JsonProperty("vSigmaDeptcd")
	private String vSigmaDeptcd;

	@JsonProperty("vPhoneNO")
	private String vPhoneNO;

	@JsonProperty("vEmail")
	private String vEmail;

	@JsonProperty("vLabor")
	private String vLabor;

	@JsonProperty("vRegUserid")
	private String vRegUserid;

	@JsonProperty("vRegDtm")
	private String vRegDtm;

	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;

	@JsonProperty("vUpdateDtm")
	private String vUpdateDtm;

	@JsonProperty("vSigmaDeptnm")
	private String vSigmaDeptnm;

}
