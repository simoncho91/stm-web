package com.mybeaker.app.common.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.mybeaker.app.common.model.AlarmDTO;
import com.mybeaker.app.common.model.AlarmRegDTO;
import com.mybeaker.app.common.model.CodeDTO;
import com.mybeaker.app.common.model.CommUserDesSearchInfoDTO;
import com.mybeaker.app.common.model.CommUserDesSearchInfoReqDTO;
import com.mybeaker.app.common.model.CommUserSearchInfoDTO;
import com.mybeaker.app.common.model.CommUserSearchInfoReqDTO;
import com.mybeaker.app.common.model.DeptDTO;
import com.mybeaker.app.common.model.GroupUserInfoDTO;
import com.mybeaker.app.common.model.OrganizationDTO;
import com.mybeaker.app.common.model.ThumbnailDTO;
import com.mybeaker.app.common.model.UploadDTO;
import com.mybeaker.app.common.model.UploadTempDTO;
import com.mybeaker.app.labnote.model.LotStatusRegDTO;
import com.mybeaker.app.labnote.model.ScheduleDTO;

@Mapper
public interface CommonMapper {
	List<OrganizationDTO> selectOrgAllList(String keyword);

	List<CodeDTO> selectCodeList(List<String> arrMstCode);

	void insertCommAttachTemp(UploadTempDTO tempDTO);

	int insertCommAttach(List<UploadDTO> uploadSuccList, String vRecordid, String vRegUserid);

	List<UploadTempDTO> selectCommAttachTempList(List<UploadTempDTO> fileList);

	void deleteCommAttachTemp(List<UploadDTO> uploadSuccList);

	List<UploadDTO> selectCommAttachList(String vRecordid, String vUploadid);

	UploadDTO selectCommAttachInfo(String vAttachid);

	List<DeptDTO> selectDeptTreeList(String vUdeptcd);

	List<ThumbnailDTO> selectThumbnailList(String vRecordid, String vFlag);

	void insertSsmAttach(List<UploadDTO> uploadSuccList, String vRecordid, String vRegUserid);

	void deleteCommAttach(UploadDTO item);

	void deleteSsmAttach(UploadDTO item);

	int selectCommUserListCount(CommUserSearchInfoDTO commUsrSrchInfDTO);

	List<CommUserSearchInfoReqDTO> selectCommUserList(CommUserSearchInfoDTO commUsrSrchInfDTO);

	int selectCommUserDesignationListCount(CommUserDesSearchInfoReqDTO commUserDesSearchInfoDTO);

	List<CommUserDesSearchInfoDTO> selectCommUserDesignationList(CommUserDesSearchInfoReqDTO commUserDesSearchInfoDTO);

	List<ScheduleDTO> selectScheduleList(String vLabNoteCd);

	List<CommUserDesSearchInfoDTO> selectDeptLeader(String vUserid, String localLanguage);

	List<AlarmDTO> selectAlarmList(String vUserid);

	void updateAlarmCheckFlag(String vUserid);

	int selectAlarmCheckCount(String vUserid);

	int insertNoteAlarmMst(AlarmRegDTO alarmRegDTO);

	void insertNoteAlarmHistory(AlarmRegDTO alarmRegDTO);

	void insertNoteAlarmSendUser(AlarmRegDTO alarmRegDTO);

	void insertNoteAlarmHistoryForTypeList(AlarmRegDTO alarmRegDTO);

	CodeDTO selectCodeInfo(String vMstCode, String vSubCode);

	int selectNoteAlarmMstCount(AlarmRegDTO alarmRegDTO);

	int selectNoteAlarmMstScheduleCount(AlarmRegDTO alarmRegDTO);

	int updateNoteAlarmMstScheduleDt(AlarmRegDTO alarmRegDTO);

	int selectMyApprovalCount(String loginId);

	void deleteCommAttachForRecordid(String vRecordid);

	void deleteSsmAttachForRecordid(String vRecordid);

	List<CommUserSearchInfoReqDTO> selectUserList(String keyword, String localLanguage);

	void updateSkyApprovalAprvDtlUrl(String vApprCd, String vAprvDtlUrl);

	UploadDTO selectTiumCommAttachInfo(String vAttachid);

	void insertLotStatusHistory(LotStatusRegDTO lotStatusRegDTO);

	String selectLabLeaderid(String vDeptcd);

	int selectNoteAlarmHistoryCount(AlarmRegDTO alarmRegDTO);

	List<GroupUserInfoDTO> selectGroupUserList(String vGroupId, String vLanguage);

	List<GroupUserInfoDTO> selectGroupMailRcvUserList(String vGroupId);

	int selectNoteAlarmHistoryTypeCount(AlarmRegDTO alarmRegDTO);
}
