package com.mybeaker.app.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AlarmKeywordDTO {
	@JsonProperty("vMstCode")
	private String vMstCode;

	@JsonProperty("vSubCode")
	private String vSubCode;

	@JsonProperty("vContCd")
	@Builder.Default
	private String vContCd = "";

	@JsonProperty("vContNm")
	@Builder.Default
	private String vContNm = "";

	@JsonProperty("vUsernm")
	@Builder.Default
	private String vUsernm = "";

	@JsonProperty("vTeamNm")
	@Builder.Default
	private String vTeamNm = "";

	@JsonProperty("vFromUsernm")
	@Builder.Default
	private String vFromUsernm = "";

	@JsonProperty("vFromTeamNm")
	@Builder.Default
	private String vFromTeamNm = "";

	@JsonProperty("vToUsernm")
	@Builder.Default
	private String vToUsernm = "";

	@JsonProperty("vToTeamNm")
	@Builder.Default
	private String vToTeamNm = "";

	@JsonProperty("vExamNm")
	@Builder.Default
	private String vExamNm = "";

	@JsonProperty("vLotNm")
	@Builder.Default
	private String vLotNm = "";

	@JsonProperty("nVerNo")
	@Builder.Default
	private String nVerNo = "";

	@JsonProperty("nSeqno")
	@Builder.Default
	private String nSeqno = "";
}
