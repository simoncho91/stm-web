package com.mybeaker.app.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@Data
public class ThumbnailDTO extends ParentDTO {
	
	@JsonProperty("vThumbnailid")
	private String vThumbnailid;

	@JsonProperty("nThumbnailWidth")
	private int nThumbnailWidth;

	@JsonProperty("vThumbnailTypecd")
	private String vThumbnailTypecd;

	@JsonProperty("vRecordid")
	private String vRecordid;

	@JsonProperty("vFlag")
	private String vFlag;

	@JsonProperty("vBuffer1")
	private String vBuffer1;

	@JsonProperty("vBuffer2")
	private String vBuffer2;

	@JsonProperty("vBuffer3")
	private String vBuffer3;

	@JsonProperty("vThumbnailnm")
	private String vThumbnailnm;

	@JsonProperty("vThumbnailPath")
	private String vThumbnailPath;

	@JsonProperty("vThumbnailExt")
	private String vThumbnailExt;

	@JsonProperty("nThumbnailSize")
	private int nThumbnailSize;

	@JsonProperty("vFlagOriginal")
	private String vFlagOriginal;

	@JsonProperty("nSeqno")
	private int nSeqno;

	@JsonProperty("vFlagDel")
	private String vFlagDel;

	@Builder
	public ThumbnailDTO(String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm,
			String vThumbnailid, int nThumbnailWidth, String vThumbnailTypecd, String vRecordid, String vFlag,
			String vBuffer1, String vBuffer2, String vBuffer3, String vThumbnailnm, String vThumbnailPath,
			String vThumbnailExt, int nThumbnailSize, String vFlagOriginal, int nSeqno, String vFlagDel) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.vThumbnailid = vThumbnailid;
		this.nThumbnailWidth = nThumbnailWidth;
		this.vThumbnailTypecd = vThumbnailTypecd;
		this.vRecordid = vRecordid;
		this.vFlag = vFlag;
		this.vBuffer1 = vBuffer1;
		this.vBuffer2 = vBuffer2;
		this.vBuffer3 = vBuffer3;
		this.vThumbnailnm = vThumbnailnm;
		this.vThumbnailPath = vThumbnailPath;
		this.vThumbnailExt = vThumbnailExt;
		this.nThumbnailSize = nThumbnailSize;
		this.vFlagOriginal = vFlagOriginal;
		this.nSeqno = nSeqno;
		this.vFlagDel = vFlagDel;
	}
}
