package com.mybeaker.app.common.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MailDTO {

    //발송 상태
    public static final String MAIL_001 = "MA0001";

    //발송 성공
    public static final String MAIL_002 = "MA0002";

    //발송 에러
    public static final String MAIL_003 = "MA0003";

    // Example
    public static final String MAIL_EXAMPLE = "ME0001";

    // 결재 메일
    public static final String MAIL_APPROVAL = "MAPR0001";

    // 사용기한 변경안내 메일
    public static final String MAIL_SHELFLIFE_CHANGE_INFO = "MAPR0002";

    // 결재 완료 메일(GATE0, GATE1, GATE2)
    public static final String MAIL_GATE_APPROVAL_END = "MAPR0003";

    // 참조 메일
    public static final String MAIL_REFERENCE = "MREF0001";

    //기능성 검사 답장 발송 메일 ( QA담당자 --> 연구원 )
    public static final String MAIL_ANSWER_FUNC_TEST = "MAFT0001";

    //시험성적서 요청 메일
    public static final String MAIL_REQUEST_FUNC_TEST = "MAFT0002";

    //마케터 공유하기 메일
    public static final String MAIL_MARKETER_SHARE = "MAMS0001";

    // SC - 연구담당자 지정 메일 발송
    public static final String MAIL_SC_CHARGER = "MSC0001";
    
    //시험의뢰 - 방부 처방 알림 메일
    public static final String MAIL_MRQ011_ALARM = "MLMRQ011";
    
    //의약외품 - 신고/허가 영업비밀 메일
    public static final String MAIL_SA_REPORT_SECRET = "MSASC001";

    //허가지원 - 심사의뢰 분석보고서 요청 메일 발송
    public static final String MAIL_SA_REPORT_SUPO = "MSASP001";

    private String langcd;

    private String recordid;

    private String title;

    private String toEmail;

    private String ccEmail;

    private String fromUsernm;

    private String fromEmail;

    private String content;

    private String type;

    private String userid;

    private String flagFile;

    private String flagMail;

    private String[] file;

    private String[] filePath;

    public void setMail( String toEmail, String title, String content, String fromEmail) {
        this.toEmail 	= toEmail;
        this.title 	 	= title;
        this.content 	= content;
        this.fromEmail 	= fromEmail;
    }
}
