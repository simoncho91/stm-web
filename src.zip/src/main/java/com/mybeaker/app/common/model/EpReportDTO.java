package com.mybeaker.app.common.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class EpReportDTO {

    //기능성 보고 심사
    public static final String REF_TYPE_REPORT = "LNC05_02";
    
    //기능성 신규 심사
    public static final String REF_TYPE_NEW = "LNC05_03";
    
    //기능성 변경 심사
    public static final String REF_TYPE_CHANGE = "LNC05_04";

}
