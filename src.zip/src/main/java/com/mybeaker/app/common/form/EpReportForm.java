package com.mybeaker.app.common.form;

import org.apache.commons.lang3.StringUtils;

import com.mybeaker.app.common.model.EpReportDTO;
import com.mybeaker.app.labnote.model.LabNoteProcessFuncReportDataDTO;

public class EpReportForm {

	public EpReportForm() {}

    public String getEpReportContent(String type, LabNoteProcessFuncReportDataDTO fvo) {
        String reportContent = "";

        if (StringUtils.isNotEmpty(type)) {
            switch (type) {
	            case EpReportDTO.REF_TYPE_REPORT:
	            	reportContent = getFuncTestReportForm(fvo);
	            	break;
	            case EpReportDTO.REF_TYPE_NEW:
	            	reportContent = getFuncTestNewForm(fvo);
	            	break;
	            case EpReportDTO.REF_TYPE_CHANGE:
	            	reportContent = getFuncTestChangeForm(fvo);
	            	break;
	            default:
	                break;
            }
        }

        return reportContent;
    }
    
    // 기능성 보고 심사
    private String getFuncTestReportForm(LabNoteProcessFuncReportDataDTO fvo) {
        StringBuilder sb = new StringBuilder();
        sb.append("\n").append("<html>");
        sb.append("\n").append("	<head>");
        sb.append("\n").append("		<title>기능성 보고심사</title>");
        sb.append("\n").append("		<meta content=\"text/html; charset=utf-8\" http-equiv=Content-Type>");
        sb.append("\n").append("		<meta name=GENERATOR content=ActiveSquare>");
        sb.append("\n").append("	</head>");
        sb.append("\n").append("	<body>");
        sb.append("\n").append("		<table cellSpacing=0 borderColorLight=black borderColorDark=white cellPadding=0 width=650 height=30>");
        sb.append("\n").append("			<tbody>");
        sb.append("\n").append("				<tr>");
        sb.append("\n").append("					<td width=565>");
        sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center><b><font style=\"FONT-FAMILY: 맑은 고딕\" size=4> 기능성 보고</font></b></p>");
        sb.append("\n").append("					</td>");
        sb.append("\n").append("					<td width=85>");
        sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\"><span style=\"FONT-FAMILY: 맑은 고딕\"></span></p>");
        sb.append("\n").append("					</td>");
        sb.append("\n").append("				</tr>");
        sb.append("\n").append("			</tbody>");
        sb.append("\n").append("		</table>");
        sb.append("\n").append("		<table border=1 cellSpacing=0 borderColorLight=black borderColorDark=white cellPadding=0 width=690>");
        sb.append("\n").append("			<tbody>");
        sb.append("\n").append("				<tr height=24>");
        sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=32 width=213>");
        sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
        sb.append("\n").append("							<b><span style=\" font-size: 10pt; FONT-FAMILY: 맑은 고딕;\">제품정보</span></b>");
        sb.append("\n").append("						</p>");
        sb.append("\n").append("					</td>");
        sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=32 width=89>");
        sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
        sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕;\">내용물코드</span>");
        sb.append("\n").append("						</p>");
        sb.append("\n").append("					</td>");
        sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=32 width=157>");
        sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
        sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕;\">"+ fvo.getVContCd() +"</span>");   //${fvo.v_cont_cd}
        sb.append("\n").append("						</p>");
        sb.append("\n").append("					</td>");
        sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=32 width=79>");
        sb.append("\n").append("						<span style=\"FONT-FAMILY: 맑은 고딕;\">제품명</span>");
        sb.append("\n").append("					</td>");
        sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=32 width=140>");        
        sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
        sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕;\">"+ fvo.getVContNm() + "</span>");	//${fvo.v_cont_nm}
        sb.append("\n").append("						</p>");
        sb.append("\n").append("					</td>");
        sb.append("\n").append("				</tr>");
        sb.append("\n").append("				<tr height=24>");
        sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=32 width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size: 10pt; FONT-FAMILY: 맑은 고딕;\">담당자</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=32 width=79>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕;\">제품연구원</span>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=32 width=140>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕;\">"+ fvo.getVUserInfo() + "</span>");	//${fvo.v_user_info}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=32 width=89>");
		sb.append("\n").append("						<span style=\"FONT-FAMILY: 맑은 고딕;\">담당PM</span>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=32 width=157>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕;\">"+ fvo.getVBrdUserInfo()+"</span>");	//${fvo.v_brd_user_info}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>   ");     
        sb.append("\n").append("				</tr>");
	    sb.append("\n").append("				<tr height=24>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=31 width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size:10pt; FONT-FAMILY: 맑은 고딕;\">기능성 유형</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; FONT-SIZE: 10pt; PADDING-TOP: 3px; COLOR: blue; FONT-FAMILY: 맑은 고딕;\" height=31 width=459 colSpan=4>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕;\">"+ fvo.getVFuncTypeInfo() +"</span>&nbsp;");		//${fvo.i_sFunctionNm}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr height=24>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=29 width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size:10pt; FONT-FAMILY: 맑은 고딕;\">주성분<br>[원료코드] 원료명 (함량 %)</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" id=p2 height=29 width=459 colSpan=4>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕;\">"+ fvo.getVFuncMateInfo() + "</span>");		//${fvo.v_func_mate_info}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>    ");    
		sb.append("\n").append("				<tr height=24>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=47 width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size:10pt; FONT-FAMILY: 맑은 고딕\">근거품목 <br>(심사번호/고시품목)</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" id=p2 height=47 width=459 colSpan=4>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕\">"+(StringUtils.isNotEmpty(fvo.getVRefTypeInfo()) ? fvo.getVRefTypeInfo() : "해당사항 없음")+"</span>");	//${!empty fvo.v_ref_type_nm ? fvo.v_ref_type_info : '해당사항없음'}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr height=24>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px\" height=29 width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size:10pt; FONT-FAMILY: 맑은 고딕;\">홋수명</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" id=p2 height=29 width=459 colSpan=4>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=left>");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕;\">"+ (StringUtils.isNotEmpty(fvo.getVNumberNm()) ? fvo.getVNumberNm() : "해당사항 없음") +"</span>");		//${!empty fvo.v_number_nm ? fvo.v_number_nm : '해당사항없음'}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>"		);
		sb.append("\n").append("				<tr height=24>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size:10pt; FONT-FAMILY: 맑은 고딕;\">총 TiO₂ , ZnO 함량 </span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" width=79>");
		sb.append("\n").append("						<span style=\"FONT-FAMILY: 맑은 고딕;\">TiO₂ 함량</span>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" width=140>");
		sb.append("\n").append("						<font style=\"FONT-FAMILY: 맑은 고딕;\" size=2>"+ (StringUtils.isNotEmpty(String.valueOf(fvo.getNTioTwoRate())) ? fvo.getNTioTwoRate() : "X") +"</font>");	//${!empty fvo.n_tiotwo_rate ? fvo.n_tiotwo_rate : 'X'}
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" width=89>");
		sb.append("\n").append("						<span style=\"FONT-FAMILY: 맑은 고딕;\">ZnO 함량</span>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" width=157>");
		sb.append("\n").append("						<font style=\"FONT-FAMILY: 맑은 고딕;\" size=2>"+ (StringUtils.isNotEmpty(String.valueOf(fvo.getNZnoRate())) ? fvo.getNZnoRate() : "X") +"</font>");	//	${!empty fvo.n_zno_rate ? fvo.n_zno_rate : 'X'}
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr height=24>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size:10pt; FONT-FAMILY: 맑은 고딕;\">파일럿 시기</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"TEXT-ALIGN: left; PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" id=p2 height=25 width=459 colSpan=4>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=left>");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕; COLOR: #0000ff\">"+ (StringUtils.isNotEmpty(fvo.getVPilotDt()) ? fvo.getVPilotDt() : "해당사항 없음") +"</span>");		//${!empty fvo.v_pilot_dt ? fvo.v_pilot_dt : '해당사항없음'}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>		");
		sb.append("\n").append("				<tr height=24>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=24 width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size:10pt; FONT-FAMILY: 맑은 고딕;\">출시지역 (출시 예정일)</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" id=p2 height=25 width=459 colSpan=4>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕\">"+(StringUtils.isNotEmpty(fvo.getVReleaseDt()) ? fvo.getVReleaseDt() : "해당사항 없음")+"</span>");		//${!empty fvo.v_release_dt ? fvo.v_release_dt : '해당사항없음'}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr height=24>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=26 width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size:10pt; FONT-FAMILY: 맑은 고딕\">제형</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" id=p2 height=26 width=459 colSpan=4>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕\">"+ (StringUtils.isNotEmpty(fvo.getVShape()) ? fvo.getVShape() : "해당사항 없음") +"</span>");	//${!empty fvo.v_shape ? fvo.v_shape : '해당사항없음'}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr height=24>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size:10pt; FONT-FAMILY: 맑은 고딕\">ｐH(기준치±1.0)</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" id=p2 height=25 width=459 colSpan=4>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕\">"+ (StringUtils.isNotEmpty(fvo.getVPh()) ? fvo.getVPh() : "해당사항 없음") +"</span>");	//${!empty fvo.v_ph ? fvo.v_ph : '해당사항없음'}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr height=24>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size:10pt; FONT-FAMILY: 맑은 고딕\">에탄올4% 초과 여부</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" id=p2 height=25 width=459 colSpan=4>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕; \">"+ (StringUtils.isNotEmpty(fvo.getVFlagOverEthanolNm()) ? fvo.getVFlagOverEthanolNm() : "해당사항 없음")+ "</span>"); 	//${fvo.v_flag_over_ethanol_nm}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr height=24>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size: 10pt; FONT-FAMILY: 맑은 고딕\">제조원</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" id=p2 width=459 colSpan=4>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕\">"+ (StringUtils.isNotEmpty(fvo.getVMaker()) ? fvo.getVMaker() : "해당사항 없음") +"</span>");	//${!empty fvo.v_maker ? fvo.v_maker : '해당사항없음'}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>	"	);
        sb.append("\n").append("			</tbody>");
        sb.append("\n").append("		</table>");
        sb.append("\n").append("	</body>");
        sb.append("\n").append("</html>");
        return sb.toString();
    }
    
    // 기능성 신규 심사
    private String getFuncTestNewForm(LabNoteProcessFuncReportDataDTO fvo) {
        StringBuilder sb = new StringBuilder();
        sb.append("\n").append("<html>");
        sb.append("\n").append("	<head>");
        sb.append("\n").append("		<title>기능성 신규심사</title>");
        sb.append("\n").append("		<meta content=\"text/html; charset=utf-8\" http-equiv=Content-Type>");
        sb.append("\n").append("		<meta name=GENERATOR content=ActiveSquare>");
        sb.append("\n").append("	</head>");
        sb.append("\n").append("	<body>");
        sb.append("\n").append("		<table cellSpacing=0 borderColorLight=black borderColorDark=white cellPadding=0 width=650 height=30>");
        sb.append("\n").append("			<tbody>");
        sb.append("\n").append("				<tr>");
        sb.append("\n").append("					<td width=565>");
        sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center><b><font style=\"FONT-FAMILY: 맑은 고딕\" size=4> 기능성 신규심사</font></b></p>");
        sb.append("\n").append("					</td>");
        sb.append("\n").append("					<td width=85>");
        sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\"><span style=\"FONT-FAMILY: 맑은 고딕\"></span></p>");
        sb.append("\n").append("					</td>");
        sb.append("\n").append("				</tr>");
        sb.append("\n").append("			</tbody>");
        sb.append("\n").append("		</table>");
        sb.append("\n").append("		<table border=1 cellSpacing=0 borderColorLight=black borderColorDark=white cellPadding=0 width=690>");
        sb.append("\n").append("			<tbody>");
        sb.append("\n").append("				<tr height=24>");
        sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=32 width=213>");
        sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
        sb.append("\n").append("							<b><span style=\" font-size: 10pt; FONT-FAMILY: 맑은 고딕;\">제 품 명</span></b>");
        sb.append("\n").append("						</p>");
        sb.append("\n").append("					</td>");
        sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; FONT-SIZE: 10pt; PADDING-TOP: 3px; COLOR: blue; FONT-FAMILY: 맑은 고딕;\" height=31 width=459 colSpan=4>");
        sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
        sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕;\">"+ fvo.getVContNm() +"</span>");		//${fvo.v_cont_nm}
        sb.append("\n").append("						</p>");
        sb.append("\n").append("					</td>");
        sb.append("\n").append("				</tr>");
        sb.append("\n").append("				<tr height=24>");
        sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=32 width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size: 10pt; FONT-FAMILY: 맑은 고딕;\">담 당 자</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=32 width=79>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕;\">제품 연구원</span>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=32 width=140>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕;\">"+ fvo.getVUserInfo() + "</span>");	//${fvo.v_user_info}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=32 width=89>");
		sb.append("\n").append("						<span style=\"FONT-FAMILY: 맑은 고딕;\">담당 PM</span>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=32 width=157>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕;\">"+ fvo.getVBrdUserInfo()+"</span>");	//${fvo.v_brd_user_info}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>   ");     
        sb.append("\n").append("				</tr>");
	    sb.append("\n").append("				<tr height=24>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=31 width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size:10pt; FONT-FAMILY: 맑은 고딕;\">내용물 코드</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; FONT-SIZE: 10pt; PADDING-TOP: 3px; COLOR: blue; FONT-FAMILY: 맑은 고딕;\" height=31 width=459 colSpan=4>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕;\">"+ fvo.getVContCd() +"</span>&nbsp;");		//${fvo.v_cont_cd}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr height=24>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=29 width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size:10pt; FONT-FAMILY: 맑은 고딕;\">주 성 분<br>[원료코드] 원료명 (함량 %)</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" id=p2 height=29 width=459 colSpan=4>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕;\">"+ fvo.getVFuncMateInfo() + "</span>");		//${fvo.v_func_mate_info}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>    ");    
		sb.append("\n").append("				<tr height=24>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=47 width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size:10pt; FONT-FAMILY: 맑은 고딕\">양 산 일</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" id=p2 height=47 width=459 colSpan=4>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕\">"+ fvo.getVMassProdDt() +"</span>");	//${fvo.v_mass_prod_dt}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr height=24>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=24 width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size:10pt; FONT-FAMILY: 맑은 고딕;\">출시지역 (출시 예정일)</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" id=p2 height=25 width=459 colSpan=4>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕\">"+(StringUtils.isNotEmpty(fvo.getVReleaseDt()) ? fvo.getVReleaseDt() : "해당사항 없음")+"</span>");		//${!empty fvo.v_release_dt ? fvo.v_release_dt : '해당사항없음'}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr height=24>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px\" height=29 width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size:10pt; FONT-FAMILY: 맑은 고딕;\">제 형</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" id=p2 height=29 width=459 colSpan=4>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=left>");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕;\">"+ (StringUtils.isNotEmpty(fvo.getVShape()) ? fvo.getVShape() : "해당사항 없음") +"</span>");		//${!empty fvo.v_shape ? fvo.v_shape : '해당사항없음'}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>"		);
		sb.append("\n").append("				<tr height=24>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size:10pt; FONT-FAMILY: 맑은 고딕;\">효능·효과</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"TEXT-ALIGN: left; PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" id=p2 height=25 width=459 colSpan=4>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"FONT-FAMILY: 맑은 고딕;COLOR: #0000ff\">" + (StringUtils.isNotEmpty(fvo.getVEffect()) ? fvo.getVEffect() : "") +"</span></b>"); 	//${fvo.v_effect}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr height=24>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size:10pt; FONT-FAMILY: 맑은 고딕;\">용법·용량</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"TEXT-ALIGN: left; PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" id=p2 height=25 width=459 colSpan=4>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=left>");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕;\">"+ (StringUtils.isNotEmpty(fvo.getVUsageCapacity()) ? fvo.getVUsageCapacity() : "")  +"</span>");		//${fvo.v_usage_capacity}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>		");
		sb.append("\n").append("				<tr height=24>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=26 width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size:10pt; FONT-FAMILY: 맑은 고딕\">제조 사업장<br>(대전/오산/기타)</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" id=p2 height=26 width=459 colSpan=4>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕\">"+ (StringUtils.isNotEmpty(fvo.getVMakePlace()) ? fvo.getVMakePlace() : "")  +"</span>");	//${fvo.v_make_place}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>");
        sb.append("\n").append("			</tbody>");
        sb.append("\n").append("		</table>");
        sb.append("\n").append("	</body>");
        sb.append("\n").append("</html>");
        return sb.toString();
    }
    
    // 기능성 변경 심사
    private String getFuncTestChangeForm(LabNoteProcessFuncReportDataDTO fvo) {
        StringBuilder sb = new StringBuilder();
        sb.append("\n").append("<html>");
        sb.append("\n").append("	<head>");
        sb.append("\n").append("		<title>기능성 변경심사</title>");
        sb.append("\n").append("		<meta content=\"text/html; charset=utf-8\" http-equiv=Content-Type>");
        sb.append("\n").append("		<meta name=GENERATOR content=ActiveSquare>");
        sb.append("\n").append("	</head>");
        sb.append("\n").append("	<body>");
        sb.append("\n").append("		<table cellSpacing=0 borderColorLight=black borderColorDark=white cellPadding=0 width=650 height=30>");
        sb.append("\n").append("			<tbody>");
        sb.append("\n").append("				<tr>");
        sb.append("\n").append("					<td width=565>");
        sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center><b><font style=\"FONT-FAMILY: 맑은 고딕\" size=4> 기능성 변경심사</font></b></p>");
        sb.append("\n").append("					</td>");
        sb.append("\n").append("					<td width=85>");
        sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\"><span style=\"FONT-FAMILY: 맑은 고딕\"></span></p>");
        sb.append("\n").append("					</td>");
        sb.append("\n").append("				</tr>");
        sb.append("\n").append("			</tbody>");
        sb.append("\n").append("		</table>");
        sb.append("\n").append("		<table border=1 cellSpacing=0 borderColorLight=black borderColorDark=white cellPadding=0 width=690>");
        sb.append("\n").append("			<tbody>");
        sb.append("\n").append("				<tr height=24>");
        sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=32 width=213>");
        sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
        sb.append("\n").append("							<b><span style=\" font-size: 10pt; FONT-FAMILY: 맑은 고딕;\">심 사 번 호</span></b>");
        sb.append("\n").append("						</p>");
        sb.append("\n").append("					</td>");
        sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; FONT-SIZE: 10pt; PADDING-TOP: 3px; COLOR: blue; FONT-FAMILY: 맑은 고딕;\" height=31 width=459 colSpan=4>");
        sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
        sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕;\">"+ (StringUtils.isNotEmpty(fvo.getVEvaluateNum()) ? fvo.getVEvaluateNum() : "") +"</span>");		//${fvo.i_sEvaluateNum}
        sb.append("\n").append("						</p>");
        sb.append("\n").append("					</td>");
        sb.append("\n").append("				</tr>");
        sb.append("\n").append("				<tr height=24>");
        sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=32 width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size: 10pt; FONT-FAMILY: 맑은 고딕;\">담 당 자</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=32 width=79>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕;\">제품 연구원</span>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=32 width=140>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕;\">"+ fvo.getVUserInfo() + "</span>");	//${fvo.v_user_info}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=32 width=89>");
		sb.append("\n").append("						<span style=\"FONT-FAMILY: 맑은 고딕;\">담당 PM</span>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=32 width=157>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕;\">"+ fvo.getVBrdUserInfo()+"</span>");	//${fvo.v_brd_user_info}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>   ");     
        sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr height=24>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=29 width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size:10pt; FONT-FAMILY: 맑은 고딕;\">주 성 분</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" id=p2 height=29 width=459 colSpan=4>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕;\">"+ fvo.getVFuncMateInfo() + "</span>");		//${fvo.v_func_mate_info}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>    ");   
		sb.append("\n").append("				<tr height=24>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=47 width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size:10pt; FONT-FAMILY: 맑은 고딕\">기 존 제 품 명</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=32 width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕\">"+ fvo.getVContNm() +"</span>");	//${fvo.v_cont_nm}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=47 width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size:10pt; FONT-FAMILY: 맑은 고딕\">변 경 제 품 명</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=32 width=213 colSpan=2>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕\">"+ (StringUtils.isNotEmpty(fvo.getVChangeProduct()) ? fvo.getVChangeProduct() : "") +"</span>");		//${fvo.v_change_product}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr height=24>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=47 width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size:10pt; FONT-FAMILY: 맑은 고딕\">기존내용물 코드</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=32 width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕\">"+ fvo.getVContCd() +"</span>");	//${fvo.v_cont_cd}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=47 width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size:10pt; FONT-FAMILY: 맑은 고딕\">변경내용물 코드</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=32 width=213 colSpan=2>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕\">"+ (StringUtils.isNotEmpty(fvo.getVChangeCd()) ? fvo.getVChangeCd() : "") +"</span>");		//${fvo.v_change_cd}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr height=24>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=24 width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size:10pt; FONT-FAMILY: 맑은 고딕;\">변경 사항</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" id=p2 height=25 width=459 colSpan=4>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕\">"+ (StringUtils.isNotEmpty(fvo.getVChangeNote()) ? fvo.getVChangeNote() : "")  +"</span>");		//${fvo.v_change_note}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>");
		sb.append("\n").append("				<tr height=24>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" height=26 width=213>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\" align=center>");
		sb.append("\n").append("							<b><span style=\"font-size:10pt; FONT-FAMILY: 맑은 고딕\">제조 사업장<br>(대전/오산/기타)</span></b>");
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("					<td style=\"PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; COLOR: blue; FONT-SIZE: 10pt; PADDING-TOP: 3px;FONT-FAMILY: 맑은 고딕;\" id=p2 height=26 width=459 colSpan=4>");
		sb.append("\n").append("						<p style=\"LINE-HEIGHT: 1.4; MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px\">");
		sb.append("\n").append("							<span style=\"FONT-FAMILY: 맑은 고딕\">"+ (StringUtils.isNotEmpty(fvo.getVMakePlace()) ? fvo.getVMakePlace() : "")  +"</span>");	//${fvo.v_make_place}
		sb.append("\n").append("						</p>");
		sb.append("\n").append("					</td>");
		sb.append("\n").append("				</tr>");
        sb.append("\n").append("			</tbody>");
        sb.append("\n").append("		</table>");
        sb.append("\n").append("	</body>");
        sb.append("\n").append("</html>");
        return sb.toString();
    }
    
}
