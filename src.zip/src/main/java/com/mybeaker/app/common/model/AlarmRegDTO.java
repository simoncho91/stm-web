package com.mybeaker.app.common.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class AlarmRegDTO extends ParentDTO {
	private String vLabNoteCd;

	private String vStatusCd;

	//private String vTimeStDt;

	//private String vSchdStDt;

	private List<String> typeList;

	private String vTypeCd;

	private String vAlrTypeCd;

	@Builder.Default
	private String vFlagAlarm = "N";

	@Builder.Default
	private String vFlagMail = "N";

	@Builder.Default
	private String vFlagAlarmDupl = "Y";

	@Builder.Default
	private String vFlagDupl = "Y";

	private String vMessage;

	private String vSchdMessage;

	private String vTimeMessage;

	private String vMoveUrl;

	private List<String> userList;

	private String vUserid;

	@JsonProperty("vMstCode")
	private String vMstCode;

	@JsonProperty("vSubCode")
	private String vSubCode;

	@JsonProperty("vContCd")
	private String vContCd;

	@JsonProperty("vContNm")
	private String vContNm;

	@JsonProperty("vUsernm")
	private String vUsernm;

	@JsonProperty("vTeamNm")
	private String vTeamNm;

	@JsonProperty("vFromUsernm")
	private String vFromUsernm;

	@JsonProperty("vFromTeamNm")
	private String vFromTeamNm;

	@JsonProperty("vToUsernm")
	private String vToUsernm;

	@JsonProperty("vToTeamNm")
	private String vToTeamNm;

	@JsonProperty("vExamNm")
	private String vExamNm;

	@JsonProperty("vLotNm")
	private String vLotNm;

	@JsonProperty("nVerNo")
	private String nVerNo;

	@JsonProperty("vFlagSchedule")
	private String vFlagSchedule;

	@JsonProperty("nSeqno")
	private String nSeqno;

	@JsonProperty("vNoteType")
	private String vNoteType;
}
