package com.mybeaker.app.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class GroupUserInfoDTO {

	@JsonProperty("vUserid")
	private String vUserid;
	
	@JsonProperty("vRefCdnm")
	private String vRefCdnm;
	
	@JsonProperty("vGroupid")
	private String vGroupid;
	
	@JsonProperty("nSeqno")
	private int nSeqno;
	
	@JsonProperty("vUsernm")
	private String vUsernm;
	
	@JsonProperty("vPositcd")
	private String vPositcd;
	
	@JsonProperty("vEmail")
	private String vEmail;
	
	@JsonProperty("vOffinm")
	private String vOffinm;
	
	@JsonProperty("vEduFinishCd")
	private String vEduFinishCd;
	
}
