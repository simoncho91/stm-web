package com.mybeaker.app.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class UploadTempDTO {
	@JsonProperty("nSeqno")
	private long nSeqno;

	@JsonProperty("vAttachnm")
	private String vAttachnm;

	@JsonProperty("vAttachExt")
	private String vAttachExt;

	@JsonProperty("nAttachSize")
	private long nAttachSize;

	@JsonProperty("vFileBytea")
	private byte[] vFileBytea;

	@JsonProperty("vRegUserid")
	private String vRegUserid;

	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;

	@JsonProperty("vNewYn")
	private String vNewYn;

	private String uploadCd;

	@JsonProperty("vUploadid")
	private String vUploadid;
}
