package com.mybeaker.app.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class DeptDTO {
	@JsonProperty("nLevel")
	private int nLevel;
	
	@JsonProperty("nLeafYn")
	private int nLeafYn;
	
	@JsonProperty("vSigmaDeptcd")
	private String vSigmaDeptcd;
	
	@JsonProperty("vSigmaUdeptcd")
	private String vSigmaUdeptcd;
	
	@JsonProperty("vSigmaDeptnm")
	private String vSigmaDeptnm;
}
