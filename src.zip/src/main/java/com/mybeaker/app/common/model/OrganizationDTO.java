package com.mybeaker.app.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class OrganizationDTO {
	@JsonProperty("vFlagRec")
	private String vFlagRec;
	
	@JsonProperty("vFlagRecNm")
	private String vFlagRecNm;
	
	@JsonProperty("vRefCd")
	private String vRefCd;
	
	@JsonProperty("vRefNm")
	private String vRefNm;
}
