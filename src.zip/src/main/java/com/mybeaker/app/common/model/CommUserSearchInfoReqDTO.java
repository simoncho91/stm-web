package com.mybeaker.app.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CommUserSearchInfoReqDTO {

	@JsonProperty("nNum")
	private int nNum;

	@JsonProperty("vUserid")
	private String vUserid;

	@JsonProperty("vEmpno")
	private String vEmpno;

	@JsonProperty("vUsernm")
	private String vUsernm;

	@JsonProperty("vUsernmEn")
	private String vUsernmEn;

	@JsonProperty("vPositcd")
	private String vPositcd;

	@JsonProperty("vPositnm")
	private String vPositnm;

	@JsonProperty("vDeptcd")
	private String vDeptcd;

	@JsonProperty("vDeptnm")
	private String vDeptnm;

	@JsonProperty("vOffinm")
	private String vOffinm;

	@JsonProperty("vSigmaDeptcd")
	private String vSigmaDeptcd;

	@JsonProperty("vSigmaUdeptcd")
	private String vSigmaUdeptcd;

	@JsonProperty("vPhoneno")
	private String vPhoneno;

	@JsonProperty("vEmail")
	private String vEmail;

	@JsonProperty("vDutynm")
	private String vDutynm;

	@JsonProperty("vRegUserid")
	private String vRegUserid;

	@JsonProperty("vRegDtm")
	private String vRegDtm;

	@JsonProperty("vUpdateUserid")
	private String vUpdateUserid;

	@JsonProperty("vUpdateDtm")
	private String vUpdateDtm;

	@JsonProperty("vSignImgPath")
	private String vSignImgPath;

	@JsonProperty("vCellSignImPath")
	private String vCellSignImPath;

	@JsonProperty("vLabor")
	private String vLabor;

}
