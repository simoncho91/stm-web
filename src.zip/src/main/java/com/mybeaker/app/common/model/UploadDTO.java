package com.mybeaker.app.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@NoArgsConstructor
public class UploadDTO extends ParentDTO {
	@JsonProperty("nSeqno")
	private long nSeqno;

	@JsonProperty("vRecordid")
	private String vRecordid;

	@JsonProperty("vUploadid")
	private String vUploadid;

	@JsonProperty("vAttachnm")
	private String vAttachnm;

	@JsonProperty("vAttachExt")
	private String vAttachExt;

	@JsonProperty("nAttachSize")
	private long nAttachSize;

	@JsonProperty("nDownloadCnt")
	private int nDownloadCnt;

	@JsonProperty("vAttachPath")
	private String vAttachPath;

	@JsonProperty("vSslPath")
	private String vSslPath;

	@JsonProperty("vKeyPath")
	private String vKeyPath;

	@JsonProperty("vBuffer1")
	private String vBuffer1;

	@JsonProperty("vBuffer2")
	private String vBuffer2;

	@JsonProperty("vBuffer3")
	private String vBuffer3;

	@JsonProperty("vAttachid")
	private String vAttachid;

	@JsonProperty("vFlagDel")
	private String vFlagDel;

	@JsonProperty("vAttType")
	private String vAttType;
	
	@JsonProperty("vS3Url")
	private String vS3Url;

	@Builder
	public UploadDTO(String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm, long nSeqno,
			String vRecordid, String vUploadid, String vAttachnm, String vAttachExt, long nAttachSize, int nDownloadCnt,
			String vAttachPath, String vSslPath, String vKeyPath, String vBuffer1, String vBuffer2, String vBuffer3,
			String vAttachid, String vFlagDel, String vAttType, String vS3Url) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.nSeqno = nSeqno;
		this.vRecordid = vRecordid;
		this.vUploadid = vUploadid;
		this.vAttachnm = vAttachnm;
		this.vAttachExt = vAttachExt;
		this.nAttachSize = nAttachSize;
		this.nDownloadCnt = nDownloadCnt;
		this.vAttachPath = vAttachPath;
		this.vSslPath = vSslPath;
		this.vKeyPath = vKeyPath;
		this.vBuffer1 = vBuffer1;
		this.vBuffer2 = vBuffer2;
		this.vBuffer3 = vBuffer3;
		this.vAttachid = vAttachid;
		this.vFlagDel = vFlagDel;
		this.vAttType = vAttType;
		this.vS3Url = vS3Url;
	}
}
