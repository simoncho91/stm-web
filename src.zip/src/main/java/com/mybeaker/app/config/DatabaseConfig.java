package com.mybeaker.app.config;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.type.JdbcType;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;

import com.mybeaker.app.utils.AES256Util;
import com.zaxxer.hikari.HikariDataSource;

import net.javacrumbs.shedlock.core.LockProvider;
import net.javacrumbs.shedlock.provider.jdbctemplate.JdbcTemplateLockProvider;

@Configuration
@MapperScan(value={"com.mybeaker.app.dbbase.mapper", "com.mybeaker.app.**.mapper"}, sqlSessionFactoryRef="mstSqlSessionFactory")
@EnableJpaRepositories(
	basePackages = "com.mybeaker.app.dbbase.repo",
	entityManagerFactoryRef = "primaryEntityManagerFactory",
	transactionManagerRef = "primaryTransactionManager"
)
public class DatabaseConfig {

	@Primary
	@Bean
	@ConfigurationProperties("spring.datasource")
	public DataSourceProperties primaryDataSourceProperties() {
		return new DataSourceProperties();
	}
	
	@Primary
	@Bean
	@ConfigurationProperties("spring.datasource.configuration")
	public DataSource primaryDataSource(
			@Qualifier("primaryDataSourceProperties") DataSourceProperties dataSourceProperties) throws Exception {
		AES256Util aes256Util = new AES256Util();
		String password = new String(aes256Util.decrypt((dataSourceProperties.getPassword())));
		dataSourceProperties.setPassword(password);
		return dataSourceProperties.initializeDataSourceBuilder().type(HikariDataSource.class).build();
	}
	
	@Primary
	@Bean
	public LocalContainerEntityManagerFactoryBean primaryEntityManagerFactory(EntityManagerFactoryBuilder builder,@Qualifier("primaryDataSource") DataSource dataSource) {
		return builder
					.dataSource(dataSource)
					.packages("com.mybeaker.app.dbbase.entity")
					.persistenceUnit("primaryEntityManager")
					.build();
	}
	
	@Primary
	@Bean
	public PlatformTransactionManager primaryTransactionManager(@Qualifier("primaryEntityManagerFactory") EntityManagerFactory entityManagerFactory) {
		return new JpaTransactionManager(entityManagerFactory);
	}
	
	@Bean(name = "mstSqlSessionFactory")
	@Primary
	public SqlSessionFactory mstSqlSessionFactory(
			@Qualifier("primaryDataSource") DataSource primaryDataSource,
			ApplicationContext applicationContext) throws Exception {
		SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();

		org.apache.ibatis.session.Configuration configuration = new org.apache.ibatis.session.Configuration();
		configuration.setMapUnderscoreToCamelCase(true);
		configuration.setJdbcTypeForNull(JdbcType.NULL);

		sqlSessionFactoryBean.setConfiguration(configuration);
		sqlSessionFactoryBean.setDataSource(primaryDataSource);
		sqlSessionFactoryBean.setTypeAliasesPackage("com.mybeaker.app.*.model");
		sqlSessionFactoryBean.setMapperLocations(applicationContext.getResources("classpath*:com/mybeaker/app/dbbase/mapper/*.xml"));
		sqlSessionFactoryBean.setMapperLocations(applicationContext.getResources("classpath*:mybatis/mapper/**/*.xml"));
		return sqlSessionFactoryBean.getObject();
	}

	@Bean(name = "mstSqlSessionTemplate")
	@Primary
	public SqlSessionTemplate mstSqlSessionTemplate(SqlSessionFactory mstSqlSessionFactory) throws Exception {
		return new SqlSessionTemplate(mstSqlSessionFactory);
	}
	
	@Bean
    public LockProvider lockProvider(@Qualifier("primaryDataSource") DataSource dataSource) {
        return new JdbcTemplateLockProvider(dataSource);
    }
}
