package com.mybeaker.app.config;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.mybeaker.app.Exception.CustomException;
import com.mybeaker.app.model.Const;
import com.mybeaker.app.model.enums.CommonResultCode;
import com.mybeaker.app.utils.JwtTokenUtil;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureException;
import io.jsonwebtoken.UnsupportedJwtException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@RequiredArgsConstructor
public class JwtAuthenticationFilter extends OncePerRequestFilter {

	@Value("${spring.jwt.headerKey}")
	private String jwtHeaderKey;

	private final JwtTokenUtil jwtTokenUtil;

	private final RequestMatcher apiRequests = new AntPathRequestMatcher("/api/**");
	private final RequestMatcher uploadRequests = new AntPathRequestMatcher("/upload/**");

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		// AntPathRequestMatcher 에 설정된 자원정보와 클라이언트의 요청정보(request)에 저장된 url 정보가 일치하는지 비교
		if (!apiRequests.matches(request) && !uploadRequests.matches(request)) {
			filterChain.doFilter(request, response);
			return;
		}

		StringBuffer sbLog = new StringBuffer();
		sbLog.append("\n").append("URI : ").append(request.getRequestURI());
		sbLog.append("\n").append("Method : ").append(request.getMethod());
		log.debug("{}", sbLog.toString());

		String requestTokenHeader = request.getHeader(jwtHeaderKey);
		String langCd = request.getHeader(Const.X_LANG_CD);

		if (StringUtils.isEmpty(langCd)) {
			langCd = "ko";
		}

		if (requestTokenHeader != null) {
			try {
				if(requestTokenHeader.startsWith(Const.BEARER)) {
					requestTokenHeader = requestTokenHeader.substring(7);
				}

				Claims claims = jwtTokenUtil.getAllClaimsFromToken(requestTokenHeader);

				Date expiration = jwtTokenUtil.getClaimFromToken(claims, Claims::getExpiration);

				if (expiration.after(new Date())) {
					// 모든 사용자가 그룹 권한을 가지고 있는 것은 아니기 때문에 주석 처리함
					/*
					List<String> list = Arrays.asList((String.valueOf(claims.get(Const.GROUPS)).split(","))).stream()
							.map(String::trim)
							.map(s -> s.replace("[","").replace("]", ""))
							.collect(Collectors.toList());
					Collection<? extends GrantedAuthority> authorities = list.stream()
							.map(SimpleGrantedAuthority::new)
							.collect(Collectors.toList());
					*/
					Collection<? extends GrantedAuthority> authorities = List.of(new SimpleGrantedAuthority("USER"));
					UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken =
							new UsernamePasswordAuthenticationToken(claims.getSubject(), null, authorities);

					usernamePasswordAuthenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
					SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);

					List<String> inclusionURI = Arrays.asList("/api/skincare", "/api/makeup", "/api/hbd", "/api/qdrug");
					String apiUrl = String.valueOf(claims.get("apiUrl"));

					for (String uri : inclusionURI) {
						if (request.getRequestURI().indexOf(uri) > -1) {
							if (apiUrl.indexOf(uri) == -1) {
								throw new CustomException(CommonResultCode.NO_AUTH);
							}
							break;
						}
					}

				}
			} catch (IllegalArgumentException e) {
				log.info("Unable to get JWT Token - {}", e.getMessage());
			} catch (ExpiredJwtException e) {
				log.info("JWT Token has expired - {}", e.getMessage());
			} catch (UnsupportedJwtException e) {
				log.info("Unsupported JWT Token - {}", e.getMessage());
			} catch (SignatureException | MalformedJwtException e) {
				log.info("Invalid JWT Token - {}", e.getMessage());
			}
		}

		filterChain.doFilter(request, response);
	}
}
