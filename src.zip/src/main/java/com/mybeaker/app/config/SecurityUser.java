package com.mybeaker.app.config;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;

import com.mybeaker.app.model.vo.SessionVO;

import lombok.Getter;

@Getter
public class SecurityUser extends User {
	private static final long serialVersionUID = 1L;
	
	private static final String ROLE_PREFIX = "ROLE_";
	
	private SessionVO sessionVO;
	
	public SecurityUser(SessionVO sessionVO) {
		super(sessionVO.getUserCd(), sessionVO.getLoginPw(), makeGrantedAuthority(Arrays.asList("USER")));
		
		this.sessionVO = sessionVO;
	}
	
	private static List<GrantedAuthority> makeGrantedAuthority(List<String> roles) {
		List<GrantedAuthority> list = new ArrayList<>();
		roles.forEach(role -> list.add(new SimpleGrantedAuthority(ROLE_PREFIX + role)));
		return list;
	}
}
