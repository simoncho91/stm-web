package com.mybeaker.app.config;

import org.springdoc.core.GroupedOpenApi;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.mybeaker.app.model.Const;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.servers.Server;

@Configuration
public class SwaggerConfig {

	@Value("${bkr.web.url}")
	private String BKR_WEB_URL;
	
	@Value("${spring.profiles.active}")
	private String ACTIVE;
	
	@Bean
	public GroupedOpenApi publicApi() {
		return GroupedOpenApi.builder()
				.group("MyBeaker API")
				.pathsToMatch("/api/**")
				.build();
	}
	
	@Bean
	public OpenAPI springSOpenAPI() {
		String jwtSchemeName = "Bearer Authentication";
		SecurityRequirement securityRequirement = new SecurityRequirement()
				.addList(jwtSchemeName);
		Components components = new Components()
				.addSecuritySchemes(jwtSchemeName, new SecurityScheme()
						.name(jwtSchemeName)
						.type(SecurityScheme.Type.HTTP)
						.scheme("bearer")
						.bearerFormat("JWT"));
		
		return new OpenAPI()
				.addServersItem(new Server()
						.url(Const.ACTIVE_LOCAL.equals(ACTIVE) ? "http://localhost:9080" : BKR_WEB_URL))
				.info(new Info()
						.title("MyBeaker API")
						.description("아모레퍼시픽 MyBeaker API 명세서 입니다.")
						.version("v1"))
				.addSecurityItem(securityRequirement)
				.components(components);
	}
}
