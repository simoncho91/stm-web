package com.mybeaker.app.batch.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.mybeaker.app.batch.model.batchLogDTO;

@Mapper
public interface BatchMapper {
    
    public int selectExecBatchCount(batchLogDTO params);

    public void deleteBatchLog(batchLogDTO params);
    
    public void insertBatchLog(batchLogDTO params);

    public int updateBatchLog(batchLogDTO params);
}
