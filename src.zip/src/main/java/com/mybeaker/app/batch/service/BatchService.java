package com.mybeaker.app.batch.service;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.mybeaker.app.batch.mapper.BatchMapper;
import com.mybeaker.app.batch.model.batchLogDTO;
import com.mybeaker.app.common.service.CommonService;
import com.mybeaker.app.hbd.service.HbdCommonService;
import com.mybeaker.app.labnote.model.BatchStatusProcessVO;
import com.mybeaker.app.labnote.model.LotStatusRegDTO;
import com.mybeaker.app.labnote.model.SapBiodRsltPerDTO;
import com.mybeaker.app.labnote.service.LabNoteCommonService;
import com.mybeaker.app.makeup.service.MakeupCommonService;
import com.mybeaker.app.model.Const;
import com.mybeaker.app.qdrug.service.QdrugCommonService;
import com.mybeaker.app.skincare.service.SkincareCommonService;
import com.mybeaker.app.user.service.UserService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class BatchService {

	private final BatchMapper batchMapper;

	private final UserService userService;

	private final CommonService commonService;

	private final LabNoteCommonService labNoteCommonService;

	private final SkincareCommonService skincareCommonService;

	private final MakeupCommonService makeupCommonService;

	private final HbdCommonService hbdCommonService;

	private final QdrugCommonService qdrugCommonService;

	public int selectExecBatchCount(batchLogDTO dto) {
		return batchMapper.selectExecBatchCount(dto);
	}

	@Transactional
	public void deleteBatchLog(batchLogDTO dto) {
		batchMapper.deleteBatchLog(dto);
	}
	
	@Transactional
	public void insertBatchLog(batchLogDTO dto) {
		batchMapper.insertBatchLog(dto);
	}

	@Transactional
	public int updateBatchLog(batchLogDTO dto) {
		return batchMapper.updateBatchLog(dto);
	}

	/**
	 * 배치 로그 기록 및 실행여부 체크
	 * @param dto
	 * @param typeCd
	 * @param period
	 * @return
	 */
	@Transactional
	private int beforeBatchLog(batchLogDTO dto, String typeCd, String period) {
		dto.setTypeCd(typeCd);
		dto.setPeriod(period);
		dto.setFlag("Y");

		int execCount = this.selectExecBatchCount(dto);

		this.insertBatchLog(dto);
		return execCount;
	}

	/**
	 * 배치 로그 종료 기록
	 * @param dto
	 * @param flag
	 * @param content
	 */
	@Transactional
	private void afterBatchLog(batchLogDTO dto, String flag, String content) {
		dto.setFlag(flag);
		if (content != null) {
			dto.setContent(content);
		}

		this.updateBatchLog(dto);
	}

	@Transactional
	public void executeExpiredTokenDelete() {
		int execCount = 0;
		batchLogDTO params = new batchLogDTO();

		try {
			execCount = beforeBatchLog(params, "BATCH_TOKEN_DELETE", "D");

			if (execCount == 0) {
				userService.executeExpiredTokenDelete();

				afterBatchLog(params, "S", "BATCH_TOKEN_DELETE => SUCC");
			} else {
				afterBatchLog(params, "E", "지정된 횟수 초과 실행");
			}
		} catch (Exception e) {
			afterBatchLog(params, "E", e.getMessage().toString());
			log.error("Error : ", e);
		} finally {
			params = null;
		}
	}

	@Transactional
	public void executeStockProcess(String forceExecuteFlag) {
		int execCount = 0;
		batchLogDTO params = new batchLogDTO();

		try {
			if ("Y".equals(forceExecuteFlag)) {
				this.deleteBatchLog(batchLogDTO.builder()
						.typeCd("BATCH_STOCK_PROCESS")
						.period("D")
						.build());
			}
			
			execCount = beforeBatchLog(params, "BATCH_STOCK_PROCESS", "D");

			if (execCount == 0) {
				List<BatchStatusProcessVO> targetList = labNoteCommonService.selectStockProcessTargetList();

				if (!ObjectUtils.isEmpty(targetList)) {
					Map<String, List<BatchStatusProcessVO>> noteTypeMap = targetList.stream().collect(Collectors.groupingBy(BatchStatusProcessVO::getVNoteType));

					Iterator<String> keys = noteTypeMap.keySet().iterator();
					while (keys.hasNext()) {
						String key = keys.next();

						List<BatchStatusProcessVO> list = noteTypeMap.get(key);

						if (!ObjectUtils.isEmpty(list)) {
							// 3 - 1. SC, SA -> 단일 내용물 처리 : XX_NOTE_MST.V_STATUS_CD = 'LNC06_51' 로 업데이트
							if ("SC".equals(key) ) {
								skincareCommonService.updateNoteContStockDt(list);
								skincareCommonService.updateDevelopmentCompletedStatus(list.stream().map(BatchStatusProcessVO::getVLabNoteCd).collect(Collectors.toList()));
								List<BatchStatusProcessVO> alarmList = skincareCommonService.selectBatchAlarmInfoList(list);

								if (!ObjectUtils.isEmpty(alarmList)) {
									labNoteCommonService.sendCompleteAlarm(alarmList, "STOCK", "skincare", "SC");

									for (BatchStatusProcessVO note : alarmList) {
										commonService.insertLotStatusHistory(LotStatusRegDTO.builder()
																				.vLabNoteCd(note.getVLabNoteCd())
																				.nVersion(note.getNVersion())
																				.vContPkCd(note.getVContPkCd())
																				.vLotCd(note.getVLotCd())
																				.vLabStatusCd(Const.LOT_05)
																				.vFlagBatch("Y")
																				.build());
									}
								}
							} else if ("SA".equals(key) ) {
								qdrugCommonService.updateNoteContStockDt(list);
								qdrugCommonService.updateDevelopmentCompletedStatus(list.stream().map(BatchStatusProcessVO::getVLabNoteCd).collect(Collectors.toList()));
								List<BatchStatusProcessVO> alarmList = qdrugCommonService.selectBatchAlarmInfoList(list);
								if (!ObjectUtils.isEmpty(alarmList)) {
									labNoteCommonService.sendCompleteAlarm(alarmList, "STOCK", "qdrug", "SA");

									for (BatchStatusProcessVO note : alarmList) {
										commonService.insertLotStatusHistory(LotStatusRegDTO.builder()
																				.vLabNoteCd(note.getVLabNoteCd())
																				.nVersion(note.getNVersion())
																				.vContPkCd(note.getVContPkCd())
																				.vLotCd(note.getVLotCd())
																				.vLabStatusCd(Const.LOT_05)
																				.vFlagBatch("Y")
																				.build());
									}
								}
							}
							// 3 - 2. MU, HBD -> 멀티 내용물 처리
							// 내용물 모두 입고 처리가 완료되어야 XX_NOTE_MST.V_STATUS_CD = 'LNC06_51' 로 업데이트
							else if ("MU".equals(key) ) {
								makeupCommonService.updateNoteContStockDt(list);

								List<String> allCompleteList = makeupCommonService.selectStockAllCompleteList(list);

								if (!ObjectUtils.isEmpty(allCompleteList)) {
									makeupCommonService.updateDevelopmentCompletedStatus(allCompleteList);
									List<BatchStatusProcessVO> alarmTargetList = list.stream().filter(note -> allCompleteList.contains(note.getVLabNoteCd())).collect(Collectors.toList());
									if (!ObjectUtils.isEmpty(alarmTargetList)) {
										List<BatchStatusProcessVO> alarmList = makeupCommonService.selectBatchAlarmInfoList(alarmTargetList);
										labNoteCommonService.sendCompleteAlarm(alarmList, "STOCK", "makeup", "MU");
										for (BatchStatusProcessVO note : alarmList) {
											commonService.insertLotStatusHistory(LotStatusRegDTO.builder()
																					.vLabNoteCd(note.getVLabNoteCd())
																					.nVersion(note.getNVersion())
																					.vContPkCd(note.getVContPkCd())
																					.vLotCd(note.getVLotCd())
																					.vLabStatusCd(Const.LOT_05)
																					.vFlagBatch("Y")
																					.build());
										}
									}
								}
							}
							else if ("HBO".equals(key) ) {
								hbdCommonService.updateNoteContStockDt(list);

								List<String> allCompleteList = hbdCommonService.selectStockAllCompleteList(list);

								if (!ObjectUtils.isEmpty(allCompleteList)) {
									hbdCommonService.updateDevelopmentCompletedStatus(allCompleteList);
									List<BatchStatusProcessVO> alarmTargetList = list.stream().filter(note -> allCompleteList.contains(note.getVLabNoteCd())).collect(Collectors.toList());
									if (!ObjectUtils.isEmpty(alarmTargetList)) {
										List<BatchStatusProcessVO> alarmList = hbdCommonService.selectBatchAlarmInfoList(alarmTargetList);
										labNoteCommonService.sendCompleteAlarm(alarmList, "STOCK", "hbd", "HBO");
										for (BatchStatusProcessVO note : alarmList) {
											commonService.insertLotStatusHistory(LotStatusRegDTO.builder()
																					.vLabNoteCd(note.getVLabNoteCd())
																					.nVersion(note.getNVersion())
																					.vContPkCd(note.getVContPkCd())
																					.vLotCd(note.getVLotCd())
																					.vLabStatusCd(Const.LOT_05)
																					.vFlagBatch("Y")
																					.build());
										}
									}
								}
							}
						}
					}
				}

				afterBatchLog(params, "S", "BATCH_STOCK_PROCESS => SUCC");
			} else {
				afterBatchLog(params, "E", "지정된 횟수 초과 실행");
			}
		} catch (Exception e) {
			afterBatchLog(params, "E", e.getMessage().toString());
			log.error("Error : ", e);
		} finally {
			params = null;
		}
	}

	@Transactional
	public void executeReleaseProcess(String forceExecuteFlag) {
		int execCount = 0;
		batchLogDTO params = new batchLogDTO();

		try {
			if ("Y".equals(forceExecuteFlag)) {
				this.deleteBatchLog(batchLogDTO.builder()
						.typeCd("BATCH_RELEASE_PROCESS")
						.period("D")
						.build());
			}
			
			execCount = beforeBatchLog(params, "BATCH_RELEASE_PROCESS", "D");

			if (execCount == 0) {
				List<BatchStatusProcessVO> targetList = labNoteCommonService.selectReleaseProcessTargetList();

				if (!ObjectUtils.isEmpty(targetList)) {
					Map<String, List<BatchStatusProcessVO>> noteTypeMap = targetList.stream().collect(Collectors.groupingBy(BatchStatusProcessVO::getVNoteType));

					Iterator<String> keys = noteTypeMap.keySet().iterator();
					while (keys.hasNext()) {
						String key = keys.next();

						List<BatchStatusProcessVO> list = noteTypeMap.get(key);

						if ("SC".equals(key) && !ObjectUtils.isEmpty(list)) {
							skincareCommonService.saveNoteReleaseInfo(list);
						} else if ("SA".equals(key) && !ObjectUtils.isEmpty(list)) {
							qdrugCommonService.saveNoteReleaseInfo(list);
						} else if ("MU".equals(key) && !ObjectUtils.isEmpty(list)) {
							makeupCommonService.saveNoteReleaseInfo(list);
						} else if ("HBO".equals(key) && !ObjectUtils.isEmpty(list)) {
							hbdCommonService.saveNoteReleaseInfo(list);
						}
					}
				}
				
				afterBatchLog(params, "S", "BATCH_RELEASE_PROCESS => SUCC");
			} else {
				afterBatchLog(params, "E", "지정된 횟수 초과 실행");
			}
		} catch (Exception e) {
			afterBatchLog(params, "E", e.getMessage().toString());
			log.error("Error : ", e);
		} finally {
			params = null;
		}
	}

	@Transactional
	public void executeBiodRsltValUpdate() {
		int execCount = 0;
		batchLogDTO params = new batchLogDTO();

		try {
			execCount = beforeBatchLog(params, "BATCH_BIO_RSLT_UPT", "D");

			if (execCount == 0) {
				List<SapBiodRsltPerDTO> targetList = labNoteCommonService.selectBiodRsltValueUpdateList();

				if (!ObjectUtils.isEmpty(targetList)) {
					for(SapBiodRsltPerDTO bioVo : targetList) {
						labNoteCommonService.updateSapBiodRsltValue(bioVo);
					}
					
					afterBatchLog(params, "S", "BATCH_BIO_RSLT_UPT => SUCC");
				}
				
			} else {
				afterBatchLog(params, "E", "지정된 횟수 초과 실행");
			}
		} catch (Exception e) {
			afterBatchLog(params, "E", e.getMessage().toString());
			log.error("Error : ", e);
		} finally {
			params = null;
		}
	}
}