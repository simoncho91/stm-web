package com.mybeaker.app.batch;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.mybeaker.app.batch.service.BatchService;

import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;

@Component
@Profile("!local")
public class Scheduler {

    @Autowired
    protected BatchService batchService;

    /*******************************************************************************
     * 배치 목록
     *
     * ---- 매일
     * 기간 만료 Token 삭제
     * >> 매일 오전 03시 00분 (03:00 AM)
     * 
     * 생분해도 데이터 업데이트 처리
     * >> 매일 오전 03시 30분 (03:30 AM)
     * 
     * 입고 처리
     * >> 매일 오전 04시 00분 (04:00 AM)
     * 
     * 출시완료
     * >> 매일 오전 04시 30분 (04:30 AM)
     *******************************************************************************/

    /*******************************************************************************
     * 매일
     *******************************************************************************/

    /**
     * 기간 만료 Token 삭제
     * 호출 주기: 매일 오전 03시 00분
     */
    @Scheduled(cron = "00 00 03 * * ?")
    @SchedulerLock(name = "executeExpiredTokenDelete", lockAtLeastFor = "10m", lockAtMostFor = "10m")
    public void executeExpiredTokenDelete() {
    	batchService.executeExpiredTokenDelete();
    }

    /**
     * 입고 처리
     * 호출 주기: 매일 오전 04시 00분
     */
    @Scheduled(cron = "00 00 04 * * ?")
    @SchedulerLock(name = "executeStockProcess", lockAtLeastFor = "10m", lockAtMostFor = "10m")
    public void executeStockProcess() {
    	batchService.executeStockProcess("N");
    }

    /**
     * 출시완료 처리
     * 호출 주기: 매일 오전 04시 30분
     */
    @Scheduled(cron = "00 30 04 * * ?")
    @SchedulerLock(name = "executeReleaseProcess", lockAtLeastFor = "10m", lockAtMostFor = "10m")
    public void executeReleaseProcess() {
    	batchService.executeReleaseProcess("N");
    }
    
    /**
     * 생분해도 데이터 업데이트 처리
     * 호출 주기: 매일 오전 03시 30분
     */
	@Scheduled(cron = "00 30 03 * * ?")
    @SchedulerLock(name = "executeBiodRsltValUpdate", lockAtLeastFor = "10m", lockAtMostFor = "10m")
    public void executeBiodRsltValUpdate() {
    	batchService.executeBiodRsltValUpdate();
    }
}
