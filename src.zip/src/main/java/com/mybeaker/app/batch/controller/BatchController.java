package com.mybeaker.app.batch.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mybeaker.app.model.Const;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.batch.service.BatchService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Tag(name = "배치 임의 실행", description="배치 임의 실행")
@RestController
@RequestMapping("api/batch")
@RequiredArgsConstructor
public class BatchController {
	private final BatchService batchService;

	@Operation(summary = "입고 처리", description = "입고 처리")
	@GetMapping("/execute-stock-process")
	public @ResponseBody ResponseEntity<ResponseVO> executeStockProcess() {
		ResponseVO responseVO = new ResponseVO();
		
		log.debug("BatchController.executeStockProcess");

		batchService.executeStockProcess("Y");
		
		responseVO.setOk(Const.SUCC);
		return ResponseEntity.ok(responseVO);
	}
	
	@Operation(summary = "출시완료 처리", description = "출시완료 처리")
	@GetMapping("/execute-release-process")
	public @ResponseBody ResponseEntity<ResponseVO> executeReleaseProcess() {
		ResponseVO responseVO = new ResponseVO();
		
		log.debug("BatchController.executeReleaseProcess");
		
		batchService.executeReleaseProcess("Y");
		
		responseVO.setOk(Const.SUCC);
		return ResponseEntity.ok(responseVO);
	}
}
