package com.mybeaker.app.batch.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class batchLogDTO {
	
    private String batchCd;
    
    private String typeCd;
    
    private String flag;

    private String period;
    
    private String stDtm;
    
    private String enDtm;
    
    private String content;

    private String buffer1;

    private String buffer2;
    
    private String buffer3;
}
