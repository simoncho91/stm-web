package com.mybeaker.app.authority.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class AuthSecuritySaveReqDTO {
	
	@JsonProperty("vFlagAuth")
	private String	 vFlagAuth;
	
	@JsonProperty("vAuthcd")
	private String	 vAuthcd;
	
	@JsonProperty("vFunccd")
	private String	 vFunccd;
	
	@JsonProperty("vRegUserid")
	private String	 vRegUserid;
	
}
