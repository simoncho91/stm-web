package com.mybeaker.app.authority.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class AuthSecurityPopReqDTO {
	
	@JsonProperty("vFlagRec")
	private String	 vFlagRec;
	
	@JsonProperty("vRecordid")
	private String	 vRecordid;
	
	@JsonProperty("vFlagOnlyFile")
	private String	 vFlagOnlyFile;
	
	@JsonProperty("vFlagAttachAuth")
	private String	 vFlagAttachAuth;
	
	private String	 localLanguage;
	
	@JsonProperty("authList")
	List<AuthSecuritySaveReqDTO> authList;
	
	@JsonProperty("vIncLowdept")
	private String vIncLowdept;
	
	@JsonProperty("arrDeptcd")
	private String [] arrDeptcd;
	
	private String vFlagAuth;
	
	private String vAuthcd;
	
	private String vFunccd;
	
	private String vRegUserid;
	
}
