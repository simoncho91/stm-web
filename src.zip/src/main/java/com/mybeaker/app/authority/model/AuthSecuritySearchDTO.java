package com.mybeaker.app.authority.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class AuthSecuritySearchDTO {
	
	@JsonProperty("vKeyword")
	private String	 vKeyword;
	
	@JsonProperty("vFlagRec")
	private String	 vFlagRec;
	
	private String	 localLanguage;
	
}
