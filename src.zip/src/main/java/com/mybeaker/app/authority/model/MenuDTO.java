package com.mybeaker.app.authority.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class MenuDTO {
	@JsonProperty("nLevel")
	private int nLevel;

	@JsonProperty("nLeafYn")
	private int nLeafYn;

	@JsonProperty("vMenuid")
	private String vMenuid;

	@JsonProperty("vUmenuid")
	private String vUmenuid;

	@JsonProperty("vMenunm")
	private String vMenunm;

	@JsonProperty("vPageid")
	private String vPageid;

	@JsonProperty("vRouter")
	private String vRouter;

	@JsonProperty("vFlagLink")
	private String vFlagLink;

	@JsonProperty("vPagenm")
	private String vPagenm;

	@JsonProperty("vPageUrl")
	private String vPageUrl;

	@JsonProperty("vCssnm")
	private String vCssnm;

	@JsonProperty("vApiUrl")
	private String vApiUrl;

	@JsonProperty("vLeftMenuYn")
	private String vLeftMenuYn;

	@JsonProperty("vDetailCssnm")
	private String vDetailCssnm;

	@JsonProperty("nDetailSeqno")
	private int nDetailSeqno;

	private List<MenuDTO> subList;
}
