package com.mybeaker.app.authority.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class AuthSecurityPopResDTO {
	
	@JsonProperty("vFlagRec")
	private String	 vFlagRec;
	
	@JsonProperty("vRecordid")
	private String	 vRecordid;
	
	@JsonProperty("vFlagAuth")
	private String	 vFlagAuth;
	
	@JsonProperty("vAuthcd")
	private String vAuthcd;
	
	@JsonProperty("vAuthnm")
	private String vAuthnm;
	
	@JsonProperty("vFlagRecNm")
	private String vFlagRecNm;
	
	@JsonProperty("vRefCd")
	private String vRefCd;
	
	@JsonProperty("vRefNm")
	private String vRefNm;
	
	@JsonProperty("vFlagOriRec")
	private String vFlagOriRec;
	
	@JsonProperty("vFunccd")
	private String vFunccd;
	
	@JsonProperty("vKey")
	private String vKey;
	
	@JsonProperty("vFlagAttach")
	private String vFlagAttach;
}
