package com.mybeaker.app.authority.mapper;

import java.util.List;

import javax.validation.Valid;

import org.apache.ibatis.annotations.Mapper;

import com.mybeaker.app.authority.model.AuthSecurityPopReqDTO;
import com.mybeaker.app.authority.model.AuthSecurityPopResDTO;
import com.mybeaker.app.authority.model.AuthSecurityResDTO;
import com.mybeaker.app.authority.model.AuthSecuritySearchDTO;
import com.mybeaker.app.authority.model.MenuDTO;

@Mapper
public interface AuthorityMapper {

	List<MenuDTO> selectMenuLevelList(String vLoginId, String vSigmaDeptcd, List<String> groups);

	List<MenuDTO> selectPageList(String vLoginId, String vSigmaDeptcd, List<String> groups);

	String selectApiUrlInfo(String vLoginId, String vSigmaDeptcd, List<String> groups);

	AuthSecurityResDTO selectCmAuthGopTypeRegYn(String vRecordid, String vFlagRec);

	AuthSecurityResDTO selectCmAuthGrpTypeRegYn(String vRecordid, String vFlagRec);

	AuthSecurityResDTO selectCmAuthBkrTypeRegYn(String vRecordid, String vFlagRec);

	AuthSecurityResDTO selectCmAuthTypeRegYn(String vRecordid, String vFlagRec);

	List<AuthSecurityPopResDTO> selectDeptUsrGrpAllList(AuthSecuritySearchDTO searchDTO);

	List<AuthSecurityPopResDTO> selectCmAuthList(AuthSecurityPopReqDTO reqDTO);

	void deleteAuthAll(@Valid AuthSecurityPopReqDTO reqDTO);

	void insertAuth(@Valid AuthSecurityPopReqDTO reqDTO);

	void insertAuthLowDept(@Valid AuthSecurityPopReqDTO reqDTO);

}
