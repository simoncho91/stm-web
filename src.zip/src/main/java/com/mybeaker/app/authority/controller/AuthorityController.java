package com.mybeaker.app.authority.controller;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mybeaker.app.authority.model.AuthSecurityPopReqDTO;
import com.mybeaker.app.authority.model.AuthSecurityReqDTO;
import com.mybeaker.app.authority.model.AuthSecuritySearchDTO;
import com.mybeaker.app.authority.service.AuthorityService;
import com.mybeaker.app.model.vo.ResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/authority")
@RequiredArgsConstructor
public class AuthorityController {
	private final AuthorityService authorityService;
	
	@GetMapping("/select-router-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectRouterList () {
		ResponseVO responseVO = new ResponseVO();
		
		responseVO.setOk(authorityService.selectRouterList());
		
		return ResponseEntity.ok(responseVO);
	}
	
	@GetMapping("/select-cm-auth-type-regYn")
	public @ResponseBody ResponseEntity<ResponseVO> selectCmAuthTypeRegYn (AuthSecurityReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();
		
		responseVO.setOk(authorityService.selectCmAuthTypeRegYn(reqDTO));
		
		return ResponseEntity.ok(responseVO);
	}
	
	@GetMapping("/select-dept-usr-grp-all-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectDeptUsrGrpAllList (AuthSecuritySearchDTO searchDTO) {
		ResponseVO responseVO = new ResponseVO();
		
		responseVO.setOk(authorityService.selectDeptUsrGrpAllList(searchDTO));
		
		return ResponseEntity.ok(responseVO);
	}
	
	@GetMapping("/select-cm-auth-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectCmAuthList (AuthSecurityPopReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();
		
		responseVO.setOk(authorityService.selectCmAuthList(reqDTO));
		
		return ResponseEntity.ok(responseVO);
	}
	
	@Operation(summary = "보안확정 권한 저장하기", description = "보안확정 권한 저장하기")
	@PostMapping("/save-cm-auth-list")
	public @ResponseBody ResponseEntity<ResponseVO> saveCmAuthList (@RequestBody @Valid AuthSecurityPopReqDTO reqDTO) {

		log.debug("AuthorityController.saveCmAuthList => AuthSecurityPopReqDTO : {}", reqDTO);
		return ResponseEntity.ok(authorityService.saveCmAuthList(reqDTO));
	}
}
