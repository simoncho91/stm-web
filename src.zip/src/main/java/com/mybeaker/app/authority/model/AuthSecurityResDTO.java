package com.mybeaker.app.authority.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class AuthSecurityResDTO {
	
	@JsonProperty("nFlag010Cnt")
	private int	nFlag010Cnt;
	
	@JsonProperty("nFlag020Cnt")
	private int	nFlag020Cnt;
	
	@JsonProperty("nFlag030Cnt")
	private int	nFlag030Cnt;
	
}
