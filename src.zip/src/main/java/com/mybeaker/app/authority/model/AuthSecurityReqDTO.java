package com.mybeaker.app.authority.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class AuthSecurityReqDTO {
	
	@JsonProperty("vFlagRec")
	private String	 vFlagRec;
	
	@JsonProperty("vRecordid")
	private String	 vRecordid;
	
	@JsonProperty("vScriptYn")
	private String	 vScriptYn;
	
	@JsonProperty("vCallFunction")
	private String	 vCallFunction;
	
	@JsonProperty("vChkboxHide")
	private String vChkboxHide;
	
	@JsonProperty("vFalgAttachAuth")
	private String vFalgAttachAuth;
	
	@JsonProperty("vFlagGopYn")
	private String vFlagGopYn;
	
	@JsonProperty("vFlagGrpYn")
	private String vFlagGrpYn;
	
	@JsonProperty("vFlagBkrYn")
	private String vFlagBkrYn;
	
}
