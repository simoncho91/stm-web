package com.mybeaker.app.authority.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mybeaker.app.authority.mapper.AuthorityMapper;
import com.mybeaker.app.authority.model.AuthSecurityPopReqDTO;
import com.mybeaker.app.authority.model.AuthSecurityPopResDTO;
import com.mybeaker.app.authority.model.AuthSecurityReqDTO;
import com.mybeaker.app.authority.model.AuthSecurityResDTO;
import com.mybeaker.app.authority.model.AuthSecuritySaveReqDTO;
import com.mybeaker.app.authority.model.AuthSecuritySearchDTO;
import com.mybeaker.app.authority.model.MenuDTO;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.utils.SessionUtil;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AuthorityService {
	private final SessionUtil sessionUtil;

	private final AuthorityMapper authorityMapper;

	public List<MenuDTO> selectRouterList() {
		List<MenuDTO> menuList = authorityMapper.selectMenuLevelList(sessionUtil.getLoginId(), sessionUtil.getSigmaDeptcd(), sessionUtil.getGroups());
		Map<String, List<MenuDTO>> routerMap;
		List<MenuDTO> pageList = authorityMapper.selectPageList(sessionUtil.getLoginId(), sessionUtil.getSigmaDeptcd(), sessionUtil.getGroups());

		if (pageList != null) {
			routerMap = pageList.stream().collect(Collectors.groupingBy(MenuDTO::getVMenuid));
		} else {
			routerMap = new HashMap<>();
		}

		menuList.forEach(obj -> {
			obj.setSubList(routerMap.get(obj.getVMenuid()));
		});

		return menuList;
	}

	public List<MenuDTO> selectMenuLevelList(String loginId, String sigmaDeptcd, List<String> groups) {
		if (StringUtils.isEmpty(loginId)) {
			loginId = sessionUtil.getLoginId();
		}
		
		if (StringUtils.isEmpty(sigmaDeptcd)) {
			sigmaDeptcd = sessionUtil.getSigmaDeptcd();
		}
		
		List<MenuDTO> pageList = authorityMapper.selectMenuLevelList(loginId, sigmaDeptcd, groups);
		List<MenuDTO> returnList = null;

		if (pageList != null && !pageList.isEmpty()) {
			returnList = pageList.stream().filter(dto -> dto.getNLevel() == 2).collect(Collectors.toList());
		}
		return returnList;
	}

	public String selectApiUrlInfo(String loginId, String sigmaDeptcd, List<String> groups) {
		return authorityMapper.selectApiUrlInfo(loginId, sigmaDeptcd, groups);
	}

	public AuthSecurityResDTO selectCmAuthTypeRegYn(AuthSecurityReqDTO reqDTO) {
		AuthSecurityResDTO resDTO = null;
		
		if(StringUtils.isNotEmpty(reqDTO.getVFlagGopYn()) && "Y".equals(reqDTO.getVFlagGopYn())) {
			resDTO = authorityMapper.selectCmAuthGopTypeRegYn(reqDTO.getVRecordid(), reqDTO.getVFlagRec());
		}
		else if(StringUtils.isNotEmpty(reqDTO.getVFlagGrpYn()) && "Y".equals(reqDTO.getVFlagGrpYn())) {
			resDTO = authorityMapper.selectCmAuthGrpTypeRegYn(reqDTO.getVRecordid(), reqDTO.getVFlagRec());
		}
		else if(StringUtils.isNotEmpty(reqDTO.getVFlagBkrYn()) && "Y".equals(reqDTO.getVFlagBkrYn())) {
			resDTO = authorityMapper.selectCmAuthBkrTypeRegYn(reqDTO.getVRecordid(), reqDTO.getVFlagRec());
		}
		else {
			resDTO = authorityMapper.selectCmAuthTypeRegYn(reqDTO.getVRecordid(), reqDTO.getVFlagRec());
		}
		
		return resDTO;
	}

	public List<AuthSecurityPopResDTO> selectDeptUsrGrpAllList(AuthSecuritySearchDTO searchDTO) {
		return authorityMapper.selectDeptUsrGrpAllList(searchDTO);
	}

	public List<AuthSecurityPopResDTO> selectCmAuthList(AuthSecurityPopReqDTO reqDTO) {
		return authorityMapper.selectCmAuthList(reqDTO);
	}

	public ResponseVO saveCmAuthList(@Valid AuthSecurityPopReqDTO reqDTO) {
		ResponseVO responseVO = new ResponseVO();
		authorityMapper.deleteAuthAll(reqDTO);
		
		if(StringUtils.isEmpty(reqDTO.getVRecordid()) || StringUtils.isEmpty(reqDTO.getVFlagRec())) {
			responseVO.setOkWithCode("C9999", "필수 인자값이 없습니다", null);
		}
		
		String Deptcd_flag010 = "";
		int size = reqDTO.getAuthList() == null ? 0 : reqDTO.getAuthList().size();
		if(size > 0) {
			for(AuthSecuritySaveReqDTO vo : reqDTO.getAuthList()) {
				if("Y".equals(reqDTO.getVIncLowdept()) && "AUTH_FLAG010".equals(vo.getVFlagAuth())) {
					Deptcd_flag010 = vo.getVAuthcd() + "/" + Deptcd_flag010;
				}else {
					reqDTO.setVFlagAuth(vo.getVFlagAuth());
					reqDTO.setVAuthcd(vo.getVAuthcd());
					reqDTO.setVFunccd(vo.getVFunccd());
					reqDTO.setVRegUserid(sessionUtil.getLoginId());
					authorityMapper.insertAuth(reqDTO);
				}
			}
			
			if(StringUtils.isNotEmpty(Deptcd_flag010)) {
				reqDTO.setArrDeptcd(Deptcd_flag010.split("/"));
				reqDTO.setVFlagAuth("AUTH_FLAG010");
				authorityMapper.insertAuthLowDept(reqDTO);
			}
			
			//문서+파일 저장하는 탭이면, 파일 첨부 권한도 저장하기
			if("N".equals(reqDTO.getVFlagOnlyFile()) && "Y".equals(reqDTO.getVFlagAttachAuth())) {
				reqDTO.setVFlagRec("AUTH040");		//파일 권한 : AUTH040
				
				for(AuthSecuritySaveReqDTO vo : reqDTO.getAuthList()) {
					reqDTO.setVFlagAuth(vo.getVFlagAuth());
					reqDTO.setVAuthcd(vo.getVAuthcd());
					reqDTO.setVFunccd(vo.getVFunccd());
					reqDTO.setVRegUserid(sessionUtil.getLoginId());
					authorityMapper.insertAuth(reqDTO);
				}
			}
		}
		
		responseVO.setOk(null);
		return responseVO;
	}
	
}
