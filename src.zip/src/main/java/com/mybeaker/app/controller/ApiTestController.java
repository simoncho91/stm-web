package com.mybeaker.app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mybeaker.app.approval.model.ReqApprovalPrcDTO;
import com.mybeaker.app.approval.model.ReqReferenceDTO;
import com.mybeaker.app.approval.model.ReqResApprovalDTO;
import com.mybeaker.app.approval.model.ResApprovalPrcDTO;
import com.mybeaker.app.common.service.AWSService;
import com.mybeaker.app.common.service.CommonService;
import com.mybeaker.app.config.SecurityUser;
import com.mybeaker.app.labnote.service.LabNoteSAPInterfaceService;
import com.mybeaker.app.model.dto.TestDTO;
import com.mybeaker.app.model.enums.CommonResultCode;
import com.mybeaker.app.model.vo.ResponseVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Tag(name = "API 테스트용 서비스", description="API 테스트용 서비스")
@RestController
@RequestMapping("/api/test")
@RequiredArgsConstructor
public class ApiTestController {
    private final CommonService commonService;
    private final LabNoteSAPInterfaceService labNoteSAPInterfaceService;
    private final AWSService awsService;
    
    @PostMapping("/appr-save")
    public ResponseEntity<ResponseVO> apprSave (@RequestBody @Valid ReqResApprovalDTO params) {
        ResponseVO responseVo = new ResponseVO();
        log.debug("TestController.apprSave : params = {}", params);
        
        commonService.handlingOfApprovalEp("APS030", "결재 테스트", params);
        responseVo.setCreateOk(null);
        
        return ResponseEntity.ok(responseVo);
    }
    
    @PostMapping("/appr-process-save")
    public ResponseEntity<ResponseVO> apprProcessSave (
            @RequestBody @Valid ReqApprovalPrcDTO params
            ) {
        ResponseVO responseVo = new ResponseVO();
        log.debug("TestController.apprProcessSave : params = {}", params);
        
        ResApprovalPrcDTO resApprovalPrcDTO = commonService.handlingOfApprovalPrcEp(params);
        
        responseVo.setOk(resApprovalPrcDTO);
        return ResponseEntity.ok(responseVo);
    }
    
    @PostMapping("/reference-save")
    public ResponseEntity<ResponseVO> referenceSave (
            @RequestBody @Valid ReqReferenceDTO params
            ) {
        ResponseVO responseVo = new ResponseVO();
        log.debug("TestController.referenceSave : params = {}", params);
        
        commonService.insertReference(params);
        responseVo.setCreateOk(null);
        
        return ResponseEntity.ok(responseVo);
    }
    
    @PostMapping("/upload-test")
    public ResponseEntity<ResponseVO> uploadTest (
            @RequestBody @Valid TestDTO params,
            @AuthenticationPrincipal SecurityUser securityUser
            ) {
        ResponseVO responseVo = new ResponseVO();
        log.debug("TestController.uploadTest : params = {}", params);
        
        int result = commonService.saveCommAttach(params.getFileList(), "TEST01", params.getVRecordid());
        
        if (result > 0) {
            responseVo.setCreateOk(null);
        } else {
            responseVo.setBadRequest("C9999", CommonResultCode.SAVE_FAIL, null);
        }
        
        return ResponseEntity.ok(responseVo);
    }
    
    @Operation(summary = "SAP 인터페이스 테스트", description = "SAP 인터페이스 테스트한다."
    		+ "<br> PPI2036 : getT_ZPLMS013, PPI2036_BOM : getT_ZPLMS013_BOM, PPI2037 : getT_ZPLMS014"
    		+ "<br> QMI0080 : getT_ZPLMS017, QMI6017 : getT_ZPLMT74, MDI0010 : getT_ZPLMS014")
    @GetMapping("/sap-test")
    public ResponseEntity<ResponseVO> sapTest (
    		@RequestParam(defaultValue = "PPI2036") String vInterfaceId,
    		@RequestParam(defaultValue = "1510") String vWerks,
        	@RequestParam(defaultValue = "3059458") String vMatnr,
        	@RequestParam(defaultValue = "UN") String vLand) {
    	log.debug("sap-test Start!");
    	log.debug("vInterfaceId : {}", vInterfaceId);
    	log.debug("vWerks : {}", vWerks);
    	log.debug("vMatnr : {}", vMatnr);
    	log.debug("vLand : {}", vLand);
    	
    	ResponseVO responseVO = new ResponseVO();
    	
    	if("PPI2036".equals(vInterfaceId)) {
    		responseVO.setOk(Optional.ofNullable(labNoteSAPInterfaceService.getT_ZPLMS013(vWerks, vMatnr, vLand))
    				.orElseGet(() -> List.of()));
    	}
    	else if("PPI2036_BOM".equals(vInterfaceId)) {
    		responseVO.setOk(Optional.ofNullable(labNoteSAPInterfaceService.getT_ZPLMS013_BOM(vWerks, vMatnr, vLand))
    				.orElseGet(() -> List.of()));
    	}
    	else if("PPI2037".equals(vInterfaceId)) {
    		responseVO.setOk(Optional.ofNullable(labNoteSAPInterfaceService.getT_ZPLMS014(vWerks, vMatnr))
    				.orElseGet(() -> List.of()));
    	}
    	else if("QMI0080".equals(vInterfaceId)) {
    		responseVO.setOk(Optional.ofNullable(labNoteSAPInterfaceService.getT_ZPLMS017(vMatnr, vLand))
    				.orElseGet(() -> List.of()));
    	}
    	else if("QMI6017".equals(vInterfaceId)) {
    		responseVO.setOk(Optional.ofNullable(labNoteSAPInterfaceService.getT_ZPLMT74(vMatnr))
    				.orElseGet(() -> List.of()));
    	}
    	else if("MDI0010".equals(vInterfaceId)) {
    		responseVO.setOk(Optional.ofNullable(labNoteSAPInterfaceService.getZmdMhdhbInfo(vMatnr, "API TEST"))
    				.orElseGet(() -> "Interface result is Empty"));
    	}
    	else {
    		responseVO.setOk("테스트 케이스에 없는 인터페이스 ID 입니다.");
    	}
    	return ResponseEntity.ok(responseVO);
    }
    
    @Operation(summary = "S3 PreSignedURL 테스트", description = "S3 PreSignedURL 테스트한다.")
    @GetMapping("/s3-pre-signed-url-test")
    public ResponseEntity<ResponseVO> s3PreSignedURLTest (
    		@RequestParam String objectKey) {
    	log.debug("s3-pre-signed-url-test Start!");
    	log.debug("objectKey : {}", objectKey);
    	
    	ResponseVO responseVO = new ResponseVO();
    	responseVO.setOk(awsService.getPreSignedURL(objectKey));
    	return ResponseEntity.ok(responseVO);
    }
}
