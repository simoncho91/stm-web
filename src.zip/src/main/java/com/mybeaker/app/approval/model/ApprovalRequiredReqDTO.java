package com.mybeaker.app.approval.model;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ApprovalRequiredReqDTO {
	@NotEmpty
	@JsonProperty("vApprCd")
	private String vApprCd;
	
	@JsonProperty("vApprUserType")
	private String vApprUserType;
}
