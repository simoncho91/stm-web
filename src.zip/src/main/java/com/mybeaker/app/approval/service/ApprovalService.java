package com.mybeaker.app.approval.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.mybeaker.app.approval.mapper.ApprovalMapper;
import com.mybeaker.app.approval.model.ApprovalDTO;
import com.mybeaker.app.approval.model.ApprovalDetailDTO;
import com.mybeaker.app.approval.model.ApprovalRequiredReqDTO;
import com.mybeaker.app.approval.model.ApprovalRequiredResDTO;
import com.mybeaker.app.approval.model.ApprovalSearchReqDTO;
import com.mybeaker.app.approval.model.ReferenceDTO;
import com.mybeaker.app.approval.model.ReqApprovalPrcDTO;
import com.mybeaker.app.approval.model.ResApprovalPrcDTO;
import com.mybeaker.app.common.form.MailForm;
import com.mybeaker.app.common.model.MailDTO;
import com.mybeaker.app.common.model.OrganizationDTO;
import com.mybeaker.app.common.service.CommonService;
import com.mybeaker.app.labnote.model.ElabShelflifeContVO;
import com.mybeaker.app.labnote.model.ElabShelflifeHisVO;
import com.mybeaker.app.labnote.model.ElabShelflifeMstVO;
import com.mybeaker.app.labnote.model.ElabShelflifeSubVO;
import com.mybeaker.app.labnote.model.ShelfLifeVO;
import com.mybeaker.app.labnote.service.LabNoteCommonService;
import com.mybeaker.app.model.Const;
import com.mybeaker.app.model.dto.PagingDTO;
import com.mybeaker.app.model.dto.ResCommSearchInfoDTO;
import com.mybeaker.app.model.enums.ApprovalResultCode;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.skincare.model.ShelfLifeCodeReqDTO;
import com.mybeaker.app.utils.CommonUtil;
import com.mybeaker.app.utils.ConvertUtil;
import com.mybeaker.app.utils.SessionUtil;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ApprovalService {
	private final ApprovalMapper approvalMapper;

	private final SessionUtil sessionUtil;

	private final CommonService commonService;

	private final LabNoteCommonService labNoteCommonService;

	public ResponseVO selectApprovalList(ApprovalSearchReqDTO approvalSearchReqDTO) {
		ResponseVO responseVO = new ResponseVO();

		approvalSearchReqDTO.setVApprMstStatus("APS030");
		approvalSearchReqDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
		approvalSearchReqDTO.setVApprUserId(sessionUtil.getLoginId());

		int totalCnt = approvalMapper.selectApprovalListCount(approvalSearchReqDTO);
		List<ApprovalDTO> list = null;
		CommonUtil.setPaging(approvalSearchReqDTO, totalCnt);

		if (totalCnt > 0) {
			list = approvalMapper.selectApprovalList(approvalSearchReqDTO);
		}

		PagingDTO page = ConvertUtil.convert(approvalSearchReqDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
									.page(page)
									.list(list)
									.build();

		responseVO.setOk(res);
		return responseVO;
	}

	public ResponseVO selectApprovalFinishList(ApprovalSearchReqDTO approvalSearchReqDTO) {
		ResponseVO responseVO = new ResponseVO();

		approvalSearchReqDTO.setVSearchFinish("Y");
		approvalSearchReqDTO.setLocalLanguage(sessionUtil.getLocalLanguage());
		approvalSearchReqDTO.setVApprUserId(sessionUtil.getLoginId());

		int totalCnt = approvalMapper.selectApprovalListCount(approvalSearchReqDTO);
		List<ApprovalDTO> list = null;
		CommonUtil.setPaging(approvalSearchReqDTO, totalCnt);

		if (totalCnt > 0) {
			list = approvalMapper.selectApprovalList(approvalSearchReqDTO);
		}

		PagingDTO page = ConvertUtil.convert(approvalSearchReqDTO, PagingDTO.class);

		ResCommSearchInfoDTO res = ResCommSearchInfoDTO.builder()
									.page(page)
									.list(list)
									.build();

		responseVO.setOk(res);
		return responseVO;
	}

	public ApprovalDTO selectApprovalInfo(String apprCd) {
		return approvalMapper.selectApprovalInfo(apprCd, sessionUtil.getLocalLanguage());
	}

	public List<ApprovalDetailDTO> selectApprovalDetailList(String apprCd) {
		return approvalMapper.selectApprovalDetailList(apprCd, sessionUtil.getLocalLanguage());
	}

	public List<OrganizationDTO> selectReferenceList(String recordId) {
		return approvalMapper.selectReferenceList(recordId);
	}

	public String selectCheckApprovalUser(String apprCd) {
		return approvalMapper.selectCheckApprovalUser(apprCd, sessionUtil.getLoginId());
	}

	public ResponseVO selectApprovalRequiredInfo(ApprovalRequiredReqDTO reqDto) {
		ResponseVO responseVO = new ResponseVO();

		String vApprCd = reqDto.getVApprCd();
		String apprUserType = reqDto.getVApprUserType();

		//메일에서 링크 타고 들어온 팝업의 결재의 경우 결재 가능 상태인지 체크
		if (StringUtils.isEmpty(apprUserType)) {
			apprUserType = approvalMapper.selectCheckApprovalUser(vApprCd, sessionUtil.getLoginId());

			if (StringUtils.isEmpty(apprUserType)) {
				//불러온 데이터에서 값이 없으면 결재 가능한 상태가 아니기 때문에 오류 메세지 전달
				responseVO.setOkWithCode(Const.FAIL, "결재를 진행하실 수 없습니다.", null);
				return responseVO;
			}
		}

		responseVO.setOk(ApprovalRequiredResDTO.builder()
											   .apprInfo(approvalMapper.selectApprovalInfo(vApprCd, sessionUtil.getLocalLanguage()))
											   .build());
		return responseVO;
	}

//	===========================================================================================================================================================
//	사용기한 관리 결재 처리 로직 Start
//	[AS-IS] LabNoteCommonController - lab_note_shelf_life_code_save - 6168 line 부터 참고
	@Transactional
	public ResponseVO updateShelfLifeCode(ShelfLifeCodeReqDTO shelfLifeCodeReqDTO) {
		ResponseVO responseVO = new ResponseVO();

		ElabShelflifeMstVO vo = labNoteCommonService.selectDOCShelflifeMSTView(ElabShelflifeMstVO.builder()
																								 .vApprCd(shelfLifeCodeReqDTO.getVApprCd())
																								 .localLanguage(sessionUtil.getLocalLanguage())
																								 .build());

		if (ObjectUtils.isEmpty(vo)) {
			responseVO.setOkWithCode(Const.FAIL, "필수 데이터가 없습니다.", null);
			return responseVO;
		}


		ResApprovalPrcDTO resApprovalPrcDTO = commonService.handlingOfApprovalPrcEp(ReqApprovalPrcDTO.builder()
																									 .vApprCd(shelfLifeCodeReqDTO.getVApprCd())
																									 .nCurRegseq(shelfLifeCodeReqDTO.getNCurRegseq())
																									 .nCurApprseq(shelfLifeCodeReqDTO.getNCurApprseq())
																									 .vApprStatus(shelfLifeCodeReqDTO.getVApprStatus())
																									 .vApprSubStatus(shelfLifeCodeReqDTO.getVApprSubStatus())
																									 .vApprOpinion(shelfLifeCodeReqDTO.getVApprOpinion())
																									 .build());

		ApprovalResultCode resultCode = resApprovalPrcDTO.getApprovalResultCode();

		if (ApprovalResultCode.ACCEPT_END.getCode().equals(resultCode.getCode())) {
			shelfLifeCodeReqDTO.setVRecordId(vo.getVRecordid());

			if ("SLK020".equals(vo.getVDocKind())) {
				shelfLifeCodeReqDTO.setVStatusCd("SLS020");
			} else if ("SLK030".equals(vo.getVDocKind())) {
				shelfLifeCodeReqDTO.setVStatusCd("SLS040");
			}

			shelfLifeCodeReqDTO.setVNoteType(vo.getVNoteType());
			this.updateShelfListMst_ContStatus(shelfLifeCodeReqDTO);

			HashMap<String, String> params = new HashMap<>();

			if (!ObjectUtils.isEmpty(shelfLifeCodeReqDTO.getApprContCdList())) {
				params.put("apprContCdList", shelfLifeCodeReqDTO.getApprContCdList().stream().collect(Collectors.joining(",")));
			}
			if (!ObjectUtils.isEmpty(shelfLifeCodeReqDTO.getApprBeforeLifeList())) {
				params.put("apprBeforeLifeList", shelfLifeCodeReqDTO.getApprBeforeLifeList().stream().collect(Collectors.joining(",")));
			}
			if (!ObjectUtils.isEmpty(shelfLifeCodeReqDTO.getApprAfterLifeList())) {
				params.put("apprAfterLifeList", shelfLifeCodeReqDTO.getApprAfterLifeList().stream().collect(Collectors.joining(",")));
			}
			
			String pageUrl = new StringBuilder()
					.append("elab/common/lab_note_shelf_life_code_appr_view.do?")
					.append("i_sApprCd=")
					.append(shelfLifeCodeReqDTO.getVApprCd())
					.append("&i_sApprClass=LAB_NOTE_SHELFLIFE")
					.toString();
			
			params.put("url", pageUrl);
			
			commonService.updateSkyApprovalAprvDtlUrl(shelfLifeCodeReqDTO.getVApprCd(), pageUrl);

			// 메일발송(참조)
			commonService.sendMailReference(ReferenceDTO.builder().vRecordId(vo.getVRecordid())
																  .vTitle(String.format("%s%s(%s)", "[사용기한 변경 안내]", vo.getVTitle(), shelfLifeCodeReqDTO.getVApprMatrCd()))
																  .vFlagContent("Y")
																  .vContent(new MailForm().getMailContent(MailDTO.MAIL_SHELFLIFE_CHANGE_INFO, params))
																  .build());

			// 메일발송(결재)
			commonService.sendMailApproval(ApprovalDTO.builder().vApprCd(shelfLifeCodeReqDTO.getVApprCd())
																.vResultStatus(resultCode.getCode())
																.vTitle(String.format("%s%s(%s)", "[사용기한 결재 승인완료]", vo.getVTitle(), shelfLifeCodeReqDTO.getVApprMatrCd()))
																.vUrl(pageUrl)
																.build());

			responseVO.setOkWithCode(resultCode.getCode(), "승인하였습니다.", null);
		} else if (ApprovalResultCode.APPR_SUCC.getCode().equals(resultCode.getCode())
				|| ApprovalResultCode.MUTUAL_SUCC.getCode().equals(resultCode.getCode())) {

			// 메일발송(결재)
			commonService.sendMailApproval(ApprovalDTO.builder().vApprCd(shelfLifeCodeReqDTO.getVApprCd())
																.vResultStatus(resultCode.getCode())
																.build());

			responseVO.setOkWithCode(resultCode.getCode(), "결재하였습니다.", null);
		} else if (ApprovalResultCode.APPR_BACK.getCode().equals(resultCode.getCode())) {
			ShelfLifeVO shelfLifeVO = ShelfLifeVO.builder()
												 .vRecordid(vo.getVRecordid())
												 .vStatusCd("SLS050")
												 .vUpdateUserid(sessionUtil.getLoginId())
												 .build();

			//원래상태로 되돌리기
			if ("SLK020".equals(vo.getVDocKind())) {
				shelfLifeVO.setVBeforeStatusCd("SLS020");
			} else if ("SLK030".equals(vo.getVDocKind())) {
				shelfLifeVO.setVBeforeStatusCd("SLS040");
			}

			labNoteCommonService.updateShelfLife(shelfLifeVO);

			// 메일발송(결재)
			commonService.sendMailApproval(ApprovalDTO.builder().vApprCd(shelfLifeCodeReqDTO.getVApprCd())
																.vResultStatus(resultCode.getCode())
																.vTitle(String.format("%s%s(%s)", "[사용기한 결재 반려]", vo.getVTitle(), shelfLifeVO.getVApprMatrCd()))
																.build());

			responseVO.setOkWithCode(resultCode.getCode(), "반려하였습니다.", null);
		} else {
			responseVO.setOkWithCode(Const.FAIL, resultCode.getMessage(), null);
		}

		return responseVO;
	}

//	[AS-IS] LabNoteCommonServiceImpl - updateShelfListMst_ContStatus - 8049 line 부터 참고
	@Transactional
	private void updateShelfListMst_ContStatus(ShelfLifeCodeReqDTO shelfLifeCodeReqDTO) {
		String vStatuCd = shelfLifeCodeReqDTO.getVStatusCd();
		String vRecordId = shelfLifeCodeReqDTO.getVRecordId();

		labNoteCommonService.updateShelfListMstStatus(vStatuCd, vRecordId);

		//이전데이터 가져오기
		List<ElabShelflifeSubVO> list = labNoteCommonService.selectBeforeShelfLife(vRecordId);
		List<String> apprContCd = new ArrayList<>();
		List<String> apprBeforeLife = new ArrayList<>();
		List<String> apprAfterLife = new ArrayList<>();
//		String StrMatrCd = "";
		List<String> StrMatrCd = new ArrayList<>();

		if (!ObjectUtils.isEmpty(list)) {
			ElabShelflifeContVO contVo = ElabShelflifeContVO.builder()
															.vStatusCd(vStatuCd)
															.vNoteType(shelfLifeCodeReqDTO.getVNoteType())
															.build();

			ElabShelflifeHisVO hisVo = ElabShelflifeHisVO.builder().build();

			for (ElabShelflifeSubVO vo : list) {
				String contCd = vo.getVContCd();

				StrMatrCd.add(contCd);

				contVo.setVContCd(contCd);

				hisVo.setVContCd(contCd);
				hisVo.setVBeforeShelfLife(vo.getVChShelfLife());

				if ("ETC".equals(vo.getVShelfLife())) {
					contVo.setVShelfLife(vo.getVShelfLifeTxt());
					hisVo.setVAfterShelfLife(vo.getVShelfLifeTxt());
				} else {
					contVo.setVShelfLife(vo.getVShelfLife());
					hisVo.setVAfterShelfLife(vo.getVShelfLife());
				}

				hisVo.setVChangeReason(vo.getVChangeReason());

				labNoteCommonService.updateShelfListContStatus(contVo); // CONT테이블 상태값 및 SHELF LIFE 값 변경
				labNoteCommonService.setElabShelfLifeSendSap(contCd); // SAP
				if("SLS040".equals(vStatuCd)) { // TDD완료변경이 승인 될 때,
					labNoteCommonService.updateTddShelfLifeVerSLS040(contCd); // TDD UPDATE
				} else if ("SLS020".equals(vStatuCd)) { //확정변경 승인 될 때,
					labNoteCommonService.updateTddShelfLifeVerSLS020(contCd);
				}

				hisVo.setVRegUserid(vo.getVRegUserid());
				labNoteCommonService.insertChangeInfo(hisVo);

				apprContCd.add(contCd);
				apprBeforeLife.add(vo.getVChShelfLife());
				apprAfterLife.add(contVo.getVShelfLife());
			}

			shelfLifeCodeReqDTO.setVApprMatrCd(StrMatrCd.stream().collect(Collectors.joining(",")));
			shelfLifeCodeReqDTO.setApprContCdList(apprContCd);
			shelfLifeCodeReqDTO.setApprBeforeLifeList(apprBeforeLife);
			shelfLifeCodeReqDTO.setApprAfterLifeList(apprAfterLife);
		}
	}

	public int insertApprovalMst(ApprovalDTO apprInfo) {
		return approvalMapper.insertApprovalMst(apprInfo);
	}
}
