package com.mybeaker.app.approval.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.mybeaker.app.approval.model.ApprovalDTO;
import com.mybeaker.app.approval.model.ApprovalDetailDTO;
import com.mybeaker.app.approval.model.ApprovalPrcDTO;
import com.mybeaker.app.approval.model.ApprovalSearchReqDTO;
import com.mybeaker.app.approval.model.ReferenceDTO;
import com.mybeaker.app.approval.model.ReqApprovalPrcDTO;
import com.mybeaker.app.approval.model.ReqReferenceDTO;
import com.mybeaker.app.approval.model.ReqResApprovalDTO;
import com.mybeaker.app.common.model.OrganizationDTO;
import com.mybeaker.app.labnote.model.MassApprovalPassDTO;
import com.mybeaker.app.labnote.model.WokAppointDesignationRefDTO;

@Mapper
public interface ApprovalMapper {
	public int selectApprovalListCount(ApprovalSearchReqDTO reqDto);

	public List<ApprovalDTO> selectApprovalList(ApprovalSearchReqDTO reqDto);

	public ApprovalDTO selectApprovalInfo(String apprCd, String localLanguage);

	public List<ApprovalDetailDTO> selectApprovalDetailList(String apprCd, String localLanguage);

	public int insertApprovalMst(ApprovalDTO apprInfo);

	public void insertApprovalSub(ReqResApprovalDTO reqResApprovalDTO);

	public int updateApprovalMst(ApprovalDTO apprInfo);

	public void deleteApprovalSub(String vApprCd, int nCurRegseq);

	public ApprovalPrcDTO selectApprovalPrcInfo(String vApprCd);

	public void updateApprovalSubPrc(ReqApprovalPrcDTO reqApprovalPrcDTO);

	public void updateApprovalMstPrc(ReqApprovalPrcDTO reqApprovalPrcDTO);

	public void updateApprovalSubStatus(ReqApprovalPrcDTO reqApprovalPrcDTO);

	public void deleteReferenceAll(ReqReferenceDTO reqReferenceDTO);

	public void insertReference(ReqReferenceDTO reqReferenceDTO);

	public List<OrganizationDTO> selectReferenceList(String recordId);

	public String selectCheckApprovalUser(String apprCd, String loginId);

	public String selectStrApprDivisionPrdSC(String apprCd);

	public String selectStrApprDivisionPrdMU(String apprCd);

	public String selectStrApprDivisionPrdHBD(String apprCd);

	public String selectStrApprDivisionPrdSA(String apprCd);

	public List<ApprovalDTO> selectApprovalSendMailInfo(String vApprCd);

	public List<ReferenceDTO> selectReferenceMailList(String vRecordId);

	public List<ApprovalDTO> selectELabNoteApprovalSendMailList(String vApprCd);

	public int insertApprovalMstPass(MassApprovalPassDTO massDTO);

	public List<String> selectReferenceUserList(String vRecordId);

	public List<WokAppointDesignationRefDTO> selectAppointUserMailList(String vAppointType);
}
