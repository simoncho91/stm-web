package com.mybeaker.app.approval.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ReqApprovalPrcDTO {
	@JsonProperty("vApprCd")
	private String vApprCd;
	
	@JsonProperty("nCurRegseq")
	private int nCurRegseq;
	
	@JsonProperty("nCurApprseq")
	private int nCurApprseq;
	
	@JsonProperty("vApprStatus")
	private String vApprStatus; // SKY_APPROVALD.V_APPR_STATUS
	
	@JsonProperty("vApprOpinion")
	@Builder.Default
	private String vApprOpinion = "";
	
	private String vApprSubStatus; // SKY_APPROVALD.V_APPR_SUB_STATUS
	
	private String vApprMstStatus; // SKY_APPROVAL.V_APPR_STATUS
	
	private int nNextCurApprseq;
}
