package com.mybeaker.app.approval.model;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ApprovalPrcDTO {
	private String vApprCd;
	
	private int nCurRegseq;
	
	private int nCurApprseq;
	
	private String vApprClass;
	
	private String vApprStatus;
	
	private int nNextCurApprseq;
	
	private String vApprUserid;
	
	private String vApprSubStatus;
	
	private String vApprLastYn;
	
	private String vDraftTitle;
}
