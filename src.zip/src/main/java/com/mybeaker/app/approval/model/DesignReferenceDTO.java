package com.mybeaker.app.approval.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class DesignReferenceDTO {
	@JsonProperty("vRecordId")
	private String vRecordId;
	
	@JsonProperty("vTitle")
	private String vTitle;
	
	@JsonProperty("vFlagContent")
	private String vFlagContent;
	
	@JsonProperty("vContent")
	private String vContent;
	
	@JsonProperty("vFlagRec")
	private String vFlagRec;
	
	@JsonProperty("vRefCd")
	private String vRefCd;
	
	@JsonProperty("vEmail")
	private String vEmail;
	
	@JsonProperty("vFlagFile")
	private String vFlagFile;
	
	@JsonProperty("vUrl")
	private String vUrl;
	
	private List<String> apprContCdList;
	
	private List<String> apprBeforeLifeList;
	
	private List<String> apprAfterLifeList;
	
	@JsonProperty("vAppointType")
	private String vAppointType;
	
}
