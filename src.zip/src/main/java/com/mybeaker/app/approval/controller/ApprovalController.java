package com.mybeaker.app.approval.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mybeaker.app.approval.model.ApprovalDTO;
import com.mybeaker.app.approval.model.ApprovalDetailDTO;
import com.mybeaker.app.approval.model.ApprovalRequiredReqDTO;
import com.mybeaker.app.approval.model.ApprovalSearchReqDTO;
import com.mybeaker.app.approval.model.ReqResApprovalDTO;
import com.mybeaker.app.approval.service.ApprovalService;
import com.mybeaker.app.model.vo.ResponseVO;
import com.mybeaker.app.skincare.model.ShelfLifeCodeReqDTO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Tag(name = "결재 공통 팝업 및 모듈 api", description="결재 공통 팝업 및 모듈 api")
@RestController
@RequestMapping("/api/appr")
@RequiredArgsConstructor
public class ApprovalController {
	private final ApprovalService approvalService;
	
	@Operation(summary = "결재함 > 결재 리스트(미결)", description = "결재함 > 결재 리스트(미결)를 조회한다. (화면ID : CO-PA-011)")
	@GetMapping("/select-approval-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectApprovalList (
		ApprovalSearchReqDTO approvalSearchReqDTO
	) {
		log.debug("ApprovalController.selectApprovalList");
		log.debug("ApprovalSearchReqDTO : {}", approvalSearchReqDTO);
		
		return ResponseEntity.ok(approvalService.selectApprovalList(approvalSearchReqDTO));
	}
	
	@Operation(summary = "결재함 > 결재 완료 리스트", description = "결재함 > 결재 완료 리스트를 조회한다. (화면ID : CO-PA-013)")
	@GetMapping("/select-approval-finish-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectApprovalFinishList (
		ApprovalSearchReqDTO approvalSearchReqDTO
	) {
		log.debug("ApprovalController.selectApprovalFinishList");
		log.debug("ApprovalSearchReqDTO : {}", approvalSearchReqDTO);
		
		return ResponseEntity.ok(approvalService.selectApprovalFinishList(approvalSearchReqDTO));
	}
	
	@GetMapping("/select-approval-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectApprovalInfo (
			@RequestParam String apprCd
			) {
		log.debug("ApiApprController.selectApprovalInfo : apprCd = {}", apprCd);
		
		ResponseVO responseVO = new ResponseVO();
		ApprovalDTO apprInfo = approvalService.selectApprovalInfo(apprCd);
		List<ApprovalDetailDTO> apprList = null;

		if (apprInfo != null) {
			apprList = approvalService.selectApprovalDetailList(apprCd);
		}
		
		ReqResApprovalDTO resApprovaDTO = ReqResApprovalDTO.builder()
											.apprInfo(apprInfo)
											.apprList(apprList)
											.build();
		
		responseVO.setOk(resApprovaDTO);
		
		return ResponseEntity.ok(responseVO);
	}
	
	@GetMapping("/select-reference-list")
	public @ResponseBody ResponseEntity<ResponseVO> selectReferenceList (
			@RequestParam String recordId
			) {
		log.debug("ApiApprController.selectReferenceList : recordId = {}", recordId);
		
		ResponseVO responseVO = new ResponseVO();
		
		responseVO.setOk(approvalService.selectReferenceList(recordId));
		
		return ResponseEntity.ok(responseVO);
	}
	
	@Operation(summary = "결재함 > 결재 리스트(미결)", description = "의견 작성에 필요한 데이터를 조회한다.")
	@GetMapping("/select-approval-required-info")
	public @ResponseBody ResponseEntity<ResponseVO> selectApprovalRequiredInfo (
		@Valid ApprovalRequiredReqDTO approvalRequiredReqDTO
	) {
		log.debug("ApiApprController.selectApprovalRequiredInfo");
		log.debug("ApprovalRequiredReqDTO : {}", approvalRequiredReqDTO);
		
		return ResponseEntity.ok(approvalService.selectApprovalRequiredInfo(approvalRequiredReqDTO));
	}
	
	@Operation(summary = "사용기한 관리 결재 처리", description = "사용기한 관리 결재 처리")
	@PostMapping("/update-shelf-life-code")
	public @ResponseBody ResponseEntity<ResponseVO> updateShelfLifeCode (
			@RequestBody @Valid ShelfLifeCodeReqDTO shelfLifeCodeReqDTO
			) {
		log.debug("ApprovalController.updateShelfLifeCode");
		log.debug("ShelfLifeCodeReqDTO : {}", shelfLifeCodeReqDTO);
		
		return ResponseEntity.ok(approvalService.updateShelfLifeCode(shelfLifeCodeReqDTO));
	}
}
