package com.mybeaker.app.approval.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.common.model.OrganizationDTO;
import com.mybeaker.app.model.dto.ParentDTO;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class ReqReferenceDTO extends ParentDTO {
	@JsonProperty("vRecordid")
	private String vRecordid;

	private List<OrganizationDTO> referenceList;

	@Builder
	public ReqReferenceDTO(String vRegUserid, String vRegDtm, String vUpdateUserid, String vUpdateDtm,
			String vRecordid, List<OrganizationDTO> referenceList) {
		super(vRegUserid, vRegDtm, vUpdateUserid, vUpdateDtm);
		this.vRecordid = vRecordid;
		this.referenceList = referenceList;
	}
}
