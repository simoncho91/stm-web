package com.mybeaker.app.approval.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mybeaker.app.model.dto.ParentPagingDTO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class ApprovalSearchReqDTO extends ParentPagingDTO{
	@JsonProperty("vKeyword")
	private String vKeyword;
	
	private String localLanguage;
	
	@JsonProperty("vApprMstStatus")
	private String vApprMstStatus;
	
	@JsonProperty("vApprUserId")
	private String vApprUserId;
	
	@JsonProperty("vDraftSearchStartDt")
	private String vDraftSearchStartDt;
	
	@JsonProperty("vDraftSearchEndDt")
	private String vDraftSearchEndDt;
	
	@JsonProperty("vApprClass")
	private String vApprClass;
	
	@JsonProperty("vSearchFinish")
	private String vSearchFinish;
}
