package com.mybeaker.app.approval.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ApprovalRequiredResDTO {
	@JsonProperty("apprInfo")
	private ApprovalDTO apprInfo;
}
