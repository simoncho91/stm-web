package com.mybeaker.app.approval.model;

import com.mybeaker.app.model.enums.ApprovalResultCode;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class ResApprovalPrcDTO {
	private ApprovalResultCode approvalResultCode;
	
	private String returnStatus;
	
	private String sendMailYn;
	
	private String draftTitle;
}
