package com.mybeaker.app.approval.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class NoteApprovalDTO {
	@JsonProperty("vApprCd")
	private String vApprCd;

	@JsonProperty("vLabNoteCd")
	private String vLabNoteCd;

	@JsonProperty("nVersion")
	private int nVersion;

	@JsonProperty("vNoteType")
	private String vNoteType;

	@JsonProperty("vUrl")
	private String vUrl;
	
	@JsonProperty("vTitle")
	private String vTitle;
}
