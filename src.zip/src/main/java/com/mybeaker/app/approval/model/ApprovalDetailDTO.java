package com.mybeaker.app.approval.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ApprovalDetailDTO {
	@JsonProperty("vApprCd")
	private String vApprCd;
	
	@JsonProperty("nCurRegseq")
	private int nCurRegseq;
	
	@JsonProperty("nCurApprseq")
	private int nCurApprseq;
	
	@JsonProperty("vApprUserid")
	private String vApprUserid;
	
	@JsonProperty("vApprUserNm")
	private String vApprUserNm;
	
	@JsonProperty("vApprOffinm")
	private String vApprOffinm;
	
	@JsonProperty("vApprPositcd")
	private String vApprPositcd;
	
	@JsonProperty("vApprPositnm")
	private String vApprPositnm;
	
	@JsonProperty("vApprDutynm")
	private String vApprDutynm;
	
	@JsonProperty("vApprUserType")
	private String vApprUserType;
	
	@JsonProperty("vApprUserTypenm")
	private String vApprUserTypenm;
	
	@JsonProperty("vApprStatus")
	private String vApprStatus;
	
	@JsonProperty("vApprStatusnm")
	private String vApprStatusnm;
	
	@JsonProperty("vApprType")
	private String vApprType;
	
	@JsonProperty("vApprTypenm")
	private String vApprTypenm;
	
	@JsonProperty("vApprSubStatus")
	private String vApprSubStatus;
	
	@JsonProperty("vApprSubStatusnm")
	private String vApprSubStatusnm;
	
	@JsonProperty("vApprDtm")
	private String vApprDtm;
	
	@JsonProperty("vApprOpinion")
	private String vApprOpinion;
	
	@JsonProperty("vCompulsoryYn")
	@Builder.Default
	private String vCompulsoryYn = "";
	
	@JsonProperty("vApprDeptnm")
	private String vApprDeptnm;
	
	@JsonProperty("vApprPhoneno")
	private String vApprPhoneno;
}
