package com.mybeaker.app.Exception;

import com.mybeaker.app.model.enums.ResultCode;

import lombok.Getter;

@Getter
public class CustomException extends RuntimeException {

	private static final long serialVersionUID = -1802025835406815353L;
	
    private final String message;
    
    private final String code;
    
    public CustomException(ResultCode resultCode) {
        super(resultCode.getMessage());
        this.message = resultCode.getMessage();
        this.code = resultCode.getCode();
    }
}
