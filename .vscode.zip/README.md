## frontend - Vue3 + Vite + Vuex
## backend  - SpringBoot2.78(Spring 5.3.25, Java11) + hibernate + queryDsl

# Vue3 + Vite

This template should help get you started developing with Vue 3 in Vite. The template uses Vue 3 `<script setup>` SFCs, check out the [script setup docs](https://v3.vuejs.org/api/sfc-script-setup.html#sfc-script-setup) to learn more.

## Recommended IDE Setup

- [VSCode](https://code.visualstudio.com) + [Volar](https://marketplace.visualstudio.com/items?itemName=johnsoncodehk.volar)

# (1) JAVA 11 이상 설치
    URL : https://developer.oracle.com/kr/java

# (2) 노드 js 설치(14버전 이상)
    URL : https://nodejs.org/ko

 설치 완료 후 윈도우 → cmd(명령 프롬포트) → node -version

 VERSION이 노출 되면 정상 설치

 # (3) GIT 설치
    URL : https://git-scm.com

 설치 완료 후 윈도우 → cmd(명령 프롬포트) → git version

 VERSION이 노출 되면 정상 설치

 WORKSPACE 설정 후 git_bash 창에다가 명령어 실행

 EX) git clone -b develop https://gitlab.apdigit.tech/rni_center/my_beaker.git

 PS : git_bash 가 귀찮다면 소스트리 또는 포크를 받으셔도 됩니다.  

 URL : https://www.sourcetreeapp.com , https://git-fork.com

# (4) 실행
 해당 git workspace 에 접근 후

 git_bash 또는 terminal 창에 "npm i" 로 프로젝트에서 사용중인 javascript 플러그인 모두 다운로드

 package.json에 설정되어 있는 npm run dev로 실행

 PS : 빌드는 기존 cli를 쓰지 않고 vite를 사용

# (5) 플러그인
```
sanitize-html
    XSS 관련 대응, INPUT, TEXTAREA 등 태그등에 불필요한 요소를 제거할 수 있음 패키지
```
```
vue-i18n
    다국어 처리 패키지
```
```
vue-plugin-load-script
    외부 스크립트 불러오는 패키지
```
```
v-calendar
    달력 패키지
```
```
vuex-composition-helpers
    Vuex와 Composition API를 쉽게 사용할 수있는 유틸리티 패키지
```
```
js-sha512
    SHA-512 해싱 알고리즘 암호화 패키지
```
## JAVA 패키지
```
janino
     logback 의 조건부 처리 기능을 사용하기 위한 라이브러리
```
```
gson
     구글에서 제공하는 json 변환 라이브러리
```
```
hibernate
    ORM 프레임워크
```
```
queryDsl
    오픈소스 빌더 API, JPQL을 SQL로 변환해주는 라이브러리
```

 # (6) 프로젝트 개발 가이드
## (1) 기본 가이드
 
 패키지 구조 가이드
 - 각 비즈니스 안에서 독립적으로 가져간다.
 - API 명 및 Method 는 동일하게 가져간다.
 예) @PostMapping("/insert-sample") 일 경우 Method, Mapper 명 insertSample 로 동일
 
  비즈니스 패키지 - 예) Biz
   - Controller
   - mapper
   - model
   - service
 
 Mapper.xml 구조 가이드
  src/main/resources/mybatis/mapper/
   - 비즈니스 폴더 - 예) Biz/BizMapper.xml
 
 model 가이드
 각 필드에 @JsonProperty("사용할 필드명") Annotation 사용
 
 @JsonProperty("vLabNoteCd")
 private String vLabNoteCd;
 
## (2) Swagger 사용 API 개발
 
 Sample Controller 참조 각 Annotation 사용
 
 Class -  @Tag(name = "컨트롤러 명", description = "컨트롤러 설명")
 Method - @Operation(summary = "API 명", description = "API 설명")
 
 Swagger 사용 방법
 
 접속URL : ~/swagger-ui/index.html
 
 로그인 API -> 리턴받은 AccessToken 을 Authorize 에 넣고 login -> 각 비즈니스 API 실행
 AccessToken 만료시 위 방법 재실행
 
## (3) 로그인 정보 사용법(SessionUtil)
 
 @RequiredArgsConstructor
 
 private final SessionUtil sessionUtil;
 
 log.debug("SessionUtil.userNm : {}", sessionUtil.getUserNm());
 
 # (4) Param Valid Annotation 사용
 
 중요 로직의 필수 Param Valid 체크시 Controller Method 의 파라미터 영역에 @Valid Annotation 추가
 (@RequestBody @Valid XxxDTO xxxDTO)
 
 해당 DTO 에 체크할 Annotation 추가
 
 @NotEmpty -  각 Annotation 들은 케이스에 맞게 셋팅
 @JsonProperty("vLabNoteCd")
 private String vLabNoteCd;
 
 